// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

/**
 * @title IERC7857
 * @notice Minimal interface for ERC-7857 Intelligent NFTs (INFTs) with
 *         sealed metadata for transferable cognition.
 * @dev    Aligns with the 0G Foundation reference. The sealed metadata
 *         carries the encryption key wrapped to the current owner's
 *         pubkey; on transfer, an attestor re-seals the key to the
 *         recipient and emits Attest. Verifiers may key off the public
 *         commitment (Merkle root of the THOT4096) without ever
 *         touching the sealed payload.
 *
 *         Standard: cypherpunk2048
 *         Target:   Ethereum mainnet (canonical registry)
 */
interface IERC7857 {
    /// @notice Public commitment to the sealed cognition payload.
    /// @dev    For THOT4096 this is the canonical Merkle root.
    function publicCommitment(uint256 tokenId) external view returns (bytes32);

    /// @notice Content address of the encrypted payload (e.g. ipfs://...).
    function payloadCID(uint256 tokenId) external view returns (string memory);

    /// @notice Sealed metadata pointer (Lighthouse Kavach descriptor).
    function sealedMetadata(uint256 tokenId) external view returns (bytes memory);

    /// @notice Transfer the INFT after a valid re-seal attestation.
    /// @param  from         Current owner.
    /// @param  to           Recipient (sealed metadata is re-encrypted to to.pubkey).
    /// @param  tokenId      INFT id.
    /// @param  attestation  Bytes blob produced by the configured TEE / zk attestor.
    function transferWithReseal(
        address from,
        address to,
        uint256 tokenId,
        bytes calldata attestation
    ) external;

    event Mint(uint256 indexed tokenId, address indexed to, bytes32 indexed commitment);
    event Attest(uint256 indexed tokenId, address indexed from, address indexed to, bytes32 attestationHash);
    event Reseal(uint256 indexed tokenId, address indexed newOwner, bytes32 newMetadataHash);
}
