// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {THOTLib} from "./libraries/THOTLib.sol";

/**
 * @title THOTRegistry
 * @notice Canonical append-only registry for the THOT family.
 *
 *         Issuers commit a THOT4096 root with its CID, ternary head,
 *         and EIP-712 issuer signature. Smaller prefix variants are
 *         registered as cryptographically derived from the parent —
 *         silent swapping is impossible by the prefix-binding theorem
 *         in THOTLib.verifyPrefix.
 *
 *         Diagonal edges (distillation, projection, federation) are
 *         recorded as a DAG; the registry is append-only and never
 *         mutates an existing THOT.
 *
 *         Standard: cypherpunk2048
 *         Target:   Ethereum mainnet
 */
contract THOTRegistry {
    using THOTLib for bytes32;

    // -----------------------------------------------------------------
    //                            Types
    // -----------------------------------------------------------------

    struct THOT4096Record {
        bytes32 root;             // Canonical Merkle root.
        bytes32 ternaryHead;      // Dedicated THOT8 sub-leaf hash.
        uint256 ternaryHeadIndex; // Position of the ternary head leaf.
        address issuer;           // BANKON-identity-gated issuer.
        uint64  timestamp;        // Block.timestamp at issuance.
        string  cid;              // ipfs:// or filecoin:// CID.
        string  metadataURI;      // Off-chain metadata (training run, parent THOT, etc.).
        bool    exists;
    }

    struct PrefixRecord {
        bytes32 parentRoot;
        bytes32 prefixRoot;
        uint16  prefixDim;        // One of {8, 768, 1024, 2048}.
        uint64  timestamp;
        bool    exists;
    }

    enum EdgeKind { Distillation, Projection, Federation }

    struct DiagonalEdge {
        bytes32 fromRoot;
        bytes32 toRoot;
        EdgeKind kind;
        bytes32 attestationHash;
        address recorder;
        uint64  timestamp;
    }

    // -----------------------------------------------------------------
    //                            Storage
    // -----------------------------------------------------------------

    /// parentRoot => THOT4096 record
    mapping(bytes32 => THOT4096Record) public parents;

    /// keccak256(parentRoot ‖ prefixDim) => PrefixRecord
    mapping(bytes32 => PrefixRecord) public prefixes;

    /// edgeId => DiagonalEdge (edgeId = keccak256(fromRoot ‖ toRoot ‖ kind ‖ recorder))
    mapping(bytes32 => DiagonalEdge) public edges;

    /// Issuer authorization (BANKON-identity gated; deployer sets, then ossifies).
    mapping(address => bool) public authorizedIssuers;
    address public bankonIdentityGate;

    // -----------------------------------------------------------------
    //                            Events
    // -----------------------------------------------------------------

    event THOT4096Issued(
        bytes32 indexed root,
        address indexed issuer,
        bytes32 ternaryHead,
        string  cid
    );

    event PrefixRegistered(
        bytes32 indexed parentRoot,
        uint16  indexed prefixDim,
        bytes32 prefixRoot
    );

    event DiagonalEdgeRecorded(
        bytes32 indexed fromRoot,
        bytes32 indexed toRoot,
        EdgeKind kind,
        bytes32  attestationHash,
        address  recorder
    );

    event IssuerAuthorized(address indexed issuer);
    event IssuerRevoked(address indexed issuer);

    // -----------------------------------------------------------------
    //                            Errors
    // -----------------------------------------------------------------

    error NotAuthorizedIssuer(address sender);
    error THOTAlreadyExists(bytes32 root);
    error THOTNotFound(bytes32 root);
    error PrefixAlreadyRegistered(bytes32 parentRoot, uint16 prefixDim);
    error PrefixVerificationFailed();
    error InvalidPrefixDimension(uint16 dim);
    error NotIdentityGate(address sender);

    // -----------------------------------------------------------------
    //                          Construction
    // -----------------------------------------------------------------

    /// @param identityGate The BANKON identity gate (an AlgoIDNFT-bound EOA / multisig).
    constructor(address identityGate) {
        bankonIdentityGate = identityGate;
    }

    modifier onlyGate() {
        if (msg.sender != bankonIdentityGate) revert NotIdentityGate(msg.sender);
        _;
    }

    modifier onlyAuthorized() {
        if (!authorizedIssuers[msg.sender]) revert NotAuthorizedIssuer(msg.sender);
        _;
    }

    // -----------------------------------------------------------------
    //                       Issuer authorization
    // -----------------------------------------------------------------

    function authorizeIssuer(address issuer) external onlyGate {
        authorizedIssuers[issuer] = true;
        emit IssuerAuthorized(issuer);
    }

    function revokeIssuer(address issuer) external onlyGate {
        authorizedIssuers[issuer] = false;
        emit IssuerRevoked(issuer);
    }

    // -----------------------------------------------------------------
    //                       Canonical issuance
    // -----------------------------------------------------------------

    /**
     * @notice Issue a new canonical THOT4096.
     * @param  root              The Merkle root (computed off-chain from 64 leaves).
     * @param  ternaryHead       The dedicated THOT8 sub-leaf hash.
     * @param  ternaryHeadIndex  Leaf position of the ternary head.
     * @param  cid               IPFS/Filecoin CID for the encrypted payload.
     * @param  metadataURI       Off-chain metadata pointer.
     */
    function issueTHOT4096(
        bytes32 root,
        bytes32 ternaryHead,
        uint256 ternaryHeadIndex,
        string calldata cid,
        string calldata metadataURI
    ) external onlyAuthorized {
        if (parents[root].exists) revert THOTAlreadyExists(root);

        parents[root] = THOT4096Record({
            root: root,
            ternaryHead: ternaryHead,
            ternaryHeadIndex: ternaryHeadIndex,
            issuer: msg.sender,
            timestamp: uint64(block.timestamp),
            cid: cid,
            metadataURI: metadataURI,
            exists: true
        });

        emit THOT4096Issued(root, msg.sender, ternaryHead, cid);
    }

    // -----------------------------------------------------------------
    //                Matryoshka prefix registration
    // -----------------------------------------------------------------

    /**
     * @notice Register a prefix variant of an existing THOT4096.
     * @dev    Verifies that prefixRoot is the canonical Matryoshka prefix
     *         of parentRoot at the asserted dimension. Reverts otherwise.
     */
    function registerPrefix(
        bytes32 parentRoot,
        uint16 prefixDim,
        bytes32 prefixRoot,
        bytes32[] calldata prefixLeaves,
        bytes32[] calldata coWitnessLeaves,
        bytes32[] calldata rightSiblings
    ) external {
        if (!parents[parentRoot].exists) revert THOTNotFound(parentRoot);
        if (prefixDim != 768 && prefixDim != 1024 && prefixDim != 2048) {
            // THOT8 is registered via the parent's ternaryHead field, not here.
            revert InvalidPrefixDimension(prefixDim);
        }

        bytes32 key = keccak256(abi.encodePacked(parentRoot, prefixDim));
        if (prefixes[key].exists) revert PrefixAlreadyRegistered(parentRoot, prefixDim);

        // Copy calldata arrays to memory for the library call.
        bytes32[] memory leaves = new bytes32[](prefixLeaves.length);
        for (uint256 i = 0; i < prefixLeaves.length; i++) leaves[i] = prefixLeaves[i];

        bytes32[] memory coWit = new bytes32[](coWitnessLeaves.length);
        for (uint256 i = 0; i < coWitnessLeaves.length; i++) coWit[i] = coWitnessLeaves[i];

        bytes32[] memory siblings = new bytes32[](rightSiblings.length);
        for (uint256 i = 0; i < rightSiblings.length; i++) siblings[i] = rightSiblings[i];

        bool ok = THOTLib.verifyPrefix(parentRoot, prefixDim, prefixRoot, leaves, coWit, siblings);
        if (!ok) revert PrefixVerificationFailed();

        prefixes[key] = PrefixRecord({
            parentRoot: parentRoot,
            prefixRoot: prefixRoot,
            prefixDim:  prefixDim,
            timestamp:  uint64(block.timestamp),
            exists:     true
        });

        emit PrefixRegistered(parentRoot, prefixDim, prefixRoot);
    }

    /// @notice Lookup a registered prefix root.
    function getPrefix(bytes32 parentRoot, uint16 prefixDim) external view returns (PrefixRecord memory) {
        return prefixes[keccak256(abi.encodePacked(parentRoot, prefixDim))];
    }

    // -----------------------------------------------------------------
    //                    Diagonal edge recording
    // -----------------------------------------------------------------

    /**
     * @notice Record a diagonal edge (distillation / projection / federation).
     */
    function recordEdge(
        bytes32 fromRoot,
        bytes32 toRoot,
        EdgeKind kind,
        bytes32 attestationHash
    ) external returns (bytes32 edgeId) {
        if (!parents[fromRoot].exists) revert THOTNotFound(fromRoot);
        if (!parents[toRoot].exists)   revert THOTNotFound(toRoot);

        edgeId = keccak256(abi.encodePacked(fromRoot, toRoot, kind, msg.sender));
        edges[edgeId] = DiagonalEdge({
            fromRoot: fromRoot,
            toRoot:   toRoot,
            kind:     kind,
            attestationHash: attestationHash,
            recorder: msg.sender,
            timestamp: uint64(block.timestamp)
        });

        emit DiagonalEdgeRecorded(fromRoot, toRoot, kind, attestationHash, msg.sender);
    }
}
