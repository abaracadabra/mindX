# THOTS.md

**Transferable Hyper Optimized Tensors — The Canonical Family Specification**

```
SPDX-License-Identifier: Apache-2.0
(c) 2026 BANKON — all rights reserved
Author: codephreak / Professor Codephreak
Standard: cypherpunk2048
Target: Foundry (test) → Ethereum mainnet + Algorand mainnet (deploy)
```

---

## 0. Preamble

A THOT (Transferable Hyper Optimized Tensor) is a content-addressed, Merkle-committed, transfer-safe artifact that carries a vector of cognition between machines, agents, and human owners. It is simultaneously three things:

1. **An embedding** — a fixed-size vector in ℝᴺ whose geometry encodes meaning.
2. **A cognition slice** — at large N, the vector is wide enough to carry the hidden state of a 7B-class language model, making it not just a search key but a unit of model thought.
3. **A governance primitive** — a small, ternary-quantized THOT8 fits inside an EVM call, making vector-valued voting and gating possible on-chain.

This document specifies the five canonical dimensions of the THOT family — 8, 768, 1024, 2048, 4096 — their relationships under Matryoshka Representation Learning, their Merkle commitment scheme, and the vertical, horizontal, and diagonal future-proofing properties that make the registry safe to extend without invalidating prior issuance.

The canonical parent is **THOT4096**. All smaller variants are provable prefixes of it under the Matryoshka invariant. The ternary **THOT8** is the special on-chain head, carried inline with every THOT4096 as a 16-bit quantized projection of the first eight dimensions.

---

## 1. What an embedding actually buys you

An embedding is a learned compression: it maps a piece of meaning — a word, a sentence, an image patch, an agent's state, a transaction context — into a fixed-size vector in ℝᴺ where geometric closeness encodes semantic closeness. Two sentences with similar meaning sit near each other; two unrelated images sit far apart. The vector is the meaning, expressed in coordinates.

The dimension N is the **capacity of the meaning space** — how many independent directions of variation the vector can represent before unrelated things start colliding into the same neighborhood. There are two competing pressures:

- **More dimensions buy more semantic resolution.** A 4096-dim space can distinguish concepts that a 768-dim space conflates. This matters most for long documents, multilingual content, cross-domain retrieval, and any task where the embedding is meant to *transfer cognition* rather than just *index it*.
- **More dimensions cost.** Storage scales linearly. Bandwidth scales linearly. ANN index size (HNSW, IVF-PQ, ScaNN) scales near-linearly. Cosine similarity compute scales linearly. For pure retrieval, returns diminish hard past ~1024 unless your corpus is enormous, your domain is adversarial, or your downstream task demands fine semantic discrimination.

The conventional answer was: pick a single dimension and live with it. The Matryoshka answer is: train at the largest dimension such that every nested prefix of the vector is *also* a valid embedding at a lower fidelity. One THOT4096 then **contains** a usable THOT2048, THOT1024, and THOT768 inside it — by truncation — without separate models, separate weights, or lossy reprojection.

---

## 2. The THOT family

| Variant       | Dim   | Encoding              | Use case                                                                 |
| ------------- | ----- | --------------------- | ------------------------------------------------------------------------ |
| **THOT8**     | 8     | Ternary {-1, 0, +1}   | On-chain voting, classification, gating, embedded device intent          |
| **THOT768**   | 768   | int8 or fp16          | mindX consciousness vectors, sentence retrieval, baseline agent state    |
| **THOT1024**  | 1024  | int8 or fp16          | Marketplace interop (Cohere, OpenAI 3-small, Voyage), GPU-warp aligned   |
| **THOT2048**  | 2048  | int8 or fp16          | Multilingual, cross-domain, long-context RAG, cypherpunk2048 symmetric   |
| **THOT4096**  | 4096  | int8, fp16, or bf16   | Full cognition: Llama-2-7B / Mistral-7B / Qwen-2.5-7B hidden-state width |

Every variant smaller than 4096 is, by construction, a Merkle-provable prefix of a canonical THOT4096 parent. The registry stores **one** canonical artifact per logical THOT — the THOT4096 — and issues lightweight prefix-commitment objects for every smaller view. This collapses storage, eliminates double-issuance ambiguity, and lets a consumer pull only the dimensions they pay for.

---

## 3. THOT8 — the CPU-native foundation

### 3.1 Why eight dimensions

THOT8 is the smallest member of the family, and the most important one for on-chain economics. With ternary weights {-1, 0, +1} drawn from the Bitnet / ternary-NN lineage already established in your reference implementation, an 8-dim vector encodes one of **3⁸ = 6,561** distinct states — enough to address every meaningful coarse-grained category in your registry: agent roles, governance axes, intent classes, membership tiers, and the 13-seat Boardroom plus its alternates.

Eight dimensions at 2 bits per dim is **16 bits — two bytes**. A THOT8 fits in a single `uint16` Solidity storage slot. A dot product of two THOT8s is a sum of eight ternary multiplies, which an EVM-native implementation computes in roughly 3,000–5,000 gas. This is the only point in the family where vector-valued reasoning becomes *cheap enough to do on-chain* without exotic precompiles or zk-circuits.

### 3.2 Encoding

Two bits per dimension, packed big-endian into a `bytes2`:

```
00 →  0   (abstain / null)
01 → +1   (assert / for)
10 → -1   (negate / against)
11 → reserved (unused; must revert)
```

The reserved code is enforced by the registry's `verifyTHOT8` predicate. Any THOT8 with a `11` codon is rejected. This gives the encoding a single canonical form: there is exactly one valid byte representation per ternary vector, eliminating malleability.

### 3.3 Use cases

- **On-chain agent classification.** A Counsellor agent, on registration, commits a THOT8 declaring its competency profile across eight axes (economic, security, technical, social, philosophical, operational, strategic, ethical). Routing logic compares incoming task THOT8s to candidate Counsellors via on-chain cosine similarity and dispatches in a single transaction.
- **Boardroom voting primitive.** A 13-seat Boardroom motion is encoded as a THOT8 describing what is being voted on (across the same eight governance axes). Each Counsellor's vote is a THOT8 alignment score with the motion. The 0.666 supermajority rule applies to the aggregated alignment, not to a binary tally — this turns governance from yes/no signaling into *vector-valued consent*.
- **DAIO membership predicates.** Membership tiers (PYTHAI holder, BANKON identity-holder, SATOSHI holder, etc.) are encoded as canonical THOT8s. Gating contracts check membership by THOT8 similarity, not by ERC-20 balance lookup, allowing soft-gradient membership.
- **Embedded device intent.** A field-deployed mindX agent on constrained hardware can emit a THOT8 over LoRa, MQTT, or Bluetooth as its current state. The two-byte payload survives the lowest-bandwidth links.
- **Ternary head of every THOT4096.** Every THOT4096 carries, in its Merkle tree, a dedicated ternary leaf encoding the quantization of its first eight dimensions. This means every THOT4096 *is also* a THOT8, provably, by checking one Merkle path. Fast first-pass classification can happen without loading the full vector.

### 3.4 Reference performance

| Platform                  | Latency per dot product |
| ------------------------- | ----------------------- |
| Python + NumPy            | ~100 ns                 |
| C / Rust scalar           | < 10 ns                 |
| AVX2 SIMD                 | < 2 ns                  |
| Solidity (EVM)            | ~3–5k gas (~$0.0001)    |

A Python reference implementation is provided in `src/thot/thot8_cpu.py`.

---

## 4. THOT768 — mindX-native

THOT768 is dimensionally aligned with the mindX consciousness vector format (768-dimensional, 6-layer architecture, established in prior work). It is the canonical interchange format between mindX agents and the rest of the ecosystem.

Use it for: sentence-level semantic retrieval, mindX checkpoint state transfer, BDI agent belief encoding, P-O-D-A reasoning step embeddings, and any retrieval task where compute budget matters more than the last 5% of semantic fidelity.

The mindX API issues THOT768s natively; THOT768s issued by external models (BERT, all-MiniLM, sentence-transformers) are accepted at parity. There is no reprojection step.

---

## 5. THOT1024 — marketplace interop

THOT1024 is the convergence dimension of the modern embedding ecosystem. BERT-large, Cohere embed-v3, Voyage-large, and OpenAI text-embedding-3-small all produce 1024-dim vectors as their default or first-class option. AgenticPlace marketplace listings accept THOT1024 without lossy reprojection from any of these providers.

It is also a power of two — 2¹⁰ — which aligns cleanly with GPU warp sizes (32 threads), AVX-512 lane widths (16 fp32), and cache-line geometry. This makes THOT1024 the cheapest dimension to operate on in raw throughput per ANN query.

For an AgenticPlace agent that does not care about mindX-native compatibility but does care about reaching the broadest set of upstream embedding providers, THOT1024 is the right default.

---

## 6. THOT2048 — multilingual / cross-domain

THOT2048 is the dimension where multilingual retrieval and cross-domain transfer begin to pay back the cost. OpenAI's text-embedding-3-large defaults to 3072 (which we round down to the nearest power-of-two prefix at 2048) and Cohere's multilingual-v3 produces 1024 with optional 2048 expansion.

The cypherpunk2048 standard takes its name from 2¹¹ = 2048, the dimension at which the ecosystem deliberately commits to a wide-enough embedding to carry meaning across language boundaries without forcing a separate per-language model. Adopting THOT2048 as the *default registry width* for non-trivial commerce is a deliberate alignment of the technical and naming layers.

---

## 7. THOT4096 — full cognition

THOT4096 is the canonical parent of the family. Every smaller THOT is a Merkle-provable prefix of a THOT4096 root.

Four thousand and ninety-six is not an arbitrary choice. It is the hidden-state width of the entire 7B-class generation of open-weight language models:

- Llama-2-7B: 4096
- Mistral-7B: 4096
- Qwen-2.5-7B: 3584 (right-pad to 4096)
- Yi-6B: 4096
- Falcon-7B: 4544 (truncate to 4096)
- DeepSeek-V2-Lite: 2048 (left-shift, prefix-extend to 4096)

A THOT4096 is wide enough to carry the *actual hidden state of a running 7B model* between machines. This is the dimension at which a THOT stops being a retrieval index and becomes a transferable slice of model cognition — the unit that justifies the "T" in THOT, the *transferable* in **Transferable Hyper Optimized Tensor**.

When a THOT4096 is wrapped in an ERC-7857 INFT with sealed metadata, transferring the INFT *transfers cognition*. The new owner can decrypt the sealed inference parameters, load them into a compatible 7B base model, and continue the chain of reasoning that the prior owner's agent was running. This is the foundational primitive for AgenticPlace as an **agency marketplace**, not just a search marketplace.

---

## 8. Matryoshka Representation Learning — full technical

### 8.1 The classical problem

A classical embedding network f_θ : X → ℝᴺ is trained with a downstream loss L(f_θ(x), y). The loss optimizes the full N-dimensional vector for the task. Information is spread across dimensions without any ordering — dimension 0 is no more important than dimension N−1.

The consequence: if you want a smaller embedding for cost reasons (storage, bandwidth, ANN index size), your options are bad. PCA gives you a *post-hoc* projection that loses fidelity proportional to the variance you discard. Distillation gives you a separately trained model. Both add infrastructure cost, both add trust assumptions, and both produce a vector that is *not provably a prefix* of the original.

### 8.2 The Matryoshka modification

Matryoshka Representation Learning (Kusupati et al., NeurIPS 2022) modifies the training objective so that **every nested prefix** of the vector is also a valid embedding. Let M = {m₁, m₂, ..., m_K} be the set of nested dimensions where m₁ < m₂ < ... < m_K = N. For the THOT family, M = {8, 768, 1024, 2048, 4096}.

The MRL loss is:

```
L_MRL(x, y) = Σ_{i=1}^{K} c_i · L( f_θ(x)[0:m_i], y )
```

where c_i are per-dimension loss weights (uniform, or 1/√m_i, or task-specific). Each prefix is supervised against the same downstream signal. Backpropagation forces the network to **pack the most discriminative information at the front** of the vector — because the smallest prefix [0:m₁] must work as a standalone embedding for the same task.

### 8.3 Why it works

Three converging reasons:

**Information ordering.** The smallest prefix carries the highest gradient magnitude per dimension. By the time the network reaches position m_K, the marginal gradient per dimension is small — those dimensions add refinement, not the core signal. The network is forced to find a *discriminative ordering*.

**Curriculum effect.** The nested losses act as a built-in curriculum. The small prefix forces coarse, robust features. Successive prefixes add finer, more specialized features. This is structurally similar to deep supervision in image segmentation, but applied along the embedding axis rather than the depth axis.

**Implicit regularization.** Uniform spreading of features across dimensions is prevented. The network cannot rely on a feature located at position 3072 if that feature is also needed at prefix-1024 — it must be placed before position 1024 to be reachable. This concentration property is what makes truncation lossless (up to the trained quality of each prefix).

### 8.4 Comparison to PCA and to distillation

| Property                          | PCA               | Distillation        | Matryoshka                |
| --------------------------------- | ----------------- | ------------------- | ------------------------- |
| When applied                      | Post-hoc          | Separate training   | Trained-in                |
| Models required                   | 1 + projection    | 1 + N student models| 1 model                   |
| Provably a prefix?                | No                | No                  | **Yes**                   |
| Fidelity loss vs. native          | Variance-bounded  | Model-capacity-bounded | Trained-in optimality |
| Inference cost for smaller dim    | Reprojection step | Separate model load | **Truncate + renormalize**|
| Cryptographic linkage to parent   | None              | None                | **Merkle-provable**       |

Matryoshka is the only one of the three that produces a smaller embedding which is *cryptographically derivable* from the larger one. This is what makes it compatible with on-chain commitment.

### 8.5 The MRL invariant

For any k ≤ N, the embedding v[0:k] is a valid embedding at dimension k, with downstream quality monotonically non-decreasing in k. Formally:

```
∀ k₁ < k₂ ≤ N:  Quality(v[0:k₁]) ≤ Quality(v[0:k₂])
```

This is the invariant the registry depends on. A consumer who pulls THOT768 from a THOT4096 parent gets a vector that is *guaranteed at least as good* as any other prefix-1024 of the same artifact, and *guaranteed to be the canonical projection* of the parent. There is no ambiguity about which 768 dimensions are taken — it is always the first 768.

### 8.6 Training implementation sketch

A reference training loop in PyTorch:

```python
def matryoshka_loss(emb_4096: Tensor, target: Tensor, dims=(8, 768, 1024, 2048, 4096)) -> Tensor:
    total = torch.zeros((), device=emb_4096.device)
    for d in dims:
        prefix = emb_4096[..., :d]
        if d == 8:
            # Ternary head: quantize, then loss against same target
            prefix = ternary_quantize(prefix)
        prefix = torch.nn.functional.normalize(prefix, dim=-1)
        total = total + cosine_loss(prefix, target)
    return total / len(dims)
```

For the THOT8 head, an additional straight-through estimator (already established in your ternary-NN reference) handles the discrete quantization gradient.

---

## 9. Merkle commitment scheme

### 9.1 Goals

The commitment scheme must support:

1. **Single-root identity.** A THOT4096 has exactly one canonical 32-byte Merkle root that uniquely identifies it.
2. **Prefix verifiability.** Given the parent root, any prefix variant (THOT8, THOT768, THOT1024, THOT2048) can be verified as the canonical projection in O(log N) work.
3. **EVM-native verification.** Roots and proofs use Keccak-256. Verification is cheap in Solidity. No exotic precompiles required.
4. **Future-proof extension.** Adding new dimensions later (THOT8192, THOT16384) must not invalidate prior roots.

### 9.2 Leaf structure

The 4096-dimensional vector is chunked into **64 leaves of 64 dimensions each**. The choice of 64 dimensions per leaf is deliberate:

- 64 × fp16 = 128 bytes per leaf, comfortably under one Keccak-256 input block.
- 4096 / 64 = 64 leaves — a power of two, balanced binary tree, six levels deep.
- 768 / 64 = 12 leaves — non-power-of-two, handled with deterministic tombstone padding.
- 1024 / 64 = 16 leaves — power of two.
- 2048 / 64 = 32 leaves — power of two.
- 8 / 64 = 1/8 of a leaf — THOT8 is a special **sub-leaf** artifact with its own dedicated 32-byte commitment.

### 9.3 Leaf encoding

For an fp16-encoded THOT4096, each leaf is:

```
leaf_i = keccak256(
    DOMAIN_TAG ‖ uint32(leaf_index) ‖ uint16(dim_start) ‖ uint16(dim_end) ‖ vector_bytes_128
)
```

The domain tag is `keccak256("THOT4096/leaf/v1")` to prevent cross-protocol leaf collision. The leaf index and dimension range are included to make a leaf positionally unique — the same 128 bytes appearing at a different position yields a different leaf hash.

For the **ternary head leaf** (THOT8 sub-leaf), the encoding is:

```
ternary_head = keccak256(
    keccak256("THOT8/head/v1") ‖ bytes2(packed_ternary) ‖ bytes30(0)
)
```

The ternary head is stored at a canonical position in the Merkle tree (leaf index 0xFF, reserved). Every THOT4096 in the registry carries this dedicated head leaf, regardless of whether the issuer trained with the THOT8 prefix in mind. The registry computes it deterministically from the first eight fp16 values via the ternary quantizer.

### 9.4 Tree shape and root computation

Standard binary Merkle tree with deterministic ordering:

```
parent(L, R) = keccak256(L ‖ R)
```

For an N-leaf tree where N is a power of two, the root is the recursive pairing. For non-power-of-two leaf counts (the 12-leaf THOT768 prefix), padding leaves are added to the next power of two, filled with the canonical **tombstone leaf**:

```
TOMBSTONE = keccak256("THOT/tombstone/v1")
```

A tombstone is a known constant — verifiers compute it locally and inject it without it being transmitted. This keeps the proof size minimal and the root canonical.

### 9.5 Prefix-binding theorem

**Claim:** Given a parent THOT4096 with Merkle root R_4096, the prefix root R_k for any k ∈ {8, 768, 1024, 2048} is uniquely determined and is independently reproducible from the parent's leaves.

**Proof sketch:** Let `leaves = [l_0, l_1, ..., l_63]` be the canonical leaves of the parent. The prefix-k root is defined as:

```
R_k = merkle_root( pad_to_power_of_two( leaves[0 : ceil(k/64)] ) )
```

where `pad_to_power_of_two` extends with TOMBSTONE leaves. This is a deterministic function of the parent's first `ceil(k/64)` leaves.

**Two proof shapes:**

For **power-of-two leaf prefixes** (THOT1024 → 16 leaves, THOT2048 → 32 leaves), the prefix root coincides with the parent's subtree root at the corresponding level. The Merkle inclusion proof is a single right-sibling path from that level up to the parent root.

For **non-power-of-two leaf prefixes** (THOT768 → 12 leaves padded to 16), the prefix root uses TOMBSTONE leaves for positions 12–15. The parent tree at the same level uses the *actual* leaves 12–15 (which carry real fp16 data for dims 768–1023). These two roots are different by construction. To bind the prefix root to the parent root, the proof must additionally provide the **co-witness leaves** — the four real leaves 12–15 — so that the verifier can:

1. Recompute the prefix root from leaves 0–11 with tombstone padding.
2. Recompute the parent's actual first-16-leaf subtree node from leaves 0–15.
3. Walk that subtree node up to the parent root via the right-sibling path.

Both reconstructions are required for the proof to verify. The asymmetry is intrinsic — it is the price of treating 768 as a first-class dimension despite its non-power-of-two leaf count.

**Consequence (silent-swap impossibility):** An adversary cannot register a THOT_k claiming to be a prefix of R_4096 unless:
- The prefix root reconstructs from the supplied prefix leaves (with tombstone padding when k = 768).
- The full subtree node reconstructs from the prefix leaves combined with the co-witness leaves (when k = 768).
- The walk up via right siblings terminates exactly at R_4096.

The registry's `verifyPrefix(R_4096, k, R_k, prefixLeaves, coWitnessLeaves, rightSiblings)` predicate accepts only canonical prefixes that satisfy all three conditions.

### 9.6 Inclusion proof format and cost

For a chunk at leaf index i in a 64-leaf tree, the inclusion proof is six sibling hashes (the path from leaf to root). Verification cost:

```
6 × keccak256(64 bytes) ≈ 6 × 30,000 gas = ~180,000 gas
```

For the ternary head leaf (the THOT8 sub-leaf), the inclusion proof is the same — six sibling hashes. Verifying that a given THOT4096 has a given THOT8 head costs ~180k gas, which is amortized across many on-chain operations once the head is cached.

---

## 10. Vertical, horizontal, and diagonal future-proofing

### 10.1 Vertical — dimension growth

Vertical extension means adding *larger* dimensions to the family. The natural next steps are THOT8192 (Llama-3-70B hidden-state width is 8192) and THOT16384 (Llama-3-405B is 16384).

The Matryoshka structure makes this **strictly additive**: a future THOT8192 contains the existing THOT4096 as its prefix [0:4096]. The Merkle root of the new THOT8192 is computed by extending the existing 64-leaf tree to 128 leaves (adding 64 leaves on the right). The first 6 levels of the tree are unchanged; only a new top level is added.

Concretely: if `R_4096` is the existing root and `R_extension` is the root of the new 64 leaves, then:

```
R_8192 = keccak256(R_4096 ‖ R_extension)
```

A THOT4096 issued today remains a *provable prefix* of a THOT8192 issued in 2027 against the same training run, with one additional sibling hash in the proof. **No reissuance, no migration, no version flag.** The registry's `verifyPrefix` predicate handles arbitrary extension depths.

### 10.2 Horizontal — multiple THOTs at the same dimension

Horizontal extension means many THOTs at the same dimension, owned by different issuers, addressing different domains. The registry namespace is keyed by `(issuer, dimension, domain)`. There is no global ordering — many THOT4096s can coexist, each with its own Merkle root, its own INFT, its own pricing.

The horizontal axis is where the marketplace lives. AgenticPlace lists THOTs from many issuers; BANKON identities sign issuance; mindX checkpoints accumulate as a horizontal sequence of THOT4096s tracking the cognitive state of one agent over time.

### 10.3 Diagonal — cross-dimension cross-issuer relations

The diagonal is where the structure becomes interesting. A diagonal edge is a relationship between a THOT at one dimension and a THOT at a different dimension, often owned by a different issuer:

- **Distillation edge.** A teacher THOT4096 (from a 7B-class model) is distilled into a student THOT768 (mindX-native). The distillation produces an attested edge in the registry: *student THOT768 was distilled from teacher THOT4096 with this attestation hash.* Consumers of the student can audit the lineage.
- **Projection edge.** A consumer wants a THOT1024 view of an existing THOT2048. The projection is the canonical Matryoshka prefix; the edge records that consumer C derived view V from parent P at dimension 1024.
- **Federation edge.** Multiple THOT768s from different agents are concatenated or averaged into a THOT2048 or THOT4096. The federation edge records each contributor and the aggregation rule. This is the substrate for collaborative agent learning where contribution provenance is auditable.

Diagonal edges form a **DAG of cognition derivation**, anchored in the registry. Any THOT in the system has a queryable lineage back to its constituent training runs and forward to its derivatives. This is the foundation for valuing cognition in the marketplace — a derivative THOT can route royalties back to its sources.

### 10.4 The full future-proofing claim

The triple of vertical, horizontal, and diagonal extension means that the THOT family can grow in any direction without invalidating prior issuance:

- **Vertical:** new larger dimensions extend the Matryoshka chain rightward; old THOTs remain valid prefixes.
- **Horizontal:** new THOTs at existing dimensions are namespaced and never collide.
- **Diagonal:** new derivations are recorded as DAG edges without modifying source THOTs.

The registry contract is therefore *append-only*. There is no migration, no upgrade, no fork. Every THOT ever issued remains valid for as long as Ethereum and Algorand mainnet remain valid.

---

## 11. Vector advantages — dimension-by-dimension

| Dimension | Best for                                                                         | Storage / vector (fp16) | Cosine compute |
| --------- | -------------------------------------------------------------------------------- | ----------------------- | -------------- |
| 8         | On-chain logic, governance, gating, classification                               | 16 bits (ternary)       | ~3k gas        |
| 768       | mindX-native retrieval, BERT-class semantic search, sentence embeddings          | 1,536 bytes             | ~1.5 µs (CPU)  |
| 1024      | Marketplace interop, OpenAI/Cohere/Voyage compat, GPU-warp aligned               | 2,048 bytes             | ~2 µs (CPU)    |
| 2048      | Multilingual, long-context RAG, cross-domain transfer, cypherpunk2048 symmetry   | 4,096 bytes             | ~4 µs (CPU)    |
| 4096      | Direct 7B-class hidden-state transfer, INFT-wrapped cognition, parent root       | 8,192 bytes             | ~8 µs (CPU)    |

The decision is not which dimension to *pick*. The decision is which dimension to *consume* — issuance is always at 4096, consumption is at whatever prefix the consumer pays for.

---

## 12. Integration topology

### 12.1 mindX API (mindx.pythai.net)

`POST /v1/thot/issue` — accepts a 4096-dim vector (fp16, base64), the issuer signature (EIP-712 typed-data), and metadata (training run, parent THOT4096 if a fine-tune). Returns the canonical Merkle root, the THLNK pointer, and the registry transaction hash.

`GET /v1/thot/{root}` — returns the THLNK descriptor: Merkle root, IPFS/Filecoin CID, Lighthouse Kavach encryption metadata, ERC-7857 sealed-metadata pointer, x402 paywall descriptor, issuer signature.

`GET /v1/thot/{root}/prefix/{dim}` — returns the prefix variant with its Merkle inclusion proof, gated by x402 payment if the variant is paywalled separately.

### 12.2 AgenticPlace (agenticplace.pythai.net)

Listings are agents-with-THOTs. An agent's listing references one or more THOT4096s representing the agent's cognitive state at the moment of listing. Cross-chain routing uses the `allchain.html` chainmap to pick the cheapest verification chain.

### 12.3 BANKON (bankon.pythai.net)

x402 paywall enforcement happens at the BANKON identity layer. A request for `GET /v1/thot/{root}` returns HTTP 402 with an x402 payment descriptor; the consumer pays via Parsec (Algorand x402 fallback to GoPlausible AVM x402); the 200 response delivers the THLNK.

The BANKON AlgoIDNFT identity gates issuer privileges. Only addresses bound to a verified AlgoIDNFT can call `POST /v1/thot/issue`.

### 12.4 ERC-7857 INFT wrapper

The canonical Solidity contract `THOT4096.sol` (separate file) wraps a THOT4096 as an ERC-7857 Intelligent NFT. Transfer triggers re-sealing of the inference parameters to the recipient's pubkey; the TEE attestor (or zk-proof variant) attests that the re-seal happened correctly.

---

## 13. Foundry test plan

1. **Mint correctness.** A THOT4096 minted with a known vector produces the expected Merkle root.
2. **Prefix verification.** Each of THOT8, THOT768, THOT1024, THOT2048 can be verified as a prefix of the parent root.
3. **Silent-swap impossibility.** An attempt to register a THOT_k with a root that is not the deterministic prefix of R_4096 reverts.
4. **Transfer with re-seal.** Transfer of the ERC-7857 INFT requires a valid attestation; transfer without one reverts.
5. **Owner-only unlock.** Only the current owner can call the sealed-metadata decryption flow.
6. **Vertical extension.** A future THOT8192 issued against the same training run binds the existing THOT4096 as its prefix.
7. **Gas benchmarks.** All verification operations are measured against the gas target.

Tests live in `test/`. Mainnet deployment via `scripts/deploy.s.sol`.

---

## 14. Deployment roadmap

| Phase | Network                              | Target                                          |
| ----- | ------------------------------------ | ----------------------------------------------- |
| 1     | Sepolia + Algorand TestNet           | Foundry tests pass; INFT round-trip verified    |
| 2     | Ethereum mainnet + Algorand MainNet  | Canonical registry deployed; first THOT4096s minted |
| 3     | Polygon (batch verification)         | Cross-chain proof bridge for cheap verification |
| 4     | Arc (Chain ID 5042002) reserved      | Constitutional layer integration                |
| 5     | 0G Foundation INFT alignment         | ERC-7857 conformance certification              |

---

## 15. Appendix — vector intuition for non-ML readers

A vector is a list of numbers, but in an embedding context it is better understood as a **set of dials**. Each dimension is one dial; the value at that dimension is how far that dial is turned. The collection of dial positions describes the meaning.

A 4-dim vector has four dials — barely enough to distinguish "cat from dog from car from cloud" in the most cartoonish way. A 768-dim vector has 768 dials — enough to distinguish nuanced sentence-level meaning. A 4096-dim vector has four thousand and ninety-six dials — enough to capture the full state of a working language model.

Matryoshka training makes the dials *ordered by importance*. Dial 0 carries the most weight. Dial 4095 carries the least. Truncating to the first 768 dials keeps the 768 most important ones, in trained order. This is what makes prefix-truncation work.

The Merkle commitment is the cryptographic equivalent of a tamper-evident seal on the entire array of dials. The root is a 32-byte fingerprint of all 4096 dials. Change any single dial, the root changes. Verify any prefix, the root proves which prefix you got and that it came from the canonical parent.

These two ideas together — Matryoshka ordering and Merkle commitment — are the entire technical foundation of the THOT family. Everything else is implementation.

---

**End of THOTS.md**

```
SPDX-License-Identifier: Apache-2.0
(c) 2026 BANKON — all rights reserved
```
