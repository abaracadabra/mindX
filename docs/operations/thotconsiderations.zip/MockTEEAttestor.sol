// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

/**
 * @title MockTEEAttestor
 * @notice Minimal attestor for tests. Signs the re-seal digest with a
 *         test private key. Replaced in production by a TEE-bound
 *         signer or a zk-attestation contract.
 *
 *         Standard: cypherpunk2048
 */
contract MockTEEAttestor {
    address public immutable signer;

    constructor(address signer_) {
        signer = signer_;
    }

    /// @notice Verify a given digest was signed by `signer`.
    function verify(bytes32 digest, uint8 v, bytes32 r, bytes32 s) external view returns (bool) {
        return ecrecover(digest, v, r, s) == signer;
    }
}
