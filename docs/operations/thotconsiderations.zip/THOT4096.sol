// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {IERC7857} from "./interfaces/IERC7857.sol";
import {THOTRegistry} from "./THOTRegistry.sol";

/**
 * @title THOT4096
 * @notice ERC-7857 INFT wrapper around a registered THOT4096.
 *
 *         Each token id binds to a parent Merkle root recorded in the
 *         THOTRegistry. The publicCommitment is that root; the sealed
 *         metadata carries the wrapped decryption key.
 *
 *         Transfer requires a valid re-seal attestation from the
 *         configured attestor. On a successful transfer, the sealed
 *         metadata pointer is replaced with the re-sealed payload.
 *
 *         Standard: cypherpunk2048
 *         Target:   Ethereum mainnet
 */
contract THOT4096 is IERC7857 {
    struct Token {
        bytes32 parentRoot;
        address owner;
        string  cid;
        bytes   sealed_;
        bool    exists;
    }

    THOTRegistry public immutable registry;
    address      public attestor;
    address      public bankonIdentityGate;

    uint256 public nextTokenId;
    mapping(uint256 => Token) public tokens;

    event AttestorUpdated(address indexed newAttestor);

    error NotIdentityGate();
    error TokenNotFound(uint256 tokenId);
    error NotOwner(address sender, uint256 tokenId);
    error InvalidAttestation();
    error ParentNotRegistered(bytes32 root);

    constructor(address registry_, address attestor_, address identityGate_) {
        registry = THOTRegistry(registry_);
        attestor = attestor_;
        bankonIdentityGate = identityGate_;
    }

    modifier onlyGate() {
        if (msg.sender != bankonIdentityGate) revert NotIdentityGate();
        _;
    }

    function setAttestor(address newAttestor) external onlyGate {
        attestor = newAttestor;
        emit AttestorUpdated(newAttestor);
    }

    // -----------------------------------------------------------------
    //                              Mint
    // -----------------------------------------------------------------

    /// @notice Mint an INFT bound to an existing registered THOT4096.
    function mint(address to, bytes32 parentRoot, string calldata cid, bytes calldata sealed_)
        external
        returns (uint256 tokenId)
    {
        (
            bytes32 root,
            ,
            ,
            address issuer,
            ,
            ,
            ,
            bool exists
        ) = registry.parents(parentRoot);
        // Touch unused unpacked fields to silence the compiler:
        root; issuer;
        if (!exists) revert ParentNotRegistered(parentRoot);

        tokenId = ++nextTokenId;
        tokens[tokenId] = Token({
            parentRoot: parentRoot,
            owner:      to,
            cid:        cid,
            sealed_:    sealed_,
            exists:     true
        });
        emit Mint(tokenId, to, parentRoot);
    }

    // -----------------------------------------------------------------
    //                       IERC7857 views
    // -----------------------------------------------------------------

    function publicCommitment(uint256 tokenId) external view returns (bytes32) {
        Token storage t = tokens[tokenId];
        if (!t.exists) revert TokenNotFound(tokenId);
        return t.parentRoot;
    }

    function payloadCID(uint256 tokenId) external view returns (string memory) {
        Token storage t = tokens[tokenId];
        if (!t.exists) revert TokenNotFound(tokenId);
        return t.cid;
    }

    function sealedMetadata(uint256 tokenId) external view returns (bytes memory) {
        Token storage t = tokens[tokenId];
        if (!t.exists) revert TokenNotFound(tokenId);
        return t.sealed_;
    }

    // -----------------------------------------------------------------
    //                      Transfer with re-seal
    // -----------------------------------------------------------------

    /**
     * @notice Transfer the INFT after a valid attestation.
     * @param  from         Current owner (must match storage).
     * @param  to           New owner.
     * @param  tokenId      Token id.
     * @param  attestation  ABI-encoded (newSealedMetadata, attestorSig) blob.
     *
     *  The attestor is expected to:
     *    1. Verify the prior owner's sealed payload decrypts to a known key.
     *    2. Re-encrypt that key to `to`'s pubkey.
     *    3. Sign the tuple (tokenId, parentRoot, newSealedHash, from, to).
     *
     *  This contract verifies the signature; the actual key handling
     *  happens off-chain inside the TEE / zk circuit.
     */
    function transferWithReseal(
        address from,
        address to,
        uint256 tokenId,
        bytes calldata attestation
    ) external {
        Token storage t = tokens[tokenId];
        if (!t.exists) revert TokenNotFound(tokenId);
        if (t.owner != from) revert NotOwner(from, tokenId);
        if (msg.sender != from && msg.sender != attestor) revert NotOwner(msg.sender, tokenId);

        // Decode attestation
        (bytes memory newSealed, bytes memory sig) = abi.decode(attestation, (bytes, bytes));

        bytes32 digest = keccak256(
            abi.encodePacked(
                "\x19Ethereum Signed Message:\n32",
                keccak256(abi.encode(tokenId, t.parentRoot, keccak256(newSealed), from, to))
            )
        );

        address signer = _recover(digest, sig);
        if (signer != attestor) revert InvalidAttestation();

        // Apply transfer + re-seal
        t.owner   = to;
        t.sealed_ = newSealed;

        emit Attest(tokenId, from, to, digest);
        emit Reseal(tokenId, to, keccak256(newSealed));
    }

    // -----------------------------------------------------------------
    //                          ecrecover utility
    // -----------------------------------------------------------------

    function _recover(bytes32 digest, bytes memory sig) private pure returns (address) {
        if (sig.length != 65) return address(0);
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly {
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
        if (v < 27) v += 27;
        if (v != 27 && v != 28) return address(0);
        return ecrecover(digest, v, r, s);
    }
}
