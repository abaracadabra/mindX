# BONAFIDE :: Genius timelock tests
#
# These are the most important tests in the suite. They prove the 100-day
# auto-rolling timelock with the 90..100 day redemption window behaves exactly
# as specified, and that no path releases liquidity outside the window.
#
# Day arithmetic in seconds:
#   day 0   = lock start
#   day 90  = 7_776_000  -> redemption window opens
#   day 100 = 8_640_000  -> epoch closes, auto-roll on next touch

import typing

import algopy
import pytest
from algopy import arc4

from smart_contracts.common import constants as C
from smart_contracts.genius.contract import Genius

if typing.TYPE_CHECKING:
    from algopy_testing import AlgopyTestContext

DAY = 86_400
POOL_APP = 5001
LP_ASSET = 6001


def _deploy(ctx: "AlgopyTestContext") -> Genius:
    """Deploy Genius, wire a Forum app id, and place it past config freeze."""
    contract = Genius()
    forum_app = ctx.any.application()
    contract.forum_app.value = forum_app.id
    return contract


def _seed_lock(ctx: "AlgopyTestContext", contract: Genius, start_ts: int) -> int:
    """Inject a LockRecord at start_ts and pretend Genius holds the LP units.
    Returns the tessera asset id recorded.
    """
    from smart_contracts.common.types import LockRecord

    tessera = ctx.any.asset()
    depositor = ctx.any.account()
    rec = LockRecord(
        pool_app=arc4.UInt64(POOL_APP),
        lp_asset_id=arc4.UInt64(LP_ASSET),
        locked_amount=arc4.UInt64(1_000_000),
        lock_start_ts=arc4.UInt64(start_ts),
        tessera_asset_id=arc4.UInt64(int(tessera.id)),
        depositor=arc4.Address(depositor),
        redeemed=arc4.Bool(False),  # noqa: FBT003
    )
    contract.lock[algopy.UInt64(POOL_APP)] = rec.copy()
    contract.tessera_pool[tessera.id] = algopy.UInt64(POOL_APP)
    return int(tessera.id)


# --------------------------------------------------------------------------
# State machine
# --------------------------------------------------------------------------


def test_uninitialized_when_no_lock(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    state = contract.state(arc4.UInt64(POOL_APP))
    assert state.native == C.STATE_UNINITIALIZED


def test_locked_epoch_at_day_zero(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    ctx.ledger.patch_global_fields(latest_timestamp=1_000_000)
    _seed_lock(ctx, contract, start_ts=1_000_000)
    state = contract.state(arc4.UInt64(POOL_APP))
    assert state.native == C.STATE_LOCKED_EPOCH


def test_locked_epoch_at_day_89(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    ctx.ledger.patch_global_fields(latest_timestamp=start + 89 * DAY)
    state = contract.state(arc4.UInt64(POOL_APP))
    assert state.native == C.STATE_LOCKED_EPOCH


def test_redemption_window_opens_at_day_90(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    ctx.ledger.patch_global_fields(latest_timestamp=start + 90 * DAY)
    state = contract.state(arc4.UInt64(POOL_APP))
    assert state.native == C.STATE_REDEMPTION_WINDOW


def test_redemption_window_at_day_99(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    ctx.ledger.patch_global_fields(latest_timestamp=start + 99 * DAY)
    state = contract.state(arc4.UInt64(POOL_APP))
    assert state.native == C.STATE_REDEMPTION_WINDOW


def test_auto_rolled_at_day_100(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    ctx.ledger.patch_global_fields(latest_timestamp=start + 100 * DAY)
    state = contract.state(arc4.UInt64(POOL_APP))
    assert state.native == C.STATE_AUTO_ROLLED


# --------------------------------------------------------------------------
# Auto-roll
# --------------------------------------------------------------------------


def test_maybe_roll_resets_epoch_after_100_days(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    # Jump past day 100.
    new_now = start + 101 * DAY
    ctx.ledger.patch_global_fields(latest_timestamp=new_now)
    state = contract.maybe_roll(arc4.UInt64(POOL_APP))
    # After roll, lock_start_ts == now, so we are back in LOCKED_EPOCH.
    assert state.native == C.STATE_LOCKED_EPOCH
    rec = contract.record(arc4.UInt64(POOL_APP))
    assert rec.lock_start_ts.native == new_now


def test_maybe_roll_noop_before_100_days(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    ctx.ledger.patch_global_fields(latest_timestamp=start + 50 * DAY)
    contract.maybe_roll(arc4.UInt64(POOL_APP))
    rec = contract.record(arc4.UInt64(POOL_APP))
    # start unchanged: no roll happened mid-epoch.
    assert rec.lock_start_ts.native == start


# --------------------------------------------------------------------------
# window_opens_in
# --------------------------------------------------------------------------


def test_window_opens_in_counts_down(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    ctx.ledger.patch_global_fields(latest_timestamp=start + 80 * DAY)
    remaining = contract.window_opens_in(arc4.UInt64(POOL_APP))
    assert remaining.native == 10 * DAY


def test_window_opens_in_zero_once_open(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    start = 1_000_000
    _seed_lock(ctx, contract, start_ts=start)
    ctx.ledger.patch_global_fields(latest_timestamp=start + 95 * DAY)
    remaining = contract.window_opens_in(arc4.UInt64(POOL_APP))
    assert remaining.native == 0


# --------------------------------------------------------------------------
# Access control
# --------------------------------------------------------------------------


def test_lock_initial_rejects_non_forum_caller(ctx: "AlgopyTestContext") -> None:
    contract = _deploy(ctx)
    # caller_application_id defaults to 0 (no parent app) != forum_app, so the
    # only-Forum guard must reject.
    with pytest.raises(Exception):  # noqa: B017, PT011
        contract.lock_initial(
            pool_app=arc4.UInt64(POOL_APP),
            lp_asset_id=arc4.UInt64(LP_ASSET),
            locked_amount=arc4.UInt64(1_000),
            depositor=arc4.Address(ctx.any.account()),
        )
