# BONAFIDE :: pytest fixtures
#
# Provides a fresh AlgopyTestContext per test. Tests run against the
# algorand-python-testing AVM emulator: no LocalNet required for unit tests.
# Integration tests (marked @pytest.mark.integration) target a running
# `algokit localnet`.

import pytest
from algopy_testing import AlgopyTestContext, algopy_testing_context


@pytest.fixture()
def ctx() -> "AlgopyTestContext":
    with algopy_testing_context() as context:
        yield context


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers", "integration: end-to-end tests requiring algokit localnet"
    )
