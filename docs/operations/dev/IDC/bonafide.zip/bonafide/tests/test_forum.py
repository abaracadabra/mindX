# BONAFIDE :: Forum AMM tests
#
# Verifies constant-product swap math, the 0.30% fee with 1/6 protocol share,
# the bootstrap pool record, and the deterministic pool id. The end-to-end
# atomic-group invariant (add_initial_liquidity requires a grouped Genius lock)
# is exercised in the LocalNet integration suite, not here.

import typing

import algopy
import pytest
from algopy import arc4

from smart_contracts.common import constants as C
from smart_contracts.forum.contract import Forum

if typing.TYPE_CHECKING:
    from algopy_testing import AlgopyTestContext


def test_fee_constants() -> None:
    assert C.TOTAL_FEE_BPS == 30  # 0.30%
    assert C.PROTOCOL_FEE_NUMERATOR == 1
    assert C.PROTOCOL_FEE_DENOMINATOR == 6
    assert C.BPS_DENOMINATOR == 10_000


def test_amount_out_constant_product(ctx: "AlgopyTestContext") -> None:
    contract = Forum()
    # 1000 in, reserves 1_000_000 / 1_000_000.
    out, prot = contract._amount_out(
        algopy.UInt64(1_000),
        algopy.UInt64(1_000_000),
        algopy.UInt64(1_000_000),
    )
    # total fee = 1000 * 30 / 10000 = 3 ; protocol = 3 // 6 = 0
    # in_after_fee = 997 ; out = 1_000_000*997 / (1_000_000+997) = 996 (floor)
    assert int(out) == 996
    assert int(prot) == 0


def test_amount_out_larger_trade_has_protocol_fee(ctx: "AlgopyTestContext") -> None:
    contract = Forum()
    out, prot = contract._amount_out(
        algopy.UInt64(1_000_000),
        algopy.UInt64(10_000_000),
        algopy.UInt64(10_000_000),
    )
    # total fee = 1_000_000 * 30 / 10000 = 3000 ; protocol = 3000 // 6 = 500
    assert int(prot) == 500
    assert int(out) > 0
    # Output must be less than naive (no-fee) and respect x*y=k direction.
    assert int(out) < 1_000_000


def test_isqrt(ctx: "AlgopyTestContext") -> None:
    contract = Forum()
    assert int(contract._isqrt(algopy.UInt64(0))) == 0
    assert int(contract._isqrt(algopy.UInt64(1))) == 1
    assert int(contract._isqrt(algopy.UInt64(4))) == 2
    assert int(contract._isqrt(algopy.UInt64(1_000_000))) == 1_000
    assert int(contract._isqrt(algopy.UInt64(999_999))) == 999  # floor


def test_pool_id_deterministic(ctx: "AlgopyTestContext") -> None:
    contract = Forum()
    a = contract._pool_id(algopy.UInt64(10), algopy.UInt64(20))
    b = contract._pool_id(algopy.UInt64(10), algopy.UInt64(20))
    c = contract._pool_id(algopy.UInt64(10), algopy.UInt64(21))
    assert a == b
    assert a != c


def test_redeem_cap_is_five_percent() -> None:
    assert C.REDEEM_CAP_NUMERATOR == 5
    assert C.REDEEM_CAP_DENOMINATOR == 100
