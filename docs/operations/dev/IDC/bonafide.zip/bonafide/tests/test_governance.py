# BONAFIDE :: governance constant + classification tests
#
# Verifies seat classification, ballot encodings, proposal lifecycle constants,
# and the Censura 3-of-7 veto threshold. Full cross-contract voting (Curia ->
# Sponsio Pactum -> Censura with real seat-NFT ownership checks) runs in the
# LocalNet integration suite where inter-app calls resolve against deployed
# app ids.

import typing

from algopy import arc4

from smart_contracts.common import constants as C
from smart_contracts.senatus.contract import Senatus

if typing.TYPE_CHECKING:
    from algopy_testing import AlgopyTestContext


def test_seat_class_convener(ctx: "AlgopyTestContext") -> None:
    contract = Senatus()
    assert contract.seat_class(arc4.UInt64(0)).native == 0  # convener


def test_seat_class_counsellors(ctx: "AlgopyTestContext") -> None:
    contract = Senatus()
    for seat in range(1, 8):
        assert contract.seat_class(arc4.UInt64(seat)).native == 1  # counsellor


def test_seat_class_citizens(ctx: "AlgopyTestContext") -> None:
    contract = Senatus()
    for seat in range(8, 13):
        assert contract.seat_class(arc4.UInt64(seat)).native == 2  # citizen


def test_cabinet_partition_sums_to_thirteen() -> None:
    convener = 1
    counsellors = C.COUNSELLOR_LAST - C.COUNSELLOR_FIRST + 1  # 7
    citizens = C.CITIZEN_LAST - C.CITIZEN_FIRST + 1  # 5
    assert convener + counsellors + citizens == C.SEAT_COUNT  # 1 + 7 + 5 == 13


def test_veto_quorum_three_of_seven() -> None:
    assert C.COUNSELLOR_VETO_QUORUM == 3
    counsellors = C.COUNSELLOR_LAST - C.COUNSELLOR_FIRST + 1
    assert counsellors == 7
    assert C.COUNSELLOR_VETO_QUORUM <= counsellors


def test_ballot_encodings_distinct() -> None:
    assert len({C.BALLOT_NO, C.BALLOT_YES, C.BALLOT_ABSTAIN}) == 3


def test_proposal_lifecycle_states_distinct() -> None:
    states = {
        C.PROP_DRAFT,
        C.PROP_ACTIVE,
        C.PROP_PASSED,
        C.PROP_REJECTED,
        C.PROP_VETOED,
        C.PROP_EXECUTED,
    }
    assert len(states) == 6
