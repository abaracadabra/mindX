# BONAFIDE :: Tabularium treasury/13 tests
#
# Verifies the seat valuation math: seat_value == treasury_usd // 13, that it
# floats with treasury value, and that the divisor is fixed.

import typing

import algopy
import pytest
from algopy import arc4

from smart_contracts.common import constants as C
from smart_contracts.tabularium.contract import Tabularium

if typing.TYPE_CHECKING:
    from algopy_testing import AlgopyTestContext


def test_seat_count_is_thirteen() -> None:
    assert C.SEAT_COUNT == 13


def test_seat_value_is_treasury_over_13(ctx: "AlgopyTestContext") -> None:
    contract = Tabularium()
    # Inject a treasury total and confirm the divisor.
    contract.last_treasury_usd.value = algopy.UInt64(13_000_000)
    # Recompute the published seat value the way revalue() would.
    seat = contract.last_treasury_usd.value // algopy.UInt64(C.SEAT_COUNT)
    contract.last_seat_value.value = seat
    assert contract.seat_value_usd().native == 1_000_000


def test_seat_value_floats_with_treasury(ctx: "AlgopyTestContext") -> None:
    contract = Tabularium()
    for treasury, expected in [
        (13, 1),
        (26, 2),
        (100, 7),  # integer floor division
        (13_000_000_000, 1_000_000_000),
    ]:
        contract.last_treasury_usd.value = algopy.UInt64(treasury)
        contract.last_seat_value.value = algopy.UInt64(treasury) // algopy.UInt64(
            C.SEAT_COUNT
        )
        assert contract.seat_value_usd().native == expected


def test_quorum_is_seven_of_thirteen() -> None:
    # More than half of 13 seats: ceil(13/2) == 7.
    assert C.QUORUM == 7
    assert C.QUORUM > C.SEAT_COUNT // 2
