# BONAFIDE

DAIO governance + Forum DEX + Genius liquidity timelock on Algorand.
Part of the PYTHAI / DELTAVERSE ecosystem.

cypherpunk2048 standard: terse docs, modular clearly-named components,
no admin keys post-deploy, no upgradeable proxies, Apache-2.0.

Author: Gregory Magnusson (codephreak / Professor Codephreak).

---

## What this is

Eight Algorand smart contracts written in Algorand Python (Algopy / PuyaPy),
forming the constitutional + economic core of the DAIO:

| Contract        | Role                                                              |
|-----------------|-------------------------------------------------------------------|
| `Genius`        | Liquidity timelock. 100-day auto-rolling epoch, 90..100 day window, Tessera-LP NFT redemption certificate. The anti-rug invariant. |
| `Forum`         | Tinyman-v2-derived constant-product AMM. `add_initial_liquidity` reverts unless grouped with `Genius.lock_initial`. |
| `Senatus`       | The 13 governance seats (ASA NFTs): 1 Convener, 7 Counsellors, 5 Citizens. |
| `Curia`         | Voting. One vote per seat, Tessera proof-of-voting NFT per cast.   |
| `SponsioPactum` | Proposal lifecycle. Passes at >= 7 of 13 YES.                     |
| `Censura`       | Collective veto. 3-of-7 Counsellors, no individual override.      |
| `Tabularium`    | Treasury ledger. Publishes `seat_value = treasury_usd / 13`.      |
| `Fides`         | Pyth oracle adapter feeding USD prices to Tabularium.             |

Naming follows the Latin civic substrate (first canonical publication here).

---

## The Genius timelock (read this first)

From the first liquidity pairing of a Forum pool, a 100-day epoch begins
automatically. There is no user choice and no team override.

```
state machine (per pool):
  0 UNINITIALIZED      no liquidity ever paired
  1 LOCKED_EPOCH       start <= now < start + 90d
  2 REDEMPTION_WINDOW  start + 90d <= now < start + 100d   <- 10-day window
  3 AUTO_ROLLED        now >= start + 100d  -> rolls to a fresh epoch on touch
```

- At genesis pairing, ALL minted LP is clawback-transferred into Genius and a
  non-fungible Tessera-LP ASA (the redemption certificate) is minted to the
  depositor. The depositor never holds transferable LP.
- Redemption is possible ONLY in the 90..100 day window, ONLY by presenting the
  matching Tessera-LP in the same atomic group, ONLY up to a 5%-of-depth cap per
  redemption (defends against redemption-right concentration).
- If no redemption is taken by day 100, the lock auto-rolls into another
  100-day epoch on the next pool touch. There is no "after the lock expires"
  state — "wait for expiry, then rug" is structurally impossible.
- The LP ASA is created with `clawback = Genius` and `manager`/`freeze` zeroed,
  and Genius has no approval-program path to release LP outside the window and
  no admin key. Compromising every PYTHAI signer still cannot pull liquidity.

Note on duration: 100 days clears the common <30-day red-flag line but is below
the 6-month credibility baseline. The auto-roll is what carries the security
argument — communicate it explicitly so the lock is not misread as a 100-day
soft rug.

---

## Build

Requires AlgoKit 3.x and the PuyaPy compiler.

```sh
pip install -e ".[dev]"          # puyapy, algorand-python-testing, sdk, pytest
algokit project run build         # compile all 8 contracts -> artifacts/<name>/
```

Or compile one contract directly:

```sh
puyapy --out-dir artifacts/genius smart_contracts/genius/contract.py
```

All eight contracts compile clean against puyapy 5.8.1.

---

## Test

```sh
pytest -q                         # unit tests (no LocalNet needed)
pytest -q -m integration          # end-to-end (requires `algokit localnet start`)
```

Unit tests run against the `algorand-python-testing` AVM emulator. The Genius
suite (`tests/test_genius_state_machine.py`) is the priority: it proves every
timelock transition and the no-release-outside-window guarantee.

---

## Deploy (mainnet runbook)

Order matters; dependencies first. Every app is created, wired, then sealed
(`freeze()` then `renounce()`) so no deployer key survives.

```sh
export DEPLOYER_MNEMONIC="..."    # never committed; read from env only
python -m smart_contracts.deploy --network localnet          # rehearse
python -m smart_contracts.deploy --network testnet           # stage
python -m smart_contracts.deploy --network mainnet --confirm # genesis
```

Deployment sequence:

1. `Fides` (set Pyth app, register feeds)
2. `Tabularium` (configure: fides, treasury, curia; register treasury assets)
3. `Senatus` (mint 13 seats, `seal_upper_house()`)
4. `Curia` (configure: senatus, sponsio, tabularium)
5. `SponsioPactum` (configure: senatus, curia, censura, tabularium)
6. `Censura` (configure: senatus, sponsio)
7. `Genius` (set forum)
8. `Forum` (configure: genius, treasury)
9. Genesis pairing: `Forum.bootstrap` + `add_initial_liquidity` grouped with
   `Genius.lock_initial` — **this transaction starts the 100-day timelock**
10. `freeze()` then `renounce()` on every app — deployer wiped everywhere

Then register the deployment into the chain map:

```sh
python -m smart_contracts.deploy --network mainnet --confirm --emit-allchain > deployment.json
python -m smart_contracts.allchain_register --allchain allchain.html --deployment deployment.json
```

Post-deploy verification: every app has no manager and returns the zero address
for its deployer slot; `Genius.state(genesis_pool)` returns LOCKED_EPOCH.

---

## Chain mapping (allchain.html)

`allchain.html` is the canonical registry consumed by agenticplace, mindx, and
bankon. `allchain_register.py` merges a deployment into the JSON block embedded
in the page (`<script id="allchain" type="application/json">`). Services fetch
it on boot to discover app ids, ASA ids, and x402 facilitator endpoints.

---

## EVM side (not in this package)

The mirrortoken / bridge layer (xERC20 `XPythai`, `XLockbox`, LayerZero V2 +
Chainlink CCIP + Wormhole NTT adapters, `EVMVoteSink` with the Algorand
state-proof / Falcon verifier) ships as a separate Foundry repository targeting
Ethereum mainnet. Tessera-LP NFTs are deliberately NOT bridgeable: redemption
must touch Genius on Algorand.

---

## Layout

```
smart_contracts/
  common/        constants.py  types.py  interfaces.py
  fides/         contract.py
  tabularium/    contract.py
  senatus/       contract.py
  curia/         contract.py
  sponsio_pactum/contract.py
  censura/       contract.py
  genius/        contract.py
  forum/         contract.py
  deploy.py              mainnet runbook
  allchain_register.py  chain-map registrar
tests/
  test_genius_state_machine.py   the priority suite
  test_tabularium.py
  test_forum.py
  test_governance.py
  conftest.py
```

---

## Security posture

- No admin keys post-deploy. Each app exposes `freeze()` then `renounce()`,
  which zeroes the deployer slot. After renounce, no privileged method passes.
- No upgradeable proxies. Contracts are immutable once deployed.
- LP ASA immutability: `clawback = Genius`, `manager`/`freeze` = zero address.
- Audit before mainnet. The Forum AMM overlaps Tinyman v2 architecturally;
  reviewers can lean on published Tinyman analysis as a baseline, but Genius,
  the atomic-group invariant, and the governance suite are net-new and must be
  audited independently. These contracts compile and pass unit tests; they have
  NOT been through a third-party security audit.
