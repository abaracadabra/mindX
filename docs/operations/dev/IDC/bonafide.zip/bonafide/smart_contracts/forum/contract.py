# BONAFIDE :: Forum
# The DEX. A constant-product AMM derived from Tinyman v2: one stateful
# validator application managing many pools, each pool keyed by its asset pair.
# Pool reserves and bookkeeping live in box storage keyed by pool app id-style
# composite (here, a synthetic pool id derived from the asset pair).
#
# The single breaking change from Tinyman v2: add_initial_liquidity is the ONLY
# path that issues LP tokens, and it MUST be grouped with Genius.lock_initial.
# If the Genius call is absent or malformed, the bootstrap reverts. There is no
# unlocked LP path.
#
# Fee model follows Tinyman v2: 0.30% total swap fee on input; 1/6 of the fee
# (0.05% of input) is set aside as protocol fee accumulated in the underlying
# reserve assets, claimable to the treasury by any caller.

from algopy import (
    Account,
    Application,
    ARC4Contract,
    Asset,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    BoxMap,
    subroutine,
    op,
)

from ..common import constants as C
from ..common.interfaces import IGenius
from ..common.types import PoolInfo


class Forum(ARC4Contract):
    def __init__(self) -> None:
        self.genius_app = GlobalState(UInt64(0))
        self.treasury = GlobalState(arc4.Address(Global.zero_address))
        self.frozen = GlobalState(UInt64(0))
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        # pool id -> PoolInfo
        self.pools = BoxMap(UInt64, PoolInfo, key_prefix=b"pool_")
        self.pool_count = GlobalState(UInt64(0))

    # -- configuration ------------------------------------------------------

    @arc4.abimethod
    def configure(self, genius_app: arc4.UInt64, treasury: arc4.Address) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.genius_app.value = genius_app.native
        self.treasury.value = treasury

    @arc4.abimethod
    def freeze(self) -> None:
        self._only_deployer()
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- pool lifecycle -----------------------------------------------------

    @arc4.abimethod
    def bootstrap(self, asset_1_id: arc4.UInt64, asset_2_id: arc4.UInt64) -> arc4.UInt64:
        """Create a pool record and its LP ASA. asset_1_id < asset_2_id by
        convention (canonical ordering). The LP ASA is created with clawback =
        Genius so its units can be locked at first pairing. Returns pool id.
        """
        a1 = asset_1_id.native
        a2 = asset_2_id.native
        assert a1 < a2, "assets must be ordered"
        pid = self._pool_id(a1, a2)
        assert pid not in self.pools, "pool exists"

        genius_addr = self._genius_address()
        lp_cfg = itxn.AssetConfig(
            total=18_446_744_073_709_551_615,  # 2**64 - 1, max ASA supply
            decimals=6,
            unit_name=b"FLP",
            asset_name=b"Forum LP",
            url=b"ipfs://bonafide/forum-lp",
            manager=genius_addr,        # Genius manages the LP ASA
            reserve=Global.current_application_address,
            freeze=Global.zero_address, # no freeze surface (Pitfall D)
            clawback=genius_addr,       # Genius can lock LP units
            fee=0,
        ).submit()
        lp_id = lp_cfg.created_asset.id

        info = PoolInfo(
            asset_1_id=arc4.UInt64(a1),
            asset_2_id=arc4.UInt64(a2),
            lp_asset_id=arc4.UInt64(lp_id),
            reserve_1=arc4.UInt64(0),
            reserve_2=arc4.UInt64(0),
            issued_lp=arc4.UInt64(0),
            protocol_fees_1=arc4.UInt64(0),
            protocol_fees_2=arc4.UInt64(0),
            bootstrapped=arc4.Bool(False),  # noqa: FBT003
        )
        self.pools[pid] = info.copy()
        self.pool_count.value = self.pool_count.value + UInt64(1)
        return arc4.UInt64(pid)

    @arc4.abimethod
    def add_initial_liquidity(
        self,
        pool_id: arc4.UInt64,
        deposit_1: gtxn.AssetTransferTransaction,
        deposit_2: gtxn.AssetTransferTransaction,
        genius_lock_appl: gtxn.ApplicationCallTransaction,
    ) -> arc4.UInt64:
        """The genesis pairing. Requires, in the SAME atomic group:
          - deposit_1, deposit_2: the two reserve asset transfers to Forum
          - genius_lock_appl: an app call to Genius.lock_initial for this pool
        Forum mints LP, clawback-transfers ALL of it into Genius custody, and
        verifies the Genius lock call targets the right app/method. Reverts if
        the Genius lock call is missing or malformed -- this is the no-unlocked-
        LP invariant.

        Returns LP minted.
        """
        pid = pool_id.native
        assert pid in self.pools, "no pool"
        info = self.pools[pid].copy()
        assert info.bootstrapped.native == False, "already bootstrapped"  # noqa: E712

        # Validate the deposits target this pool and Forum.
        assert deposit_1.xfer_asset.id == info.asset_1_id.native, "bad asset 1"
        assert deposit_2.xfer_asset.id == info.asset_2_id.native, "bad asset 2"
        assert deposit_1.asset_receiver == Global.current_application_address, "dep1 not to forum"
        assert deposit_2.asset_receiver == Global.current_application_address, "dep2 not to forum"
        amt_1 = deposit_1.asset_amount
        amt_2 = deposit_2.asset_amount
        assert amt_1 > UInt64(0) and amt_2 > UInt64(0), "empty deposit"

        # The mandatory Genius lock call invariant.
        assert genius_lock_appl.app_id.id == self.genius_app.value, "lock not to Genius"
        assert (
            genius_lock_appl.app_args(0) == arc4.arc4_signature("lock_initial(uint64,uint64,uint64,address)uint64")
        ), "lock method mismatch"

        # Initial LP = sqrt(amt_1 * amt_2) - MINIMUM_LIQUIDITY.
        liq = self._isqrt(amt_1 * amt_2)
        assert liq > C.MINIMUM_LIQUIDITY, "insufficient initial liquidity"
        minted = liq - C.MINIMUM_LIQUIDITY

        info.reserve_1 = arc4.UInt64(amt_1)
        info.reserve_2 = arc4.UInt64(amt_2)
        info.issued_lp = arc4.UInt64(liq)  # includes the burned minimum
        info.bootstrapped = arc4.Bool(True)  # noqa: FBT003
        self.pools[pid] = info.copy()

        # Clawback ALL minted LP into Genius custody. The depositor never holds
        # transferable LP -- they hold the Tessera-LP certificate instead.
        itxn.AssetTransfer(
            xfer_asset=info.lp_asset_id.native,
            asset_receiver=self._genius_address(),
            asset_amount=minted,
            fee=0,
        ).submit()
        return arc4.UInt64(minted)

    @arc4.abimethod
    def swap(
        self,
        pool_id: arc4.UInt64,
        asset_in: gtxn.AssetTransferTransaction,
        min_out: arc4.UInt64,
    ) -> arc4.UInt64:
        """Constant-product swap with 0.30% fee. The 1/6 protocol share of the
        fee accumulates in reserves and is tracked in protocol_fees_*. Also
        nudges the Genius auto-roll for this pool. Returns output amount.
        """
        pid = pool_id.native
        assert pid in self.pools, "no pool"
        info = self.pools[pid].copy()
        assert info.bootstrapped.native == True, "not bootstrapped"  # noqa: E712
        assert asset_in.asset_receiver == Global.current_application_address, "in not to forum"

        in_id = asset_in.xfer_asset.id
        in_amt = asset_in.asset_amount
        assert in_amt > UInt64(0), "empty swap"

        if in_id == info.asset_1_id.native:
            out_amt, prot_fee = self._amount_out(in_amt, info.reserve_1.native, info.reserve_2.native)
            assert out_amt >= min_out.native, "slippage"
            info.reserve_1 = arc4.UInt64(info.reserve_1.native + in_amt)
            info.reserve_2 = arc4.UInt64(info.reserve_2.native - out_amt)
            info.protocol_fees_1 = arc4.UInt64(info.protocol_fees_1.native + prot_fee)
            self.pools[pid] = info.copy()
            itxn.AssetTransfer(
                xfer_asset=info.asset_2_id.native,
                asset_receiver=Txn.sender,
                asset_amount=out_amt,
                fee=0,
            ).submit()
        else:
            assert in_id == info.asset_2_id.native, "bad input asset"
            out_amt, prot_fee = self._amount_out(in_amt, info.reserve_2.native, info.reserve_1.native)
            assert out_amt >= min_out.native, "slippage"
            info.reserve_2 = arc4.UInt64(info.reserve_2.native + in_amt)
            info.reserve_1 = arc4.UInt64(info.reserve_1.native - out_amt)
            info.protocol_fees_2 = arc4.UInt64(info.protocol_fees_2.native + prot_fee)
            self.pools[pid] = info.copy()
            itxn.AssetTransfer(
                xfer_asset=info.asset_1_id.native,
                asset_receiver=Txn.sender,
                asset_amount=out_amt,
                fee=0,
            ).submit()

        # Touch Genius auto-roll (best-effort; ignores if not yet rollable).
        arc4.abi_call(
            IGenius.maybe_roll,
            pool_id,
            app_id=self.genius_app.value,
        )
        return arc4.UInt64(out_amt)

    @arc4.abimethod
    def remove_liquidity(
        self,
        pool_id: arc4.UInt64,
        lp_amount: arc4.UInt64,
        recipient: arc4.Address,
    ) -> None:
        """Burn LP and return the proportional reserve share. Callable ONLY by
        Genius (as the result of a valid Tessera-LP redemption). There is no
        public remove-liquidity path; ordinary users redeem via Genius.
        """
        assert Global.caller_application_id == self.genius_app.value, "not Genius"
        pid = pool_id.native
        info = self.pools[pid].copy()
        total_lp = info.issued_lp.native
        burn = lp_amount.native
        assert burn > UInt64(0) and burn <= total_lp, "bad lp amount"

        out_1 = (info.reserve_1.native * burn) // total_lp
        out_2 = (info.reserve_2.native * burn) // total_lp
        info.reserve_1 = arc4.UInt64(info.reserve_1.native - out_1)
        info.reserve_2 = arc4.UInt64(info.reserve_2.native - out_2)
        info.issued_lp = arc4.UInt64(total_lp - burn)
        self.pools[pid] = info.copy()

        itxn.AssetTransfer(
            xfer_asset=info.asset_1_id.native,
            asset_receiver=recipient.native,
            asset_amount=out_1,
            fee=0,
        ).submit()
        itxn.AssetTransfer(
            xfer_asset=info.asset_2_id.native,
            asset_receiver=recipient.native,
            asset_amount=out_2,
            fee=0,
        ).submit()

    @arc4.abimethod
    def claim_protocol_fees(self, pool_id: arc4.UInt64) -> None:
        """Sweep accumulated protocol fees to the treasury. Any caller may
        invoke; the destination is fixed to the configured treasury.
        """
        pid = pool_id.native
        info = self.pools[pid].copy()
        fee_1 = info.protocol_fees_1.native
        fee_2 = info.protocol_fees_2.native
        info.protocol_fees_1 = arc4.UInt64(0)
        info.protocol_fees_2 = arc4.UInt64(0)
        # Protocol fees are carved out of reserves at claim time.
        info.reserve_1 = arc4.UInt64(info.reserve_1.native - fee_1)
        info.reserve_2 = arc4.UInt64(info.reserve_2.native - fee_2)
        self.pools[pid] = info.copy()
        if fee_1 > UInt64(0):
            itxn.AssetTransfer(
                xfer_asset=info.asset_1_id.native,
                asset_receiver=self.treasury.value.native,
                asset_amount=fee_1,
                fee=0,
            ).submit()
        if fee_2 > UInt64(0):
            itxn.AssetTransfer(
                xfer_asset=info.asset_2_id.native,
                asset_receiver=self.treasury.value.native,
                asset_amount=fee_2,
                fee=0,
            ).submit()

    # -- reads --------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def pool(self, pool_id: arc4.UInt64) -> PoolInfo:
        return self.pools[pool_id.native]

    @arc4.abimethod(readonly=True)
    def pool_id_of(self, asset_1_id: arc4.UInt64, asset_2_id: arc4.UInt64) -> arc4.UInt64:
        return arc4.UInt64(self._pool_id(asset_1_id.native, asset_2_id.native))

    @arc4.abimethod(readonly=True)
    def quote(self, pool_id: arc4.UInt64, asset_1_in: arc4.UInt64) -> arc4.UInt64:
        info = self.pools[pool_id.native].copy()
        out_amt, _fee = self._amount_out(
            asset_1_in.native, info.reserve_1.native, info.reserve_2.native
        )
        return arc4.UInt64(out_amt)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _amount_out(
        self, in_amt: UInt64, reserve_in: UInt64, reserve_out: UInt64
    ) -> tuple[UInt64, UInt64]:
        """Constant-product output with 0.30% fee. Returns (out, protocol_fee).
        protocol_fee is the 1/6 share of the total fee, expressed in input-asset
        units, accumulated in reserve_in.
        """
        assert reserve_in > UInt64(0) and reserve_out > UInt64(0), "empty reserves"
        total_fee = (in_amt * C.TOTAL_FEE_BPS) // C.BPS_DENOMINATOR
        protocol_fee = (total_fee * C.PROTOCOL_FEE_NUMERATOR) // C.PROTOCOL_FEE_DENOMINATOR
        in_after_fee = in_amt - total_fee
        # x*y=k: out = reserve_out * in_after_fee / (reserve_in + in_after_fee)
        numerator = reserve_out * in_after_fee
        denominator = reserve_in + in_after_fee
        out_amt = numerator // denominator
        return out_amt, protocol_fee

    @subroutine
    def _isqrt(self, n: UInt64) -> UInt64:
        """Integer square root (Newton's method)."""
        if n == UInt64(0):
            return UInt64(0)
        x = n
        y = (x + UInt64(1)) // UInt64(2)
        while y < x:
            x = y
            y = (x + n // x) // UInt64(2)
        return x

    @subroutine
    def _pool_id(self, a1: UInt64, a2: UInt64) -> UInt64:
        # Deterministic synthetic pool id from the ordered asset pair.
        raw = op.sha256(op.itob(a1) + op.itob(a2))
        return op.extract_uint64(raw, UInt64(0))

    @subroutine
    def _genius_address(self) -> Account:
        # Application address of the configured Genius app.
        return Application(self.genius_app.value).address

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
