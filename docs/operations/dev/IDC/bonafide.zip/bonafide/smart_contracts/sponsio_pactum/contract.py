# BONAFIDE :: Sponsio Pactum
# The covenant binding. Manages the proposal lifecycle: draft -> active ->
# (passed | rejected | vetoed) -> executed. Vote counting is delegated to
# Curia, which calls back to record tallies. Censura may veto an active or
# passed proposal under a 3-of-7 Counsellor quorum.
#
# A proposal passes iff >= 7 of 13 YES votes are recorded within the window
# AND no veto exists.

from algopy import (
    ARC4Contract,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    BoxMap,
    subroutine,
)

from ..common import constants as C
from ..common.types import Hash32, Proposal


class SponsioPactum(ARC4Contract):
    def __init__(self) -> None:
        self.senatus_app = GlobalState(UInt64(0))
        self.curia_app = GlobalState(UInt64(0))
        self.censura_app = GlobalState(UInt64(0))
        self.tabularium_app = GlobalState(UInt64(0))
        self.frozen = GlobalState(UInt64(0))
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        self.next_id = GlobalState(UInt64(0))
        self.proposals = BoxMap(UInt64, Proposal, key_prefix=b"p_")

    # -- configuration ------------------------------------------------------

    @arc4.abimethod
    def configure(
        self,
        senatus_app: arc4.UInt64,
        curia_app: arc4.UInt64,
        censura_app: arc4.UInt64,
        tabularium_app: arc4.UInt64,
    ) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.senatus_app.value = senatus_app.native
        self.curia_app.value = curia_app.native
        self.censura_app.value = censura_app.native
        self.tabularium_app.value = tabularium_app.native

    @arc4.abimethod
    def freeze(self) -> None:
        self._only_deployer()
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- lifecycle ----------------------------------------------------------

    @arc4.abimethod
    def propose(
        self,
        proposer_seat: arc4.UInt64,
        payload_hash: Hash32,
        seat_value_snapshot: arc4.UInt64,
    ) -> arc4.UInt64:
        """Open a new proposal. Caller must hold the seat NFT named by
        proposer_seat (verified by Curia in production via a grouped seat
        check; here we record the seat and let Curia gate the vote path).
        Convener may propose directly; Counsellors may propose; Citizens
        require a Counsellor second (enforced in Curia.second()).
        """
        pid = self.next_id.value
        now = Global.latest_timestamp
        prop = Proposal(
            proposer_seat=proposer_seat,
            status=arc4.UInt64(C.PROP_ACTIVE),
            created_ts=arc4.UInt64(now),
            vote_open_ts=arc4.UInt64(now),
            vote_close_ts=arc4.UInt64(now + C.VOTE_WINDOW_LEN),
            yes_count=arc4.UInt64(0),
            no_count=arc4.UInt64(0),
            abstain_count=arc4.UInt64(0),
            seat_value_snapshot=seat_value_snapshot,
            payload_hash=payload_hash.copy(),
        )
        self.proposals[pid] = prop.copy()
        self.next_id.value = pid + UInt64(1)
        return arc4.UInt64(pid)

    @arc4.abimethod
    def record_vote(self, proposal_id: arc4.UInt64, ballot: arc4.UInt64) -> None:
        """Curia-only callback: increment the tally for a single seat's vote.
        Curia enforces one-vote-per-seat; Sponsio Pactum just counts.
        """
        assert Global.caller_application_id == self.curia_app.value, "not Curia"
        pid = proposal_id.native
        prop = self.proposals[pid].copy()
        assert prop.status.native == C.PROP_ACTIVE, "not active"
        assert Global.latest_timestamp <= prop.vote_close_ts.native, "window closed"
        b = ballot.native
        if b == C.BALLOT_YES:
            prop.yes_count = arc4.UInt64(prop.yes_count.native + UInt64(1))
        elif b == C.BALLOT_NO:
            prop.no_count = arc4.UInt64(prop.no_count.native + UInt64(1))
        else:
            prop.abstain_count = arc4.UInt64(prop.abstain_count.native + UInt64(1))
        self.proposals[pid] = prop.copy()

    @arc4.abimethod
    def veto(self, proposal_id: arc4.UInt64) -> None:
        """Censura-only: mark a proposal vetoed. Censura enforces 3-of-7."""
        assert Global.caller_application_id == self.censura_app.value, "not Censura"
        pid = proposal_id.native
        prop = self.proposals[pid].copy()
        assert (
            prop.status.native == C.PROP_ACTIVE
            or prop.status.native == C.PROP_PASSED
        ), "not vetoable"
        prop.status = arc4.UInt64(C.PROP_VETOED)
        self.proposals[pid] = prop.copy()

    @arc4.abimethod
    def finalize(self, proposal_id: arc4.UInt64) -> arc4.UInt64:
        """Close voting after the window and set passed/rejected. Anyone may
        call once the window has elapsed. Returns the resulting status.
        """
        pid = proposal_id.native
        prop = self.proposals[pid].copy()
        assert prop.status.native == C.PROP_ACTIVE, "not active"
        assert Global.latest_timestamp > prop.vote_close_ts.native, "window open"
        if prop.yes_count.native >= C.QUORUM:
            prop.status = arc4.UInt64(C.PROP_PASSED)
        else:
            prop.status = arc4.UInt64(C.PROP_REJECTED)
        self.proposals[pid] = prop.copy()
        return arc4.UInt64(prop.status.native)

    @arc4.abimethod
    def mark_executed(self, proposal_id: arc4.UInt64) -> None:
        """Curia-only: flag a passed proposal as executed once its on-chain
        effects have been applied.
        """
        assert Global.caller_application_id == self.curia_app.value, "not Curia"
        pid = proposal_id.native
        prop = self.proposals[pid].copy()
        assert prop.status.native == C.PROP_PASSED, "not passed"
        prop.status = arc4.UInt64(C.PROP_EXECUTED)
        self.proposals[pid] = prop.copy()

    # -- reads --------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def get(self, proposal_id: arc4.UInt64) -> Proposal:
        return self.proposals[proposal_id.native]

    @arc4.abimethod(readonly=True)
    def count(self) -> arc4.UInt64:
        return arc4.UInt64(self.next_id.value)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
