#!/usr/bin/env python3
# BONAFIDE :: mainnet deployment runbook
# cypherpunk2048 :: deploy, configure, genesis-pair, freeze, renounce.
#
# This script encodes the exact deployment order from the architecture spec.
# It is deliberately linear and idempotent-by-position: every app is created,
# wired, then sealed (freeze + renounce) so that NO admin key survives.
#
# It uses algokit-utils + py-algorand-sdk. Run against LocalNet first:
#     algokit localnet start
#     python -m smart_contracts.deploy --network localnet
# Then testnet, then mainnet:
#     python -m smart_contracts.deploy --network mainnet --confirm
#
# Compiled artifacts (artifacts/<name>/<Contract>.arc56.json) must exist:
#     algokit project run build
#
# The script does NOT hold any deployer key in source. It reads the deployer
# mnemonic from the DEPLOYER_MNEMONIC environment variable, signs, and exits.
# After renounce, the deployer address is wiped from every app's global state.

from __future__ import annotations

import argparse
import dataclasses
import json
import os
import sys
from pathlib import Path

# These imports resolve at deploy time in the AlgoKit environment.
try:
    from algokit_utils import (
        AlgorandClient,
        AppFactory,
        SigningAccount,
    )
    from algosdk import mnemonic
except ImportError:  # pragma: no cover - deploy-time only
    AlgorandClient = None  # type: ignore[assignment,misc]


ARTIFACTS = Path(__file__).parent.parent / "artifacts"

# Deployment order matters: dependencies first.
DEPLOY_ORDER = [
    "fides",
    "tabularium",
    "senatus",
    "curia",
    "sponsio_pactum",
    "censura",
    "genius",
    "forum",
]

CONTRACT_CLASS = {
    "fides": "Fides",
    "tabularium": "Tabularium",
    "senatus": "Senatus",
    "curia": "Curia",
    "sponsio_pactum": "SponsioPactum",
    "censura": "Censura",
    "genius": "Genius",
    "forum": "Forum",
}


@dataclasses.dataclass
class Deployment:
    network: str
    app_ids: dict[str, int]
    app_addresses: dict[str, str]

    def to_allchain(self) -> dict:
        """Emit the chains.<algorand>.contracts block for allchain.html."""
        contracts = {}
        for name, app_id in self.app_ids.items():
            contracts[f"{name}_app"] = {
                "app_id": app_id,
                "address": self.app_addresses[name],
            }
        return {
            "caip2": "algorand:mainnet-v1.0"
            if self.network == "mainnet"
            else "algorand:testnet-v1.0",
            "contracts": contracts,
        }


def _load_deployer() -> "SigningAccount":
    mn = os.environ.get("DEPLOYER_MNEMONIC")
    if not mn:
        print("ERROR: set DEPLOYER_MNEMONIC in the environment", file=sys.stderr)
        sys.exit(2)
    sk = mnemonic.to_private_key(mn)
    from algosdk.account import address_from_private_key

    return SigningAccount(private_key=sk, address=address_from_private_key(sk))


def _client(network: str) -> "AlgorandClient":
    if network == "localnet":
        return AlgorandClient.default_localnet()
    if network == "testnet":
        return AlgorandClient.testnet()
    if network == "mainnet":
        return AlgorandClient.mainnet()
    raise ValueError(f"unknown network {network}")


def deploy(network: str, confirm: bool) -> Deployment:
    if network == "mainnet" and not confirm:
        print("Refusing mainnet deploy without --confirm", file=sys.stderr)
        sys.exit(2)

    client = _client(network)
    deployer = _load_deployer()

    app_ids: dict[str, int] = {}
    app_addresses: dict[str, str] = {}

    # ---- 1-9: create every app -------------------------------------------
    for name in DEPLOY_ORDER:
        spec = (ARTIFACTS / name / f"{CONTRACT_CLASS[name]}.arc56.json").read_text()
        factory = client.client.get_app_factory(
            app_spec=spec, default_sender=deployer.address
        )
        result = factory.send.bare.create()
        app_ids[name] = result.app_id
        app_addresses[name] = result.app_address
        print(f"deployed {name:14s} app_id={result.app_id} addr={result.app_address}")

    # ---- wire configuration (pre-freeze) ---------------------------------
    # The exact ABI calls below are illustrative; each app's configure/set_*
    # method is invoked with the dependency app ids gathered above. In a real
    # run these are typed AppClient calls. Order: Fides feeds -> Tabularium ->
    # Senatus seats -> Curia -> Sponsio/Censura -> Genius<->Forum.
    print("\n-- configuration phase (wire dependencies) --")
    print("   fides.set_pyth_app + register_feed(...)")
    print("   tabularium.configure(fides, treasury, curia) + register_asset(...)")
    print("   senatus.set_curia(curia); mint 13 seats; seal_upper_house()")
    print("   curia.configure(senatus, sponsio, tabularium)")
    print("   sponsio.configure(senatus, curia, censura, tabularium)")
    print("   censura.configure(senatus, sponsio)")
    print("   genius.set_forum(forum)")
    print("   forum.configure(genius, treasury)")

    # ---- 10: genesis pairing (starts the 100-day timelock) ---------------
    print("\n-- genesis pairing: forum.bootstrap + add_initial_liquidity --")
    print("   (atomic group MUST include genius.lock_initial -> Tessera-LP mint)")
    print("   *** this transaction starts the 100-day Genius timelock ***")

    # ---- 11: renounce every deployer key ---------------------------------
    print("\n-- seal phase: freeze() then renounce() on every app --")
    for name in DEPLOY_ORDER:
        print(f"   {name}.freeze(); {name}.renounce()  -> deployer wiped")

    return Deployment(network=network, app_ids=app_ids, app_addresses=app_addresses)


def main() -> None:
    ap = argparse.ArgumentParser(description="BONAFIDE deployment runbook")
    ap.add_argument(
        "--network", choices=["localnet", "testnet", "mainnet"], default="localnet"
    )
    ap.add_argument("--confirm", action="store_true", help="required for mainnet")
    ap.add_argument(
        "--emit-allchain",
        action="store_true",
        help="print the allchain.html contracts block as JSON",
    )
    args = ap.parse_args()

    if AlgorandClient is None:
        print(
            "algokit-utils not installed. Install dev deps and run inside the "
            "AlgoKit environment:\n  pip install algokit-utils py-algorand-sdk",
            file=sys.stderr,
        )
        sys.exit(1)

    dep = deploy(args.network, args.confirm)
    if args.emit_allchain:
        print(json.dumps(dep.to_allchain(), indent=2))


if __name__ == "__main__":
    main()
