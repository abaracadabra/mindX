# BONAFIDE :: typed cross-contract interfaces
#
# PuyaPy resolves cross-contract ABI calls against a typed contract reference.
# Collecting the interface stubs here keeps each production contract module
# free of stub classes, and gives the build a single place to find them.
#
# These classes are interface shapes only: their method bodies are never
# deployed. arc4.abi_call(Interface.method, ..., app_id=<live app>) routes the
# call to the real deployed application at <live app>.

from algopy import ARC4Contract, arc4


class IFides(ARC4Contract):
    @arc4.abimethod(readonly=True)
    def price(self, asset_id: arc4.UInt64) -> arc4.UInt64:  # pragma: no cover
        return arc4.UInt64(0)


class ISenatus(ARC4Contract):
    @arc4.abimethod(readonly=True)
    def holder_of(self, seat_index: arc4.UInt64) -> arc4.Address:  # pragma: no cover
        return arc4.Address()

    @arc4.abimethod
    def rotate_citizen(
        self, seat_index: arc4.UInt64, new_holder: arc4.Address
    ) -> None:  # pragma: no cover
        pass


class ISponsioPactum(ARC4Contract):
    @arc4.abimethod
    def record_vote(
        self, proposal_id: arc4.UInt64, ballot: arc4.UInt64
    ) -> None:  # pragma: no cover
        pass

    @arc4.abimethod
    def mark_executed(self, proposal_id: arc4.UInt64) -> None:  # pragma: no cover
        pass

    @arc4.abimethod
    def veto(self, proposal_id: arc4.UInt64) -> None:  # pragma: no cover
        pass


class IGenius(ARC4Contract):
    @arc4.abimethod
    def maybe_roll(self, pool_app: arc4.UInt64) -> arc4.UInt64:  # pragma: no cover
        return arc4.UInt64(0)
