# BONAFIDE :: shared constants
# cypherpunk2048 :: terse, immutable, no admin keys post-deploy
#
# Module-level constants are plain int/Final literals. PuyaPy promotes them to
# UInt64 at each use site inside contract methods. (PuyaPy forbids UInt64(...)
# construction at module scope.)
#
# All time arithmetic is in whole seconds against Global.latest_timestamp.

from typing import Final

# ---------------------------------------------------------------------------
# Timelock geometry (Genius)
# ---------------------------------------------------------------------------
SECONDS_PER_DAY: Final = 86_400

# 90 days: redemption window opens.
LOCK_WINDOW_OPEN: Final = 90 * 86_400  # 7_776_000

# 100 days: epoch closes; auto-roll fires on next touch.
LOCK_EPOCH_LEN: Final = 100 * 86_400  # 8_640_000

# Redemption window length is LOCK_EPOCH_LEN - LOCK_WINDOW_OPEN == 10 days.

# ---------------------------------------------------------------------------
# Genius lock state machine enum
# ---------------------------------------------------------------------------
STATE_UNINITIALIZED: Final = 0
STATE_LOCKED_EPOCH: Final = 1
STATE_REDEMPTION_WINDOW: Final = 2
STATE_AUTO_ROLLED: Final = 3  # transient; resolves back to LOCKED_EPOCH on touch

# ---------------------------------------------------------------------------
# Governance geometry (Senatus / Curia)
# ---------------------------------------------------------------------------
SEAT_COUNT: Final = 13
QUORUM: Final = 7  # >= 7 of 13 YES to pass
COUNSELLOR_VETO_QUORUM: Final = 3  # 3-of-7 Counsellors for Censura veto
CONVENER_SEAT: Final = 0
COUNSELLOR_FIRST: Final = 1
COUNSELLOR_LAST: Final = 7
CITIZEN_FIRST: Final = 8
CITIZEN_LAST: Final = 12

# Ballot encodings.
BALLOT_NO: Final = 0
BALLOT_YES: Final = 1
BALLOT_ABSTAIN: Final = 2

# Proposal lifecycle (Sponsio Pactum).
PROP_DRAFT: Final = 0
PROP_ACTIVE: Final = 1
PROP_PASSED: Final = 2
PROP_REJECTED: Final = 3
PROP_VETOED: Final = 4
PROP_EXECUTED: Final = 5

# Default voting window: 7 days.
VOTE_WINDOW_LEN: Final = 7 * 86_400

# ---------------------------------------------------------------------------
# Forum AMM geometry (Tinyman v2 derived)
# ---------------------------------------------------------------------------
# Total swap fee in basis points of input (0.30%).
TOTAL_FEE_BPS: Final = 30
# Protocol share = 1/6 of total fee (0.05% of input), accumulated in the
# underlying reserve assets and claimable to treasury by any caller.
PROTOCOL_FEE_NUMERATOR: Final = 1
PROTOCOL_FEE_DENOMINATOR: Final = 6
BPS_DENOMINATOR: Final = 10_000

# Minimum liquidity permanently locked on first pairing (mirrors UniswapV2
# MINIMUM_LIQUIDITY; prevents first-LP share inflation).
MINIMUM_LIQUIDITY: Final = 1_000

# Per-redemption cap: a single Tessera-LP redemption may withdraw at most this
# fraction (numerator/denominator) of locked depth. Defends against
# redemption-right concentration (Pitfall B).
REDEEM_CAP_NUMERATOR: Final = 5
REDEEM_CAP_DENOMINATOR: Final = 100  # 5%
