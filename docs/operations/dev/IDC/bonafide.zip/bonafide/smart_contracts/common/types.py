# BONAFIDE :: shared ARC4 struct types
#
# On-chain record formats stored in box storage and returned across ABI
# boundaries. Flat and fixed-size where possible so box sizing is deterministic.

import typing

from algopy import arc4

# 32-byte commitment (sha256 of an off-chain proposal payload).
Hash32: typing.TypeAlias = arc4.StaticArray[arc4.Byte, typing.Literal[32]]


class LockRecord(arc4.Struct):
    """Genius timelock record, one per Forum pool (keyed by pool app id)."""

    pool_app: arc4.UInt64
    lp_asset_id: arc4.UInt64
    locked_amount: arc4.UInt64
    lock_start_ts: arc4.UInt64
    tessera_asset_id: arc4.UInt64
    depositor: arc4.Address
    redeemed: arc4.Bool


class PoolInfo(arc4.Struct):
    """Forum pool reserves and bookkeeping."""

    asset_1_id: arc4.UInt64
    asset_2_id: arc4.UInt64
    lp_asset_id: arc4.UInt64
    reserve_1: arc4.UInt64
    reserve_2: arc4.UInt64
    issued_lp: arc4.UInt64
    protocol_fees_1: arc4.UInt64
    protocol_fees_2: arc4.UInt64
    bootstrapped: arc4.Bool


class Proposal(arc4.Struct):
    """Sponsio Pactum proposal record."""

    proposer_seat: arc4.UInt64
    status: arc4.UInt64
    created_ts: arc4.UInt64
    vote_open_ts: arc4.UInt64
    vote_close_ts: arc4.UInt64
    yes_count: arc4.UInt64
    no_count: arc4.UInt64
    abstain_count: arc4.UInt64
    seat_value_snapshot: arc4.UInt64
    payload_hash: Hash32


class AssetUsd(arc4.Struct):
    """Tabularium per-asset USD valuation line item."""

    asset_id: arc4.UInt64
    held_amount: arc4.UInt64
    price_usd_micro: arc4.UInt64  # USD price * 1e6
    value_usd_micro: arc4.UInt64  # held * price, normalised to 1e6


# Composite vote/veto key: (proposal_id, seat_index) packed into a fixed
# 2-element StaticArray of UInt64. Used as a BoxMap key in Curia and Censura.
VoteKey: typing.TypeAlias = arc4.StaticArray[arc4.UInt64, typing.Literal[2]]
