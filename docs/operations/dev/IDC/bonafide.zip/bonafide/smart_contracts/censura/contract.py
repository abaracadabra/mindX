# BONAFIDE :: Censura
# The moderation organ. Holds no individual veto. A proposal may be vetoed
# only when 3 of the 7 Counsellors (seats 1-7) co-sign a veto for the same
# proposal id. Censura accumulates Counsellor veto signals in box storage and,
# on the third distinct Counsellor, calls Sponsio Pactum.veto.
#
# There is no Convener override and no admin override. The kill switch is
# collective by construction.

from algopy import (
    ARC4Contract,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    BoxMap,
    subroutine,
)

from ..common import constants as C
from ..common.interfaces import ISenatus, ISponsioPactum
from ..common.types import VoteKey


class Censura(ARC4Contract):
    def __init__(self) -> None:
        self.senatus_app = GlobalState(UInt64(0))
        self.sponsio_app = GlobalState(UInt64(0))
        self.frozen = GlobalState(UInt64(0))
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        # (proposal_id, seat_index) -> 1 if that Counsellor signalled veto.
        self.signal = BoxMap(VoteKey, UInt64, key_prefix=b"v_")
        # proposal_id -> count of distinct Counsellor veto signals.
        self.veto_tally = BoxMap(UInt64, UInt64, key_prefix=b"t_")
        # proposal_id -> 1 once veto fired (idempotency).
        self.vetoed = BoxMap(UInt64, UInt64, key_prefix=b"x_")

    # -- configuration ------------------------------------------------------

    @arc4.abimethod
    def configure(self, senatus_app: arc4.UInt64, sponsio_app: arc4.UInt64) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.senatus_app.value = senatus_app.native
        self.sponsio_app.value = sponsio_app.native

    @arc4.abimethod
    def freeze(self) -> None:
        self._only_deployer()
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- veto signalling ----------------------------------------------------

    @arc4.abimethod
    def signal_veto(self, proposal_id: arc4.UInt64, seat_index: arc4.UInt64) -> arc4.UInt64:
        """A Counsellor signals veto for a proposal. Caller must hold the
        Counsellor seat NFT for seat_index (verified by Senatus). On the third
        distinct Counsellor signal, fire the veto on Sponsio Pactum.

        Returns the current veto tally.
        """
        idx = seat_index.native
        assert idx >= C.COUNSELLOR_FIRST and idx <= C.COUNSELLOR_LAST, "not a counsellor seat"
        self._require_seat_holder(seat_index, arc4.Address(Txn.sender))

        key = self._key(proposal_id.native, idx)
        assert key not in self.signal, "already signalled"
        self.signal[key] = UInt64(1)

        pid = proposal_id.native
        tally = (self.veto_tally[pid] if pid in self.veto_tally else UInt64(0)) + UInt64(1)
        self.veto_tally[pid] = tally

        if tally >= C.COUNSELLOR_VETO_QUORUM and (pid not in self.vetoed):
            self.vetoed[pid] = UInt64(1)
            arc4.abi_call(
                ISponsioPactum.veto,
                proposal_id,
                app_id=self.sponsio_app.value,
            )
        return arc4.UInt64(tally)

    # -- reads --------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def tally(self, proposal_id: arc4.UInt64) -> arc4.UInt64:
        pid = proposal_id.native
        return arc4.UInt64(self.veto_tally[pid] if pid in self.veto_tally else UInt64(0))

    @arc4.abimethod(readonly=True)
    def is_vetoed(self, proposal_id: arc4.UInt64) -> arc4.Bool:
        pid = proposal_id.native
        return arc4.Bool(pid in self.vetoed)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _key(self, proposal_id: UInt64, seat_index: UInt64) -> VoteKey:
        return VoteKey(arc4.UInt64(proposal_id), arc4.UInt64(seat_index))

    @subroutine
    def _require_seat_holder(self, seat_index: arc4.UInt64, who: arc4.Address) -> None:
        holder, _txn = arc4.abi_call(
            ISenatus.holder_of,
            seat_index,
            app_id=self.senatus_app.value,
        )
        assert holder.native == who.native, "caller not seat holder"

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
