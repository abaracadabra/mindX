#!/usr/bin/env python3
# BONAFIDE :: allchain.html registrar
#
# allchain.html is the canonical multi-chain registry consumed by every PYTHAI
# service (agenticplace, mindx, bankon). This helper merges a fresh BONAFIDE
# deployment into the registry's Algorand block and re-emits the file. It
# operates on the JSON payload embedded in allchain.html (a <script id="allchain"
# type="application/json"> block) so the page stays a single static artifact.
#
# Usage:
#   python -m smart_contracts.allchain_register \
#       --allchain path/to/allchain.html \
#       --deployment deployment.json
#
# deployment.json is the output of `deploy.py --emit-allchain`.

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

# The expected registry schema. New BONAFIDE components register under
# chains["algorand:mainnet-v1.0"].contracts and .asas.
SCHEMA_VERSION = "1.0.0"

SCRIPT_RE = re.compile(
    r'(<script id="allchain" type="application/json">)(.*?)(</script>)',
    re.DOTALL,
)


def _empty_registry() -> dict:
    return {
        "version": SCHEMA_VERSION,
        "updated": None,
        "chains": {},
        "services": {
            "agenticplace": {
                "url": "https://agenticplace.pythai.net",
                "x402_schemes": ["exact_avm", "exact_evm"],
            },
            "mindx": {
                "url": "https://mindx.pythai.net",
                "x402_schemes": ["exact_avm"],
                "billing": "per-inference",
            },
            "bankon": {"url": "https://bankon.pythai.net", "role": "identity"},
        },
    }


def load_registry(allchain_path: Path) -> tuple[dict, str]:
    """Return (registry_dict, raw_html). If the file is missing the embedded
    JSON block, start from an empty registry."""
    if not allchain_path.exists():
        return _empty_registry(), ""
    html = allchain_path.read_text()
    m = SCRIPT_RE.search(html)
    if not m:
        return _empty_registry(), html
    return json.loads(m.group(2)), html


def merge_deployment(registry: dict, deployment: dict) -> dict:
    caip2 = deployment["caip2"]
    chains = registry.setdefault("chains", {})
    chain = chains.setdefault(caip2, {"caip2": caip2, "contracts": {}, "asas": {}})
    chain.setdefault("contracts", {}).update(deployment.get("contracts", {}))
    if "asas" in deployment:
        chain.setdefault("asas", {}).update(deployment["asas"])
    if "facilitators" in deployment:
        chain.setdefault("facilitators", {}).update(deployment["facilitators"])
    return registry


def write_registry(registry: dict, allchain_path: Path, raw_html: str) -> None:
    payload = json.dumps(registry, indent=2)
    block = f'<script id="allchain" type="application/json">\n{payload}\n</script>'
    if raw_html and SCRIPT_RE.search(raw_html):
        new_html = SCRIPT_RE.sub(
            lambda _m: f'<script id="allchain" type="application/json">\n{payload}\n</script>',
            raw_html,
        )
    else:
        # Minimal standalone page if none existed.
        new_html = (
            "<!doctype html><html><head><meta charset='utf-8'>"
            "<title>allchain</title></head><body>\n"
            f"{block}\n</body></html>\n"
        )
    allchain_path.write_text(new_html)


def main() -> None:
    ap = argparse.ArgumentParser(description="Register a BONAFIDE deployment into allchain.html")
    ap.add_argument("--allchain", type=Path, required=True)
    ap.add_argument("--deployment", type=Path, required=True)
    args = ap.parse_args()

    registry, raw_html = load_registry(args.allchain)
    deployment = json.loads(args.deployment.read_text())
    merged = merge_deployment(registry, deployment)
    write_registry(merged, args.allchain, raw_html)
    print(f"registered deployment into {args.allchain}")


if __name__ == "__main__":
    main()
