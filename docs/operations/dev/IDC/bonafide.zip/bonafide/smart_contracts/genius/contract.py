# BONAFIDE :: Genius
# The liquidity timelock. The single most important invariant in the suite.
#
# At the first liquidity pairing of a Forum pool, Genius takes custody of the
# pool LP ASA and starts a 100-day epoch. It mints a Tessera-LP redemption
# certificate (a non-fungible ASA) to the depositor. No address -- not even the
# deployer -- can withdraw locked liquidity except by presenting the matching
# Tessera-LP inside the 90..100 day redemption window. On day 100+ the lock
# auto-rolls into a fresh 100-day epoch on the next touch. There is no path to
# pull liquidity before day 90, after day 100, or without the Tessera-LP.
#
# State machine (per pool app id):
#   0 UNINITIALIZED      no liquidity ever paired
#   1 LOCKED_EPOCH       start <= now < start + 90d
#   2 REDEMPTION_WINDOW  start + 90d <= now < start + 100d
#   3 AUTO_ROLLED        now >= start + 100d (transient; rolls to 1 on touch)

from algopy import (
    Account,
    ARC4Contract,
    Asset,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    BoxMap,
    subroutine,
)

from ..common import constants as C
from ..common.types import LockRecord


class Genius(ARC4Contract):
    def __init__(self) -> None:
        self.forum_app = GlobalState(UInt64(0))
        self.frozen = GlobalState(UInt64(0))
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        # pool app id -> LockRecord
        self.lock = BoxMap(UInt64, LockRecord, key_prefix=b"lk_")
        # tessera asset id -> pool app id (redemption lookup)
        self.tessera_pool = BoxMap(UInt64, UInt64, key_prefix=b"tp_")

    # -- configuration ------------------------------------------------------

    @arc4.abimethod
    def set_forum(self, forum_app: arc4.UInt64) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.forum_app.value = forum_app.native

    @arc4.abimethod
    def freeze(self) -> None:
        self._only_deployer()
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- lock initiation (Forum only) --------------------------------------

    @arc4.abimethod
    def lock_initial(
        self,
        pool_app: arc4.UInt64,
        lp_asset_id: arc4.UInt64,
        locked_amount: arc4.UInt64,
        depositor: arc4.Address,
    ) -> arc4.UInt64:
        """Called by Forum.validator_app in the SAME atomic group as the
        first add_initial_liquidity. Genius must already hold the LP ASA units
        (the LP ASA is created with clawback = Genius and the units are
        clawback-transferred into Genius in the group). Genius records the
        lock, starts the epoch, mints the Tessera-LP, and returns its asset id.

        Reverts if the pool is already initialised -- there is exactly one
        genesis pairing per pool.
        """
        assert Global.caller_application_id == self.forum_app.value, "not Forum"
        pid = pool_app.native
        assert pid not in self.lock, "already locked"

        # Verify Genius actually holds the locked LP units now.
        held = Asset(lp_asset_id.native).balance(Global.current_application_address)
        assert held >= locked_amount.native, "LP not in custody"

        now = Global.latest_timestamp

        # Mint the Tessera-LP redemption certificate (NFT).
        tlp = itxn.AssetConfig(
            total=1,
            decimals=0,
            unit_name=b"TLP",
            asset_name=b"Tessera-LP",
            url=b"ipfs://bonafide/tessera-lp",
            manager=Global.zero_address,
            reserve=Global.current_application_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()
        tessera_id = tlp.created_asset.id

        rec = LockRecord(
            pool_app=pool_app,
            lp_asset_id=lp_asset_id,
            locked_amount=locked_amount,
            lock_start_ts=arc4.UInt64(now),
            tessera_asset_id=arc4.UInt64(tessera_id),
            depositor=depositor,
            redeemed=arc4.Bool(False),  # noqa: FBT003
        )
        self.lock[pid] = rec.copy()
        self.tessera_pool[tessera_id] = pid

        # Send the Tessera-LP to the depositor (must be opted in).
        itxn.AssetTransfer(
            xfer_asset=tessera_id,
            asset_receiver=depositor.native,
            asset_amount=1,
            fee=0,
        ).submit()
        return arc4.UInt64(tessera_id)

    # -- redemption ---------------------------------------------------------

    @arc4.abimethod
    def redeem(
        self,
        pool_app: arc4.UInt64,
        tessera_xfer: gtxn.AssetTransferTransaction,
        max_withdraw: arc4.UInt64,
    ) -> arc4.UInt64:
        """Redeem locked liquidity. Requires, in the same group:
          - tessera_xfer: the caller sends the matching Tessera-LP NFT to Genius
        The call must land inside the 90..100 day redemption window. Genius
        verifies the Tessera matches the pool, returns up to max_withdraw LP
        units (capped per REDEEM_CAP) to the caller, destroys the Tessera-LP,
        and marks the record redeemed.

        Returns the LP amount released.
        """
        pid = pool_app.native
        assert pid in self.lock, "no lock"
        rec = self.lock[pid].copy()
        assert rec.redeemed.native == False, "already redeemed"  # noqa: E712

        # Window check: REDEMPTION_WINDOW only.
        st = self._state_of(rec.lock_start_ts.native)
        assert st == C.STATE_REDEMPTION_WINDOW, "not in window"

        # Tessera validation.
        tessera_id = rec.tessera_asset_id.native
        assert tessera_xfer.xfer_asset.id == tessera_id, "wrong tessera"
        assert tessera_xfer.asset_receiver == Global.current_application_address, "tessera not to genius"
        assert tessera_xfer.asset_amount == UInt64(1), "need the whole tessera"
        assert tessera_xfer.sender == Txn.sender, "tessera sender mismatch"

        # Per-redemption depth cap (Pitfall B mitigation).
        cap = (rec.locked_amount.native * C.REDEEM_CAP_NUMERATOR) // C.REDEEM_CAP_DENOMINATOR
        release = max_withdraw.native
        if release > cap:
            release = cap
        if release > rec.locked_amount.native:
            release = rec.locked_amount.native

        # Release LP units back to the redeemer.
        itxn.AssetTransfer(
            xfer_asset=rec.lp_asset_id.native,
            asset_receiver=Txn.sender,
            asset_amount=release,
            fee=0,
        ).submit()

        # Destroy the Tessera-LP (Genius now holds it and is the manager-less
        # creator; destroy requires the creator to hold the full supply).
        itxn.AssetConfig(
            config_asset=tessera_id,
            fee=0,
        ).submit()
        # Note: an explicit asset-destroy is `acfg` with no addresses; PuyaPy
        # encodes destroy when total fields are omitted on an existing asset.

        rec.redeemed = arc4.Bool(True)  # noqa: FBT003
        rec.locked_amount = arc4.UInt64(rec.locked_amount.native - release)
        self.lock[pid] = rec.copy()
        return arc4.UInt64(release)

    # -- auto-roll ----------------------------------------------------------

    @arc4.abimethod
    def maybe_roll(self, pool_app: arc4.UInt64) -> arc4.UInt64:
        """If the epoch has elapsed past 100 days with no redemption taken,
        roll into a fresh epoch by resetting lock_start_ts to now. Any caller
        may invoke; Forum calls it implicitly on swaps/LP ops. Returns the new
        state.
        """
        pid = pool_app.native
        assert pid in self.lock, "no lock"
        rec = self.lock[pid].copy()
        now = Global.latest_timestamp
        if now >= rec.lock_start_ts.native + C.LOCK_EPOCH_LEN and rec.redeemed.native == False:  # noqa: E712
            rec.lock_start_ts = arc4.UInt64(now)
            self.lock[pid] = rec.copy()
        return arc4.UInt64(self._state_of(self.lock[pid].lock_start_ts.native))

    # -- reads --------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def state(self, pool_app: arc4.UInt64) -> arc4.UInt64:
        pid = pool_app.native
        if pid not in self.lock:
            return arc4.UInt64(C.STATE_UNINITIALIZED)
        return arc4.UInt64(self._state_of(self.lock[pid].lock_start_ts.native))

    @arc4.abimethod(readonly=True)
    def record(self, pool_app: arc4.UInt64) -> LockRecord:
        return self.lock[pool_app.native]

    @arc4.abimethod(readonly=True)
    def window_opens_in(self, pool_app: arc4.UInt64) -> arc4.UInt64:
        """Seconds until the redemption window opens (0 if open or past)."""
        start = self.lock[pool_app.native].lock_start_ts.native
        open_ts = start + C.LOCK_WINDOW_OPEN
        now = Global.latest_timestamp
        if now >= open_ts:
            return arc4.UInt64(0)
        return arc4.UInt64(open_ts - now)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _state_of(self, lock_start_ts: UInt64) -> UInt64:
        now = Global.latest_timestamp
        elapsed = now - lock_start_ts
        if elapsed < UInt64(C.LOCK_WINDOW_OPEN):
            return UInt64(C.STATE_LOCKED_EPOCH)
        if elapsed < UInt64(C.LOCK_EPOCH_LEN):
            return UInt64(C.STATE_REDEMPTION_WINDOW)
        return UInt64(C.STATE_AUTO_ROLLED)

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
