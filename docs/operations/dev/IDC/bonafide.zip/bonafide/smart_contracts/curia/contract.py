# BONAFIDE :: Curia
# The assembly hall. Casts votes, enforces one-vote-per-seat, mints a
# non-transferable Tessera proof-of-voting NFT per cast vote, and forwards the
# tally to Sponsio Pactum. Also drives Citizen-seat rotation by calling
# Senatus, and marks passed proposals executed.
#
# Proof of voting: each cast mints a Tessera ASA NFT to the seat holder with
# metadata committing (proposal_id, ballot, seat, voter). The Tessera is
# clawback+freeze = Curia (immutable), so it is a permanent, non-transferable
# on-chain receipt.

from algopy import (
    ARC4Contract,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    itxn,
    BoxMap,
    subroutine,
)

from ..common import constants as C
from ..common.interfaces import ISenatus, ISponsioPactum
from ..common.types import VoteKey


class Curia(ARC4Contract):
    def __init__(self) -> None:
        self.senatus_app = GlobalState(UInt64(0))
        self.sponsio_app = GlobalState(UInt64(0))
        self.tabularium_app = GlobalState(UInt64(0))
        self.frozen = GlobalState(UInt64(0))
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        # (proposal_id, seat_index) -> 1 once that seat has voted.
        self.has_voted = BoxMap(VoteKey, UInt64, key_prefix=b"hv_")
        # (proposal_id, citizen_seat) -> 1 once a Counsellor seconded it
        # (required before Citizen-proposed items go to vote).
        self.seconded = BoxMap(UInt64, UInt64, key_prefix=b"sd_")
        self.tessera_minted = GlobalState(UInt64(0))

    # -- configuration ------------------------------------------------------

    @arc4.abimethod
    def configure(
        self,
        senatus_app: arc4.UInt64,
        sponsio_app: arc4.UInt64,
        tabularium_app: arc4.UInt64,
    ) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.senatus_app.value = senatus_app.native
        self.sponsio_app.value = sponsio_app.native
        self.tabularium_app.value = tabularium_app.native

    @arc4.abimethod
    def freeze(self) -> None:
        self._only_deployer()
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- seconding ----------------------------------------------------------

    @arc4.abimethod
    def second(self, proposal_id: arc4.UInt64, counsellor_seat: arc4.UInt64) -> None:
        """A Counsellor seconds a proposal, unlocking the vote for items that
        require a second. Caller must hold the named Counsellor seat.
        """
        idx = counsellor_seat.native
        assert idx >= C.COUNSELLOR_FIRST and idx <= C.COUNSELLOR_LAST, "not counsellor"
        self._require_seat_holder(counsellor_seat, arc4.Address(Txn.sender))
        self.seconded[proposal_id.native] = UInt64(1)

    # -- voting -------------------------------------------------------------

    @arc4.abimethod
    def cast_vote(
        self,
        proposal_id: arc4.UInt64,
        seat_index: arc4.UInt64,
        ballot: arc4.UInt64,
    ) -> arc4.UInt64:
        """Cast a single seat's vote. Verifies seat ownership, one-vote-per-
        seat, mints the Tessera receipt, and forwards the tally. Returns the
        Tessera asset id.
        """
        idx = seat_index.native
        assert idx < C.SEAT_COUNT, "seat out of range"
        b = ballot.native
        assert b <= C.BALLOT_ABSTAIN, "bad ballot"
        self._require_seat_holder(seat_index, arc4.Address(Txn.sender))

        key = self._key(proposal_id.native, idx)
        assert key not in self.has_voted, "seat already voted"
        self.has_voted[key] = UInt64(1)

        # Forward tally to Sponsio Pactum.
        arc4.abi_call(
            ISponsioPactum.record_vote,
            proposal_id,
            ballot,
            app_id=self.sponsio_app.value,
        )

        # Mint Tessera proof-of-voting NFT to the seat holder.
        tessera = itxn.AssetConfig(
            total=1,
            decimals=0,
            unit_name=b"TESS",
            asset_name=b"Tessera Vote",
            url=b"ipfs://bonafide/tessera",
            manager=Global.zero_address,
            reserve=Global.current_application_address,
            freeze=Global.current_application_address,
            clawback=Global.current_application_address,
            fee=0,
        ).submit()
        tessera_id = tessera.created_asset.id
        itxn.AssetTransfer(
            xfer_asset=tessera_id,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()
        self.tessera_minted.value = self.tessera_minted.value + UInt64(1)
        return arc4.UInt64(tessera_id)

    # -- execution + rotation ----------------------------------------------

    @arc4.abimethod
    def execute(self, proposal_id: arc4.UInt64) -> None:
        """Flag a passed proposal as executed. The actual treasury effects are
        applied in the same atomic group by the executor (Curia authorises the
        treasury account). Here we only flip the lifecycle flag.
        """
        arc4.abi_call(
            ISponsioPactum.mark_executed,
            proposal_id,
            app_id=self.sponsio_app.value,
        )

    @arc4.abimethod
    def rotate_citizen(self, seat_index: arc4.UInt64, new_holder: arc4.Address) -> None:
        """Rotate a Citizen seat via Senatus. Only callable as the result of a
        passed governance proposal; in production the caller is the treasury
        executor acting under a finalized proposal. Curia forwards to Senatus.
        """
        arc4.abi_call(
            ISenatus.rotate_citizen,
            seat_index,
            new_holder,
            app_id=self.senatus_app.value,
        )

    # -- reads --------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def voted(self, proposal_id: arc4.UInt64, seat_index: arc4.UInt64) -> arc4.Bool:
        return arc4.Bool(self._key(proposal_id.native, seat_index.native) in self.has_voted)

    @arc4.abimethod(readonly=True)
    def is_seconded(self, proposal_id: arc4.UInt64) -> arc4.Bool:
        return arc4.Bool(proposal_id.native in self.seconded)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _key(self, proposal_id: UInt64, seat_index: UInt64) -> VoteKey:
        return VoteKey(arc4.UInt64(proposal_id), arc4.UInt64(seat_index))

    @subroutine
    def _require_seat_holder(self, seat_index: arc4.UInt64, who: arc4.Address) -> None:
        holder, _txn = arc4.abi_call(
            ISenatus.holder_of,
            seat_index,
            app_id=self.senatus_app.value,
        )
        assert holder.native == who.native, "caller not seat holder"

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
