# BONAFIDE :: Senatus
# Mints and tracks the 13 governance seats as ASA NFTs. Seat 0 is the
# Convener, seats 1-7 the Counsellors, seats 8-12 the Voting Citizens.
#
# Seats are ASAs of total supply 1, decimals 0. The Senatus app is their
# clawback so it can reassign Citizen seats (8-12) at epoch rotation under
# Curia authority. Convener and Counsellor seats (0-7) have their clawback
# burned to zero address after assignment so they cannot be reassigned.
#
# The valuation of a seat (treasury/13) lives in Tabularium; Senatus only
# tracks seat ownership and class.

from algopy import (
    ARC4Contract,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    itxn,
    BoxMap,
    subroutine,
)

from ..common import constants as C


class Senatus(ARC4Contract):
    def __init__(self) -> None:
        self.curia_app = GlobalState(UInt64(0))
        self.frozen = GlobalState(UInt64(0))
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        self.seats_minted = GlobalState(UInt64(0))
        # seat index (0..12) -> ASA id
        self.seat_asset = BoxMap(UInt64, UInt64, key_prefix=b"s_")
        # seat index -> holder address
        self.seat_holder = BoxMap(UInt64, arc4.Address, key_prefix=b"h_")
        # 1 once seats 0-7 clawback burned (immutable upper house)
        self.upper_house_sealed = GlobalState(UInt64(0))

    # -- configuration ------------------------------------------------------

    @arc4.abimethod
    def set_curia(self, curia_app: arc4.UInt64) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.curia_app.value = curia_app.native

    @arc4.abimethod
    def mint_seat(self, seat_index: arc4.UInt64, holder: arc4.Address) -> arc4.UInt64:
        """Mint one seat NFT and assign it. Callable only pre-freeze by the
        deployer during genesis. Each index 0..12 may be minted exactly once.
        """
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        idx = seat_index.native
        assert idx < C.SEAT_COUNT, "seat out of range"
        assert idx not in self.seat_asset, "seat exists"

        cfg = itxn.AssetConfig(
            total=1,
            decimals=0,
            unit_name=b"SEAT",
            asset_name=b"Senatus Seat",
            url=b"ipfs://bonafide/senatus",
            manager=Global.zero_address,
            reserve=Global.current_application_address,
            freeze=Global.zero_address,
            # clawback retained by app so Citizen seats can rotate;
            # burned for upper house at seal_upper_house().
            clawback=Global.current_application_address,
            fee=0,
        ).submit()
        asset_id = cfg.created_asset.id

        self.seat_asset[idx] = asset_id
        self.seat_holder[idx] = holder
        self.seats_minted.value = self.seats_minted.value + UInt64(1)
        # Transfer the freshly minted unit to the holder (holder must be opted in).
        itxn.AssetTransfer(
            xfer_asset=asset_id,
            asset_receiver=holder.native,
            asset_amount=1,
            fee=0,
        ).submit()
        return arc4.UInt64(asset_id)

    @arc4.abimethod
    def seal_upper_house(self) -> None:
        """Burn clawback on seats 0-7 by reconfiguring them to zero clawback.
        After this the upper house is immutable; only Citizen seats rotate.
        """
        self._only_deployer()
        assert self.seats_minted.value == UInt64(C.SEAT_COUNT), "mint all seats first"
        i = UInt64(C.CONVENER_SEAT)
        while i <= UInt64(C.COUNSELLOR_LAST):
            asset_id = self.seat_asset[i]
            itxn.AssetConfig(
                config_asset=asset_id,
                manager=Global.zero_address,
                reserve=Global.zero_address,
                freeze=Global.zero_address,
                clawback=Global.zero_address,
                fee=0,
            ).submit()
            i = i + UInt64(1)
        self.upper_house_sealed.value = UInt64(1)

    @arc4.abimethod
    def freeze(self) -> None:
        self._only_deployer()
        assert self.upper_house_sealed.value == UInt64(1), "seal upper house first"
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- citizen rotation (Curia only) --------------------------------------

    @arc4.abimethod
    def rotate_citizen(self, seat_index: arc4.UInt64, new_holder: arc4.Address) -> None:
        """Reassign a Citizen seat (8-12). Only Curia may call this, and only
        for Citizen-class seats; upper house is immutable post-seal.
        """
        assert Global.caller_application_id == self.curia_app.value, "not Curia"
        idx = seat_index.native
        assert idx >= C.CITIZEN_FIRST and idx <= C.CITIZEN_LAST, "not a citizen seat"
        asset_id = self.seat_asset[idx]
        old_holder = self.seat_holder[idx].native
        # Clawback the seat from old holder to new holder.
        itxn.AssetTransfer(
            xfer_asset=asset_id,
            asset_sender=old_holder,
            asset_receiver=new_holder.native,
            asset_amount=1,
            fee=0,
        ).submit()
        self.seat_holder[idx] = new_holder

    # -- reads --------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def seat_of(self, seat_index: arc4.UInt64) -> arc4.UInt64:
        return arc4.UInt64(self.seat_asset[seat_index.native])

    @arc4.abimethod(readonly=True)
    def holder_of(self, seat_index: arc4.UInt64) -> arc4.Address:
        return self.seat_holder[seat_index.native]

    @arc4.abimethod(readonly=True)
    def seat_class(self, seat_index: arc4.UInt64) -> arc4.UInt64:
        """0 = convener, 1 = counsellor, 2 = citizen."""
        idx = seat_index.native
        if idx == C.CONVENER_SEAT:
            return arc4.UInt64(0)
        if idx <= C.COUNSELLOR_LAST:
            return arc4.UInt64(1)
        return arc4.UInt64(2)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
