# BONAFIDE :: Tabularium
# The treasury ledger. Holds the canonical list of treasury assets, reads
# their USD prices from Fides, sums to a treasury total, and publishes
# seat_value = treasury_usd / 13. The 13 divisor is a compile-time constant
# and has no setter: seat valuation floats only with treasury value and price,
# never by governance fiat.
#
# Tabularium does not custody the treasury; the treasury account's authority is
# the Curia voting app. Tabularium reads that account's balances and values them.

from algopy import (
    ARC4Contract,
    Asset,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    BoxMap,
    subroutine,
)

from ..common import constants as C
from ..common.interfaces import IFides
from ..common.types import AssetUsd


class Tabularium(ARC4Contract):
    def __init__(self) -> None:
        self.fides_app = GlobalState(UInt64(0))
        self.treasury = GlobalState(arc4.Address(Global.zero_address))
        self.curia_app = GlobalState(UInt64(0))
        self.frozen = GlobalState(UInt64(0))
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        self.asset_count = GlobalState(UInt64(0))
        # index -> asset_id, the iteration order for valuation.
        self.asset_at = BoxMap(UInt64, UInt64, key_prefix=b"a_")
        self.last_treasury_usd = GlobalState(UInt64(0))
        self.last_seat_value = GlobalState(UInt64(0))

    # -- configuration ------------------------------------------------------

    @arc4.abimethod
    def configure(
        self,
        fides_app: arc4.UInt64,
        treasury: arc4.Address,
        curia_app: arc4.UInt64,
    ) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.fides_app.value = fides_app.native
        self.treasury.value = treasury
        self.curia_app.value = curia_app.native

    @arc4.abimethod
    def register_asset(self, asset_id: arc4.UInt64) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        idx = self.asset_count.value
        self.asset_at[idx] = asset_id.native
        self.asset_count.value = idx + UInt64(1)

    @arc4.abimethod
    def freeze(self) -> None:
        self._only_deployer()
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- valuation ----------------------------------------------------------

    @arc4.abimethod
    def revalue(self) -> arc4.UInt64:
        """Recompute treasury_usd and seat_value, persist, return seat_value."""
        total = UInt64(0)
        i = UInt64(0)
        n = self.asset_count.value
        while i < n:
            asset_id = self.asset_at[i]
            held = self._balance(asset_id)
            price = self._fides_price(asset_id)
            # value = held * price / 1e6 (price is USD * 1e6)
            total = total + ((held * price) // UInt64(1_000_000))
            i = i + UInt64(1)
        self.last_treasury_usd.value = total
        seat = total // C.SEAT_COUNT
        self.last_seat_value.value = seat
        return arc4.UInt64(seat)

    @arc4.abimethod(readonly=True)
    def seat_value_usd(self) -> arc4.UInt64:
        return arc4.UInt64(self.last_seat_value.value)

    @arc4.abimethod(readonly=True)
    def treasury_usd(self) -> arc4.UInt64:
        return arc4.UInt64(self.last_treasury_usd.value)

    @arc4.abimethod(readonly=True)
    def line_item(self, index: arc4.UInt64) -> AssetUsd:
        asset_id = self.asset_at[index.native]
        held = self._balance(asset_id)
        price = self._fides_price(asset_id)
        value = (held * price) // UInt64(1_000_000)
        return AssetUsd(
            asset_id=arc4.UInt64(asset_id),
            held_amount=arc4.UInt64(held),
            price_usd_micro=arc4.UInt64(price),
            value_usd_micro=arc4.UInt64(value),
        )

    @arc4.abimethod(readonly=True)
    def asset_total(self) -> arc4.UInt64:
        return arc4.UInt64(self.asset_count.value)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _balance(self, asset_id: UInt64) -> UInt64:
        treasury_acct = self.treasury.value.native
        bal, exists = Asset(asset_id).balance(treasury_acct), True
        return bal

    @subroutine
    def _fides_price(self, asset_id: UInt64) -> UInt64:
        price, _txn = arc4.abi_call(
            IFides.price,
            arc4.UInt64(asset_id),
            app_id=self.fides_app.value,
        )
        return price.native

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
