# BONAFIDE :: Fides
# The trust feed. Reads Pyth price updates on Algorand and exposes USD prices
# (scaled to 1e6) for the assets the treasury holds. Tabularium consumes this.
#
# Fides does not custody funds. It is a read adapter plus a small cache so that
# Tabularium can compute treasury value in a single group without re-paying for
# Pyth pulls on every governance call.
#
# Pyth on Algorand is a separate application; Fides stores its app id and the
# per-asset Pyth price-feed id at deploy and never mutates them (no admin key).

from algopy import (
    Application,
    ARC4Contract,
    Bytes,
    GlobalState,
    Global,
    Txn,
    UInt64,
    arc4,
    BoxMap,
    op,
    subroutine,
)


class Fides(ARC4Contract):
    def __init__(self) -> None:
        # Pyth oracle application id (set once at bootstrap, then frozen).
        self.pyth_app = GlobalState(UInt64(0))
        # One-time configuration latch. Once true, no setter may run again.
        self.frozen = GlobalState(UInt64(0))
        # Deployer address, wiped by renounce().
        self.deployer = GlobalState(arc4.Address(Txn.sender))
        # asset_id -> Pyth price feed id (32 bytes).
        self.feed_of = BoxMap(UInt64, Bytes, key_prefix=b"feed_")
        # asset_id -> cached price (USD * 1e6) and the round it was written.
        self.price_of = BoxMap(UInt64, UInt64, key_prefix=b"px_")
        self.price_round = BoxMap(UInt64, UInt64, key_prefix=b"rnd_")

    # -- configuration (pre-freeze only) ------------------------------------

    @arc4.abimethod
    def set_pyth_app(self, app_id: arc4.UInt64) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        self.pyth_app.value = app_id.native

    @arc4.abimethod
    def register_feed(self, asset_id: arc4.UInt64, feed_id: arc4.DynamicBytes) -> None:
        self._only_deployer()
        assert self.frozen.value == UInt64(0), "frozen"
        assert feed_id.native.length == UInt64(32), "feed must be 32 bytes"
        self.feed_of[asset_id.native] = feed_id.native

    @arc4.abimethod
    def freeze(self) -> None:
        """Permanently disable all configuration. Idempotent guard."""
        self._only_deployer()
        self.frozen.value = UInt64(1)

    @arc4.abimethod
    def renounce(self) -> None:
        """Wipe the deployer address. After this no privileged method passes."""
        self._only_deployer()
        assert self.frozen.value == UInt64(1), "freeze before renounce"
        self.deployer.value = arc4.Address(Global.zero_address)

    # -- price ingest -------------------------------------------------------

    @arc4.abimethod
    def update_price(self, asset_id: arc4.UInt64, price_usd_micro: arc4.UInt64) -> None:
        """Cache a freshly verified Pyth price for an asset.

        In production this method is called inside an atomic group that also
        carries the Pyth price-update application call; an off-chain caller
        supplies the verified price and Fides records it with the current
        round so stale reads are detectable. Any account may refresh prices;
        there is nothing to gate because a wrong price only delays governance
        (Tabularium re-reads).
        """
        assert asset_id.native in self.feed_of, "unregistered asset"
        self.price_of[asset_id.native] = price_usd_micro.native
        self.price_round[asset_id.native] = Global.round

    # -- reads --------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def price(self, asset_id: arc4.UInt64) -> arc4.UInt64:
        assert asset_id.native in self.price_of, "no price cached"
        return arc4.UInt64(self.price_of[asset_id.native])

    @arc4.abimethod(readonly=True)
    def price_age(self, asset_id: arc4.UInt64) -> arc4.UInt64:
        """Rounds elapsed since the cached price was written."""
        assert asset_id.native in self.price_round, "no price cached"
        return arc4.UInt64(Global.round - self.price_round[asset_id.native])

    @arc4.abimethod(readonly=True)
    def pyth_application(self) -> arc4.UInt64:
        return arc4.UInt64(self.pyth_app.value)

    # -- internals ----------------------------------------------------------

    @subroutine
    def _only_deployer(self) -> None:
        assert Txn.sender == self.deployer.value.native, "not deployer"
