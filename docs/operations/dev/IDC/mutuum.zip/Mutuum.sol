// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

import {IERC3156FlashLender} from "./interfaces/IERC3156FlashLender.sol";
import {IERC3156FlashBorrower} from "./interfaces/IERC3156FlashBorrower.sol";
import {IFlashSource} from "./interfaces/IFlashSource.sol";

/// @title MUTUUM — multi-source flash lending facility (DELTAVERSE / IDC)
/// @author Professor Codephreak — BANKON
/// @notice An ERC-3156 flash lender that routes liquidity through pluggable,
///         single-capability sources: the IDC stablecoin (flash-mint), the iDEBT
///         inverse-debt token (flash-mint), and an OHM reserve (treasury-backed).
/// @dev Immutable by construction — no admin keys, no upgradeable proxy. The set of
///      sources and the fee are fixed at deploy. To change them, deploy a new MUTUUM
///      and re-point token mint authority / reserves. Target chain: Moonbeam (GLMR).
///
///      Repayment model (per ERC-3156): the borrower approves THIS contract for
///      `amount + fee`; after the callback, the core pulls that amount into the
///      relevant source and instructs it to settle (burn principal for mint sources,
///      retain principal for reserve sources, forward fee to the treasury in both).
contract Mutuum is IERC3156FlashLender, ReentrancyGuard {
    using SafeERC20 for IERC20;

    /// @notice Required return value of a compliant borrower callback.
    bytes32 public constant CALLBACK_SUCCESS = keccak256("ERC3156FlashBorrower.onFlashLoan");

    /// @notice Basis-points denominator.
    uint256 public constant BPS = 10_000;

    /// @notice Flash fee in basis points, fixed at deploy (e.g. 5 = 0.05%).
    uint256 public immutable feeBps;

    /// @notice token => the source authorised to flash-lend it.
    mapping(address token => IFlashSource source) public sourceOf;

    error UnsupportedToken(address token);
    error AmountExceedsMax(address token, uint256 amount, uint256 max);
    error CallbackFailed();
    error ZeroSource();
    error DuplicateToken(address token);
    error FeeTooHigh(uint256 feeBps);

    event FlashLoan(
        address indexed receiver,
        address indexed initiator,
        address indexed token,
        uint256 amount,
        uint256 fee
    );

    /// @param feeBps_  Flash fee in basis points (hard-capped at 1000 = 10%).
    /// @param sources  The complete, final set of liquidity sources. Each must expose a
    ///                 distinct `asset()`. Order is irrelevant.
    constructor(uint256 feeBps_, IFlashSource[] memory sources) {
        if (feeBps_ > 1_000) revert FeeTooHigh(feeBps_);
        feeBps = feeBps_;

        uint256 len = sources.length;
        for (uint256 i; i < len; ++i) {
            IFlashSource s = sources[i];
            if (address(s) == address(0)) revert ZeroSource();
            address token = s.asset();
            if (address(sourceOf[token]) != address(0)) revert DuplicateToken(token);
            sourceOf[token] = s;
        }
    }

    /// @inheritdoc IERC3156FlashLender
    function maxFlashLoan(address token) external view override returns (uint256) {
        IFlashSource s = sourceOf[token];
        return address(s) == address(0) ? 0 : s.maxFlash();
    }

    /// @inheritdoc IERC3156FlashLender
    function flashFee(address token, uint256 amount) external view override returns (uint256) {
        if (address(sourceOf[token]) == address(0)) revert UnsupportedToken(token);
        return _flashFee(amount);
    }

    /// @inheritdoc IERC3156FlashLender
    function flashLoan(
        IERC3156FlashBorrower receiver,
        address token,
        uint256 amount,
        bytes calldata data
    ) external override nonReentrant returns (bool) {
        IFlashSource src = sourceOf[token];
        if (address(src) == address(0)) revert UnsupportedToken(token);

        uint256 max = src.maxFlash();
        if (amount > max) revert AmountExceedsMax(token, amount, max);

        uint256 fee = _flashFee(amount);

        // 1. Deliver principal to the borrower (mint, or transfer from reserve).
        src.provide(address(receiver), amount);

        // 2. Hand control to the borrower.
        if (
            receiver.onFlashLoan(msg.sender, token, amount, fee, data) != CALLBACK_SUCCESS
        ) {
            revert CallbackFailed();
        }

        // 3. Pull principal + fee from the borrower into the source. Reverts on shortfall
        //    or missing approval, unwinding the whole transaction.
        IERC20(token).safeTransferFrom(address(receiver), address(src), amount + fee);

        // 4. Settle: burn principal (mint source) or retain it (reserve source); fee -> treasury.
        src.settle(amount, fee);

        emit FlashLoan(address(receiver), msg.sender, token, amount, fee);
        return true;
    }

    function _flashFee(uint256 amount) internal view returns (uint256) {
        return (amount * feeBps) / BPS;
    }
}
