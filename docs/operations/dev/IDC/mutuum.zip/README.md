# MUTUUM — Multi-Source Flash Lending for IDC / DELTAVERSE

`(c) 2026 BANKON — all rights reserved · Apache-2.0`

MUTUUM is an [ERC-3156](https://eips.ethereum.org/EIPS/eip-3156) flash lender designed
for the IDC stablecoin and the DELTAVERSE Debt Inheritance Protocol, deployable to
**Moonbeam (GLMR, chain id 1284)**. It routes flash liquidity through pluggable,
single-capability **sources**:

| Source | Token | Model | Liquidity |
|--------|-------|-------|-----------|
| `IDCFlashSource` | IDC stablecoin | flash-**mint** | mint at origination, burn at settlement (supply-neutral) |
| `IDebtFlashSource` | iDEBT (inverse world debt) | flash-**mint** | same; for rebalancing the GlobalCurrencyBasket / DebasementIndex peg |
| `OhmReserveSource` | OHM (bridged on Moonbeam) | **reserve** | transfer from a held reserve, restore on repay — the "if necessary" hard-liquidity path |

The name is the Roman-law contract *mutuum*: a loan of fungible goods repaid in kind —
exactly the semantics of a flash loan, consistent with the BONA FIDE contractual framing.

## Design principles

- **Immutable, no admin keys.** Fee and the full source set are fixed in the MUTUUM
  constructor. There are no setters, no owner, no pause, no upgradeable proxy. To change
  the fee or add a source, deploy a new MUTUUM and re-point token mint authority /
  reserves. This is the deliberate `no admin keys post-deploy` / `no upgradeable proxies`
  posture — the opposite of Aave's governance-upgradeable Pool proxy.
- **Least privilege per source.** Each source holds exactly one capability for exactly
  one token. Granting IDC mint rights exposes only a tiny audited adapter, never a router.
- **Single reentrancy gate.** `flashLoan` is `nonReentrant`; sources accept calls only
  from the immutable `core`, so a borrower cannot re-enter mid-callback.
- **ERC-3156 standard.** Any compliant borrower/aggregator interoperates; the borrower
  approves MUTUUM for `amount + fee` and returns the canonical callback hash.

## Repayment flow

```
flashLoan(receiver, token, amount, data)
  ├─ src.provide(receiver, amount)              // mint, or transfer from reserve
  ├─ receiver.onFlashLoan(...) == CALLBACK_OK   // borrower runs strategy
  ├─ token.transferFrom(receiver, src, amount+fee)   // pull principal + fee (needs approval)
  └─ src.settle(amount, fee)                    // mint src: burn principal, fee→treasury
                                                // reserve src: keep principal, fee→treasury
```

For mint sources, principal mint and burn net to zero; the fee is paid from the
borrower's *pre-existing* tokens and accrues to the Aerarium treasury as real value.
Borrowers must therefore hold the fee before the call (flash loans lend principal, not
the fee).

## Layout

```
src/
  Mutuum.sol                     # ERC-3156 core, multi-source router
  interfaces/
    IERC3156FlashLender.sol
    IERC3156FlashBorrower.sol
    IFlashSource.sol             # internal source abstraction
    IFlashMintable.sol           # mint/burn surface for protocol tokens
  sources/
    FlashSourceBase.sol          # immutable core/asset/treasury/ceiling + onlyCore
    MintFlashSource.sol          # flash-mint adapter
    ReserveFlashSource.sol       # reserve-backed adapter
    IDCFlashSource.sol           # named: IDC
    IDebtFlashSource.sol         # named: iDEBT
    OhmReserveSource.sol         # named: OHM
  examples/
    MutuumBorrowerExample.sol    # safe borrower template
test/
  Mutuum.t.sol                   # full suite incl. reentrancy, supply-neutrality, reverts
  mocks/
script/
  DeployMutuum.s.sol             # Moonbeam deploy, immutable wiring
```

## Build & test

```bash
forge install OpenZeppelin/openzeppelin-contracts foundry-rs/forge-std
forge build
forge test -vvv
```

> The core `src/` tree and mocks were compile-verified with solc 0.8.26 (paris,
> optimizer 200) — 0 errors, 0 warnings, deployable bytecode for every contract. The
> `test/` and `script/` files depend on `forge-std`; run `forge test` in your toolchain.

## Deploy to Moonbeam (GLMR)

```bash
cp .env.example .env   # fill IDC_TOKEN, IDEBT_TOKEN, OHM_TOKEN, AERARIUM_TREASURY, RPC, key
forge script script/DeployMutuum.s.sol:DeployMutuum \
  --rpc-url moonbeam --broadcast --verify
```

Then, by the respective token owners (MUTUUM itself holds no admin keys):

1. Grant the printed `IDCFlashSource` mint + self-burn authority on the IDC token.
2. Grant the printed `IDebtFlashSource` mint + self-burn authority on iDEBT.
3. Fund the printed `OhmReserveSource` with an OHM reserve.

## IDC integration

IDC participates by granting `IDCFlashSource` its mint/burn role; MUTUUM is then IDC's
ERC-3156 flash lender. To make the IDC token itself present an ERC-3156 facade, add a
thin view that forwards `maxFlashLoan`/`flashFee`/`flashLoan` to the deployed MUTUUM —
no token storage changes required.

## Notes / caveats

- `evm_version = paris` is a conservative Moonbeam-safe floor; raise to shanghai/cancun
  only after confirming the live GLMR runtime enables those opcodes.
- The mint `ceiling` bounds systemic exposure per loan; size it against IDC/iDEBT
  monetary policy, not arbitrarily high.
- Fee is hard-capped at 10% (1000 bps) in the constructor as a sanity bound.
- Wrap the deploy + role-granting in the DAIO Boardroom timelock if you want governance
  to authorise the mint-role grant rather than an EOA.
- This is unaudited code. Get an external review before mainnet value flows through it.
