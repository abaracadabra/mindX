// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {Script, console2} from "forge-std/Script.sol";
import {BANKONPythai} from "src/BANKONPythai.sol";

/// @title  Deploy BANKON PYTHAI
/// @notice One script, multiple chains. Toggle MINT_CANONICAL via env on the canonical chain only.
/// @dev    Run with:
///           forge script script/Deploy.s.sol:Deploy --rpc-url $RPC --broadcast --verify
///         Required env:
///           PRIVATE_KEY       deployer private key (use a hardware wallet via --ledger in prod)
///           LZ_ENDPOINT       LayerZero EndpointV2 for the target chain
///           INITIAL_OWNER     multisig or timelock address; never an EOA in production
///           MINT_CANONICAL    "true" only on the canonical chain, "false" everywhere else
contract Deploy is Script {
    /// @notice EndpointV2 is the same address on most major EVMs by LayerZero design.
    /// @dev    Verify per-chain at https://docs.layerzero.network/v2/deployments/deployed-contracts.
    address public constant LZ_ENDPOINT_V2_DEFAULT = 0x1a44076050125825900e736c501f859c50fE728c;

    function run() external returns (BANKONPythai token) {
        uint256 deployerPk = vm.envUint("PRIVATE_KEY");
        address lzEndpoint = vm.envOr("LZ_ENDPOINT", LZ_ENDPOINT_V2_DEFAULT);
        address initialOwner = vm.envAddress("INITIAL_OWNER");
        bool mintCanonical = vm.envOr("MINT_CANONICAL", false);

        require(initialOwner != address(0), "INITIAL_OWNER unset");
        require(initialOwner.code.length > 0 || _allowEoa(), "INITIAL_OWNER must be a contract (multisig/timelock)");

        vm.startBroadcast(deployerPk);

        token = new BANKONPythai(lzEndpoint, initialOwner, mintCanonical);

        vm.stopBroadcast();

        console2.log("=== BANKON PYTHAI deployed ===");
        console2.log("address       :", address(token));
        console2.log("lz endpoint   :", lzEndpoint);
        console2.log("initial owner :", initialOwner);
        console2.log("is canonical  :", mintCanonical);
        console2.log("name          :", token.name());
        console2.log("symbol        :", token.symbol());
        console2.log("decimals      :", token.decimals());
        console2.log("totalSupply   :", token.totalSupply());
        console2.log("==============================");
        console2.log("Next steps:");
        console2.log("  1. Repeat deployment on every target chain with MINT_CANONICAL=false");
        console2.log("  2. On each chain call setPeer(eid, bytes32(uint256(uint160(addr))))");
        console2.log("     to wire the OFT mesh");
        console2.log("  3. Optionally set enforced options via setEnforcedOptions(...)");
        console2.log("  4. After full mesh verification, call renounceOwnership() or");
        console2.log("     transferOwnership(timelock) on every chain");
    }

    /// @dev Allow EOA owner only on testnets. Override by setting ALLOW_EOA_OWNER=true.
    function _allowEoa() internal view returns (bool) {
        return vm.envOr("ALLOW_EOA_OWNER", false);
    }
}
