// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {Test, console2} from "forge-std/Test.sol";
import {BANKONPythai} from "src/BANKONPythai.sol";
import {EndpointV2Mock} from "@layerzerolabs/oft-evm/test/mocks/EndpointV2Mock.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {IERC20Errors} from "@openzeppelin/contracts/interfaces/draft-IERC6093.sol";

/// @notice Unit tests for BANKON PYTHAI token. All tests run against a mock LayerZero endpoint
///         so they do not require a forked network. Cross-chain mesh tests live separately
///         under test/integration/Mesh.t.sol (requires --fork-url).
contract BANKONPythaiTest is Test {
    BANKONPythai internal token;
    EndpointV2Mock internal endpoint;

    address internal owner   = makeAddr("owner");
    address internal alice   = makeAddr("alice");
    address internal bob     = makeAddr("bob");
    address internal mallory = makeAddr("mallory");

    uint32 internal constant LOCAL_EID = 1;

    function setUp() public {
        endpoint = new EndpointV2Mock(LOCAL_EID);
        token = new BANKONPythai(address(endpoint), owner, true);
    }

    /*//////////////////////////////////////////////////////////////
                          METADATA & SUPPLY
    //////////////////////////////////////////////////////////////*/

    function test_metadata() public view {
        assertEq(token.name(), "BANKON");
        assertEq(token.symbol(), "PYTHAI");
        assertEq(token.decimals(), 18);
    }

    function test_canonicalSupplyValue() public pure {
        // 111111.111111111111111111 PYTHAI at 18 decimals == 24 ones in raw wei
        assertEq(
            BANKONPythai.CANONICAL_SUPPLY,
            111_111_111_111_111_111_111_111
        );
    }

    function test_supplyMintedToOwnerOnCanonicalChain() public view {
        assertEq(token.totalSupply(), BANKONPythai.CANONICAL_SUPPLY);
        assertEq(token.balanceOf(owner), BANKONPythai.CANONICAL_SUPPLY);
        assertTrue(token.IS_CANONICAL_CHAIN());
    }

    function test_supplyZeroOnNonCanonicalChain() public {
        BANKONPythai remote = new BANKONPythai(address(endpoint), owner, false);
        assertEq(remote.totalSupply(), 0);
        assertEq(remote.balanceOf(owner), 0);
        assertFalse(remote.IS_CANONICAL_CHAIN());
    }

    function test_humanReadableSupplyMatchesRawValue() public view {
        assertEq(
            keccak256(bytes(token.CANONICAL_SUPPLY_HUMAN())),
            keccak256(bytes("111111.111111111111111111"))
        );
    }

    /*//////////////////////////////////////////////////////////////
                          CONSTRUCTOR GUARDS
    //////////////////////////////////////////////////////////////*/

    function test_revertOnZeroEndpoint() public {
        vm.expectRevert(BANKONPythai.ZeroAddress.selector);
        new BANKONPythai(address(0), owner, true);
    }

    function test_revertOnZeroOwner() public {
        vm.expectRevert(BANKONPythai.ZeroAddress.selector);
        new BANKONPythai(address(endpoint), address(0), true);
    }

    /*//////////////////////////////////////////////////////////////
                          OWNERSHIP & RENOUNCE
    //////////////////////////////////////////////////////////////*/

    function test_ownerIsInitialOwner() public view {
        assertEq(token.owner(), owner);
    }

    function test_onlyOwnerCanSetPeer() public {
        vm.prank(mallory);
        vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, mallory));
        token.setPeer(2, bytes32(uint256(uint160(makeAddr("remote")))));
    }

    function test_ownerCanSetPeer() public {
        bytes32 peer = bytes32(uint256(uint160(makeAddr("remote"))));
        vm.prank(owner);
        token.setPeer(2, peer);
        assertEq(token.peers(2), peer);
    }

    function test_renounceOwnership() public {
        vm.prank(owner);
        token.renounceOwnership();
        assertEq(token.owner(), address(0));

        // After renounce, no one can configure new peers.
        vm.prank(owner);
        vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, owner));
        token.setPeer(2, bytes32(uint256(uint160(makeAddr("remote")))));
    }

    function test_transferOwnershipToTimelock() public {
        address timelock = makeAddr("timelock");
        vm.prank(owner);
        token.transferOwnership(timelock);
        assertEq(token.owner(), timelock);
    }

    /*//////////////////////////////////////////////////////////////
                          ERC20 BEHAVIOR
    //////////////////////////////////////////////////////////////*/

    function test_transfer() public {
        uint256 amount = 1_000 ether;
        vm.prank(owner);
        token.transfer(alice, amount);
        assertEq(token.balanceOf(alice), amount);
        assertEq(token.balanceOf(owner), BANKONPythai.CANONICAL_SUPPLY - amount);
    }

    function test_transferFromWithApproval() public {
        uint256 amount = 500 ether;
        vm.prank(owner);
        token.approve(alice, amount);

        vm.prank(alice);
        token.transferFrom(owner, bob, amount);
        assertEq(token.balanceOf(bob), amount);
    }

    function test_transferRevertsOnInsufficient() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(
                IERC20Errors.ERC20InsufficientBalance.selector,
                alice,
                0,
                1
            )
        );
        token.transfer(bob, 1);
    }

    function testFuzz_transferPreservesTotalSupply(uint256 amount) public {
        amount = bound(amount, 0, BANKONPythai.CANONICAL_SUPPLY);
        uint256 supplyBefore = token.totalSupply();
        vm.prank(owner);
        token.transfer(alice, amount);
        assertEq(token.totalSupply(), supplyBefore);
    }

    /*//////////////////////////////////////////////////////////////
                          ERC20 PERMIT (EIP-2612)
    //////////////////////////////////////////////////////////////*/

    function test_permit() public {
        uint256 holderPk = 0xA11CE;
        address holder = vm.addr(holderPk);

        // Seed holder with tokens
        vm.prank(owner);
        token.transfer(holder, 1_000 ether);

        uint256 nonce = token.nonces(holder);
        uint256 deadline = block.timestamp + 1 hours;
        uint256 value = 500 ether;

        bytes32 structHash = keccak256(
            abi.encode(
                keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)"),
                holder,
                bob,
                value,
                nonce,
                deadline
            )
        );
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", token.DOMAIN_SEPARATOR(), structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(holderPk, digest);

        token.permit(holder, bob, value, deadline, v, r, s);

        assertEq(token.allowance(holder, bob), value);
        assertEq(token.nonces(holder), nonce + 1);
    }

    /*//////////////////////////////////////////////////////////////
                          INVARIANTS
    //////////////////////////////////////////////////////////////*/

    /// @notice Pure non-canonical chains can never mint without an OFT receive from a peer.
    ///         Verified by the absence of any public mint function on the contract.
    function test_noPublicMintFunction() public view {
        // If anyone adds a public mint() in the future, this test must be updated and
        // an audit must be re-run. The current ABI exposes no such function.
        bytes4 mintSelector = bytes4(keccak256("mint(address,uint256)"));
        (bool success, ) = address(token).staticcall(abi.encodeWithSelector(mintSelector, alice, 1));
        assertFalse(success, "Token must not expose a public mint() function");
    }
}
