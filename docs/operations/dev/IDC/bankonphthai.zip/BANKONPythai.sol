// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {OFT} from "@layerzerolabs/oft-evm/contracts/OFT.sol";
import {
    SendParam,
    MessagingFee,
    MessagingReceipt,
    OFTReceipt
} from "@layerzerolabs/oft-evm/contracts/interfaces/IOFT.sol";
import {ERC20Permit, ERC20} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import {Nonces} from "@openzeppelin/contracts/utils/Nonces.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @title  BANKON PYTHAI - Omnichain Fixed-Supply Reserve Token
/// @author codephreak (PYTHAI / DELTAVERSE)
/// @notice Fixed total supply of 111,111.111111111111111111 PYTHAI (24 ones at 18 decimals).
///         Native cross-chain transfers via LayerZero OFT V2; canonical mint on a single chain,
///         all other chains receive supply through burn-on-source / mint-on-destination.
/// @dev    Inheritance order is deliberate:
///           - OFT          : ERC20 + LayerZero OApp + Ownable (renounceable)
///           - ERC20Permit  : EIP-2612 gasless approvals + Nonces
///           - ReentrancyGuard : defense-in-depth on cross-chain entrypoints
///         OZ v5's diamond pattern is resolved via the explicit `nonces` override below.
contract BANKONPythai is OFT, ERC20Permit, ReentrancyGuard {
    /*//////////////////////////////////////////////////////////////
                              CONSTANTS
    //////////////////////////////////////////////////////////////*/

    /// @notice Canonical mint, expressed in raw wei units (18 decimals).
    /// @dev    111_111_111_111_111_111_111_111 wei == 111111.111111111111111111 PYTHAI.
    ///         This is the global supply ceiling; never minted again on any chain after
    ///         constructor execution on the canonical chain.
    uint256 public constant CANONICAL_SUPPLY = 111_111_111_111_111_111_111_111;

    /// @notice Human-readable supply for off-chain tooling and dashboards.
    string public constant CANONICAL_SUPPLY_HUMAN = "111111.111111111111111111";

    /*//////////////////////////////////////////////////////////////
                              IMMUTABLES
    //////////////////////////////////////////////////////////////*/

    /// @notice True only on the chain where the canonical mint was performed.
    ///         Every other chain starts at zero supply and acquires it via OFT receives.
    bool public immutable IS_CANONICAL_CHAIN;

    /*//////////////////////////////////////////////////////////////
                                ERRORS
    //////////////////////////////////////////////////////////////*/

    error ZeroAddress();

    /*//////////////////////////////////////////////////////////////
                              CONSTRUCTOR
    //////////////////////////////////////////////////////////////*/

    /// @param _lzEndpoint           LayerZero EndpointV2 for the deployment chain.
    ///                              On most EVM chains this is 0x1a44076050125825900e736c501f859c50fE728c.
    /// @param _initialOwner         Receives ownership and (on the canonical chain) the full supply.
    ///                              MUST be a multisig or timelock before renouncing.
    /// @param _mintCanonicalSupply  Pass `true` on exactly ONE chain across the entire deployment.
    ///                              On all other chains pass `false`; supply arrives via OFT receive.
    constructor(
        address _lzEndpoint,
        address _initialOwner,
        bool _mintCanonicalSupply
    )
        OFT("BANKON", "PYTHAI", _lzEndpoint, _initialOwner)
        ERC20Permit("BANKON")
    {
        if (_lzEndpoint == address(0)) revert ZeroAddress();
        if (_initialOwner == address(0)) revert ZeroAddress();

        IS_CANONICAL_CHAIN = _mintCanonicalSupply;

        if (_mintCanonicalSupply) {
            _mint(_initialOwner, CANONICAL_SUPPLY);
        }
    }

    /*//////////////////////////////////////////////////////////////
                          REQUIRED OVERRIDES
    //////////////////////////////////////////////////////////////*/

    /// @inheritdoc ERC20Permit
    function nonces(address owner_)
        public
        view
        override(ERC20Permit, Nonces)
        returns (uint256)
    {
        return super.nonces(owner_);
    }

    /*//////////////////////////////////////////////////////////////
                     REENTRANCY HARDENING (CROSS-CHAIN)
    //////////////////////////////////////////////////////////////*/

    /// @notice Cross-chain send with reentrancy guard.
    /// @dev    The underlying OFT._debit() burns the caller's tokens BEFORE the external
    ///         endpoint call, so this is defense-in-depth rather than a strict requirement.
    ///         We still apply nonReentrant because the endpoint call routes through
    ///         user-controllable executor and DVN paths that could in principle re-enter
    ///         a future composer hook in the same transaction.
    function send(
        SendParam calldata _sendParam,
        MessagingFee calldata _fee,
        address _refundAddress
    )
        external
        payable
        virtual
        override
        nonReentrant
        returns (MessagingReceipt memory msgReceipt, OFTReceipt memory oftReceipt)
    {
        return super.send(_sendParam, _fee, _refundAddress);
    }
}
