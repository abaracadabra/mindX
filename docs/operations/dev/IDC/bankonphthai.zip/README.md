# BANKON PYTHAI

Omnichain fixed-supply ERC20 reserve token for the PYTHAI / DELTAVERSE ecosystem. Native cross-chain transfers via LayerZero OFT V2, EIP-2612 gasless approvals, ReentrancyGuard-hardened cross-chain send path, and renounceable ownership.

## Token Specification

The token name is `BANKON` and the symbol is `PYTHAI`. The decimals value is 18, matching standard ERC20 convention and the LayerZero OFT shared-decimals rail. The canonical total supply is exactly `111111.111111111111111111` PYTHAI, which resolves to `111_111_111_111_111_111_111_111` in raw wei units — twenty-four consecutive ones at 18 decimals. This supply is minted exactly once, on a single canonical chain, during constructor execution; on every other chain the contract is deployed with zero local supply and acquires balance only through legitimate LayerZero OFT receive operations from a configured peer. Because LayerZero OFT burns on the source chain before minting on the destination chain, the global supply summed across every chain in the mesh is invariant and equal to `CANONICAL_SUPPLY` at all times.

## Architecture

The contract inherits from three bases in a deliberate order. The first is LayerZero's `OFT`, which itself extends OpenZeppelin's `ERC20` and the LayerZero `OApp` stack, providing the cross-chain `send` / `_lzReceive` machinery and a renounceable `Ownable` for peer configuration. The second is OpenZeppelin's `ERC20Permit`, adding EIP-2612 signature-based approvals and a `Nonces` registry so users can authorize spenders without paying gas for an approve transaction. The third is OpenZeppelin's `ReentrancyGuard`, which we apply to the cross-chain `send` entrypoint as defense-in-depth; while the underlying OFT implementation already burns tokens before the external endpoint call, the executor and DVN paths LayerZero routes through are user-influenced, and a future composer hook could in principle re-enter, so the guard is appropriate.

The diamond inheritance between `OFT.ERC20` and `ERC20Permit.ERC20` is resolved by Solidity's C3 linearization, with one explicit override required on the `nonces(address)` function so that both `ERC20Permit` and `Nonces` route through `super`.

## Ownership Lifecycle

Ownership is held initially by the address passed as `_initialOwner` to the constructor. This address must be a multisig wallet or a timelock contract in production; the deployment script enforces this by requiring `initialOwner.code.length > 0` unless the `ALLOW_EOA_OWNER` environment flag is set, which is intended only for testnets. The owner is the LayerZero delegate and the only address that can call `setPeer` to wire the OFT mesh, `setEnforcedOptions` to configure cross-chain execution parameters, and the standard `Ownable.transferOwnership` and `Ownable.renounceOwnership` functions.

The recommended operational flow is to deploy the canonical instance first with `MINT_CANONICAL=true`, then deploy non-canonical instances on every other target chain with `MINT_CANONICAL=false`. Once every contract is deployed, the owner calls `setPeer` on each chain to register every other chain's contract address, encoded as `bytes32(uint256(uint160(remoteAddress)))`. After the full mesh has been verified end-to-end with small test transfers, the owner either calls `renounceOwnership` to permanently lock the configuration, or calls `transferOwnership` to a timelock that gates any future changes behind a delay. Renouncing before completing the mesh is irreversible and would leave the token unable to add new chains, so the order matters.

## Cross-Chain Model

LayerZero OFT V2 implements native cross-chain transfers without a separate bridge contract or wrapped token. When a holder calls `send` on the source chain, the contract burns the specified amount from their balance, dispatches a `MessagingPacket` to the configured peer on the destination chain through the LayerZero EndpointV2, and on arrival the peer contract mints the equivalent amount to the recipient. Because this is the same contract bytecode on both sides — distinguished only by chain ID and the `IS_CANONICAL_CHAIN` immutable — the token is fungible across the entire mesh and no manual peg maintenance is required.

The EndpointV2 address is `0x1a44076050125825900e736c501f859c50fE728c` on Ethereum, Arbitrum, Optimism, Polygon, Base, and most other major EVM chains by LayerZero's deliberate design; the deployment script defaults to this value but accepts an `LZ_ENDPOINT` override for chains where it differs. The canonical authoritative list lives at `docs.layerzero.network/v2/deployments/deployed-contracts` and should be checked before any production deployment.

## Reentrancy Protection

Standard ERC20 transfer paths in OpenZeppelin v5 perform no external calls and therefore require no reentrancy guard. The `send` function does perform an external call to the LayerZero endpoint after debiting the caller's balance, and while the strict check-effects-interactions ordering in the LayerZero implementation makes a re-entry exploit difficult, we still apply `nonReentrant` to `send` for two reasons. First, the LayerZero endpoint dispatches messages through user-configurable DVN and executor contracts, which are external code paths outside the OFT contract's audit boundary. Second, future composer hooks in the LayerZero V2 architecture allow callbacks during message delivery, and a defensive guard now avoids a future migration risk.

## Deployment

The deployment requires Foundry and the following environment variables: `PRIVATE_KEY` for the deployer (use a hardware wallet via `--ledger` in production), `LZ_ENDPOINT` for the target chain's LayerZero EndpointV2, `INITIAL_OWNER` set to a multisig or timelock address, and `MINT_CANONICAL` set to `true` on exactly one chain and `false` everywhere else. The deployment command is `forge script script/Deploy.s.sol:Deploy --rpc-url $RPC --broadcast --verify`, repeated once per chain.

After the per-chain deployments complete, the owner connects the mesh by calling `setPeer(remoteEid, bytes32(uint256(uint160(remoteAddress))))` on each chain for every other chain. The LayerZero endpoint IDs for major chains are 30101 for Ethereum, 30110 for Arbitrum, 30111 for Optimism, 30109 for Polygon, and 30184 for Base; the full list is maintained at `docs.layerzero.network/v2/deployments/deployed-endpoints`. Optionally the owner can call `setEnforcedOptions` to require minimum gas budgets for destination execution, which prevents users from underpaying and stranding messages.

## Testing

The test suite under `test/BANKONPythai.t.sol` covers metadata, supply correctness on canonical and non-canonical chains, constructor zero-address reverts, ownership and renounce semantics, ERC20 transfer and allowance behavior, EIP-2612 permit signing, fuzz invariants over total supply preservation, and a sanity check that no public `mint` function is exposed on the contract ABI. Run the suite with `forge test -vvv`. Integration tests against a forked mainnet, including LayerZero mesh wiring with the live endpoint, belong in a separate `test/integration/` directory and require the `MAINNET_RPC_URL` environment variable.

## Security Considerations

The contract is fixed-supply with no public or owner-callable mint function; supply can only enter circulation through the constructor on the canonical chain or through legitimate OFT receives from a configured peer. The owner cannot mint, cannot pause transfers, cannot blacklist addresses, and cannot upgrade the contract — the only owner privileges are LayerZero peer configuration, enforced options, and standard `Ownable` transfer or renouncement. There is no proxy, no upgradeability, and no admin escape hatch.

The cross-chain trust model inherits LayerZero's: the security of any given transfer depends on the DVN configuration the contract uses on each route, which is set at the OApp level and inherited from the LayerZero defaults unless explicitly overridden. Users sending across chains assume the security of the LayerZero protocol, the DVN set, and the executor. Holders who never bridge are unaffected by these assumptions and rely only on the standard ERC20 security properties of the local contract.

Before launching with `renounceOwnership`, operators should verify that every intended chain has been deployed, every peer has been wired, every enforced option has been set, and end-to-end test transfers have completed in both directions on every route. After renouncement, none of these can be changed.

## License

Apache-2.0. All source files carry the SPDX header `// SPDX-License-Identifier: Apache-2.0` and the `BANKON 2026` attribution line. The contract has no third-party proprietary dependencies; OpenZeppelin Contracts is MIT-licensed, and LayerZero OFT EVM is MIT-licensed, both of which are compatible with the Apache-2.0 license under which this project is released.
