// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IAlgebraPositionManager, IAlgebraPool} from "src/interfaces/IAlgebra.sol";

/// @title  AlgebraLocker - BANKON PYTHAI Liquidity Position Locker for Algebra V3 DEXes
/// @author codephreak (PYTHAI / DELTAVERSE)
/// @notice Parallel implementation of UniswapV3Locker for Algebra Integral pools.
///         Used on QuickSwap V3 (Polygon), StellaSwap V3 (Moonbeam), and Camelot V3
///         (Arbitrum). Identical security model: immutable pool binding, on-deposit
///         verification, time-locked custody, permissionless fee collection.
/// @dev    Algebra pools differ from Uniswap V3 pools in two ways: positions() omits
///         the `fee` field because Algebra uses dynamic fees, and the slot0-equivalent
///         is named globalState(). The locker abstracts these differences while
///         preserving the same external interface as UniswapV3Locker.
contract AlgebraLocker is ReentrancyGuard {
    /*//////////////////////////////////////////////////////////////
                            IMMUTABLE BINDINGS
    //////////////////////////////////////////////////////////////*/

    IAlgebraPositionManager public immutable POSITION_MANAGER;
    IAlgebraPool            public immutable POOL;
    address                 public immutable TOKEN0;
    address                 public immutable TOKEN1;
    address                 public immutable TREASURY;

    uint256 public constant MAX_LOCK_DURATION = 365 days * 10;
    uint256 public constant MIN_LOCK_DURATION = 30 days;

    /*//////////////////////////////////////////////////////////////
                              LOCK STATE
    //////////////////////////////////////////////////////////////*/

    struct Lock {
        uint40  unlockAt;
        uint40  depositedAt;
        uint128 liquidityAtDeposit;
        int24   tickLowerAtDeposit;
        int24   tickUpperAtDeposit;
        bool    active;
    }

    mapping(uint256 tokenId => Lock) public locks;
    uint256[] private _lockedTokenIds;
    mapping(uint256 tokenId => uint256 index) private _lockedTokenIndex;

    /*//////////////////////////////////////////////////////////////
                                EVENTS
    //////////////////////////////////////////////////////////////*/

    event PositionLocked(
        uint256 indexed tokenId,
        uint40  unlockAt,
        uint128 liquidity,
        int24   tickLower,
        int24   tickUpper
    );
    event FeesCollected(uint256 indexed tokenId, uint256 amount0, uint256 amount1);
    event PositionReleased(uint256 indexed tokenId, address indexed recipient);

    /*//////////////////////////////////////////////////////////////
                                ERRORS
    //////////////////////////////////////////////////////////////*/

    error ZeroAddress();
    error TokensNotSorted();
    error WrongPool(address t0, address t1);
    error EmptyPosition();
    error LockDurationOutOfRange();
    error PositionNotLocked();
    error LockNotExpired(uint256 unlockAt, uint256 nowAt);
    error AlreadyLocked();

    /*//////////////////////////////////////////////////////////////
                              CONSTRUCTOR
    //////////////////////////////////////////////////////////////*/

    constructor(address positionManager, address pool, address treasury) {
        if (positionManager == address(0) || pool == address(0) || treasury == address(0)) {
            revert ZeroAddress();
        }

        POSITION_MANAGER = IAlgebraPositionManager(positionManager);
        POOL             = IAlgebraPool(pool);
        TREASURY         = treasury;

        address t0 = IAlgebraPool(pool).token0();
        address t1 = IAlgebraPool(pool).token1();
        if (t0 >= t1) revert TokensNotSorted();

        TOKEN0 = t0;
        TOKEN1 = t1;
    }

    /*//////////////////////////////////////////////////////////////
                                DEPOSIT
    //////////////////////////////////////////////////////////////*/

    function deposit(uint256 tokenId, uint256 lockDuration) external nonReentrant {
        if (lockDuration < MIN_LOCK_DURATION || lockDuration > MAX_LOCK_DURATION) {
            revert LockDurationOutOfRange();
        }
        if (locks[tokenId].active) revert AlreadyLocked();

        (
            ,                      // nonce
            ,                      // operator
            address t0,
            address t1,
            int24   tickLower,
            int24   tickUpper,
            uint128 liquidity,
            ,                      // feeGrowthInside0LastX128
            ,                      // feeGrowthInside1LastX128
            ,                      // tokensOwed0
                                   // tokensOwed1
        ) = POSITION_MANAGER.positions(tokenId);

        if (t0 != TOKEN0 || t1 != TOKEN1) revert WrongPool(t0, t1);
        if (liquidity == 0) revert EmptyPosition();

        uint40 unlockAt = uint40(block.timestamp + lockDuration);
        locks[tokenId] = Lock({
            unlockAt:           unlockAt,
            depositedAt:        uint40(block.timestamp),
            liquidityAtDeposit: liquidity,
            tickLowerAtDeposit: tickLower,
            tickUpperAtDeposit: tickUpper,
            active:             true
        });
        _lockedTokenIndex[tokenId] = _lockedTokenIds.length;
        _lockedTokenIds.push(tokenId);

        POSITION_MANAGER.transferFrom(msg.sender, address(this), tokenId);

        emit PositionLocked(tokenId, unlockAt, liquidity, tickLower, tickUpper);
    }

    /*//////////////////////////////////////////////////////////////
                            FEE COLLECTION
    //////////////////////////////////////////////////////////////*/

    function collectFees(uint256 tokenId)
        external
        nonReentrant
        returns (uint256 amount0, uint256 amount1)
    {
        if (!locks[tokenId].active) revert PositionNotLocked();

        (amount0, amount1) = POSITION_MANAGER.collect(
            IAlgebraPositionManager.CollectParams({
                tokenId:    tokenId,
                recipient:  TREASURY,
                amount0Max: type(uint128).max,
                amount1Max: type(uint128).max
            })
        );

        emit FeesCollected(tokenId, amount0, amount1);
    }

    function collectFeesBatch(uint256[] calldata tokenIds) external nonReentrant {
        uint256 len = tokenIds.length;
        for (uint256 i; i < len; ) {
            uint256 id = tokenIds[i];
            if (!locks[id].active) revert PositionNotLocked();

            (uint256 a0, uint256 a1) = POSITION_MANAGER.collect(
                IAlgebraPositionManager.CollectParams({
                    tokenId:    id,
                    recipient:  TREASURY,
                    amount0Max: type(uint128).max,
                    amount1Max: type(uint128).max
                })
            );

            emit FeesCollected(id, a0, a1);
            unchecked { ++i; }
        }
    }

    /*//////////////////////////////////////////////////////////////
                              WITHDRAWAL
    //////////////////////////////////////////////////////////////*/

    function withdraw(uint256 tokenId) external nonReentrant {
        Lock memory lock_ = locks[tokenId];
        if (!lock_.active) revert PositionNotLocked();
        if (block.timestamp < lock_.unlockAt) {
            revert LockNotExpired(lock_.unlockAt, block.timestamp);
        }

        locks[tokenId].active = false;
        _removeTokenFromIndex(tokenId);

        POSITION_MANAGER.transferFrom(address(this), TREASURY, tokenId);

        emit PositionReleased(tokenId, TREASURY);
    }

    function _removeTokenFromIndex(uint256 tokenId) internal {
        uint256 index = _lockedTokenIndex[tokenId];
        uint256 lastIndex = _lockedTokenIds.length - 1;
        if (index != lastIndex) {
            uint256 lastTokenId = _lockedTokenIds[lastIndex];
            _lockedTokenIds[index] = lastTokenId;
            _lockedTokenIndex[lastTokenId] = index;
        }
        _lockedTokenIds.pop();
        delete _lockedTokenIndex[tokenId];
    }

    /*//////////////////////////////////////////////////////////////
                          PRICE VIEW FUNCTIONS
    //////////////////////////////////////////////////////////////*/

    /// @notice Current spot sqrt-price of the bound Algebra pool, scaled by 2^96.
    function currentSqrtPriceX96() external view returns (uint160 price) {
        (price,,,,,,) = POOL.globalState();
    }

    /// @notice Current spot tick of the bound pool.
    function currentTick() external view returns (int24 tick) {
        (, tick,,,,,) = POOL.globalState();
    }

    /// @notice Current dynamic fee of the bound pool, expressed in hundredths of a bip.
    /// @dev    Algebra fees are not fixed; this returns the live value as of the last
    ///         observation update.
    function currentFee() external view returns (uint16) {
        (,, uint16 fee,,,,) = POOL.globalState();
        return fee;
    }

    function poolLiquidity() external view returns (uint128) {
        return POOL.liquidity();
    }

    /// @notice Time-weighted average tick over the last `window` seconds.
    function twapTick(uint32 window) external view returns (int24) {
        require(window > 0, "window=0");

        uint32[] memory secondsAgos = new uint32[](2);
        secondsAgos[0] = window;
        secondsAgos[1] = 0;

        (int56[] memory tickCumulatives,,,) = POOL.getTimepoints(secondsAgos);
        int56 delta = tickCumulatives[1] - tickCumulatives[0];
        int24 t = int24(delta / int56(uint56(window)));
        if (delta < 0 && (delta % int56(uint56(window))) != 0) {
            t--;
        }
        return t;
    }

    /*//////////////////////////////////////////////////////////////
                            POSITION HEALTH
    //////////////////////////////////////////////////////////////*/

    function isInRange(uint256 tokenId) public view returns (bool) {
        if (!locks[tokenId].active) revert PositionNotLocked();
        (,,,, int24 tl, int24 tu,,,,,) = POSITION_MANAGER.positions(tokenId);
        (, int24 t,,,,,) = POOL.globalState();
        return t >= tl && t < tu;
    }

    function lockedPositionCount() external view returns (uint256) {
        return _lockedTokenIds.length;
    }

    function lockedTokenIds() external view returns (uint256[] memory) {
        return _lockedTokenIds;
    }

    function lockedTokenIdAt(uint256 index) external view returns (uint256) {
        return _lockedTokenIds[index];
    }
}
