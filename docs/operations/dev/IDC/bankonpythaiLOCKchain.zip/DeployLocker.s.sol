// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {Script, console2}  from "forge-std/Script.sol";
import {LockerFactory}     from "src/lockers/LockerFactory.sol";
import {UniswapV3Locker}   from "src/lockers/UniswapV3Locker.sol";
import {AlgebraLocker}     from "src/lockers/AlgebraLocker.sol";

/// @title  DeployLocker - Cross-chain locker deployment script
/// @notice Deploys a LockerFactory (or reuses an existing one) and creates the
///         appropriate locker for the target chain's DEX family.
///
///         Required env:
///           PRIVATE_KEY        deployer (use --ledger in production)
///           FACTORY            existing LockerFactory address; if 0x0, a new one is deployed
///           DEX_KIND           "univ3" or "algebra"
///           POSITION_MANAGER   chain-specific NPM address
///           POOL               main pool address on this chain
///           TREASURY           multisig/timelock that receives fees and post-lock NFTs
///           SALT_LABEL         deterministic deployment label, e.g. "bankon.pythai.v1.eth"
contract DeployLocker is Script {
    function run() external returns (address factoryAddr, address lockerAddr) {
        uint256 deployerPk = vm.envUint("PRIVATE_KEY");
        address existingFactory = vm.envOr("FACTORY", address(0));
        string  memory dexKind = vm.envString("DEX_KIND");
        address positionManager = vm.envAddress("POSITION_MANAGER");
        address pool            = vm.envAddress("POOL");
        address treasury        = vm.envAddress("TREASURY");
        bytes32 salt = keccak256(bytes(vm.envString("SALT_LABEL")));

        require(treasury.code.length > 0 || vm.envOr("ALLOW_EOA_TREASURY", false),
            "TREASURY must be a contract (multisig/timelock)");

        vm.startBroadcast(deployerPk);

        LockerFactory factory = existingFactory == address(0)
            ? new LockerFactory()
            : LockerFactory(existingFactory);
        factoryAddr = address(factory);

        if (keccak256(bytes(dexKind)) == keccak256(bytes("univ3"))) {
            address predicted = factory.predictUniswapV3LockerAddress(
                positionManager, pool, treasury, salt
            );
            lockerAddr = factory.deployUniswapV3Locker(
                positionManager, pool, treasury, salt
            );
            require(lockerAddr == predicted, "address mismatch");
        } else if (keccak256(bytes(dexKind)) == keccak256(bytes("algebra"))) {
            address predicted = factory.predictAlgebraLockerAddress(
                positionManager, pool, treasury, salt
            );
            lockerAddr = factory.deployAlgebraLocker(
                positionManager, pool, treasury, salt
            );
            require(lockerAddr == predicted, "address mismatch");
        } else {
            revert("DEX_KIND must be univ3 or algebra");
        }

        vm.stopBroadcast();

        console2.log("=== Locker deployment ===");
        console2.log("factory         :", factoryAddr);
        console2.log("locker          :", lockerAddr);
        console2.log("dex kind        :", dexKind);
        console2.log("position manager:", positionManager);
        console2.log("pool            :", pool);
        console2.log("treasury        :", treasury);
        console2.logBytes32(salt);
    }
}
