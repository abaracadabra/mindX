// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {Test, console2} from "forge-std/Test.sol";
import {UniswapV3Locker} from "src/lockers/UniswapV3Locker.sol";
import {LockerFactory}   from "src/lockers/LockerFactory.sol";
import {MockPositionManager, MockUniswapV3Pool} from "test/mocks/MockV3.sol";

contract UniswapV3LockerTest is Test {
    UniswapV3Locker  internal locker;
    MockPositionManager internal pm;
    MockUniswapV3Pool   internal pool;

    address internal pythai   = address(0xAAAA);
    address internal weth     = address(0xBBBB);
    uint24  internal constant FEE_TIER = 3000;

    address internal treasury = makeAddr("treasury");
    address internal alice    = makeAddr("alice");
    address internal mallory  = makeAddr("mallory");

    function setUp() public {
        // token0 must be < token1
        if (pythai > weth) (pythai, weth) = (weth, pythai);

        pm   = new MockPositionManager();
        pool = new MockUniswapV3Pool(pythai, weth, FEE_TIER);
        pool.setSlot0(uint160(1 << 96), int24(0));
        pool.setLiquidity(1e18);

        locker = new UniswapV3Locker(address(pm), address(pool), treasury);
    }

    function _mintPosition(address to, int24 tl, int24 tu, uint128 liq) internal returns (uint256) {
        return pm.mintPosition(to, pythai, weth, FEE_TIER, tl, tu, liq);
    }

    /*//////////////////////////////////////////////////////////////
                          CONSTRUCTOR BINDING
    //////////////////////////////////////////////////////////////*/

    function test_constructorBindsToPool() public view {
        assertEq(address(locker.POSITION_MANAGER()), address(pm));
        assertEq(address(locker.POOL()),             address(pool));
        assertEq(locker.TOKEN0(),                    pythai);
        assertEq(locker.TOKEN1(),                    weth);
        assertEq(locker.FEE(),                       FEE_TIER);
        assertEq(locker.TREASURY(),                  treasury);
    }

    function test_constructorRevertsOnZeroAddresses() public {
        vm.expectRevert(UniswapV3Locker.ZeroAddress.selector);
        new UniswapV3Locker(address(0), address(pool), treasury);

        vm.expectRevert(UniswapV3Locker.ZeroAddress.selector);
        new UniswapV3Locker(address(pm), address(0), treasury);

        vm.expectRevert(UniswapV3Locker.ZeroAddress.selector);
        new UniswapV3Locker(address(pm), address(pool), address(0));
    }

    function test_lockerReadsPoolIdentityFromPoolNotConstructorArgs() public view {
        // The locker reads token0/token1/fee directly from the pool. There's no
        // way to pass mismatched values through the constructor because the
        // constructor doesn't accept them.
        assertEq(locker.TOKEN0(), pool.token0());
        assertEq(locker.TOKEN1(), pool.token1());
        assertEq(locker.FEE(),    pool.fee());
    }

    /*//////////////////////////////////////////////////////////////
                        ON-DEPOSIT VERIFICATION
    //////////////////////////////////////////////////////////////*/

    function test_depositSucceedsForCorrectPool() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);

        vm.prank(alice);
        locker.deposit(tokenId, 365 days);

        assertEq(pm.ownerOf(tokenId), address(locker));
        (uint40 unlockAt,, uint128 liq,,,bool active) = locker.locks(tokenId);
        assertTrue(active);
        assertEq(liq, 1e18);
        assertEq(unlockAt, block.timestamp + 365 days);
    }

    function test_depositRejectsWrongTokens() public {
        address otherToken = address(0xCCCC);
        uint256 tokenId = pm.mintPosition(alice, otherToken, weth, FEE_TIER, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);

        vm.prank(alice);
        vm.expectRevert();
        locker.deposit(tokenId, 365 days);
    }

    function test_depositRejectsWrongFee() public {
        uint256 tokenId = pm.mintPosition(alice, pythai, weth, 500, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);

        vm.prank(alice);
        vm.expectRevert();
        locker.deposit(tokenId, 365 days);
    }

    function test_depositRejectsEmptyLiquidity() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 0);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);

        vm.prank(alice);
        vm.expectRevert(UniswapV3Locker.EmptyPosition.selector);
        locker.deposit(tokenId, 365 days);
    }

    function test_depositRejectsBelowMinDuration() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);

        vm.prank(alice);
        vm.expectRevert(UniswapV3Locker.LockDurationOutOfRange.selector);
        locker.deposit(tokenId, 29 days);
    }

    function test_depositRejectsAboveMaxDuration() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);

        vm.prank(alice);
        vm.expectRevert(UniswapV3Locker.LockDurationOutOfRange.selector);
        locker.deposit(tokenId, 11 * 365 days);
    }

    function test_depositRejectsRelockSameTokenId() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.startPrank(alice);
        pm.approve(address(locker), tokenId);
        locker.deposit(tokenId, 365 days);
        vm.expectRevert(UniswapV3Locker.AlreadyLocked.selector);
        locker.deposit(tokenId, 365 days);
        vm.stopPrank();
    }

    /*//////////////////////////////////////////////////////////////
                            FEE COLLECTION
    //////////////////////////////////////////////////////////////*/

    function test_collectFeesRoutesToTreasury() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);
        vm.prank(alice);
        locker.deposit(tokenId, 365 days);

        pm.setOwedFees(tokenId, 100, 200);

        // Anyone can trigger fee collection - the destination is hard-coded to TREASURY
        vm.prank(mallory);
        locker.collectFees(tokenId);

        assertEq(pm.recipientOf(tokenId), treasury);
    }

    function test_collectFeesRevertsOnUnlockedPosition() public {
        vm.expectRevert(UniswapV3Locker.PositionNotLocked.selector);
        locker.collectFees(999);
    }

    /*//////////////////////////////////////////////////////////////
                              WITHDRAWAL
    //////////////////////////////////////////////////////////////*/

    function test_withdrawRevertsBeforeUnlock() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);
        vm.prank(alice);
        locker.deposit(tokenId, 365 days);

        vm.expectRevert();
        locker.withdraw(tokenId);
    }

    function test_withdrawSucceedsAfterUnlockAndRoutesToTreasury() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);
        vm.prank(alice);
        locker.deposit(tokenId, 365 days);

        vm.warp(block.timestamp + 365 days + 1);

        // Mallory triggers withdrawal - but the NFT must go to treasury, not mallory
        vm.prank(mallory);
        locker.withdraw(tokenId);

        assertEq(pm.ownerOf(tokenId), treasury);
        (,,,,, bool active) = locker.locks(tokenId);
        assertFalse(active);
    }

    function test_withdrawCannotBeRedirectedAwayFromTreasury() public {
        // There is no withdraw(tokenId, recipient) variant. The recipient is
        // hard-coded to TREASURY at the contract level. This test documents
        // that the public ABI does not expose any path for an attacker to
        // redirect the NFT.
        bytes4 sel = bytes4(keccak256("withdraw(uint256,address)"));
        (bool ok, ) = address(locker).call(abi.encodeWithSelector(sel, uint256(1), mallory));
        assertFalse(ok, "withdraw(uint256,address) must not exist");
    }

    /*//////////////////////////////////////////////////////////////
                          NO ADMIN FUNCTIONS
    //////////////////////////////////////////////////////////////*/

    function test_noOwnerFunction() public {
        // The locker has no Ownable and no admin path. This test confirms
        // no owner() function is exposed.
        bytes4 sel = bytes4(keccak256("owner()"));
        (bool ok, ) = address(locker).staticcall(abi.encodeWithSelector(sel));
        assertFalse(ok, "locker must not expose owner()");
    }

    function test_noUpgradeFunction() public {
        bytes4[] memory upgradeSelectors = new bytes4[](4);
        upgradeSelectors[0] = bytes4(keccak256("upgradeTo(address)"));
        upgradeSelectors[1] = bytes4(keccak256("upgradeToAndCall(address,bytes)"));
        upgradeSelectors[2] = bytes4(keccak256("setImplementation(address)"));
        upgradeSelectors[3] = bytes4(keccak256("pause()"));

        for (uint256 i; i < upgradeSelectors.length; ++i) {
            (bool ok, ) = address(locker).call(
                abi.encodeWithSelector(upgradeSelectors[i], makeAddr("attacker"))
            );
            assertFalse(ok, "locker must not expose upgrade/pause functions");
        }
    }

    /*//////////////////////////////////////////////////////////////
                          PRICE VIEW FUNCTIONS
    //////////////////////////////////////////////////////////////*/

    function test_currentSqrtPriceReadsFromPool() public {
        uint160 expectedSqrt = uint160(uint256(1234567) << 80);
        pool.setSlot0(expectedSqrt, int24(100));

        assertEq(locker.currentSqrtPriceX96(), expectedSqrt);
        assertEq(locker.currentTick(),         100);
    }

    function test_poolLiquidityReadsFromPool() public {
        pool.setLiquidity(5e18);
        assertEq(locker.poolLiquidity(), 5e18);
    }

    function test_twapTickComputesCorrectly() public {
        // Set tickCumulatives such that delta over 300s averages to 50
        // observe([300, 0]) returns [cumAt-300s, cumAtNow]; delta = +15000 over 300s = avg 50
        pool.pushTickCumulative(int56(0));      // 300 seconds ago
        pool.pushTickCumulative(int56(15000));  // now
        assertEq(locker.twapTick(300), int24(50));
    }

    /*//////////////////////////////////////////////////////////////
                              ENUMERATION
    //////////////////////////////////////////////////////////////*/

    function test_lockedTokenEnumeration() public {
        uint256 id1 = _mintPosition(alice, -1000, 1000, 1e18);
        uint256 id2 = _mintPosition(alice, -2000, 2000, 2e18);

        vm.startPrank(alice);
        pm.approve(address(locker), id1);
        pm.approve(address(locker), id2);
        locker.deposit(id1, 365 days);
        locker.deposit(id2, 365 days);
        vm.stopPrank();

        assertEq(locker.lockedPositionCount(), 2);
        assertEq(locker.lockedTokenIdAt(0), id1);
        assertEq(locker.lockedTokenIdAt(1), id2);

        vm.warp(block.timestamp + 366 days);
        locker.withdraw(id1);

        assertEq(locker.lockedPositionCount(), 1);
        assertEq(locker.lockedTokenIdAt(0), id2);
    }

    /*//////////////////////////////////////////////////////////////
                          POSITION HEALTH
    //////////////////////////////////////////////////////////////*/

    function test_isInRangeReturnsTrueWhenInRange() public {
        uint256 tokenId = _mintPosition(alice, -1000, 1000, 1e18);
        vm.prank(alice);
        pm.approve(address(locker), tokenId);
        vm.prank(alice);
        locker.deposit(tokenId, 365 days);

        pool.setSlot0(uint160(1 << 96), int24(0));
        assertTrue(locker.isInRange(tokenId));

        pool.setSlot0(uint160(1 << 96), int24(1500));
        assertFalse(locker.isInRange(tokenId));
    }
}

/*//////////////////////////////////////////////////////////////
                          FACTORY TESTS
//////////////////////////////////////////////////////////////*/

contract LockerFactoryTest is Test {
    LockerFactory       internal factory;
    MockPositionManager internal pm;
    MockUniswapV3Pool   internal pool;

    address internal treasury = makeAddr("treasury");

    function setUp() public {
        factory = new LockerFactory();
        pm = new MockPositionManager();

        address t0 = address(0x1111);
        address t1 = address(0x2222);
        if (t0 > t1) (t0, t1) = (t1, t0);

        pool = new MockUniswapV3Pool(t0, t1, 3000);
    }

    function test_deployUniswapV3LockerAtPredictedAddress() public {
        bytes32 salt = keccak256("bankon.pythai.v1.eth");
        address predicted = factory.predictUniswapV3LockerAddress(
            address(pm), address(pool), treasury, salt
        );
        address deployed = factory.deployUniswapV3Locker(
            address(pm), address(pool), treasury, salt
        );
        assertEq(deployed, predicted);
    }

    function test_deployingSameSaltTwiceReverts() public {
        bytes32 salt = keccak256("bankon.pythai.v1.eth");
        factory.deployUniswapV3Locker(address(pm), address(pool), treasury, salt);

        vm.expectRevert(LockerFactory.DeploymentFailed.selector);
        factory.deployUniswapV3Locker(address(pm), address(pool), treasury, salt);
    }
}
