// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {
    INonfungiblePositionManager,
    IUniswapV3Pool
} from "src/interfaces/IUniswapV3.sol";

/// @title  UniswapV3Locker - BANKON PYTHAI Liquidity Position Locker
/// @author codephreak (PYTHAI / DELTAVERSE)
/// @notice Immutably binds locked LP NFT positions to a single Uniswap V3 pool.
///         Verifies every deposited position against the bound pool's identity,
///         enforces time-locked custody with no early-release path, and exposes
///         live price view functions for the parity hub and external consumers.
/// @dev    NO ADMIN FUNCTIONS. NO UPGRADE PATH. NO PAUSE.
///         Once deployed, the locker operates autonomously under its constructor
///         parameters until the end of time. The treasury cannot bypass the lock,
///         a multisig cannot bypass the lock, and a governance vote cannot bypass
///         the lock. The only state transitions are deposit (before lock expiry)
///         and withdraw (after lock expiry), with permissionless fee collection
///         throughout.
contract UniswapV3Locker is ReentrancyGuard {
    /*//////////////////////////////////////////////////////////////
                            IMMUTABLE BINDINGS
    //////////////////////////////////////////////////////////////*/

    /// @notice The Uniswap V3 NonfungiblePositionManager whose NFTs this locker accepts.
    INonfungiblePositionManager public immutable POSITION_MANAGER;

    /// @notice The single Uniswap V3 pool this locker is bound to.
    ///         Every deposited NFT must reference this pool's (token0, token1, fee).
    IUniswapV3Pool public immutable POOL;

    /// @notice Sorted token0/token1 of the bound pool. token0 < token1 by Uniswap convention.
    address public immutable TOKEN0;
    address public immutable TOKEN1;

    /// @notice Fee tier of the bound pool (e.g., 3000 for 0.30%).
    uint24 public immutable FEE;

    /// @notice Sole recipient of returned positions and collected fees.
    ///         MUST be a multisig or timelock; never an EOA in production.
    ///         The locker NEVER sends funds or NFTs to msg.sender.
    address public immutable TREASURY;

    /*//////////////////////////////////////////////////////////////
                              CONSTANTS
    //////////////////////////////////////////////////////////////*/

    /// @notice Hard cap on lock duration. Prevents accidental locks beyond a
    ///         reasonable planning horizon. 10 years.
    uint256 public constant MAX_LOCK_DURATION = 365 days * 10;

    /// @notice Hard floor on lock duration. 30 days.
    uint256 public constant MIN_LOCK_DURATION = 30 days;

    /*//////////////////////////////////////////////////////////////
                              LOCK STATE
    //////////////////////////////////////////////////////////////*/

    struct Lock {
        uint40  unlockAt;          // unix seconds, max year 36812
        uint40  depositedAt;
        uint128 liquidityAtDeposit;
        int24   tickLowerAtDeposit;
        int24   tickUpperAtDeposit;
        bool    active;
    }

    /// @notice Per-tokenId lock record. `active` is true iff the locker holds the NFT.
    mapping(uint256 tokenId => Lock) public locks;

    /// @dev Enumerable set of currently-locked token IDs.
    uint256[] private _lockedTokenIds;
    mapping(uint256 tokenId => uint256 index) private _lockedTokenIndex;

    /*//////////////////////////////////////////////////////////////
                                EVENTS
    //////////////////////////////////////////////////////////////*/

    event PositionLocked(
        uint256 indexed tokenId,
        uint40  unlockAt,
        uint128 liquidity,
        int24   tickLower,
        int24   tickUpper
    );

    event FeesCollected(
        uint256 indexed tokenId,
        uint256 amount0,
        uint256 amount1
    );

    event PositionReleased(uint256 indexed tokenId, address indexed recipient);

    /*//////////////////////////////////////////////////////////////
                                ERRORS
    //////////////////////////////////////////////////////////////*/

    error ZeroAddress();
    error TokensNotSorted();
    error WrongPool(address t0, address t1, uint24 fee);
    error EmptyPosition();
    error LockDurationOutOfRange();
    error PositionNotLocked();
    error LockNotExpired(uint256 unlockAt, uint256 nowAt);
    error AlreadyLocked();

    /*//////////////////////////////////////////////////////////////
                              CONSTRUCTOR
    //////////////////////////////////////////////////////////////*/

    /// @param positionManager Uniswap V3 NonfungiblePositionManager address on this chain.
    /// @param pool            The single PYTHAI/ETH pool address this locker will be bound to.
    /// @param treasury        Recipient of fee collections and post-lock withdrawals.
    /// @dev   Pool identity (token0, token1, fee) is read directly from the pool itself,
    ///        not from constructor arguments. This eliminates a class of misconfiguration
    ///        bug where the deployer passes incorrect tokens.
    constructor(address positionManager, address pool, address treasury) {
        if (positionManager == address(0) || pool == address(0) || treasury == address(0)) {
            revert ZeroAddress();
        }

        POSITION_MANAGER = INonfungiblePositionManager(positionManager);
        POOL             = IUniswapV3Pool(pool);
        TREASURY         = treasury;

        address t0 = IUniswapV3Pool(pool).token0();
        address t1 = IUniswapV3Pool(pool).token1();
        if (t0 >= t1) revert TokensNotSorted();

        TOKEN0 = t0;
        TOKEN1 = t1;
        FEE    = IUniswapV3Pool(pool).fee();
    }

    /*//////////////////////////////////////////////////////////////
                                DEPOSIT
    //////////////////////////////////////////////////////////////*/

    /// @notice Locks a Uniswap V3 LP NFT for the specified duration.
    /// @dev    The caller must have approved this contract to transfer the NFT.
    ///         Uses `transferFrom` (not `safeTransferFrom`) to avoid the receiver
    ///         hook, which is unnecessary because we validate the NFT before
    ///         pulling it.
    /// @param  tokenId      The Uniswap V3 position NFT to lock.
    /// @param  lockDuration Seconds until the position becomes withdrawable.
    function deposit(uint256 tokenId, uint256 lockDuration) external nonReentrant {
        if (lockDuration < MIN_LOCK_DURATION || lockDuration > MAX_LOCK_DURATION) {
            revert LockDurationOutOfRange();
        }
        if (locks[tokenId].active) revert AlreadyLocked();

        (
            ,                      // nonce
            ,                      // operator
            address t0,
            address t1,
            uint24  fee,
            int24   tickLower,
            int24   tickUpper,
            uint128 liquidity,
            ,                      // feeGrowthInside0LastX128
            ,                      // feeGrowthInside1LastX128
            ,                      // tokensOwed0
                                   // tokensOwed1
        ) = POSITION_MANAGER.positions(tokenId);

        if (t0 != TOKEN0 || t1 != TOKEN1 || fee != FEE) revert WrongPool(t0, t1, fee);
        if (liquidity == 0) revert EmptyPosition();

        // CEI: record state before external NFT pull.
        uint40 unlockAt = uint40(block.timestamp + lockDuration);
        locks[tokenId] = Lock({
            unlockAt:           unlockAt,
            depositedAt:        uint40(block.timestamp),
            liquidityAtDeposit: liquidity,
            tickLowerAtDeposit: tickLower,
            tickUpperAtDeposit: tickUpper,
            active:             true
        });
        _lockedTokenIndex[tokenId] = _lockedTokenIds.length;
        _lockedTokenIds.push(tokenId);

        // Pull the NFT. transferFrom does not invoke onERC721Received, so no
        // receiver hook is required and no transient-flag dance is needed.
        POSITION_MANAGER.transferFrom(msg.sender, address(this), tokenId);

        emit PositionLocked(tokenId, unlockAt, liquidity, tickLower, tickUpper);
    }

    /*//////////////////////////////////////////////////////////////
                            FEE COLLECTION
    //////////////////////////////////////////////////////////////*/

    /// @notice Sweeps accumulated trading fees from a locked position to TREASURY.
    /// @dev    Permissionless. Fees can only flow to the immutable TREASURY,
    ///         so allowing anyone to trigger this is safe and removes operational
    ///         dependence on a privileged keeper.
    function collectFees(uint256 tokenId)
        external
        nonReentrant
        returns (uint256 amount0, uint256 amount1)
    {
        if (!locks[tokenId].active) revert PositionNotLocked();

        (amount0, amount1) = POSITION_MANAGER.collect(
            INonfungiblePositionManager.CollectParams({
                tokenId:    tokenId,
                recipient:  TREASURY,
                amount0Max: type(uint128).max,
                amount1Max: type(uint128).max
            })
        );

        emit FeesCollected(tokenId, amount0, amount1);
    }

    /// @notice Batch fee collection across multiple locked positions.
    function collectFeesBatch(uint256[] calldata tokenIds) external nonReentrant {
        uint256 len = tokenIds.length;
        for (uint256 i; i < len; ) {
            uint256 id = tokenIds[i];
            if (!locks[id].active) revert PositionNotLocked();

            (uint256 a0, uint256 a1) = POSITION_MANAGER.collect(
                INonfungiblePositionManager.CollectParams({
                    tokenId:    id,
                    recipient:  TREASURY,
                    amount0Max: type(uint128).max,
                    amount1Max: type(uint128).max
                })
            );

            emit FeesCollected(id, a0, a1);
            unchecked { ++i; }
        }
    }

    /*//////////////////////////////////////////////////////////////
                              WITHDRAWAL
    //////////////////////////////////////////////////////////////*/

    /// @notice Releases a locked position to TREASURY after its lock expires.
    /// @dev    Permissionless. The NFT can only go to the immutable TREASURY,
    ///         so allowing any caller to trigger this removes operational
    ///         dependence on the treasury being live at the unlock moment.
    function withdraw(uint256 tokenId) external nonReentrant {
        Lock memory lock_ = locks[tokenId];
        if (!lock_.active) revert PositionNotLocked();
        if (block.timestamp < lock_.unlockAt) {
            revert LockNotExpired(lock_.unlockAt, block.timestamp);
        }

        // CEI: clear state before transferring the NFT out.
        locks[tokenId].active = false;
        _removeTokenFromIndex(tokenId);

        POSITION_MANAGER.transferFrom(address(this), TREASURY, tokenId);

        emit PositionReleased(tokenId, TREASURY);
    }

    function _removeTokenFromIndex(uint256 tokenId) internal {
        uint256 index = _lockedTokenIndex[tokenId];
        uint256 lastIndex = _lockedTokenIds.length - 1;
        if (index != lastIndex) {
            uint256 lastTokenId = _lockedTokenIds[lastIndex];
            _lockedTokenIds[index] = lastTokenId;
            _lockedTokenIndex[lastTokenId] = index;
        }
        _lockedTokenIds.pop();
        delete _lockedTokenIndex[tokenId];
    }

    /*//////////////////////////////////////////////////////////////
                          PRICE VIEW FUNCTIONS
    //////////////////////////////////////////////////////////////*/

    /// @notice Current spot sqrt-price of the bound pool, scaled by 2^96.
    function currentSqrtPriceX96() external view returns (uint160 sqrtPriceX96) {
        (sqrtPriceX96,,,,,,) = POOL.slot0();
    }

    /// @notice Current spot tick of the bound pool.
    function currentTick() external view returns (int24 tick) {
        (, tick,,,,,) = POOL.slot0();
    }

    /// @notice Current in-range active liquidity of the bound pool.
    function poolLiquidity() external view returns (uint128) {
        return POOL.liquidity();
    }

    /// @notice Time-weighted average tick over the last `window` seconds.
    /// @dev    Rounds toward negative infinity for negative cumulative deltas,
    ///         matching Uniswap V3's OracleLibrary.consult convention.
    function twapTick(uint32 window) external view returns (int24) {
        require(window > 0, "window=0");

        uint32[] memory secondsAgos = new uint32[](2);
        secondsAgos[0] = window;
        secondsAgos[1] = 0;

        (int56[] memory tickCumulatives,) = POOL.observe(secondsAgos);
        int56 delta = tickCumulatives[1] - tickCumulatives[0];
        int24 t = int24(delta / int56(uint56(window)));
        if (delta < 0 && (delta % int56(uint56(window))) != 0) {
            t--;
        }
        return t;
    }

    /*//////////////////////////////////////////////////////////////
                            POSITION HEALTH
    //////////////////////////////////////////////////////////////*/

    /// @notice True if the position's range currently contains the pool's spot tick.
    function isInRange(uint256 tokenId) public view returns (bool) {
        if (!locks[tokenId].active) revert PositionNotLocked();
        (,,,,, int24 tl, int24 tu,,,,,) = POSITION_MANAGER.positions(tokenId);
        (, int24 t,,,,,) = POOL.slot0();
        return t >= tl && t < tu;
    }

    /// @notice Number of positions currently locked.
    function lockedPositionCount() external view returns (uint256) {
        return _lockedTokenIds.length;
    }

    /// @notice Returns all currently-locked token IDs.
    function lockedTokenIds() external view returns (uint256[] memory) {
        return _lockedTokenIds;
    }

    function lockedTokenIdAt(uint256 index) external view returns (uint256) {
        return _lockedTokenIds[index];
    }

    /// @notice Sum of current liquidity across all locked positions.
    function totalLockedLiquidity() external view returns (uint256 total) {
        uint256 len = _lockedTokenIds.length;
        for (uint256 i; i < len; ) {
            (,,,,,,, uint128 liq,,,,) = POSITION_MANAGER.positions(_lockedTokenIds[i]);
            total += liq;
            unchecked { ++i; }
        }
    }

    /// @notice Detailed snapshot of a single locked position.
    struct PositionView {
        bool    active;
        uint40  unlockAt;
        uint40  depositedAt;
        int24   tickLower;
        int24   tickUpper;
        uint128 currentLiquidity;
        bool    inRange;
        int24   currentTick;
    }

    function positionView(uint256 tokenId) external view returns (PositionView memory v) {
        Lock memory l = locks[tokenId];
        v.active      = l.active;
        v.unlockAt    = l.unlockAt;
        v.depositedAt = l.depositedAt;

        if (l.active) {
            (,,,,, int24 tl, int24 tu, uint128 liq,,,,) = POSITION_MANAGER.positions(tokenId);
            (, int24 t,,,,,) = POOL.slot0();
            v.tickLower        = tl;
            v.tickUpper        = tu;
            v.currentLiquidity = liq;
            v.currentTick      = t;
            v.inRange          = t >= tl && t < tu;
        }
    }
}
