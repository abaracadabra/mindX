// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {INonfungiblePositionManager} from "src/interfaces/IUniswapV3.sol";

/// @notice Mock NonfungiblePositionManager for unit tests. Mints ERC721 tokenIds
///         with arbitrary position data and exposes the standard collect() function.
contract MockPositionManager is ERC721 {
    struct Position {
        address token0;
        address token1;
        uint24  fee;
        int24   tickLower;
        int24   tickUpper;
        uint128 liquidity;
        uint128 tokensOwed0;
        uint128 tokensOwed1;
    }

    mapping(uint256 => Position) public positionsData;
    uint256 public nextTokenId = 1;

    constructor() ERC721("Mock V3 Positions", "MV3P") {}

    function mintPosition(
        address to,
        address token0,
        address token1,
        uint24 fee,
        int24 tickLower,
        int24 tickUpper,
        uint128 liquidity
    ) external returns (uint256 tokenId) {
        tokenId = nextTokenId++;
        positionsData[tokenId] = Position({
            token0:       token0,
            token1:       token1,
            fee:          fee,
            tickLower:    tickLower,
            tickUpper:    tickUpper,
            liquidity:    liquidity,
            tokensOwed0:  0,
            tokensOwed1:  0
        });
        _mint(to, tokenId);
    }

    function setOwedFees(uint256 tokenId, uint128 owed0, uint128 owed1) external {
        positionsData[tokenId].tokensOwed0 = owed0;
        positionsData[tokenId].tokensOwed1 = owed1;
    }

    function positions(uint256 tokenId)
        external
        view
        returns (
            uint96 nonce,
            address operator,
            address token0,
            address token1,
            uint24 fee,
            int24 tickLower,
            int24 tickUpper,
            uint128 liquidity,
            uint256 feeGrowthInside0LastX128,
            uint256 feeGrowthInside1LastX128,
            uint128 tokensOwed0,
            uint128 tokensOwed1
        )
    {
        Position memory p = positionsData[tokenId];
        return (
            0,
            address(0),
            p.token0,
            p.token1,
            p.fee,
            p.tickLower,
            p.tickUpper,
            p.liquidity,
            0,
            0,
            p.tokensOwed0,
            p.tokensOwed1
        );
    }

    function collect(INonfungiblePositionManager.CollectParams calldata params)
        external
        returns (uint256 amount0, uint256 amount1)
    {
        require(ownerOf(params.tokenId) == msg.sender, "not owner");
        Position storage p = positionsData[params.tokenId];
        amount0 = p.tokensOwed0;
        amount1 = p.tokensOwed1;
        p.tokensOwed0 = 0;
        p.tokensOwed1 = 0;
        // For testing we just zero out; no actual token transfer.
        // The caller can verify the recipient param via the returned amounts and event-tracing.
        recipientOf[params.tokenId] = params.recipient;
    }

    // Test hook: track who fees were collected to.
    mapping(uint256 => address) public recipientOf;
}

/// @notice Mock Uniswap V3 Pool for unit tests. Returns configurable slot0 and observe data.
contract MockUniswapV3Pool {
    address public immutable token0;
    address public immutable token1;
    uint24  public immutable fee;

    uint160 public slot0SqrtPriceX96;
    int24   public slot0Tick;
    uint128 public liquidity;

    int56[] public tickCumulativesQueue;

    constructor(address _t0, address _t1, uint24 _fee) {
        require(_t0 < _t1, "sort tokens");
        token0 = _t0;
        token1 = _t1;
        fee    = _fee;
    }

    function setSlot0(uint160 sqrtPriceX96, int24 tick) external {
        slot0SqrtPriceX96 = sqrtPriceX96;
        slot0Tick = tick;
    }

    function setLiquidity(uint128 liq) external {
        liquidity = liq;
    }

    function pushTickCumulative(int56 c) external {
        tickCumulativesQueue.push(c);
    }

    function slot0()
        external
        view
        returns (
            uint160 sqrtPriceX96,
            int24 tick,
            uint16,
            uint16,
            uint16,
            uint8,
            bool
        )
    {
        return (slot0SqrtPriceX96, slot0Tick, 0, 1, 1, 0, true);
    }

    function observe(uint32[] calldata secondsAgos)
        external
        view
        returns (
            int56[] memory tickCumulatives,
            uint160[] memory secondsPerLiquidityCumulativeX128s
        )
    {
        tickCumulatives = new int56[](secondsAgos.length);
        secondsPerLiquidityCumulativeX128s = new uint160[](secondsAgos.length);
        require(tickCumulativesQueue.length >= secondsAgos.length, "set cumulatives first");
        for (uint256 i; i < secondsAgos.length; ++i) {
            tickCumulatives[i] = tickCumulativesQueue[i];
        }
    }
}
