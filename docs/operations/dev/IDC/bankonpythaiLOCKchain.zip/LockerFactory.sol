// SPDX-License-Identifier: Apache-2.0
// BANKON 2026
pragma solidity ^0.8.25;

import {UniswapV3Locker} from "src/lockers/UniswapV3Locker.sol";
import {AlgebraLocker}   from "src/lockers/AlgebraLocker.sol";

/// @title  LockerFactory - Deterministic cross-chain locker deployment via CREATE2
/// @author codephreak (PYTHAI / DELTAVERSE)
/// @notice Deploys UniswapV3Locker and AlgebraLocker instances at predictable addresses
///         derived from the deployer, salt, and constructor arguments. Predictable
///         addresses simplify cross-chain operational tooling and allow off-chain
///         consumers to verify the locker for a given chain by recomputing the
///         expected address from public parameters.
/// @dev    The factory itself is immutable, has no admin, and is itself a deterministic
///         contract. Deploying the factory at the same address on every chain (via
///         e.g. Nick's deterministic deployer 0x4e59b44847b379578588920cA78FbF26c0B4956C)
///         ensures that for the same (positionManager, pool, treasury, salt) tuple,
///         the resulting locker address is identical across chains.
contract LockerFactory {
    /*//////////////////////////////////////////////////////////////
                                EVENTS
    //////////////////////////////////////////////////////////////*/

    event UniswapV3LockerDeployed(
        address indexed locker,
        address indexed pool,
        address indexed treasury,
        bytes32 salt
    );

    event AlgebraLockerDeployed(
        address indexed locker,
        address indexed pool,
        address indexed treasury,
        bytes32 salt
    );

    /*//////////////////////////////////////////////////////////////
                                ERRORS
    //////////////////////////////////////////////////////////////*/

    error DeploymentFailed();

    /*//////////////////////////////////////////////////////////////
                          UNISWAP V3 DEPLOYMENT
    //////////////////////////////////////////////////////////////*/

    /// @notice Deploys a UniswapV3Locker bound to the specified pool.
    /// @param positionManager Uniswap V3 NonfungiblePositionManager on this chain.
    /// @param pool            The PYTHAI/ETH pool address.
    /// @param treasury        Multisig/timelock receiving fees and post-lock NFTs.
    /// @param salt            Deployment salt; should be derived deterministically
    ///                        from the protocol's deployment plan (e.g. keccak256
    ///                        of a versioned label).
    function deployUniswapV3Locker(
        address positionManager,
        address pool,
        address treasury,
        bytes32 salt
    ) external returns (address locker) {
        bytes memory bytecode = abi.encodePacked(
            type(UniswapV3Locker).creationCode,
            abi.encode(positionManager, pool, treasury)
        );

        assembly {
            locker := create2(0, add(bytecode, 0x20), mload(bytecode), salt)
        }
        if (locker == address(0)) revert DeploymentFailed();

        emit UniswapV3LockerDeployed(locker, pool, treasury, salt);
    }

    /// @notice Computes the deployment address for a UniswapV3Locker without deploying it.
    function predictUniswapV3LockerAddress(
        address positionManager,
        address pool,
        address treasury,
        bytes32 salt
    ) external view returns (address) {
        bytes memory bytecode = abi.encodePacked(
            type(UniswapV3Locker).creationCode,
            abi.encode(positionManager, pool, treasury)
        );
        return _computeAddress(bytecode, salt);
    }

    /*//////////////////////////////////////////////////////////////
                            ALGEBRA DEPLOYMENT
    //////////////////////////////////////////////////////////////*/

    function deployAlgebraLocker(
        address positionManager,
        address pool,
        address treasury,
        bytes32 salt
    ) external returns (address locker) {
        bytes memory bytecode = abi.encodePacked(
            type(AlgebraLocker).creationCode,
            abi.encode(positionManager, pool, treasury)
        );

        assembly {
            locker := create2(0, add(bytecode, 0x20), mload(bytecode), salt)
        }
        if (locker == address(0)) revert DeploymentFailed();

        emit AlgebraLockerDeployed(locker, pool, treasury, salt);
    }

    function predictAlgebraLockerAddress(
        address positionManager,
        address pool,
        address treasury,
        bytes32 salt
    ) external view returns (address) {
        bytes memory bytecode = abi.encodePacked(
            type(AlgebraLocker).creationCode,
            abi.encode(positionManager, pool, treasury)
        );
        return _computeAddress(bytecode, salt);
    }

    /*//////////////////////////////////////////////////////////////
                              INTERNAL
    //////////////////////////////////////////////////////////////*/

    function _computeAddress(bytes memory bytecode, bytes32 salt) internal view returns (address) {
        bytes32 hash = keccak256(
            abi.encodePacked(bytes1(0xff), address(this), salt, keccak256(bytecode))
        );
        return address(uint160(uint256(hash)));
    }
}
