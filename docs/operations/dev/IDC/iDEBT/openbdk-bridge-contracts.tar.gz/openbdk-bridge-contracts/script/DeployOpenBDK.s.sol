// SPDX-License-Identifier: MIT
pragma solidity 0.8.23;

import {Script, console2} from "forge-std/Script.sol";
import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";

import {OpenBDKL1Escrow} from "../src/bridge/OpenBDKL1Escrow.sol";
import {OpenBDKL2MinterBurner} from "../src/bridge/OpenBDKL2MinterBurner.sol";
import {OpenBDKNativeConverter} from "../src/bridge/OpenBDKNativeConverter.sol";
import {OpenBDKL2Token} from "../src/token/OpenBDKL2Token.sol";
import {OpenBDKValidatorRegistry} from "../src/governance/OpenBDKValidatorRegistry.sol";

/**
 * @title DeployOpenBDK
 * @notice Multi-chain deployment script for the openBDK bridge contracts
 * @dev Mirrors the BuildOnPolygon/usdc-lxly DeployInit.s.sol pattern
 *      with adjustments for the openBDK Relayer-Validator architecture.
 *
 *      Deployment order:
 *      1. L1: Deploy L1Escrow proxy (uninitialized — needs L2MinterBurner address)
 *      2. L2: Deploy L2Token, L2MinterBurner, NativeConverter
 *      3. L2: Deploy ValidatorRegistry (independent of bridge stack)
 *      4. L1: Initialize L1Escrow with L2MinterBurner counterpart address
 *      5. L2: Initialize L2MinterBurner with L1Escrow counterpart address
 *      6. L2: Grant MINTER_ROLE / BURNER_ROLE on L2Token to bridge contracts
 *
 *      Run: forge script script/DeployOpenBDK.s.sol --multi --broadcast -vvvv
 */
contract DeployOpenBDK is Script {
    // ============ Network IDs (AggLayer canonical) ============

    uint32 constant L1_NETWORK_ID = 0;          // Ethereum
    uint32 constant POLYGON_ZKEVM_NETWORK_ID = 1; // Polygon zkEVM
    uint32 constant OPENBDK_NETWORK_ID = 7;     // openBDK v7 (placeholder)

    // ============ Mainnet addresses ============

    /// @notice The Unified Bridge address (same on every AggLayer-connected chain)
    address constant UNIFIED_BRIDGE = 0x2a3DD3EB832aF982ec71669E178424b10Dca2EDe;

    /// @notice USDC on Ethereum mainnet
    address constant L1_USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;

    function run() external {
        uint256 deployerKey = vm.envUint("DEPLOYER_PRIVATE_KEY");
        address admin = vm.envAddress("ADMIN_ADDRESS");
        address escrowManager = vm.envAddress("ESCROW_MANAGER_ADDRESS");
        address initialRelayer = vm.envAddress("INITIAL_RELAYER_ADDRESS");
        address stakingToken = vm.envAddress("STAKING_TOKEN_ADDRESS");
        uint256 minimumStake = vm.envUint("MINIMUM_VALIDATOR_STAKE");

        // --- Step 1 + 4: L1 Escrow ---
        vm.createSelectFork("ethereum");
        vm.startBroadcast(deployerKey);

        OpenBDKL1Escrow l1EscrowImpl = new OpenBDKL1Escrow();
        ERC1967Proxy l1EscrowProxy = new ERC1967Proxy(
            address(l1EscrowImpl),
            ""  // Initialize later with L2MinterBurner address
        );
        OpenBDKL1Escrow l1Escrow = OpenBDKL1Escrow(address(l1EscrowProxy));

        console2.log("L1Escrow proxy:", address(l1Escrow));
        console2.log("L1Escrow implementation:", address(l1EscrowImpl));

        vm.stopBroadcast();

        // --- Step 2 + 5: L2 Token, MinterBurner, NativeConverter ---
        vm.createSelectFork("openbdk_testnet");
        vm.startBroadcast(deployerKey);

        // L2 Token
        OpenBDKL2Token l2TokenImpl = new OpenBDKL2Token();
        ERC1967Proxy l2TokenProxy = new ERC1967Proxy(
            address(l2TokenImpl),
            abi.encodeCall(
                OpenBDKL2Token.initialize,
                ("USD Coin (openBDK)", "USDC.b", 6, admin)
            )
        );
        OpenBDKL2Token l2Token = OpenBDKL2Token(address(l2TokenProxy));
        console2.log("L2Token proxy:", address(l2Token));

        // L2 MinterBurner
        OpenBDKL2MinterBurner mbImpl = new OpenBDKL2MinterBurner();
        ERC1967Proxy mbProxy = new ERC1967Proxy(
            address(mbImpl),
            abi.encodeCall(
                OpenBDKL2MinterBurner.initialize,
                (
                    admin,
                    UNIFIED_BRIDGE,
                    address(l1Escrow),
                    L1_NETWORK_ID,
                    address(l2Token)
                )
            )
        );
        OpenBDKL2MinterBurner minterBurner = OpenBDKL2MinterBurner(address(mbProxy));
        console2.log("L2MinterBurner proxy:", address(minterBurner));

        // Grant MINTER and BURNER roles on L2 Token to MinterBurner
        l2Token.grantRole(l2Token.MINTER_ROLE(), address(minterBurner));
        l2Token.grantRole(l2Token.BURNER_ROLE(), address(minterBurner));

        // NativeConverter
        OpenBDKNativeConverter ncImpl = new OpenBDKNativeConverter();
        // Compute the BridgeWrappedToken address (deterministic per Unified Bridge)
        // For deployment, use the precomputed bwToken address from prior deposits
        address bridgeWrappedToken = vm.envAddress("BRIDGE_WRAPPED_TOKEN_ADDRESS");

        ERC1967Proxy ncProxy = new ERC1967Proxy(
            address(ncImpl),
            abi.encodeCall(
                OpenBDKNativeConverter.initialize,
                (
                    admin,
                    UNIFIED_BRIDGE,
                    address(l2Token),
                    bridgeWrappedToken,
                    address(l1Escrow),
                    L1_NETWORK_ID
                )
            )
        );
        OpenBDKNativeConverter converter = OpenBDKNativeConverter(address(ncProxy));
        console2.log("NativeConverter proxy:", address(converter));

        // Grant MINTER role on L2 Token to NativeConverter
        l2Token.grantRole(l2Token.MINTER_ROLE(), address(converter));

        // ValidatorRegistry
        OpenBDKValidatorRegistry vrImpl = new OpenBDKValidatorRegistry();
        ERC1967Proxy vrProxy = new ERC1967Proxy(
            address(vrImpl),
            abi.encodeCall(
                OpenBDKValidatorRegistry.initialize,
                (admin, stakingToken, initialRelayer, minimumStake, 100 /* unbonding blocks */)
            )
        );
        OpenBDKValidatorRegistry registry = OpenBDKValidatorRegistry(address(vrProxy));
        console2.log("ValidatorRegistry proxy:", address(registry));

        vm.stopBroadcast();

        // --- Step 4: Initialize L1Escrow with the L2MinterBurner counterpart ---
        vm.createSelectFork("ethereum");
        vm.startBroadcast(deployerKey);

        l1Escrow.initialize(
            admin,
            escrowManager,
            UNIFIED_BRIDGE,
            address(minterBurner),
            OPENBDK_NETWORK_ID,
            L1_USDC,
            address(l2Token)
        );

        console2.log("=== Deployment complete ===");
        console2.log("L1Escrow:        ", address(l1Escrow));
        console2.log("L2Token:         ", address(l2Token));
        console2.log("L2MinterBurner:  ", address(minterBurner));
        console2.log("NativeConverter: ", address(converter));
        console2.log("ValidatorRegistry:", address(registry));

        vm.stopBroadcast();
    }
}
