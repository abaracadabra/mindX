# DEPLOYMENT.md — AgenticPlace Algorand v1.3

End-to-end guide for getting from a fresh clone to a wired-up production
deployment, including all the post-deploy steps that aren't automated by
`deploy/deploy.py`.

---

## 0. Prerequisites

| Tool | Version | Install |
| --- | --- | --- |
| Python | ≥ 3.12 | https://www.python.org/downloads/ |
| Poetry | ≥ 1.7 | `curl -sSL https://install.python-poetry.org \| python3 -` |
| AlgoKit | ≥ 2.0 | `pipx install algokit` |
| Docker | latest | needed by `algokit localnet start` |
| Node.js | ≥ 18 | optional, only if you want the AlgoKit explorer UI |

Verify everything:

```bash
python --version       # 3.12.x
poetry --version       # 1.7.x or higher
algokit --version      # 2.x
docker --version       # any recent
```

---

## 1. Clone and install

```bash
unzip agenticplace-algorand-v1.3.zip
cd agenticplace-algorand
poetry install
poetry shell
```

Verify the install:

```bash
pytest tests/ -vv
```

All ~25 invariant tests should pass. These don't touch the chain — they just
sanity-check the constants and the frontend helper.

---

## 2. Compile contracts to TEAL

```bash
algokit compile py smart_contracts/anft/contract.py
algokit compile py smart_contracts/dnft/contract.py
algokit compile py smart_contracts/inft/contract.py
algokit compile py smart_contracts/thot/contract.py
algokit compile py smart_contracts/mindx/contract.py
algokit compile py smart_contracts/paimint/contract.py
algokit compile py smart_contracts/x402/contract.py
algokit compile py smart_contracts/registry/contract.py
```

Each command emits ARC-56 specs and TEAL bytecode under
`smart_contracts/<name>/artifacts/`. The deploy script reads these.

If a compile fails, the two most common gotchas are:

- `Global.current_application_id.id` — some Puya versions want `Global.current_application_id` directly. Drop `.id` if compile errors mention it.
- `arc4.emit(...)` — some versions use `arc4.emit_event(...)`. Search-and-replace if compile errors mention `emit`.

---

## 3. Deploy to LocalNet (smoke test)

```bash
algokit localnet start
NETWORK=localnet python deploy/deploy.py
```

You should see output like:

```
[network ] localnet
[deployer] 7K3X...QZUA

[deploy] ANFT (anft) ...
           -> app_id  = 1001
           -> app_addr = WJZL...VFXY
[deploy] DNFT (dnft) ...
... (six more)

======================================================================
Wiring contracts together
======================================================================
[wiring ] registry(1008).set_mindx(app=1005, oracle=7K3X...QZUA)
[wiring ] paimint(1006).bootstrap_asset(...)
           -> PAIMINT ASA id = 1009

======================================================================
AgenticPlace Algorand stack deployed:
======================================================================
  ANFT                   app_id=1001       addr=WJZL...VFXY
  DNFT                   app_id=1002       addr=...
  INFT                   app_id=1003       addr=...
  THOT                   app_id=1004       addr=...
  MindXBridge            app_id=1005       addr=...
  BankonPaimint          app_id=1006       addr=...  asset_id=1009
  X402Verifier           app_id=1007       addr=...
  AgenticPlaceRegistry   app_id=1008       addr=...

Wrote deploy/deployment.json
```

`deploy/deployment.json` is the source of truth for which app id is which.
Keep it under version control if you're doing a real deployment.

---

## 4. Deploy to TestNet

You need:
- A funded TestNet account (https://testnet.algoexplorer.io/dispenser)
- Its 25-word mnemonic

```bash
export NETWORK=testnet
export DEPLOYER_MNEMONIC="word1 word2 ... word25"
python deploy/deploy.py
```

The deployer account needs roughly:

- 8 × 0.1 ALGO (app account MBR per contract)
- 8 × 0.3 ALGO (the script funds each app for inner-txn budget)
- 0.1 ALGO (PAIMINT ASA creation MBR — paid by the BankonPaimint app account)
- ~0.1 ALGO (txn fees for ~30 transactions)

Round up to **~5 ALGO** to be safe.

---

## 5. Deploy to MainNet

Same as TestNet, but be aware of the cost. The full deploy is roughly:

- 0.8 ALGO held as MBR across the 8 app accounts (returned if you ever delete them)
- 2.4 ALGO funded into app accounts as inner-txn budget
- 0.1 ALGO held as the PAIMINT ASA MBR
- ~0.05 ALGO in txn fees

≈ **3.4 ALGO** at deploy time, of which ~3.3 ALGO is recoverable.

```bash
export NETWORK=mainnet
export DEPLOYER_MNEMONIC="word1 word2 ... word25"
python deploy/deploy.py
```

---

## 6. Post-deploy: wire up roles

The deploy script handles two of the three wiring steps automatically:

✅ `registry.set_mindx(mindx_app_id, deployer_address_as_oracle)` —
   uses the deployer as the mindX oracle by default. **Rotate this** to
   the actual mindX backend operator key in production (see step 6.1).

✅ `paimint.bootstrap_asset(...)` — creates the PAIMINT ASA.

❌ Granting CHARGER_ROLE to publisher contracts — manual.
❌ Granting CONSUMER_ROLE on x402 to consumer contracts — manual.
❌ Rotating the mindX oracle to the production hot key — manual.

### 6.1. Rotate the mindX oracle to the production hot key

```python
from algokit_utils import AlgorandClient, SigningAccount
from algosdk import mnemonic
import json

deployment = json.load(open("deploy/deployment.json"))
algorand = AlgorandClient.mainnet()  # or testnet
admin = SigningAccount(
    private_key=mnemonic.to_private_key("admin 25 words..."),
    address="ADMIN_ADDR",
)

mindx_app_id = next(a["app_id"] for a in deployment["apps"] if a["name"] == "MindXBridge")
registry_app_id = next(a["app_id"] for a in deployment["apps"] if a["name"] == "AgenticPlaceRegistry")
prod_oracle_addr = "PROD_ORACLE_ADDRESS_HERE"

# 1. Rotate mindX bridge's oracle
algorand.send.app_call_method_call({
    "app_id": mindx_app_id,
    "method": "set_oracle",
    "args": [prod_oracle_addr],
    "sender": admin.address,
    "signer": admin,
})

# 2. Update the registry to expect the same oracle
algorand.send.app_call_method_call({
    "app_id": registry_app_id,
    "method": "set_mindx",
    "args": [mindx_app_id, prod_oracle_addr],
    "sender": admin.address,
    "signer": admin,
})
```

### 6.2. Grant CHARGER role to a PAIMINT publisher contract

```python
paimint_app_id = next(a["app_id"] for a in deployment["apps"] if a["name"] == "BankonPaimint")
publisher_app_address = "PUBLISHER_APP_ADDRESS"  # e.g. THOT publisher contract

algorand.send.app_call_method_call({
    "app_id": paimint_app_id,
    "method": "grant_charger",
    "args": [publisher_app_address],
    "sender": admin.address,
    "signer": admin,
})
```

### 6.3. Grant CONSUMER role on x402 to consumer contracts

```python
x402_app_id = next(a["app_id"] for a in deployment["apps"] if a["name"] == "X402Verifier")
consumer_app_address = "CONSUMER_APP_ADDRESS"

algorand.send.app_call_method_call({
    "app_id": x402_app_id,
    "method": "grant_consumer",
    "args": [consumer_app_address],
    "sender": admin.address,
    "signer": admin,
})
```

### 6.4. Rotate the x402 operator (parsec-wallet operator)

Same pattern as the mindX oracle rotation:

```python
algorand.send.app_call_method_call({
    "app_id": x402_app_id,
    "method": "set_operator",
    "args": [parsec_wallet_operator_address],
    "sender": admin.address,
    "signer": admin,
})
```

---

## 7. Smoke test the deployed stack

A minimal end-to-end test that exercises every contract:

```python
from frontend_helper.agentic_client import (
    AgenticPlaceClient,
    AgentType,
    MindXPlan,
    TrustModel,
)
from algokit_utils import SigningAccount
from algosdk import mnemonic
import json

deployment = json.load(open("deploy/deployment.json"))
app_ids = {a["name"]: a["app_id"] for a in deployment["apps"]}
paimint_asset_id = next(
    a["asset_id"] for a in deployment["apps"] if a["name"] == "BankonPaimint"
)

user = SigningAccount(
    private_key=mnemonic.to_private_key("user 25 words..."),
    address="USER_ADDR",
)

client = AgenticPlaceClient.testnet(
    signer=user,
    anft_app_id=app_ids["ANFT"],
    dnft_app_id=app_ids["DNFT"],
    inft_app_id=app_ids["INFT"],
    thot_app_id=app_ids["THOT"],
    registry_app_id=app_ids["AgenticPlaceRegistry"],
    mindx_app_id=app_ids["MindXBridge"],
    paimint_app_id=app_ids["BankonPaimint"],
    x402_app_id=app_ids["X402Verifier"],
)

# 1. Mint a 1024-dim THOT
mint = client.mint_thot(
    name="smoke-test-thot",
    unit_name="STT",
    agent_type=AgentType.ANALYTICAL_PROCESSING,
    description="Smoke test embedding",
    data_cid="QmSmokeTestCID",
    dimensions=1024,
)
print(f"Minted THOT asset_id={mint.asset_id}")

# 2. Register on AgenticPlace
binding_id = client.register_agent(
    nft_app_id=client.thot_app_id,
    asset_id=mint.asset_id,
    mcp_endpoint="https://example.com/mcp",
    a2a_endpoint="https://example.com/a2a",
    trust_models=TrustModel.REPUTATION | TrustModel.CRYPTO_ECONOMIC,
    skills=["smoke", "test"],
)
print(f"Registered binding_id={binding_id.hex()}")

# 3. Subscribe to mindX (Free plan)
expires_at = client.mindx_subscribe(plan=MindXPlan.FREE, payment_microalgos=0)
print(f"mindX subscription expires at unix ts {expires_at}")

# 4. Request a behavior evaluation
job_id = client.mindx_request_behavior_evaluation("QmBehaviorTestCID")
print(f"mindX job_id={job_id.hex()}")

# 5. Opt into PAIMINT
client.paimint_opt_in(asset_id=paimint_asset_id)
print(f"Opted into PAIMINT asset_id={paimint_asset_id}")
print(f"PAIMINT balance: {client.paimint_balance_of(user.address)}")
```

If all five steps succeed without errors, your deploy is healthy.

---

## 8. Hand off to the AgenticPlace frontend

Update `agenticplace.pythai.net/register` (and any other consumer) with
the deployed app ids:

```javascript
// frontend config
const ALGORAND_DEPLOYMENT = {
  network: "mainnet",
  apps: {
    anft:     1001,  // ← from deployment.json
    dnft:     1002,
    inft:     1003,
    thot:     1004,
    mindx:    1005,
    paimint:  1006,
    x402:     1007,
    registry: 1008,
  },
  paimint_asset_id: 1009,
};
```

The register form's mint flow becomes:

1. User fills in the form (name, unit, type, etc.)
2. Frontend builds the ARC-69 metadata JSON (the `Arc69Metadata` helper does this)
3. Frontend calls the appropriate `mint_*` method on the relevant contract
4. After the 3-step mint completes, frontend calls `register` on the registry

For server-side / agent-side automation, use `frontend_helper/agentic_client.py`
directly from Python.

---

## 9. mindX oracle setup

The mindX oracle is the off-chain process that delivers consciousness
attestations and behavior scores. It needs:

- A funded Algorand account (the one set as oracle in step 6.1)
- Access to mindx.pythai.net's compute backend
- A loop that watches the chain for `AttestationRequested` and
  `BehaviorEvaluationRequested` events, runs the workload, and calls
  `deliver_attestation` / `deliver_behavior_score`

A minimal Python sketch:

```python
import time
from frontend_helper.agentic_client import AgenticPlaceClient
from algokit_utils import AlgorandClient, SigningAccount

oracle = SigningAccount(...)
algorand = AlgorandClient.mainnet()
client = AgenticPlaceClient(
    algorand=algorand, signer=oracle,
    mindx_app_id=mindx_app_id, registry_app_id=registry_app_id,
)

while True:
    # In production: subscribe to the indexer for ARC-28 events.
    # For the sketch, just poll a queue your mindX backend writes to.
    pending_jobs = mindx_backend.get_pending_jobs()
    for job in pending_jobs:
        result = mindx_backend.run_evaluation(job.behavior_cid)
        client.mindx_deliver_behavior_score(
            job_id=job.job_id,
            score=result.score,
        )
        # If this iNFT is registered, also push to the registry
        if registry_binding := find_binding(job):
            client.registry_deliver_mindx_result(
                nft_app_id=registry_binding.nft_app_id,
                asset_id=registry_binding.asset_id,
                score=result.score,
                passed=result.score >= 70,
            )
    time.sleep(5)
```

---

## 10. Operational runbook

### Funding app accounts

If an app account runs low on ALGO (boxes growing, lots of inner txns),
top it up:

```python
algorand.send.payment({
    "sender": admin.address,
    "receiver": app_address,
    "amount": 1_000_000,  # 1 ALGO
    "signer": admin,
})
```

### Withdrawing collected fees

Each contract has a `withdraw(amount, receiver)` method, admin-only:

```python
algorand.send.app_call_method_call({
    "app_id": registry_app_id,
    "method": "withdraw",
    "args": [collected_amount, treasury_address],
    "sender": admin.address,
    "signer": admin,
})
```

### Pausing operations

There's no global pause switch by design — each contract is independently
upgradeable via admin rotation. To effectively pause:

- **mindX**: rotate oracle to a dead address. Pending jobs can never be delivered.
- **PAIMINT**: revoke all charger grants. Existing user balances are unaffected.
- **x402**: revoke all consumer grants. No new receipts can be verified.
- **NFT contracts**: set `mint_fee` to a very high number. Existing NFTs unaffected.

### Monitoring

Watch these ARC-28 events on your indexer of choice (8004scan, AlgoExplorer):

| Contract | Event | Why |
| --- | --- | --- |
| ANFT/DNFT/INFT/THOT | `*Minted` | Track new mints |
| INFT | `InftDirectiveRotated`, `InftFrozen` | Detect agent state changes |
| MindXBridge | `Subscribed`, `*Delivered`, `OracleRotated` | Verify oracle is healthy |
| BankonPaimint | `AllowanceApproved`, `PaimintBurned` | Watch for unexpected burn patterns |
| X402Verifier | `ReceiptConsumed`, `OperatorRotated` | Track parsec-wallet activity |
| Registry | `AgentRegistered`, `MindXVerificationDelivered` | Index for the directory |

---

## 11. Upgrade path

These contracts are **not upgradeable in place** by design. To upgrade
behavior:

1. Deploy a new version of the contract (new app id)
2. Migrate state by calling view methods on the old version and writing
   the data to the new one
3. Update the frontend to point at the new app id
4. (Optional) Have the old contract `withdraw` its balance to the new one,
   then leave it deployed but inert

For the registry specifically, off-chain indexers should support reading
from multiple registry app ids during migration.

---

## 12. Security checklist before mainnet

- [ ] Independent third-party audit completed
- [ ] Admin keys held in cold storage / multi-sig
- [ ] mindX oracle keys rotated to production hot key (NOT the deployer)
- [ ] x402 operator key rotated to parsec-wallet's actual operator address
- [ ] PAIMINT charger grants minimised — only known-good publisher contracts
- [ ] Test allowance flow with a small amount before any real burns
- [ ] Verify all 8 contracts' `withdraw` admin == multi-sig address
- [ ] `deployment.json` checked into version control
- [ ] Off-chain indexer subscribing to all ARC-28 events
- [ ] Runbook for oracle key rotation tested on TestNet
- [ ] Disaster recovery plan: what happens if the admin key is lost?

---

## 13. Common errors and fixes

| Error | Fix |
| --- | --- |
| `payment receiver must be application` | Frontend sent the payment to the wrong address. Use `algorand.app.get_by_id(app_id).address`. |
| `payment below mint_fee` | Your payment is < 0.201 ALGO. Bump the `payment_amount` arg. |
| `caller not opted into asset` | Run `paimint_opt_in()` (or asset opt-in for the relevant ASA) first. |
| `not pending owner` | The wrong account is calling `claim`. Only the original `mint` caller can claim. |
| `CID already minted` | THOT CIDs are globally unique. Each tensor needs its own CID. |
| `unsupported dimensions` | THOT only accepts 64/384/512/768/1024. |
| `no allowance from user` | User must call `paimint_approve_charger(charger, amount)` before the burn. |
| `caller is not an authorized consumer` | x402 consumer contract not granted via `grant_consumer`. |
| `receipt expired` | x402 receipt's `expires_at` < now. Generate a new one. |
| `payment round not yet reached` | x402 receipt's `algo_round` is in the future. Wait for the payment to confirm. |
| `invalid payer signature` | The signed digest doesn't match. Use `client.x402_compute_digest(receipt)` to get the exact bytes to sign. |

---

## 14. Going further

- **EVM port**: the same eight contracts exist as Solidity in
  `agenticplace-evm/` (Foundry project). Same ABI shapes so applications
  can target both chains.
- **Cross-chain**: bridge events between EVM and Algorand via mindX as
  the canonical truth source. mindX runs the same workload regardless of
  chain.
- **Indexing**: 8004scan indexes ARC-28 events out of the box. Custom
  indexers can subscribe to specific event types.
- **mindX integration**: see `mindx.pythai.net/redoc` for the full API.
  The bridge contract mirrors that API on chain.

---

## License

MIT OR Apache-2.0
