# tasklist.md
## Production tasklist — every task, in order, to ship x402 on mindX

This is the exact sequence of tasks to go from "I have the codebase" to "I am accepting real USDC payments on Base mainnet." Work through it top to bottom. Don't skip sections — each phase builds on the previous.

**Total time:** 2-3 weeks focused work, assuming familiarity with your existing mindX infrastructure. Longer if you also need to set up container registry, monitoring, and secrets infrastructure from scratch.

**Status key:**
- `[ ]` — not done
- `[x]` — done
- `[~]` — in progress
- `[!]` — blocked (add a note)

---

## PHASE 0 — Environment and prerequisites (Day 1)

### 0.1 Tooling installation

- [ ] Install Python 3.11+ locally
- [ ] Install Foundry: `curl -L https://foundry.paradigm.xyz | bash && foundryup`
- [ ] Verify: `forge --version`, `anvil --version`, `cast --version`
- [ ] Install Podman (or use Docker if you prefer): `podman --version`
- [ ] Install `jq`, `curl`, `git` (usually already there)
- [ ] Confirm `uv` or `pip` available

### 0.2 Repo setup

- [ ] Unzip `mindx-x402.zip` into your workspace
- [ ] Create a new git repo: `git init && git add . && git commit -m "initial import"`
- [ ] Push to your GitHub organization (BANKON, PYTHAI, wherever)
- [ ] Add repo to CI (GitHub Actions is already configured)

### 0.3 Local Python environment

- [ ] Create a virtualenv: `python3 -m venv .venv && source .venv/bin/activate`
- [ ] Install in editable mode: `pip install -e ".[dev]"`
- [ ] Verify x402 SDK: `python -c "import x402; print(x402.__version__)"` → should print 2.6.0 or later
- [ ] Run the unit tests: `pytest tests/test_middleware.py -v` → should pass

### 0.4 Wallet creation (testnet)

- [ ] Generate receiving wallet: `cast wallet new` → save address as `TEST_PAY_TO`
- [ ] Save private key in a password manager as `TEST_PAY_TO_KEY` (not in git)
- [ ] Generate agent wallet: `cast wallet new` → save address as `TEST_AGENT`
- [ ] Save agent private key as `TEST_AGENT_KEY`

### 0.5 Fund testnet wallets

- [ ] Visit `https://faucet.circle.com`, select Base Sepolia, paste `TEST_AGENT` address
- [ ] Wait ~1 min; confirm balance with `cast call $USDC_SEPOLIA "balanceOf(address)(uint256)" $TEST_AGENT --rpc-url https://sepolia.base.org` → should be non-zero
- [ ] Get Sepolia ETH from `https://bridge.base.org` or `https://coinbase.com/faucets/base-ethereum-sepolia-faucet` for `TEST_AGENT` (small amount, for any non-gasless ops)

**Phase 0 done when:** you have tooling installed, the codebase committed, unit tests passing, and two funded Sepolia wallets.

---

## PHASE 1 — Local development and testing (Days 2-4)

### 1.1 Configure local .env

- [ ] Copy `.env.example` to `.env`
- [ ] Set `MINDX_ENV=development`
- [ ] Set `PAY_TO_ADDRESS` to your `TEST_PAY_TO` address
- [ ] Set `X402_NETWORK=eip155:84532`
- [ ] Set `USDC_ASSET_ADDRESS=0x036CbD53842c5426634e7929541eC2318f3dCF7e`
- [ ] Set `FACILITATOR_URL=https://x402.org/facilitator`
- [ ] Leave `CDP_API_KEY_*` blank for now
- [ ] Leave `BANKON_*` and `BONAFIDE_*` disabled/blank

### 1.2 Run the server locally

- [ ] Run: `uvicorn mindx.api.main:app --port 8000 --loop asyncio`
- [ ] Confirm startup logs show correct config
- [ ] Visit `http://localhost:8000/health` → `{"status": "ok"}`
- [ ] Visit `http://localhost:8000/redoc` → see four paid endpoints with `x-402` metadata

### 1.3 Test the 402 flow manually

- [ ] Call paid endpoint without payment: `curl -i http://localhost:8000/pay/api/v1/reason?question=test`
- [ ] Confirm response is `402 Payment Required`
- [ ] Confirm `PAYMENT-REQUIRED` header is present
- [ ] Decode the header, verify it matches your config:
  ```bash
  curl -si http://localhost:8000/pay/api/v1/reason?question=test \
    | grep -i "PAYMENT-REQUIRED" | cut -d: -f2- | tr -d ' \r' | base64 -d | jq
  ```

### 1.4 Test the 402 → sign → 200 flow

- [ ] Export agent key: `export AGENT_PRIVATE_KEY=$TEST_AGENT_KEY`
- [ ] Run: `python agents/example_agent.py http://localhost:8000`
- [ ] Confirm all three calls succeed (health, reason, socratic)
- [ ] Extract the transaction hash from the settlement receipt
- [ ] Verify on Basescan: `https://sepolia.basescan.org/tx/<hash>`
- [ ] Confirm the transaction transferred USDC from `TEST_AGENT` to `TEST_PAY_TO`

### 1.5 Test audit logging

- [ ] Check `/var/log/mindx/payments.jsonl` (or wherever you configured it)
- [ ] Confirm there are JSONL entries for each paid call
- [ ] Verify each entry has: `ts`, `route`, `payer`, `tx_hash`, `amount`, `network`

### 1.6 Replace placeholder handlers with real inference

- [ ] In `mindx/api/routes/reasoning.py`, replace the stub body of `reason()` with an actual call to your reasoning backend (Ollama, funAGI, your mindX engine)
- [ ] Same for `socratic()`, `dream()`, `discover_agents()`
- [ ] Re-run the agent: confirm real answers come back, not placeholders

### 1.7 Run Foundry tests

- [ ] `cd contracts && forge install foundry-rs/forge-std --no-commit`
- [ ] `forge build` → compiles clean
- [ ] `forge test --fork-url https://sepolia.base.org -vv` → all tests pass (or document known failures)

**Phase 1 done when:** you've made a real testnet USDC payment end-to-end, verified it on Basescan, and have replaced placeholder logic with real inference calls.

---

## PHASE 2 — Infrastructure and CI/CD (Days 5-8)

### 2.1 Containerization

- [ ] Build the image: `podman build -t mindx-x402:dev -f Containerfile .`
- [ ] Run the container: `podman run -p 8000:8000 --env-file .env mindx-x402:dev`
- [ ] Confirm same behavior as running uvicorn directly
- [ ] Test `podman-compose up` with the compose file (runs mindX + anvil fork together)

### 2.2 Container registry

- [ ] Pick a registry: GitHub Container Registry (ghcr.io), Docker Hub, or your own
- [ ] Configure podman/docker to authenticate to it
- [ ] Push a test image: `podman push mindx-x402:dev ghcr.io/yourorg/mindx-x402:dev`
- [ ] Update `.github/workflows/deploy.yml` with your registry details

### 2.3 Secrets management

- [ ] Decide: GCP Secret Manager, AWS Secrets Manager, HashiCorp Vault, or equivalent
- [ ] If GCP Secret Manager, create a project for secrets (or use existing `deltaverse-prod`)
- [ ] Create secrets (empty values for now; fill in phase 3):
  - [ ] `MINDX_MAINNET_PAY_TO`
  - [ ] `CDP_API_KEY_ID`
  - [ ] `CDP_API_KEY_SECRET`
- [ ] Configure your deployment environment's service account with `secretmanager.secretAccessor` role
- [ ] Test locally: `MINDX_ENV=production python -c "from mindx.config.secrets import get_secret; print(get_secret('MINDX_MAINNET_PAY_TO'))"`

### 2.4 CI pipeline

- [ ] Push the repo to GitHub
- [ ] Verify `.github/workflows/test.yml` runs on push
- [ ] Confirm Python unit tests pass in CI
- [ ] Confirm Foundry tests run (may have intermittent failures against public RPC; set `continue-on-error` or use a paid RPC)

### 2.5 Hosting environment

- [ ] Decide where to run: Cloud Run, ECS, Kubernetes, bare metal with systemd
- [ ] Provision one staging instance of the chosen infrastructure
- [ ] Deploy the dev image to staging
- [ ] Confirm staging is reachable and healthy via `/health` endpoint
- [ ] Set up HTTPS (via Cloudflare, CDN, or load balancer)

### 2.6 Domain and DNS

- [ ] Point `mindx.pythai.net` (or your chosen subdomain) at staging first
- [ ] Verify TLS cert is valid
- [ ] Test paid endpoint flow through the real domain with testnet wallet
- [ ] Prepare to switch to production DNS once mainnet testing passes

**Phase 2 done when:** the container builds clean, is pushed to a registry, deploys to a staging environment, and responds correctly to both free and paid (testnet) calls through a real TLS-protected domain.

---

## PHASE 3 — Production wallet setup (Days 9-10)

### 3.1 Coinbase Developer Platform account

- [ ] Sign up at `https://portal.cdp.coinbase.com`
- [ ] Verify business/identity per their KYC
- [ ] Create an API key: Settings → API Keys → Create
- [ ] Copy `CDP_API_KEY_ID` and `CDP_API_KEY_SECRET` immediately (secret shown once)
- [ ] Store both in your secrets manager under those names
- [ ] Test the facilitator is reachable:
  ```bash
  curl -H "Authorization: Bearer $CDP_API_KEY_SECRET" \
    https://api.cdp.coinbase.com/platform/v2/x402/supported
  ```

### 3.2 Mainnet receiving wallet — the critical decision

Pick one path:

**Path A: GCP Cloud KMS (recommended for production)**
- [ ] Create a KMS keyring in your GCP project
- [ ] Create a signing key with protection level `HSM`
- [ ] Configure service account to sign with this key
- [ ] Derive the Ethereum address from the KMS public key
- [ ] Save the derived address as `MINDX_MAINNET_PAY_TO` in Secret Manager
- [ ] Test signing: use `eth-account` or `web3.py` with KMS backend to sign a test transaction

**Path B: Cold storage (simpler, less frequent withdrawals)**
- [ ] On an air-gapped machine, generate wallet: `cast wallet new`
- [ ] Write down the private key on paper, store in a safe
- [ ] OR: write the key to a hardware wallet (Ledger, Trezor) via their tooling
- [ ] Save the public address as `MINDX_MAINNET_PAY_TO` in Secret Manager
- [ ] Plan to periodically (weekly? monthly?) bring the key online briefly to drain accumulated USDC

**Path C: Hot wallet in Secret Manager (acceptable for small scale)**
- [ ] Generate wallet: `cast wallet new`
- [ ] Save private key to Secret Manager as `MINDX_MAINNET_PAY_TO_KEY`
- [ ] Save public address as `MINDX_MAINNET_PAY_TO`
- [ ] **Risk:** if Secret Manager is compromised, funds are at risk. Only use if daily balance is small ($<1000).

### 3.3 Production configuration

- [ ] Set `MINDX_ENV=production` in the production deployment environment
- [ ] Confirm all required secrets exist in Secret Manager:
  - [ ] `MINDX_MAINNET_PAY_TO`
  - [ ] `CDP_API_KEY_ID`
  - [ ] `CDP_API_KEY_SECRET`
- [ ] Update deployment env vars:
  - [ ] `X402_NETWORK=eip155:8453`
  - [ ] `USDC_ASSET_ADDRESS=0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`
  - [ ] `FACILITATOR_URL=https://api.cdp.coinbase.com/platform/v2/x402`

**Phase 3 done when:** you have a production wallet with a secure key management setup, CDP credentials are in your secrets manager, and production config is ready.

---

## PHASE 4 — Pre-mainnet validation (Days 11-13)

### 4.1 Sepolia dogfooding

- [ ] Run the staging deployment (on Base Sepolia) for at least 7 days
- [ ] Every day, check:
  - [ ] Health endpoint responds
  - [ ] At least one test payment per day (use the example agent)
  - [ ] Audit log is being written
  - [ ] No unexpected errors in server logs
  - [ ] Reconciliation script passes clean
- [ ] Fix any issues before proceeding

### 4.2 Test matrix execution

Work through the full pre-mainnet matrix on Sepolia:

- [ ] Valid payment with fresh nonce → 402 → sign → 200 with PAYMENT-RESPONSE
- [ ] Expired authorization (craft one with validBefore in past) → facilitator rejects
- [ ] Replayed nonce (submit same auth twice) → USDC contract reverts
- [ ] Wrong chain ID in EIP-712 domain (craft manually) → signature fails
- [ ] Insufficient USDC balance (drain test wallet, then try to pay) → settlement fails gracefully
- [ ] Wrong USDC contract address (craft auth against wrong address) → EIP-712 domain mismatch
- [ ] Multiple concurrent payments from same payer → both succeed with different nonces
- [ ] BANKON check fails (if enabled): agent without identity → 403
- [ ] BONAFIDE discount applies (if enabled): high-rep agent → reduced price in 402
- [ ] Free endpoint accessed without payment → 200, no 402
- [ ] API-key endpoint with valid key → 200, x402 bypassed (when /free mount is active)

### 4.3 Monitoring setup

- [ ] Pick a metrics backend: Prometheus/Grafana, Datadog, CloudWatch, whatever you already use
- [ ] Emit metrics from the FastAPI app:
  - [ ] Request count by endpoint
  - [ ] 402 response count
  - [ ] Settlement success/failure count
  - [ ] Settlement latency (p50, p95, p99)
  - [ ] USDC balance of receiving wallet
- [ ] Build a dashboard showing these
- [ ] Set alerts:
  - [ ] Settlement failure rate > 5% over 5 min → page on-call
  - [ ] Facilitator reachability failure → page
  - [ ] Receiving wallet balance change > threshold → notification
  - [ ] Audit log not growing while traffic is flowing → critical alert

### 4.4 Reconciliation automation

- [ ] Deploy `scripts/reconcile_daily.py` as a cron job in production environment
- [ ] Route its output to a log aggregator and/or Slack channel
- [ ] Run once manually to confirm it works on staging data
- [ ] Plan for 1-business-day response to any reconciliation failure

### 4.5 Rollback plan

- [ ] Document exact steps for each rollback scenario:
  - [ ] Disable x402 (deploy image without `install_x402`)
  - [ ] Point facilitator at a different URL
  - [ ] Revert to previous image
  - [ ] Emergency wallet rotation
- [ ] Test one rollback scenario on staging (not in production, unless you can afford downtime)
- [ ] Ensure the runbook is accessible from on-call's phone

### 4.6 Operational runbook

- [ ] Write a short runbook document with:
  - [ ] How to deploy
  - [ ] How to roll back
  - [ ] How to issue a refund
  - [ ] How to investigate a reconciliation failure
  - [ ] Contact info for CDP support
  - [ ] Contact info for Base chain status
- [ ] Share with anyone who might be on-call

**Phase 4 done when:** you have run on Sepolia for a week without issue, the test matrix fully passes, monitoring is live, and you have a tested rollback.

---

## PHASE 5 — Mainnet canary deployment (Day 14)

### 5.1 Pre-deployment check

- [ ] All phase 4 checkboxes complete
- [ ] Production wallet is set up and you know where the private key is
- [ ] Monitoring dashboard is up and green
- [ ] Refund script is tested on Sepolia
- [ ] On-call rotation knows today is go-live

### 5.2 Deploy to canary

- [ ] Tag the release: `git tag v1.0.0-mainnet-canary && git push --tags`
- [ ] Deploy to production infrastructure with **5% traffic share** (via load balancer weight, Kubernetes canary, or whatever mechanism you use)
- [ ] The other 95% continues serving non-paid endpoints only (or the previous free-tier implementation)
- [ ] Verify the canary instance starts cleanly
- [ ] Check `/health/config` on the canary → shows production config

### 5.3 First mainnet transaction

From your own wallet (not an external agent, for the first call):

- [ ] Fund a wallet you control with $1 of real USDC on Base
- [ ] Point `agents/example_agent.py` at your production URL
- [ ] Make one call to the cheapest endpoint (`$0.001`)
- [ ] Verify:
  - [ ] Response is 200
  - [ ] `PAYMENT-RESPONSE` header is present
  - [ ] Your agent wallet was debited $0.001 (less $0 gas since CDP absorbs it)
  - [ ] Production `payments.jsonl` has the entry
  - [ ] CDP dashboard shows the settlement
  - [ ] Basescan at `https://basescan.org/tx/<hash>` shows the transfer
- [ ] Confirm receiving wallet balance increased by 1,000 USDC base units (=$0.001)

### 5.4 Hold at 5% for 24 hours

- [ ] Watch error rates every few hours
- [ ] Check audit log is growing at expected rate given traffic share
- [ ] Run `scripts/reconcile_daily.py` manually at end of 24h
- [ ] Any unexpected failures → pause and investigate

### 5.5 Ramp to 25%

- [ ] Increase traffic weight to 25% / 75%
- [ ] Watch metrics for 24h
- [ ] Check reconciliation
- [ ] Confirm: error rate stable, latency stable, no surprises

### 5.6 Ramp to 50%

- [ ] Increase traffic weight to 50% / 50%
- [ ] Watch metrics for 24h

### 5.7 Ramp to 100%

- [ ] Cut all traffic to the x402-enabled deployment
- [ ] Decommission the old deployment
- [ ] Announce go-live to users/community

**Phase 5 done when:** 100% of mainnet traffic goes through the x402-enabled deployment, monitoring is clean, and reconciliation has passed at every stage.

---

## PHASE 6 — Post-launch operations (Ongoing)

### 6.1 Daily (business days)

- [ ] Check monitoring dashboard — 5 min
- [ ] Review reconciliation report — 2 min
- [ ] Check receiving wallet balance — 30 sec
- [ ] Respond to any alerts, refund requests, or support tickets

### 6.2 Weekly

- [ ] Review x402 SDK release notes for any upgrades
- [ ] Review Coinbase CDP changelog
- [ ] Review Base chain status and any upcoming network events
- [ ] Check for unusual patterns in audit log (same wallet paying abnormally often, geographic anomalies)

### 6.3 Monthly

- [ ] Drain accumulated USDC to treasury (unless hot wallet is already at target balance)
- [ ] Review pricing — is it still aligned with compute cost?
- [ ] Review which endpoints are getting traffic — decommission unused ones
- [ ] Review dispute/refund rate — if high, investigate root cause

### 6.4 Quarterly

- [ ] Rotate CDP API keys
- [ ] Review secrets manager access list
- [ ] Review rollback plan; update if infrastructure has changed
- [ ] Test one disaster scenario end-to-end on staging

### 6.5 Annually

- [ ] Rotate the receiving wallet key (new wallet, drain old)
- [ ] Full security audit of the integration
- [ ] Review whether to add additional chains (Algorand via GoPlausible, Solana, etc.)
- [ ] Tax reporting: reconcile payments with on-chain records for the fiscal year

---

## PHASE 7 — Optional enhancements (After phase 5 stable)

### 7.1 Add BANKON identity gating

- [ ] Deploy `BankonRegistry.sol` to Base mainnet via Foundry
- [ ] Verify the contract on Basescan
- [ ] Set `BANKON_REGISTRY_CONTRACT` in production env
- [ ] Populate the registry with known agent→Algorand mappings (coordinate with BANKON identity service)
- [ ] Set `BANKON_ENABLED=true` and `BANKON_MODE=soft` (surcharge unverified, don't reject)
- [ ] Monitor for a week — how many calls are unverified? What's the revenue impact of the surcharge?
- [ ] If signal is positive, move to `BANKON_MODE=strict` (reject unverified)

### 7.2 Add BONAFIDE reputation pricing

- [ ] Confirm BONAFIDE Tessera contract is deployed on Base
- [ ] Set `BONAFIDE_TESSERA_CONTRACT` in production env
- [ ] Set `BONAFIDE_ENABLED=true`
- [ ] Monitor for a week — are discounts being applied? How many agents qualify?
- [ ] Tune the discount tiers in `mindx/x402_integration/reputation.py` based on score distribution

### 7.3 Add `upto` scheme for variable-cost inference

- [ ] Wait for `upto` scheme to be stable in x402 SDK (check release notes)
- [ ] Update `middleware.py` to register `UptoEvmServerScheme`
- [ ] Update `pricing.py` with maximum prices
- [ ] Update route handlers to report actual compute consumption
- [ ] Deploy to staging, verify settlement amounts match actual usage

### 7.4 Add Algorand as second chain

- [ ] Set up GoPlausible facilitator access
- [ ] Create Algorand mainnet receiving wallet
- [ ] Opt the wallet in to USDC ASA (asset ID 31566704)
- [ ] Add Algorand `PaymentOption` to each route's `accepts` list
- [ ] Update discovery endpoint to advertise both chains
- [ ] Test end-to-end with an Algorand-funded agent

### 7.5 AgenticPlace discovery endpoint

- [ ] Build `/api/v1/services` on agenticplace.pythai.net (new FastAPI route or static JSON)
- [ ] List mindX and any other x402-enabled services
- [ ] Include price, endpoints, required identity
- [ ] Update `allchain.html` to link to the discovery JSON
- [ ] Publish the discovery URL to the x402 Bazaar (if using it)

### 7.6 Build a PHP x402 library

(From the playbook's Section 10 — optional community contribution.)

- [ ] Fork the x402 spec from `github.com/coinbase/x402`
- [ ] Create `pythai/x402-php` package
- [ ] Implement server middleware (Laravel, Slim, or plain PSR-7)
- [ ] Implement client helpers for EIP-712 signing (use `kornrunner/keccak`, `kornrunner/secp256k1`)
- [ ] Publish to Packagist
- [ ] Open a PR against awesome-x402 to add it to the registry

---

## PHASE 8 — Expansion (Months 2+)

### 8.1 Additional endpoints

- [ ] Add any mindX endpoints currently out of scope
- [ ] Gate them behind x402 via `BASE_PRICES` config
- [ ] No code change needed beyond the price dict

### 8.2 Fallback facilitator

- [ ] Evaluate alternative facilitators (0xmeta.ai, Cloudflare, GoPlausible)
- [ ] Implement `FallbackFacilitator` wrapper in `middleware.py`
- [ ] Deploy with primary=CDP, fallback=alternative
- [ ] Monitor failover behavior

### 8.3 Self-hosted facilitator

(Only if volume justifies ~$600/month in subsidized gas plus engineering burden.)

- [ ] Study the facilitator spec at `github.com/coinbase/x402`
- [ ] Implement /verify and /settle endpoints in a new service
- [ ] Fund the facilitator wallet with ETH for gas
- [ ] Deploy redundantly (multiple regions)
- [ ] Add monitoring for wallet balance, settlement queue depth, error rates
- [ ] Switch your own mindX service to use your facilitator first, CDP as fallback

### 8.4 Economic analysis

- [ ] At 30-day mark post-launch, analyze:
  - [ ] Revenue per endpoint
  - [ ] Cost per call (upstream LLM + infra)
  - [ ] Gross margin
  - [ ] Which agents are the biggest payers (consider volume discounts)
  - [ ] Which endpoints are most profitable
- [ ] Adjust prices accordingly
- [ ] Consider deprecating low-margin endpoints or raising their prices

---

## Quick reference: common commands

```bash
# Run locally
uvicorn mindx.api.main:app --port 8000 --loop asyncio

# Run unit tests
pytest tests/test_middleware.py -v

# Run Foundry tests
cd contracts && forge test --fork-url https://sepolia.base.org -vvv

# Build container
podman build -t mindx-x402:latest -f Containerfile .

# Run agent against local
export AGENT_PRIVATE_KEY=0x...
python agents/example_agent.py http://localhost:8000

# Check USDC balance
cast call 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  "balanceOf(address)(uint256)" $PAY_TO_ADDRESS \
  --rpc-url https://mainnet.base.org

# Reconcile last 24h
python scripts/reconcile_daily.py

# Refund
./scripts/refund.sh 0xPayer 0.01 "reason" 0xOrigTx

# Drain wallet
cast send 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  "transfer(address,uint256)" \
  $TREASURY_ADDRESS $AMOUNT \
  --rpc-url https://mainnet.base.org \
  --private-key $PAY_TO_PRIVATE_KEY
```

---

## Decision points summary

Each of these decisions has to be made before reaching the relevant phase. Note the answer in your team's wiki.

- **Phase 2:** Which container registry? (ghcr.io | Docker Hub | ECR | GCR)
- **Phase 2:** Which hosting environment? (Cloud Run | ECS | K8s | bare metal)
- **Phase 2:** Which secrets manager? (GCP | AWS | Vault)
- **Phase 3:** Which wallet security model? (KMS | cold storage | hot wallet)
- **Phase 4:** Which monitoring stack? (Prom/Grafana | Datadog | CloudWatch)
- **Phase 5:** Canary ramp strategy? (5/25/50/100 over 3 days | faster | slower)
- **Phase 7:** Enable BANKON identity gating? (off | soft | strict)
- **Phase 7:** Enable BONAFIDE reputation pricing? (off | enabled)
- **Phase 7:** Add Algorand chain? (not yet | soon | now)
- **Phase 8:** Add fallback facilitator? (not yet | yes)
- **Phase 8:** Self-host a facilitator? (probably never | maybe at scale | now)

---

## When you can declare victory

You have successfully shipped x402 on mindX when:

1. Real autonomous agents (not just your test wallets) are making paid calls against production
2. USDC is accumulating in your mainnet receiving wallet
3. Daily reconciliation passes without manual intervention
4. You have not had a security incident involving the receiving wallet key
5. You have handled at least one refund through the documented process
6. You have successfully deployed at least one hot-fix after go-live

When all six are true, congratulations — you are operating a working agentic payment rail. The rest is optimization.
