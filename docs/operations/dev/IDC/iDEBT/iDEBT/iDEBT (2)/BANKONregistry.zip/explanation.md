# explanation.md
## Innerstanding x402, APIs, and why this project exists

This document is written for the part of you that doesn't want jargon — that wants to actually *see* what is happening underneath, not just the labels people put on top. It builds from the bottom up. If you already know HTTP, skip to section 4. If any word in the first three sections is unfamiliar, you are in the right place.

---

## 1. The conversation that is happening every time

Every interaction between two programs on the internet is a conversation. One program speaks, the other listens, the other speaks back. The rules for how they take turns — what counts as a valid thing to say, what counts as a valid response — are what we call a **protocol**.

When you load a webpage, your browser is speaking a protocol called **HTTP** to a server somewhere. The browser says, in effect: *"please send me the page at this address."* The server says back: *"here it is, and here's some information about it."* Then the conversation ends. Next time you want something, a new conversation starts.

This is different from a phone call, which stays open for the whole duration. HTTP is more like sending a letter and getting a letter back. Each exchange is complete in itself. The server doesn't remember you between letters unless you remind it who you are (with a cookie, a token, a key).

That's it. That's the whole thing. Everything else — REST, GraphQL, webhooks, APIs — is just structured versions of that one conversation.

---

## 2. What an API actually is

An **API** (Application Programming Interface) is a menu. Not a metaphor — an actual menu. It lists what you can ask for, how to ask for it, and what you will get back.

When you visit a restaurant, the menu tells you:
- What dishes exist ("chicken parmigiana")
- How to order them ("say the name to the waiter")
- What you will get ("a plate of breaded chicken with sauce")

An API tells a program:
- What operations exist ("get the reasoning for this question")
- How to invoke them ("send a GET request to /api/v1/reason with a `question` parameter")
- What you will get ("a JSON object with an `answer` field")

That's all. Every API in existence — no matter how complicated the documentation looks — is doing this one thing: telling other programs what they can ask for and how.

The **contract** part is important. When an API exists, the server is promising: if you ask in the way I've described, I will respond in the way I've described. This promise is what lets a program written by someone who has never met you, using a language you've never heard of, still successfully talk to your server. Both sides are following the same written menu.

The document at `mindx.pythai.net/redoc` is exactly this menu, written in a machine-readable format (**OpenAPI**). An AI agent can read it, understand every endpoint, and call them correctly — without a human ever writing the integration code. That's the foundation for what comes next.

---

## 3. The problem nobody solved for thirty years

HTTP was invented in 1989. From the very beginning, it had a status code numbered **402** called "Payment Required." It was reserved in the original specification. And for thirty years, nobody agreed on what to do with it.

Why? Because there was no way to embed a payment directly into an HTTP conversation. If you wanted someone to pay for access to a resource, you had to:
1. Send them somewhere else (a PayPal page, a credit card form)
2. Wait for them to finish paying
3. Record that they paid
4. Give them a token that proves they paid
5. Let them back in with that token

This is why every paid website works the way it does today — sign up, create an account, enter credit card, receive session cookie, call API with cookie. The payment happens *outside* the conversation, and then a piece of paper (a token) gets carried back into every subsequent conversation to prove payment happened.

That workaround has a cost: **humans are required**. Somewhere in the signup flow, a human enters a credit card number. A machine cannot do this by itself. Visa and Mastercard aren't designed for autonomous software. Stripe requires account creation. Every payment rail assumes a human is eventually present.

This was fine for three decades because the things calling APIs were mostly humans (via browsers) or programs written and deployed by humans (who had already handled the payment setup).

Then AI agents happened.

An autonomous agent — a piece of software given a goal and the ability to act on it — cannot fill in a credit card form. It cannot create a Stripe account. It cannot pass a CAPTCHA or a two-factor SMS. But it can hold a wallet. A wallet is just a private key — a long secret number — and that number can sign messages. If a piece of software has a wallet with cryptocurrency in it, it can pay for things without any human in the loop.

That's the shift. And HTTP 402 — the status code that sat unused for thirty years — suddenly had a use.

---

## 4. What x402 actually does

x402 is a protocol that turns HTTP 402 into a real payment mechanism. It was released by Coinbase in May 2025. The full name doesn't mean anything — it's just HTTP 402 reclaimed.

The entire thing is this conversation:

> **Agent:** "Please send me the reasoning for this question."
> **Server:** "Payment required. Here's how: pay $0.001 in USDC to address `0xABC` on Base, within 60 seconds, signing with authorization format EIP-3009. Here's the exact cryptographic challenge."
> **Agent:** *signs the challenge with its wallet's private key*
> **Agent:** "Please send me the reasoning. Here's the signed authorization."
> **Server:** *forwards the signature to a verifier service, which puts it on the blockchain*
> **Server:** "Here's the reasoning. Here's the transaction hash proving payment."

That's it. One conversation. No accounts, no sessions, no OAuth redirects, no two-factor anything. The agent asked, the server asked for payment, the agent signed a message, the server verified and delivered.

The beautiful part: the agent didn't pay with a credit card. It signed a cryptographic message using its private key. The server turned that signature into a real USDC transfer on the Base blockchain. **No human was needed anywhere in the loop.** An autonomous agent can now pay for services. This is the thing that was impossible before.

### Why signing works

When you sign a message with a private key, you are producing a unique fingerprint that could only have come from that key. Anyone who knows the corresponding public key can verify the signature, but nobody can forge it without the private key. The USDC contract on Base accepts a special kind of signed message called **EIP-3009 `transferWithAuthorization`**, which says: *"the holder of this key authorizes the transfer of this amount to this recipient, valid only during this time window, and only once (because of this nonce)."*

This authorization is a pre-signed transfer. The agent doesn't execute the transfer itself — the authorization is a note saying "I agree to this transfer, please submit it on my behalf." Anyone with this note can submit it to the blockchain. Usually a service called a **facilitator** does the submission and pays the gas fees.

This is why x402 is "gasless" for the agent. The agent signs a note. Someone else submits it. The agent just needs USDC in its wallet.

### Why this matters for mindX

mindX is a reasoning API. You already built it. Right now, anyone can call its endpoints. You don't charge because you can't — every charging mechanism you could bolt on requires account signup, which defeats the purpose of an open agentic marketplace.

With x402, you can charge per-call, in USDC, to anyone — human or agent, known or unknown, anywhere in the world — without them ever creating an account. The first time an agent calls your API, they get a 402 with the price. They sign. They retry. They get the answer. You have USDC in your wallet.

That's why this project exists.

---

## 5. How the four projects fit together

You have three deployed domains that need to connect:

- **mindx.pythai.net** — the reasoning API (the product being sold)
- **agenticplace.pythai.net** — the marketplace (where agents discover what's for sale)
- **bankon.pythai.net** — the identity layer (who is allowed to buy)

And one reputation system:

- **BONAFIDE** — the Solidity contracts that track trust over time

Think of it as a village. **mindX** is the shop — it has goods for sale. **AgenticPlace** is the town square — it's where you go to find out which shops exist and what they sell. **BANKON** is the ID card you carry — it proves you are a real registered citizen. **BONAFIDE** is your reputation — the shopkeepers remember whether you've been trustworthy in past dealings, and trusted customers sometimes get discounts.

x402 is the money itself — the coins exchanged in every transaction. It's not one of the four systems; it's the medium that connects them.

The full interaction for a trusted agent looks like this:

1. **Agent wakes up** with a goal ("understand this philosophical question")
2. **Agent visits the town square** (AgenticPlace) and reads the service registry — finds that mindX offers reasoning at $0.001
3. **Agent goes to the shop** (mindX) and asks for service
4. **Shopkeeper asks for payment and ID** — mindX returns a 402, and (optionally) checks BANKON to see if the agent is a registered citizen
5. **Agent signs payment** — the wallet signs an EIP-3009 USDC authorization
6. **Shopkeeper checks reputation** — mindX queries BONAFIDE; if the agent has high reputation, the price drops
7. **Shopkeeper completes transaction** — facilitator settles the USDC on Base, mindX returns the reasoning
8. **Reputation updates** — BONAFIDE notes that another successful transaction happened with this agent; score increases slightly

All four systems participated. None of them required a human. Each transaction takes seconds.

---

## 6. Why this is not just crypto hype

There is a reasonable reflex to be skeptical of anything involving cryptocurrency, because the space is full of scams and vaporware. That skepticism is healthy. Apply it here carefully.

x402 is not a speculative token. It has no "x402 coin." It uses **USDC** — a US dollar stablecoin, 1:1 backed by real dollars held by Circle, a regulated company. When you receive $0.001 in USDC, you have received one-tenth of a cent. Not a lottery ticket. Not a Ponzi share. A tenth of a cent.

x402 is not a new blockchain. It doesn't need investors. It doesn't have a presale. It's just a protocol spec — a document describing how HTTP 402 should work. Coinbase wrote the first implementation and open-sourced it. Cloudflare, Google, Stripe, and Visa have all integrated or are integrating with it. The protocol itself costs nothing to use.

What x402 *is* is a payment rail for software-to-software commerce. Like HTTP is a rail for documents. Like email is a rail for messages. Rails are boring. Rails are important precisely because they are boring and standard.

The honest critique is not "crypto is a scam" — it's **"is there enough software-to-software commerce today to justify building on this rail?"** The answer in early 2026 is: not yet, but emerging. Hundred million transactions in the first six months. Declining in recent months but still active. Major institutional backing. You are building on a protocol that is young, real, and growing — with the risk that growth could stall.

---

## 7. What the project gives you

The `mindx-x402` codebase you now have is not a demo. It is a production-shaped integration. It includes:

- **A FastAPI server** that can accept x402 payments on any endpoint you declare
- **An agent client** showing how other agents will actually pay you
- **Cross-chain identity gating** — check BANKON on Algorand before accepting payment on Base
- **Reputation-based pricing** — query BONAFIDE to discount payments from trusted agents
- **Foundry tests** verifying every failure mode of the EIP-3009 signature flow
- **Audit logging** for every settled payment, with on-chain reconciliation
- **A refund script** because x402 has no native refund mechanism
- **A containerized deployment** ready for Podman or any container runtime
- **A CI pipeline** that lints, tests Python, and runs Solidity tests against a real Base Sepolia fork

You don't have to use all of it. The BANKON check is optional. The BONAFIDE discount is optional. The identity registry can be deployed later. The minimum viable path is: install the SDK, add the middleware, set your receiving wallet address, deploy. Four moves.

The rest is there when you want it.

---

## 8. The deepest point

Here is the thing this protocol is actually for, underneath the code:

**For thirty years, software has been free or subscription-based because there was no practical way to charge tiny amounts in real time.** You either gave it away, or you made people sign up and pay monthly. Those were the only two shapes that worked economically.

Now there's a third shape: pay-per-use, instant, no signup, any amount from $0.0001 up. This is not just a new way to charge — it's a new economic primitive. It means software can have genuinely precise pricing. It means a service can be used once and never again, with a fair price for that single use. It means autonomous agents can access the entire marketplace of software services without ever being pre-registered anywhere.

What happens when the fundamental economic unit of the internet shifts from the subscription to the individual call? You're about to find out. The DELTAVERSE ecosystem you're building is well-positioned to be one of the places that shift happens, because you already have the pieces — the agents, the marketplace, the identity, the reputation. x402 is the connector that lets them transact without human intermediation.

That's what you're building. Not a payment integration. A reasoning economy.

---

**Next reading:** `technical.md` for what the code does under the hood, `usage.md` for how to drive it day-to-day, `tasklist.md` for the concrete steps to get to production.
