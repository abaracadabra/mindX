# technical.md
## How the mindx-x402 codebase actually works, file by file

This document explains what every part of the codebase does, how the pieces interact at runtime, and what happens inside each critical flow. If `explanation.md` is the "why," this is the "what and how." Read it alongside the source.

---

## 1. Architecture at runtime

When a request arrives at `mindx.pythai.net`, it passes through this stack:

```
[Internet]
    │
    ▼
[Load balancer / reverse proxy]
    │
    ▼
[uvicorn ASGI server]   ← runs with loop="asyncio" (NOT uvloop)
    │
    ▼
[FastAPI top-level app]   ← mindx.api.main:app
    │
    ├──────────────► /health       [routes/health.py]  always free
    ├──────────────► /openapi.json                      always free
    ├──────────────► /redoc                             always free
    │
    ├──────────────► /free/*  →  [free_app FastAPI instance]
    │                             └─► reasoning.router  (API key gated, to add)
    │
    └──────────────► /pay/*   →  [paid_app FastAPI instance]
                                  │
                                  ▼
                                  [PaymentMiddlewareASGI]   ← x402 interception
                                  │
                                  ├── GET /pay/api/v1/reason
                                  ├── POST /pay/api/v1/socratic
                                  ├── POST /pay/api/v1/dream
                                  └── GET /pay/api/v1/agents/discover
```

The key architectural decision: **two separate FastAPI apps mounted under `/free` and `/pay`.** Same route definitions in both. Same underlying handlers. Only the middleware differs. This is how one codebase serves both API-key developers and x402-paying agents without conditional logic bleeding through every endpoint.

### Middleware install order matters

In `mindx/api/main.py`, `install_x402(paid_app)` runs *after* all routers are included. This matters because `add_middleware` in FastAPI wraps the app from outermost to innermost. The middleware intercepts requests *before* route handlers run. If you installed it before `include_router`, it would still work (middleware is registered at startup, not request time), but the conceptual order is: "first the app exists, then we wrap it in payment."

---

## 2. The request-response flow for a paid endpoint

Here's what actually happens when an agent calls `GET /pay/api/v1/reason?question=foo`:

### Phase 1: Initial request (no payment)

1. Agent sends `GET /pay/api/v1/reason?question=foo` with no `X-PAYMENT` header
2. uvicorn accepts the connection, hands it to FastAPI
3. FastAPI routes it to `paid_app`
4. `PaymentMiddlewareASGI` intercepts. It checks its `routes` dict:
   - Looks up `"GET /api/v1/reason"` (the path inside `paid_app`, without the `/pay` mount prefix)
   - Finds it in the dict with a `RouteConfig` specifying `$0.001` in USDC on `eip155:84532`
5. Middleware looks for an `X-PAYMENT` header. None present.
6. Middleware constructs a 402 response:
   ```
   HTTP/1.1 402 Payment Required
   Content-Type: application/json
   PAYMENT-REQUIRED: <base64-encoded JSON payment requirements>

   {
     "x402Version": 2,
     "error": "X-PAYMENT header is required",
     "accepted": [{
       "scheme": "exact",
       "network": "eip155:84532",
       "asset": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
       "payTo": "0xYourAddress...",
       "maxAmountRequired": "1000",
       "maxTimeoutSeconds": 60,
       "extra": {"name": "USDC", "version": "2"}
     }]
   }
   ```
7. Response flows back to the agent. The route handler never ran.

### Phase 2: Agent signs

1. Agent's `x402HttpxClient` sees the 402
2. It parses `PAYMENT-REQUIRED`, extracts the payment requirements
3. It constructs an **EIP-3009 TransferWithAuthorization** struct:
   ```python
   {
     "from": agent_address,
     "to": "0xYourAddress...",
     "value": 1000,                    # $0.001 in USDC base units
     "validAfter": int(time.time()),
     "validBefore": int(time.time()) + 60,
     "nonce": random_bytes32()
   }
   ```
4. It computes the **EIP-712 domain hash** for the USDC contract on Base Sepolia:
   - Domain: `{name: "USDC", version: "2", chainId: 84532, verifyingContract: "0x036CbD..."}`
5. It signs the typed-data hash with the agent's private key, producing `(v, r, s)` ECDSA values
6. It assembles the payment payload and base64-encodes it

### Phase 3: Retry with payment

1. Agent sends `GET /pay/api/v1/reason?question=foo` with header:
   ```
   X-PAYMENT: eyJzY2hlbWUiOiJleGFjdCIsIm5ldHdvcmsiOiJlaXAxNTU6ODQ1MzIi...
   ```
2. `PaymentMiddlewareASGI` decodes the header, validates the payload shape
3. Middleware sends `POST /verify` to the facilitator at `https://x402.org/facilitator`:
   ```json
   {"paymentPayload": {...}, "paymentRequirements": {...}}
   ```
4. Facilitator verifies:
   - Signature is valid for the claimed `from` address
   - `validAfter <= now <= validBefore`
   - Amount matches or exceeds required
   - Nonce hasn't been used (checked via USDC contract's `authorizationState(from, nonce)`)
   - Payer has sufficient USDC balance
5. Facilitator returns `{"isValid": true}`

### Phase 4: Settle

1. Middleware calls `POST /settle` on the facilitator
2. Facilitator submits `transferWithAuthorization(...)` to the USDC contract on Base Sepolia
3. USDC contract verifies the signature internally (it's part of the EIP-3009 standard), marks the nonce as used, transfers the USDC
4. Facilitator waits for on-chain confirmation (1-2 seconds on Base)
5. Facilitator returns:
   ```json
   {"success": true, "transaction": "0xabc123...", "network": "eip155:84532"}
   ```

### Phase 5: Route handler runs

1. Now and only now, `PaymentMiddlewareASGI` passes the request to the route handler
2. `reason()` in `routes/reasoning.py` runs
3. Handler returns `{"question": "foo", "answer": "..."}`
4. Middleware adds a `PAYMENT-RESPONSE` header containing the settlement receipt
5. Full 200 response returns to the agent

**Total elapsed time:** typically 3-6 seconds, mostly dominated by the block confirmation.

---

## 3. File-by-file walkthrough

### `mindx/api/main.py`

The app entry point. Three FastAPI instances:

- `free_app` — mounted at `/free`, for API-key developers (middleware slot exists but not filled in this reference implementation)
- `paid_app` — mounted at `/pay`, wrapped with `install_x402(paid_app)`
- `app` — the top-level app that mounts both, plus the always-free `/health` routes

The `lifespan` context manager runs at startup and shutdown, logging the config summary. Useful for verifying at a glance that production actually got the production config.

The `if __name__ == "__main__"` block uses `uvicorn.run(app, loop="asyncio")`. The `loop="asyncio"` is critical — `fastapi-x402` middleware has a known incompatibility with `uvloop`, which would otherwise be uvicorn's default. Using standard asyncio avoids it.

### `mindx/api/routes/health.py`

Two endpoints, both always free. `/health` returns `{"status": "ok"}`. `/health/config` returns the sanitized config summary — useful for confirming "am I actually on mainnet or testnet right now?" in production.

### `mindx/api/routes/reasoning.py`

The paid endpoints. Four of them: `reason`, `socratic`, `dream`, `discover_agents`. Each has Pydantic request/response models for input validation, and each has `openapi_extra` with an `x-402` block announcing pricing in the OpenAPI spec. Agents reading `/openapi.json` see this metadata and can discover pricing without humans.

The handlers themselves are placeholder implementations. In production you'd replace the bodies with actual calls to Ollama, your reasoning engine, or whatever inference backend you use.

### `mindx/x402_integration/config.py`

Environment-driven configuration. Top of the file has a hardcoded dict of **USDC contract addresses** for every supported chain. This is the single source of truth — if you have doubts about which address to use for which chain, look here.

The module chooses `NETWORK`, `FACILITATOR_URL`, `PAY_TO_ADDRESS` based on `MINDX_ENV`:
- `production` → Base mainnet + CDP facilitator + secrets fetched from GCP Secret Manager
- `staging` → Base Sepolia + public facilitator
- `development` → same as staging but reads env vars directly

`summary()` returns a sanitized dict for logging. It never includes private keys or API secrets.

### `mindx/x402_integration/middleware.py`

The `install_x402(app)` function. This is where the x402 SDK is actually wired in:

1. Create an `HTTPFacilitatorClient` pointing at the configured facilitator URL
2. Create a `x402ResourceServer` with that facilitator
3. Register `ExactEvmServerScheme()` for our target network
4. Build a `routes` dict mapping endpoint → `RouteConfig` with price/network/recipient
5. Add `PaymentMiddlewareASGI` to the FastAPI app with those routes and that server

The imports are deferred inside the function so the module is importable even if the x402 SDK isn't installed (useful for test environments that only exercise the non-payment parts).

### `mindx/x402_integration/pricing.py`

The `BASE_PRICES` dict maps endpoint strings to USD price strings. The x402 SDK accepts prices as strings like `"$0.001"` and handles USDC decimal conversion internally.

`discounted_price_for(endpoint, payer)` computes the final price with BONAFIDE reputation discount applied (if enabled). It returns a USD string in the format the SDK expects.

The helper functions `usd_to_float` and `float_to_usd` handle the string parsing. Worth noting: `float_to_usd(0.001)` strips trailing zeros, so you get `"$0.001"` not `"$0.001000"`.

### `mindx/x402_integration/audit.py`

Append-only JSONL logging. Two functions: `log_payment` and `log_refund`, each writing one JSON object per line to a configurable file path.

The schema is intentionally flat and simple — no nested structures, no optional fields that might be missing — to make downstream reconciliation (`scripts/reconcile_daily.py`) straightforward.

The `extra` parameter on `log_payment` lets you attach endpoint-specific metadata (e.g., which agent called, which reputation score applied).

Retention policy: 7 years for US tax/regulatory compliance. In practice, rotate the file daily and compress old files.

### `mindx/x402_integration/identity.py`

BANKON cross-chain identity check. The interesting part is the two-level caching:

1. `_cached_algo_address(evm_addr, ttl_bucket)` — LRU cache of the EVM→Algorand lookup. The `ttl_bucket` argument is the current 5-minute wall-clock bucket; when it changes, all cached entries are effectively invalidated because the key changed.
2. The actual lookup queries the `BankonRegistry` contract on Base.

Then `has_bankon_identity` queries the Algorand indexer HTTP API to check whether the linked Algorand account actually holds the AlgoIDNFT ASA. If either step fails, the function returns `False` — fail-closed, so strict mode rejects by default.

`price_multiplier(has_identity)` returns 2.0 for unverified payers in soft mode, 1.0 otherwise.

### `mindx/x402_integration/reputation.py`

BONAFIDE reputation-based discounts. Same caching pattern as `identity.py` but with a 1-hour TTL bucket (reputation changes slower than identity).

`discount_factor(address)` returns:
- 0.5 for scores ≥ 800 (50% off)
- 0.75 for scores ≥ 500 (25% off)
- 1.0 otherwise (full price)

These thresholds are arbitrary starting values. You'll want to tune them based on your actual reputation score distribution once BONAFIDE is collecting data.

### `mindx/config/secrets.py`

GCP Secret Manager helper. In development, falls through to environment variables. In production, fetches from Secret Manager and caches in-process with `@lru_cache`. The cache means secrets are fetched once per process lifetime — to rotate, restart the process.

### `agents/example_agent.py`

Demonstration client using `x402HttpxClient`. This is what an AgenticPlace agent's payment code looks like, minus the outer agent loop that decides *why* to make the call in the first place.

Three calls in sequence:
1. `/health` — free, no payment
2. `/pay/api/v1/reason` — paid, automatically signed and retried
3. `/pay/api/v1/socratic` — another paid call with a POST body

The SDK handles all the 402-detection, signing, and retry logic transparently. The agent code looks like a normal HTTP client.

### `contracts/src/BankonRegistry.sol`

The on-chain piece of the BANKON cross-chain identity link. Minimal Solidity: `linkIdentity(algoAddress)` stores the mapping, `algoAddressFor(evmAddress)` reads it back. Two events (`IdentityLinked`, `IdentityUnlinked`) for indexing.

Production version should add off-chain signature verification proving the caller actually controls the claimed Algorand address — without that, anyone could claim anyone's Algorand address. For v1, trust the agent and rely on BANKON's own verification layer to reject bogus registrations before they hit the contract.

### `contracts/test/X402Settlement.t.sol`

Foundry test suite. Six tests covering the EIP-3009 flow:

1. **Happy path** — valid payment settles, balance updates, nonce marked used
2. **Expired authorization** — `validBefore < now` reverts
3. **Not-yet-valid** — `validAfter > now` reverts
4. **Replayed nonce** — second settlement with same nonce reverts
5. **Wrong signer** — signing with key A but claiming `from = B` reverts
6. **Insufficient balance** — transfer exceeds balance, reverts

Plus a sanity check on the USDC `name()` and `version()` — if these drift, signatures will fail across the board.

Run with `forge test --fork-url https://sepolia.base.org -vvv`.

### `scripts/refund.sh`

Bash script for manual refunds. Takes four arguments: payer address, USD amount, reason, original tx hash. Confirms interactively, then uses `cast send` to transfer USDC back, then calls the Python `log_refund` helper to write the refund record.

The shell-Python bridge is ugly but keeps the script self-contained without requiring a separate Python CLI.

### `scripts/reconcile_daily.py`

The nightly reconciliation job. Loads payment records from the last 24 hours, fetches each transaction receipt from Base, decodes the Transfer event, compares on-chain amount to logged amount. Prints a summary and exits non-zero if any mismatches.

Run as a cron job. Expected output on a clean day: "Summary: 142 ok, 0 failed".

### `tests/test_middleware.py`

Unit tests for the config, pricing, and audit layers. These do NOT exercise the x402 SDK itself — they're pure Python unit tests of the mindx-specific code. Runs in CI without any blockchain access.

### `tests/test_e2e.py`

End-to-end scaffold. Skipped by default (set `E2E_ENABLED=1` to run). Includes one test verifying that `/health` is accessible without payment, and one verifying that a paid endpoint returns 402 without an `X-PAYMENT` header. A full signed-retry test is documented as requiring a live server + agent key.

---

## 4. The subtleties that bite people

### USDC `name()` and `version()` must match exactly

The EIP-712 domain hash depends on these values. If the SDK's default domain doesn't match what the USDC contract returns, signatures will fail with `invalid_exact_evm_payload_signature`. On Base mainnet USDC, `name()` is `"USD Coin"` and `version()` is `"2"`. On Base Sepolia USDC, it's `"USDC"` and `"2"`. The Foundry test `test_DomainValues_MatchExpected` asserts this — if it fails, investigate before trusting any downstream signing.

### `uvloop` vs `asyncio` incompatibility

`fastapi-x402` middleware does not work correctly under `uvloop`. Symptom: `Can't patch loop of type uvloop.Loop`. Fix: always run uvicorn with `--loop asyncio` explicitly. Encoded into the `Containerfile` and the `main.py` main block.

### Mount path stripping

`PaymentMiddlewareASGI` sees paths from the perspective of `paid_app`, not the top-level `app`. So the routes dict has `"GET /api/v1/reason"`, not `"GET /pay/api/v1/reason"`. The `/pay` prefix is stripped by FastAPI's mount mechanism before the sub-app sees the request.

### Nonce generation

x402 relies on unique nonces per payment to prevent replay. The SDK generates random 32-byte nonces per call. If you write a custom client, make sure nonces are genuinely unpredictable — `keccak256(abi.encodePacked(payer, block.timestamp))` is NOT sufficient because concurrent calls from the same payer in the same second would collide.

### Facilitator downtime

If the facilitator is unreachable, every paid endpoint fails. There's no local fallback (you can't settle without the facilitator). The `FallbackFacilitator` pattern in the playbook wraps two facilitators with automatic failover. In the reference implementation we use a single facilitator for simplicity — add the fallback wrapper before production.

### In-flight payment pricing during price changes

If you raise prices from $0.001 to $0.002, agents who received a 402 at $0.001 and haven't signed yet will successfully sign at $0.001. The signature is bound to a specific amount. The new price only applies to new 402 responses issued after the config change. This is correct behavior — you should never reject a signature that matches a 402 you issued.

### Refunds are out-of-band

x402 has no native refund protocol. When you need to refund, you use `scripts/refund.sh` to send USDC back manually, and you log the refund to `refunds.jsonl` for reconciliation. There's no automatic linkage — if a customer claims they were charged twice, you have to investigate by matching timestamps and amounts against their wallet address.

---

## 5. Networks, addresses, and chain IDs

Everything we interact with:

| Layer | Value |
|-------|-------|
| Base mainnet chain ID | 8453 |
| Base Sepolia chain ID | 84532 |
| Base mainnet RPC | `https://mainnet.base.org` |
| Base Sepolia RPC | `https://sepolia.base.org` |
| USDC on Base mainnet | `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` |
| USDC on Base Sepolia | `0x036CbD53842c5426634e7929541eC2318f3dCF7e` |
| CDP facilitator (mainnet) | `https://api.cdp.coinbase.com/platform/v2/x402` |
| Public facilitator (testnet) | `https://x402.org/facilitator` |
| Basescan (mainnet) | `https://basescan.org` |
| Basescan (testnet) | `https://sepolia.basescan.org` |
| Algorand USDC ASA ID | 31566704 |
| Algorand mainnet indexer | `https://mainnet-idx.algonode.cloud` |

The `NETWORK` environment variable uses CAIP-2 format: `eip155:8453` for Base mainnet, `eip155:84532` for Base Sepolia, `algorand:mainnet-v1.0` for Algorand mainnet.

---

**Next reading:** `usage.md` for how to drive all of this day-to-day. `tasklist.md` for what to do, in order, to get to production.
