# usage.md
## How to drive mindx-x402 day to day

This is the operator's manual. It assumes the code is deployed. It covers: how to set it up from scratch, how to run it locally, how to use it as a developer, how to use it as an agent, how to monitor it, and how to handle the routine operational situations you'll face.

If you haven't deployed yet, go to `tasklist.md` first. Come back here when you have a running service.

---

## 1. First-time setup

### Install prerequisites

```bash
# Python 3.11 or later
python3 --version

# Foundry (for Solidity testing)
curl -L https://foundry.paradigm.xyz | bash
foundryup

# Clone and install
git clone <your-repo-url> mindx-x402
cd mindx-x402
pip install -e ".[dev]"

# Verify x402 SDK
python -c "import x402; print(x402.__version__)"
```

### Create a receiving wallet

```bash
# Generate a new wallet
cast wallet new

# You get output like:
# Successfully created new keypair.
# Address:     0xABcD...
# Private key: 0x1234...
```

Save the private key in a secure place (password manager, Secret Manager). You will need it later if you want to withdraw USDC from this wallet.

**For testnet:** This private key can live in a `.env` file on your dev machine. For mainnet: the private key should never touch disk unencrypted. Use GCP Cloud KMS or equivalent.

### Fund the wallet for testing

Visit `https://faucet.circle.com`, select **Base Sepolia**, paste your wallet address. You'll get some test USDC within a minute. Also get a small amount of Sepolia ETH from `https://bridge.base.org` — you may need it for any operations that aren't gas-abstracted.

### Configure environment

```bash
cp .env.example .env
```

Edit `.env`:

```bash
MINDX_ENV=development
PAY_TO_ADDRESS=0x...your-address-from-cast-wallet-new...
X402_NETWORK=eip155:84532
USDC_ASSET_ADDRESS=0x036CbD53842c5426634e7929541eC2318f3dCF7e
FACILITATOR_URL=https://x402.org/facilitator
```

### Run the server

```bash
uvicorn mindx.api.main:app --port 8000 --loop asyncio
```

You should see:
```
INFO mindx - mindX v1.0.0 starting with config: {
  'env': 'development',
  'network': 'eip155:84532',
  'facilitator': 'https://x402.org/facilitator',
  ...
}
INFO mindx - x402 middleware installed with 4 paid routes
```

Visit `http://localhost:8000/health` in your browser — you should get `{"status": "ok"}`.

Visit `http://localhost:8000/redoc` — you should see the full API documentation with the four paid endpoints marked with their `x-402` extensions.

---

## 2. Testing it works end-to-end

### Call the health endpoint (free)

```bash
curl http://localhost:8000/health
# {"status":"ok","version":"1.0.0"}
```

### Call a paid endpoint without payment

```bash
curl -i http://localhost:8000/pay/api/v1/reason?question=test
```

You'll get:
```
HTTP/1.1 402 Payment Required
PAYMENT-REQUIRED: eyJ4NDAyVmVyc2lvbiI6...
Content-Type: application/json

{"x402Version":2,"error":"X-PAYMENT header is required","accepted":[...]}
```

Decode the `PAYMENT-REQUIRED` header to see the payment requirements:

```bash
curl -si http://localhost:8000/pay/api/v1/reason?question=test \
  | grep -i "PAYMENT-REQUIRED" \
  | cut -d: -f2- \
  | tr -d ' \r' \
  | base64 -d \
  | jq
```

### Pay with the example agent

Generate an agent wallet (different from the receiving wallet):

```bash
cast wallet new
```

Fund this agent wallet with Base Sepolia USDC from `faucet.circle.com`.

Then run:

```bash
export AGENT_PRIVATE_KEY=0x...your-agent-testnet-key...
python agents/example_agent.py http://localhost:8000
```

Expected output:

```
Agent wallet address: 0xAgent...
Calling mindX at: http://localhost:8000

1. GET /health (free)
   → 200 {'status': 'ok', 'version': '1.0.0'}

2. GET /pay/api/v1/reason (paid — $0.001)
   → 200
   → answer: The unexamined life is not worth living...
   → settlement receipt: eyJzdWNjZXNzIjp0cnVlLCJ0eEhhc2...

3. POST /pay/api/v1/socratic (paid — $0.01)
   → 200
   → chain: {...}
```

Verify on Basescan: decode the `settlement receipt`, extract the `txHash`, visit `https://sepolia.basescan.org/tx/<hash>` — you'll see the real USDC transfer.

---

## 3. Calling from your own agent code

The minimal async client:

```python
import asyncio
import os
from eth_account import Account
from x402.clients import x402HttpxClient

account = Account.from_key(os.environ["AGENT_PRIVATE_KEY"])

async def main():
    async with x402HttpxClient(
        account=account,
        base_url="https://mindx.pythai.net",
    ) as client:
        response = await client.get("/pay/api/v1/reason?question=what+is+being")
        print(response.json())
        print("Paid:", response.headers.get("PAYMENT-RESPONSE"))

asyncio.run(main())
```

The synchronous equivalent:

```python
from x402.clients import x402_requests
session = x402_requests(account)
response = session.get("https://mindx.pythai.net/pay/api/v1/reason?question=foo")
```

**The SDK handles everything:** receives the 402, parses payment requirements, builds the EIP-3009 authorization, signs it, retries with `X-PAYMENT` header, returns the final 200. Your code sees one HTTP call.

### Typescript/JavaScript agents

```typescript
import { x402Fetch } from "x402-fetch";
import { privateKeyToAccount } from "viem/accounts";

const account = privateKeyToAccount(process.env.AGENT_PRIVATE_KEY);
const fetchWithPayment = x402Fetch(fetch, account);

const response = await fetchWithPayment(
  "https://mindx.pythai.net/pay/api/v1/reason?question=what+is+being"
);
```

### Adding endpoints

To add a new paid endpoint:

1. Add the route handler in `mindx/api/routes/reasoning.py` (or a new router file):

```python
@router.post("/translate", openapi_extra={
    "x-402": {"schemes": ["exact"], "price": "$0.02"}
})
async def translate(payload: TranslateRequest) -> dict:
    return {"translation": ...}
```

2. Add the price to `mindx/x402_integration/pricing.py`:

```python
BASE_PRICES = {
    ...
    "POST /api/v1/translate": "$0.02",
}
```

3. Restart the server. The middleware reads `BASE_PRICES` at startup.

---

## 4. Switching from testnet to mainnet

When you're ready for real payments:

### Get a CDP account

1. Sign up at `https://portal.cdp.coinbase.com`
2. Settings → API Keys → Create
3. Save `CDP_API_KEY_ID` and `CDP_API_KEY_SECRET` to your secrets manager (not a file on disk)

### Move your receiving wallet to a secure key management system

For production, generate the mainnet wallet inside **GCP Cloud KMS** (or AWS CloudHSM). The private key never leaves the HSM. Signing happens via API call. This means: even if your server is compromised, the attacker cannot steal your USDC because they cannot sign withdrawal transactions.

Alternative for small-scale production: cold storage. Generate the wallet on an air-gapped machine, save the private key to paper or a hardware wallet, only bring it online when you want to withdraw accumulated USDC to your main treasury.

### Update configuration

Set production environment:

```bash
MINDX_ENV=production
X402_NETWORK=eip155:8453
USDC_ASSET_ADDRESS=0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913
FACILITATOR_URL=https://api.cdp.coinbase.com/platform/v2/x402
```

With `MINDX_ENV=production`, the config module automatically reads `PAY_TO_ADDRESS`, `CDP_API_KEY_ID`, `CDP_API_KEY_SECRET` from GCP Secret Manager instead of environment variables.

### Do the first mainnet transaction before opening traffic

Fund the agent with $0.01 of real USDC. Call one endpoint. Verify:

1. Server logs show the 402 then 200
2. `payments.jsonl` has a new entry
3. Basescan shows the transaction (`https://basescan.org/tx/<hash>`)
4. Your CDP dashboard shows the facilitator settlement

Only after all four match, ramp to real traffic.

---

## 5. Monitoring daily

### The 5-minute morning check

```bash
# 1. How many payments in the last 24h?
grep -c "" /var/log/mindx/payments.jsonl  # line count = payment count

# 2. Total USDC received today (base units, divide by 1_000_000 for dollars)
jq -s '[.[] | select(.ts > (now - 86400)) | .amount | tonumber] | add' \
  /var/log/mindx/payments.jsonl

# 3. Any refunds?
tail -20 /var/log/mindx/refunds.jsonl

# 4. Current receiving wallet balance
cast call 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  "balanceOf(address)(uint256)" \
  $PAY_TO_ADDRESS \
  --rpc-url https://mainnet.base.org

# 5. Facilitator health
curl -sf https://api.cdp.coinbase.com/platform/v2/x402/supported \
  -H "Authorization: Bearer $CDP_API_KEY_SECRET"
```

If any of these fail, investigate before doing anything else.

### The nightly reconciliation

Set up as a cron job:

```cron
0 2 * * * cd /opt/mindx && python scripts/reconcile_daily.py >> /var/log/mindx/reconcile.log 2>&1
```

On a clean day the script outputs:
```
Reconciling 142 payments from last 24h...
Summary: 142 ok, 0 failed
```

If any failures, they're logged with the `tx_hash` and reason. Investigate each one. Usually failures are:
- Stuck transactions (facilitator submitted but block hasn't confirmed yet) — retry the reconciliation in an hour
- Failed transactions (facilitator submission reverted) — something is wrong with the facilitator; investigate
- Amount mismatches (very rare) — indicates a real bug somewhere; stop and investigate immediately

### Metrics to graph

If you have Grafana or similar, track:

- `payments_per_hour` — hourly payment count
- `usdc_received_per_hour` — hourly revenue
- `failed_payments_per_hour` — 402-but-no-subsequent-200 count
- `settlement_latency_p50` and `p95` — time from 402 to 200
- `facilitator_errors_per_hour` — how often settlement fails
- `audit_log_size` — file size, to detect logging issues

---

## 6. Handling routine operational situations

### A customer says they were charged twice

1. Get the wallet address they're paying from
2. Search `payments.jsonl` for their address:
   ```bash
   grep '"payer": "0xCustomerAddr"' /var/log/mindx/payments.jsonl
   ```
3. Check if there are truly duplicate settlements within seconds of each other for the same endpoint
4. If yes, refund the duplicate via `scripts/refund.sh`:
   ```bash
   ./scripts/refund.sh 0xCustomerAddr 0.01 "duplicate_charge" 0xOriginalTxHash
   ```
5. Investigate root cause — usually a client-side retry bug

### A request completed but the customer says they never got a response

1. Check server logs for their request timestamp
2. If the server logged a 200 but the customer didn't receive it, that's a network issue between you and them — not your problem to refund (but maybe do it as goodwill)
3. If the server logged a 402 → settlement succeeded but no route handler ran, that's a middleware bug — investigate urgently

### The facilitator is down

Symptoms: all paid endpoints fail. Free endpoints work fine. Logs show facilitator timeouts.

Short term:
1. Verify with `curl https://api.cdp.coinbase.com/platform/v2/x402/supported` — does it respond?
2. Check Coinbase status page: `status.coinbase.com`
3. If it's a real outage, update your status page, let users know

Medium term:
4. Add the `FallbackFacilitator` wrapper to your middleware (see PLAYBOOK.md Section 7), falling back to `https://0xmeta.ai/facilitator` or similar

Long term:
5. Consider running your own facilitator. Non-trivial — you need a funded wallet with gas, redundant infrastructure, 24/7 monitoring.

### You need to change prices

1. Edit `BASE_PRICES` in `mindx/x402_integration/pricing.py`
2. Deploy the change (rolling restart)
3. New 402 responses reflect new prices immediately
4. In-flight signed authorizations at the old price still settle correctly

No coordination needed. Prices can change anytime.

### You need to decommission an endpoint

1. Change the endpoint to return 410 Gone:
   ```python
   @router.get("/api/v1/deprecated")
   async def deprecated():
       raise HTTPException(status_code=410, detail="This endpoint has been retired")
   ```
2. Remove the entry from `BASE_PRICES`
3. Deploy
4. Leave the 410 up for at least 30 days so existing agents see a clean error

### You need to rotate the receiving wallet key

Every 6-12 months is good practice.

1. Generate a new wallet: `cast wallet new`
2. Update `PAY_TO_ADDRESS` in your secrets manager (new address)
3. Rolling restart — new 402 responses point to the new address
4. In-flight signed authorizations to the old address still settle correctly (USDC doesn't care about your config)
5. After all old authorizations are settled (wait the max `validBefore` window, usually 60 seconds), drain the old wallet:
   ```bash
   cast send 0xUSDC_CONTRACT "transfer(address,uint256)" \
     $NEW_ADDRESS $OLD_WALLET_BALANCE \
     --rpc-url $BASE_RPC \
     --private-key $OLD_PAY_TO_PRIVATE_KEY
   ```
6. Archive the old private key (don't delete — you may need it for historical investigation)

### You detect fraud or abuse

Signs:
- One wallet making thousands of calls per minute
- Calls from KYT/OFAC-flagged addresses (CDP will alert you)
- Pattern of small payments followed by refund requests

Response:
1. Block the abusive wallet at the middleware layer:
   ```python
   BLOCKED_WALLETS = {"0xAbuser1", "0xAbuser2"}
   # Reject in middleware before even emitting 402
   ```
2. Investigate patterns — is there a vulnerability in your rate limiting?
3. Update BONAFIDE to tag the address with negative reputation (other services benefit)
4. If funds need to be frozen (in OFAC case), coordinate with Coinbase

---

## 7. Withdrawing USDC from the receiving wallet

Once USDC accumulates in the receiving wallet, you'll want to move it to treasury or off-ramp it.

### Move to another on-chain address

```bash
cast send 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  "transfer(address,uint256)" \
  $TREASURY_ADDRESS \
  $AMOUNT_IN_USDC_BASE_UNITS \
  --rpc-url https://mainnet.base.org \
  --private-key $PAY_TO_PRIVATE_KEY
```

### Off-ramp to bank (Coinbase)

1. Send USDC from your receiving wallet to your Coinbase account's USDC deposit address on Base
2. Within Coinbase, convert USDC → USD
3. Withdraw USD to linked bank account

### Off-ramp via Circle

If you have a Circle business account, Circle will redeem USDC for USD directly at 1:1. This is the most capital-efficient path at scale.

---

## 8. Upgrading the codebase

### x402 SDK updates

```bash
pip install --upgrade "x402[fastapi]"
```

Check the changelog at `github.com/x402-foundation/x402/releases`. Pay attention to:
- Breaking changes to `PaymentMiddlewareASGI` signature
- New payment schemes added (e.g., `upto` → stable)
- Protocol version bumps (V2 → V3)

Test on staging before production.

### Adding the `upto` scheme

Once the `upto` scheme is stable in the SDK (check the package docs), you can switch variable-cost endpoints from flat `exact` pricing to usage-based billing. The migration:

1. Import `UptoEvmServerScheme` instead of (or in addition to) `ExactEvmServerScheme`
2. Register it on the server
3. Add an `upto` `PaymentOption` to the route's `accepts` list
4. Update the handler to report actual consumption so settlement charges the right amount

### Adding Algorand as a second chain

When you're ready:

1. Sign up for GoPlausible access
2. Install Algorand SDK: `pip install "py-algorand-sdk"`
3. Add `ExactAvmServerScheme` registration in `middleware.py`
4. Add an Algorand `PaymentOption` to each route's `accepts` list
5. Deploy

Agents will now see both options in 402 responses and can pay on whichever chain they hold funds.

---

## 9. Common errors and their meanings

### `invalid_exact_evm_payload_signature`

The signature in the `X-PAYMENT` header doesn't match the claimed `from` address.

Causes:
- Wrong USDC contract address in the EIP-712 domain
- Wrong `name` or `version` in the domain (should be `"USD Coin"` / `"2"` on Base mainnet)
- Wrong `chainId` in the domain
- Client signed with a different key than the claimed `from`

### `unable to estimate gas`

The facilitator couldn't simulate the transaction. Usually transient — retry in 30 seconds. If persistent, check:
- Facilitator has gas in its own wallet
- USDC contract is actually at the address you specified
- Network isn't congested

### `nonce already used`

Client is trying to replay an authorization that's already been settled. Legitimate clients shouldn't hit this — the SDK generates fresh nonces. If it happens, check for client bugs around retry logic.

### `authorization expired`

`validBefore` is in the past. The client took too long between signing and submission. Usually a network issue — retry.

### `403 Forbidden` with a BANKON message

The payer's wallet isn't linked to a verified BANKON identity. Either they need to register via BANKON, or the service is in `strict` mode and doesn't accept unverified payers.

### `402 Payment Required` after you already paid

The `PAYMENT-SIGNATURE` header was rejected. Check:
- Header is actually being sent (not stripped by a proxy)
- Payload is correctly base64-encoded
- Signature was made for THIS specific request (each 402 should generate a new signature)

---

## 10. When things go really wrong

### The server is dropping paid traffic

1. Revert to the previous stable deployment
2. If you can't revert (no previous image), temporarily remove `install_x402(paid_app)` and redeploy — endpoints become free rather than broken
3. Investigate at leisure

### You were hacked / private key exposed

1. Immediately generate a new wallet and update `PAY_TO_ADDRESS`
2. Deploy
3. Drain the compromised wallet as fast as possible:
   ```bash
   cast send 0xUSDC "transfer(address,uint256)" $SAFE_ADDRESS $BALANCE ...
   ```
4. Notify users that the old address is retired
5. Rotate all other credentials (CDP API keys, server SSH keys, etc.)

### The blockchain itself has problems

Rare, but Base has had brief outages. If settlement stops:

1. Return 503 Service Unavailable for paid endpoints
2. Keep free endpoints running
3. Wait for Base to recover
4. Reprocess any queued requests

You cannot cache settlements locally — each payment must actually be on-chain. If the chain is down, no payments are possible.

---

## 11. Getting help

- **Code bugs:** check GitHub issues at `github.com/coinbase/x402/issues` and `github.com/x402-foundation/x402/issues`
- **Protocol questions:** the x402 spec at `github.com/coinbase/x402/blob/main/specs/x402-specification.md`
- **Facilitator issues:** CDP support via the portal
- **Base chain issues:** `status.base.org`
- **Community:** x402 Telegram group (linked from `x402.org`)

---

**Next reading:** `tasklist.md` for the exact sequence of tasks to go from nothing to running in production.
