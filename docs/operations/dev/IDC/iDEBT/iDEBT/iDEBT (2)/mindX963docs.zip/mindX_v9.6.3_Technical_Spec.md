# mindX v9.6.3 Technical Specification

**Version:** 9.6.3  
**Released:** January 18, 2026  
**Status:** Production Stable  
**License:** MIT  

---

## System Requirements

### Minimum
- **CPU:** 2 cores @ 2.0 GHz
- **RAM:** 2 GB
- **Disk:** 500 MB
- **Python:** 3.9+
- **OS:** Linux, macOS, Windows (WSL2)

### Recommended
- **CPU:** 4+ cores @ 3.0 GHz
- **RAM:** 4+ GB
- **Disk:** 2+ GB (SSD)
- **Python:** 3.11+
- **OS:** Ubuntu 22.04 LTS or macOS 13+

### Production
- **CPU:** 8+ cores @ 3.5 GHz
- **RAM:** 16+ GB
- **Disk:** 50+ GB (NVMe SSD)
- **Python:** 3.11
- **OS:** Ubuntu 24.04 LTS

---

## Core Architecture

### Three-Layer System

```
Layer I: Marketing
├── Vision & Mission
├── Strategic Positioning
└── Distribution Channels

Layer II: Community
├── Identity Management (DIDs)
├── Reputation Systems
└── DAIO Governance

Layer III: Development
├── BDI Cognitive Architecture
├── Multi-Agent Orchestration
└── Deployment Infrastructure
```

### Cross-Cutting Components

**THOT Memory System v2.0**
- Storage: IPFS, PostgreSQL, Memory
- Encryption: AES-256-GCM (quantum-resistant option)
- Compression: Zstandard (zstd)
- Retrieval: Vector similarity search
- Performance: 15ms p95 query latency

**BDI Control System v3.0**
- Architecture: Belief-Desire-Intention
- Deliberation: 95ms average cycle time
- Conflict Resolution: Priority-based + consensus
- Explainability: Full decision logging
- Nesting: Up to 5 levels deep

**Protocol Layer**
- MCP v1.0: Model Context Protocol
- A2A v2.1: Agent-to-Agent Protocol
- AP2 v1.0: Agent Payments Protocol
- ACP v1.0: Agentic Commerce Protocol

**Blockchain Integration**
- Primary: Arc Network (Chain ID: 5042002)
- Support: Ethereum, BSC, Polygon, Base
- Transaction Time: <1s (Arc), 12s (Ethereum)
- Gas: USDC (Arc), ETH/BNB (others)

---

## API Specifications

### Agent API

```python
class Agent:
    """Base agent class"""
    
    def __init__(
        self,
        name: str,
        beliefs: Optional[Dict] = None,
        desires: Optional[List[Desire]] = None,
        memory_backend: str = "ipfs"
    ) -> None: ...
    
    def deliberate(self) -> Intention: ...
    def execute(self, intention: Intention) -> Result: ...
    def run(self, mode: str = "continuous") -> None: ...
```

### Memory API

```python
class MemoryBank:
    """Persistent memory system"""
    
    def store_episode(
        self,
        episode: Dict[str, Any],
        tags: Optional[List[str]] = None
    ) -> str: ...
    
    def query(
        self,
        query: str,
        top_k: int = 5,
        min_similarity: float = 0.7
    ) -> List[Episode]: ...
    
    def get_episode(self, episode_id: str) -> Episode: ...
```

### Blockchain API

```python
class ArcAdapter:
    """Arc Network integration"""
    
    def deploy_agent(
        self,
        agent_config: AgentConfig,
        stake_amount: Decimal
    ) -> Transaction: ...
    
    def submit_transaction(
        self,
        tx: Transaction,
        gas_limit: int = 1_000_000
    ) -> Receipt: ...
```

### Governance API

```python
class DAIOClient:
    """Governance participation"""
    
    def submit_proposal(
        self,
        proposal: Proposal
    ) -> str: ...
    
    def vote(
        self,
        proposal_id: str,
        vote: Literal["approve", "reject", "abstain"],
        rationale: str
    ) -> Transaction: ...
```

---

## Performance Benchmarks

### v9.6.3 (Current)

| Metric | Value | Notes |
|--------|-------|-------|
| Cold Start | 400ms | Agent initialization |
| Memory Query | 15ms | p95 latency |
| Memory Storage | 8ms | p95 latency |
| BDI Deliberation | 95ms | Average cycle time |
| Transaction Submit | 800ms | Arc Testnet |
| Agent Communication | 140ms | A2A protocol |
| IPFS Upload | 250ms | 1MB file |
| IPFS Download | 180ms | 1MB file |

### Comparison (v9.6.2 → v9.6.3)

| Metric | v9.6.2 | v9.6.3 | Improvement |
|--------|--------|--------|-------------|
| Cold Start | 1200ms | 400ms | **67% faster** |
| Memory Query | 45ms | 15ms | **67% faster** |
| Transaction | 2500ms | 800ms | **68% faster** |
| BDI Cycle | 120ms | 95ms | **21% faster** |
| Communication | 180ms | 140ms | **22% faster** |

### Scalability

| Agents | Memory (MB) | CPU (%) | Latency (ms) |
|--------|-------------|---------|--------------|
| 1 | 120 | 5 | 15 |
| 10 | 450 | 18 | 18 |
| 50 | 1,800 | 45 | 24 |
| 100 | 3,200 | 72 | 32 |
| 250 | 7,500 | 95 | 48 |

**Recommended:** Max 50 agents per instance (horizontal scaling for more)

---

## Security Specifications

### Encryption

**At Rest:**
- Algorithm: AES-256-GCM
- Key Derivation: PBKDF2-HMAC-SHA256 (600,000 iterations)
- Option: Post-Quantum Cryptography (Kyber1024)

**In Transit:**
- TLS 1.3 (minimum)
- Certificate Pinning (recommended)
- Perfect Forward Secrecy (PFS)

### Authentication

**Agent Identity:**
- DID: did:mindx:agent:{id}
- Verification: Ethereum signatures (secp256k1)
- Key Management: Hardware wallets supported

**API Access:**
- JWT tokens (RS256)
- Expiration: 1 hour (configurable)
- Refresh tokens: 30 days

### Rate Limiting

**Default Limits:**
- API: 100 requests/minute
- Blockchain: 20 transactions/minute
- Memory: 1000 queries/minute
- IPFS: 500 operations/minute

**Configurable per agent**

---

## Network Protocols

### Arc Network (Primary)

```
Chain ID: 5042002
RPC: https://arc-testnet.rpc.thirdweb.com
Explorer: https://arc-testnet.blockscout.com
Gas Token: USDC (6 decimals)
Block Time: <1 second
Finality: Instant (BFT)
```

### Ethereum (Secondary)

```
Chain ID: 1 (mainnet), 11155111 (sepolia)
Gas Token: ETH (18 decimals)
Block Time: 12 seconds
Finality: 12 confirmations (~2.5 minutes)
```

### BSC (DeltaV THRUST Integration)

```
Chain ID: 56 (mainnet), 97 (testnet)
Gas Token: BNB (18 decimals)
Block Time: 3 seconds
Finality: 15 confirmations (~45 seconds)
```

---

## Protocol Specifications

### MCP (Model Context Protocol) v1.0

```
Transport: WebSocket, HTTP
Format: JSON
Session: Persistent, resumable
Context Size: Up to 100,000 tokens
Compression: Optional (gzip)
```

### A2A (Agent-to-Agent) v2.1

```
Transport: JSON-RPC 2.0 over HTTP/WebSocket
Methods: 25+ standard methods
Streaming: Server-Sent Events (SSE)
Retry Logic: Exponential backoff
Timeout: 30s (configurable)
```

### AP2 (Agent Payments) v1.0

```
Escrow: Smart contract-based
Settlement: Atomic (success or revert)
Dispute Window: 7 days
Arbitration: DAIO governance
Currency: PYTHAI, USDC, ETH, BNB
```

### ACP (Agentic Commerce) v1.0

```
Phases: 8 (Discovery → Review)
State Machine: Deterministic FSM
Rollback: Supported
Timeout: Per-phase configurable
Reputation: Automatic updates
```

---

## Memory Specifications

### THOT Memory System v2.0

**Storage Backends:**
- IPFS (recommended): Decentralized, content-addressed
- PostgreSQL: Relational, queryable
- Memory: Fast, non-persistent (testing)

**Data Structure:**

```json
{
  "episode_id": "ep_abc123",
  "agent_id": "did:mindx:agent:12345",
  "timestamp": "2026-01-18T10:30:45.123Z",
  "type": "service_completion",
  "data": {
    "task": "code_generation",
    "outcome": "successful",
    "duration_ms": 847,
    "customer_rating": 4.8
  },
  "tags": ["successful", "code_generation", "high_rating"],
  "embedding": [0.123, -0.456, ...],  // 768-dimensional vector
  "provenance": {
    "stored_by": "agent:12345",
    "ipfs_cid": "QmXyz...",
    "blockchain_hash": "0xabc..."
  }
}
```

**Query Performance:**
- Vector similarity: 15ms (1M episodes)
- Tag filtering: 5ms (1M episodes)
- Full-text search: 25ms (1M episodes)

**Storage Efficiency:**
- Compression ratio: 3.2:1 (zstd level 9)
- Deduplication: Automatic (content-addressed)
- Pruning: Age-based + importance scoring

---

## Deployment Configurations

### Development

```yaml
environment: development
debug: true
logging:
  level: DEBUG
  format: pretty
memory:
  backend: memory
  cache_size: 100
network:
  chain: arc-testnet
  gas_limit: 1000000
```

### Staging

```yaml
environment: staging
debug: false
logging:
  level: INFO
  format: json
memory:
  backend: ipfs
  cache_size: 1000
  encryption: true
network:
  chain: arc-testnet
  gas_limit: 2000000
monitoring:
  enabled: true
  metrics_port: 9090
```

### Production

```yaml
environment: production
debug: false
logging:
  level: WARNING
  format: json
  output: /var/log/mindx/
memory:
  backend: ipfs
  cache_size: 10000
  encryption: true
  compression: zstd
network:
  chain: arc-mainnet
  gas_limit: 3000000
monitoring:
  enabled: true
  metrics_port: 9090
  alerting:
    email: alerts@example.com
    slack: https://hooks.slack.com/...
security:
  rate_limit: 100
  sandboxing: true
  secret_scanning: true
```

---

## Monitoring & Observability

### Metrics

**Agent Metrics:**
- `mindx_agent_startup_time_seconds`
- `mindx_agent_memory_usage_bytes`
- `mindx_agent_deliberation_duration_seconds`
- `mindx_agent_transactions_total`
- `mindx_agent_errors_total`

**System Metrics:**
- `mindx_memory_query_duration_seconds`
- `mindx_memory_storage_bytes_total`
- `mindx_blockchain_transaction_duration_seconds`
- `mindx_ipfs_operation_duration_seconds`

**Business Metrics:**
- `mindx_revenue_total` (PYTHAI)
- `mindx_services_completed_total`
- `mindx_customer_satisfaction_score`
- `mindx_reputation_score`

### Logging

**Format:** Structured JSON

```json
{
  "timestamp": "2026-01-18T10:30:45.123Z",
  "level": "INFO",
  "logger": "mindx.agent",
  "agent_id": "did:mindx:agent:12345",
  "event": "service_completed",
  "details": {
    "service": "code_generation",
    "duration_ms": 847,
    "customer": "0x123...",
    "earnings": 15.5
  },
  "trace_id": "tr_xyz789",
  "span_id": "sp_abc123"
}
```

### Tracing

**OpenTelemetry Integration:**
- Jaeger exporter supported
- Zipkin exporter supported
- Trace context propagation
- Distributed tracing across agents

---

## Testing

### Test Coverage

**Unit Tests:** 2,847 tests (94.2% coverage)  
**Integration Tests:** 423 tests (89.7% coverage)  
**E2E Tests:** 67 scenarios (100% pass)

### Test Environments

**Local:**
```bash
pytest tests/
```

**Docker:**
```bash
docker-compose -f docker-compose.test.yml up
```

**CI/CD:**
- GitHub Actions
- Automated on every PR
- Coverage reports to Codecov

### Benchmarking

```bash
# Performance benchmarks
mindx bench --suite performance

# Load testing
mindx bench --suite load --agents 100 --duration 10m

# Stress testing
mindx bench --suite stress --max-agents 500
```

---

## Dependencies

### Core Dependencies

```
python >= 3.9
ipfs-api >= 0.4.0
web3 >= 6.0.0
pydantic >= 2.0.0
fastapi >= 0.100.0
sqlalchemy >= 2.0.0
cryptography >= 42.0.0
```

### Optional Dependencies

```
# PostgreSQL support
psycopg2-binary >= 2.9.0

# Monitoring
prometheus-client >= 0.17.0
opentelemetry-api >= 1.20.0

# Development
pytest >= 7.4.0
black >= 23.0.0
mypy >= 1.5.0
```

### System Dependencies

```
# Ubuntu/Debian
sudo apt install python3.11 python3-pip libpq-dev

# macOS
brew install python@3.11 postgresql
```

---

## Compliance & Standards

### Standards Implemented

- **EIP-712:** Ethereum typed structured data signing
- **DID:** W3C Decentralized Identifiers
- **JWT:** RFC 7519 JSON Web Tokens
- **OAuth 2.0:** RFC 6749 (future)
- **OpenAPI 3.0:** API documentation

### Compliance

- **GDPR:** Right to be forgotten (memory deletion)
- **SOC 2 Type II:** In progress (Q3 2026)
- **ISO 27001:** Planned (Q4 2026)

### Audits

- **Security:** Trail of Bits (Dec 2025) ✅
- **Smart Contracts:** Certik (Planned Q2 2026)
- **GDPR:** External audit (Planned Q3 2026)

---

## Support & Maintenance

### Support Tiers

**Community (Free):**
- Discord support
- GitHub issues
- Documentation
- Response: Best effort

**Professional ($500/month):**
- Email support
- Priority bug fixes
- Response: <48 hours

**Enterprise (Custom):**
- Dedicated support engineer
- 24/7 availability
- Custom SLAs
- Response: <4 hours (critical)

### Maintenance Windows

**Regular Updates:**
- Security patches: As needed (0-day)
- Bug fixes: Monthly (PATCH releases)
- Features: Quarterly (MINOR releases)

**Supported Versions:**
- v9.6.x: Until January 2027
- v9.5.x: Until July 2026
- v9.4.x and older: No longer supported

---

## License

**MIT License**

```
Copyright (c) 2026 AgenticPlace / Professor Codephreak

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software...
```

See [LICENSE](https://github.com/AgenticPlace/mindXgamma/blob/main/LICENSE) for full text.

---

## Contact

**Technical Support:** support@mindx.io  
**Security Issues:** security@mindx.io (PGP key available)  
**Sales & Partnerships:** partnerships@mindx.io  
**Press & Media:** press@mindx.io

**Office Hours:** Monday-Friday, 9 AM - 5 PM PST

---

**Document Version:** 1.0  
**Last Updated:** January 18, 2026  
**Maintained By:** mindX Core Team
