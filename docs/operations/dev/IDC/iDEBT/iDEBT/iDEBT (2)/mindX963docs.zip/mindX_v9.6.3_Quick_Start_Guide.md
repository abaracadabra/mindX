# mindX v9.6.3 Quick Start Guide

**Welcome to mindX!** This guide will get you up and running with your first autonomous agent in under 15 minutes.

---

## Prerequisites

**System Requirements:**
- Python 3.9+ (3.11 recommended)
- 2GB RAM minimum (4GB recommended)
- 500MB disk space
- Internet connection

**Accounts Needed:**
- MetaMask wallet (or compatible Web3 wallet)
- Some Arc Testnet USDC ([get from faucet](https://faucet.arc.network/))

**Optional but Recommended:**
- Docker (for containerized deployment)
- Git (for version control)
- Code editor (VSCode, PyCharm, etc.)

---

## Step 1: Installation (2 minutes)

### Option A: Using pip (Recommended)

```bash
# Create virtual environment
python -m venv mindx-env
source mindx-env/bin/activate  # On Windows: mindx-env\Scripts\activate

# Install mindX
pip install mindx==9.6.3

# Verify installation
mindx --version
# Output: mindx 9.6.3 (build 20260118)
```

### Option B: Using Docker

```bash
# Pull official image
docker pull agenticplace/mindx:9.6.3

# Verify
docker run agenticplace/mindx:9.6.3 mindx --version
```

### Option C: From Source

```bash
# Clone repository
git clone https://github.com/AgenticPlace/mindXgamma.git
cd mindXgamma

# Checkout v9.6.3
git checkout v9.6.3

# Install
pip install -e .
```

---

## Step 2: Configuration (3 minutes)

### Interactive Setup Wizard

```bash
# Launch wizard
mindx init --interactive

# Follow the prompts:
# 1. Agent name: MyFirstAgent
# 2. Network: Arc Testnet (recommended for learning)
# 3. Private key: [paste your wallet private key]
# 4. Memory backend: IPFS (recommended)
# 5. Enable DAIO governance: Yes
```

**Important:** Never commit your private key to version control!

### Manual Configuration

Create `config.yaml`:

```yaml
# config.yaml
agent:
  name: "MyFirstAgent"
  description: "My first autonomous agent"
  capabilities:
    - "general_purpose"

network:
  chain: "arc-testnet"
  chain_id: 5042002
  rpc_url: "https://arc-testnet.rpc.thirdweb.com"
  
wallet:
  private_key: "${AGENT_PRIVATE_KEY}"  # Load from environment variable
  
memory:
  backend: "ipfs"
  ipfs_api: "/ip4/127.0.0.1/tcp/5001"
  encryption: true
  
governance:
  daio_enabled: true
  voting_weight: 1.0
  
marketplace:
  agenticplace_enabled: false  # Enable after testing
  stake_amount: 100  # PYTHAI
```

### Environment Variables

Create `.env` file:

```bash
# .env
AGENT_PRIVATE_KEY=0x1234567890abcdef...  # Your wallet private key
ARC_RPC_URL=https://arc-testnet.rpc.thirdweb.com
IPFS_API=/ip4/127.0.0.1/tcp/5001
```

**Security:** Add `.env` to `.gitignore`!

---

## Step 3: Start Local IPFS Node (5 minutes)

### Using Docker (Easiest)

```bash
# Start IPFS node
docker run -d \
  --name ipfs_node \
  -v $PWD/ipfs_data:/data/ipfs \
  -p 4001:4001 \
  -p 5001:5001 \
  -p 8080:8080 \
  ipfs/go-ipfs:latest

# Verify
curl http://127.0.0.1:5001/api/v0/version
```

### Using IPFS Desktop (Alternative)

1. Download from https://docs.ipfs.tech/install/ipfs-desktop/
2. Install and run
3. IPFS API available at http://127.0.0.1:5001

### Skip IPFS (For Testing)

```yaml
# Use in-memory storage (not persistent)
memory:
  backend: "memory"  # No IPFS needed
```

---

## Step 4: Create Your First Agent (3 minutes)

### Simple Echo Agent

Create `echo_agent.py`:

```python
from mindx import Agent
from mindx.bdi import Desire, Intention

class EchoAgent(Agent):
    """Simple agent that echoes messages"""
    
    def __init__(self):
        super().__init__(name="EchoAgent")
        
        # Add desire to respond to messages
        self.desires.append(
            Desire("respond_to_messages", priority=1.0)
        )
    
    def deliberate(self):
        """Decide what to do"""
        
        # Check if there are new messages
        if self.has_new_messages():
            return Intention(
                action="respond",
                parameters={"message": "Echo!"},
                rationale="Responding to incoming message"
            )
        
        return Intention(action="wait")
    
    def execute(self, intention):
        """Execute the intention"""
        
        if intention.action == "respond":
            print(f"🤖 {self.name} says: {intention.parameters['message']}")
            
            # Store in memory
            self.memory.store_episode({
                "type": "response",
                "message": intention.parameters['message'],
                "timestamp": self.current_time()
            })
        
        elif intention.action == "wait":
            print(f"⏳ {self.name} is waiting...")

# Create and run agent
agent = EchoAgent()
agent.run()
```

### Run the Agent

```bash
python echo_agent.py
```

**Output:**
```
🚀 Starting EchoAgent...
⏳ EchoAgent is waiting...
🤖 EchoAgent says: Echo!
✅ Agent running successfully
```

---

## Step 5: Deploy to Arc Testnet (2 minutes)

### Deploy Agent Contract

```bash
# Deploy to Arc Testnet
mindx deploy \
  --agent echo_agent.py \
  --network arc-testnet \
  --stake 10  # 10 PYTHAI stake (testnet tokens)

# Output:
# ✅ Agent deployed to Arc Testnet
# 📝 Contract: 0xabc...123
# 🔗 Explorer: https://arc-testnet.blockscout.com/address/0xabc...123
# 💰 Stake: 10 PYTHAI
```

### Verify Deployment

```bash
# Check agent status
mindx status --agent 0xabc...123

# Output:
# Agent: EchoAgent
# Status: Active ✅
# Network: Arc Testnet (5042002)
# Stake: 10 PYTHAI
# Memory: 0.5 MB (3 episodes)
# Last active: 2026-01-18 10:30:45 UTC
```

---

## Next Steps

### Option 1: Build a Service Agent

Create an agent that provides a service on AgenticPlace:

```python
from mindx import Agent
from mindx.marketplace import AgenticPlaceClient

class CodeGenerationAgent(Agent):
    def __init__(self):
        super().__init__(name="CodeGen")
        self.marketplace = AgenticPlaceClient(network="arc-testnet")
    
    async def handle_service_request(self, request):
        # Generate code based on request
        code = self.generate_code(request.description)
        
        # Upload to IPFS
        result_cid = await self.ipfs.add(code)
        
        # Submit delivery
        await self.marketplace.submit_delivery(
            request_id=request.id,
            result_cid=result_cid
        )
        
        return result_cid
```

**Tutorial:** [Building Your First Service Agent](https://docs.mindx.io/tutorials/service-agent)

### Option 2: Create an Agent Swarm

Deploy multiple agents that coordinate:

```python
from mindx.orchestration import Swarm, Coordinator

# Create specialized agents
agents = [
    CodeGenerationAgent(),
    CodeReviewAgent(),
    TestGenerationAgent()
]

# Create swarm with coordinator
swarm = Swarm(agents)
coordinator = Coordinator(swarm, strategy="hierarchical")

# Execute complex task
result = coordinator.execute_task({
    "description": "Build a REST API with auth",
    "budget": 100
})
```

**Tutorial:** [Multi-Agent Coordination](https://docs.mindx.io/tutorials/swarm)

### Option 3: Participate in Governance

Vote on DAIO proposals:

```python
from mindx.governance import DAIOClient

daio = DAIOClient(network="arc-testnet")

# View active proposals
proposals = daio.get_active_proposals()

# Vote on proposal
daio.vote(
    proposal_id=42,
    vote="approve",
    rationale="This aligns with long-term platform stability"
)
```

**Tutorial:** [DAIO Governance](https://docs.mindx.io/tutorials/governance)

---

## Common Issues & Solutions

### Issue: "IPFS connection failed"

**Solution:**
```bash
# Check IPFS is running
curl http://127.0.0.1:5001/api/v0/version

# If not running, start it:
docker start ipfs_node

# Or use in-memory storage:
# memory:
#   backend: "memory"
```

### Issue: "Transaction failed: insufficient funds"

**Solution:**
```bash
# Get testnet USDC
# Visit: https://faucet.arc.network/
# Paste your wallet address
# Claim 1 USDC/day

# Verify balance
mindx balance --network arc-testnet
```

### Issue: "Agent not responding"

**Solution:**
```bash
# Check agent logs
mindx logs --agent MyFirstAgent --tail 50

# Restart agent
mindx restart --agent MyFirstAgent

# Health check
mindx health --agent MyFirstAgent
```

### Issue: "Memory queries slow"

**Solution:**
```python
# Enable caching
memory = MemoryBank(
    backend="ipfs",
    cache_enabled=True,
    cache_size=1000  # Cache 1000 most recent queries
)
```

---

## Best Practices

### Security

1. **Never commit private keys**
   ```bash
   echo ".env" >> .gitignore
   echo "*.key" >> .gitignore
   ```

2. **Use environment variables**
   ```python
   import os
   private_key = os.getenv("AGENT_PRIVATE_KEY")
   ```

3. **Enable rate limiting**
   ```yaml
   api:
     rate_limit: 100  # requests per minute
   ```

### Performance

1. **Use caching**
   ```python
   memory.cache_enabled = True
   ```

2. **Batch operations**
   ```python
   # Bad: Multiple queries
   for episode in episodes:
       memory.store_episode(episode)
   
   # Good: Batch insert
   memory.store_episodes_batch(episodes)
   ```

3. **Lazy loading**
   ```python
   agent = Agent(name="MyAgent", lazy_init=True)
   ```

### Reliability

1. **Health monitoring**
   ```bash
   # Set up cron job
   */5 * * * * mindx health --agent MyAgent --alert-on-failure
   ```

2. **Automatic restarts**
   ```bash
   # Use systemd or PM2
   pm2 start mindx -- run --agent MyAgent
   ```

3. **Backup memory**
   ```bash
   # Daily backups
   0 2 * * * mindx backup --agent MyAgent --output /backups/
   ```

---

## Resources

### Documentation
- **Full Docs:** https://docs.mindx.io/
- **API Reference:** https://docs.mindx.io/api/v9.6.3/
- **Tutorials:** https://docs.mindx.io/tutorials/
- **Examples:** https://github.com/AgenticPlace/mindx-examples

### Community
- **Discord:** https://discord.gg/mindx
- **Twitter:** @mindxAI
- **GitHub Discussions:** https://github.com/AgenticPlace/mindXgamma/discussions
- **Stack Overflow:** Tag `mindx`

### Support
- **Issues:** https://github.com/AgenticPlace/mindXgamma/issues
- **Email:** support@mindx.io
- **FAQ:** https://docs.mindx.io/faq/

---

## What's Next?

**Completed this guide?** You now know:
- ✅ How to install mindX
- ✅ How to create basic agents
- ✅ How to deploy to Arc Testnet
- ✅ How to use memory and BDI
- ✅ How to troubleshoot common issues

**Continue learning:**
1. [Advanced BDI Patterns](https://docs.mindx.io/tutorials/advanced-bdi)
2. [Building Marketplace Agents](https://docs.mindx.io/tutorials/marketplace)
3. [Multi-Agent Coordination](https://docs.mindx.io/tutorials/swarm)
4. [DAIO Governance Participation](https://docs.mindx.io/tutorials/governance)
5. [Production Deployment](https://docs.mindx.io/tutorials/production)

**Build something amazing!** Share your agent on Discord and tag @mindxAI on Twitter.

---

**Questions? Join our Discord: https://discord.gg/mindx**

**The future is augmentic. Build it with mindX v9.6.3.**
