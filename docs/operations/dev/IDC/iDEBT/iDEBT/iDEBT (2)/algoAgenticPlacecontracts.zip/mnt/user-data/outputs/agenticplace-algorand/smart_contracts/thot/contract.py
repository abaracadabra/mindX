# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# THOT — Transferable Hyper-Optimized Tensor (Algorand ASA)
#
# Mirrors the AgenticPlace `THOT` type from agenticplace.pythai.net/register:
#
#   "THOT — Knowledge tensor. Immutable (no manager). Requires IPFS data
#    CID. Dimensions: 64/384/512/768. One CID per THOT."
#
# This implementation extends the official schema with **1024-dimension**
# support for high-fidelity embedders (text-embedding-3-large,
# mxbai-embed-large, BGE-large) and the mindX 768 → 1024 expansion path.
#
# Supported dimensions: { 64, 384, 512, 768, 1024 }
#
# Uniqueness enforcement: every THOT mint stores a second box keyed by
# sha256(data_cid). Re-minting the same CID reverts. Reverse lookup via
# `lookup_cid()` returns the original ASA id.

from algopy import (
    ARC4Contract,
    Account,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    DEFAULT_MINT_FEE_MICROALGOS,
    KIND_THOT,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
    THOT_DIM_64,
    THOT_DIM_384,
    THOT_DIM_512,
    THOT_DIM_768,
    THOT_DIM_1024,
)


# ─────────────────────────────────────────────────────────────────────────
#  Box records
# ─────────────────────────────────────────────────────────────────────────
class TensorRecord(arc4.Struct):
    """Identity + tensor record for a THOT ASA."""

    # ARC-69 identity
    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address

    # Mint flow state
    pending_owner: arc4.Address
    claimed: arc4.Bool

    # Tensor config
    data_cid: arc4.String
    dimensions: arc4.UInt16
    tensor_hash: arc4.StaticArray[arc4.Byte, arc4.UInt64]  # 32 bytes (sha256)


class CidIndex(arc4.Struct):
    """Reverse lookup record: sha256(data_cid) -> asset id."""

    asset_id: arc4.UInt64
    minter: arc4.Address
    minted_at: arc4.UInt64


class THOT(ARC4Contract):
    """Knowledge tensor NFT factory with global CID uniqueness."""

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)

        # asset_id -> TensorRecord
        self.tensors = BoxMap(UInt64, TensorRecord, key_prefix=b"th")
        # sha256(data_cid) -> CidIndex (uniqueness gate)
        self.cid_index = BoxMap(Bytes, CidIndex, key_prefix=b"ci")

    # ─── lifecycle ─────────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(DEFAULT_MINT_FEE_MICROALGOS)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    # ─── helpers ──────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def is_supported_dimension(self, d: arc4.UInt16) -> arc4.Bool:
        n = d.native
        return arc4.Bool(
            n == UInt64(THOT_DIM_64)
            or n == UInt64(THOT_DIM_384)
            or n == UInt64(THOT_DIM_512)
            or n == UInt64(THOT_DIM_768)
            or n == UInt64(THOT_DIM_1024)
        )

    # ─── mint (step 1: create the ASA) ────────────────────────────────────
    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        data_cid: arc4.String,
        dimensions: arc4.UInt16,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        # Validate payment
        assert payment.receiver == Global.current_application_address, "wrong receiver"
        assert payment.amount >= self.mint_fee.value, "fee too low"
        assert payment.sender == Txn.sender, "fee sender mismatch"

        # Validate identity
        assert name.native.length > 0, "empty name"
        assert unit_name.native.length <= UInt64(MAX_UNIT_NAME), "unit_name too long"
        assert metadata_note.native.length <= UInt64(MAX_NOTE_LENGTH), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"

        # Validate tensor config
        assert data_cid.native.length > 0, "empty CID"
        d = dimensions.native
        assert (
            d == UInt64(THOT_DIM_64)
            or d == UInt64(THOT_DIM_384)
            or d == UInt64(THOT_DIM_512)
            or d == UInt64(THOT_DIM_768)
            or d == UInt64(THOT_DIM_1024)
        ), "unsupported dimensions"

        # Enforce CID uniqueness via box index keyed by sha256(data_cid).
        cid_key = op.sha256(data_cid.native)
        assert cid_key not in self.cid_index, "CID already minted"

        # Create the immutable ASA — every address role is the zero address.
        # Once issued, the asset can never be reconfigured by anyone.
        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        new_asset_id = result.created_asset.id

        # tensor_hash = sha256 of the data_cid bytes (placeholder — in
        # production the off-chain pipeline pre-computes a sha256 over the
        # raw tensor blob and supplies it; we hash the CID here so the
        # struct is well-formed even if the caller did not provide one).
        tensor_hash_bytes = op.sha256(data_cid.native)

        self.tensors[new_asset_id] = TensorRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
            data_cid=data_cid,
            dimensions=dimensions,
            tensor_hash=arc4.StaticArray[arc4.Byte, arc4.UInt64].from_bytes(
                tensor_hash_bytes
            ),
        )

        self.cid_index[cid_key] = CidIndex(
            asset_id=arc4.UInt64(new_asset_id),
            minter=arc4.Address(Txn.sender),
            minted_at=arc4.UInt64(Global.latest_timestamp),
        )

        self.total_minted.value += UInt64(1)
        return arc4.UInt64(new_asset_id)

    # ─── mint (step 2: claim) ─────────────────────────────────────────────
    @arc4.abimethod
    def claim(self, asset_id: arc4.UInt64) -> None:
        rec = self.tensors[asset_id.native].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native.bytes, "not pending owner"

        itxn.AssetTransfer(
            xfer_asset=asset_id.native,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.tensors[asset_id.native] = rec.copy()

    # ─── views ────────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_tensor(self, asset_id: arc4.UInt64) -> TensorRecord:
        return self.tensors[asset_id.native]

    @arc4.abimethod(readonly=True)
    def lookup_cid(self, data_cid: arc4.String) -> arc4.UInt64:
        """Reverse lookup: given a CID, return the THOT ASA id that owns it."""
        cid_key = op.sha256(data_cid.native)
        return self.cid_index[cid_key].asset_id

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
