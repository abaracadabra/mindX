# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# AgenticPlaceRegistry — Algorand binding directory
#
# Mirrors the AgenticPlace register flow at agenticplace.pythai.net/register.
# Accepts an ASA id minted by ANY of the four NFT contracts in this project
# (or any third-party Algorand NFT) and binds it to:
#
#     - MCP endpoint
#     - A2A endpoint
#     - Directive address (Algorand)
#     - Website
#     - Trust model bitmap (Reputation, Crypto-Economic, TEE upcoming, zkML upcoming)
#     - Skills (comma-separated, packed into a single string)
#     - Cached intelligence level + autonomy flag
#
# The registry never custodies assets — it only stores metadata bindings
# keyed by (nft_app_id, asset_id). Worst-case impact of a registry compromise
# is metadata corruption, never asset loss.
#
# Reusable: any project can register their own ASAs as long as the caller
# currently holds the asset.

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    DEFAULT_MINT_FEE_MICROALGOS,
    TRUST_BITMAP_MAX,
)


# ─────────────────────────────────────────────────────────────────────────
#  Box record
# ─────────────────────────────────────────────────────────────────────────
class AgentBinding(arc4.Struct):
    """One row in the AgenticPlace registry, keyed by (nft_app_id, asset_id)."""

    nft_app_id: arc4.UInt64
    asset_id: arc4.UInt64
    owner: arc4.Address

    mcp_endpoint: arc4.String
    a2a_endpoint: arc4.String
    directive: arc4.Address
    website: arc4.String

    trust_models: arc4.UInt8
    skills: arc4.String  # comma-separated

    intelligence_level: arc4.UInt8
    autonomous: arc4.Bool

    registered_at: arc4.UInt64
    updated_at: arc4.UInt64
    active: arc4.Bool


class AgenticPlaceRegistry(ARC4Contract):
    """On-chain directory for agent NFTs minted via AgenticPlace."""

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_bindings = GlobalState(UInt64)

        # Optional mindX backend (an Algorand application id, 0 if not set).
        self.mindx_app_id = GlobalState(UInt64)
        self.mindx_gated = GlobalState(UInt64)  # 0 = off, 1 = on

        # (nft_app_id || asset_id) -> AgentBinding
        self.bindings = BoxMap(Bytes, AgentBinding, key_prefix=b"bd")

    # ─── lifecycle ─────────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(DEFAULT_MINT_FEE_MICROALGOS)
        self.total_bindings.value = UInt64(0)
        self.mindx_app_id.value = UInt64(0)
        self.mindx_gated.value = UInt64(0)

    # ─── admin ────────────────────────────────────────────────────────────
    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    @arc4.abimethod
    def set_mindx(self, app_id: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mindx_app_id.value = app_id.native

    @arc4.abimethod
    def set_mindx_gated(self, gated: arc4.Bool) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mindx_gated.value = UInt64(1) if gated.native else UInt64(0)

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()

    # ─── helpers ──────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def binding_key(self, nft_app_id: arc4.UInt64, asset_id: arc4.UInt64) -> Bytes:
        """Stable key for the bindings box map."""
        return nft_app_id.bytes + asset_id.bytes

    # ─── public registration ──────────────────────────────────────────────
    @arc4.abimethod
    def register(
        self,
        nft_app_id: arc4.UInt64,
        asset: Asset,
        mcp_endpoint: arc4.String,
        a2a_endpoint: arc4.String,
        directive: arc4.Address,
        website: arc4.String,
        trust_models: arc4.UInt8,
        skills: arc4.String,
        intelligence_level: arc4.UInt8,
        autonomous: arc4.Bool,
        payment: gtxn.PaymentTransaction,
    ) -> Bytes:
        # Validate payment
        assert payment.receiver == Global.current_application_address, "wrong receiver"
        assert payment.amount >= self.mint_fee.value, "fee too low"
        assert payment.sender == Txn.sender, "fee sender mismatch"

        # Validate trust bitmap
        assert trust_models.native <= UInt64(TRUST_BITMAP_MAX), "invalid trust bitmap"

        # Caller must currently hold the ASA. This is the only authentication
        # gate the registry needs — it works for ASAs minted by any of our
        # four contracts and for any third-party Algorand NFT.
        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        key = nft_app_id.bytes + asset.id.bytes
        assert key not in self.bindings, "already registered"

        self.bindings[key] = AgentBinding(
            nft_app_id=nft_app_id,
            asset_id=arc4.UInt64(asset.id),
            owner=arc4.Address(Txn.sender),
            mcp_endpoint=mcp_endpoint,
            a2a_endpoint=a2a_endpoint,
            directive=directive,
            website=website,
            trust_models=trust_models,
            skills=skills,
            intelligence_level=intelligence_level,
            autonomous=autonomous,
            registered_at=arc4.UInt64(Global.latest_timestamp),
            updated_at=arc4.UInt64(Global.latest_timestamp),
            active=arc4.Bool(True),  # noqa: FBT003
        )

        self.total_bindings.value += UInt64(1)
        return key

    @arc4.abimethod
    def update(
        self,
        nft_app_id: arc4.UInt64,
        asset: Asset,
        mcp_endpoint: arc4.String,
        a2a_endpoint: arc4.String,
        directive: arc4.Address,
        website: arc4.String,
        trust_models: arc4.UInt8,
        skills: arc4.String,
        intelligence_level: arc4.UInt8,
        autonomous: arc4.Bool,
    ) -> None:
        assert trust_models.native <= UInt64(TRUST_BITMAP_MAX), "invalid trust bitmap"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists and balance == UInt64(1), "caller is not the asset holder"

        key = nft_app_id.bytes + asset.id.bytes
        rec = self.bindings[key].copy()

        rec.owner = arc4.Address(Txn.sender)
        rec.mcp_endpoint = mcp_endpoint
        rec.a2a_endpoint = a2a_endpoint
        rec.directive = directive
        rec.website = website
        rec.trust_models = trust_models
        rec.skills = skills
        rec.intelligence_level = intelligence_level
        rec.autonomous = autonomous
        rec.updated_at = arc4.UInt64(Global.latest_timestamp)

        self.bindings[key] = rec.copy()

    @arc4.abimethod
    def deactivate(self, nft_app_id: arc4.UInt64, asset: Asset) -> None:
        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists and balance == UInt64(1), "caller is not the asset holder"

        key = nft_app_id.bytes + asset.id.bytes
        rec = self.bindings[key].copy()
        rec.active = arc4.Bool(False)  # noqa: FBT003
        rec.updated_at = arc4.UInt64(Global.latest_timestamp)
        self.bindings[key] = rec.copy()

    # ─── views ────────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_binding(
        self, nft_app_id: arc4.UInt64, asset_id: arc4.UInt64
    ) -> AgentBinding:
        key = nft_app_id.bytes + asset_id.bytes
        return self.bindings[key]

    @arc4.abimethod(readonly=True)
    def is_registered(
        self, nft_app_id: arc4.UInt64, asset_id: arc4.UInt64
    ) -> arc4.Bool:
        key = nft_app_id.bytes + asset_id.bytes
        return arc4.Bool(key in self.bindings)
