# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# Unit tests for the AgenticPlace Algorand stack.
#
# Uses `algorand-python-testing` (algopy_testing) which lets us exercise
# the algopy contracts in pure Python without spinning up a localnet.
#
# Run with:
#     pytest tests/ -vv

from __future__ import annotations

import pytest
from algopy import arc4, Bytes, UInt64
import algopy_testing
from algopy_testing import AlgopyTestContext, algopy_testing_context

from smart_contracts.anft.contract import ANFT
from smart_contracts.dnft.contract import DNFT
from smart_contracts.inft.contract import INFT
from smart_contracts.thot.contract import THOT
from smart_contracts.registry.contract import AgenticPlaceRegistry
from smart_contracts.common.constants import (
    AGENT_TYPE_COGNITIVE_AUGMENTATION,
    AGENT_TYPE_ANALYTICAL_PROCESSING,
    DEFAULT_MINT_FEE_MICROALGOS,
    THOT_DIM_64,
    THOT_DIM_384,
    THOT_DIM_512,
    THOT_DIM_768,
    THOT_DIM_1024,
    TRUST_REPUTATION,
    TRUST_CRYPTO_ECONOMIC,
)


# ─────────────────────────────────────────────────────────────────────────
#  Fixture helpers
# ─────────────────────────────────────────────────────────────────────────
@pytest.fixture()
def ctx() -> AlgopyTestContext:
    with algopy_testing_context() as c:
        yield c


def _identity_args() -> dict:
    return {
        "name": arc4.String("alpha"),
        "unit_name": arc4.String("ALPHA"),
        "agent_type": arc4.UInt8(AGENT_TYPE_COGNITIVE_AUGMENTATION),
        "metadata_note": arc4.String('{"standard":"arc69","description":"test"}'),
    }


def _payment(ctx: AlgopyTestContext, amount: int):
    return ctx.any.txn.payment(
        sender=ctx.default_sender,
        receiver=ctx.ledger.get_app(ctx.active_app_id).address,
        amount=UInt64(amount),
    )


# ─────────────────────────────────────────────────────────────────────────
#  ANFT
# ─────────────────────────────────────────────────────────────────────────
class TestANFT:
    def test_create_and_mint(self, ctx: AlgopyTestContext) -> None:
        contract = ANFT()
        contract.create()

        assert contract.mint_fee.value == UInt64(DEFAULT_MINT_FEE_MICROALGOS)
        assert contract.total_minted.value == UInt64(0)

    def test_mint_increments_total(self, ctx: AlgopyTestContext) -> None:
        contract = ANFT()
        contract.create()

        payment = _payment(ctx, DEFAULT_MINT_FEE_MICROALGOS)
        with ctx.txn.create_group([ctx.any.txn.application_call()]):
            asset_id = contract.mint(
                payment=payment,
                **_identity_args(),
            )

        assert contract.total_minted.value == UInt64(1)
        rec = contract.identities[asset_id.native]
        assert rec.claimed.native is False
        assert rec.minter.native.bytes == ctx.default_sender.bytes

    def test_kind_is_anft(self, ctx: AlgopyTestContext) -> None:
        contract = ANFT()
        contract.create()
        kind_bytes = contract.kind().bytes
        assert kind_bytes == Bytes(b"aNFT")


# ─────────────────────────────────────────────────────────────────────────
#  DNFT
# ─────────────────────────────────────────────────────────────────────────
class TestDNFT:
    def test_freeze_blocks_further_updates(self, ctx: AlgopyTestContext) -> None:
        contract = DNFT()
        contract.create()

        payment = _payment(ctx, DEFAULT_MINT_FEE_MICROALGOS)
        asset_id = contract.mint(payment=payment, **_identity_args())

        # Direct box mutation to simulate freeze (bypassing the ASA inner txn
        # which the testing harness mocks). The contract's freeze() method
        # would normally do this plus an inner asset config; here we are
        # asserting the box-level invariant.
        rec = contract.identities[asset_id.native].copy()
        rec.frozen = arc4.Bool(True)
        contract.identities[asset_id.native] = rec.copy()

        assert contract.is_frozen(asset_id).native is True


# ─────────────────────────────────────────────────────────────────────────
#  INFT — directive autonomy
# ─────────────────────────────────────────────────────────────────────────
class TestINFT:
    def test_self_update_only_directive(self, ctx: AlgopyTestContext) -> None:
        contract = INFT()
        contract.create()

        directive = ctx.any.account()
        payment = _payment(ctx, DEFAULT_MINT_FEE_MICROALGOS)

        asset_id = contract.mint(
            name=arc4.String("smart"),
            unit_name=arc4.String("SMART"),
            agent_type=arc4.UInt8(AGENT_TYPE_COGNITIVE_AUGMENTATION),
            metadata_note=arc4.String('{"standard":"arc69"}'),
            directive=arc4.Address(directive),
            level=arc4.UInt8(60),
            autonomous=arc4.Bool(True),  # noqa: FBT003
            behavior_cid=arc4.String("QmBehavior"),
            payment=payment,
        )

        rec = contract.records[asset_id.native]
        assert rec.directive.native.bytes == directive.bytes
        assert rec.level == arc4.UInt8(60)

    def test_freeze_severs_directive(self, ctx: AlgopyTestContext) -> None:
        contract = INFT()
        contract.create()

        directive = ctx.any.account()
        payment = _payment(ctx, DEFAULT_MINT_FEE_MICROALGOS)
        asset_id = contract.mint(
            name=arc4.String("smart"),
            unit_name=arc4.String("SMART"),
            agent_type=arc4.UInt8(AGENT_TYPE_COGNITIVE_AUGMENTATION),
            metadata_note=arc4.String("{}"),
            directive=arc4.Address(directive),
            level=arc4.UInt8(60),
            autonomous=arc4.Bool(True),  # noqa: FBT003
            behavior_cid=arc4.String("QmX"),
            payment=payment,
        )

        # Simulate the freeze box-state effects
        rec = contract.records[asset_id.native].copy()
        rec.frozen = arc4.Bool(True)
        rec.directive = arc4.Address(ctx.ledger.get_app(0).address)
        rec.autonomous = arc4.Bool(False)
        contract.records[asset_id.native] = rec.copy()

        assert contract.is_frozen(asset_id).native is True
        assert contract.records[asset_id.native].autonomous.native is False


# ─────────────────────────────────────────────────────────────────────────
#  THOT — dimensions and CID uniqueness
# ─────────────────────────────────────────────────────────────────────────
class TestTHOT:
    @pytest.mark.parametrize("dim", [THOT_DIM_64, THOT_DIM_384, THOT_DIM_512, THOT_DIM_768, THOT_DIM_1024])
    def test_supports_dimension(self, ctx: AlgopyTestContext, dim: int) -> None:
        contract = THOT()
        contract.create()
        assert contract.is_supported_dimension(arc4.UInt16(dim)).native is True

    def test_rejects_unsupported_dimension(self, ctx: AlgopyTestContext) -> None:
        contract = THOT()
        contract.create()
        assert contract.is_supported_dimension(arc4.UInt16(256)).native is False
        assert contract.is_supported_dimension(arc4.UInt16(1536)).native is False

    def test_1024_dim_mint_path(self, ctx: AlgopyTestContext) -> None:
        contract = THOT()
        contract.create()

        payment = _payment(ctx, DEFAULT_MINT_FEE_MICROALGOS)
        asset_id = contract.mint(
            name=arc4.String("rag-1024"),
            unit_name=arc4.String("RAG1024"),
            agent_type=arc4.UInt8(AGENT_TYPE_ANALYTICAL_PROCESSING),
            metadata_note=arc4.String('{"standard":"arc69"}'),
            data_cid=arc4.String("QmDeltaVerseRagBig"),
            dimensions=arc4.UInt16(1024),
            payment=payment,
        )

        tensor = contract.tensors[asset_id.native]
        assert tensor.dimensions == arc4.UInt16(1024)
        assert tensor.data_cid.native == arc4.String("QmDeltaVerseRagBig").native

    def test_cid_uniqueness(self, ctx: AlgopyTestContext) -> None:
        contract = THOT()
        contract.create()

        payment = _payment(ctx, DEFAULT_MINT_FEE_MICROALGOS)
        contract.mint(
            name=arc4.String("first"),
            unit_name=arc4.String("FIRST"),
            agent_type=arc4.UInt8(AGENT_TYPE_ANALYTICAL_PROCESSING),
            metadata_note=arc4.String("{}"),
            data_cid=arc4.String("QmDuplicate"),
            dimensions=arc4.UInt16(768),
            payment=payment,
        )

        # Second mint with the same CID must revert.
        with pytest.raises(AssertionError, match="CID already minted"):
            contract.mint(
                name=arc4.String("second"),
                unit_name=arc4.String("SECOND"),
                agent_type=arc4.UInt8(AGENT_TYPE_ANALYTICAL_PROCESSING),
                metadata_note=arc4.String("{}"),
                data_cid=arc4.String("QmDuplicate"),
                dimensions=arc4.UInt16(768),
                payment=_payment(ctx, DEFAULT_MINT_FEE_MICROALGOS),
            )


# ─────────────────────────────────────────────────────────────────────────
#  Registry
# ─────────────────────────────────────────────────────────────────────────
class TestRegistry:
    def test_create_initializes_state(self, ctx: AlgopyTestContext) -> None:
        contract = AgenticPlaceRegistry()
        contract.create()

        assert contract.mint_fee.value == UInt64(DEFAULT_MINT_FEE_MICROALGOS)
        assert contract.total_bindings.value == UInt64(0)
        assert contract.mindx_app_id.value == UInt64(0)
        assert contract.mindx_gated.value == UInt64(0)

    def test_set_mindx_admin_only(self, ctx: AlgopyTestContext) -> None:
        contract = AgenticPlaceRegistry()
        contract.create()

        contract.set_mindx(arc4.UInt64(12345))
        assert contract.mindx_app_id.value == UInt64(12345)

    def test_trust_bitmap_validation(self, ctx: AlgopyTestContext) -> None:
        # The TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC bitmap is the full
        # set of currently-supported trust models per the register form.
        full = TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC
        assert full == 0b11
        assert full <= 0x0F
