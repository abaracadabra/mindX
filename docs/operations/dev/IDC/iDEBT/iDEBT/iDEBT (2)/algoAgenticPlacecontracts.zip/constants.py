# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# Common constants for the AgenticPlace Algorand contracts.
#
# These mirror the discriminators and validation rules used by the
# AgenticPlace register form at agenticplace.pythai.net/register so that
# every NFT minted by these contracts is indexable by 8004scan and any
# downstream ARC-69 reader.

from algopy import UInt64, Bytes


# ─────────────────────────────────────────────────────────────────────────
# NFT kind discriminators — written into box storage so the registry can
# tell which type a given ASA was minted as without making an app call.
# ─────────────────────────────────────────────────────────────────────────
KIND_ANFT: bytes = b"aNFT"
KIND_DNFT: bytes = b"dNFT"
KIND_INFT: bytes = b"iNFT"
KIND_THOT: bytes = b"THOT"


# ─────────────────────────────────────────────────────────────────────────
# Mint fee — matches the AgenticPlace register form ("Mint cost: 0.001 ALGO")
# ─────────────────────────────────────────────────────────────────────────
DEFAULT_MINT_FEE_MICROALGOS: int = 1_000  # 0.001 ALGO


# ─────────────────────────────────────────────────────────────────────────
# THOT supported embedding dimensions.
#
# The register form lists 64 / 384 (pgvector) / 512 / 768. This deployment
# adds 1024 for high-fidelity embedders (text-embedding-3-large,
# mxbai-embed-large, BGE-large) and the mindX 768 → 1024 expansion path.
# ─────────────────────────────────────────────────────────────────────────
THOT_DIM_64: int = 64
THOT_DIM_384: int = 384
THOT_DIM_512: int = 512
THOT_DIM_768: int = 768
THOT_DIM_1024: int = 1024


# ─────────────────────────────────────────────────────────────────────────
# Trust model bitmap (Reputation, Crypto-Economic, TEE upcoming, zkML upcoming)
# ─────────────────────────────────────────────────────────────────────────
TRUST_REPUTATION: int = 1 << 0
TRUST_CRYPTO_ECONOMIC: int = 1 << 1
TRUST_TEE: int = 1 << 2  # upcoming
TRUST_ZKML: int = 1 << 3  # upcoming
TRUST_BITMAP_MAX: int = 0x0F


# ─────────────────────────────────────────────────────────────────────────
# Agent type discriminators — match the AgenticPlace register form dropdown.
# ─────────────────────────────────────────────────────────────────────────
AGENT_TYPE_NONE: int = 0
AGENT_TYPE_COGNITIVE_AUGMENTATION: int = 1
AGENT_TYPE_CREATIVE_INTELLIGENCE: int = 2
AGENT_TYPE_ANALYTICAL_PROCESSING: int = 3
AGENT_TYPE_SPECIALIZED_DOMAIN: int = 4
AGENT_TYPE_AGENT_ORCHESTRATOR: int = 5


# ─────────────────────────────────────────────────────────────────────────
# Maximum ARC-69 note length. The Algorand transaction note field is
# capped at 1024 bytes. We leave 24 bytes of headroom for system fields.
# ─────────────────────────────────────────────────────────────────────────
MAX_NOTE_LENGTH: int = 1000

# Maximum unit name length per ARC-69 spec.
MAX_UNIT_NAME: int = 8

# Intelligence level cap.
MAX_INTELLIGENCE_LEVEL: int = 100
