# AgenticPlace Algorand Contracts

Five algopy smart contracts that implement the four NFT types from the
[AgenticPlace register flow](https://agenticplace.pythai.net/register) on
Algorand, plus a binding registry that mirrors the form's directory layer.

```
© 2026 BANKON • Professor Codephreak
agenticplace.pythai.net • mindx.pythai.net • bankon.pythai.net
```

Each NFT class is a separate AlgoKit / algopy contract compiled via Puya into
TEAL. The contracts are independent — they do not import each other and
do not share global state. They interact exclusively through the registry.

---

## Contract map

| Contract | AgenticPlace type | ASA manager | Mutability | Special features |
| --- | --- | --- | --- | --- |
| `ANFT` | `aNFT` | Zero address | Immutable from mint | Static identity |
| `DNFT` | `dNFT` | Application | Holder can update note | `freeze()` clears manager → permanent |
| `INFT` | `iNFT` | Application | Holder + directive | Self-update by directive address |
| `THOT` | `THOT` | Zero address | Immutable | CID-unique • dims **64 / 384 / 512 / 768 / 1024** |
| `AgenticPlaceRegistry` | (the directory) | n/a | Owner-updatable | Binds any ASA to MCP/A2A/trust/skills |

Every per-type behavior in the table comes directly from the AgenticPlace
register page wording. The only intentional addition is **1024-dimension
support for THOT** — the page lists 64 / 384 / 512 / 768; the contract
extends that to include 1024 for high-fidelity embedders.

---

## ARC-69 metadata model

All four NFT contracts emit ARC-69-compliant assets. The full ARC-69 JSON
goes into the asset config note field at mint time. For dynamic types
(`dNFT`, `iNFT`) the application — which is the on-chain manager — issues
subsequent inner asset config transactions to update that note. Indexers
like 8004scan walk an asset's config-tx history and use the most recent
note as the current metadata snapshot.

Example ARC-69 note for an iNFT:

```json
{
  "standard": "arc69",
  "description": "Cognitive augmentation agent",
  "external_url": "https://example.com",
  "media_url": "ipfs://QmAvatar",
  "properties": {
    "agent_type": "Cognitive Augmentation",
    "intelligence_level": 75,
    "autonomous": true,
    "behavior_cid": "QmBehaviorProgram",
    "skills": ["research", "synthesis"],
    "trust_models": 3
  }
}
```

The note must fit in 1000 bytes (the contract enforces this) — Algorand's
hard transaction note limit is 1024 bytes and we leave 24 bytes of headroom
for system fields.

---

## ASA mint semantics per type

### ANFT — `aNFT`

```
manager   = ZeroAddress
reserve   = ZeroAddress
freeze    = ZeroAddress
clawback  = ZeroAddress
total     = 1
decimals  = 0
note      = ARC-69 JSON
```

Setting every address role to zero at creation makes the asset
**permanently immutable**. No party — not the minter, not the contract
admin, not the holder — can ever update the note or any other field. This
matches the form's wording: *"No manager address. Permanent on-chain
identity. Cannot be updated after mint."*

### DNFT — `dNFT`

```
manager   = ApplicationAddress      ← critical: enables future reconfigs
reserve   = ZeroAddress
freeze    = ZeroAddress
clawback  = ZeroAddress
```

The current asset holder calls `update_note(asset, new_note)` and the
contract verifies their balance is 1, then issues an inner asset config tx
keeping `manager = ApplicationAddress` and replacing the note. Every other
address role is re-supplied as zero to keep them revoked.

`freeze(asset)` issues a final config that sets `manager = ZeroAddress`,
permanently locking the asset. After this it behaves identically to an
`ANFT`.

> ⚠️ Algorand quirk: any address role omitted from an asset config tx is
> set to zero, not preserved. Once a role is zero it can never be restored.
> The contract always re-supplies every address explicitly to avoid this trap.

### INFT — `iNFT`

Same ASA shape as `DNFT` (manager = application). Adds two distinct
privilege tracks tracked in box storage:

| Action | Caller | Reason |
| --- | --- | --- |
| `mint`, `claim`, `update_identity`, `set_directive`, `freeze` | Asset holder | Human / owner controls the asset |
| `self_update(level, autonomous, behavior_cid, new_note)` | Directive address only | Agent evolves itself |

`freeze` does two things in one call:

1. Issues an inner asset config setting `manager = ZeroAddress`.
2. Clears the directive address in box storage.

After freeze the iNFT cannot self-update even if the directive key is
later compromised. This is the kill-switch the form description hints at.

### THOT — `THOT`

Same ASA shape as `ANFT` (every role zeroed), plus two extra invariants
enforced by the contract:

1. **Dimension whitelist.** `mint` reverts unless `dimensions ∈ {64, 384,
   512, 768, 1024}`. The first four come from the register form
   ("64 lightweight / 384 pgvector / 512 standard / 768 high-fidelity");
   1024 is added for high-fidelity embedders.

2. **CID uniqueness.** A second box map keyed by `sha256(data_cid)` indexes
   every minted THOT. Re-minting the same CID reverts with `"CID already minted"`.
   `lookup_cid(data_cid)` is the public reverse lookup.

This matches the form's *"Knowledge tensor. Immutable (no manager).
Requires IPFS data CID. Dimensions: 64/384/512/768. One CID per THOT."*

---

## Two-step mint flow (Algorand quirk)

Algorand requires an account to opt into an asset before it can hold any.
At the time `mint` is called, the new asset's id is unknown, so the caller
cannot pre-opt-in. The contracts therefore use a **mint → opt-in → claim**
flow:

```
1. Caller submits group: [Payment(0.001 ALGO), AppCall.mint(...)]
   → mint creates the ASA (held by the application) and records the
     caller as `pending_owner` in box storage.
   → mint returns the new asset_id.

2. Caller submits an opt-in: AssetTransfer(amount=0, sender=caller,
   receiver=caller, asset=new_asset_id)

3. Caller submits group: [AppCall.claim(asset_id)]
   → claim verifies the caller is `pending_owner` and the asset has not
     been claimed, then transfers the supply (1 token) to the caller via
     inner asset transfer.
```

Frontends typically hide this from the user — Pera and Parsec wallets sign
all three transactions in sequence on a single click.

---

## AgenticPlaceRegistry

Binds any ASA — minted by the four contracts in this repo or by any
third-party Algorand NFT — to the protocol endpoints, trust model, and
skill set described in the register form. The registry never custodies
assets; it only stores box-mapped binding records keyed by
`(nft_app_id, asset_id)`.

```python
binding_key = registry.register(
    nft_app_id=thot_app_id,
    asset=Asset(asset_id),
    mcp_endpoint="https://mcp.example/dvr1024",
    a2a_endpoint="https://a2a.example/dvr1024",
    directive=Address("ALGORAND_DIRECTIVE_ADDR..."),
    website="https://example.com",
    trust_models=arc4.UInt8(TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC),
    skills=arc4.String("retrieval,embedding,rag"),
    intelligence_level=arc4.UInt8(0),  # 0 if not iNFT
    autonomous=arc4.Bool(False),
    payment=PaymentTxn(amount=1000, ...),
)
```

Authentication: the only check the registry runs is *"does the caller
currently hold this asset?"* — verified via `AssetHoldingGet.asset_balance`.
This works for any Algorand NFT without the registry needing to know which
app minted it.

### mindX backend hook

The registry stores a `mindx_app_id` (an Algorand application id) plus a
`mindx_gated` flag. When set, the registry can call into the mindX
application via inner application calls to:

- request a behavior evaluation against an iNFT's `behavior_cid`
- pull a fresh consciousness attestation
- subscribe to a usage plan

The contract leaves the actual mindX integration as a hook — the wiring
calls are added once the mindX Algorand bridge is deployed.

---

## Project layout

```
agenticplace-algorand/
├── pyproject.toml
├── .algokit.toml
├── README.md
├── smart_contracts/
│   ├── __init__.py
│   ├── common/
│   │   ├── __init__.py
│   │   └── constants.py             discriminators, dim whitelist, trust bits
│   ├── anft/
│   │   ├── __init__.py
│   │   └── contract.py              ANFT — immutable
│   ├── dnft/
│   │   ├── __init__.py
│   │   └── contract.py              DNFT — manager-updatable + freeze
│   ├── inft/
│   │   ├── __init__.py
│   │   └── contract.py              INFT — directive autonomy
│   ├── thot/
│   │   ├── __init__.py
│   │   └── contract.py              THOT — knowledge tensor (1024 added)
│   └── registry/
│       ├── __init__.py
│       └── contract.py              AgenticPlaceRegistry
├── tests/
│   ├── __init__.py
│   └── test_contracts.py            algopy_testing harness
└── deploy/
    └── deploy.py                    AlgoKit deploy for all five
```

---

## Setup

This is an [AlgoKit](https://github.com/algorandfoundation/algokit-cli)
Python project using **algopy** (the typed Python language for Algorand
contracts that compiles to TEAL via Puya).

```bash
# Prerequisites
pip install algokit
algokit --version           # >= 2.0.0

# Bootstrap
cd agenticplace-algorand
poetry install              # or: pip install -e .

# Compile every contract to TEAL
algokit compile py smart_contracts/anft/contract.py
algokit compile py smart_contracts/dnft/contract.py
algokit compile py smart_contracts/inft/contract.py
algokit compile py smart_contracts/thot/contract.py
algokit compile py smart_contracts/registry/contract.py

# Run unit tests (algopy_testing — no localnet required)
pytest tests/ -vv
```

---

## Deployment

### LocalNet

```bash
algokit localnet start
NETWORK=localnet python deploy/deploy.py
```

### TestNet

```bash
export NETWORK=testnet
export DEPLOYER_MNEMONIC="word1 word2 ... word25"
python deploy/deploy.py
```

### MainNet

```bash
export NETWORK=mainnet
export DEPLOYER_MNEMONIC="word1 word2 ... word25"
python deploy/deploy.py
```

The deploy script writes a `deploy/deployment.json` file with all five
app ids and addresses so the frontend can pick them up.

---

## End-to-end: mint a 1024-dim THOT and register it

```python
from algokit_utils import AlgorandClient, PaymentParams
from algosdk.transaction import AssetOptInTxn

algorand = AlgorandClient.testnet()
caller = ...  # Account with the deployer's mnemonic

# 1. Mint the THOT (group: payment + app call).
mint_result = thot_client.send.mint(
    name="deltaverse-rag-1024",
    unit_name="DVR1024",
    agent_type=3,                    # ANALYTICAL_PROCESSING
    metadata_note=arc69_json,
    data_cid="QmDeltaVerseRagBig",
    dimensions=1024,
    payment=algorand.create_transaction.payment(
        PaymentParams(
            sender=caller.address,
            receiver=thot_client.app_address,
            amount=1000,             # 0.001 ALGO
        )
    ),
)
asset_id = mint_result.return_value

# 2. Opt the caller into the new asset.
algorand.send.asset_opt_in({"sender": caller.address, "asset_id": asset_id})

# 3. Claim the asset.
thot_client.send.claim(asset_id=asset_id)

# 4. Register on AgenticPlaceRegistry.
registry_client.send.register(
    nft_app_id=thot_client.app_id,
    asset=asset_id,
    mcp_endpoint="https://mcp.example/dvr1024",
    a2a_endpoint="https://a2a.example/dvr1024",
    directive=ZeroAddress,
    website="https://example.com",
    trust_models=3,                  # REPUTATION | CRYPTO_ECONOMIC
    skills="retrieval,embedding,rag",
    intelligence_level=0,
    autonomous=False,
    payment=algorand.create_transaction.payment(
        PaymentParams(
            sender=caller.address,
            receiver=registry_client.app_address,
            amount=1000,
        )
    ),
)
```

---

## Mint combinations from the register form

The form lists these recommended combinations. They all work as-is:

| Combination | How |
| --- | --- |
| `aNFT + MCP` | Mint via `ANFT.mint()` then register with `mcp_endpoint=...` |
| `dNFT + A2A` | Mint via `DNFT.mint()` then register with `a2a_endpoint=...` |
| `iNFT + MCP + A2A` | Mint via `INFT.mint()`, register with both endpoints |
| `THOT + iNFT` | Mint THOT first; mint iNFT next with `behavior_cid` referencing the THOT's `data_cid` |
| `Any + aORC` | Mint here, then verify via the [aORC minter](https://agenticplace.pythai.net/minter) at 1 ALGO |

---

## Audit notes

- **No clawback, no freeze role, no reserve** on any of the four NFT types.
  Every minted asset has those address fields hard-zeroed at creation.
- **Manager rotation safety.** Every dynamic asset config in `DNFT` /
  `INFT` re-supplies all four address roles explicitly so we never
  accidentally revoke the manager mid-life.
- **CID uniqueness** is keyed by `sha256(data_cid)` rather than the raw
  CID so the box key fits within Algorand's 64-byte limit even for unusual
  CID encodings.
- **`freeze` on iNFT** clears the directive address in the same call as
  the manager revocation, so a frozen iNFT can never self-mutate again.
- **Mint flow is two-step** (`mint` → opt-in → `claim`) because Algorand
  requires opt-in before holding an ASA. The contract records the pending
  owner so no third party can race the claim.
- **The application's account holds the supply between mint and claim**.
  After claim it holds zero of that ASA.
- **Registry never custodies assets.** Worst-case impact of a registry
  compromise is metadata corruption, never asset loss.

> ⚠️ Unaudited code. Run a third-party audit before mainnet deployment.

---

## Mapping to the AgenticPlace register form

| Form section | Where it lives in these contracts |
| --- | --- |
| **Step 1: Agent Details** (name, type, description, avatar, unit) | ARC-69 note + `IdentityRecord` box on each NFT |
| **Step 2: NFT Type** (aNFT/dNFT/iNFT/THOT) | One contract per type |
| **Step 3: Endpoints** (MCP, A2A, directive, website) | `AgenticPlaceRegistry` binding |
| **Step 4: Mint** (0.001 ALGO) | `mint_fee` global state on each contract |
| **Intelligence Config** (level, autonomous, behavior CID) | `INFT.records` box |
| **Tensor Config** (dimensions 64/384/512/768/1024 + data CID) | `THOT.tensors` box |
| **Trust & Capabilities** (Reputation, Crypto-Economic, TEE, zkML) | `trust_models` bitmap on registry |
| **Skills** (comma-separated) | `skills` string on registry |

Every field on the form maps to either an ARC-69 metadata field (frozen
into the note) or a box-storage field that the registry exposes for
8004scan and the AgenticPlace frontend to read.

---

## License

MIT OR Apache-2.0 — pick whichever fits your downstream project.
