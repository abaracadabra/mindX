# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# INFT — Intelligent Agent NFT (Algorand ASA)
#
# Mirrors the AgenticPlace `iNFT` type from agenticplace.pythai.net/register:
#
#   "iNFT — Intelligent. Retains manager. Agent's directive address can
#    update metadata autonomously. Set intelligence level and behavior CID."
#
# Two distinct privilege tracks:
#
#   1. Owner / human track
#        - mint, claim
#        - set_directive (rotate or revoke the autonomous key)
#        - update_identity (push a new ARC-69 note manually)
#        - freeze (permanent kill-switch; also clears the directive)
#
#   2. Directive / autonomous track
#        - self_update (the agent updates its own intelligence config and
#          ARC-69 note without owner intervention)
#
# The directive address is typically held by the agent's runtime. `freeze`
# severs the autonomy link in the same call, so a frozen iNFT can never
# self-mutate again — even if the directive key is later compromised.

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    DEFAULT_MINT_FEE_MICROALGOS,
    KIND_INFT,
    MAX_INTELLIGENCE_LEVEL,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
)


# ─────────────────────────────────────────────────────────────────────────
#  Box record
# ─────────────────────────────────────────────────────────────────────────
class InftRecord(arc4.Struct):
    """Combined identity + intelligence record for an iNFT."""

    # ARC-69 identity
    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address

    # Mint flow state
    pending_owner: arc4.Address
    claimed: arc4.Bool
    frozen: arc4.Bool

    # Intelligence config (matches AgenticPlace register form fields)
    directive: arc4.Address
    level: arc4.UInt8
    autonomous: arc4.Bool
    behavior_cid: arc4.String

    # Counters
    self_update_count: arc4.UInt64
    owner_update_count: arc4.UInt64


class INFT(ARC4Contract):
    """Intelligent agent NFT factory with directive-driven self-update."""

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)
        self.records = BoxMap(UInt64, InftRecord, key_prefix=b"in")

    # ─── lifecycle ─────────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(DEFAULT_MINT_FEE_MICROALGOS)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    # ─── mint (step 1: create the ASA) ────────────────────────────────────
    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        directive: arc4.Address,
        level: arc4.UInt8,
        autonomous: arc4.Bool,
        behavior_cid: arc4.String,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        # Validate payment
        assert payment.receiver == Global.current_application_address, "wrong receiver"
        assert payment.amount >= self.mint_fee.value, "fee too low"
        assert payment.sender == Txn.sender, "fee sender mismatch"

        # Validate identity + intelligence
        assert name.native.length > 0, "empty name"
        assert unit_name.native.length <= UInt64(MAX_UNIT_NAME), "unit_name too long"
        assert metadata_note.native.length <= UInt64(MAX_NOTE_LENGTH), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"
        assert level.native <= UInt64(MAX_INTELLIGENCE_LEVEL), "level > 100"

        # Manager = this application so it can issue reconfigs to update note
        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        new_asset_id = result.created_asset.id

        self.records[new_asset_id] = InftRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
            frozen=arc4.Bool(False),  # noqa: FBT003
            directive=directive,
            level=level,
            autonomous=autonomous,
            behavior_cid=behavior_cid,
            self_update_count=arc4.UInt64(0),
            owner_update_count=arc4.UInt64(0),
        )

        self.total_minted.value += UInt64(1)
        return arc4.UInt64(new_asset_id)

    # ─── mint (step 2: claim) ─────────────────────────────────────────────
    @arc4.abimethod
    def claim(self, asset: Asset) -> None:
        rec = self.records[asset.id].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native.bytes, "not pending owner"

        itxn.AssetTransfer(
            xfer_asset=asset.id,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.records[asset.id] = rec.copy()

    # ─── owner-side controls ──────────────────────────────────────────────
    @arc4.abimethod
    def update_identity(self, asset: Asset, new_note: arc4.String) -> None:
        """Owner manually pushes a new ARC-69 note for the iNFT."""
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "frozen"
        assert new_note.native.length <= UInt64(MAX_NOTE_LENGTH), "note too long"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists and balance == UInt64(1), "caller is not the holder"

        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            note=new_note.native,
            fee=0,
        ).submit()

        rec.owner_update_count = arc4.UInt64(rec.owner_update_count.native + UInt64(1))
        self.records[asset.id] = rec.copy()

    @arc4.abimethod
    def set_directive(self, asset: Asset, new_directive: arc4.Address) -> None:
        """Rotate or revoke the autonomous-update key."""
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "frozen"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists and balance == UInt64(1), "caller is not the holder"

        rec.directive = new_directive
        self.records[asset.id] = rec.copy()

    @arc4.abimethod
    def freeze(self, asset: Asset) -> None:
        """Permanently lock the iNFT and sever its directive in one call."""
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "already frozen"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists and balance == UInt64(1), "caller is not the holder"

        # Revoke manager role on chain.
        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        rec.frozen = arc4.Bool(True)  # noqa: FBT003
        rec.directive = arc4.Address(Global.zero_address)  # sever autonomy
        rec.autonomous = arc4.Bool(False)  # noqa: FBT003
        self.records[asset.id] = rec.copy()

    # ─── directive-side autonomous self-update ────────────────────────────
    @arc4.abimethod
    def self_update(
        self,
        asset: Asset,
        new_level: arc4.UInt8,
        new_autonomous: arc4.Bool,
        new_behavior_cid: arc4.String,
        new_note: arc4.String,
    ) -> None:
        """The agent's directive address updates its own intelligence config.

        Cannot run on a frozen iNFT. The new ARC-69 note is also pushed in
        the same call so off-chain indexers see the change immediately.
        """
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "frozen"
        assert Txn.sender == rec.directive.native.bytes, "not the directive"
        assert new_level.native <= UInt64(MAX_INTELLIGENCE_LEVEL), "level > 100"
        assert new_note.native.length <= UInt64(MAX_NOTE_LENGTH), "note too long"

        # Push the new ARC-69 note via inner asset config (we are the manager).
        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            note=new_note.native,
            fee=0,
        ).submit()

        rec.level = new_level
        rec.autonomous = new_autonomous
        rec.behavior_cid = new_behavior_cid
        rec.self_update_count = arc4.UInt64(rec.self_update_count.native + UInt64(1))
        self.records[asset.id] = rec.copy()

    # ─── views ────────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_record(self, asset_id: arc4.UInt64) -> InftRecord:
        return self.records[asset_id.native]

    @arc4.abimethod(readonly=True)
    def get_intelligence(self, asset_id: arc4.UInt64) -> arc4.Tuple[
        arc4.Address, arc4.UInt8, arc4.Bool, arc4.String
    ]:
        rec = self.records[asset_id.native]
        return arc4.Tuple(
            (rec.directive, rec.level, rec.autonomous, rec.behavior_cid)
        )

    @arc4.abimethod(readonly=True)
    def is_frozen(self, asset_id: arc4.UInt64) -> arc4.Bool:
        return arc4.Bool(self.records[asset_id.native].frozen.native)

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
