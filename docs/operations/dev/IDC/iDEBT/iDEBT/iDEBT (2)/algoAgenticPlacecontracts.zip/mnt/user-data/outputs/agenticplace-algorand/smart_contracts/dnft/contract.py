# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# DNFT — Dynamic Agent NFT (Algorand ASA)
#
# Mirrors the AgenticPlace `dNFT` type from agenticplace.pythai.net/register:
#
#   "dNFT — Dynamic. Retains manager address. Owner can update ARC-69
#    metadata via asset config transaction. Freeze to lock permanently."
#
# Implementation notes:
#   - The application's account is the on-chain manager of every dNFT it
#     mints. Reserve / freeze / clawback are set to the zero address so
#     those roles can never be exercised by anyone.
#   - The current token holder (the only account with balance == 1) is the
#     only address authorised to call `update_note`. The application then
#     issues an inner asset config transaction with the new note. Indexers
#     like 8004scan read the most recent config transaction's note as the
#     current ARC-69 metadata.
#   - `freeze` sets the manager to the zero address via an inner asset
#     config. After this the asset becomes permanently immutable, just
#     like an aNFT — no future call from any party can update its metadata.

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    DEFAULT_MINT_FEE_MICROALGOS,
    KIND_DNFT,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
)


class DnftIdentityRecord(arc4.Struct):
    """Identity record for a dNFT. `frozen` becomes True after `freeze()`."""

    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address
    pending_owner: arc4.Address
    claimed: arc4.Bool
    frozen: arc4.Bool
    update_count: arc4.UInt64


class DNFT(ARC4Contract):
    """Dynamic agent NFT factory and metadata gate."""

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)
        self.identities = BoxMap(UInt64, DnftIdentityRecord, key_prefix=b"id")

    # ─── lifecycle ─────────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(DEFAULT_MINT_FEE_MICROALGOS)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    # ─── mint (step 1) ────────────────────────────────────────────────────
    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        # Validate payment
        assert payment.receiver == Global.current_application_address, "wrong receiver"
        assert payment.amount >= self.mint_fee.value, "fee too low"
        assert payment.sender == Txn.sender, "fee sender mismatch"

        # Validate identity
        assert name.native.length > 0, "empty name"
        assert unit_name.native.length <= UInt64(MAX_UNIT_NAME), "unit_name too long"
        assert metadata_note.native.length <= UInt64(MAX_NOTE_LENGTH), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"

        # Inner asset config — manager is THIS application so it can issue
        # subsequent reconfigs to update the note. Reserve / freeze / clawback
        # are zeroed so no party can ever exercise those roles.
        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        new_asset_id = result.created_asset.id

        self.identities[new_asset_id] = DnftIdentityRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
            frozen=arc4.Bool(False),  # noqa: FBT003
            update_count=arc4.UInt64(0),
        )

        self.total_minted.value += UInt64(1)
        return arc4.UInt64(new_asset_id)

    # ─── mint (step 2) ────────────────────────────────────────────────────
    @arc4.abimethod
    def claim(self, asset: Asset) -> None:
        rec = self.identities[asset.id].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native.bytes, "not pending owner"

        itxn.AssetTransfer(
            xfer_asset=asset.id,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.identities[asset.id] = rec.copy()

    # ─── owner-side metadata update ───────────────────────────────────────
    @arc4.abimethod
    def update_note(self, asset: Asset, new_note: arc4.String) -> None:
        """Issue a new asset config tx with an updated ARC-69 note.

        The caller must currently hold the asset (balance == 1) and the
        asset must not be frozen. The application — as the asset's manager
        — submits an inner asset config keeping every existing role except
        for the note, which is replaced.
        """
        rec = self.identities[asset.id].copy()
        assert not rec.frozen.native, "frozen"
        assert new_note.native.length <= UInt64(MAX_NOTE_LENGTH), "note too long"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted in"
        assert balance == UInt64(1), "caller is not the holder"

        # Re-config the asset with the same manager + new note. Every address
        # role must be re-supplied; any field omitted (or set to zero) is
        # *permanently* revoked, so we keep manager = self and the others
        # at their original zero values.
        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            note=new_note.native,
            fee=0,
        ).submit()

        rec.update_count = arc4.UInt64(rec.update_count.native + UInt64(1))
        self.identities[asset.id] = rec.copy()

    # ─── permanent freeze (lock) ──────────────────────────────────────────
    @arc4.abimethod
    def freeze(self, asset: Asset) -> None:
        """Permanently lock the asset by clearing its manager address.

        After this call the asset is fully immutable — no future asset
        config can ever be issued, by anyone.
        """
        rec = self.identities[asset.id].copy()
        assert not rec.frozen.native, "already frozen"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists and balance == UInt64(1), "caller is not the holder"

        # Revoke the manager role permanently.
        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        rec.frozen = arc4.Bool(True)  # noqa: FBT003
        self.identities[asset.id] = rec.copy()

    # ─── views ────────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_identity(self, asset_id: arc4.UInt64) -> DnftIdentityRecord:
        return self.identities[asset_id.native]

    @arc4.abimethod(readonly=True)
    def is_frozen(self, asset_id: arc4.UInt64) -> arc4.Bool:
        return arc4.Bool(self.identities[asset_id.native].frozen.native)

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
