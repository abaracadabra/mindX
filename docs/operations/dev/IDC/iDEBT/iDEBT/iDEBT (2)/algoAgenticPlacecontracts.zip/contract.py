# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# ANFT — Standard Immutable Agent NFT (Algorand ASA)
#
# Mirrors the AgenticPlace `aNFT` type from agenticplace.pythai.net/register:
#
#   "aNFT — Standard immutable NFT. No manager address. Permanent on-chain
#    identity. Cannot be updated after mint."
#
# Implementation notes:
#   - Each mint creates a fresh ASA via an inner asset config transaction
#     with manager / reserve / freeze / clawback all set to the zero address.
#     This makes the asset permanently immutable and uncontrollable by any
#     party — exactly what the form promises.
#   - The ARC-69 metadata JSON is embedded in the asset config note field at
#     creation time. Because there is no manager, that note can never be
#     updated by any subsequent transaction.
#   - Two-step mint flow: callers mint, opt into the new asset, then call
#     `claim` to receive it. This is the only way on Algorand to send a newly
#     created ASA to an account that has not previously opted in.
#
# Reusable: this contract has zero coupling to the registry, mindX, or any
# other AgenticPlace component. Any project can deploy it standalone.

from algopy import (
    ARC4Contract,
    Account,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    DEFAULT_MINT_FEE_MICROALGOS,
    KIND_ANFT,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
)


# ─────────────────────────────────────────────────────────────────────────
#  Box record types
# ─────────────────────────────────────────────────────────────────────────
class IdentityRecord(arc4.Struct):
    """ARC-69 identity record stored alongside every minted ASA."""

    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address
    pending_owner: arc4.Address  # whoever is allowed to call claim(asset_id)
    claimed: arc4.Bool


# ─────────────────────────────────────────────────────────────────────────
#  Contract
# ─────────────────────────────────────────────────────────────────────────
class ANFT(ARC4Contract):
    """Immutable agent NFT factory and registry."""

    def __init__(self) -> None:
        # Global state
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)

        # Box storage: asset_id -> IdentityRecord
        self.identities = BoxMap(UInt64, IdentityRecord, key_prefix=b"id")

    # ─── lifecycle ─────────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(DEFAULT_MINT_FEE_MICROALGOS)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    # ─── mint (step 1: create the ASA) ────────────────────────────────────
    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        """Create a new immutable agent NFT.

        The caller must include a grouped payment to the application of at
        least `mint_fee` microAlgos (default 0.001 ALGO, matching the
        AgenticPlace register form).

        Returns the new ASA id. The caller must then opt into this asset
        and call `claim(asset_id)` to receive it.
        """
        # Validate payment
        assert payment.receiver == Global.current_application_address, "wrong receiver"
        assert payment.amount >= self.mint_fee.value, "fee too low"
        assert payment.sender == Txn.sender, "fee sender mismatch"

        # Validate identity
        assert name.native.length > 0, "empty name"
        assert unit_name.native.length <= UInt64(MAX_UNIT_NAME), "unit_name too long"
        assert metadata_note.native.length <= UInt64(MAX_NOTE_LENGTH), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"

        # Inner asset config — manager / reserve / freeze / clawback are
        # all the zero address, which makes the ASA permanently immutable.
        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        new_asset_id = result.created_asset.id

        # Persist the identity record indexed by ASA id
        self.identities[new_asset_id] = IdentityRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
        )

        self.total_minted.value += UInt64(1)
        return arc4.UInt64(new_asset_id)

    # ─── mint (step 2: send the ASA to the caller) ────────────────────────
    @arc4.abimethod
    def claim(self, asset_id: arc4.UInt64) -> None:
        """Transfer a freshly minted ANFT to its pending owner.

        The caller must have opted into the asset before calling this. Only
        the address listed as `pending_owner` in the identity record can
        successfully claim. After claim the contract retains zero balance
        of the ASA.
        """
        rec = self.identities[asset_id.native].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native.bytes, "not pending owner"

        # Inner transfer of the entire supply (= 1) to the caller
        itxn.AssetTransfer(
            xfer_asset=asset_id.native,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        # Mark claimed and clear the pending owner so claim cannot be replayed
        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.identities[asset_id.native] = rec.copy()

    # ─── views ────────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_identity(self, asset_id: arc4.UInt64) -> IdentityRecord:
        return self.identities[asset_id.native]

    @arc4.abimethod(readonly=True)
    def kind(self) -> arc4.StaticArray[arc4.Byte, arc4.UInt64]:
        # Returns "aNFT" as a 4-byte static array
        return arc4.StaticArray[arc4.Byte, arc4.UInt64].from_bytes(Bytes(KIND_ANFT))

    # ─── treasury ─────────────────────────────────────────────────────────
    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
