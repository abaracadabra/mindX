# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# AlgoKit deploy script for the AgenticPlace Algorand stack.
#
# Usage:
#
#   1. Compile each contract to TEAL:
#        algokit compile py smart_contracts/anft/contract.py
#        algokit compile py smart_contracts/dnft/contract.py
#        algokit compile py smart_contracts/inft/contract.py
#        algokit compile py smart_contracts/thot/contract.py
#        algokit compile py smart_contracts/registry/contract.py
#
#      Each command emits an `*.arc56.json` artifact plus an auto-generated
#      typed Python client under `smart_contracts/artifacts/<name>/`.
#
#   2. Set up your environment:
#        - LocalNet:   algokit localnet start
#        - TestNet:    export DEPLOYER_MNEMONIC="..." NETWORK=testnet
#        - MainNet:    export DEPLOYER_MNEMONIC="..." NETWORK=mainnet
#
#   3. Run:
#        python deploy/deploy.py
#
# This script intentionally uses the generic AlgorandClient API rather than
# depending on the auto-generated typed clients, so it works the moment the
# TEAL artifacts exist on disk regardless of how you compiled them.

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

from algokit_utils import (
    AlgorandClient,
    AppFactoryCreateMethodCallParams,
    Account,
    PaymentParams,
)
from algosdk import mnemonic


PROJECT_ROOT = Path(__file__).resolve().parent.parent
ARTIFACTS_DIR = PROJECT_ROOT / "smart_contracts" / "artifacts"

CONTRACTS = [
    ("anft", "ANFT"),
    ("dnft", "DNFT"),
    ("inft", "INFT"),
    ("thot", "THOT"),
    ("registry", "AgenticPlaceRegistry"),
]


def _load_arc56(name: str) -> dict[str, Any]:
    """Load the ARC-56 application spec emitted by `algokit compile py`."""
    artifact = ARTIFACTS_DIR / name / f"{name}.arc56.json"
    if not artifact.exists():
        raise FileNotFoundError(
            f"Missing compiled artifact: {artifact}\n"
            f"Run: algokit compile py smart_contracts/{name}/contract.py"
        )
    with artifact.open("r") as fh:
        return json.load(fh)


def _make_client() -> AlgorandClient:
    network = os.environ.get("NETWORK", "localnet").lower()
    if network == "localnet":
        return AlgorandClient.default_localnet()
    if network == "testnet":
        return AlgorandClient.testnet()
    if network == "mainnet":
        return AlgorandClient.mainnet()
    raise ValueError(f"Unknown NETWORK: {network!r}")


def _load_deployer(algorand: AlgorandClient) -> Account:
    mn = os.environ.get("DEPLOYER_MNEMONIC")
    if mn:
        sk = mnemonic.to_private_key(mn)
        from algosdk.account import address_from_private_key

        return Account(address=address_from_private_key(sk), private_key=sk)

    # Fall back to a freshly funded LocalNet account.
    deployer = algorand.account.localnet_dispenser()
    print(f"[localnet] using dispenser account: {deployer.address}")
    return deployer


def _fund_app(algorand: AlgorandClient, deployer: Account, app_address: str) -> None:
    """Top up the application account so it can hold the asset MBR for inner txns."""
    algorand.send.payment(
        PaymentParams(
            sender=deployer.address,
            receiver=app_address,
            amount=200_000,  # 0.2 ALGO — covers MBR for ~1 ASA + a couple of boxes
            note=b"agenticplace bootstrap",
        )
    )


def deploy_one(
    algorand: AlgorandClient,
    deployer: Account,
    contract_name: str,
    class_name: str,
) -> dict[str, Any]:
    print(f"[deploy] {class_name} ({contract_name}) ...")

    spec = _load_arc56(contract_name)
    factory = algorand.client.get_app_factory(
        app_spec=json.dumps(spec),
        default_sender=deployer.address,
    )

    create_result = factory.send.create(
        AppFactoryCreateMethodCallParams(
            method="create",
            args=[],
            sender=deployer.address,
        )
    )

    app_id = create_result.app_id
    app_address = create_result.app_address

    _fund_app(algorand, deployer, app_address)

    print(f"           -> app_id  = {app_id}")
    print(f"           -> app_addr = {app_address}")
    return {"name": class_name, "app_id": app_id, "app_address": app_address}


def main() -> int:
    algorand = _make_client()
    deployer = _load_deployer(algorand)

    print(f"[network ] {os.environ.get('NETWORK', 'localnet')}")
    print(f"[deployer] {deployer.address}")
    print()

    deployed: list[dict[str, Any]] = []
    for contract_name, class_name in CONTRACTS:
        deployed.append(deploy_one(algorand, deployer, contract_name, class_name))

    print()
    print("=" * 60)
    print("AgenticPlace Algorand stack deployed:")
    print("=" * 60)
    for d in deployed:
        print(f"  {d['name']:<22} app_id={d['app_id']:<10} addr={d['app_address']}")

    out = PROJECT_ROOT / "deploy" / "deployment.json"
    with out.open("w") as fh:
        json.dump({"network": os.environ.get("NETWORK", "localnet"), "apps": deployed}, fh, indent=2)
    print(f"\nWrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
