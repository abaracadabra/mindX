// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./ARC69Base.sol";
import "../interfaces/IIntelligentNFT.sol";

/**
 * @title INFT — Intelligent Agent NFT
 * @author Professor Codephreak
 * @notice EVM analog of the AgenticPlace Algorand `iNFT` type:
 *           "Intelligent. Retains manager. Agent's directive address can
 *            update metadata autonomously. Set intelligence level and
 *            behavior CID."
 *
 *         Two distinct privileges:
 *           - The token owner (or appointed manager) can rotate the directive
 *             address, freeze the token, or update identity.
 *           - The directive address — typically the agent itself, or a key
 *             held by an autonomous runtime — can self-update its intelligence
 *             config (level, autonomy flag, behavior CID) without owner
 *             intervention.
 *
 *         This split is the core feature: it lets an agent evolve while
 *         keeping the human owner in ultimate control via the kill-switch
 *         (rotate directive to address(0) or freeze).
 *
 *         Reusable: zero AgenticPlace coupling. Any project can mint iNFTs.
 */
contract INFT is ARC69Base, IIntelligentNFT {
    bytes4 public constant KIND = 0x694e4654; // "iNFT"

    mapping(uint256 => Intelligence) internal _intel;
    mapping(uint256 => address)      public  manager;

    event ManagerUpdated(uint256 indexed tokenId, address indexed previous, address indexed next);

    error NotManager();
    error NotDirective();
    error InvalidLevel();

    constructor(address admin) ARC69Base("DeltaVerse iNFT", "INFT", admin) {}

    modifier onlyManager(uint256 tokenId) {
        address m         = manager[tokenId];
        address ownerAddr = _ownerOf(tokenId);
        bool    isOwner   = msg.sender == ownerAddr;
        bool    isManager = m != address(0) && msg.sender == m;
        if (!isOwner && !isManager) revert NotManager();
        _;
    }

    modifier onlyDirective(uint256 tokenId) {
        if (_intel[tokenId].directive != msg.sender) revert NotDirective();
        _;
    }

    /**
     * @notice Mint a new intelligent agent NFT.
     * @param  to            Recipient (initial owner & manager).
     * @param  identity      ARC-69 identity record.
     * @param  intel         Initial intelligence config.
     * @param  metadataURI   ipfs:// JSON pointer.
     */
    function mint(
        address to,
        Identity calldata identity,
        Intelligence calldata intel,
        string calldata metadataURI
    ) external nonReentrant onlyRole(MINTER_ROLE) returns (uint256 tokenId) {
        if (to == address(0)) revert ZeroAddress();
        _validateIdentity(identity);
        if (intel.level > 100) revert InvalidLevel();

        tokenId = _nextTokenId++;

        _writeIdentity(tokenId, identity);
        _intel[tokenId] = intel;

        _safeMint(to, tokenId);
        _setTokenURI(tokenId, metadataURI);

        emit IdentityMinted(tokenId, to, identity.agentType);
        emit IntelligenceUpdated(tokenId, intel.level, intel.autonomous, intel.behaviorCID);
        if (intel.directive != address(0)) {
            emit DirectiveUpdated(tokenId, address(0), intel.directive);
        }
    }

    // ─── manager-side controls ───────────────────────────────────────────

    function updateIdentity(uint256 tokenId, Identity calldata identity)
        external
        nonReentrant
        onlyManager(tokenId)
    {
        _requireUnfrozen(tokenId);
        _validateIdentity(identity);
        _writeIdentity(tokenId, identity);
        emit IdentityUpdated(tokenId);
    }

    function setDirective(uint256 tokenId, address directive)
        external
        nonReentrant
        onlyManager(tokenId)
    {
        _requireUnfrozen(tokenId);
        address prev = _intel[tokenId].directive;
        _intel[tokenId].directive = directive;
        emit DirectiveUpdated(tokenId, prev, directive);
    }

    function setManager(uint256 tokenId, address newManager) external {
        if (_ownerOf(tokenId) != msg.sender) revert NotTokenOwner();
        address prev = manager[tokenId];
        manager[tokenId] = newManager;
        emit ManagerUpdated(tokenId, prev, newManager);
    }

    function freeze(uint256 tokenId) external onlyManager(tokenId) {
        _requireUnfrozen(tokenId);
        _frozen[tokenId] = true;
        // Sever the autonomy link: a frozen iNFT cannot self-update.
        _intel[tokenId].directive = address(0);
        emit IdentityFrozenEvent(tokenId);
    }

    // ─── directive-side autonomous self-update ──────────────────────────

    /**
     * @notice The agent's directive address updates its own intelligence
     *         config without owner intervention. Cannot run on a frozen token.
     */
    function selfUpdate(
        uint256 tokenId,
        uint8 level,
        bool autonomous,
        string calldata behaviorCID
    ) external nonReentrant onlyDirective(tokenId) {
        _requireUnfrozen(tokenId);
        if (level > 100) revert InvalidLevel();

        Intelligence storage i = _intel[tokenId];
        i.level       = level;
        i.autonomous  = autonomous;
        i.behaviorCID = behaviorCID;

        emit IntelligenceUpdated(tokenId, level, autonomous, behaviorCID);
    }

    function intelligenceOf(uint256 tokenId) external view returns (Intelligence memory) {
        _requireOwned(tokenId);
        return _intel[tokenId];
    }

    function nftKind() external pure override returns (bytes4) {
        return KIND;
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override
        returns (bool)
    {
        return
            interfaceId == type(IIntelligentNFT).interfaceId ||
            super.supportsInterface(interfaceId);
    }
}
