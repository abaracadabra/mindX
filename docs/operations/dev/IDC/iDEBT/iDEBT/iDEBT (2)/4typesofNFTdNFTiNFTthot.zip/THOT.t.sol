// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./TestFixtures.sol";
import "../src/nft/THOT.sol";

contract THOTTest is TestFixtures {
    THOT internal thot;

    function setUp() public {
        vm.prank(admin);
        thot = new THOT(admin);
    }

    function test_AllSupportedDimensions() public {
        uint16[5] memory dims = [uint16(64), 384, 512, 768, 1024];
        for (uint256 i; i < dims.length; ++i) {
            assertTrue(thot.isSupportedDimension(dims[i]));

            string memory cid = string.concat("Qm", vm.toString(dims[i]));
            vm.prank(admin);
            uint256 id = thot.mint(
                alice,
                _identity("tensor"),
                _tensor(cid, dims[i]),
                "ipfs://meta"
            );
            assertEq(thot.tensorOf(id).dimensions, dims[i]);
        }
    }

    function test_1024DimMintWorks() public {
        vm.prank(admin);
        uint256 id = thot.mint(
            alice,
            _identity("hi-fidelity"),
            _tensor("QmBigEmbed", 1024),
            "ipfs://meta"
        );
        IKnowledgeTensor.Tensor memory t = thot.tensorOf(id);
        assertEq(t.dimensions, 1024);
        assertEq(t.dataCID, "QmBigEmbed");
        assertTrue(thot.isFrozen(id));
    }

    function test_RevertWhen_UnsupportedDimension() public {
        vm.prank(admin);
        vm.expectRevert(abi.encodeWithSelector(THOT.UnsupportedDimensions.selector, uint16(256)));
        thot.mint(alice, _identity("x"), _tensor("Qm256", 256), "ipfs://x");
    }

    function test_RevertWhen_DuplicateCID() public {
        vm.startPrank(admin);
        thot.mint(alice, _identity("a"), _tensor("QmDup", 768), "ipfs://a");
        vm.expectRevert(THOT.CIDAlreadyMinted.selector);
        thot.mint(bob, _identity("b"), _tensor("QmDup", 768), "ipfs://b");
        vm.stopPrank();
    }

    function test_TokenIdOfCIDLookup() public {
        vm.prank(admin);
        uint256 id = thot.mint(alice, _identity("a"), _tensor("QmLookup", 1024), "ipfs://a");
        assertEq(thot.tokenIdOfCID("QmLookup"), id);
    }

    function test_RevertWhen_EmptyCID() public {
        vm.prank(admin);
        vm.expectRevert(THOT.EmptyCID.selector);
        thot.mint(alice, _identity("x"), _tensor("", 768), "ipfs://x");
    }
}
