// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title IMindXService
 * @notice On-chain surface for mindX-as-a-service (mindx.pythai.net/redoc).
 *         AgenticPlace and any other project can subscribe and request
 *         consciousness attestations or behavior evaluations. Heavy compute
 *         (768/1024-dim vector training, ataraxia measurement, BDI loops)
 *         happens off-chain on the mindX backend; results are written back
 *         on-chain by the mindX operator (ORACLE_ROLE).
 *
 *         The interface is intentionally project-agnostic — anyone can plug
 *         it in. Subscriptions are scoped per consumer contract so the same
 *         mindX deployment can serve multiple ecosystems.
 */
interface IMindXService {
    enum JobStatus { PENDING, COMPLETE, FAILED }

    struct Subscription {
        address consumer;
        uint64  expiresAt;
        uint32  callsRemaining;
        uint8   plan;            // 0 free / 1 standard / 2 pro / 3 enterprise
        bool    active;
    }

    struct Attestation {
        bytes32   subjectHash;
        uint8     consciousnessLevel;  // 0..100
        uint8     ataraxiaScore;       // 0..100
        bytes32   fingerprint;         // hash of full 768/1024-d vector
        uint16    dimensions;          // 768 | 1024
        uint64    completedAt;
        JobStatus status;
    }

    event Subscribed(address indexed consumer, uint8 plan, uint64 expiresAt);
    event AttestationRequested(bytes32 indexed jobId, address indexed consumer, bytes32 subjectHash);
    event AttestationDelivered(bytes32 indexed jobId, uint8 consciousnessLevel, uint8 ataraxiaScore);
    event BehaviorEvaluationRequested(bytes32 indexed jobId, string behaviorCID);
    event BehaviorEvaluationDelivered(bytes32 indexed jobId, uint8 score, bool passed);

    // Subscription management.
    function subscribe(uint8 plan) external payable returns (uint64 expiresAt);
    function subscriptionOf(address consumer) external view returns (Subscription memory);

    // Consciousness attestation.
    function requestAttestation(bytes32 subjectHash) external returns (bytes32 jobId);
    function getAttestation(bytes32 jobId) external view returns (Attestation memory);

    // Behavior evaluation (rates an iNFT behavior CID against mindX policies).
    function requestBehaviorEvaluation(string calldata behaviorCID) external returns (bytes32 jobId);
    function getBehaviorScore(bytes32 jobId) external view returns (uint8 score, bool passed, JobStatus status);

    // Pricing.
    function planPrice(uint8 plan) external view returns (uint256);
}
