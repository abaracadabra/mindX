// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./ARC69Base.sol";
import "../interfaces/IKnowledgeTensor.sol";

/**
 * @title THOT — Transferable Hyper-Optimized Tensor
 * @author Professor Codephreak
 * @notice EVM analog of the AgenticPlace Algorand `THOT` type:
 *           "Knowledge tensor. Immutable (no manager). Requires IPFS data CID.
 *            Dimensions: 64/384/512/768. One CID per THOT."
 *
 *         This implementation extends the schema with **1024-dim** support
 *         for high-fidelity embedding models (text-embedding-3-large,
 *         mxbai-embed-large, BGE-large) and the mindX 1024-d expansion path.
 *
 *         Supported dimensions: { 64, 384, 512, 768, 1024 }
 *
 *         THOTs are completely independent from aNFT / dNFT / iNFT — they
 *         live in their own contract and their own ID space. They interoperate
 *         via the AgenticPlace registry, not via direct coupling.
 *
 *         Reusable: any project can mint THOTs by granting MINTER_ROLE.
 */
contract THOT is ARC69Base, IKnowledgeTensor {
    bytes4 public constant KIND = 0x54484f54; // "THOT"

    mapping(uint256 => Tensor)  internal _tensor;
    mapping(bytes32 => uint256) internal _cidToTokenId; // keccak256(dataCID) → id

    error UnsupportedDimensions(uint16 d);
    error EmptyCID();
    error CIDAlreadyMinted();
    error UnknownCID();

    constructor(address admin) ARC69Base("DeltaVerse THOT", "THOT", admin) {}

    /**
     * @notice Mint a new knowledge tensor NFT. Identity is frozen at mint
     *         (no manager) and the data CID is enforced globally unique.
     */
    function mint(
        address to,
        Identity calldata identity,
        Tensor calldata tensor,
        string calldata metadataURI
    ) external nonReentrant onlyRole(MINTER_ROLE) returns (uint256 tokenId) {
        if (to == address(0)) revert ZeroAddress();
        _validateIdentity(identity);

        if (bytes(tensor.dataCID).length == 0) revert EmptyCID();
        if (!isSupportedDimension(tensor.dimensions)) {
            revert UnsupportedDimensions(tensor.dimensions);
        }

        bytes32 cidKey = keccak256(bytes(tensor.dataCID));
        if (_cidToTokenId[cidKey] != 0) revert CIDAlreadyMinted();

        tokenId = _nextTokenId++;

        _writeIdentity(tokenId, identity);
        _frozen[tokenId] = true; // THOTs are immutable like aNFTs

        Tensor memory stored = tensor;
        stored.mintedAt = uint64(block.timestamp);
        _tensor[tokenId] = stored;
        _cidToTokenId[cidKey] = tokenId;

        _safeMint(to, tokenId);
        _setTokenURI(tokenId, metadataURI);

        emit IdentityMinted(tokenId, to, identity.agentType);
        emit IdentityFrozenEvent(tokenId);
        emit TensorMinted(tokenId, to, tensor.dataCID, tensor.dimensions);
    }

    /// @notice The five accepted embedding dimensions.
    function isSupportedDimension(uint16 d) public pure returns (bool) {
        return d == 64 || d == 384 || d == 512 || d == 768 || d == 1024;
    }

    function tensorOf(uint256 tokenId) external view returns (Tensor memory) {
        _requireOwned(tokenId);
        return _tensor[tokenId];
    }

    function tokenIdOfCID(string calldata dataCID) external view returns (uint256) {
        uint256 id = _cidToTokenId[keccak256(bytes(dataCID))];
        if (id == 0) revert UnknownCID();
        return id;
    }

    function nftKind() external pure override returns (bytes4) {
        return KIND;
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override
        returns (bool)
    {
        return
            interfaceId == type(IKnowledgeTensor).interfaceId ||
            super.supportsInterface(interfaceId);
    }
}
