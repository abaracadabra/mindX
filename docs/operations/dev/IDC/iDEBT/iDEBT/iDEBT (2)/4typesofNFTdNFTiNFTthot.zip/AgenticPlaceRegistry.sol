// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/introspection/ERC165Checker.sol";

import "../interfaces/IAgenticPlaceRegistry.sol";
import "../interfaces/IARC69Metadata.sol";
import "../interfaces/IIntelligentNFT.sol";
import "../interfaces/IKnowledgeTensor.sol";
import "../interfaces/IMindXService.sol";

/**
 * @title AgenticPlaceRegistry
 * @author Professor Codephreak
 * @notice On-chain directory that binds an agent NFT (aNFT, dNFT, iNFT, or
 *         THOT — or any third-party ERC-721 implementing IARC69Metadata) to
 *         its protocol endpoints, trust model, intelligence config, and skill
 *         set. Mirrors the AgenticPlace register flow at
 *         agenticplace.pythai.net/register.
 *
 *         Design notes:
 *           - The registry never owns or transfers NFTs. It only stores
 *             metadata bindings keyed by (nftContract, tokenId).
 *           - Any project's ERC-721 can be registered as long as it implements
 *             IARC69Metadata. The four NFTs in this repo are not privileged.
 *           - For iNFTs, intelligence level + autonomy are pulled live from
 *             the source contract via IIntelligentNFT — they are NOT
 *             duplicated into the registry, so they can never go stale.
 *           - mindX is wired in optionally as a service: when present, the
 *             registry can request a behavior evaluation from mindX before
 *             flipping a binding `active`.
 */
contract AgenticPlaceRegistry is
    IAgenticPlaceRegistry,
    AccessControl,
    ReentrancyGuard
{
    using ERC165Checker for address;

    bytes32 public constant ADMIN_ROLE     = keccak256("ADMIN_ROLE");
    bytes32 public constant TREASURY_ROLE  = keccak256("TREASURY_ROLE");

    /// @notice Native-token mint fee. Default 0; admin can raise.
    uint256 public mintFee;

    /// @notice Optional mindX backend (mindx.pythai.net) for behavior gating.
    IMindXService public mindX;

    /// @notice If true, every registration must pass a mindX behavior check.
    bool public mindXGated;

    mapping(bytes32 => AgentBinding) internal _bindings;
    mapping(bytes32 => bool)         internal _exists;

    error NotARC69Compatible();
    error NotTokenOwner();
    error AlreadyRegistered();
    error UnknownBinding();
    error InsufficientFee();
    error MindXNotConfigured();
    error MindXEvaluationFailed();
    error TransferFailed();
    error InvalidTrustBitmap();

    constructor(address admin, address mindXAddress) {
        if (admin == address(0)) revert();
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(ADMIN_ROLE, admin);
        _grantRole(TREASURY_ROLE, admin);
        mindX = IMindXService(mindXAddress);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Public registration
    // ─────────────────────────────────────────────────────────────────────

    function register(
        address  nftContract,
        uint256  tokenId,
        string   calldata mcpEndpoint,
        string   calldata a2aEndpoint,
        address  directiveAddress,
        string   calldata website,
        uint8    trustModels,
        string[] calldata skills
    ) external payable nonReentrant returns (bytes32 bindingId) {
        if (msg.value < mintFee) revert InsufficientFee();
        if (!nftContract.supportsInterface(type(IARC69Metadata).interfaceId)) {
            revert NotARC69Compatible();
        }
        if (IERC721(nftContract).ownerOf(tokenId) != msg.sender) {
            revert NotTokenOwner();
        }
        if (trustModels > 0x0F) revert InvalidTrustBitmap();

        bindingId = bindingIdFor(nftContract, tokenId);
        if (_exists[bindingId]) revert AlreadyRegistered();

        // Pull live intelligence config if the NFT is an iNFT.
        (uint8 intelLevel, bool autonomous) = _readIntelligence(nftContract, tokenId);

        // Optional mindX behavior gating.
        if (mindXGated) {
            if (address(mindX) == address(0)) revert MindXNotConfigured();
            // We only block if the mindX consumer's subscription has callsRemaining;
            // otherwise we let the registration proceed without a fresh score.
            IMindXService.Subscription memory sub = mindX.subscriptionOf(address(this));
            if (sub.active && sub.callsRemaining > 0) {
                bytes32 jobId = mindX.requestBehaviorEvaluation(
                    _readBehaviorCID(nftContract, tokenId)
                );
                (, bool passed, IMindXService.JobStatus status) = mindX.getBehaviorScore(jobId);
                if (status == IMindXService.JobStatus.COMPLETE && !passed) {
                    revert MindXEvaluationFailed();
                }
            }
        }

        AgentBinding storage b = _bindings[bindingId];
        b.nftContract       = nftContract;
        b.tokenId           = tokenId;
        b.owner             = msg.sender;
        b.mcpEndpoint       = mcpEndpoint;
        b.a2aEndpoint       = a2aEndpoint;
        b.directiveAddress  = directiveAddress;
        b.website           = website;
        b.trustModels       = trustModels;
        b.skills            = skills;
        b.autonomous        = autonomous;
        b.intelligenceLevel = intelLevel;
        b.registeredAt      = uint64(block.timestamp);
        b.updatedAt         = uint64(block.timestamp);
        b.active            = true;
        _exists[bindingId]  = true;

        emit AgentRegistered(bindingId, nftContract, tokenId, msg.sender);
    }

    function update(
        bytes32  bindingId,
        string   calldata mcpEndpoint,
        string   calldata a2aEndpoint,
        address  directiveAddress,
        string   calldata website,
        uint8    trustModels,
        string[] calldata skills
    ) external nonReentrant {
        if (!_exists[bindingId]) revert UnknownBinding();
        AgentBinding storage b = _bindings[bindingId];
        if (IERC721(b.nftContract).ownerOf(b.tokenId) != msg.sender) {
            revert NotTokenOwner();
        }
        if (trustModels > 0x0F) revert InvalidTrustBitmap();

        b.owner            = msg.sender;
        b.mcpEndpoint      = mcpEndpoint;
        b.a2aEndpoint      = a2aEndpoint;
        b.directiveAddress = directiveAddress;
        b.website          = website;
        b.trustModels      = trustModels;
        b.skills           = skills;

        // Refresh live intelligence in case it changed via INFT.selfUpdate.
        (b.intelligenceLevel, b.autonomous) = _readIntelligence(b.nftContract, b.tokenId);

        b.updatedAt = uint64(block.timestamp);
        emit AgentUpdated(bindingId);
    }

    function deactivate(bytes32 bindingId) external nonReentrant {
        if (!_exists[bindingId]) revert UnknownBinding();
        AgentBinding storage b = _bindings[bindingId];
        if (IERC721(b.nftContract).ownerOf(b.tokenId) != msg.sender) {
            revert NotTokenOwner();
        }
        b.active = false;
        b.updatedAt = uint64(block.timestamp);
        emit AgentDeactivated(bindingId);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Views
    // ─────────────────────────────────────────────────────────────────────

    function bindingOf(bytes32 bindingId) external view returns (AgentBinding memory) {
        if (!_exists[bindingId]) revert UnknownBinding();
        return _bindings[bindingId];
    }

    function bindingIdFor(address nftContract, uint256 tokenId) public pure returns (bytes32) {
        return keccak256(abi.encode(nftContract, tokenId));
    }

    function isRegistered(address nftContract, uint256 tokenId) external view returns (bool) {
        return _exists[bindingIdFor(nftContract, tokenId)];
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Admin
    // ─────────────────────────────────────────────────────────────────────

    function setMintFee(uint256 newFee) external onlyRole(ADMIN_ROLE) {
        mintFee = newFee;
    }

    function setMindX(address mindXAddress) external onlyRole(ADMIN_ROLE) {
        mindX = IMindXService(mindXAddress);
    }

    function setMindXGated(bool gated) external onlyRole(ADMIN_ROLE) {
        mindXGated = gated;
    }

    function withdraw(address payable to, uint256 amount) external onlyRole(TREASURY_ROLE) {
        (bool ok, ) = to.call{value: amount}("");
        if (!ok) revert TransferFailed();
    }

    /// @notice Subscribe this registry to mindX as a service consumer.
    function subscribeToMindX(uint8 plan) external payable onlyRole(ADMIN_ROLE) {
        if (address(mindX) == address(0)) revert MindXNotConfigured();
        mindX.subscribe{value: msg.value}(plan);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Internals
    // ─────────────────────────────────────────────────────────────────────

    function _readIntelligence(address nftContract, uint256 tokenId)
        internal
        view
        returns (uint8 level, bool autonomous)
    {
        if (nftContract.supportsInterface(type(IIntelligentNFT).interfaceId)) {
            IIntelligentNFT.Intelligence memory i =
                IIntelligentNFT(nftContract).intelligenceOf(tokenId);
            return (i.level, i.autonomous);
        }
        return (0, false);
    }

    function _readBehaviorCID(address nftContract, uint256 tokenId)
        internal
        view
        returns (string memory)
    {
        if (nftContract.supportsInterface(type(IIntelligentNFT).interfaceId)) {
            return IIntelligentNFT(nftContract).intelligenceOf(tokenId).behaviorCID;
        }
        return "";
    }

    receive() external payable {}
}
