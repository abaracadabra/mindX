// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./ARC69Base.sol";

/**
 * @title DNFT — Dynamic Agent NFT
 * @author Professor Codephreak
 * @notice EVM analog of the AgenticPlace Algorand `dNFT` type:
 *           "Dynamic. Retains manager address. Owner can update ARC-69
 *            metadata via asset config transaction. Freeze to lock permanently."
 *
 *         The manager (default = current token owner) can update identity
 *         fields and metadata URI. Calling `freeze` permanently locks the
 *         token, after which it behaves identically to an aNFT.
 *
 *         Reusable: any project can plug in by granting MINTER_ROLE.
 */
contract DNFT is ARC69Base {
    bytes4 public constant KIND = 0x644e4654; // "dNFT"

    /// @dev Optional alternate manager (e.g. a multisig). If unset (== 0),
    ///      the current token owner is the manager.
    mapping(uint256 => address) public manager;

    event ManagerUpdated(uint256 indexed tokenId, address indexed previous, address indexed next);

    error NotManager();

    constructor(address admin) ARC69Base("DeltaVerse dNFT", "DNFT", admin) {}

    modifier onlyManager(uint256 tokenId) {
        address m         = manager[tokenId];
        address ownerAddr = _ownerOf(tokenId);
        bool    isOwner   = msg.sender == ownerAddr;
        bool    isManager = m != address(0) && msg.sender == m;
        if (!isOwner && !isManager) revert NotManager();
        _;
    }

    /**
     * @notice Mint a new dynamic identity NFT. Identity can be updated later.
     */
    function mint(
        address to,
        Identity calldata identity,
        string calldata metadataURI
    ) external nonReentrant onlyRole(MINTER_ROLE) returns (uint256 tokenId) {
        if (to == address(0)) revert ZeroAddress();
        _validateIdentity(identity);

        tokenId = _nextTokenId++;

        _writeIdentity(tokenId, identity);

        _safeMint(to, tokenId);
        _setTokenURI(tokenId, metadataURI);

        emit IdentityMinted(tokenId, to, identity.agentType);
    }

    /**
     * @notice Update the identity record. Manager-only and only while unfrozen.
     */
    function updateIdentity(uint256 tokenId, Identity calldata identity)
        external
        nonReentrant
        onlyManager(tokenId)
    {
        _requireUnfrozen(tokenId);
        _validateIdentity(identity);
        _writeIdentity(tokenId, identity);
        emit IdentityUpdated(tokenId);
    }

    function updateMetadataURI(uint256 tokenId, string calldata metadataURI)
        external
        nonReentrant
        onlyManager(tokenId)
    {
        _requireUnfrozen(tokenId);
        _setTokenURI(tokenId, metadataURI);
        emit IdentityUpdated(tokenId);
    }

    function setManager(uint256 tokenId, address newManager) external {
        if (_ownerOf(tokenId) != msg.sender) revert NotTokenOwner();
        address prev = manager[tokenId];
        manager[tokenId] = newManager;
        emit ManagerUpdated(tokenId, prev, newManager);
    }

    /**
     * @notice Permanently freeze identity. After this call, the token behaves
     *         like an aNFT — no field can ever change again.
     */
    function freeze(uint256 tokenId) external onlyManager(tokenId) {
        _requireUnfrozen(tokenId);
        _frozen[tokenId] = true;
        emit IdentityFrozenEvent(tokenId);
    }

    function nftKind() external pure override returns (bytes4) {
        return KIND;
    }
}
