// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title IARC69Metadata
 * @notice EVM mirror of Algorand ARC-69 asset metadata. Implemented by every
 *         agent NFT in this project (aNFT, dNFT, iNFT, THOT) so any external
 *         consumer — including AgenticPlace, indexers, marketplaces, or other
 *         projects — can read identity metadata through one stable interface.
 *
 *         Note: this interface intentionally describes ONLY identity. Protocol
 *         endpoints (MCP, A2A, directive, trust models, skills) live on
 *         IAgenticPlaceRegistry so that the NFTs themselves remain reusable
 *         outside the AgenticPlace ecosystem.
 */
interface IARC69Metadata {
    enum AgentType {
        NONE,
        COGNITIVE_AUGMENTATION,
        CREATIVE_INTELLIGENCE,
        ANALYTICAL_PROCESSING,
        SPECIALIZED_DOMAIN,
        AGENT_ORCHESTRATOR
    }

    /// @dev On-chain identity record. `properties` is a bytes32 hash pointing
    ///      at an off-chain JSON blob with arbitrary extra fields.
    struct Identity {
        string    name;          // "Agent Name *"
        string    unitName;      // max 8 chars per ARC-69
        string    description;
        string    avatarURL;     // image / IPFS gateway URL
        string    externalURL;   // website
        AgentType agentType;
        bytes32   propertiesHash;
        uint64    mintedAt;
    }

    /// @notice Identity record for `tokenId`.
    function identityOf(uint256 tokenId) external view returns (Identity memory);

    /// @notice Whether identity for `tokenId` is permanently frozen.
    function isFrozen(uint256 tokenId) external view returns (bool);

    /// @notice ARC-69-style discriminator: "aNFT" | "dNFT" | "iNFT" | "THOT".
    function nftKind() external view returns (bytes4);
}
