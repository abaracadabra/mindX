// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title IKnowledgeTensor
 * @notice Surface for THOT knowledge tensors. Each THOT pins a single,
 *         globally unique data CID with a declared embedding dimension.
 *         Supported dimensions: 64, 384, 512, 768, 1024.
 *
 *         The 384 / 512 / 768 dimensions match the AgenticPlace register
 *         schema; 64 is the lightweight option; 1024 is added for high-fidelity
 *         embedding models (e.g. text-embedding-3-large, mxbai-embed-large,
 *         BGE-large) and for compatibility with the mindX 768→1024 expansion
 *         path.
 */
interface IKnowledgeTensor {
    struct Tensor {
        string  dataCID;        // IPFS CID of the tensor blob (unique)
        bytes32 tensorHash;     // keccak256 of the raw tensor bytes
        uint16  dimensions;     // 64 | 384 | 512 | 768 | 1024
        uint64  mintedAt;
    }

    event TensorMinted(
        uint256 indexed tokenId,
        address indexed minter,
        string  dataCID,
        uint16  dimensions
    );

    function tensorOf(uint256 tokenId) external view returns (Tensor memory);
    function tokenIdOfCID(string calldata dataCID) external view returns (uint256);
    function isSupportedDimension(uint16 d) external pure returns (bool);
}
