// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

interface IX402 {
    struct Receipt {
        address payer;
        bytes32 algoSender;
        bytes32 algoAsset;
        uint256 amount;
        uint64  algoRound;
        bytes32 algoTxId;
        uint64  expiresAt;
        bytes32 purpose;
    }
    function verifyReceipt(Receipt calldata r, bytes calldata sig, address expectedPayer) external view returns (bool);
    function operator() external view returns (address);
}
