// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title IIntelligentNFT
 * @notice Surface for intelligent NFTs (iNFT). Adds an autonomy layer on top
 *         of the base identity: a directive address that can self-update
 *         metadata, an intelligence level, an autonomy flag, and a behavior
 *         CID pointing at the agent's executable directives on IPFS.
 *
 *         iNFTs are valid agent identities for any project — they do not
 *         depend on AgenticPlace.
 */
interface IIntelligentNFT {
    struct Intelligence {
        address directive;        // address allowed to autonomously update
        uint8   level;            // 0..100
        bool    autonomous;
        string  behaviorCID;      // IPFS CID of the directive program
    }

    event DirectiveUpdated(uint256 indexed tokenId, address indexed previous, address indexed next);
    event IntelligenceUpdated(uint256 indexed tokenId, uint8 level, bool autonomous, string behaviorCID);

    function intelligenceOf(uint256 tokenId) external view returns (Intelligence memory);
    function setDirective(uint256 tokenId, address directive) external;
    function selfUpdate(
        uint256 tokenId,
        uint8 level,
        bool autonomous,
        string calldata behaviorCID
    ) external;
}
