// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

interface IPAIMINT {
    function balanceOf(address user) external view returns (uint256);
    function rewardPAIMINT(address user, uint256 amount, string calldata reason) external;
    function burnForOperation(address user, uint256 amount, string calldata operation) external;
}
