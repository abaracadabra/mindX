# DeltaVerse Agent Stack — aNFT • dNFT • iNFT • THOT

Four independent ERC-721 contracts plus a directory contract that mirrors the
[AgenticPlace](https://agenticplace.pythai.net/register) register flow on EVM,
with optional plug-ins for BANKON PAIMINT and parsec / Algorand x402 payments.

```
© 2022 BANKON • Professor Codephreak (Gregory L)
agenticplace.pythai.net • mindx.pythai.net • bankon.pythai.net
```

---

## TL;DR

| Contract | Algorand analog | Mutable? | Special powers |
| --- | --- | --- | --- |
| `ANFT` | `aNFT` | No, frozen at mint | Static identity, transferable |
| `DNFT` | `dNFT` | Yes, by manager | `freeze()` permanently locks |
| `INFT` | `iNFT` | Yes, by directive address | Self-updating intelligence + behavior CID |
| `THOT` | `THOT` | No, frozen at mint | Knowledge tensor, CID-unique, dims **64 / 384 / 512 / 768 / 1024** |

The four NFTs share an abstract base (`ARC69Base`) for ERC-721 mechanics and
the on-chain `Identity` record, but they do not import each other and do not
share storage. They interoperate exclusively through `AgenticPlaceRegistry`.

---

## Why four contracts instead of one

The AgenticPlace register form treats these as four genuinely different asset
types with different mutability rules and different downstream consumers. A
single contract with mode flags would force every consumer to branch on
runtime state. Four separate contracts let:

- Indexers route by contract address instead of inspecting fields.
- Marketplaces price by class without reading per-token mutability flags.
- Third-party projects mint just one type without dragging in the others.
- Frozen types (`ANFT`, `THOT`) skip an entire class of update bugs by
  construction.

---

## ARC-69 identity (shared by all four)

```solidity
struct Identity {
    string    name;          // required
    string    unitName;      // ≤ 8 chars per ARC-69
    string    description;
    string    avatarURL;     // ipfs:// or https://
    string    externalURL;   // website
    AgentType agentType;     // enum, see below
    bytes32   propertiesHash; // keccak256 of off-chain extras
    uint64    mintedAt;
}

enum AgentType {
    NONE,
    COGNITIVE_AUGMENTATION,
    CREATIVE_INTELLIGENCE,
    ANALYTICAL_PROCESSING,
    SPECIALIZED_DOMAIN,
    AGENT_ORCHESTRATOR
}
```

Validation: `name` non-empty, `unitName` ≤ 8 chars, `agentType ≠ NONE`. The
heavy ARC-69 JSON document lives off-chain at `tokenURI()`; on-chain we keep
only what indexers need to filter and rank.

---

## THOT and the 1024-dim addition

The AgenticPlace form lists 64 / 384 (pgvector) / 512 / 768 as the supported
embedding dimensions. This implementation **adds 1024** for compatibility
with high-fidelity embedders and the mindX 768→1024 expansion path:

```solidity
function isSupportedDimension(uint16 d) public pure returns (bool) {
    return d == 64 || d == 384 || d == 512 || d == 768 || d == 1024;
}
```

CID uniqueness is enforced globally inside the THOT contract. Trying to mint
a second THOT with a `dataCID` that's already on chain reverts with
`CIDAlreadyMinted()`. Reverse lookup is exposed via `tokenIdOfCID(string)`.

THOTs are frozen at mint — they have no manager and no update path. They
behave exactly like `ANFT` plus the tensor payload.

---

## iNFT autonomy model

`INFT` has two distinct privilege tracks that never overlap:

| Action | Caller | Reason |
| --- | --- | --- |
| `mint`, `setDirective`, `setManager`, `freeze`, `updateIdentity` | Owner / manager | Human keeps control of the asset |
| `selfUpdate(level, autonomous, behaviorCID)` | Directive address only | Agent evolves itself |

The directive address is typically held by the agent's runtime. `freeze()`
sets the directive back to `address(0)` so a frozen iNFT cannot self-mutate
again — the kill-switch is built into the freeze call.

```solidity
struct Intelligence {
    address directive;        // self-update key
    uint8   level;            // 0..100
    bool    autonomous;
    string  behaviorCID;      // IPFS CID of the directive program
}
```

---

## AgenticPlaceRegistry — the binding layer

`register(nftContract, tokenId, mcpEndpoint, a2aEndpoint, directiveAddress, website, trustModels, skills)`

The registry never owns or transfers NFTs. It binds metadata to a
`(nftContract, tokenId)` pair and lets the binding be updated or deactivated
by whoever currently owns the underlying token.

Key properties:

- **Project-agnostic.** Any ERC-721 that returns true for
  `supportsInterface(IARC69Metadata)` can be registered. The four NFTs in
  this repo are not privileged.
- **Live intelligence pull.** When registering or updating an iNFT, the
  registry calls `IIntelligentNFT.intelligenceOf()` to read the level and
  autonomy flag directly from the source contract. It is never duplicated,
  so a directive `selfUpdate()` is reflected on the next registry `update()`.
- **Trust bitmap.** `TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC | TRUST_TEE | TRUST_ZKML`
  (last two are upcoming per the form, but the bits are reserved).
- **Mint fee.** Native-token fee, default 0, configurable by admin to mirror
  the 0.001 ALGO Algorand cost.
- **mindX gating.** Optional. When `mindXGated == true` and the registry
  has an active mindX subscription, registrations call
  `requestBehaviorEvaluation()` against the iNFT's behavior CID and revert
  if the result comes back `COMPLETE && !passed`. Async results (`PENDING`)
  do not block.

---

## mindX as a service

`mindx.pythai.net/redoc` is the off-chain API. `IMindXService` is its
on-chain mirror so AgenticPlace — or any other consumer — can subscribe and
request work without needing a custom integration each time.

```solidity
interface IMindXService {
    function subscribe(uint8 plan) external payable returns (uint64 expiresAt);
    function subscriptionOf(address consumer) external view returns (Subscription memory);

    function requestAttestation(bytes32 subjectHash) external returns (bytes32 jobId);
    function getAttestation(bytes32 jobId) external view returns (Attestation memory);

    function requestBehaviorEvaluation(string calldata behaviorCID) external returns (bytes32 jobId);
    function getBehaviorScore(bytes32 jobId) external view returns (uint8 score, bool passed, JobStatus status);
}
```

Wiring AgenticPlace to mindX:

```solidity
// Once, from admin:
registry.setMindX(mindxAddress);
registry.subscribeToMindX{value: planPrice}(1);     // plan 1 = standard
registry.setMindXGated(true);                       // turn on behavior gating
```

After this, every registration of an iNFT runs its `behaviorCID` through
mindX before going active. Other projects can plug in by deploying their own
consumer contract and calling `mindX.subscribe()` from it — no permission
needed from this repo.

---

## Optional adapters (BANKON + x402)

The four NFTs deliberately have **zero coupling** to PAIMINT, DAIO, or x402.
If you want to gate minting on PAIMINT burn or Algorand payment, plug in:

- `adapters/BankonPaymentAdapter.sol` — burns PAIMINT via
  `IPAIMINT.burnForOperation()` before your minter contract calls `NFT.mint()`.
- `adapters/X402Adapter.sol` — verifies a parsec / parsec-wallet x402 receipt
  against `IX402.verifyReceipt()` and prevents replay.

Your minter contract chains them:

```solidity
bankon.chargePublishFee(msg.sender, 100 ether, "thot.publish");
x402.verifyAndConsume(receipt, sig, msg.sender);
thot.mint(msg.sender, identity, tensor, metadataURI);
```

Other projects that don't care about either system simply don't deploy the
adapters. The NFTs work standalone.

---

## Project layout

```
thot/
├── foundry.toml
├── README.md
├── src/
│   ├── nft/
│   │   ├── ARC69Base.sol
│   │   ├── ANFT.sol
│   │   ├── DNFT.sol
│   │   ├── INFT.sol
│   │   └── THOT.sol
│   ├── registry/
│   │   └── AgenticPlaceRegistry.sol
│   ├── interfaces/
│   │   ├── IARC69Metadata.sol
│   │   ├── IIntelligentNFT.sol
│   │   ├── IKnowledgeTensor.sol
│   │   ├── IAgenticPlaceRegistry.sol
│   │   ├── IMindXService.sol
│   │   ├── IPAIMINT.sol
│   │   └── IX402.sol
│   └── adapters/
│       ├── BankonPaymentAdapter.sol
│       └── X402Adapter.sol
├── test/
│   ├── TestFixtures.sol
│   ├── ANFT.t.sol
│   ├── DNFT.t.sol
│   ├── INFT.t.sol
│   ├── THOT.t.sol
│   └── AgenticPlaceRegistry.t.sol
└── script/
    └── Deploy.s.sol
```

---

## Setup

```bash
cd thot
forge init --no-commit --force
forge install OpenZeppelin/openzeppelin-contracts
forge install foundry-rs/forge-std
forge build
forge test -vvv
```

---

## Deployment

### Testnet (Sepolia)

```bash
export PRIVATE_KEY=0x...
export ADMIN=0x...
export MINDX_ADDR=0x...        # or 0x0 if not yet live
export SEPOLIA_RPC=https://...

forge script script/Deploy.s.sol:DeployAgenticStack \
  --rpc-url $SEPOLIA_RPC --broadcast --verify -vvvv
```

### Mainnet

Same script, swap RPC, add `--slow` for nonce safety:

```bash
forge script script/Deploy.s.sol:DeployAgenticStack \
  --rpc-url $MAINNET_RPC --broadcast --verify --slow -vvvv
```

The script deploys ANFT, DNFT, INFT, THOT, and AgenticPlaceRegistry in one
broadcast and prints all five addresses to the console.

### Post-deploy wiring

```solidity
// From the admin account:
registry.setMintFee(0.001 ether);             // optional, mirror Algorand cost
registry.setMindX(mindxBackend);              // optional
registry.subscribeToMindX{value: x}(plan);    // optional
registry.setMindXGated(true);                 // optional behavior gating

// Grant minter rights to your application contracts:
anft.grantRole(anft.MINTER_ROLE(), yourMinter);
dnft.grantRole(dnft.MINTER_ROLE(), yourMinter);
inft.grantRole(inft.MINTER_ROLE(), yourMinter);
thot.grantRole(thot.MINTER_ROLE(), yourMinter);
```

---

## End-to-end flow: mint a 1024-dim THOT and register it

```solidity
// 1. Mint the THOT.
IARC69Metadata.Identity memory id = IARC69Metadata.Identity({
    name:           "deltaverse-rag-1024",
    unitName:       "DVR1024",
    description:    "Retrieval embeddings for the DeltaVerse corpus",
    avatarURL:      "ipfs://QmAvatar",
    externalURL:    "https://agenticplace.pythai.net",
    agentType:      IARC69Metadata.AgentType.ANALYTICAL_PROCESSING,
    propertiesHash: keccak256(bytes("{...}")),
    mintedAt:       0
});

IKnowledgeTensor.Tensor memory tensor = IKnowledgeTensor.Tensor({
    dataCID:    "QmDeltaVerseRagBig",
    tensorHash: keccak256("raw_weights_blob"),
    dimensions: 1024,
    mintedAt:   0
});

uint256 tokenId = thot.mint(alice, id, tensor, "ipfs://QmMetaJson");

// 2. Register the THOT on AgenticPlace.
string[] memory skills = new string[](2);
skills[0] = "retrieval";
skills[1] = "embedding";

bytes32 binding = registry.register{value: registry.mintFee()}(
    address(thot),
    tokenId,
    "https://mcp.example/dvr1024",
    "https://a2a.example/dvr1024",
    address(0),                          // THOTs have no directive address
    "https://example.com",
    TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC,
    skills
);
```

---

## Testing

```bash
forge test -vvv

# Just the THOT 1024-dim path:
forge test -vvv --match-test test_1024DimMintWorks

# Just the registry's iNFT live-pull path:
forge test -vvv --match-test test_RegisterINFT_PullsLiveIntelligence
```

The suite covers:

- All five THOT dimensions (64, 384, 512, 768, **1024**)
- THOT CID uniqueness and reverse lookup
- iNFT directive autonomy + freeze severance
- DNFT manager update + freeze immutability transition
- ANFT immutability and minter access control
- Registry: own-token enforcement, double-register block, unsupported NFT
  rejection, fee enforcement, live intelligence refresh on update,
  mindX-gated registration with a mock backend

---

## Audit notes

- All external state-changing entry points are `nonReentrant`.
- THOT freezes the token at mint, so the otherwise-tricky
  "publish then mutate" race is impossible by construction.
- iNFT freeze severs the directive in the same call, so a frozen iNFT can
  never self-update again even if the directive key is later compromised.
- Registry never custodies tokens. The worst-case impact of a registry
  compromise is metadata corruption, never asset loss.
- Trust bitmap is bounded to `0x0F` to reserve high bits for future flags
  (TEE, zkML) without touching the validation path.
- The four NFT contracts have zero dependencies on BANKON, DAIO, x402,
  AgenticPlace, or each other. They will keep working if any of those
  systems is later removed or replaced.

> ⚠️  Unaudited code. Run a third-party audit before mainnet deployment.

---

## License

MIT OR Apache-2.0 — pick whichever fits your downstream project.
