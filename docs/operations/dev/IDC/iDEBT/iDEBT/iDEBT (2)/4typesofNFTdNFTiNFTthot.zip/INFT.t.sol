// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./TestFixtures.sol";
import "../src/nft/INFT.sol";

contract INFTTest is TestFixtures {
    INFT internal inft;
    address internal directive = address(0xD1);

    function setUp() public {
        vm.prank(admin);
        inft = new INFT(admin);
    }

    function test_DirectiveCanSelfUpdate() public {
        vm.prank(admin);
        uint256 id = inft.mint(
            alice,
            _identity("agent-1"),
            _intelligence(directive, 60),
            "ipfs://i1"
        );

        vm.prank(directive);
        inft.selfUpdate(id, 80, true, "QmNewBehavior");

        IIntelligentNFT.Intelligence memory got = inft.intelligenceOf(id);
        assertEq(got.level, 80);
        assertEq(got.behaviorCID, "QmNewBehavior");
    }

    function test_RevertWhen_NonDirectiveSelfUpdates() public {
        vm.prank(admin);
        uint256 id = inft.mint(
            alice,
            _identity("agent-1"),
            _intelligence(directive, 60),
            "ipfs://i1"
        );

        vm.prank(bob);
        vm.expectRevert(INFT.NotDirective.selector);
        inft.selfUpdate(id, 80, true, "QmX");
    }

    function test_OwnerCanRotateDirective() public {
        vm.prank(admin);
        uint256 id = inft.mint(
            alice,
            _identity("agent-1"),
            _intelligence(directive, 60),
            "ipfs://i1"
        );

        address newDirective = address(0xD2);
        vm.prank(alice);
        inft.setDirective(id, newDirective);

        assertEq(inft.intelligenceOf(id).directive, newDirective);

        // Old directive can no longer self-update.
        vm.prank(directive);
        vm.expectRevert(INFT.NotDirective.selector);
        inft.selfUpdate(id, 90, true, "QmX");
    }

    function test_FreezeSeversDirective() public {
        vm.prank(admin);
        uint256 id = inft.mint(
            alice,
            _identity("agent-1"),
            _intelligence(directive, 60),
            "ipfs://i1"
        );

        vm.prank(alice);
        inft.freeze(id);

        assertEq(inft.intelligenceOf(id).directive, address(0));
        assertTrue(inft.isFrozen(id));

        vm.prank(directive);
        vm.expectRevert(INFT.NotDirective.selector);
        inft.selfUpdate(id, 99, false, "QmX");
    }

    function test_RevertWhen_LevelExceeds100() public {
        IIntelligentNFT.Intelligence memory bad = _intelligence(directive, 101);
        vm.prank(admin);
        vm.expectRevert(INFT.InvalidLevel.selector);
        inft.mint(alice, _identity("x"), bad, "ipfs://x");
    }
}
