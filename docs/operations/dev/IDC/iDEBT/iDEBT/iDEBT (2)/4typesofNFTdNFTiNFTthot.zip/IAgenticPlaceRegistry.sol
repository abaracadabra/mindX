// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

// File-level trust model bitmap (Solidity disallows constants inside interfaces).
uint8 constant TRUST_REPUTATION      = 1 << 0;
uint8 constant TRUST_CRYPTO_ECONOMIC = 1 << 1;
uint8 constant TRUST_TEE             = 1 << 2; // upcoming
uint8 constant TRUST_ZKML            = 1 << 3; // upcoming

/**
 * @title IAgenticPlaceRegistry
 * @notice Directory that binds an agent NFT (aNFT, dNFT, iNFT, or THOT)
 *         to its protocol endpoints, trust model, and skill set. Modeled
 *         after the AgenticPlace register flow at agenticplace.pythai.net/register.
 *
 *         The registry accepts any ERC-721 implementing IARC69Metadata, so
 *         third-party projects can register their own agent NFTs without
 *         needing to use the contracts in this repository.
 */
interface IAgenticPlaceRegistry {
    struct AgentBinding {
        address  nftContract;
        uint256  tokenId;
        address  owner;
        string   mcpEndpoint;
        string   a2aEndpoint;
        address  directiveAddress;     // EVM mirror; bytes32 if Algorand-native
        string   website;
        uint8    trustModels;          // bitmap of TRUST_* flags
        string[] skills;
        bool     autonomous;
        uint8    intelligenceLevel;    // 0..100; 0 if not iNFT
        uint64   registeredAt;
        uint64   updatedAt;
        bool     active;
    }

    event AgentRegistered(
        bytes32 indexed bindingId,
        address indexed nftContract,
        uint256 indexed tokenId,
        address owner
    );
    event AgentUpdated(bytes32 indexed bindingId);
    event AgentDeactivated(bytes32 indexed bindingId);

    function register(
        address  nftContract,
        uint256  tokenId,
        string   calldata mcpEndpoint,
        string   calldata a2aEndpoint,
        address  directiveAddress,
        string   calldata website,
        uint8    trustModels,
        string[] calldata skills
    ) external payable returns (bytes32 bindingId);

    function update(
        bytes32  bindingId,
        string   calldata mcpEndpoint,
        string   calldata a2aEndpoint,
        address  directiveAddress,
        string   calldata website,
        uint8    trustModels,
        string[] calldata skills
    ) external;

    function deactivate(bytes32 bindingId) external;

    function bindingOf(bytes32 bindingId) external view returns (AgentBinding memory);
    function bindingIdFor(address nftContract, uint256 tokenId) external pure returns (bytes32);
    function mintFee() external view returns (uint256);
}
