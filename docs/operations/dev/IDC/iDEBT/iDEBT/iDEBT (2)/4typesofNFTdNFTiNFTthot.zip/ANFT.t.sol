// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./TestFixtures.sol";
import "../src/nft/ANFT.sol";

contract ANFTTest is TestFixtures {
    ANFT internal anft;

    function setUp() public {
        vm.prank(admin);
        anft = new ANFT(admin);
    }

    function test_MintFreezesAtCreation() public {
        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        assertEq(anft.ownerOf(id), alice);
        assertTrue(anft.isFrozen(id));
        assertEq(anft.identityOf(id).name, "alpha");
        assertEq(uint32(anft.nftKind()), uint32(0x614e4654)); // "aNFT"
    }

    function test_RevertWhen_NonMinterMints() public {
        vm.prank(alice);
        vm.expectRevert();
        anft.mint(alice, _identity("x"), "ipfs://x");
    }

    function test_RevertWhen_EmptyName() public {
        IARC69Metadata.Identity memory id = _identity("x");
        id.name = "";
        vm.prank(admin);
        vm.expectRevert(ARC69Base.EmptyName.selector);
        anft.mint(alice, id, "ipfs://x");
    }

    function test_TransferAllowedDespiteFreeze() public {
        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        vm.prank(alice);
        anft.transferFrom(alice, bob, id);
        assertEq(anft.ownerOf(id), bob);
    }
}
