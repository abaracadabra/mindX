// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./TestFixtures.sol";
import "../src/registry/AgenticPlaceRegistry.sol";
import "../src/interfaces/IAgenticPlaceRegistry.sol";
import "../src/interfaces/IMindXService.sol";
import "../src/nft/ANFT.sol";
import "../src/nft/INFT.sol";
import "../src/nft/THOT.sol";

// ─────────────────────────────────────────────────────────────────────────
//  Mock mindX backend
// ─────────────────────────────────────────────────────────────────────────
contract MockMindX is IMindXService {
    mapping(address => Subscription) public subs;
    mapping(bytes32 => Attestation)  public atts;
    mapping(bytes32 => uint8)        public behaviorScores;
    mapping(bytes32 => bool)         public behaviorPassed;
    mapping(bytes32 => JobStatus)    public behaviorStatus;
    uint256 public counter;

    function planPrice(uint8) external pure returns (uint256) { return 0; }

    function subscribe(uint8 plan) external payable returns (uint64 expiresAt) {
        expiresAt = uint64(block.timestamp + 30 days);
        subs[msg.sender] = Subscription({
            consumer:       msg.sender,
            expiresAt:      expiresAt,
            callsRemaining: 1000,
            plan:           plan,
            active:         true
        });
        emit Subscribed(msg.sender, plan, expiresAt);
    }

    function subscriptionOf(address consumer) external view returns (Subscription memory) {
        return subs[consumer];
    }

    function requestAttestation(bytes32 subjectHash) external returns (bytes32 jobId) {
        jobId = keccak256(abi.encode(msg.sender, subjectHash, counter++));
        atts[jobId] = Attestation({
            subjectHash:        subjectHash,
            consciousnessLevel: 75,
            ataraxiaScore:      80,
            fingerprint:        keccak256("fp"),
            dimensions:         1024,
            completedAt:        uint64(block.timestamp),
            status:             JobStatus.COMPLETE
        });
        emit AttestationRequested(jobId, msg.sender, subjectHash);
        emit AttestationDelivered(jobId, 75, 80);
    }

    function getAttestation(bytes32 jobId) external view returns (Attestation memory) {
        return atts[jobId];
    }

    function requestBehaviorEvaluation(string calldata behaviorCID) external returns (bytes32 jobId) {
        jobId = keccak256(abi.encode(msg.sender, behaviorCID, counter++));
        behaviorScores[jobId] = 90;
        behaviorPassed[jobId] = true;
        behaviorStatus[jobId] = JobStatus.COMPLETE;
        emit BehaviorEvaluationRequested(jobId, behaviorCID);
        emit BehaviorEvaluationDelivered(jobId, 90, true);
    }

    function getBehaviorScore(bytes32 jobId)
        external
        view
        returns (uint8 score, bool passed, JobStatus status)
    {
        return (behaviorScores[jobId], behaviorPassed[jobId], behaviorStatus[jobId]);
    }

    // Test helper.
    function setBehaviorResult(bytes32 jobId, uint8 score, bool passed) external {
        behaviorScores[jobId] = score;
        behaviorPassed[jobId] = passed;
        behaviorStatus[jobId] = JobStatus.COMPLETE;
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  Tests
// ─────────────────────────────────────────────────────────────────────────
contract AgenticPlaceRegistryTest is TestFixtures {
    AgenticPlaceRegistry internal registry;
    MockMindX            internal mindx;
    ANFT                 internal anft;
    INFT                 internal inft;
    THOT                 internal thot;

    function setUp() public {
        mindx = new MockMindX();

        vm.startPrank(admin);
        registry = new AgenticPlaceRegistry(admin, address(mindx));
        anft = new ANFT(admin);
        inft = new INFT(admin);
        thot = new THOT(admin);
        vm.stopPrank();
    }

    function _emptySkills() internal pure returns (string[] memory s) {
        s = new string[](2);
        s[0] = "research";
        s[1] = "synthesis";
    }

    // ────────── basic registration ──────────

    function test_RegisterANFT() public {
        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        vm.prank(alice);
        bytes32 binding = registry.register(
            address(anft),
            id,
            "https://mcp.example/agent",
            "https://a2a.example/agent",
            address(0xDEAD),
            "https://example.com",
            uint8(TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC),
            _emptySkills()
        );

        IAgenticPlaceRegistry.AgentBinding memory b = registry.bindingOf(binding);
        assertEq(b.nftContract, address(anft));
        assertEq(b.tokenId, id);
        assertEq(b.owner, alice);
        assertTrue(b.active);
        assertEq(b.intelligenceLevel, 0); // aNFT has no intelligence
        assertFalse(b.autonomous);
    }

    function test_RegisterINFT_PullsLiveIntelligence() public {
        vm.prank(admin);
        uint256 id = inft.mint(
            alice,
            _identity("smart"),
            _intelligence(address(0xD1), 75),
            "ipfs://i"
        );

        vm.prank(alice);
        bytes32 binding = registry.register(
            address(inft),
            id,
            "https://mcp",
            "https://a2a",
            address(0xD1),
            "https://w",
            uint8(TRUST_REPUTATION),
            _emptySkills()
        );

        IAgenticPlaceRegistry.AgentBinding memory b = registry.bindingOf(binding);
        assertEq(b.intelligenceLevel, 75);
        assertTrue(b.autonomous);
    }

    function test_RegisterTHOT_With1024Dim() public {
        vm.prank(admin);
        uint256 id = thot.mint(
            alice,
            _identity("knowledge"),
            _tensor("QmBigBrain", 1024),
            "ipfs://meta"
        );

        vm.prank(alice);
        bytes32 binding = registry.register(
            address(thot),
            id,
            "https://mcp",
            "https://a2a",
            address(0),
            "https://w",
            uint8(TRUST_CRYPTO_ECONOMIC),
            _emptySkills()
        );

        IAgenticPlaceRegistry.AgentBinding memory b = registry.bindingOf(binding);
        assertEq(b.nftContract, address(thot));
        assertTrue(b.active);
    }

    // ────────── access control ──────────

    function test_RevertWhen_NonOwnerRegisters() public {
        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        vm.prank(bob);
        vm.expectRevert(AgenticPlaceRegistry.NotTokenOwner.selector);
        registry.register(
            address(anft),
            id,
            "x", "x", address(0), "x",
            uint8(TRUST_REPUTATION),
            _emptySkills()
        );
    }

    function test_RevertWhen_DoubleRegister() public {
        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        vm.startPrank(alice);
        registry.register(address(anft), id, "x","x",address(0),"x",
            uint8(TRUST_REPUTATION), _emptySkills());

        vm.expectRevert(AgenticPlaceRegistry.AlreadyRegistered.selector);
        registry.register(address(anft), id, "x","x",address(0),"x",
            uint8(TRUST_REPUTATION), _emptySkills());
        vm.stopPrank();
    }

    function test_RevertWhen_UnsupportedNFT() public {
        // A bare ERC-721 that does NOT implement IARC69Metadata should be rejected.
        vm.prank(alice);
        vm.expectRevert(AgenticPlaceRegistry.NotARC69Compatible.selector);
        registry.register(
            address(0xBEEF),
            1,
            "x","x",address(0),"x",
            uint8(TRUST_REPUTATION),
            _emptySkills()
        );
    }

    // ────────── update / deactivate ──────────

    function test_UpdateRefreshesIntelligence() public {
        vm.prank(admin);
        uint256 id = inft.mint(alice, _identity("s"), _intelligence(address(0xD1), 50), "ipfs://i");

        vm.prank(alice);
        bytes32 binding = registry.register(
            address(inft),
            id, "x","x",address(0xD1),"x",
            uint8(TRUST_REPUTATION), _emptySkills()
        );
        assertEq(registry.bindingOf(binding).intelligenceLevel, 50);

        // Directive bumps level via selfUpdate.
        vm.prank(address(0xD1));
        inft.selfUpdate(id, 95, true, "QmNew");

        // Owner pushes a registry update — should refresh the cached level.
        vm.prank(alice);
        registry.update(binding, "x","x",address(0xD1),"x",
            uint8(TRUST_REPUTATION), _emptySkills());

        assertEq(registry.bindingOf(binding).intelligenceLevel, 95);
    }

    function test_DeactivateBinding() public {
        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        vm.startPrank(alice);
        bytes32 binding = registry.register(address(anft), id, "x","x",address(0),"x",
            uint8(TRUST_REPUTATION), _emptySkills());
        registry.deactivate(binding);
        vm.stopPrank();

        assertFalse(registry.bindingOf(binding).active);
    }

    // ────────── mint fee ──────────

    function test_MintFeeCharged() public {
        vm.prank(admin);
        registry.setMintFee(0.001 ether);

        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        vm.deal(alice, 1 ether);
        vm.prank(alice);
        registry.register{value: 0.001 ether}(
            address(anft),
            id, "x","x",address(0),"x",
            uint8(TRUST_REPUTATION), _emptySkills()
        );

        assertEq(address(registry).balance, 0.001 ether);
    }

    function test_RevertWhen_FeeTooLow() public {
        vm.prank(admin);
        registry.setMintFee(0.001 ether);

        vm.prank(admin);
        uint256 id = anft.mint(alice, _identity("alpha"), "ipfs://meta");

        vm.deal(alice, 1 ether);
        vm.prank(alice);
        vm.expectRevert(AgenticPlaceRegistry.InsufficientFee.selector);
        registry.register{value: 0.0005 ether}(
            address(anft),
            id, "x","x",address(0),"x",
            uint8(TRUST_REPUTATION), _emptySkills()
        );
    }

    // ────────── mindX gating ──────────

    function test_MindXGatedRegistration_Passes() public {
        vm.startPrank(admin);
        registry.setMindXGated(true);
        registry.subscribeToMindX(1);
        vm.stopPrank();

        vm.prank(admin);
        uint256 id = inft.mint(alice, _identity("smart"),
            _intelligence(address(0xD1), 80), "ipfs://i");

        // Mock mindX returns score=90 passed=true by default.
        vm.prank(alice);
        bytes32 binding = registry.register(
            address(inft),
            id, "x","x",address(0xD1),"x",
            uint8(TRUST_REPUTATION), _emptySkills()
        );
        assertTrue(registry.bindingOf(binding).active);
    }
}
