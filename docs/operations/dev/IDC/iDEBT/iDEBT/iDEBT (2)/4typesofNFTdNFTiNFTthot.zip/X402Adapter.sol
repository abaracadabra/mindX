// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/AccessControl.sol";
import "../interfaces/IX402.sol";

/**
 * @title X402Adapter
 * @notice Optional adapter that lets a project accept Algorand payments
 *         (settled via parsec / parsec-wallet x402) as proof-of-payment for
 *         minting privileges. Independent of all NFT contracts.
 */
contract X402Adapter is AccessControl {
    bytes32 public constant CONSUMER_ROLE = keccak256("CONSUMER_ROLE");

    IX402 public x402;
    mapping(bytes32 => bool) public usedReceipts;

    event ReceiptConsumed(bytes32 indexed receiptId, address indexed payer, uint256 amount);

    error UnknownReceipt();
    error ReceiptAlreadyUsed();
    error Expired();

    constructor(address admin, address x402Address) {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(CONSUMER_ROLE, admin);
        x402 = IX402(x402Address);
    }

    function verifyAndConsume(
        IX402.Receipt calldata receipt,
        bytes calldata signature,
        address expectedPayer
    ) external onlyRole(CONSUMER_ROLE) returns (bytes32 receiptId) {
        if (receipt.expiresAt < block.timestamp) revert Expired();
        if (!x402.verifyReceipt(receipt, signature, expectedPayer)) revert UnknownReceipt();

        receiptId = keccak256(abi.encode(receipt));
        if (usedReceipts[receiptId]) revert ReceiptAlreadyUsed();
        usedReceipts[receiptId] = true;

        emit ReceiptConsumed(receiptId, expectedPayer, receipt.amount);
    }

    function setX402(address next) external onlyRole(DEFAULT_ADMIN_ROLE) {
        x402 = IX402(next);
    }
}
