// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/interfaces/IARC69Metadata.sol";
import "../src/interfaces/IIntelligentNFT.sol";
import "../src/interfaces/IKnowledgeTensor.sol";

/**
 * @title TestFixtures
 * @notice Shared helpers for building Identity, Intelligence, and Tensor
 *         records inside the Foundry test suite. All four NFT test files
 *         inherit from this so the boilerplate stays in one place.
 */
abstract contract TestFixtures is Test {
    address internal admin = address(0xA11CE);
    address internal alice = address(0xA1);
    address internal bob   = address(0xB0B);
    address internal carol = address(0xCA70);

    function _identity(string memory name)
        internal
        pure
        returns (IARC69Metadata.Identity memory)
    {
        return IARC69Metadata.Identity({
            name:           name,
            unitName:       "AGENT",
            description:    "test agent",
            avatarURL:      "ipfs://avatar",
            externalURL:    "https://agenticplace.pythai.net",
            agentType:      IARC69Metadata.AgentType.COGNITIVE_AUGMENTATION,
            propertiesHash: keccak256("props"),
            mintedAt:       0
        });
    }

    function _intelligence(address directive, uint8 level)
        internal
        pure
        returns (IIntelligentNFT.Intelligence memory)
    {
        return IIntelligentNFT.Intelligence({
            directive:   directive,
            level:       level,
            autonomous:  true,
            behaviorCID: "QmBehaviorCID"
        });
    }

    function _tensor(string memory cid, uint16 dims)
        internal
        pure
        returns (IKnowledgeTensor.Tensor memory)
    {
        return IKnowledgeTensor.Tensor({
            dataCID:    cid,
            tensorHash: keccak256(bytes(cid)),
            dimensions: dims,
            mintedAt:   0
        });
    }
}
