// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./TestFixtures.sol";
import "../src/nft/DNFT.sol";

contract DNFTTest is TestFixtures {
    DNFT internal dnft;

    function setUp() public {
        vm.prank(admin);
        dnft = new DNFT(admin);
    }

    function test_OwnerCanUpdateBeforeFreeze() public {
        vm.prank(admin);
        uint256 id = dnft.mint(alice, _identity("v1"), "ipfs://v1");

        IARC69Metadata.Identity memory updated = _identity("v2");
        vm.prank(alice);
        dnft.updateIdentity(id, updated);

        assertEq(dnft.identityOf(id).name, "v2");
    }

    function test_FreezeMakesImmutable() public {
        vm.prank(admin);
        uint256 id = dnft.mint(alice, _identity("v1"), "ipfs://v1");

        vm.startPrank(alice);
        dnft.freeze(id);

        vm.expectRevert(ARC69Base.IdentityFrozen.selector);
        dnft.updateIdentity(id, _identity("v2"));
        vm.stopPrank();

        assertTrue(dnft.isFrozen(id));
    }

    function test_RevertWhen_NonOwnerUpdates() public {
        vm.prank(admin);
        uint256 id = dnft.mint(alice, _identity("v1"), "ipfs://v1");

        vm.prank(bob);
        vm.expectRevert(DNFT.NotManager.selector);
        dnft.updateIdentity(id, _identity("v2"));
    }
}
