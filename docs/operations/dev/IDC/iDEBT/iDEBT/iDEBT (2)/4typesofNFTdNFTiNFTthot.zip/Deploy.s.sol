// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "forge-std/Script.sol";

import "../src/nft/ANFT.sol";
import "../src/nft/DNFT.sol";
import "../src/nft/INFT.sol";
import "../src/nft/THOT.sol";
import "../src/registry/AgenticPlaceRegistry.sol";

/**
 * @title DeployAgenticStack
 * @notice Foundry deploy script. Deploys the four independent NFT contracts
 *         (ANFT, DNFT, INFT, THOT) followed by the AgenticPlaceRegistry. The
 *         registry is wired to an existing mindX backend address (or zero if
 *         mindX is not yet live on the target chain).
 *
 *   Testnet:
 *     forge script script/Deploy.s.sol:DeployAgenticStack \
 *       --rpc-url $SEPOLIA_RPC --broadcast --verify -vvvv
 *
 *   Mainnet:
 *     forge script script/Deploy.s.sol:DeployAgenticStack \
 *       --rpc-url $MAINNET_RPC --broadcast --verify --slow -vvvv
 *
 *   Required env vars:
 *     PRIVATE_KEY     deployer key
 *     ADMIN           admin / DEFAULT_ADMIN_ROLE recipient
 *     MINDX_ADDR      mindx.pythai.net on-chain bridge (or 0x0 if N/A)
 */
contract DeployAgenticStack is Script {
    function run()
        external
        returns (
            ANFT anft,
            DNFT dnft,
            INFT inft,
            THOT thot,
            AgenticPlaceRegistry registry
        )
    {
        uint256 pk        = vm.envUint("PRIVATE_KEY");
        address admin     = vm.envAddress("ADMIN");
        address mindxAddr = vm.envOr("MINDX_ADDR", address(0));

        vm.startBroadcast(pk);

        anft = new ANFT(admin);
        dnft = new DNFT(admin);
        inft = new INFT(admin);
        thot = new THOT(admin);

        registry = new AgenticPlaceRegistry(admin, mindxAddr);

        vm.stopBroadcast();

        console2.log("ANFT:                ", address(anft));
        console2.log("DNFT:                ", address(dnft));
        console2.log("INFT:                ", address(inft));
        console2.log("THOT:                ", address(thot));
        console2.log("AgenticPlaceRegistry:", address(registry));
        console2.log("MindX backend:       ", mindxAddr);
        console2.log("Admin:               ", admin);
    }
}
