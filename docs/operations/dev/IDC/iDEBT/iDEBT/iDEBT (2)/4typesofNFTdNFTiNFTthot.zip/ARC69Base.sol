// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721Enumerable.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

import "../interfaces/IARC69Metadata.sol";

/**
 * @title ARC69Base
 * @author Professor Codephreak
 * @notice Abstract base shared by aNFT, dNFT, iNFT, and THOT. Implements the
 *         ARC-69-style identity record on chain plus the standard ERC-721
 *         extensions. Whether identity can be mutated, and by whom, is left
 *         entirely to the concrete child contract.
 *
 *         Reusability: this contract has zero coupling to BANKON, PAIMINT,
 *         DAIO, x402, or AgenticPlace. Any project can extend it.
 */
abstract contract ARC69Base is
    ERC721,
    ERC721Enumerable,
    ERC721URIStorage,
    AccessControl,
    ReentrancyGuard,
    IARC69Metadata
{
    // ─────────────────────────────────────────────────────────────────────
    //  Roles
    // ─────────────────────────────────────────────────────────────────────
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");

    // ─────────────────────────────────────────────────────────────────────
    //  Storage
    // ─────────────────────────────────────────────────────────────────────
    uint256 internal _nextTokenId = 1;
    mapping(uint256 => Identity) internal _identity;
    mapping(uint256 => bool)     internal _frozen;

    // ─────────────────────────────────────────────────────────────────────
    //  Errors
    // ─────────────────────────────────────────────────────────────────────
    error NotTokenOwner();
    error IdentityFrozen();
    error EmptyName();
    error UnitNameTooLong();
    error InvalidAgentType();
    error ZeroAddress();

    // ─────────────────────────────────────────────────────────────────────
    //  Events
    // ─────────────────────────────────────────────────────────────────────
    event IdentityMinted(uint256 indexed tokenId, address indexed to, AgentType agentType);
    event IdentityUpdated(uint256 indexed tokenId);
    event IdentityFrozenEvent(uint256 indexed tokenId);

    constructor(
        string memory name_,
        string memory symbol_,
        address admin
    ) ERC721(name_, symbol_) {
        if (admin == address(0)) revert ZeroAddress();
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(MINTER_ROLE, admin);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  IARC69Metadata
    // ─────────────────────────────────────────────────────────────────────
    function identityOf(uint256 tokenId) external view returns (Identity memory) {
        _requireOwned(tokenId);
        return _identity[tokenId];
    }

    function isFrozen(uint256 tokenId) external view returns (bool) {
        _requireOwned(tokenId);
        return _frozen[tokenId];
    }

    function nftKind() external pure virtual returns (bytes4);

    // ─────────────────────────────────────────────────────────────────────
    //  Internal helpers
    // ─────────────────────────────────────────────────────────────────────
    function _validateIdentity(Identity memory id) internal pure {
        if (bytes(id.name).length == 0)         revert EmptyName();
        if (bytes(id.unitName).length > 8)      revert UnitNameTooLong();
        if (uint8(id.agentType) == 0)           revert InvalidAgentType();
    }

    function _writeIdentity(uint256 tokenId, Identity memory id) internal {
        id.mintedAt = uint64(block.timestamp);
        _identity[tokenId] = id;
    }

    function _requireUnfrozen(uint256 tokenId) internal view {
        if (_frozen[tokenId]) revert IdentityFrozen();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Required overrides
    // ─────────────────────────────────────────────────────────────────────
    function _update(address to, uint256 tokenId, address auth)
        internal
        override(ERC721, ERC721Enumerable)
        returns (address)
    {
        return super._update(to, tokenId, auth);
    }

    function _increaseBalance(address account, uint128 value)
        internal
        override(ERC721, ERC721Enumerable)
    {
        super._increaseBalance(account, value);
    }

    function tokenURI(uint256 tokenId)
        public
        view
        override(ERC721, ERC721URIStorage)
        returns (string memory)
    {
        return super.tokenURI(tokenId);
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        virtual
        override(ERC721, ERC721Enumerable, ERC721URIStorage, AccessControl)
        returns (bool)
    {
        return
            interfaceId == type(IARC69Metadata).interfaceId ||
            super.supportsInterface(interfaceId);
    }
}
