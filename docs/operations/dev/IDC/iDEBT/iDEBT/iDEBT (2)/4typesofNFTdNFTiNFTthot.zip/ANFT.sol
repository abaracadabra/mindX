// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "./ARC69Base.sol";

/**
 * @title ANFT — Standard Immutable Agent NFT
 * @author Professor Codephreak
 * @notice EVM analog of the AgenticPlace Algorand `aNFT` type:
 *           "Standard immutable NFT. No manager address. Permanent on-chain
 *            identity. Cannot be updated after mint."
 *
 *         Identity is frozen at mint and cannot be changed by anyone — not
 *         the owner, not the minter, not the contract admin. Transfers are
 *         allowed; identity is not.
 *
 *         Reusable: depends only on ARC69Base + OpenZeppelin. Any project
 *         can mint aNFTs by granting MINTER_ROLE to its own contract.
 */
contract ANFT is ARC69Base {
    bytes4 public constant KIND = 0x614e4654; // "aNFT" big-endian

    constructor(address admin) ARC69Base("DeltaVerse aNFT", "ANFT", admin) {}

    /**
     * @notice Mint a new immutable identity NFT.
     * @param  to           Recipient.
     * @param  identity     Frozen identity record.
     * @param  metadataURI  ipfs://<cid> for the full ARC-69 JSON.
     */
    function mint(
        address to,
        Identity calldata identity,
        string calldata metadataURI
    ) external nonReentrant onlyRole(MINTER_ROLE) returns (uint256 tokenId) {
        if (to == address(0)) revert ZeroAddress();
        _validateIdentity(identity);

        tokenId = _nextTokenId++;

        _writeIdentity(tokenId, identity);
        _frozen[tokenId] = true; // immutable from inception

        _safeMint(to, tokenId);
        _setTokenURI(tokenId, metadataURI);

        emit IdentityMinted(tokenId, to, identity.agentType);
        emit IdentityFrozenEvent(tokenId);
    }

    function nftKind() external pure override returns (bytes4) {
        return KIND;
    }
}
