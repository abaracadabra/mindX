// SPDX-License-Identifier: MIT OR Apache-2.0
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/AccessControl.sol";
import "../interfaces/IPAIMINT.sol";

/**
 * @title BankonPaymentAdapter
 * @notice Optional payment gate that burns BANKON PAIMINT in exchange for
 *         minting privileges on any of the four NFT contracts. Wholly
 *         decoupled — projects that don't want PAIMINT can ignore this file.
 *
 *         Pattern:
 *           1. Project's minter contract calls `chargePublishFee(payer, amt, op)`.
 *           2. This adapter burns PAIMINT from `payer`.
 *           3. Adapter returns; minter proceeds with NFT.mint(...).
 */
contract BankonPaymentAdapter is AccessControl {
    bytes32 public constant CHARGER_ROLE = keccak256("CHARGER_ROLE");

    IPAIMINT public paimint;
    uint256  public defaultFee;

    event Charged(address indexed payer, uint256 amount, bytes32 op);
    event PaimintUpdated(address indexed previous, address indexed next);
    event DefaultFeeUpdated(uint256 previous, uint256 next);

    error InsufficientPAIMINT();

    constructor(address admin, address paimintAddress, uint256 _defaultFee) {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(CHARGER_ROLE, admin);
        paimint    = IPAIMINT(paimintAddress);
        defaultFee = _defaultFee;
    }

    function chargePublishFee(address payer, uint256 amount, bytes32 op)
        external
        onlyRole(CHARGER_ROLE)
    {
        uint256 fee = amount == 0 ? defaultFee : amount;
        if (paimint.balanceOf(payer) < fee) revert InsufficientPAIMINT();
        paimint.burnForOperation(payer, fee, _toString(op));
        emit Charged(payer, fee, op);
    }

    function setPaimint(address next) external onlyRole(DEFAULT_ADMIN_ROLE) {
        emit PaimintUpdated(address(paimint), next);
        paimint = IPAIMINT(next);
    }

    function setDefaultFee(uint256 next) external onlyRole(DEFAULT_ADMIN_ROLE) {
        emit DefaultFeeUpdated(defaultFee, next);
        defaultFee = next;
    }

    function _toString(bytes32 b) internal pure returns (string memory) {
        bytes memory buf = new bytes(32);
        uint256 len;
        for (uint256 i; i < 32; ++i) {
            bytes1 c = b[i];
            if (c == 0) break;
            buf[i] = c;
            unchecked { ++len; }
        }
        bytes memory out = new bytes(len);
        for (uint256 i; i < len; ++i) out[i] = buf[i];
        return string(out);
    }
}
