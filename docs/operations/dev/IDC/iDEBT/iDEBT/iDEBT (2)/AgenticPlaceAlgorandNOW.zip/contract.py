# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# BankonPaimint — BANKON PAIMINT token on Algorand   v1.3
#
# PAIMINT is the in-engine reward token for the DeltaVerse. It is:
#   - An Algorand ASA (fungible, 6 decimals, fixed total supply at deploy)
#   - Fully managed by this application (manager + reserve + clawback)
#   - Operated by authorized CHARGER apps via reward() / burn_for_operation()
#
# AUDIT v1.3 — CRITICAL SECURITY FIX:
#
#   v1.2 let any charger burn any amount of PAIMINT from any user at any time.
#   That's a privilege explosion: a compromised charger could drain every
#   user's balance.
#
#   v1.3 introduces a per-user allowance system:
#     - Users call `approve_charger(charger, max_amount)` to set an
#       allowance. This is a user-signed tx: the user explicitly consents
#       to be charged up to `max_amount` by that charger.
#     - Each successful `burn_for_operation` decrements the allowance.
#     - When the allowance hits zero, the charger can no longer burn from
#       that user until they approve again.
#     - `reward()` does not consume allowance (minting to users is always safe).
#     - Admin revoke does NOT affect user allowances — users revoke via
#       `revoke_charger_approval(charger)`.
#
# This mirrors ERC-20's `approve` + `transferFrom` pattern adapted to
# Algorand's clawback model. It provides the same security guarantee: a
# compromised charger can only burn what users have already authorized.

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    itxn,
    op,
)

from smart_contracts.common.constants import MAX_REASON_LENGTH


# Token defaults: 1B PAIMINT with 6 decimals.
DEFAULT_DECIMALS: int = 6
DEFAULT_TOTAL_SUPPLY: int = 1_000_000_000 * 10**6


# ─── Events ───────────────────────────────────────────────────────────────
class PaimintBootstrapped(arc4.Struct):
    asset_id: arc4.UInt64
    total_supply: arc4.UInt64


class PaimintRewarded(arc4.Struct):
    user: arc4.Address
    amount: arc4.UInt64
    reason: arc4.String
    charger: arc4.Address


class PaimintBurned(arc4.Struct):
    user: arc4.Address
    amount: arc4.UInt64
    operation: arc4.String
    charger: arc4.Address


class ChargerGranted(arc4.Struct):
    charger: arc4.Address


class ChargerRevoked(arc4.Struct):
    charger: arc4.Address


class AllowanceApproved(arc4.Struct):
    user: arc4.Address
    charger: arc4.Address
    amount: arc4.UInt64


class AllowanceRevoked(arc4.Struct):
    user: arc4.Address
    charger: arc4.Address


# ─── Box records ──────────────────────────────────────────────────────────
class ChargerRecord(arc4.Struct):
    granted_at: arc4.UInt64
    granted_by: arc4.Address
    total_rewarded: arc4.UInt64
    total_burned: arc4.UInt64


class AllowanceRecord(arc4.Struct):
    user: arc4.Address
    charger: arc4.Address
    amount: arc4.UInt64
    approved_at: arc4.UInt64


class BankonPaimint(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.asset_id = GlobalState(UInt64)
        self.decimals = GlobalState(UInt64)
        self.total_supply = GlobalState(UInt64)
        self.created = GlobalState(UInt64)  # 0 = not bootstrapped, 1 = bootstrapped

        self.total_rewarded_cumulative = GlobalState(UInt64)
        self.total_burned_cumulative = GlobalState(UInt64)

        self.chargers = BoxMap(Account, ChargerRecord, key_prefix=b"ch")
        # Allowance key: sha256(user_address || charger_address) → AllowanceRecord
        self.allowances = BoxMap(Bytes, AllowanceRecord, key_prefix=b"al")

    # ─── lifecycle ─────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.asset_id.value = UInt64(0)
        self.decimals.value = UInt64(DEFAULT_DECIMALS)
        self.total_supply.value = UInt64(DEFAULT_TOTAL_SUPPLY)
        self.created.value = UInt64(0)
        self.total_rewarded_cumulative.value = UInt64(0)
        self.total_burned_cumulative.value = UInt64(0)

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    # ─── one-time ASA creation ─────────────────────────────────────────
    @arc4.abimethod
    def bootstrap_asset(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        url: arc4.String,
        metadata_note: arc4.String,
    ) -> arc4.UInt64:
        """Mint the PAIMINT ASA. Callable exactly once by the admin."""
        assert Txn.sender == self.admin.value, "admin only"
        assert self.created.value == UInt64(0), "already bootstrapped"

        result = itxn.AssetConfig(
            total=self.total_supply.value,
            decimals=self.decimals.value,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=url.native,
            note=metadata_note.native,
            manager=Global.current_application_address,
            reserve=Global.current_application_address,
            freeze=Global.current_application_address,
            clawback=Global.current_application_address,
            fee=0,
        ).submit()

        self.asset_id.value = result.created_asset.id
        self.created.value = UInt64(1)

        arc4.emit(
            PaimintBootstrapped(
                asset_id=arc4.UInt64(self.asset_id.value),
                total_supply=arc4.UInt64(self.total_supply.value),
            )
        )
        return arc4.UInt64(self.asset_id.value)

    # ─── charger management (admin only) ────────────────────────────────
    @arc4.abimethod
    def grant_charger(self, charger: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        assert charger.native not in self.chargers, "already a charger"

        self.chargers[charger.native] = ChargerRecord(
            granted_at=arc4.UInt64(Global.latest_timestamp),
            granted_by=arc4.Address(Txn.sender),
            total_rewarded=arc4.UInt64(0),
            total_burned=arc4.UInt64(0),
        )
        arc4.emit(ChargerGranted(charger=charger))

    @arc4.abimethod
    def revoke_charger(self, charger: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        assert charger.native in self.chargers, "not a charger"
        op.Box.delete(b"ch" + charger.native.bytes)
        arc4.emit(ChargerRevoked(charger=charger))

    @arc4.abimethod(readonly=True)
    def is_charger(self, addr: arc4.Address) -> arc4.Bool:
        if addr.native in self.chargers:
            return arc4.Bool(True)  # noqa: FBT003
        return arc4.Bool(False)  # noqa: FBT003

    @arc4.abimethod(readonly=True)
    def get_charger_stats(self, addr: arc4.Address) -> ChargerRecord:
        return self.chargers[addr.native]

    # ─── user-signed allowance system ───────────────────────────────────
    def _allowance_key(self, user: Account, charger: Account) -> Bytes:
        return op.sha256(user.bytes + charger.bytes)

    @arc4.abimethod
    def approve_charger(
        self, charger: arc4.Address, amount: arc4.UInt64
    ) -> None:
        """User grants a charger permission to burn up to `amount` PAIMINT.

        This is a user-signed transaction: the user (Txn.sender) explicitly
        consents to be charged up to `amount` by the specified charger.
        Amount accumulates on repeated approvals — call with amount=0 or
        use `revoke_charger_approval` to revoke.
        """
        assert charger.native in self.chargers, "target is not a registered charger"

        key = self._allowance_key(Txn.sender, charger.native)

        if key in self.allowances:
            existing = self.allowances[key].copy()
            existing.amount = arc4.UInt64(existing.amount.native + amount.native)
            existing.approved_at = arc4.UInt64(Global.latest_timestamp)
            self.allowances[key] = existing.copy()
            arc4.emit(
                AllowanceApproved(
                    user=arc4.Address(Txn.sender),
                    charger=charger,
                    amount=existing.amount,
                )
            )
        else:
            self.allowances[key] = AllowanceRecord(
                user=arc4.Address(Txn.sender),
                charger=charger,
                amount=amount,
                approved_at=arc4.UInt64(Global.latest_timestamp),
            )
            arc4.emit(
                AllowanceApproved(
                    user=arc4.Address(Txn.sender),
                    charger=charger,
                    amount=amount,
                )
            )

    @arc4.abimethod
    def revoke_charger_approval(self, charger: arc4.Address) -> None:
        """User revokes all allowance to the specified charger."""
        key = self._allowance_key(Txn.sender, charger.native)
        assert key in self.allowances, "no allowance to revoke"
        op.Box.delete(b"al" + key)
        arc4.emit(
            AllowanceRevoked(
                user=arc4.Address(Txn.sender),
                charger=charger,
            )
        )

    @arc4.abimethod(readonly=True)
    def allowance_of(
        self, user: arc4.Address, charger: arc4.Address
    ) -> arc4.UInt64:
        key = self._allowance_key(user.native, charger.native)
        if key not in self.allowances:
            return arc4.UInt64(0)
        return self.allowances[key].amount

    # ─── reward (charger-only, no allowance needed — minting is safe) ──
    @arc4.abimethod
    def reward(
        self,
        user: arc4.Address,
        amount: arc4.UInt64,
        reason: arc4.String,
    ) -> None:
        """Move PAIMINT from the reserve pool to a user (mint-by-clawback)."""
        assert Txn.sender in self.chargers, "caller is not a charger"
        assert self.created.value == UInt64(1), "asset not bootstrapped"
        assert amount.native > UInt64(0), "zero amount"
        assert (
            reason.native.bytes.length <= UInt64(MAX_REASON_LENGTH)
        ), "reason too long"

        # Verify reserve has enough and user is opted in.
        app_balance, app_exists = op.AssetHoldingGet.asset_balance(
            Global.current_application_address, self.asset_id.value
        )
        assert app_exists, "application not opted into its own asset"
        assert app_balance >= amount.native, "insufficient reserve pool"

        _, user_opted = op.AssetHoldingGet.asset_balance(
            user.native, self.asset_id.value
        )
        assert user_opted, "user not opted into PAIMINT"

        # Transfer from application (which holds the reserve) to the user.
        itxn.AssetTransfer(
            xfer_asset=self.asset_id.value,
            asset_sender=Global.current_application_address,
            asset_receiver=user.native,
            asset_amount=amount.native,
            fee=0,
        ).submit()

        stats = self.chargers[Txn.sender].copy()
        stats.total_rewarded = arc4.UInt64(stats.total_rewarded.native + amount.native)
        self.chargers[Txn.sender] = stats.copy()

        self.total_rewarded_cumulative.value = (
            self.total_rewarded_cumulative.value + amount.native
        )

        arc4.emit(
            PaimintRewarded(
                user=user,
                amount=amount,
                reason=reason,
                charger=arc4.Address(Txn.sender),
            )
        )

    # ─── burn (charger-only, consumes user allowance) ──────────────────
    @arc4.abimethod
    def burn_for_operation(
        self,
        user: arc4.Address,
        amount: arc4.UInt64,
        operation: arc4.String,
    ) -> None:
        """Move PAIMINT from user back to reserve (burn-by-clawback).

        Consumes the user's allowance for the calling charger. The user
        MUST have previously called approve_charger(charger, amount) with
        sufficient amount, or this call reverts.
        """
        assert Txn.sender in self.chargers, "caller is not a charger"
        assert self.created.value == UInt64(1), "asset not bootstrapped"
        assert amount.native > UInt64(0), "zero amount"
        assert (
            operation.native.bytes.length <= UInt64(MAX_REASON_LENGTH)
        ), "operation label too long"

        # Allowance check (CRITICAL — this is the authorization gate)
        allowance_key = self._allowance_key(user.native, Txn.sender)
        assert allowance_key in self.allowances, "no allowance from user"
        allowance = self.allowances[allowance_key].copy()
        assert allowance.amount.native >= amount.native, "allowance insufficient"

        user_bal, user_opted = op.AssetHoldingGet.asset_balance(
            user.native, self.asset_id.value
        )
        assert user_opted, "user not opted into PAIMINT"
        assert user_bal >= amount.native, "user balance insufficient"

        # Clawback from user → application (reserve pool).
        itxn.AssetTransfer(
            xfer_asset=self.asset_id.value,
            asset_sender=user.native,
            asset_receiver=Global.current_application_address,
            asset_amount=amount.native,
            fee=0,
        ).submit()

        # Decrement allowance
        allowance.amount = arc4.UInt64(allowance.amount.native - amount.native)
        self.allowances[allowance_key] = allowance.copy()

        stats = self.chargers[Txn.sender].copy()
        stats.total_burned = arc4.UInt64(stats.total_burned.native + amount.native)
        self.chargers[Txn.sender] = stats.copy()

        self.total_burned_cumulative.value = (
            self.total_burned_cumulative.value + amount.native
        )

        arc4.emit(
            PaimintBurned(
                user=user,
                amount=amount,
                operation=operation,
                charger=arc4.Address(Txn.sender),
            )
        )

    # ─── views ─────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def balance_of(self, user: arc4.Address) -> arc4.UInt64:
        bal, opted = op.AssetHoldingGet.asset_balance(
            user.native, self.asset_id.value
        )
        if not opted:
            return arc4.UInt64(0)
        return arc4.UInt64(bal)

    @arc4.abimethod(readonly=True)
    def reserve_balance(self) -> arc4.UInt64:
        bal, opted = op.AssetHoldingGet.asset_balance(
            Global.current_application_address, self.asset_id.value
        )
        if not opted:
            return arc4.UInt64(0)
        return arc4.UInt64(bal)

    @arc4.abimethod(readonly=True)
    def circulating_supply(self) -> arc4.UInt64:
        bal, opted = op.AssetHoldingGet.asset_balance(
            Global.current_application_address, self.asset_id.value
        )
        if not opted:
            return arc4.UInt64(0)
        return arc4.UInt64(self.total_supply.value - bal)

    @arc4.abimethod
    def withdraw_algos(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
