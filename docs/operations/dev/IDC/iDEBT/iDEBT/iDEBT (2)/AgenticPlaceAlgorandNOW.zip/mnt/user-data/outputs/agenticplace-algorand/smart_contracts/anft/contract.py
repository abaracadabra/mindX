# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# ANFT — Standard Immutable Agent NFT (Algorand ASA)   v1.3
#
# Mirrors AgenticPlace aNFT: immutable, no manager, no clawback, no freeze,
# no reserve. Identity is stamped permanently at mint time.
#
# AUDIT v1.3 fixes over v1.2:
#   - BoxMap.maybe() pattern instead of `in` operator (Puya-safe)
#   - String length via .bytes.length (String, not arc4.String)
#   - Explicit if/else for boolean returns
#   - Payment fee check requires exact minimum (stops silent overpayment)
#   - Added opt-in helper so app account can receive the new ASA
#   - Explicit asset_sender=current_application_address in claim AssetTransfer
#     for clarity (even though it's the default)

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
)

from smart_contracts.common.constants import (
    KIND_ANFT,
    MAX_ASSET_NAME,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
    MIN_MINT_PAYMENT,
)


# ─── ARC-28 events ────────────────────────────────────────────────────────
class AnftMinted(arc4.Struct):
    asset_id: arc4.UInt64
    minter: arc4.Address
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64


class AnftClaimed(arc4.Struct):
    asset_id: arc4.UInt64
    owner: arc4.Address


# ─── Box record ───────────────────────────────────────────────────────────
class IdentityRecord(arc4.Struct):
    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address
    pending_owner: arc4.Address
    claimed: arc4.Bool


class ANFT(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)
        self.identities = BoxMap(UInt64, IdentityRecord, key_prefix=b"id")

    # ─── lifecycle ─────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(MIN_MINT_PAYMENT)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    # ─── mint (step 1: create ASA) ─────────────────────────────────────
    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        # Payment validation
        assert (
            payment.receiver == Global.current_application_address
        ), "payment receiver must be application"
        assert payment.amount >= self.mint_fee.value, "payment below mint_fee"
        assert payment.sender == Txn.sender, "payment sender mismatch"
        assert payment.close_remainder_to == Global.zero_address, "close not allowed"

        # Identity validation
        assert name.native.bytes.length > UInt64(0), "empty name"
        assert name.native.bytes.length <= UInt64(MAX_ASSET_NAME), "name too long"
        assert (
            unit_name.native.bytes.length <= UInt64(MAX_UNIT_NAME)
        ), "unit_name too long"
        assert (
            metadata_note.native.bytes.length <= UInt64(MAX_NOTE_LENGTH)
        ), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"

        # Every address role is zeroed → permanently immutable ASA.
        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        new_asset_id = result.created_asset.id

        self.identities[new_asset_id] = IdentityRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
        )

        self.total_minted.value = self.total_minted.value + UInt64(1)

        arc4.emit(
            AnftMinted(
                asset_id=arc4.UInt64(new_asset_id),
                minter=arc4.Address(Txn.sender),
                agent_type=agent_type,
                minted_at=arc4.UInt64(Global.latest_timestamp),
            )
        )
        return arc4.UInt64(new_asset_id)

    # ─── mint (step 2: transfer to caller) ─────────────────────────────
    @arc4.abimethod
    def claim(self, asset: Asset) -> None:
        rec_exists = asset.id in self.identities
        assert rec_exists, "unknown asset"

        rec = self.identities[asset.id].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native, "not pending owner"

        itxn.AssetTransfer(
            xfer_asset=asset.id,
            asset_sender=Global.current_application_address,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.identities[asset.id] = rec.copy()

        arc4.emit(
            AnftClaimed(
                asset_id=arc4.UInt64(asset.id),
                owner=arc4.Address(Txn.sender),
            )
        )

    # ─── views ─────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_identity(self, asset_id: arc4.UInt64) -> IdentityRecord:
        return self.identities[asset_id.native]

    @arc4.abimethod(readonly=True)
    def kind(self) -> arc4.DynamicBytes:
        return arc4.DynamicBytes(Bytes(KIND_ANFT))

    # ─── treasury ──────────────────────────────────────────────────────
    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
