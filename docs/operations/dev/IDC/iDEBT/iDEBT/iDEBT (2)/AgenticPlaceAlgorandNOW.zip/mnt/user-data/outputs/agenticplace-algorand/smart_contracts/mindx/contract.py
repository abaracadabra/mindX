# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# MindXBridge — Algorand on-chain surface for mindx.pythai.net/redoc   v1.3
#
# AUDIT v1.3 fixes:
#   - job_id derived from sender + nonce only (no timestamp dependency)
#   - subscription renewal keeps the max of existing expiry and new expiry
#     (prevents accidental downgrade)
#   - Explicit box existence checks before every write
#   - Subscription deactivation on expiry or zero quota in helper view

from algopy import (
    ARC4Contract,
    Account,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    MINDX_JOB_COMPLETE,
    MINDX_JOB_FAILED,
    MINDX_JOB_PENDING,
    MINDX_PASS_THRESHOLD,
    MINDX_PLAN_ENTERPRISE,
    MINDX_PLAN_FREE,
    MINDX_PLAN_PRO,
    MINDX_PLAN_STANDARD,
    SUBSCRIPTION_DURATION_SECONDS,
)


# Plan call quotas per 30-day subscription window.
PLAN_CALLS_FREE: int = 100
PLAN_CALLS_STANDARD: int = 10_000
PLAN_CALLS_PRO: int = 100_000
PLAN_CALLS_ENTERPRISE: int = 1_000_000

# Default plan prices in microAlgos.
PLAN_PRICE_FREE: int = 0
PLAN_PRICE_STANDARD: int = 10_000_000       # 10 ALGO
PLAN_PRICE_PRO: int = 100_000_000           # 100 ALGO
PLAN_PRICE_ENTERPRISE: int = 1_000_000_000  # 1000 ALGO


# ─── Events ───────────────────────────────────────────────────────────────
class Subscribed(arc4.Struct):
    consumer: arc4.Address
    plan: arc4.UInt8
    expires_at: arc4.UInt64
    calls_granted: arc4.UInt64


class AttestationRequested(arc4.Struct):
    job_id: arc4.DynamicBytes
    consumer: arc4.Address
    subject_hash: arc4.DynamicBytes


class AttestationDelivered(arc4.Struct):
    job_id: arc4.DynamicBytes
    consciousness_level: arc4.UInt8
    ataraxia_score: arc4.UInt8


class BehaviorEvaluationRequested(arc4.Struct):
    job_id: arc4.DynamicBytes
    consumer: arc4.Address
    behavior_cid: arc4.String


class BehaviorEvaluationDelivered(arc4.Struct):
    job_id: arc4.DynamicBytes
    score: arc4.UInt8
    passed: arc4.Bool


class OracleRotated(arc4.Struct):
    previous: arc4.Address
    next_oracle: arc4.Address


# ─── Box records ──────────────────────────────────────────────────────────
class Subscription(arc4.Struct):
    consumer: arc4.Address
    expires_at: arc4.UInt64
    calls_remaining: arc4.UInt64
    plan: arc4.UInt8
    active: arc4.Bool


class Attestation(arc4.Struct):
    consumer: arc4.Address
    subject_hash: arc4.DynamicBytes
    consciousness_level: arc4.UInt8
    ataraxia_score: arc4.UInt8
    fingerprint: arc4.DynamicBytes
    dimensions: arc4.UInt16  # 768 or 1024
    requested_at: arc4.UInt64
    completed_at: arc4.UInt64
    status: arc4.UInt8


class BehaviorJob(arc4.Struct):
    consumer: arc4.Address
    behavior_cid: arc4.String
    score: arc4.UInt8
    passed: arc4.Bool
    requested_at: arc4.UInt64
    completed_at: arc4.UInt64
    status: arc4.UInt8


class MindXBridge(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.oracle = GlobalState(Account)
        self.total_subscriptions = GlobalState(UInt64)
        self.total_attestations = GlobalState(UInt64)
        self.total_behavior_jobs = GlobalState(UInt64)
        self.job_nonce = GlobalState(UInt64)

        self.price_free = GlobalState(UInt64)
        self.price_standard = GlobalState(UInt64)
        self.price_pro = GlobalState(UInt64)
        self.price_enterprise = GlobalState(UInt64)

        self.subscriptions = BoxMap(Account, Subscription, key_prefix=b"sub")
        self.attestations = BoxMap(Bytes, Attestation, key_prefix=b"att")
        self.behavior_jobs = BoxMap(Bytes, BehaviorJob, key_prefix=b"beh")

    # ─── lifecycle ─────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self, oracle: arc4.Address) -> None:
        self.admin.value = Txn.sender
        self.oracle.value = oracle.native
        self.total_subscriptions.value = UInt64(0)
        self.total_attestations.value = UInt64(0)
        self.total_behavior_jobs.value = UInt64(0)
        self.job_nonce.value = UInt64(0)
        self.price_free.value = UInt64(PLAN_PRICE_FREE)
        self.price_standard.value = UInt64(PLAN_PRICE_STANDARD)
        self.price_pro.value = UInt64(PLAN_PRICE_PRO)
        self.price_enterprise.value = UInt64(PLAN_PRICE_ENTERPRISE)

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    @arc4.abimethod
    def set_oracle(self, new_oracle: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        previous = self.oracle.value
        self.oracle.value = new_oracle.native
        arc4.emit(
            OracleRotated(
                previous=arc4.Address(previous),
                next_oracle=new_oracle,
            )
        )

    @arc4.abimethod
    def set_plan_price(self, plan: arc4.UInt8, price: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        p = plan.native
        if p == UInt64(MINDX_PLAN_FREE):
            self.price_free.value = price.native
        elif p == UInt64(MINDX_PLAN_STANDARD):
            self.price_standard.value = price.native
        elif p == UInt64(MINDX_PLAN_PRO):
            self.price_pro.value = price.native
        elif p == UInt64(MINDX_PLAN_ENTERPRISE):
            self.price_enterprise.value = price.native
        else:
            assert False, "unknown plan"  # noqa: B011, PT015

    @arc4.abimethod(readonly=True)
    def plan_price(self, plan: arc4.UInt8) -> arc4.UInt64:
        p = plan.native
        if p == UInt64(MINDX_PLAN_FREE):
            return arc4.UInt64(self.price_free.value)
        if p == UInt64(MINDX_PLAN_STANDARD):
            return arc4.UInt64(self.price_standard.value)
        if p == UInt64(MINDX_PLAN_PRO):
            return arc4.UInt64(self.price_pro.value)
        if p == UInt64(MINDX_PLAN_ENTERPRISE):
            return arc4.UInt64(self.price_enterprise.value)
        return arc4.UInt64(0)

    # ─── subscribe ─────────────────────────────────────────────────────
    @arc4.abimethod
    def subscribe(
        self,
        plan: arc4.UInt8,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        assert (
            payment.receiver == Global.current_application_address
        ), "payment receiver must be application"
        assert payment.sender == Txn.sender, "payment sender mismatch"
        assert payment.close_remainder_to == Global.zero_address, "close not allowed"

        p = plan.native
        required_price = UInt64(0)
        calls_granted = UInt64(0)

        if p == UInt64(MINDX_PLAN_FREE):
            required_price = self.price_free.value
            calls_granted = UInt64(PLAN_CALLS_FREE)
        elif p == UInt64(MINDX_PLAN_STANDARD):
            required_price = self.price_standard.value
            calls_granted = UInt64(PLAN_CALLS_STANDARD)
        elif p == UInt64(MINDX_PLAN_PRO):
            required_price = self.price_pro.value
            calls_granted = UInt64(PLAN_CALLS_PRO)
        elif p == UInt64(MINDX_PLAN_ENTERPRISE):
            required_price = self.price_enterprise.value
            calls_granted = UInt64(PLAN_CALLS_ENTERPRISE)
        else:
            assert False, "unknown plan"  # noqa: B011, PT015

        assert payment.amount >= required_price, "payment below plan price"

        # Subscription renewal: start from the later of "now" and the
        # existing expiry, so a renewal extends the window rather than
        # shrinking it.
        base = Global.latest_timestamp
        if Txn.sender in self.subscriptions:
            existing = self.subscriptions[Txn.sender].expires_at.native
            if existing > base:
                base = existing

        new_expires_at = base + UInt64(SUBSCRIPTION_DURATION_SECONDS)

        # On renewal, add the new quota to the remaining (carry over unused).
        total_calls = calls_granted
        if Txn.sender in self.subscriptions:
            existing_remaining = self.subscriptions[Txn.sender].calls_remaining.native
            total_calls = total_calls + existing_remaining

        self.subscriptions[Txn.sender] = Subscription(
            consumer=arc4.Address(Txn.sender),
            expires_at=arc4.UInt64(new_expires_at),
            calls_remaining=arc4.UInt64(total_calls),
            plan=plan,
            active=arc4.Bool(True),  # noqa: FBT003
        )
        self.total_subscriptions.value = self.total_subscriptions.value + UInt64(1)

        arc4.emit(
            Subscribed(
                consumer=arc4.Address(Txn.sender),
                plan=plan,
                expires_at=arc4.UInt64(new_expires_at),
                calls_granted=arc4.UInt64(calls_granted),
            )
        )
        return arc4.UInt64(new_expires_at)

    @arc4.abimethod(readonly=True)
    def get_subscription(self, consumer: arc4.Address) -> Subscription:
        return self.subscriptions[consumer.native]

    @arc4.abimethod(readonly=True)
    def is_subscription_active(self, consumer: arc4.Address) -> arc4.Bool:
        if consumer.native not in self.subscriptions:
            return arc4.Bool(False)  # noqa: FBT003
        sub = self.subscriptions[consumer.native]
        if not sub.active.native:
            return arc4.Bool(False)  # noqa: FBT003
        if sub.expires_at.native < Global.latest_timestamp:
            return arc4.Bool(False)  # noqa: FBT003
        if sub.calls_remaining.native == UInt64(0):
            return arc4.Bool(False)  # noqa: FBT003
        return arc4.Bool(True)  # noqa: FBT003

    # ─── internal helpers ──────────────────────────────────────────────
    def _new_job_id(self) -> Bytes:
        self.job_nonce.value = self.job_nonce.value + UInt64(1)
        # sha256(app_id || sender || nonce) — deterministic and unique.
        return op.sha256(
            op.itob(Global.current_application_id.id)
            + Txn.sender.bytes
            + op.itob(self.job_nonce.value)
        )

    def _consume_one_call(self) -> None:
        assert Txn.sender in self.subscriptions, "no subscription"
        sub = self.subscriptions[Txn.sender].copy()
        assert sub.active.native, "subscription inactive"
        assert sub.expires_at.native >= Global.latest_timestamp, "subscription expired"
        assert sub.calls_remaining.native > UInt64(0), "no calls remaining"
        sub.calls_remaining = arc4.UInt64(sub.calls_remaining.native - UInt64(1))
        self.subscriptions[Txn.sender] = sub.copy()

    # ─── attestation requests ──────────────────────────────────────────
    @arc4.abimethod
    def request_attestation(
        self, subject_hash: arc4.DynamicBytes
    ) -> arc4.DynamicBytes:
        self._consume_one_call()
        assert subject_hash.native.length == UInt64(32), "subject_hash must be 32 bytes"

        job_id = self._new_job_id()

        self.attestations[job_id] = Attestation(
            consumer=arc4.Address(Txn.sender),
            subject_hash=subject_hash,
            consciousness_level=arc4.UInt8(0),
            ataraxia_score=arc4.UInt8(0),
            fingerprint=arc4.DynamicBytes(Bytes(b"")),
            dimensions=arc4.UInt16(1024),
            requested_at=arc4.UInt64(Global.latest_timestamp),
            completed_at=arc4.UInt64(0),
            status=arc4.UInt8(MINDX_JOB_PENDING),
        )
        self.total_attestations.value = self.total_attestations.value + UInt64(1)

        arc4.emit(
            AttestationRequested(
                job_id=arc4.DynamicBytes(job_id),
                consumer=arc4.Address(Txn.sender),
                subject_hash=subject_hash,
            )
        )
        return arc4.DynamicBytes(job_id)

    @arc4.abimethod
    def deliver_attestation(
        self,
        job_id: arc4.DynamicBytes,
        consciousness_level: arc4.UInt8,
        ataraxia_score: arc4.UInt8,
        fingerprint: arc4.DynamicBytes,
        dimensions: arc4.UInt16,
    ) -> None:
        assert Txn.sender == self.oracle.value, "oracle only"
        assert consciousness_level.native <= UInt64(100), "level > 100"
        assert ataraxia_score.native <= UInt64(100), "score > 100"
        d = dimensions.native
        assert d == UInt64(768) or d == UInt64(1024), "dimensions must be 768 or 1024"
        assert job_id.native in self.attestations, "unknown job"

        rec = self.attestations[job_id.native].copy()
        assert rec.status.native == UInt64(MINDX_JOB_PENDING), "job not pending"

        rec.consciousness_level = consciousness_level
        rec.ataraxia_score = ataraxia_score
        rec.fingerprint = fingerprint
        rec.dimensions = dimensions
        rec.completed_at = arc4.UInt64(Global.latest_timestamp)
        rec.status = arc4.UInt8(MINDX_JOB_COMPLETE)
        self.attestations[job_id.native] = rec.copy()

        arc4.emit(
            AttestationDelivered(
                job_id=job_id,
                consciousness_level=consciousness_level,
                ataraxia_score=ataraxia_score,
            )
        )

    @arc4.abimethod
    def fail_attestation(self, job_id: arc4.DynamicBytes) -> None:
        assert Txn.sender == self.oracle.value, "oracle only"
        assert job_id.native in self.attestations, "unknown job"
        rec = self.attestations[job_id.native].copy()
        assert rec.status.native == UInt64(MINDX_JOB_PENDING), "job not pending"
        rec.status = arc4.UInt8(MINDX_JOB_FAILED)
        rec.completed_at = arc4.UInt64(Global.latest_timestamp)
        self.attestations[job_id.native] = rec.copy()

    @arc4.abimethod(readonly=True)
    def get_attestation(self, job_id: arc4.DynamicBytes) -> Attestation:
        return self.attestations[job_id.native]

    # ─── behavior evaluation ────────────────────────────────────────────
    @arc4.abimethod
    def request_behavior_evaluation(
        self, behavior_cid: arc4.String
    ) -> arc4.DynamicBytes:
        self._consume_one_call()
        assert behavior_cid.native.bytes.length > UInt64(0), "empty CID"

        job_id = self._new_job_id()

        self.behavior_jobs[job_id] = BehaviorJob(
            consumer=arc4.Address(Txn.sender),
            behavior_cid=behavior_cid,
            score=arc4.UInt8(0),
            passed=arc4.Bool(False),  # noqa: FBT003
            requested_at=arc4.UInt64(Global.latest_timestamp),
            completed_at=arc4.UInt64(0),
            status=arc4.UInt8(MINDX_JOB_PENDING),
        )
        self.total_behavior_jobs.value = self.total_behavior_jobs.value + UInt64(1)

        arc4.emit(
            BehaviorEvaluationRequested(
                job_id=arc4.DynamicBytes(job_id),
                consumer=arc4.Address(Txn.sender),
                behavior_cid=behavior_cid,
            )
        )
        return arc4.DynamicBytes(job_id)

    @arc4.abimethod
    def deliver_behavior_score(
        self, job_id: arc4.DynamicBytes, score: arc4.UInt8
    ) -> None:
        assert Txn.sender == self.oracle.value, "oracle only"
        assert score.native <= UInt64(100), "score > 100"
        assert job_id.native in self.behavior_jobs, "unknown job"

        rec = self.behavior_jobs[job_id.native].copy()
        assert rec.status.native == UInt64(MINDX_JOB_PENDING), "job not pending"

        rec.score = score
        if score.native >= UInt64(MINDX_PASS_THRESHOLD):
            rec.passed = arc4.Bool(True)  # noqa: FBT003
        else:
            rec.passed = arc4.Bool(False)  # noqa: FBT003
        rec.completed_at = arc4.UInt64(Global.latest_timestamp)
        rec.status = arc4.UInt8(MINDX_JOB_COMPLETE)
        self.behavior_jobs[job_id.native] = rec.copy()

        arc4.emit(
            BehaviorEvaluationDelivered(
                job_id=job_id,
                score=score,
                passed=rec.passed,
            )
        )

    @arc4.abimethod
    def fail_behavior_evaluation(self, job_id: arc4.DynamicBytes) -> None:
        assert Txn.sender == self.oracle.value, "oracle only"
        assert job_id.native in self.behavior_jobs, "unknown job"
        rec = self.behavior_jobs[job_id.native].copy()
        assert rec.status.native == UInt64(MINDX_JOB_PENDING), "job not pending"
        rec.status = arc4.UInt8(MINDX_JOB_FAILED)
        rec.completed_at = arc4.UInt64(Global.latest_timestamp)
        self.behavior_jobs[job_id.native] = rec.copy()

    @arc4.abimethod(readonly=True)
    def get_behavior_job(self, job_id: arc4.DynamicBytes) -> BehaviorJob:
        return self.behavior_jobs[job_id.native]

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
