# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# Common constants for the AgenticPlace Algorand stack (v1.3).

# NFT kind discriminators (4 bytes each).
KIND_ANFT: bytes = b"aNFT"
KIND_DNFT: bytes = b"dNFT"
KIND_INFT: bytes = b"iNFT"
KIND_THOT: bytes = b"THOT"

# Mint economics.
# AgenticPlace register form lists 0.001 ALGO, but that's the *protocol
# cut only*. The user also pays the inner txn fee (~0.001 ALGO) and the
# application must hold enough MBR to cover the new ASA (0.1 ALGO) and
# the IdentityRecord box (variable, budget 0.1 ALGO). Total realistic
# mint payment floor is 0.201 ALGO.
PROTOCOL_MINT_FEE_MICROALGOS: int = 1_000           # 0.001 ALGO
ASSET_MBR_MICROALGOS: int = 100_000                 # 0.1 ALGO (fixed by Algorand)
BOX_MBR_BUFFER_MICROALGOS: int = 100_000            # 0.1 ALGO buffer per mint
MIN_MINT_PAYMENT: int = (
    PROTOCOL_MINT_FEE_MICROALGOS
    + ASSET_MBR_MICROALGOS
    + BOX_MBR_BUFFER_MICROALGOS
)  # 201_000 microAlgos

# THOT supported embedding dimensions. Register form lists 64/384/512/768;
# 1024 added for high-fidelity embedders and mindX 768 → 1024 expansion.
THOT_DIM_64: int = 64
THOT_DIM_384: int = 384
THOT_DIM_512: int = 512
THOT_DIM_768: int = 768
THOT_DIM_1024: int = 1024

# Trust model bitmap.
TRUST_REPUTATION: int = 1 << 0
TRUST_CRYPTO_ECONOMIC: int = 1 << 1
TRUST_TEE: int = 1 << 2  # upcoming
TRUST_ZKML: int = 1 << 3  # upcoming
TRUST_BITMAP_MAX: int = 0x0F

# Agent type enum (matches AgenticPlace register form dropdown).
AGENT_TYPE_NONE: int = 0
AGENT_TYPE_COGNITIVE_AUGMENTATION: int = 1
AGENT_TYPE_CREATIVE_INTELLIGENCE: int = 2
AGENT_TYPE_ANALYTICAL_PROCESSING: int = 3
AGENT_TYPE_SPECIALIZED_DOMAIN: int = 4
AGENT_TYPE_AGENT_ORCHESTRATOR: int = 5

# Field length limits.
MAX_NOTE_LENGTH: int = 1000       # Algorand txn note cap is 1024 bytes
MAX_UNIT_NAME: int = 8             # ARC-69 / ASA spec
MAX_ASSET_NAME: int = 32           # ASA spec
MAX_INTELLIGENCE_LEVEL: int = 100
MAX_REASON_LENGTH: int = 64        # short labels for PAIMINT reward/burn
MAX_SKILLS_LENGTH: int = 512       # comma-separated skills list

# mindX subscription plan enum.
MINDX_PLAN_FREE: int = 0
MINDX_PLAN_STANDARD: int = 1
MINDX_PLAN_PRO: int = 2
MINDX_PLAN_ENTERPRISE: int = 3

# mindX job status enum.
MINDX_JOB_PENDING: int = 0
MINDX_JOB_COMPLETE: int = 1
MINDX_JOB_FAILED: int = 2

# mindX behavior pass threshold (0..100).
MINDX_PASS_THRESHOLD: int = 70

# Subscription duration in seconds (30 days).
SUBSCRIPTION_DURATION_SECONDS: int = 30 * 24 * 60 * 60

# Signature length (ed25519).
ED25519_SIGNATURE_LENGTH: int = 64
ED25519_PUBKEY_LENGTH: int = 32
