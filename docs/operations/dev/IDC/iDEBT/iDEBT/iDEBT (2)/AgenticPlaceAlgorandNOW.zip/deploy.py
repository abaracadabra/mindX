# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# AlgoKit deploy script for the AgenticPlace Algorand stack (v1.3).
#
# Deploys all eight contracts in dependency order:
#
#     1. ANFT
#     2. DNFT
#     3. INFT
#     4. THOT
#     5. MindXBridge   (oracle = deployer by default)
#     6. BankonPaimint (admin = deployer; bootstraps PAIMINT ASA)
#     7. X402Verifier  (operator = deployer by default)
#     8. AgenticPlaceRegistry  (wired to mindX)
#
# After deploys it:
#   - Funds each application account with 0.3 ALGO for MBR
#   - Bootstraps the PAIMINT ASA via paimint.bootstrap_asset(...)
#   - Calls registry.set_mindx(mindx_app_id, oracle_address)
#   - Writes deploy/deployment.json with all app ids, addresses, and the
#     PAIMINT ASA id
#
# Usage:
#
#   # Compile each contract first
#   algokit compile py smart_contracts/anft/contract.py
#   ... (one per contract)
#
#   # LocalNet
#   algokit localnet start
#   NETWORK=localnet python deploy/deploy.py
#
#   # TestNet
#   NETWORK=testnet DEPLOYER_MNEMONIC="..." python deploy/deploy.py
#
#   # MainNet
#   NETWORK=mainnet DEPLOYER_MNEMONIC="..." python deploy/deploy.py

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

from algokit_utils import (
    AlgorandClient,
    PaymentParams,
    SigningAccount,
)
from algosdk import mnemonic
from algosdk.account import address_from_private_key

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ARTIFACTS_DIR = PROJECT_ROOT / "smart_contracts" / "artifacts"

# (folder, class_name) — order matters: registry depends on mindx wiring,
# paimint bootstraps an ASA after deploy.
CONTRACTS: list[tuple[str, str]] = [
    ("anft", "ANFT"),
    ("dnft", "DNFT"),
    ("inft", "INFT"),
    ("thot", "THOT"),
    ("mindx", "MindXBridge"),
    ("paimint", "BankonPaimint"),
    ("x402", "X402Verifier"),
    ("registry", "AgenticPlaceRegistry"),
]


def _load_arc56(name: str) -> dict[str, Any]:
    """Load the ARC-56 spec emitted by `algokit compile py`."""
    candidates = [
        ARTIFACTS_DIR / name / f"{name.capitalize()}.arc56.json",
        ARTIFACTS_DIR / name / f"{name}.arc56.json",
        PROJECT_ROOT / "smart_contracts" / name / "artifacts" / f"{name}.arc56.json",
    ]
    for path in candidates:
        if path.exists():
            with path.open("r") as fh:
                return json.load(fh)
    raise FileNotFoundError(
        f"No ARC-56 artifact found for {name}. Tried:\n  "
        + "\n  ".join(str(c) for c in candidates)
        + f"\n\nRun: algokit compile py smart_contracts/{name}/contract.py"
    )


def _make_client() -> AlgorandClient:
    network = os.environ.get("NETWORK", "localnet").lower()
    if network == "localnet":
        return AlgorandClient.default_localnet()
    if network == "testnet":
        return AlgorandClient.testnet()
    if network == "mainnet":
        return AlgorandClient.mainnet()
    raise ValueError(f"Unknown NETWORK: {network!r}")


def _load_deployer(algorand: AlgorandClient) -> SigningAccount:
    mn = os.environ.get("DEPLOYER_MNEMONIC")
    if mn:
        sk = mnemonic.to_private_key(mn)
        addr = address_from_private_key(sk)
        return SigningAccount(private_key=sk, address=addr)

    # Fall back to a freshly funded LocalNet dispenser.
    print("[localnet] no DEPLOYER_MNEMONIC set; using LocalNet dispenser")
    return algorand.account.localnet_dispenser_v2()


def _fund_app(
    algorand: AlgorandClient,
    deployer: SigningAccount,
    app_address: str,
    amount_microalgos: int = 300_000,
) -> None:
    """Top up the application account so it can hold MBR for inner txns."""
    algorand.send.payment(
        PaymentParams(
            sender=deployer.address,
            receiver=app_address,
            amount=amount_microalgos,
            note=b"agenticplace bootstrap",
            signer=deployer,
        )
    )


def deploy_one(
    algorand: AlgorandClient,
    deployer: SigningAccount,
    contract_name: str,
    class_name: str,
    create_args: list[Any],
) -> dict[str, Any]:
    print(f"[deploy] {class_name} ({contract_name}) ...")

    spec = _load_arc56(contract_name)
    factory = algorand.client.get_app_factory(
        app_spec=json.dumps(spec),
        default_sender=deployer.address,
        default_signer=deployer,
    )

    create_result = factory.send.create(
        {
            "method": "create",
            "args": create_args,
            "sender": deployer.address,
            "signer": deployer,
        }
    )

    app_id = create_result.app_id
    app_address = create_result.app_address
    _fund_app(algorand, deployer, app_address)

    print(f"           -> app_id  = {app_id}")
    print(f"           -> app_addr = {app_address}")
    return {"name": class_name, "app_id": app_id, "app_address": app_address}


def main() -> int:
    algorand = _make_client()
    deployer = _load_deployer(algorand)

    print(f"[network ] {os.environ.get('NETWORK', 'localnet')}")
    print(f"[deployer] {deployer.address}")
    print()

    deployed: list[dict[str, Any]] = []
    deployed_by_name: dict[str, dict[str, Any]] = {}

    for contract_name, class_name in CONTRACTS:
        # Build create-method args based on contract.
        if contract_name == "mindx":
            args: list[Any] = [deployer.address]  # oracle
        elif contract_name == "x402":
            args = [deployer.address]  # operator
        else:
            args = []

        result = deploy_one(algorand, deployer, contract_name, class_name, args)
        deployed.append(result)
        deployed_by_name[contract_name] = result

    # ─── post-deploy wiring ───────────────────────────────────────────────
    print()
    print("=" * 70)
    print("Wiring contracts together")
    print("=" * 70)

    # Wire registry → mindX (set both app id and oracle address)
    if "registry" in deployed_by_name and "mindx" in deployed_by_name:
        registry_id = deployed_by_name["registry"]["app_id"]
        mindx_id = deployed_by_name["mindx"]["app_id"]
        print(
            f"[wiring ] registry({registry_id}).set_mindx("
            f"app={mindx_id}, oracle={deployer.address})"
        )
        algorand.send.app_call_method_call(
            {
                "app_id": registry_id,
                "method": "set_mindx",
                "args": [mindx_id, deployer.address],
                "sender": deployer.address,
                "signer": deployer,
            }
        )

    # Bootstrap PAIMINT ASA
    if "paimint" in deployed_by_name:
        paimint_id = deployed_by_name["paimint"]["app_id"]
        print(f"[wiring ] paimint({paimint_id}).bootstrap_asset(...)")
        try:
            bootstrap = algorand.send.app_call_method_call(
                {
                    "app_id": paimint_id,
                    "method": "bootstrap_asset",
                    "args": [
                        "BANKON PAIMINT",
                        "PAIMINT",
                        "https://bankon.pythai.net",
                        '{"standard":"arc3","name":"BANKON PAIMINT","decimals":6}',
                    ],
                    "sender": deployer.address,
                    "signer": deployer,
                }
            )
            asset_id = bootstrap.returns[-1].return_value
            deployed_by_name["paimint"]["asset_id"] = int(asset_id)
            print(f"           -> PAIMINT ASA id = {asset_id}")
        except Exception as e:  # noqa: BLE001
            print(f"           -> bootstrap skipped/failed: {e}")

    # ─── summary ─────────────────────────────────────────────────────────
    print()
    print("=" * 70)
    print("AgenticPlace Algorand stack deployed:")
    print("=" * 70)
    for d in deployed:
        extra = ""
        if "asset_id" in d:
            extra = f"  asset_id={d['asset_id']}"
        print(
            f"  {d['name']:<22} app_id={d['app_id']:<10} addr={d['app_address']}{extra}"
        )

    out = PROJECT_ROOT / "deploy" / "deployment.json"
    with out.open("w") as fh:
        json.dump(
            {
                "network": os.environ.get("NETWORK", "localnet"),
                "deployer": deployer.address,
                "apps": deployed,
            },
            fh,
            indent=2,
        )
    print(f"\nWrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
