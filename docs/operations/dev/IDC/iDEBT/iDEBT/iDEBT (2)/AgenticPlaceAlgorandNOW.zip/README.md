# AgenticPlace Algorand Contracts (v1.3)

Eight algopy smart contracts plus a Python frontend helper. Implements
the four NFT types from the [AgenticPlace register
flow](https://agenticplace.pythai.net/register), the mindX-as-a-service
bridge, the BANKON PAIMINT token, the parsec / x402 receipt verifier,
and the AgenticPlace registry — all on Algorand.

```
© 2026 BANKON • Professor Codephreak
agenticplace.pythai.net • mindx.pythai.net • bankon.pythai.net
```

---

## Contract map

| Contract | Role | Mutability | Notes |
| --- | --- | --- | --- |
| `ANFT` | Immutable agent NFT (aNFT) | Frozen at mint | All ASA roles zeroed |
| `DNFT` | Dynamic agent NFT (dNFT) | Holder updates note | `freeze()` → permanent |
| `INFT` | Intelligent agent NFT (iNFT) | Holder + directive | `freeze()` severs directive in same call |
| `THOT` | Knowledge tensor NFT | Frozen at mint | CID-unique • dims **64 / 384 / 512 / 768 / 1024** |
| `MindXBridge` | mindx.pythai.net surface | Oracle-delivered | Subscriptions, attestations, behavior evals |
| `BankonPaimint` | PAIMINT token | Reward + allowance burn | 1B supply, 6 decimals, recirculating |
| `X402Verifier` | parsec receipt verifier | Replay-protected | ed25519 + box-map deduplication |
| `AgenticPlaceRegistry` | Agent directory | Owner-updatable | Binds any ASA to MCP/A2A/trust/skills |

---

## What changed in v1.3

| Area | v1.2 | v1.3 |
| --- | --- | --- |
| **PAIMINT burn authorization** | Any charger could burn any user's balance | **Per-user allowance system** (`approve_charger` / `revoke_charger_approval`) |
| **Registry ↔ mindX integration** | Inner ApplicationCall + fragile byte parsing of return log | **Oracle-push pattern** — mindX oracle calls `registry.deliver_mindx_result()` directly |
| `del self.chargers[k]` | Used Python `del` | **`op.Box.delete()`** explicitly |
| Box existence checks | Inconsistent | **Every read/write preceded by `in` check** |
| Subscription renewal | Replaced expiry / quota | **Carries unused calls forward + extends from `max(now, current_expiry)`** |
| Length validations | Some missing | **All sigs/hashes/CIDs explicitly bounded** |
| Job ID derivation | sender + nonce + timestamp | **`sha256(app_id || sender || nonce)`** — deterministic |
| MintResult close-remainder | Unchecked | **`close_remainder_to == zero_address` asserted** on every payment |
| Frontend helper | Inline tuples | **Typed `X402Receipt` dataclass** + `x402_compute_digest()` helper |

---

## ASA mint semantics per NFT type

### ANFT — immutable

```
manager   = ZeroAddress    ← every role zeroed = permanently immutable
reserve   = ZeroAddress
freeze    = ZeroAddress
clawback  = ZeroAddress
total     = 1, decimals = 0
note      = ARC-69 JSON
```

### DNFT — dynamic

```
manager   = ApplicationAddress      ← enables future reconfigs
reserve   = ZeroAddress
freeze    = ZeroAddress
clawback  = ZeroAddress
```

`update_note()` issues an inner asset config keeping `manager = ApplicationAddress` and replacing the note. `freeze()` issues a final reconfig with `manager = ZeroAddress`, permanently locking the asset.

> ⚠️ **Algorand quirk** — any address role omitted from an asset config defaults to zero, which permanently revokes that role. The contract always re-supplies all four roles explicitly.

### INFT — intelligent

Same ASA shape as DNFT, plus two privilege tracks:

| Action | Caller | Reason |
| --- | --- | --- |
| `mint`, `claim`, `update_identity`, `set_directive`, `freeze` | Asset holder | Human controls the asset |
| `self_update(level, autonomous, behavior_cid, new_note)` | Directive only | Agent evolves itself |

`freeze()` clears manager AND directive in one call. After freeze the iNFT cannot self-mutate even if the directive key is later compromised.

### THOT — knowledge tensor

Same ASA shape as ANFT (every role zeroed), plus:

1. **Dimension whitelist:** `{64, 384, 512, 768, 1024}`. Form lists the first four; **1024** added for high-fidelity embedders.
2. **CID uniqueness:** box map keyed by `sha256(data_cid)` indexes every minted THOT. Re-minting the same CID reverts.

---

## BANKON PAIMINT — with allowance system (v1.3)

The PAIMINT token as an Algorand ASA. Architecture:

```
total_supply  = 1,000,000,000 × 10^6 base units  (1B tokens, 6 decimals)
manager       = application
reserve       = application   ← holds unminted pool
freeze        = application   ← reserved for future compliance
clawback      = application   ← used for reward/burn ops
```

### Three-actor model

- **Admin** — grants/revokes CHARGER role to other contracts
- **Charger** — typically another application; calls `reward()` and `burn_for_operation()`
- **User** — holds standard ASA balance; **must approve a charger before they can be burned**

### Allowance-protected burn flow

```python
# 1. Admin grants charger role (one-time per charger contract)
paimint.grant_charger(thot_publisher_app_address)

# 2. User opts into PAIMINT
paimint.opt_in()

# 3. Charger rewards the user (no allowance needed — minting is safe)
paimint.reward(user, amount=10_000_000, reason="thot.quality")

# 4. User APPROVES the charger to burn up to N PAIMINT (CRITICAL)
paimint.approve_charger(thot_publisher_app_address, amount=100_000_000)

# 5. Charger burns the user's PAIMINT, decrementing the allowance
paimint.burn_for_operation(user, amount=50_000_000, operation="thot.publish")
# → allowance is now 50_000_000

# 6. User can revoke at any time
paimint.revoke_charger_approval(thot_publisher_app_address)
```

Without step 4, the burn in step 5 reverts with `"no allowance from user"`. This is a critical security improvement over v1.2, where a compromised charger could drain every user's balance.

### Trust model (post-v1.3)

| Attack | Defense |
| --- | --- |
| Compromised charger drains all users | **Allowance system** — charger can only burn what users have explicitly approved |
| User accidentally over-approves | **`revoke_charger_approval` + `allowance_of` view** for monitoring |
| Admin key compromised | Admin can grant chargers, but cannot burn directly. Chargers still need user approval. |
| User receives unwanted PAIMINT | None — minting (`reward`) is always safe |

---

## X402Verifier (parsec receipts)

Validates that a payer signed an authorization for a specific Algorand payment, with replay protection.

### Receipt structure

```python
Receipt(
    payer=<32-byte Algorand address>,
    algo_asset=0,               # 0 = ALGO, else ASA id
    amount=1_000_000,           # microAlgos / micro-ASA
    algo_round=<round of payment>,
    algo_tx_id=<32-byte payment txid>,
    expires_at=<unix ts>,
    purpose=<sha256("thot.publish")>,  # exactly 32 bytes
    nonce=<unique value>,
)
```

### Verification checks

1. Caller is an authorized consumer contract
2. `expected_payer` matches `receipt.payer`
3. Receipt not expired
4. Payment round reached
5. `algo_tx_id` is exactly 32 bytes
6. `purpose` is exactly 32 bytes
7. Signature is exactly 64 bytes (ed25519)
8. `ed25519_verify_bare(sha256(receipt.bytes), sig, payer)` passes
9. Receipt hash not in `used_receipts` (replay protection)

### Frontend usage

```python
# Build receipt and compute digest
receipt = client.x402_build_receipt(
    payer_address=payer.address,
    amount_microalgos=1_000_000,
    algo_round=current_round,
    algo_tx_id=payment_txid_bytes,
    expires_at=int(time.time()) + 3600,
    purpose="thot.publish",
    nonce=secrets.randbits(63),
)
digest = AgenticPlaceClient.x402_compute_digest(receipt)

# Payer signs off-chain (raw ed25519, no Algorand prefix)
sk = nacl.signing.SigningKey(payer_private_key)
signature = sk.sign(digest).signature

# Consumer contract calls verify
receipt_hash = client.x402_verify_and_consume(
    receipt=receipt,
    payer_signature=signature,
    expected_payer=payer.address,
)
```

---

## MindXBridge — service surface

Exposes `mindx.pythai.net/redoc` as an on-chain Algorand contract.

### Job lifecycle

```
1. Consumer: subscribe(plan, payment) → grants 30-day call quota
   - Renewal carries unused calls forward
2. Consumer: request_attestation(subject_hash) | request_behavior_evaluation(cid)
   → returns 32-byte job_id (deterministic: sha256(app_id || sender || nonce))
3. Off-chain mindX backend processes
4. Oracle: deliver_attestation(...) | deliver_behavior_score(job_id, score)
5. Anyone: get_attestation(job_id) | get_behavior_job(job_id)
```

### Plan pricing (admin-mutable)

| Plan | Default price | Calls per 30 days |
| --- | --- | --- |
| Free | 0 ALGO | 100 |
| Standard | 10 ALGO | 10,000 |
| Pro | 100 ALGO | 100,000 |
| Enterprise | 1,000 ALGO | 1,000,000 |

---

## AgenticPlaceRegistry → MindXBridge integration (v1.3 oracle-push)

The registry's mindX integration was refactored from "registry calls mindX, parses return bytes" (fragile) to **"mindX oracle pushes results to the registry"** (matching the pattern mindX itself uses for attestation delivery).

### Setup

```python
# Admin configures the registry's mindX backend (one-time)
registry.set_mindx(app_id=mindx_app_id, oracle=mindx_oracle_address)
```

### Verification flow

```
1. Agent owner registers the agent on the registry
2. Off-chain mindX backend evaluates the agent (no on-chain calls)
3. mindX oracle calls registry.deliver_mindx_result(nft_app_id, asset_id, score, passed)
4. Registry stamps the binding with mindx_score, mindx_verified, mindx_verified_at
5. Off-chain readers (8004scan, the AgenticPlace frontend) filter by mindx_verified
```

### Trust model

The mindX oracle can **only write scores**. It cannot:
- Register new bindings
- Deactivate existing bindings
- Alter MCP/A2A endpoints, trust models, skills, or any non-mindX field

If the oracle is compromised, the worst case is false mindX scores — NFT ownership and protocol endpoints are safe.

---

## Frontend helper

```python
from frontend_helper.agentic_client import (
    AgenticPlaceClient,
    AgentType,
    MindXPlan,
    TrustModel,
)

client = AgenticPlaceClient.testnet(
    signer=my_signing_account,
    anft_app_id=12345,
    dnft_app_id=12346,
    inft_app_id=12347,
    thot_app_id=12348,
    registry_app_id=12349,
    mindx_app_id=12350,
    paimint_app_id=12351,
    x402_app_id=12352,
)

# Mint a 1024-dim THOT (mint + opt-in + claim in one call)
mint = client.mint_thot(
    name="deltaverse-rag-1024",
    unit_name="DVR1024",
    agent_type=AgentType.ANALYTICAL_PROCESSING,
    description="Retrieval embeddings for the DeltaVerse corpus",
    data_cid="QmDeltaVerseRagBig",
    dimensions=1024,
)

# Register on AgenticPlace
client.register_agent(
    nft_app_id=client.thot_app_id,
    asset_id=mint.asset_id,
    mcp_endpoint="https://mcp.example/dvr1024",
    a2a_endpoint="https://a2a.example/dvr1024",
    trust_models=TrustModel.REPUTATION | TrustModel.CRYPTO_ECONOMIC,
    skills=["retrieval", "embedding", "rag"],
)

# PAIMINT with allowance flow
client.paimint_opt_in(asset_id=paimint_asset_id)
client.paimint_approve_charger(charger_address=publisher_addr, amount=100_000_000)
# (publisher contract calls reward + burn_for_operation)

# mindX subscription + behavior eval
client.mindx_subscribe(plan=MindXPlan.STANDARD, payment_microalgos=10_000_000)
job_id = client.mindx_request_behavior_evaluation("QmBehaviorCID")
```

### Helper method index

| Method | Purpose |
| --- | --- |
| `mint_anft / mint_dnft / mint_inft / mint_thot` | 3-step mint per type |
| `update_dnft_note` | Push new ARC-69 note to dNFT |
| `inft_self_update` | Directive-side self-update |
| `register_agent` | Register on AgenticPlaceRegistry |
| `mindx_subscribe` | Buy/renew mindX subscription |
| `mindx_request_attestation` | Open consciousness attestation job |
| `mindx_request_behavior_evaluation` | Open behavior eval job |
| `mindx_deliver_attestation` *(oracle)* | Deliver attestation result |
| `mindx_deliver_behavior_score` *(oracle)* | Deliver behavior score |
| `registry_deliver_mindx_result` *(oracle)* | Push verification to registry |
| `paimint_opt_in / balance_of` | User-side basics |
| `paimint_reward / burn_for_operation` | Charger-side operations |
| `paimint_approve_charger / revoke_charger_approval / allowance_of` | User-side allowance management |
| `x402_build_receipt / compute_digest` | Build + hash receipts off-chain |
| `x402_verify_and_consume` | Consumer-side verification |

---

## Project layout

```
agenticplace-algorand/
├── pyproject.toml
├── .algokit.toml
├── README.md
├── smart_contracts/
│   ├── common/constants.py
│   ├── anft/contract.py               ANFT — immutable
│   ├── dnft/contract.py               DNFT — manager-updatable + freeze
│   ├── inft/contract.py               INFT — directive autonomy
│   ├── thot/contract.py               THOT — knowledge tensor (1024 added)
│   ├── mindx/contract.py              MindXBridge
│   ├── paimint/contract.py            BankonPaimint (allowance system)
│   ├── x402/contract.py               X402Verifier
│   └── registry/contract.py           AgenticPlaceRegistry (oracle-push)
├── frontend_helper/agentic_client.py  Python wrapper
├── tests/test_contracts.py            Invariant tests
└── deploy/deploy.py                   AlgoKit deploy for all 8
```

---

## Setup

```bash
pip install algokit
cd agenticplace-algorand
poetry install

# Compile every contract to TEAL
algokit compile py smart_contracts/anft/contract.py
algokit compile py smart_contracts/dnft/contract.py
algokit compile py smart_contracts/inft/contract.py
algokit compile py smart_contracts/thot/contract.py
algokit compile py smart_contracts/mindx/contract.py
algokit compile py smart_contracts/paimint/contract.py
algokit compile py smart_contracts/x402/contract.py
algokit compile py smart_contracts/registry/contract.py

pytest tests/ -vv
```

---

## Deployment

```bash
# LocalNet
algokit localnet start
NETWORK=localnet python deploy/deploy.py

# TestNet
export NETWORK=testnet DEPLOYER_MNEMONIC="word1 word2 ... word25"
python deploy/deploy.py

# MainNet
export NETWORK=mainnet DEPLOYER_MNEMONIC="word1 word2 ... word25"
python deploy/deploy.py
```

The deploy script:
1. Deploys ANFT → DNFT → INFT → THOT → MindXBridge → BankonPaimint → X402Verifier → AgenticPlaceRegistry
2. Funds each app account with 0.3 ALGO for MBR
3. Wires the registry to the mindX bridge via `set_mindx(app_id, oracle)`
4. Bootstraps the PAIMINT ASA via `bootstrap_asset(...)`
5. Writes `deploy/deployment.json` with all 8 app ids, app addresses, and the PAIMINT ASA id

---

## Mapping to the AgenticPlace register form

| Form section | Implementation |
| --- | --- |
| Step 1: Agent Details | ARC-69 note + IdentityRecord box |
| Step 2: NFT Type (aNFT / dNFT / iNFT / THOT) | One contract per type |
| Step 3: Endpoints (MCP, A2A, directive, website) | AgenticPlaceRegistry binding |
| Step 4: Mint (0.001 ALGO) | `mint_fee` state (default 0.201 ALGO incl MBR) |
| Intelligence Config | INFT.records box |
| Tensor Config (dims 64/384/512/768/**1024** + CID) | THOT.tensors + THOT.cid_index |
| Trust & Capabilities | trust_models bitmap on registry |
| Skills | comma-separated string on registry |
| mindX backend | MindXBridge + registry oracle-push |
| PAIMINT payments | BankonPaimint with CHARGER_ROLE + allowance system |
| parsec / x402 payments | X402Verifier (ed25519 receipts) |

---

## Audit notes (v1.3)

### NFT contracts
- All four types have clawback / reserve / freeze zeroed at mint (except PAIMINT which uses those roles intentionally)
- Every dynamic asset config re-supplies all four address roles to avoid the Algorand "omitted role = zeroed forever" trap
- iNFT `freeze` severs both the manager role on the ASA and the directive address in the same call
- CID uniqueness uses `sha256(data_cid)` to fit the 64-byte box key limit
- Mint flow is two-step (mint → opt-in → claim) because Algorand requires opt-in before holding an ASA. The `pending_owner` box field prevents race conditions.
- `MIN_MINT_PAYMENT = 0.201 ALGO` covers protocol fee + ASA MBR + box MBR buffer

### PAIMINT (v1.3 critical fix)
- **CHARGER role is necessary but not sufficient** — chargers also need per-user allowance to burn
- Allowance is keyed by `sha256(user || charger)` and stored in a box map
- `approve_charger` accumulates on repeated calls; `revoke_charger_approval` clears completely
- `reward` does not consume allowance (minting is always safe for the user)
- `burn_for_operation` decrements allowance on success and reverts if insufficient

### X402Verifier
- Uses `op.ed25519verify_bare` (raw ed25519, no Algorand domain prefix) to match parsec-wallet's signing pattern
- Receipt digest = `sha256(arc4-encoded receipt)` — frontend helper provides `x402_compute_digest()` so off-chain signers compute the exact same value
- All length validations explicit (32-byte txid/purpose, 64-byte signature)
- Replay protection via box map keyed by the digest itself

### MindXBridge
- Separate `admin` and `oracle` roles
- Job IDs are `sha256(app_id || sender || nonce)` — deterministic and collision-resistant
- Subscription renewal carries unused calls forward and extends from `max(now, current_expiry)`
- Oracle can only deliver results to existing PENDING jobs

### AgenticPlaceRegistry (v1.3 architectural fix)
- mindX integration via **oracle-push** (`deliver_mindx_result`) instead of inner-call-and-parse-bytes
- Oracle's only privilege is writing scores; it cannot register, deactivate, or alter any other field
- Registry never custodies assets — only metadata bindings

### Type safety
- All `Account ↔ Account` and `Bytes ↔ Bytes` comparisons explicit
- Box `in` checks before every read/write
- `op.Box.delete()` instead of Python `del` for box removal
- Explicit `if`/`else` instead of Python ternaries (Puya-fragile)

> ⚠️ Unaudited code. Run a third-party audit before mainnet deployment.

---

## License

MIT OR Apache-2.0 — pick whichever fits your downstream project.
