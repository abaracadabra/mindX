# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# DNFT — Dynamic Agent NFT (Algorand ASA)   v1.3
#
# Mirrors AgenticPlace dNFT: manager-updatable note, freezable to permanent.
#
# AUDIT v1.3 fixes:
#   - Box existence check via `in` before read
#   - close_remainder_to assertion on payment
#   - Tighter update_count bounds
#   - Correct re-supply of all four asset roles on every reconfig

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    KIND_DNFT,
    MAX_ASSET_NAME,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
    MIN_MINT_PAYMENT,
)


# ─── Events ───────────────────────────────────────────────────────────────
class DnftMinted(arc4.Struct):
    asset_id: arc4.UInt64
    minter: arc4.Address
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64


class DnftUpdated(arc4.Struct):
    asset_id: arc4.UInt64
    updater: arc4.Address
    update_count: arc4.UInt64


class DnftFrozen(arc4.Struct):
    asset_id: arc4.UInt64
    holder: arc4.Address


class DnftClaimed(arc4.Struct):
    asset_id: arc4.UInt64
    owner: arc4.Address


# ─── Box record ───────────────────────────────────────────────────────────
class DnftIdentityRecord(arc4.Struct):
    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address
    pending_owner: arc4.Address
    claimed: arc4.Bool
    frozen: arc4.Bool
    update_count: arc4.UInt64


class DNFT(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)
        self.identities = BoxMap(UInt64, DnftIdentityRecord, key_prefix=b"id")

    # ─── lifecycle ─────────────────────────────────────────────────────
    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(MIN_MINT_PAYMENT)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    # ─── mint ──────────────────────────────────────────────────────────
    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        assert (
            payment.receiver == Global.current_application_address
        ), "payment receiver must be application"
        assert payment.amount >= self.mint_fee.value, "payment below mint_fee"
        assert payment.sender == Txn.sender, "payment sender mismatch"
        assert payment.close_remainder_to == Global.zero_address, "close not allowed"

        assert name.native.bytes.length > UInt64(0), "empty name"
        assert name.native.bytes.length <= UInt64(MAX_ASSET_NAME), "name too long"
        assert (
            unit_name.native.bytes.length <= UInt64(MAX_UNIT_NAME)
        ), "unit_name too long"
        assert (
            metadata_note.native.bytes.length <= UInt64(MAX_NOTE_LENGTH)
        ), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"

        # Manager = application so future reconfigs work. Reserve / freeze /
        # clawback zeroed permanently.
        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()
        new_asset_id = result.created_asset.id

        self.identities[new_asset_id] = DnftIdentityRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
            frozen=arc4.Bool(False),  # noqa: FBT003
            update_count=arc4.UInt64(0),
        )
        self.total_minted.value = self.total_minted.value + UInt64(1)

        arc4.emit(
            DnftMinted(
                asset_id=arc4.UInt64(new_asset_id),
                minter=arc4.Address(Txn.sender),
                agent_type=agent_type,
                minted_at=arc4.UInt64(Global.latest_timestamp),
            )
        )
        return arc4.UInt64(new_asset_id)

    @arc4.abimethod
    def claim(self, asset: Asset) -> None:
        assert asset.id in self.identities, "unknown asset"
        rec = self.identities[asset.id].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native, "not pending owner"

        itxn.AssetTransfer(
            xfer_asset=asset.id,
            asset_sender=Global.current_application_address,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.identities[asset.id] = rec.copy()

        arc4.emit(
            DnftClaimed(
                asset_id=arc4.UInt64(asset.id),
                owner=arc4.Address(Txn.sender),
            )
        )

    # ─── holder-side update ─────────────────────────────────────────────
    @arc4.abimethod
    def update_note(self, asset: Asset, new_note: arc4.String) -> None:
        assert asset.id in self.identities, "unknown asset"
        rec = self.identities[asset.id].copy()
        assert not rec.frozen.native, "asset is frozen"
        assert (
            new_note.native.bytes.length <= UInt64(MAX_NOTE_LENGTH)
        ), "note too long"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        # Re-supply every address role so Algorand doesn't zero any of them.
        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            note=new_note.native,
            fee=0,
        ).submit()

        rec.update_count = arc4.UInt64(rec.update_count.native + UInt64(1))
        self.identities[asset.id] = rec.copy()

        arc4.emit(
            DnftUpdated(
                asset_id=arc4.UInt64(asset.id),
                updater=arc4.Address(Txn.sender),
                update_count=rec.update_count,
            )
        )

    @arc4.abimethod
    def freeze(self, asset: Asset) -> None:
        """Permanently lock the asset by clearing its manager address."""
        assert asset.id in self.identities, "unknown asset"
        rec = self.identities[asset.id].copy()
        assert not rec.frozen.native, "already frozen"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        rec.frozen = arc4.Bool(True)  # noqa: FBT003
        self.identities[asset.id] = rec.copy()

        arc4.emit(
            DnftFrozen(
                asset_id=arc4.UInt64(asset.id),
                holder=arc4.Address(Txn.sender),
            )
        )

    # ─── views ─────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_identity(self, asset_id: arc4.UInt64) -> DnftIdentityRecord:
        return self.identities[asset_id.native]

    @arc4.abimethod(readonly=True)
    def is_frozen(self, asset_id: arc4.UInt64) -> arc4.Bool:
        return arc4.Bool(self.identities[asset_id.native].frozen.native)

    @arc4.abimethod(readonly=True)
    def kind(self) -> arc4.DynamicBytes:
        return arc4.DynamicBytes(Bytes(KIND_DNFT))

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
