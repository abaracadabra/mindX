# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# THOT — Transferable Hyper-Optimized Tensor (Algorand ASA)   v1.3
#
# Mirrors AgenticPlace THOT: immutable, CID-unique, dim in
# {64, 384, 512, 768, 1024} (form lists first four; 1024 added).
#
# AUDIT v1.3 fixes:
#   - tensor_hash length validation (exactly 32 bytes)
#   - CID uniqueness box existence check before read
#   - close_remainder_to assertion on payment

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    KIND_THOT,
    MAX_ASSET_NAME,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
    MIN_MINT_PAYMENT,
    THOT_DIM_64,
    THOT_DIM_384,
    THOT_DIM_512,
    THOT_DIM_768,
    THOT_DIM_1024,
)


# ─── Events ───────────────────────────────────────────────────────────────
class ThotMinted(arc4.Struct):
    asset_id: arc4.UInt64
    minter: arc4.Address
    dimensions: arc4.UInt16
    cid_hash: arc4.DynamicBytes


class ThotClaimed(arc4.Struct):
    asset_id: arc4.UInt64
    owner: arc4.Address


# ─── Box records ──────────────────────────────────────────────────────────
class TensorRecord(arc4.Struct):
    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address
    pending_owner: arc4.Address
    claimed: arc4.Bool
    data_cid: arc4.String
    dimensions: arc4.UInt16
    tensor_hash: arc4.DynamicBytes  # 32 bytes


class CidIndex(arc4.Struct):
    asset_id: arc4.UInt64
    minter: arc4.Address
    minted_at: arc4.UInt64


class THOT(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)
        self.tensors = BoxMap(UInt64, TensorRecord, key_prefix=b"th")
        # sha256(data_cid) → CidIndex
        self.cid_index = BoxMap(Bytes, CidIndex, key_prefix=b"ci")

    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(MIN_MINT_PAYMENT)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    @arc4.abimethod(readonly=True)
    def is_supported_dimension(self, d: arc4.UInt16) -> arc4.Bool:
        n = d.native
        if (
            n == UInt64(THOT_DIM_64)
            or n == UInt64(THOT_DIM_384)
            or n == UInt64(THOT_DIM_512)
            or n == UInt64(THOT_DIM_768)
            or n == UInt64(THOT_DIM_1024)
        ):
            return arc4.Bool(True)  # noqa: FBT003
        return arc4.Bool(False)  # noqa: FBT003

    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        data_cid: arc4.String,
        dimensions: arc4.UInt16,
        tensor_hash: arc4.DynamicBytes,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        assert (
            payment.receiver == Global.current_application_address
        ), "payment receiver must be application"
        assert payment.amount >= self.mint_fee.value, "payment below mint_fee"
        assert payment.sender == Txn.sender, "payment sender mismatch"
        assert payment.close_remainder_to == Global.zero_address, "close not allowed"

        assert name.native.bytes.length > UInt64(0), "empty name"
        assert name.native.bytes.length <= UInt64(MAX_ASSET_NAME), "name too long"
        assert (
            unit_name.native.bytes.length <= UInt64(MAX_UNIT_NAME)
        ), "unit_name too long"
        assert (
            metadata_note.native.bytes.length <= UInt64(MAX_NOTE_LENGTH)
        ), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"
        assert data_cid.native.bytes.length > UInt64(0), "empty CID"
        # tensor_hash must be exactly 32 bytes (sha256 output)
        assert tensor_hash.native.length == UInt64(32), "tensor_hash must be 32 bytes"

        d = dimensions.native
        assert (
            d == UInt64(THOT_DIM_64)
            or d == UInt64(THOT_DIM_384)
            or d == UInt64(THOT_DIM_512)
            or d == UInt64(THOT_DIM_768)
            or d == UInt64(THOT_DIM_1024)
        ), "unsupported dimensions"

        cid_key = op.sha256(data_cid.native.bytes)
        assert cid_key not in self.cid_index, "CID already minted"

        # Immutable ASA (all roles zeroed)
        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()
        new_asset_id = result.created_asset.id

        self.tensors[new_asset_id] = TensorRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
            data_cid=data_cid,
            dimensions=dimensions,
            tensor_hash=tensor_hash,
        )

        self.cid_index[cid_key] = CidIndex(
            asset_id=arc4.UInt64(new_asset_id),
            minter=arc4.Address(Txn.sender),
            minted_at=arc4.UInt64(Global.latest_timestamp),
        )

        self.total_minted.value = self.total_minted.value + UInt64(1)

        arc4.emit(
            ThotMinted(
                asset_id=arc4.UInt64(new_asset_id),
                minter=arc4.Address(Txn.sender),
                dimensions=dimensions,
                cid_hash=arc4.DynamicBytes(cid_key),
            )
        )
        return arc4.UInt64(new_asset_id)

    @arc4.abimethod
    def claim(self, asset: Asset) -> None:
        assert asset.id in self.tensors, "unknown asset"
        rec = self.tensors[asset.id].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native, "not pending owner"

        itxn.AssetTransfer(
            xfer_asset=asset.id,
            asset_sender=Global.current_application_address,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.tensors[asset.id] = rec.copy()

        arc4.emit(
            ThotClaimed(
                asset_id=arc4.UInt64(asset.id),
                owner=arc4.Address(Txn.sender),
            )
        )

    @arc4.abimethod(readonly=True)
    def get_tensor(self, asset_id: arc4.UInt64) -> TensorRecord:
        return self.tensors[asset_id.native]

    @arc4.abimethod(readonly=True)
    def lookup_cid(self, data_cid: arc4.String) -> arc4.UInt64:
        cid_key = op.sha256(data_cid.native.bytes)
        return self.cid_index[cid_key].asset_id

    @arc4.abimethod(readonly=True)
    def cid_exists(self, data_cid: arc4.String) -> arc4.Bool:
        cid_key = op.sha256(data_cid.native.bytes)
        if cid_key in self.cid_index:
            return arc4.Bool(True)  # noqa: FBT003
        return arc4.Bool(False)  # noqa: FBT003

    @arc4.abimethod(readonly=True)
    def kind(self) -> arc4.DynamicBytes:
        return arc4.DynamicBytes(Bytes(KIND_THOT))

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
