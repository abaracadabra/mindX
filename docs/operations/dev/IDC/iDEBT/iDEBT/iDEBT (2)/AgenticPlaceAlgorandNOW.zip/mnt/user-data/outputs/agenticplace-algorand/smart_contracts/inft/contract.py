# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# INFT — Intelligent Agent NFT (Algorand ASA)   v1.3
#
# Mirrors AgenticPlace iNFT: manager-updatable note + directive-driven
# self-update of intelligence config. Freeze severs both the manager role
# on the ASA and the directive address in box storage in one atomic call.
#
# AUDIT v1.3 fixes:
#   - Box existence check on every box read
#   - close_remainder_to assertion on payment
#   - Explicit directive nonzero check (cannot set directive to zero except
#     via freeze, which is the intended kill-switch semantics)

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    String,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    KIND_INFT,
    MAX_ASSET_NAME,
    MAX_INTELLIGENCE_LEVEL,
    MAX_NOTE_LENGTH,
    MAX_UNIT_NAME,
    MIN_MINT_PAYMENT,
)


# ─── Events ───────────────────────────────────────────────────────────────
class InftMinted(arc4.Struct):
    asset_id: arc4.UInt64
    minter: arc4.Address
    directive: arc4.Address
    level: arc4.UInt8


class InftClaimed(arc4.Struct):
    asset_id: arc4.UInt64
    owner: arc4.Address


class InftDirectiveRotated(arc4.Struct):
    asset_id: arc4.UInt64
    previous: arc4.Address
    next_directive: arc4.Address


class InftSelfUpdated(arc4.Struct):
    asset_id: arc4.UInt64
    directive: arc4.Address
    level: arc4.UInt8
    autonomous: arc4.Bool
    self_update_count: arc4.UInt64


class InftFrozen(arc4.Struct):
    asset_id: arc4.UInt64
    holder: arc4.Address


# ─── Box record ───────────────────────────────────────────────────────────
class InftRecord(arc4.Struct):
    name: arc4.String
    unit_name: arc4.String
    agent_type: arc4.UInt8
    minted_at: arc4.UInt64
    minter: arc4.Address
    pending_owner: arc4.Address
    claimed: arc4.Bool
    frozen: arc4.Bool
    directive: arc4.Address
    level: arc4.UInt8
    autonomous: arc4.Bool
    behavior_cid: arc4.String
    self_update_count: arc4.UInt64
    owner_update_count: arc4.UInt64


class INFT(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_minted = GlobalState(UInt64)
        self.records = BoxMap(UInt64, InftRecord, key_prefix=b"in")

    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(MIN_MINT_PAYMENT)
        self.total_minted.value = UInt64(0)

    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    # ─── mint ──────────────────────────────────────────────────────────
    @arc4.abimethod
    def mint(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        agent_type: arc4.UInt8,
        metadata_note: arc4.String,
        directive: arc4.Address,
        level: arc4.UInt8,
        autonomous: arc4.Bool,
        behavior_cid: arc4.String,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.UInt64:
        assert (
            payment.receiver == Global.current_application_address
        ), "payment receiver must be application"
        assert payment.amount >= self.mint_fee.value, "payment below mint_fee"
        assert payment.sender == Txn.sender, "payment sender mismatch"
        assert payment.close_remainder_to == Global.zero_address, "close not allowed"

        assert name.native.bytes.length > UInt64(0), "empty name"
        assert name.native.bytes.length <= UInt64(MAX_ASSET_NAME), "name too long"
        assert (
            unit_name.native.bytes.length <= UInt64(MAX_UNIT_NAME)
        ), "unit_name too long"
        assert (
            metadata_note.native.bytes.length <= UInt64(MAX_NOTE_LENGTH)
        ), "note too long"
        assert agent_type.native > UInt64(0), "agent_type required"
        assert (
            level.native <= UInt64(MAX_INTELLIGENCE_LEVEL)
        ), "level exceeds 100"
        # Directive may be zero at mint if the agent will rotate it in later.

        result = itxn.AssetConfig(
            total=1,
            decimals=0,
            default_frozen=False,
            asset_name=name.native,
            unit_name=unit_name.native,
            url=String(""),
            note=metadata_note.native,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()
        new_asset_id = result.created_asset.id

        self.records[new_asset_id] = InftRecord(
            name=name,
            unit_name=unit_name,
            agent_type=agent_type,
            minted_at=arc4.UInt64(Global.latest_timestamp),
            minter=arc4.Address(Txn.sender),
            pending_owner=arc4.Address(Txn.sender),
            claimed=arc4.Bool(False),  # noqa: FBT003
            frozen=arc4.Bool(False),  # noqa: FBT003
            directive=directive,
            level=level,
            autonomous=autonomous,
            behavior_cid=behavior_cid,
            self_update_count=arc4.UInt64(0),
            owner_update_count=arc4.UInt64(0),
        )
        self.total_minted.value = self.total_minted.value + UInt64(1)

        arc4.emit(
            InftMinted(
                asset_id=arc4.UInt64(new_asset_id),
                minter=arc4.Address(Txn.sender),
                directive=directive,
                level=level,
            )
        )
        return arc4.UInt64(new_asset_id)

    @arc4.abimethod
    def claim(self, asset: Asset) -> None:
        assert asset.id in self.records, "unknown asset"
        rec = self.records[asset.id].copy()
        assert not rec.claimed.native, "already claimed"
        assert Txn.sender == rec.pending_owner.native, "not pending owner"

        itxn.AssetTransfer(
            xfer_asset=asset.id,
            asset_sender=Global.current_application_address,
            asset_receiver=Txn.sender,
            asset_amount=1,
            fee=0,
        ).submit()

        rec.claimed = arc4.Bool(True)  # noqa: FBT003
        rec.pending_owner = arc4.Address(Global.zero_address)
        self.records[asset.id] = rec.copy()

        arc4.emit(
            InftClaimed(
                asset_id=arc4.UInt64(asset.id),
                owner=arc4.Address(Txn.sender),
            )
        )

    # ─── owner-side ─────────────────────────────────────────────────────
    @arc4.abimethod
    def update_identity(self, asset: Asset, new_note: arc4.String) -> None:
        assert asset.id in self.records, "unknown asset"
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "asset is frozen"
        assert (
            new_note.native.bytes.length <= UInt64(MAX_NOTE_LENGTH)
        ), "note too long"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            note=new_note.native,
            fee=0,
        ).submit()

        rec.owner_update_count = arc4.UInt64(rec.owner_update_count.native + UInt64(1))
        self.records[asset.id] = rec.copy()

    @arc4.abimethod
    def set_directive(self, asset: Asset, new_directive: arc4.Address) -> None:
        assert asset.id in self.records, "unknown asset"
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "asset is frozen"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        previous = rec.directive.copy()
        rec.directive = new_directive
        self.records[asset.id] = rec.copy()

        arc4.emit(
            InftDirectiveRotated(
                asset_id=arc4.UInt64(asset.id),
                previous=previous,
                next_directive=new_directive,
            )
        )

    @arc4.abimethod
    def freeze(self, asset: Asset) -> None:
        """Permanently lock the iNFT and sever its directive in one call."""
        assert asset.id in self.records, "unknown asset"
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "already frozen"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.zero_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=0,
        ).submit()

        rec.frozen = arc4.Bool(True)  # noqa: FBT003
        rec.directive = arc4.Address(Global.zero_address)
        rec.autonomous = arc4.Bool(False)  # noqa: FBT003
        self.records[asset.id] = rec.copy()

        arc4.emit(
            InftFrozen(
                asset_id=arc4.UInt64(asset.id),
                holder=arc4.Address(Txn.sender),
            )
        )

    # ─── directive-side ─────────────────────────────────────────────────
    @arc4.abimethod
    def self_update(
        self,
        asset: Asset,
        new_level: arc4.UInt8,
        new_autonomous: arc4.Bool,
        new_behavior_cid: arc4.String,
        new_note: arc4.String,
    ) -> None:
        assert asset.id in self.records, "unknown asset"
        rec = self.records[asset.id].copy()
        assert not rec.frozen.native, "asset is frozen"
        # A zeroed directive means no self-update is allowed (post-freeze state).
        assert (
            rec.directive.native != Global.zero_address
        ), "directive is disabled"
        assert Txn.sender == rec.directive.native, "caller is not the directive"
        assert (
            new_level.native <= UInt64(MAX_INTELLIGENCE_LEVEL)
        ), "level exceeds 100"
        assert (
            new_note.native.bytes.length <= UInt64(MAX_NOTE_LENGTH)
        ), "note too long"

        itxn.AssetConfig(
            config_asset=asset.id,
            manager=Global.current_application_address,
            reserve=Global.zero_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            note=new_note.native,
            fee=0,
        ).submit()

        rec.level = new_level
        rec.autonomous = new_autonomous
        rec.behavior_cid = new_behavior_cid
        rec.self_update_count = arc4.UInt64(rec.self_update_count.native + UInt64(1))
        self.records[asset.id] = rec.copy()

        arc4.emit(
            InftSelfUpdated(
                asset_id=arc4.UInt64(asset.id),
                directive=arc4.Address(Txn.sender),
                level=new_level,
                autonomous=new_autonomous,
                self_update_count=rec.self_update_count,
            )
        )

    # ─── views ─────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_record(self, asset_id: arc4.UInt64) -> InftRecord:
        return self.records[asset_id.native]

    @arc4.abimethod(readonly=True)
    def is_frozen(self, asset_id: arc4.UInt64) -> arc4.Bool:
        return arc4.Bool(self.records[asset_id.native].frozen.native)

    @arc4.abimethod(readonly=True)
    def kind(self) -> arc4.DynamicBytes:
        return arc4.DynamicBytes(Bytes(KIND_INFT))

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
