# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# X402Verifier — parsec / parsec-wallet x402 receipt verifier (Algorand)   v1.3
#
# AUDIT v1.3 fixes:
#   - Signature length validated (exactly 64 bytes for ed25519)
#   - Purpose hash length validated (exactly 32 bytes)
#   - algo_tx_id length validated (exactly 32 bytes)
#   - Box existence checks on delete/read
#   - op.Box.delete used instead of `del` for consumer revocation

from algopy import (
    ARC4Contract,
    Account,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    ED25519_SIGNATURE_LENGTH,
)


# ─── Receipt struct ───────────────────────────────────────────────────────
class Receipt(arc4.Struct):
    """parsec-wallet x402 receipt payload (matches off-chain ABI exactly)."""

    payer: arc4.Address
    algo_asset: arc4.UInt64       # 0 = ALGO, else ASA id
    amount: arc4.UInt64           # microAlgos or micro-ASA
    algo_round: arc4.UInt64       # round the payment confirmed in
    algo_tx_id: arc4.DynamicBytes  # 32-byte Algorand txid of the payment
    expires_at: arc4.UInt64       # unix timestamp
    purpose: arc4.DynamicBytes    # 32-byte sha256 hash of the purpose string
    nonce: arc4.UInt64            # unique nonce


# ─── Events ───────────────────────────────────────────────────────────────
class ReceiptConsumed(arc4.Struct):
    receipt_id: arc4.DynamicBytes
    payer: arc4.Address
    amount: arc4.UInt64
    purpose: arc4.DynamicBytes
    consumer: arc4.Address


class ConsumerGranted(arc4.Struct):
    consumer: arc4.Address


class ConsumerRevoked(arc4.Struct):
    consumer: arc4.Address


class OperatorRotated(arc4.Struct):
    previous: arc4.Address
    next_operator: arc4.Address


# ─── Box records ──────────────────────────────────────────────────────────
class ConsumedReceipt(arc4.Struct):
    payer: arc4.Address
    amount: arc4.UInt64
    purpose: arc4.DynamicBytes
    consumed_at: arc4.UInt64
    consumer: arc4.Address


class ConsumerRecord(arc4.Struct):
    granted_at: arc4.UInt64
    receipts_consumed: arc4.UInt64
    total_amount_consumed: arc4.UInt64


class X402Verifier(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.operator = GlobalState(Account)
        self.total_consumed = GlobalState(UInt64)
        self.total_amount_consumed = GlobalState(UInt64)

        # sha256(receipt.bytes) → ConsumedReceipt
        self.used_receipts = BoxMap(Bytes, ConsumedReceipt, key_prefix=b"ur")
        self.consumers = BoxMap(Account, ConsumerRecord, key_prefix=b"co")

    @arc4.abimethod(create="require")
    def create(self, operator: arc4.Address) -> None:
        self.admin.value = Txn.sender
        self.operator.value = operator.native
        self.total_consumed.value = UInt64(0)
        self.total_amount_consumed.value = UInt64(0)

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    @arc4.abimethod
    def set_operator(self, new_operator: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        previous = self.operator.value
        self.operator.value = new_operator.native
        arc4.emit(
            OperatorRotated(
                previous=arc4.Address(previous),
                next_operator=new_operator,
            )
        )

    # ─── consumer management ────────────────────────────────────────────
    @arc4.abimethod
    def grant_consumer(self, consumer: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        assert consumer.native not in self.consumers, "already a consumer"

        self.consumers[consumer.native] = ConsumerRecord(
            granted_at=arc4.UInt64(Global.latest_timestamp),
            receipts_consumed=arc4.UInt64(0),
            total_amount_consumed=arc4.UInt64(0),
        )
        arc4.emit(ConsumerGranted(consumer=consumer))

    @arc4.abimethod
    def revoke_consumer(self, consumer: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        assert consumer.native in self.consumers, "not a consumer"
        op.Box.delete(b"co" + consumer.native.bytes)
        arc4.emit(ConsumerRevoked(consumer=consumer))

    @arc4.abimethod(readonly=True)
    def is_consumer(self, addr: arc4.Address) -> arc4.Bool:
        if addr.native in self.consumers:
            return arc4.Bool(True)  # noqa: FBT003
        return arc4.Bool(False)  # noqa: FBT003

    # ─── receipt hash ──────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def receipt_hash(self, receipt: Receipt) -> arc4.DynamicBytes:
        """Canonical hash: sha256(ABI-encoded receipt bytes)."""
        return arc4.DynamicBytes(op.sha256(receipt.bytes))

    # ─── verification ──────────────────────────────────────────────────
    @arc4.abimethod
    def verify_and_consume(
        self,
        receipt: Receipt,
        payer_signature: arc4.DynamicBytes,
        expected_payer: arc4.Address,
    ) -> arc4.DynamicBytes:
        """Validate an x402 receipt and mark it as consumed.

        All of these must hold or the tx reverts:
          1. Caller is an authorized consumer contract
          2. receipt.payer == expected_payer
          3. receipt.expires_at >= latest_timestamp
          4. receipt.algo_round <= current round
          5. receipt.algo_tx_id is exactly 32 bytes
          6. receipt.purpose is exactly 32 bytes
          7. payer_signature is exactly 64 bytes (ed25519)
          8. ed25519_verify_bare(sha256(receipt.bytes), payer_signature, receipt.payer) == true
          9. sha256(receipt.bytes) not in used_receipts

        On success, the receipt hash is stored and cannot be re-consumed.
        """
        # 1. Authorization
        assert Txn.sender in self.consumers, "caller is not an authorized consumer"

        # 2. Payer identity
        assert (
            receipt.payer.native == expected_payer.native
        ), "receipt payer mismatch"

        # 3. Expiry
        assert (
            receipt.expires_at.native >= Global.latest_timestamp
        ), "receipt expired"

        # 4. Payment must have landed
        assert (
            receipt.algo_round.native <= Global.round
        ), "payment round not yet reached"

        # 5-7. Length validations
        assert (
            receipt.algo_tx_id.native.length == UInt64(32)
        ), "algo_tx_id must be 32 bytes"
        assert (
            receipt.purpose.native.length == UInt64(32)
        ), "purpose must be 32 bytes"
        assert (
            payer_signature.native.length == UInt64(ED25519_SIGNATURE_LENGTH)
        ), "signature must be 64 bytes"

        # 8. Signature check
        receipt_digest = op.sha256(receipt.bytes)
        assert op.ed25519verify_bare(
            receipt_digest,
            payer_signature.native,
            receipt.payer.native.bytes,
        ), "invalid payer signature"

        # 9. Replay protection
        assert receipt_digest not in self.used_receipts, "receipt already consumed"

        self.used_receipts[receipt_digest] = ConsumedReceipt(
            payer=receipt.payer,
            amount=receipt.amount,
            purpose=receipt.purpose,
            consumed_at=arc4.UInt64(Global.latest_timestamp),
            consumer=arc4.Address(Txn.sender),
        )

        self.total_consumed.value = self.total_consumed.value + UInt64(1)
        self.total_amount_consumed.value = (
            self.total_amount_consumed.value + receipt.amount.native
        )

        stats = self.consumers[Txn.sender].copy()
        stats.receipts_consumed = arc4.UInt64(
            stats.receipts_consumed.native + UInt64(1)
        )
        stats.total_amount_consumed = arc4.UInt64(
            stats.total_amount_consumed.native + receipt.amount.native
        )
        self.consumers[Txn.sender] = stats.copy()

        arc4.emit(
            ReceiptConsumed(
                receipt_id=arc4.DynamicBytes(receipt_digest),
                payer=receipt.payer,
                amount=receipt.amount,
                purpose=receipt.purpose,
                consumer=arc4.Address(Txn.sender),
            )
        )
        return arc4.DynamicBytes(receipt_digest)

    # ─── views ─────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def is_consumed(self, receipt: Receipt) -> arc4.Bool:
        digest = op.sha256(receipt.bytes)
        if digest in self.used_receipts:
            return arc4.Bool(True)  # noqa: FBT003
        return arc4.Bool(False)  # noqa: FBT003

    @arc4.abimethod(readonly=True)
    def get_consumed(self, receipt_hash: arc4.DynamicBytes) -> ConsumedReceipt:
        return self.used_receipts[receipt_hash.native]

    @arc4.abimethod(readonly=True)
    def get_consumer_stats(self, addr: arc4.Address) -> ConsumerRecord:
        return self.consumers[addr.native]

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()
