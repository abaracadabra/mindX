# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# AgenticPlace Algorand frontend helper  v1.3
#
# One-call wrappers for the 3-step mint flow (mint → opt-in → claim) plus
# helpers for registry, mindX, PAIMINT allowance system, and x402 receipts.
#
# AUDIT v1.3 additions:
#   - paimint_approve_charger / paimint_revoke_charger_approval (user-side)
#   - paimint_allowance_of (view)
#   - mindx_deliver_result (oracle-side, for the registry oracle-push pattern)

from __future__ import annotations

import enum
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Optional

from algokit_utils import (
    AlgorandClient,
    AssetOptInParams,
    PaymentParams,
    SigningAccount,
)


# ─── Enums ────────────────────────────────────────────────────────────────
class AgentType(enum.IntEnum):
    NONE = 0
    COGNITIVE_AUGMENTATION = 1
    CREATIVE_INTELLIGENCE = 2
    ANALYTICAL_PROCESSING = 3
    SPECIALIZED_DOMAIN = 4
    AGENT_ORCHESTRATOR = 5


class TrustModel(enum.IntFlag):
    REPUTATION = 1 << 0
    CRYPTO_ECONOMIC = 1 << 1
    TEE = 1 << 2
    ZKML = 1 << 3


class MindXPlan(enum.IntEnum):
    FREE = 0
    STANDARD = 1
    PRO = 2
    ENTERPRISE = 3


SUPPORTED_THOT_DIMENSIONS: frozenset[int] = frozenset({64, 384, 512, 768, 1024})
DEFAULT_MINT_PAYMENT_MICROALGOS: int = 201_000  # matches MIN_MINT_PAYMENT


# ─── ARC-69 metadata ──────────────────────────────────────────────────────
@dataclass
class Arc69Metadata:
    description: str
    agent_type: AgentType
    media_url: str = ""
    external_url: str = ""
    properties: dict[str, Any] = field(default_factory=dict)

    def to_json_bytes(self) -> bytes:
        body = {
            "standard": "arc69",
            "description": self.description,
            "external_url": self.external_url,
            "media_url": self.media_url,
            "properties": {
                "agent_type": self.agent_type.name,
                **self.properties,
            },
        }
        return json.dumps(body, separators=(",", ":")).encode("utf-8")


@dataclass
class MintResult:
    asset_id: int
    mint_txid: str
    opt_in_txid: str
    claim_txid: str


@dataclass
class X402Receipt:
    """Client-side representation of an x402 receipt."""

    payer: str
    algo_asset: int
    amount: int
    algo_round: int
    algo_tx_id: bytes           # exactly 32 bytes
    expires_at: int
    purpose: bytes              # sha256 of purpose string, exactly 32 bytes
    nonce: int

    def as_abi_tuple(self) -> tuple[Any, ...]:
        return (
            self.payer,
            self.algo_asset,
            self.amount,
            self.algo_round,
            self.algo_tx_id,
            self.expires_at,
            self.purpose,
            self.nonce,
        )


# ─── Main client ──────────────────────────────────────────────────────────
class AgenticPlaceClient:
    """High-level client wrapping the 3-step mint flow + all ancillary ops."""

    def __init__(
        self,
        algorand: AlgorandClient,
        signer: SigningAccount,
        *,
        anft_app_id: int = 0,
        dnft_app_id: int = 0,
        inft_app_id: int = 0,
        thot_app_id: int = 0,
        registry_app_id: int = 0,
        mindx_app_id: int = 0,
        paimint_app_id: int = 0,
        x402_app_id: int = 0,
    ) -> None:
        self.algorand = algorand
        self.signer = signer
        self.anft_app_id = anft_app_id
        self.dnft_app_id = dnft_app_id
        self.inft_app_id = inft_app_id
        self.thot_app_id = thot_app_id
        self.registry_app_id = registry_app_id
        self.mindx_app_id = mindx_app_id
        self.paimint_app_id = paimint_app_id
        self.x402_app_id = x402_app_id

    # ─── factories ─────────────────────────────────────────────────────
    @classmethod
    def localnet(cls, signer: SigningAccount, **app_ids: int) -> AgenticPlaceClient:
        return cls(AlgorandClient.default_localnet(), signer, **app_ids)

    @classmethod
    def testnet(cls, signer: SigningAccount, **app_ids: int) -> AgenticPlaceClient:
        return cls(AlgorandClient.testnet(), signer, **app_ids)

    @classmethod
    def mainnet(cls, signer: SigningAccount, **app_ids: int) -> AgenticPlaceClient:
        return cls(AlgorandClient.mainnet(), signer, **app_ids)

    # ─── internals ──────────────────────────────────────────────────────
    def _app_address(self, app_id: int) -> str:
        return self.algorand.app.get_by_id(app_id).address

    def _call(self, app_id: int, method: str, args: list[Any]) -> Any:
        return self.algorand.send.app_call_method_call(
            {
                "app_id": app_id,
                "method": method,
                "args": args,
                "sender": self.signer.address,
                "signer": self.signer,
            }
        )

    def _three_step_mint(
        self,
        app_id: int,
        mint_args_before_payment: list[Any],
        payment_amount: int = DEFAULT_MINT_PAYMENT_MICROALGOS,
    ) -> MintResult:
        app_address = self._app_address(app_id)

        composer = self.algorand.new_group()
        payment = composer.add_payment(
            PaymentParams(
                sender=self.signer.address,
                receiver=app_address,
                amount=payment_amount,
                signer=self.signer,
            )
        )
        composer.add_app_call_method_call(
            {
                "app_id": app_id,
                "method": "mint",
                "args": [*mint_args_before_payment, payment],
                "sender": self.signer.address,
                "signer": self.signer,
            }
        )
        mint_result = composer.send()
        mint_txid = mint_result.tx_ids[-1]
        asset_id = mint_result.returns[-1].return_value
        if not isinstance(asset_id, int):
            raise RuntimeError(f"unexpected mint return: {asset_id!r}")

        opt_in_result = self.algorand.send.asset_opt_in(
            AssetOptInParams(
                sender=self.signer.address,
                asset_id=asset_id,
                signer=self.signer,
            )
        )

        claim_result = self._call(app_id, "claim", [asset_id])
        return MintResult(
            asset_id=asset_id,
            mint_txid=mint_txid,
            opt_in_txid=opt_in_result.tx_id,
            claim_txid=claim_result.tx_id,
        )

    # ─── ANFT / DNFT / INFT / THOT mints ────────────────────────────────
    def mint_anft(
        self,
        *,
        name: str,
        unit_name: str,
        agent_type: AgentType,
        description: str,
        media_url: str = "",
        external_url: str = "",
        extra_properties: Optional[dict[str, Any]] = None,
        payment_amount: int = DEFAULT_MINT_PAYMENT_MICROALGOS,
    ) -> MintResult:
        if not self.anft_app_id:
            raise ValueError("anft_app_id not set")
        note = Arc69Metadata(
            description=description,
            agent_type=agent_type,
            media_url=media_url,
            external_url=external_url,
            properties=extra_properties or {},
        ).to_json_bytes()
        return self._three_step_mint(
            self.anft_app_id,
            [name, unit_name, int(agent_type), note],
            payment_amount=payment_amount,
        )

    def mint_dnft(
        self,
        *,
        name: str,
        unit_name: str,
        agent_type: AgentType,
        description: str,
        media_url: str = "",
        external_url: str = "",
        extra_properties: Optional[dict[str, Any]] = None,
        payment_amount: int = DEFAULT_MINT_PAYMENT_MICROALGOS,
    ) -> MintResult:
        if not self.dnft_app_id:
            raise ValueError("dnft_app_id not set")
        note = Arc69Metadata(
            description=description,
            agent_type=agent_type,
            media_url=media_url,
            external_url=external_url,
            properties=extra_properties or {},
        ).to_json_bytes()
        return self._three_step_mint(
            self.dnft_app_id,
            [name, unit_name, int(agent_type), note],
            payment_amount=payment_amount,
        )

    def mint_inft(
        self,
        *,
        name: str,
        unit_name: str,
        agent_type: AgentType,
        description: str,
        directive_address: str,
        intelligence_level: int,
        autonomous: bool,
        behavior_cid: str,
        media_url: str = "",
        external_url: str = "",
        extra_properties: Optional[dict[str, Any]] = None,
        payment_amount: int = DEFAULT_MINT_PAYMENT_MICROALGOS,
    ) -> MintResult:
        if not self.inft_app_id:
            raise ValueError("inft_app_id not set")
        if not 0 <= intelligence_level <= 100:
            raise ValueError("intelligence_level must be 0..100")

        properties = dict(extra_properties or {})
        properties.update(
            {
                "intelligence_level": intelligence_level,
                "autonomous": autonomous,
                "behavior_cid": behavior_cid,
            }
        )
        note = Arc69Metadata(
            description=description,
            agent_type=agent_type,
            media_url=media_url,
            external_url=external_url,
            properties=properties,
        ).to_json_bytes()

        return self._three_step_mint(
            self.inft_app_id,
            [
                name,
                unit_name,
                int(agent_type),
                note,
                directive_address,
                intelligence_level,
                autonomous,
                behavior_cid,
            ],
            payment_amount=payment_amount,
        )

    def mint_thot(
        self,
        *,
        name: str,
        unit_name: str,
        agent_type: AgentType,
        description: str,
        data_cid: str,
        dimensions: int,
        tensor_hash: Optional[bytes] = None,
        media_url: str = "",
        external_url: str = "",
        extra_properties: Optional[dict[str, Any]] = None,
        payment_amount: int = DEFAULT_MINT_PAYMENT_MICROALGOS,
    ) -> MintResult:
        if not self.thot_app_id:
            raise ValueError("thot_app_id not set")
        if dimensions not in SUPPORTED_THOT_DIMENSIONS:
            raise ValueError(
                f"unsupported dimensions {dimensions}; "
                f"must be one of {sorted(SUPPORTED_THOT_DIMENSIONS)}"
            )
        if tensor_hash is None:
            tensor_hash = hashlib.sha256(data_cid.encode("utf-8")).digest()
        if len(tensor_hash) != 32:
            raise ValueError("tensor_hash must be exactly 32 bytes")

        properties = dict(extra_properties or {})
        properties.update(
            {"tensor_dimensions": dimensions, "data_cid": data_cid}
        )
        note = Arc69Metadata(
            description=description,
            agent_type=agent_type,
            media_url=media_url,
            external_url=external_url,
            properties=properties,
        ).to_json_bytes()

        return self._three_step_mint(
            self.thot_app_id,
            [
                name,
                unit_name,
                int(agent_type),
                note,
                data_cid,
                dimensions,
                tensor_hash,
            ],
            payment_amount=payment_amount,
        )

    # ─── dNFT update and iNFT self-update ─────────────────────────────
    def update_dnft_note(
        self,
        *,
        asset_id: int,
        new_description: str,
        agent_type: AgentType,
        media_url: str = "",
        external_url: str = "",
        extra_properties: Optional[dict[str, Any]] = None,
    ) -> str:
        note = Arc69Metadata(
            description=new_description,
            agent_type=agent_type,
            media_url=media_url,
            external_url=external_url,
            properties=extra_properties or {},
        ).to_json_bytes()
        return self._call(
            self.dnft_app_id, "update_note", [asset_id, note]
        ).tx_id

    def inft_self_update(
        self,
        *,
        asset_id: int,
        new_level: int,
        new_autonomous: bool,
        new_behavior_cid: str,
        agent_type: AgentType,
        description: str,
    ) -> str:
        note = Arc69Metadata(
            description=description,
            agent_type=agent_type,
            properties={
                "intelligence_level": new_level,
                "autonomous": new_autonomous,
                "behavior_cid": new_behavior_cid,
            },
        ).to_json_bytes()
        return self._call(
            self.inft_app_id,
            "self_update",
            [asset_id, new_level, new_autonomous, new_behavior_cid, note],
        ).tx_id

    # ─── Registry ──────────────────────────────────────────────────────
    def register_agent(
        self,
        *,
        nft_app_id: int,
        asset_id: int,
        mcp_endpoint: str = "",
        a2a_endpoint: str = "",
        directive_address: str = "",
        website: str = "",
        trust_models: int = 0,
        skills: Optional[list[str]] = None,
        intelligence_level: int = 0,
        autonomous: bool = False,
        payment_amount: int = DEFAULT_MINT_PAYMENT_MICROALGOS,
    ) -> bytes:
        if not self.registry_app_id:
            raise ValueError("registry_app_id not set")
        if trust_models > 0x0F:
            raise ValueError("trust_models bitmap must be in [0, 15]")
        if not 0 <= intelligence_level <= 100:
            raise ValueError("intelligence_level must be 0..100")

        skills_str = ",".join(skills or [])
        directive = directive_address or ("\x00" * 32)
        registry_address = self._app_address(self.registry_app_id)

        composer = self.algorand.new_group()
        payment = composer.add_payment(
            PaymentParams(
                sender=self.signer.address,
                receiver=registry_address,
                amount=payment_amount,
                signer=self.signer,
            )
        )
        composer.add_app_call_method_call(
            {
                "app_id": self.registry_app_id,
                "method": "register",
                "args": [
                    nft_app_id,
                    asset_id,
                    mcp_endpoint,
                    a2a_endpoint,
                    directive,
                    website,
                    trust_models,
                    skills_str,
                    intelligence_level,
                    autonomous,
                    payment,
                ],
                "sender": self.signer.address,
                "signer": self.signer,
            }
        )
        result = composer.send()
        return result.returns[-1].return_value

    # ─── mindX bridge ──────────────────────────────────────────────────
    def mindx_subscribe(
        self, plan: MindXPlan, payment_microalgos: int = 0
    ) -> int:
        if not self.mindx_app_id:
            raise ValueError("mindx_app_id not set")
        mindx_address = self._app_address(self.mindx_app_id)

        composer = self.algorand.new_group()
        payment = composer.add_payment(
            PaymentParams(
                sender=self.signer.address,
                receiver=mindx_address,
                amount=payment_microalgos,
                signer=self.signer,
            )
        )
        composer.add_app_call_method_call(
            {
                "app_id": self.mindx_app_id,
                "method": "subscribe",
                "args": [int(plan), payment],
                "sender": self.signer.address,
                "signer": self.signer,
            }
        )
        result = composer.send()
        return int(result.returns[-1].return_value)

    def mindx_request_behavior_evaluation(self, behavior_cid: str) -> bytes:
        result = self._call(
            self.mindx_app_id,
            "request_behavior_evaluation",
            [behavior_cid],
        )
        return result.returns[-1].return_value

    def mindx_request_attestation(self, subject_hash: bytes) -> bytes:
        if len(subject_hash) != 32:
            raise ValueError("subject_hash must be exactly 32 bytes")
        result = self._call(
            self.mindx_app_id,
            "request_attestation",
            [subject_hash],
        )
        return result.returns[-1].return_value

    def mindx_deliver_behavior_score(
        self, *, job_id: bytes, score: int
    ) -> str:
        """Oracle-only: deliver a behavior score to the mindX bridge."""
        if not 0 <= score <= 100:
            raise ValueError("score must be 0..100")
        return self._call(
            self.mindx_app_id,
            "deliver_behavior_score",
            [job_id, score],
        ).tx_id

    def registry_deliver_mindx_result(
        self,
        *,
        nft_app_id: int,
        asset_id: int,
        score: int,
        passed: bool,
    ) -> str:
        """Oracle-only: push a mindX verification result to the registry."""
        if not 0 <= score <= 100:
            raise ValueError("score must be 0..100")
        return self._call(
            self.registry_app_id,
            "deliver_mindx_result",
            [nft_app_id, asset_id, score, passed],
        ).tx_id

    # ─── PAIMINT ───────────────────────────────────────────────────────
    def paimint_opt_in(self, asset_id: int) -> str:
        return self.algorand.send.asset_opt_in(
            AssetOptInParams(
                sender=self.signer.address,
                asset_id=asset_id,
                signer=self.signer,
            )
        ).tx_id

    def paimint_balance_of(self, user_address: str) -> int:
        if not self.paimint_app_id:
            raise ValueError("paimint_app_id not set")
        result = self._call(
            self.paimint_app_id, "balance_of", [user_address]
        )
        return int(result.returns[-1].return_value)

    def paimint_reward(
        self, user_address: str, amount: int, reason: str
    ) -> str:
        if not self.paimint_app_id:
            raise ValueError("paimint_app_id not set")
        if amount <= 0:
            raise ValueError("amount must be positive")
        if len(reason.encode("utf-8")) > 64:
            raise ValueError("reason too long (max 64 bytes)")
        return self._call(
            self.paimint_app_id, "reward", [user_address, amount, reason]
        ).tx_id

    def paimint_burn_for_operation(
        self, user_address: str, amount: int, operation: str
    ) -> str:
        """Charger-only. Requires the user to have approved the charger first."""
        if not self.paimint_app_id:
            raise ValueError("paimint_app_id not set")
        if amount <= 0:
            raise ValueError("amount must be positive")
        if len(operation.encode("utf-8")) > 64:
            raise ValueError("operation label too long (max 64 bytes)")
        return self._call(
            self.paimint_app_id,
            "burn_for_operation",
            [user_address, amount, operation],
        ).tx_id

    def paimint_approve_charger(
        self, charger_address: str, amount: int
    ) -> str:
        """User-side: approve a charger to burn up to `amount` PAIMINT."""
        if not self.paimint_app_id:
            raise ValueError("paimint_app_id not set")
        if amount < 0:
            raise ValueError("amount must be non-negative")
        return self._call(
            self.paimint_app_id,
            "approve_charger",
            [charger_address, amount],
        ).tx_id

    def paimint_revoke_charger_approval(
        self, charger_address: str
    ) -> str:
        """User-side: revoke all allowance to a charger."""
        return self._call(
            self.paimint_app_id,
            "revoke_charger_approval",
            [charger_address],
        ).tx_id

    def paimint_allowance_of(
        self, user_address: str, charger_address: str
    ) -> int:
        result = self._call(
            self.paimint_app_id,
            "allowance_of",
            [user_address, charger_address],
        )
        return int(result.returns[-1].return_value)

    # ─── x402 ──────────────────────────────────────────────────────────
    @staticmethod
    def x402_build_receipt(
        *,
        payer_address: str,
        amount_microalgos: int,
        algo_round: int,
        algo_tx_id: bytes,
        expires_at: int,
        purpose: str,
        nonce: int,
        algo_asset: int = 0,
    ) -> X402Receipt:
        if len(algo_tx_id) != 32:
            raise ValueError("algo_tx_id must be exactly 32 bytes")
        purpose_hash = hashlib.sha256(purpose.encode("utf-8")).digest()
        return X402Receipt(
            payer=payer_address,
            algo_asset=algo_asset,
            amount=amount_microalgos,
            algo_round=algo_round,
            algo_tx_id=algo_tx_id,
            expires_at=expires_at,
            purpose=purpose_hash,
            nonce=nonce,
        )

    def x402_verify_and_consume(
        self,
        *,
        receipt: X402Receipt,
        payer_signature: bytes,
        expected_payer: str,
    ) -> bytes:
        if not self.x402_app_id:
            raise ValueError("x402_app_id not set")
        if len(payer_signature) != 64:
            raise ValueError("payer_signature must be 64 bytes (ed25519)")

        result = self._call(
            self.x402_app_id,
            "verify_and_consume",
            [receipt.as_abi_tuple(), payer_signature, expected_payer],
        )
        return result.returns[-1].return_value

    def x402_is_consumed(self, receipt: X402Receipt) -> bool:
        result = self._call(
            self.x402_app_id, "is_consumed", [receipt.as_abi_tuple()]
        )
        return bool(result.returns[-1].return_value)

    @staticmethod
    def x402_compute_digest(receipt: X402Receipt) -> bytes:
        """Compute the canonical digest the payer signs.

        This must match the on-chain `sha256(receipt.bytes)`. The off-chain
        ABI encoding of the receipt struct is the concatenation of fields
        in declared order, with DynamicBytes prefixed by 2-byte length.
        """
        from algosdk import encoding

        # Encode each field in order matching the on-chain Receipt struct.
        # Static fields first (address 32B + 4× uint64), then dynamic offsets,
        # then dynamic data (algo_tx_id, purpose).
        # For simplicity we use algosdk's ABI encoder.
        try:
            from algosdk.abi import (
                ABIType,
                AddressType,
                ByteType,
                TupleType,
                UintType,
            )
        except ImportError as e:
            raise RuntimeError(
                "algosdk required for x402_compute_digest"
            ) from e

        receipt_type = TupleType(
            [
                AddressType(),
                UintType(64),
                UintType(64),
                UintType(64),
                ABIType.from_string("byte[]"),
                UintType(64),
                ABIType.from_string("byte[]"),
                UintType(64),
            ]
        )
        encoded = receipt_type.encode(list(receipt.as_abi_tuple()))
        return hashlib.sha256(encoded).digest()

    # ─── mindX oracle-side ─────────────────────────────────────────────
    def mindx_deliver_attestation(
        self,
        *,
        job_id: bytes,
        consciousness_level: int,
        ataraxia_score: int,
        fingerprint: bytes,
        dimensions: int,
    ) -> str:
        """Oracle-only: deliver a consciousness attestation to mindX."""
        if not 0 <= consciousness_level <= 100:
            raise ValueError("consciousness_level must be 0..100")
        if not 0 <= ataraxia_score <= 100:
            raise ValueError("ataraxia_score must be 0..100")
        if dimensions not in (768, 1024):
            raise ValueError("dimensions must be 768 or 1024")
        return self._call(
            self.mindx_app_id,
            "deliver_attestation",
            [job_id, consciousness_level, ataraxia_score, fingerprint, dimensions],
        ).tx_id
