# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# Invariant tests for the AgenticPlace Algorand stack (v1.3).
#
# Pure-Python tests against the constants module and the frontend helper.
# Run with: pytest tests/ -vv

from __future__ import annotations

import hashlib
from unittest.mock import MagicMock

import pytest

from smart_contracts.common.constants import (
    AGENT_TYPE_ANALYTICAL_PROCESSING,
    AGENT_TYPE_COGNITIVE_AUGMENTATION,
    ASSET_MBR_MICROALGOS,
    BOX_MBR_BUFFER_MICROALGOS,
    ED25519_PUBKEY_LENGTH,
    ED25519_SIGNATURE_LENGTH,
    KIND_ANFT,
    KIND_DNFT,
    KIND_INFT,
    KIND_THOT,
    MAX_ASSET_NAME,
    MAX_INTELLIGENCE_LEVEL,
    MAX_NOTE_LENGTH,
    MAX_REASON_LENGTH,
    MAX_UNIT_NAME,
    MIN_MINT_PAYMENT,
    MINDX_JOB_COMPLETE,
    MINDX_JOB_FAILED,
    MINDX_JOB_PENDING,
    MINDX_PASS_THRESHOLD,
    MINDX_PLAN_ENTERPRISE,
    MINDX_PLAN_FREE,
    MINDX_PLAN_PRO,
    MINDX_PLAN_STANDARD,
    PROTOCOL_MINT_FEE_MICROALGOS,
    SUBSCRIPTION_DURATION_SECONDS,
    THOT_DIM_64,
    THOT_DIM_384,
    THOT_DIM_512,
    THOT_DIM_768,
    THOT_DIM_1024,
    TRUST_BITMAP_MAX,
    TRUST_CRYPTO_ECONOMIC,
    TRUST_REPUTATION,
    TRUST_TEE,
    TRUST_ZKML,
)


# ─── NFT kind discriminators ───────────────────────────────────────────
class TestKindDiscriminators:
    def test_each_kind_is_4_bytes(self) -> None:
        assert len(KIND_ANFT) == 4
        assert len(KIND_DNFT) == 4
        assert len(KIND_INFT) == 4
        assert len(KIND_THOT) == 4

    def test_kinds_are_unique(self) -> None:
        assert len({KIND_ANFT, KIND_DNFT, KIND_INFT, KIND_THOT}) == 4

    def test_kinds_match_register_form(self) -> None:
        assert KIND_ANFT == b"aNFT"
        assert KIND_DNFT == b"dNFT"
        assert KIND_INFT == b"iNFT"
        assert KIND_THOT == b"THOT"


# ─── THOT dimensions ────────────────────────────────────────────────────
class TestThotDimensions:
    @pytest.mark.parametrize(
        "dim",
        [THOT_DIM_64, THOT_DIM_384, THOT_DIM_512, THOT_DIM_768, THOT_DIM_1024],
    )
    def test_supported_dimension_values(self, dim: int) -> None:
        assert dim in {64, 384, 512, 768, 1024}

    def test_1024_is_in_supported_set(self) -> None:
        assert 1024 in {THOT_DIM_64, THOT_DIM_384, THOT_DIM_512, THOT_DIM_768, THOT_DIM_1024}

    def test_register_form_dims_all_present(self) -> None:
        supported = {THOT_DIM_64, THOT_DIM_384, THOT_DIM_512, THOT_DIM_768, THOT_DIM_1024}
        for dim in (64, 384, 512, 768):
            assert dim in supported


# ─── Trust bitmap ───────────────────────────────────────────────────────
class TestTrustBitmap:
    def test_bitmap_max(self) -> None:
        assert TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC | TRUST_TEE | TRUST_ZKML == 0x0F
        assert TRUST_BITMAP_MAX == 0x0F

    def test_individual_flags(self) -> None:
        assert TRUST_REPUTATION == 1
        assert TRUST_CRYPTO_ECONOMIC == 2
        assert TRUST_TEE == 4
        assert TRUST_ZKML == 8

    def test_register_form_default_combo(self) -> None:
        active = TRUST_REPUTATION | TRUST_CRYPTO_ECONOMIC
        assert active == 0b11
        assert active <= TRUST_BITMAP_MAX


# ─── Register form field constraints ────────────────────────────────────
class TestFormConstraints:
    def test_unit_name_max_8_chars(self) -> None:
        assert MAX_UNIT_NAME == 8

    def test_asset_name_max_32_chars(self) -> None:
        assert MAX_ASSET_NAME == 32

    def test_intelligence_level_0_to_100(self) -> None:
        assert MAX_INTELLIGENCE_LEVEL == 100

    def test_note_under_algorand_limit(self) -> None:
        assert MAX_NOTE_LENGTH < 1024
        assert MAX_NOTE_LENGTH == 1000

    def test_min_mint_payment_covers_mbr(self) -> None:
        assert MIN_MINT_PAYMENT == (
            PROTOCOL_MINT_FEE_MICROALGOS + ASSET_MBR_MICROALGOS + BOX_MBR_BUFFER_MICROALGOS
        )
        assert MIN_MINT_PAYMENT >= 200_000


# ─── mindX constants ────────────────────────────────────────────────────
class TestMindX:
    def test_pass_threshold_in_range(self) -> None:
        assert 0 < MINDX_PASS_THRESHOLD <= 100
        assert MINDX_PASS_THRESHOLD == 70

    def test_job_statuses_unique(self) -> None:
        assert len({MINDX_JOB_PENDING, MINDX_JOB_COMPLETE, MINDX_JOB_FAILED}) == 3

    def test_plans_unique(self) -> None:
        assert len({MINDX_PLAN_FREE, MINDX_PLAN_STANDARD, MINDX_PLAN_PRO, MINDX_PLAN_ENTERPRISE}) == 4

    def test_subscription_duration_30_days(self) -> None:
        assert SUBSCRIPTION_DURATION_SECONDS == 30 * 24 * 60 * 60


# ─── PAIMINT constants ──────────────────────────────────────────────────
class TestPaimint:
    def test_max_reason_length(self) -> None:
        assert MAX_REASON_LENGTH == 64


# ─── Ed25519 constants ──────────────────────────────────────────────────
class TestEd25519:
    def test_signature_length(self) -> None:
        assert ED25519_SIGNATURE_LENGTH == 64

    def test_pubkey_length(self) -> None:
        assert ED25519_PUBKEY_LENGTH == 32


# ─── Frontend helper ────────────────────────────────────────────────────
class TestFrontendHelperEnums:
    def test_agent_type_values_match_constants(self) -> None:
        from frontend_helper.agentic_client import AgentType

        assert AgentType.COGNITIVE_AUGMENTATION == AGENT_TYPE_COGNITIVE_AUGMENTATION
        assert AgentType.ANALYTICAL_PROCESSING == AGENT_TYPE_ANALYTICAL_PROCESSING

    def test_trust_model_flag_values(self) -> None:
        from frontend_helper.agentic_client import TrustModel

        assert TrustModel.REPUTATION == TRUST_REPUTATION
        assert TrustModel.CRYPTO_ECONOMIC == TRUST_CRYPTO_ECONOMIC
        assert TrustModel.TEE == TRUST_TEE
        assert TrustModel.ZKML == TRUST_ZKML

    def test_mindx_plan_values(self) -> None:
        from frontend_helper.agentic_client import MindXPlan

        assert MindXPlan.FREE == MINDX_PLAN_FREE
        assert MindXPlan.STANDARD == MINDX_PLAN_STANDARD
        assert MindXPlan.PRO == MINDX_PLAN_PRO
        assert MindXPlan.ENTERPRISE == MINDX_PLAN_ENTERPRISE

    def test_supported_thot_dimensions_includes_1024(self) -> None:
        from frontend_helper.agentic_client import SUPPORTED_THOT_DIMENSIONS

        assert SUPPORTED_THOT_DIMENSIONS == frozenset({64, 384, 512, 768, 1024})


class TestArc69Metadata:
    def test_serializes_to_compact_json(self) -> None:
        from frontend_helper.agentic_client import AgentType, Arc69Metadata

        blob = Arc69Metadata(
            description="hello",
            agent_type=AgentType.COGNITIVE_AUGMENTATION,
        ).to_json_bytes()
        assert b'"standard":"arc69"' in blob
        assert b'"description":"hello"' in blob
        assert b'"agent_type":"COGNITIVE_AUGMENTATION"' in blob
        # Compact: no spaces between separators
        assert b": " not in blob

    def test_includes_custom_properties(self) -> None:
        from frontend_helper.agentic_client import AgentType, Arc69Metadata

        blob = Arc69Metadata(
            description="x",
            agent_type=AgentType.ANALYTICAL_PROCESSING,
            properties={"intelligence_level": 75, "autonomous": True},
        ).to_json_bytes()
        assert b'"intelligence_level":75' in blob
        assert b'"autonomous":true' in blob


class TestThotMintValidation:
    def test_rejects_unsupported_dimension(self) -> None:
        from frontend_helper.agentic_client import (
            AgenticPlaceClient,
            AgentType,
        )

        client = AgenticPlaceClient(
            algorand=MagicMock(),
            signer=MagicMock(),
            thot_app_id=12345,
        )
        with pytest.raises(ValueError, match="unsupported dimensions"):
            client.mint_thot(
                name="x",
                unit_name="X",
                agent_type=AgentType.ANALYTICAL_PROCESSING,
                description="x",
                data_cid="QmX",
                dimensions=256,
            )

    def test_rejects_wrong_tensor_hash_length(self) -> None:
        from frontend_helper.agentic_client import (
            AgenticPlaceClient,
            AgentType,
        )

        client = AgenticPlaceClient(
            algorand=MagicMock(),
            signer=MagicMock(),
            thot_app_id=12345,
        )
        with pytest.raises(ValueError, match="tensor_hash must be exactly 32 bytes"):
            client.mint_thot(
                name="x",
                unit_name="X",
                agent_type=AgentType.ANALYTICAL_PROCESSING,
                description="x",
                data_cid="QmX",
                dimensions=768,
                tensor_hash=b"short",
            )


class TestX402ReceiptBuilder:
    def test_builds_valid_receipt(self) -> None:
        from frontend_helper.agentic_client import AgenticPlaceClient

        tx_id_32 = bytes(32)
        r = AgenticPlaceClient.x402_build_receipt(
            payer_address="ALICE" * 11 + "A",  # placeholder 56 chars
            amount_microalgos=1_000_000,
            algo_round=1000,
            algo_tx_id=tx_id_32,
            expires_at=99999,
            purpose="thot.publish",
            nonce=42,
        )
        assert r.amount == 1_000_000
        assert len(r.algo_tx_id) == 32
        assert r.purpose == hashlib.sha256(b"thot.publish").digest()
        assert r.nonce == 42

    def test_rejects_wrong_txid_length(self) -> None:
        from frontend_helper.agentic_client import AgenticPlaceClient

        with pytest.raises(ValueError, match="algo_tx_id must be exactly 32 bytes"):
            AgenticPlaceClient.x402_build_receipt(
                payer_address="x",
                amount_microalgos=1,
                algo_round=1,
                algo_tx_id=b"short",
                expires_at=1,
                purpose="x",
                nonce=1,
            )


class TestPaimintHelperValidation:
    def test_reward_rejects_long_reason(self) -> None:
        from frontend_helper.agentic_client import AgenticPlaceClient

        client = AgenticPlaceClient(
            algorand=MagicMock(), signer=MagicMock(), paimint_app_id=1
        )
        with pytest.raises(ValueError, match="reason too long"):
            client.paimint_reward("user_address", 1_000_000, "x" * 65)

    def test_burn_rejects_long_operation(self) -> None:
        from frontend_helper.agentic_client import AgenticPlaceClient

        client = AgenticPlaceClient(
            algorand=MagicMock(), signer=MagicMock(), paimint_app_id=1
        )
        with pytest.raises(ValueError, match="operation label too long"):
            client.paimint_burn_for_operation("user", 1, "x" * 65)

    def test_approve_rejects_negative(self) -> None:
        from frontend_helper.agentic_client import AgenticPlaceClient

        client = AgenticPlaceClient(
            algorand=MagicMock(), signer=MagicMock(), paimint_app_id=1
        )
        with pytest.raises(ValueError, match="amount must be non-negative"):
            client.paimint_approve_charger("charger", -1)
