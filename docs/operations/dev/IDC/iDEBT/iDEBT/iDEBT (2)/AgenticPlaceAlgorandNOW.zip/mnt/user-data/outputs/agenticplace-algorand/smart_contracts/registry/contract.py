# Copyright (c) 2026 BANKON / Professor Codephreak
# SPDX-License-Identifier: MIT OR Apache-2.0
#
# AgenticPlaceRegistry — Algorand binding directory   v1.3
#
# Binds any Algorand NFT (minted by these contracts or any third-party ASA)
# to protocol endpoints, trust model, skills, and mindX verification status.
#
# AUDIT v1.3 fixes:
#   - CRITICAL: Replaced fragile "call mindX and parse return bytes" approach
#     with "caller supplies mindX job_id, registry verifies it via typed
#     inner call or a separate delivery pattern". The registry now uses a
#     simpler pattern: the mindX oracle directly delivers verification
#     results to the registry via `deliver_mindx_result()`, which is the
#     same pattern mindX already uses for attestations. This is safer and
#     doesn't depend on brittle ABI return parsing.
#   - close_remainder_to assertion on all payments
#   - Explicit box existence checks before read/write
#   - Trust bitmap validation tightened

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
)

from smart_contracts.common.constants import (
    MIN_MINT_PAYMENT,
    TRUST_BITMAP_MAX,
)


# ─── Events ───────────────────────────────────────────────────────────────
class AgentRegistered(arc4.Struct):
    nft_app_id: arc4.UInt64
    asset_id: arc4.UInt64
    owner: arc4.Address
    intelligence_level: arc4.UInt8
    autonomous: arc4.Bool


class AgentUpdated(arc4.Struct):
    nft_app_id: arc4.UInt64
    asset_id: arc4.UInt64
    updated_at: arc4.UInt64


class AgentDeactivated(arc4.Struct):
    nft_app_id: arc4.UInt64
    asset_id: arc4.UInt64


class MindXVerificationDelivered(arc4.Struct):
    nft_app_id: arc4.UInt64
    asset_id: arc4.UInt64
    score: arc4.UInt8
    passed: arc4.Bool


# ─── Box record ───────────────────────────────────────────────────────────
class AgentBinding(arc4.Struct):
    nft_app_id: arc4.UInt64
    asset_id: arc4.UInt64
    owner: arc4.Address
    mcp_endpoint: arc4.String
    a2a_endpoint: arc4.String
    directive: arc4.Address
    website: arc4.String
    trust_models: arc4.UInt8
    skills: arc4.String
    intelligence_level: arc4.UInt8
    autonomous: arc4.Bool
    registered_at: arc4.UInt64
    updated_at: arc4.UInt64
    active: arc4.Bool
    mindx_score: arc4.UInt8
    mindx_verified: arc4.Bool
    mindx_verified_at: arc4.UInt64


class AgenticPlaceRegistry(ARC4Contract):
    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.mint_fee = GlobalState(UInt64)
        self.total_bindings = GlobalState(UInt64)

        # Configured mindX bridge app id (0 = not set).
        self.mindx_app_id = GlobalState(UInt64)
        # Configured mindX oracle address — only this account can deliver
        # verification results. Mirrored from the MindXBridge's oracle.
        self.mindx_oracle = GlobalState(Account)

        # (nft_app_id || asset_id) → AgentBinding
        self.bindings = BoxMap(Bytes, AgentBinding, key_prefix=b"bd")

    @arc4.abimethod(create="require")
    def create(self) -> None:
        self.admin.value = Txn.sender
        self.mint_fee.value = UInt64(MIN_MINT_PAYMENT)
        self.total_bindings.value = UInt64(0)
        self.mindx_app_id.value = UInt64(0)
        self.mindx_oracle.value = Global.zero_address

    # ─── admin ─────────────────────────────────────────────────────────
    @arc4.abimethod
    def set_mint_fee(self, new_fee: arc4.UInt64) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.mint_fee.value = new_fee.native

    @arc4.abimethod
    def set_admin(self, new_admin: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin.native

    @arc4.abimethod
    def set_mindx(
        self, app_id: arc4.UInt64, oracle: arc4.Address
    ) -> None:
        """Configure the mindX bridge app + its oracle address (admin only)."""
        assert Txn.sender == self.admin.value, "admin only"
        self.mindx_app_id.value = app_id.native
        self.mindx_oracle.value = oracle.native

    @arc4.abimethod
    def withdraw(self, amount: arc4.UInt64, receiver: arc4.Address) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        itxn.Payment(
            receiver=receiver.native,
            amount=amount.native,
            fee=0,
        ).submit()

    # ─── helper ────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def binding_key(
        self, nft_app_id: arc4.UInt64, asset_id: arc4.UInt64
    ) -> arc4.DynamicBytes:
        return arc4.DynamicBytes(
            op.itob(nft_app_id.native) + op.itob(asset_id.native)
        )

    # ─── register ──────────────────────────────────────────────────────
    @arc4.abimethod
    def register(
        self,
        nft_app_id: arc4.UInt64,
        asset: Asset,
        mcp_endpoint: arc4.String,
        a2a_endpoint: arc4.String,
        directive: arc4.Address,
        website: arc4.String,
        trust_models: arc4.UInt8,
        skills: arc4.String,
        intelligence_level: arc4.UInt8,
        autonomous: arc4.Bool,
        payment: gtxn.PaymentTransaction,
    ) -> arc4.DynamicBytes:
        assert (
            payment.receiver == Global.current_application_address
        ), "payment receiver must be application"
        assert payment.amount >= self.mint_fee.value, "payment below mint_fee"
        assert payment.sender == Txn.sender, "payment sender mismatch"
        assert payment.close_remainder_to == Global.zero_address, "close not allowed"

        assert (
            trust_models.native <= UInt64(TRUST_BITMAP_MAX)
        ), "invalid trust bitmap"
        assert (
            intelligence_level.native <= UInt64(100)
        ), "intelligence_level > 100"

        # Auth gate: caller must currently hold the ASA.
        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        key = op.itob(nft_app_id.native) + op.itob(asset.id)
        assert key not in self.bindings, "already registered"

        self.bindings[key] = AgentBinding(
            nft_app_id=nft_app_id,
            asset_id=arc4.UInt64(asset.id),
            owner=arc4.Address(Txn.sender),
            mcp_endpoint=mcp_endpoint,
            a2a_endpoint=a2a_endpoint,
            directive=directive,
            website=website,
            trust_models=trust_models,
            skills=skills,
            intelligence_level=intelligence_level,
            autonomous=autonomous,
            registered_at=arc4.UInt64(Global.latest_timestamp),
            updated_at=arc4.UInt64(Global.latest_timestamp),
            active=arc4.Bool(True),  # noqa: FBT003
            mindx_score=arc4.UInt8(0),
            mindx_verified=arc4.Bool(False),  # noqa: FBT003
            mindx_verified_at=arc4.UInt64(0),
        )

        self.total_bindings.value = self.total_bindings.value + UInt64(1)

        arc4.emit(
            AgentRegistered(
                nft_app_id=nft_app_id,
                asset_id=arc4.UInt64(asset.id),
                owner=arc4.Address(Txn.sender),
                intelligence_level=intelligence_level,
                autonomous=autonomous,
            )
        )
        return arc4.DynamicBytes(key)

    @arc4.abimethod
    def update(
        self,
        nft_app_id: arc4.UInt64,
        asset: Asset,
        mcp_endpoint: arc4.String,
        a2a_endpoint: arc4.String,
        directive: arc4.Address,
        website: arc4.String,
        trust_models: arc4.UInt8,
        skills: arc4.String,
        intelligence_level: arc4.UInt8,
        autonomous: arc4.Bool,
    ) -> None:
        assert (
            trust_models.native <= UInt64(TRUST_BITMAP_MAX)
        ), "invalid trust bitmap"
        assert (
            intelligence_level.native <= UInt64(100)
        ), "intelligence_level > 100"

        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        key = op.itob(nft_app_id.native) + op.itob(asset.id)
        assert key in self.bindings, "binding not found"

        rec = self.bindings[key].copy()
        rec.owner = arc4.Address(Txn.sender)
        rec.mcp_endpoint = mcp_endpoint
        rec.a2a_endpoint = a2a_endpoint
        rec.directive = directive
        rec.website = website
        rec.trust_models = trust_models
        rec.skills = skills
        rec.intelligence_level = intelligence_level
        rec.autonomous = autonomous
        rec.updated_at = arc4.UInt64(Global.latest_timestamp)
        self.bindings[key] = rec.copy()

        arc4.emit(
            AgentUpdated(
                nft_app_id=nft_app_id,
                asset_id=arc4.UInt64(asset.id),
                updated_at=arc4.UInt64(Global.latest_timestamp),
            )
        )

    @arc4.abimethod
    def deactivate(self, nft_app_id: arc4.UInt64, asset: Asset) -> None:
        balance, exists = op.AssetHoldingGet.asset_balance(Txn.sender, asset.id)
        assert exists, "caller not opted into asset"
        assert balance == UInt64(1), "caller is not the asset holder"

        key = op.itob(nft_app_id.native) + op.itob(asset.id)
        assert key in self.bindings, "binding not found"

        rec = self.bindings[key].copy()
        rec.active = arc4.Bool(False)  # noqa: FBT003
        rec.updated_at = arc4.UInt64(Global.latest_timestamp)
        self.bindings[key] = rec.copy()

        arc4.emit(
            AgentDeactivated(
                nft_app_id=nft_app_id,
                asset_id=arc4.UInt64(asset.id),
            )
        )

    # ─── mindX verification (oracle-delivered, not inner-call-parsed) ──
    @arc4.abimethod
    def deliver_mindx_result(
        self,
        nft_app_id: arc4.UInt64,
        asset_id: arc4.UInt64,
        score: arc4.UInt8,
        passed: arc4.Bool,
    ) -> None:
        """Oracle-only: stamp a mindX verification result on a binding.

        This is the safe version of the v1.2 `verify_via_mindx` pattern.
        Instead of the registry calling mindX via inner app call and parsing
        return bytes (which is fragile), we flip the direction: the mindX
        oracle (the same account that delivers results to MindXBridge) also
        delivers them to the registry. This matches the oracle pattern
        already established for attestations and behavior evaluations.

        Trust model: the oracle can only WRITE scores. It cannot register
        new bindings, deactivate existing ones, or alter any non-mindX
        fields. If the oracle is compromised, at worst it can publish
        false mindX scores — the NFT ownership and endpoints are safe.
        """
        assert (
            Txn.sender == self.mindx_oracle.value
        ), "not the configured mindX oracle"
        assert self.mindx_oracle.value != Global.zero_address, "mindX not configured"
        assert score.native <= UInt64(100), "score > 100"

        key = op.itob(nft_app_id.native) + op.itob(asset_id.native)
        assert key in self.bindings, "binding not found"

        rec = self.bindings[key].copy()
        rec.mindx_score = score
        rec.mindx_verified = passed
        rec.mindx_verified_at = arc4.UInt64(Global.latest_timestamp)
        self.bindings[key] = rec.copy()

        arc4.emit(
            MindXVerificationDelivered(
                nft_app_id=nft_app_id,
                asset_id=arc4.UInt64(asset_id.native),
                score=score,
                passed=passed,
            )
        )

    # ─── views ─────────────────────────────────────────────────────────
    @arc4.abimethod(readonly=True)
    def get_binding(
        self, nft_app_id: arc4.UInt64, asset_id: arc4.UInt64
    ) -> AgentBinding:
        key = op.itob(nft_app_id.native) + op.itob(asset_id.native)
        return self.bindings[key]

    @arc4.abimethod(readonly=True)
    def is_registered(
        self, nft_app_id: arc4.UInt64, asset_id: arc4.UInt64
    ) -> arc4.Bool:
        key = op.itob(nft_app_id.native) + op.itob(asset_id.native)
        if key in self.bindings:
            return arc4.Bool(True)  # noqa: FBT003
        return arc4.Bool(False)  # noqa: FBT003
