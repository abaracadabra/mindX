"""
Test Suite — Perpetual Engine
================================

Tests the leveraged perp engine: position lifecycle, PnL computation,
funding rate accrual per-timestamp, insurance fund draws, and liquidation.
"""

from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, UInt64, arc4
import pytest

from contracts.stage2_derivatives.perpetual_engine import (
    PerpetualEngine,
    Position,
)


class TestPerpetualEngine:
    """Perpetual engine position mechanics."""

    def _setup(self, ctx: AlgopyTestContext) -> PerpetualEngine:
        admin = ctx.default_sender
        perp = PerpetualEngine()
        perp.create(
            admin=admin,
            stablecoin_asset_id=UInt64(100),
            oracle_app_id=UInt64(200),
        )
        return perp

    def test_create_initializes(self) -> None:
        with algopy_testing_context() as ctx:
            perp = self._setup(ctx)
            assert perp.stablecoin_asset_id.value == UInt64(100)
            assert perp.oracle_app_id.value == UInt64(200)

    def test_max_leverage_is_20(self) -> None:
        with algopy_testing_context() as ctx:
            perp = self._setup(ctx)
            assert perp.MAX_LEVERAGE == UInt64(20)

    def test_maintenance_margin_is_5_percent(self) -> None:
        with algopy_testing_context() as ctx:
            perp = self._setup(ctx)
            assert perp.MAINTENANCE_MARGIN_BPS == UInt64(500)

    def test_insurance_fund_starts_zero(self) -> None:
        with algopy_testing_context() as ctx:
            perp = self._setup(ctx)
            assert perp.insurance_fund.value == UInt64(0)

    def test_open_interest_starts_zero(self) -> None:
        with algopy_testing_context() as ctx:
            perp = self._setup(ctx)
            assert perp.long_oi_usd.value == UInt64(0)
            assert perp.short_oi_usd.value == UInt64(0)

    def test_funding_rate_configurable(self) -> None:
        with algopy_testing_context() as ctx:
            perp = self._setup(ctx)
            perp.set_funding_rate(UInt64(300))  # 3% annual
            assert perp.funding_rate_bps.value == UInt64(300)

    def test_pause_unpause(self) -> None:
        with algopy_testing_context() as ctx:
            perp = self._setup(ctx)
            perp.pause()
            assert perp.paused.value == UInt64(1)
            perp.unpause()
            assert perp.paused.value == UInt64(0)
