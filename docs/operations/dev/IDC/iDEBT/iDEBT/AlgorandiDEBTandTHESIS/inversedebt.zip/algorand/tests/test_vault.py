"""
Test Suite — Collateral Vault
================================

Tests the multi-asset vault: asset registration, deposit/borrow tracking,
interest accrual, liquidation with 50% close factor and 5% bonus, and
health factor computation.
"""

from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, UInt64, arc4
import pytest

from contracts.stage2_derivatives.collateral_vault import (
    CollateralVault,
    AssetConfig,
    UserDebt,
)


class TestCollateralVault:
    """Vault deposit, borrow, and liquidation mechanics."""

    def _setup(self, ctx: AlgopyTestContext) -> CollateralVault:
        admin = ctx.default_sender
        vault = CollateralVault()
        vault.create(
            admin=admin,
            stablecoin_asset_id=UInt64(100),
            oracle_app_id=UInt64(200),
        )
        return vault

    def test_create_initializes(self) -> None:
        with algopy_testing_context() as ctx:
            vault = self._setup(ctx)
            assert vault.stablecoin_asset_id.value == UInt64(100)
            assert vault.oracle_app_id.value == UInt64(200)

    def test_register_asset(self) -> None:
        with algopy_testing_context() as ctx:
            vault = self._setup(ctx)
            vault.register_asset(
                asset_id=UInt64(300),
                collateral_factor_bps=UInt64(8500),
                liquidation_threshold_bps=UInt64(9000),
                max_staleness=UInt64(7200),
            )
            # Verify registration stored.
            assert vault.asset_count.value >= UInt64(1)

    def test_borrow_rate_basis_points(self) -> None:
        with algopy_testing_context() as ctx:
            vault = self._setup(ctx)
            # Verify interest rate params exist.
            assert vault.interest_rate_bps.value >= UInt64(0)

    def test_close_factor_is_50_percent(self) -> None:
        with algopy_testing_context() as ctx:
            vault = self._setup(ctx)
            assert vault.CLOSE_FACTOR_BPS == UInt64(5000)

    def test_liquidation_bonus_is_5_percent(self) -> None:
        with algopy_testing_context() as ctx:
            vault = self._setup(ctx)
            assert vault.LIQUIDATION_BONUS_BPS == UInt64(500)

    def test_pause_unpause(self) -> None:
        with algopy_testing_context() as ctx:
            vault = self._setup(ctx)
            vault.pause()
            assert vault.paused.value == UInt64(1)
            vault.unpause()
            assert vault.paused.value == UInt64(0)
