"""
Test Suite — Inverse Debt Token (iDEBT) on Algorand
=====================================================

Tests the profit-from-loss mechanic: mint at baseline, update the
debasement index, burn for more or less stablecoin than deposited.
"""

from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, Asset, UInt64, arc4
import pytest

from contracts.stage2_derivatives.inverse_debt_token import (
    InverseDebtToken,
    MintPosition,
)


PRECISION = 1_000_000_000_000_000_000  # 1e18
USDC_SCALE = 1_000_000_000_000  # 1e12


class TestInverseDebtToken:
    """iDEBT mint/burn mechanics and profit recognition."""

    def _setup(self, ctx: AlgopyTestContext) -> InverseDebtToken:
        admin = ctx.default_sender
        idebt = InverseDebtToken()
        idebt.create(
            admin=admin,
            reporter=admin,
            stablecoin_asset_id=UInt64(100),  # mock USDC ASA
            mint_fee_bps=UInt64(30),   # 0.30%
            burn_fee_bps=UInt64(30),   # 0.30%
            reserve_share_bps=UInt64(5000),  # 50% of fees to reserve
            max_index_age=UInt64(21600),  # 6 hours
        )
        return idebt

    def test_create_sets_baseline_index(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            assert idebt.current_index_e18.value == UInt64(PRECISION)

    def test_update_index(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            new_index = PRECISION + PRECISION // 2  # 1.5
            idebt.update_index(UInt64(new_index))
            assert idebt.current_index_e18.value == UInt64(new_index)

    def test_redemption_value_at_baseline(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            # At baseline index (1.0), 10000 iDEBT units → ~9970 USDC (less 30bps)
            rv = idebt.redemption_value(UInt64(10_000_000_000))
            # gross = 10000e6, fee = 30bps → 9970e6 approx
            assert 9960_000_000 <= rv <= 9980_000_000

    def test_redemption_value_with_risen_index(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            # Index rises to 1.3 (30% debasement)
            idebt.update_index(UInt64(PRECISION + PRECISION * 3 // 10))
            rv = idebt.redemption_value(UInt64(10_000_000_000))
            # gross = 10000 * 1.3 = 13000, fee 30bps → ~12961
            assert rv > 12_900_000_000
            assert rv < 13_100_000_000

    def test_redemption_value_with_fallen_index(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            # Index falls to 0.7 (fiat strengthening)
            idebt.update_index(UInt64(PRECISION * 7 // 10))
            rv = idebt.redemption_value(UInt64(10_000_000_000))
            # gross = 10000 * 0.7 = 7000, fee 30bps → ~6979
            assert rv > 6_900_000_000
            assert rv < 7_100_000_000

    def test_fee_accounting(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            # Verify fee splits are correctly configured
            assert idebt.mint_fee_bps.value == UInt64(30)
            assert idebt.burn_fee_bps.value == UInt64(30)
            assert idebt.reserve_share_bps.value == UInt64(5000)

    def test_set_fees(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            idebt.set_fees(UInt64(50), UInt64(50), UInt64(6000))
            assert idebt.mint_fee_bps.value == UInt64(50)
            assert idebt.burn_fee_bps.value == UInt64(50)
            assert idebt.reserve_share_bps.value == UInt64(6000)

    def test_fee_cap_enforced(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            with pytest.raises(AssertionError, match="fee too high"):
                idebt.set_fees(UInt64(1500), UInt64(30), UInt64(5000))

    def test_pause_prevents_operations(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            idebt.pause()
            assert idebt.paused.value == UInt64(1)
            idebt.unpause()
            assert idebt.paused.value == UInt64(0)

    def test_admin_transfer(self) -> None:
        with algopy_testing_context() as ctx:
            idebt = self._setup(ctx)
            new_admin = ctx.any.account()
            idebt.transfer_admin(new_admin)
            assert idebt.admin.value == new_admin
