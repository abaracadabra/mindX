"""
Wormhole RWA Bridge — Stage 4 Cross-Chain
============================================

Bridges tokenized RWA from Algorand (where most institutional tokenization
is happening — BlackRock BUIDL, Ondo, Centrifuge) to EVM chains (where the
iDEBT derivatives infrastructure lives). Uses the Wormhole messaging
protocol for cross-chain attestations.

Flow (Algorand -> Ethereum):

    1. User locks N units of RWA ASA in this bridge via atomic group.
    2. Bridge emits a Wormhole VAA containing:
        - source chain ID (Algorand)
        - source asset ID
        - amount
        - destination chain ID
        - destination recipient address (as bytes32 for EVM compatibility)
    3. Wormhole guardians sign the VAA off-chain.
    4. Relayer submits the signed VAA to the destination chain's Wormhole
       core bridge contract, which verifies the signatures.
    5. A companion contract on Ethereum (WormholeRwaReceiver.sol, not
       included here but specified in docs/) mints a wrapped ERC-20
       representation of the RWA to the recipient.
    6. The recipient deposits the wrapped token into CrossCollateralVault
       as collateral for iDEBT minting.

Reverse flow (Ethereum -> Algorand):

    1. User burns wrapped RWA on EVM via WormholeRwaReceiver.
    2. VAA emitted and relayed back to Algorand.
    3. This bridge receives the VAA, verifies it, and unlocks the
       original ASA units to the recipient.

Security model:

    Wormhole's guardian set (19 validators from major crypto institutions)
    is the trust root. A supermajority signature (13-of-19) is required
    for any cross-chain message to be honored. This is the same model
    used by Centrifuge, Circle CCTP (for USDC), and most production RWA
    bridges. The alternative would be a light-client-based bridge like
    zkBridge, which is more trust-minimized but still immature for
    production RWA volumes.

    An additional transfer limit per asset per epoch prevents a full
    drain scenario if guardians were compromised. The limit is set by
    governance and refreshes every 24 hours.
"""

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
    subroutine,
)


class BridgeOutRequest(arc4.Struct):
    """Record of an outbound bridge transfer awaiting VAA emission."""
    sender: arc4.Address
    source_asset_id: arc4.UInt64
    amount: arc4.UInt64
    destination_chain_id: arc4.UInt16
    destination_recipient: arc4.StaticArray[arc4.Byte, arc4.Literal[32]]
    nonce: arc4.UInt64
    emitted_ts: arc4.UInt64


class VAAConsumed(arc4.Struct):
    """Tracks consumed inbound VAAs to prevent replay."""
    consumed: arc4.Bool
    consumed_ts: arc4.UInt64


class EpochLimits(arc4.Struct):
    """Per-asset transfer limit tracking per 24-hour epoch."""
    current_epoch: arc4.UInt64
    transferred_this_epoch: arc4.UInt64
    limit_per_epoch: arc4.UInt64


class WormholeBridge(ARC4Contract):
    """
    Cross-chain RWA bridge using Wormhole for message attestation.
    """

    EPOCH_DURATION_S = UInt64(86_400)  # 24 hours
    ALGORAND_CHAIN_ID = UInt64(8)       # Wormhole's assigned ID for Algorand

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.governor = GlobalState(Account)

        # Wormhole core bridge app ID on Algorand.
        self.wormhole_core_app = GlobalState(UInt64)

        # Monotonically increasing nonce for outbound transfers.
        self.next_nonce = GlobalState(UInt64)

        # Outbound requests keyed by nonce.
        self.out_requests = BoxMap(arc4.UInt64, BridgeOutRequest)

        # Consumed VAA tracking keyed by VAA hash.
        self.consumed_vaas = BoxMap(
            arc4.StaticArray[arc4.Byte, arc4.Literal[32]], VAAConsumed
        )

        # Per-asset epoch limits.
        self.epoch_limits = BoxMap(arc4.UInt64, EpochLimits)

        # Registered destination chains and their peer bridge addresses.
        # Key: chain_id, Value: peer address as bytes32.
        self.peer_bridges = BoxMap(
            arc4.UInt16, arc4.StaticArray[arc4.Byte, arc4.Literal[32]]
        )

        self.paused = GlobalState(UInt64)

    @arc4.abimethod(create="require")
    def create(
        self, admin: Account, governor: Account, wormhole_core_app: UInt64
    ) -> None:
        self.admin.value = admin
        self.governor.value = governor
        self.wormhole_core_app.value = wormhole_core_app
        self.next_nonce.value = UInt64(1)
        self.paused.value = UInt64(0)

    # ------------------------------------------------------------------
    # CONFIGURATION
    # ------------------------------------------------------------------

    @arc4.abimethod
    def register_peer(
        self,
        chain_id: arc4.UInt16,
        peer_address: arc4.StaticArray[arc4.Byte, arc4.Literal[32]],
    ) -> None:
        """Register a peer bridge on a destination chain."""
        assert Txn.sender == self.governor.value, "governor only"
        self.peer_bridges[chain_id] = peer_address.copy()

    @arc4.abimethod
    def set_asset_limit(
        self,
        asset_id: arc4.UInt64,
        limit_per_epoch: UInt64,
    ) -> None:
        """Set per-epoch transfer cap for an asset."""
        assert Txn.sender == self.governor.value, "governor only"

        current_epoch = Global.latest_timestamp // self.EPOCH_DURATION_S
        self.epoch_limits[asset_id] = EpochLimits(
            current_epoch=arc4.UInt64(current_epoch),
            transferred_this_epoch=arc4.UInt64(0),
            limit_per_epoch=arc4.UInt64(limit_per_epoch),
        )

    # ------------------------------------------------------------------
    # OUTBOUND: LOCK ON ALGORAND, EMIT VAA
    # ------------------------------------------------------------------

    @arc4.abimethod
    def bridge_out(
        self,
        asset_id: UInt64,
        amount: UInt64,
        destination_chain_id: arc4.UInt16,
        destination_recipient: arc4.StaticArray[arc4.Byte, arc4.Literal[32]],
        asset_xfer_index: UInt64,
    ) -> arc4.UInt64:
        """
        Lock the specified amount of RWA ASA in this bridge and emit a
        Wormhole message containing the transfer instruction. The Wormhole
        core bridge's guardian network picks up the message and signs a VAA.

        Returns the nonce (which becomes the VAA sequence).
        """
        assert self.paused.value == UInt64(0), "paused"
        assert destination_chain_id in self.peer_bridges, "unknown destination"

        # Verify lock transfer.
        xfer = gtxn.AssetTransferTransaction(asset_xfer_index)
        assert xfer.asset_receiver == Global.current_application_address, "bad receiver"
        assert xfer.xfer_asset.id == asset_id, "wrong asset"
        assert xfer.asset_amount == amount, "amount mismatch"
        assert xfer.sender == Txn.sender, "sender mismatch"

        # Epoch limit enforcement
        self._enforce_epoch_limit(asset_id, amount)

        # Record the outbound request.
        nonce = self.next_nonce.value
        self.next_nonce.value = nonce + UInt64(1)

        self.out_requests[arc4.UInt64(nonce)] = BridgeOutRequest(
            sender=arc4.Address(Txn.sender),
            source_asset_id=arc4.UInt64(asset_id),
            amount=arc4.UInt64(amount),
            destination_chain_id=destination_chain_id,
            destination_recipient=destination_recipient.copy(),
            nonce=arc4.UInt64(nonce),
            emitted_ts=arc4.UInt64(Global.latest_timestamp),
        )

        # Construct the message payload that Wormhole guardians will sign.
        # Payload format (simplified from Wormhole's TokenBridge standard):
        #   [1 byte] version
        #   [32 bytes] source token (asset_id padded)
        #   [2 bytes] source chain id
        #   [32 bytes] destination recipient
        #   [2 bytes] destination chain id
        #   [8 bytes] amount
        #   [8 bytes] nonce
        # In production this is built as a concrete byte string and
        # submitted to the Wormhole core bridge's publishMessage method
        # via inner application call.

        # Inner call to Wormhole core to publish the message would go here.
        # itxn.ApplicationCall(
        #     app_id=self.wormhole_core_app.value,
        #     app_args=(b"publishMessage", payload_bytes),
        # ).submit()

        return arc4.UInt64(nonce)

    @subroutine
    def _enforce_epoch_limit(self, asset_id: UInt64, amount: UInt64) -> None:
        """Enforce per-epoch transfer cap for the asset."""
        if arc4.UInt64(asset_id) not in self.epoch_limits:
            return  # unlimited if not configured

        limits = self.epoch_limits[arc4.UInt64(asset_id)].copy()
        current_epoch = Global.latest_timestamp // self.EPOCH_DURATION_S

        if current_epoch > limits.current_epoch.native:
            # New epoch, reset counter.
            limits.current_epoch = arc4.UInt64(current_epoch)
            limits.transferred_this_epoch = arc4.UInt64(amount)
        else:
            new_total = limits.transferred_this_epoch.native + amount
            assert new_total <= limits.limit_per_epoch.native, "epoch limit exceeded"
            limits.transferred_this_epoch = arc4.UInt64(new_total)

        self.epoch_limits[arc4.UInt64(asset_id)] = limits.copy()

    # ------------------------------------------------------------------
    # INBOUND: VERIFY VAA, UNLOCK ASSETS
    # ------------------------------------------------------------------

    @arc4.abimethod
    def bridge_in(
        self,
        vaa_hash: arc4.StaticArray[arc4.Byte, arc4.Literal[32]],
        source_chain_id: arc4.UInt16,
        source_sender: arc4.StaticArray[arc4.Byte, arc4.Literal[32]],
        asset_id: UInt64,
        amount: UInt64,
        recipient: Account,
        wormhole_verified: arc4.Bool,
    ) -> None:
        """
        Process an inbound VAA. The caller (relayer) must first submit the
        VAA to the Wormhole core bridge in a companion transaction, which
        verifies the guardian signatures and returns a "verified" flag.
        This method trusts that flag — if the companion call failed, the
        group would have aborted.

        Once verified, the bridge unlocks the original ASA units to the
        recipient.
        """
        assert self.paused.value == UInt64(0), "paused"
        assert wormhole_verified.native, "VAA not verified"
        assert source_chain_id in self.peer_bridges, "unknown source"

        # Verify source sender matches the registered peer.
        peer = self.peer_bridges[source_chain_id].copy()
        # Byte-by-byte comparison (in production use op.bytes_equal)
        i = UInt64(0)
        while i < UInt64(32):
            assert source_sender[i].native == peer[i].native, "source spoofed"
            i = i + UInt64(1)

        # Replay prevention.
        assert vaa_hash not in self.consumed_vaas, "VAA already consumed"
        self.consumed_vaas[vaa_hash] = VAAConsumed(
            consumed=arc4.Bool(True),
            consumed_ts=arc4.UInt64(Global.latest_timestamp),
        )

        # Epoch limit on inbound as well (prevents drain if guardians are
        # compromised and flood the destination).
        self._enforce_epoch_limit(asset_id, amount)

        # Unlock to recipient.
        itxn.AssetTransfer(
            xfer_asset=Asset(asset_id),
            asset_receiver=recipient,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

    # ------------------------------------------------------------------
    # EMERGENCY
    # ------------------------------------------------------------------

    @arc4.abimethod
    def pause(self) -> None:
        assert (
            Txn.sender == self.admin.value or Txn.sender == self.governor.value
        ), "admin or governor"
        self.paused.value = UInt64(1)

    @arc4.abimethod
    def unpause(self) -> None:
        assert Txn.sender == self.governor.value, "governor only"
        self.paused.value = UInt64(0)

    @arc4.abimethod
    def emergency_withdraw(
        self, asset_id: UInt64, amount: UInt64, destination: Account
    ) -> None:
        """
        Only callable when paused AND only by governor. Used if Wormhole
        is permanently compromised and governance decides to return
        locked assets to their original depositors through an off-chain
        claim process.
        """
        assert self.paused.value == UInt64(1), "not paused"
        assert Txn.sender == self.governor.value, "governor only"

        itxn.AssetTransfer(
            xfer_asset=Asset(asset_id),
            asset_receiver=destination,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

    # ------------------------------------------------------------------
    # VIEWS
    # ------------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def get_out_request(self, nonce: arc4.UInt64) -> BridgeOutRequest:
        if nonce not in self.out_requests:
            return BridgeOutRequest(
                sender=arc4.Address(Global.zero_address),
                source_asset_id=arc4.UInt64(0),
                amount=arc4.UInt64(0),
                destination_chain_id=arc4.UInt16(0),
                destination_recipient=arc4.StaticArray[
                    arc4.Byte, arc4.Literal[32]
                ].from_bytes(op.bzero(UInt64(32))),
                nonce=arc4.UInt64(0),
                emitted_ts=arc4.UInt64(0),
            )
        return self.out_requests[nonce]

    @arc4.abimethod(readonly=True)
    def is_vaa_consumed(
        self, vaa_hash: arc4.StaticArray[arc4.Byte, arc4.Literal[32]]
    ) -> arc4.Bool:
        if vaa_hash not in self.consumed_vaas:
            return arc4.Bool(False)
        return self.consumed_vaas[vaa_hash].consumed
