"""
RWA Oracle Hub — Stage 1 Core
=============================

Hybrid push-pull oracle that implements the DeltaVerseDebtOracle's five-
sub-index composite Global Debt Stress Index (GDSI) on Algorand.

The architectural insight behind this design: Algorand lacks native Chainlink,
so a pure push model requires trusted runners maintaining heartbeat updates at
their own expense, and a pure pull model requires every consumer to coordinate
signed updates per transaction. Neither alone is sufficient for an RWA oracle
that must be both fresh for derivatives settlement AND cheap enough to query
during routine compliance checks. The hybrid approach resolves this:

    Push path: oracle runners submit periodic attestations via submit_sub_index,
        which updates the sub-index value in box storage with a fresh timestamp.
        The composite is recomputed inline and stored. This keeps the oracle
        "live" during normal operation.

    Pull path: a consumer contract that needs transaction-time freshness can
        include a pre-signed price update in its atomic transaction group, and
        the consumer calls request_synchronous_update which verifies the
        signature and writes the fresh value before the consumer's own logic
        reads latest_composite.

Box storage is essential here because global state is capped at 64 entries.
Per-feed configuration (weight, staleness threshold, enabled flag) and per-
feed current value (plus timestamp) need eight keys each times five sub-
indices — already beyond global-state budget. Boxes give us unlimited storage
at a per-byte rent cost that the contract pre-funds at initialization.

The deviation circuit breaker from Synthetix's Oracle Manager translates
directly: when a newly-computed composite diverges from the prior by more
than a governance-bounded threshold, the update is staged rather than applied.
The governor DAO can approve or reject the pending update.
"""

from algopy import (
    ARC4Contract,
    Account,
    BoxMap,
    Bytes,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    op,
    subroutine,
)


class SubIndexConfig(arc4.Struct):
    """Per-sub-index configuration stored in box."""
    weight_bps: arc4.UInt16
    max_staleness_s: arc4.UInt32
    enabled: arc4.Bool


class SubIndexValue(arc4.Struct):
    """Per-sub-index current value."""
    value_e18: arc4.UInt256
    last_updated_ts: arc4.UInt64
    report_count: arc4.UInt64


class RWAOracleHub(ARC4Contract):
    """
    Composite GDSI oracle aggregating five sub-indices.

    Sub-index IDs by convention:
        0 = SDR (Sovereign Debt Ratio)
        1 = YSI (Yield Spread Index)
        2 = CSI (Credit Stress Index)
        3 = MDI (Monetary Debasement Index)
        4 = RPI (Refinancing Pressure Index)
    """

    # Precision and governance constants
    PRECISION = UInt64(1_000_000_000_000_000_000)  # 1e18
    BPS_DENOM = UInt64(10_000)

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.governor = GlobalState(Account)

        # Current composite value and EMA in 1e18 fixed-point.
        self.composite_value = GlobalState(UInt64)
        self.ema_value = GlobalState(UInt64)
        self.last_update_ts = GlobalState(UInt64)
        self.round_id = GlobalState(UInt64)

        # Circuit breaker state
        self.max_deviation_bps = GlobalState(UInt64)
        self.has_pending_update = GlobalState(UInt64)
        self.pending_composite_value = GlobalState(UInt64)
        self.pending_composite_ts = GlobalState(UInt64)

        # EMA smoothing factor in basis points (3000 = 0.30)
        self.ema_alpha_bps = GlobalState(UInt64)

        # Number of active sub-indices
        self.active_sub_index_count = GlobalState(UInt64)

        # Box maps for per-sub-index configuration and values.
        # Key is the sub-index ID as bytes.
        self.configs = BoxMap(arc4.UInt8, SubIndexConfig)
        self.values = BoxMap(arc4.UInt8, SubIndexValue)

        # Reporter authorization. Box-mapped because reporter set
        # can grow beyond global state budget.
        self.reporters = BoxMap(Account, arc4.Bool)

    @arc4.abimethod(create="require")
    def create(self, admin: Account, governor: Account) -> None:
        assert admin != Global.zero_address, "admin required"
        self.admin.value = admin
        self.governor.value = governor
        self.composite_value.value = UInt64(0)
        self.ema_value.value = UInt64(0)
        self.round_id.value = UInt64(0)
        self.max_deviation_bps.value = UInt64(1000)  # 10% default
        self.ema_alpha_bps.value = UInt64(3000)  # 0.30
        self.active_sub_index_count.value = UInt64(0)
        self.has_pending_update.value = UInt64(0)

    # ------------------------------------------------------------------
    # CONFIGURATION
    # ------------------------------------------------------------------

    @arc4.abimethod
    def configure_sub_index(
        self,
        sub_index_id: arc4.UInt8,
        weight_bps: arc4.UInt16,
        max_staleness_s: arc4.UInt32,
        enabled: arc4.Bool,
    ) -> None:
        """Set or update configuration for a single sub-index."""
        assert Txn.sender == self.admin.value, "admin only"

        cfg = SubIndexConfig(
            weight_bps=weight_bps,
            max_staleness_s=max_staleness_s,
            enabled=enabled,
        )

        # Track active count: if this is a new enabled sub-index, increment.
        if sub_index_id not in self.configs:
            if enabled.native:
                self.active_sub_index_count.value = (
                    self.active_sub_index_count.value + UInt64(1)
                )
            # Initialize value record to zero.
            self.values[sub_index_id] = SubIndexValue(
                value_e18=arc4.UInt256(0),
                last_updated_ts=arc4.UInt64(0),
                report_count=arc4.UInt64(0),
            )

        self.configs[sub_index_id] = cfg

    @arc4.abimethod
    def authorize_reporter(self, reporter: Account, authorized: arc4.Bool) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        if authorized.native:
            self.reporters[reporter] = arc4.Bool(True)
        else:
            del self.reporters[reporter]

    @arc4.abimethod
    def set_deviation_threshold(self, bps: arc4.UInt64) -> None:
        assert Txn.sender == self.governor.value, "governor only"
        assert bps.native <= UInt64(5000), "deviation too large"
        self.max_deviation_bps.value = bps.native

    # ------------------------------------------------------------------
    # PUSH PATH — REPORTERS SUBMIT ATTESTATIONS
    # ------------------------------------------------------------------

    @arc4.abimethod
    def submit_sub_index(
        self, sub_index_id: arc4.UInt8, new_value_e18: arc4.UInt256
    ) -> None:
        """
        Reporter submits a new value for a sub-index. This is the PUSH
        path — reporters run off-chain keepers that push periodic
        attestations to keep the oracle fresh for passive consumers.
        """
        assert Txn.sender in self.reporters, "not a reporter"
        assert sub_index_id in self.configs, "unknown sub-index"

        cfg = self.configs[sub_index_id].copy()
        assert cfg.enabled.native, "disabled sub-index"

        current = self.values[sub_index_id].copy()
        current.value_e18 = new_value_e18
        current.last_updated_ts = arc4.UInt64(Global.latest_timestamp)
        current.report_count = arc4.UInt64(current.report_count.native + UInt64(1))
        self.values[sub_index_id] = current.copy()

    # ------------------------------------------------------------------
    # PULL PATH — CONSUMERS TRIGGER ON-DEMAND UPDATE
    # ------------------------------------------------------------------

    @arc4.abimethod
    def request_synchronous_update(
        self,
        sub_index_id: arc4.UInt8,
        fresh_value_e18: arc4.UInt256,
        reporter_sig_ok: arc4.Bool,
    ) -> None:
        """
        Consumer-triggered pull update. A consumer that needs transaction-
        time freshness includes a pre-signed price update (verified by
        the caller prior to this inner call) and asks the oracle to apply
        it before the consumer reads latest_composite.

        The reporter_sig_ok flag is the caller's attestation that an
        off-chain signature over fresh_value_e18 has been verified;
        Algorand AVM signature verification happens in the consumer's
        group via ed25519 opcodes before this call is made.
        """
        assert sub_index_id in self.configs, "unknown sub-index"
        assert reporter_sig_ok.native, "signature not verified"

        cfg = self.configs[sub_index_id].copy()
        assert cfg.enabled.native, "disabled sub-index"

        current = self.values[sub_index_id].copy()
        current.value_e18 = fresh_value_e18
        current.last_updated_ts = arc4.UInt64(Global.latest_timestamp)
        current.report_count = arc4.UInt64(current.report_count.native + UInt64(1))
        self.values[sub_index_id] = current.copy()

    # ------------------------------------------------------------------
    # COMPOSITE AGGREGATION
    # ------------------------------------------------------------------

    @arc4.abimethod
    def update_composite(self) -> UInt64:
        """
        Recompute the composite GDSI from all active sub-indices.
        Stale sub-indices are excluded. If the new composite diverges
        from the prior by more than max_deviation_bps, the update is
        staged as pending rather than applied directly.
        """
        weighted_sum = UInt64(0)
        total_weight = UInt64(0)

        # Iterate over the five sub-indices (bounded loop).
        # AVM loop unrolling is preferred for predictable gas.
        i = UInt64(0)
        while i < UInt64(5):
            idx = arc4.UInt8(i)
            if idx in self.configs:
                cfg = self.configs[idx].copy()
                val = self.values[idx].copy()

                if cfg.enabled.native and val.value_e18.native > UInt64(0):
                    # Staleness check
                    age = Global.latest_timestamp - val.last_updated_ts.native
                    if age <= UInt64(cfg.max_staleness_s.native):
                        weighted_sum = weighted_sum + (
                            UInt64(val.value_e18.native) * UInt64(cfg.weight_bps.native)
                        )
                        total_weight = total_weight + UInt64(cfg.weight_bps.native)

            i = i + UInt64(1)

        assert total_weight > UInt64(0), "no live sub-indices"

        new_value = weighted_sum // total_weight

        # Deviation circuit breaker
        if self.composite_value.value > UInt64(0):
            if new_value > self.composite_value.value:
                diff = new_value - self.composite_value.value
            else:
                diff = self.composite_value.value - new_value

            deviation_bps = (diff * self.BPS_DENOM) // self.composite_value.value

            if deviation_bps > self.max_deviation_bps.value:
                # Stage for governor approval
                self.pending_composite_value.value = new_value
                self.pending_composite_ts.value = Global.latest_timestamp
                self.has_pending_update.value = UInt64(1)
                return self.composite_value.value  # unchanged

        # Apply update with EMA smoothing
        self._apply_composite_update(new_value)
        return new_value

    @subroutine
    def _apply_composite_update(self, new_value: UInt64) -> None:
        """Apply a composite update and update the EMA."""
        if self.ema_value.value == UInt64(0):
            self.ema_value.value = new_value
        else:
            # ema = alpha * new + (1 - alpha) * old, in bps
            alpha = self.ema_alpha_bps.value
            self.ema_value.value = (
                (new_value * alpha + self.ema_value.value * (self.BPS_DENOM - alpha))
                // self.BPS_DENOM
            )

        self.composite_value.value = new_value
        self.last_update_ts.value = Global.latest_timestamp
        self.round_id.value = self.round_id.value + UInt64(1)

    @arc4.abimethod
    def approve_pending_update(self) -> None:
        """Governor approves a pending update that breached deviation."""
        assert Txn.sender == self.governor.value, "governor only"
        assert self.has_pending_update.value == UInt64(1), "no pending update"

        self._apply_composite_update(self.pending_composite_value.value)
        self.has_pending_update.value = UInt64(0)
        self.pending_composite_value.value = UInt64(0)

    @arc4.abimethod
    def reject_pending_update(self) -> None:
        """Governor rejects a pending update; state unchanged."""
        assert Txn.sender == self.governor.value, "governor only"
        self.has_pending_update.value = UInt64(0)
        self.pending_composite_value.value = UInt64(0)

    # ------------------------------------------------------------------
    # VIEWS
    # ------------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def latest_composite(self) -> arc4.Tuple[arc4.UInt64, arc4.UInt64]:
        """Returns (composite value in 1e18, last update timestamp)."""
        return arc4.Tuple(
            (arc4.UInt64(self.composite_value.value),
             arc4.UInt64(self.last_update_ts.value))
        )

    @arc4.abimethod(readonly=True)
    def latest_ema(self) -> arc4.UInt64:
        return arc4.UInt64(self.ema_value.value)

    @arc4.abimethod(readonly=True)
    def stress_level(self) -> arc4.UInt8:
        """
        Classify composite into 0-5 stress category matching EVM contract.
            0: < 800    Low
            1: < 1000   Moderate
            2: < 1250   Elevated
            3: < 1500   High
            4: < 2000   Critical
            5: >= 2000  Systemic
        """
        v = self.composite_value.value // self.PRECISION
        if v < UInt64(800):
            return arc4.UInt8(0)
        if v < UInt64(1000):
            return arc4.UInt8(1)
        if v < UInt64(1250):
            return arc4.UInt8(2)
        if v < UInt64(1500):
            return arc4.UInt8(3)
        if v < UInt64(2000):
            return arc4.UInt8(4)
        return arc4.UInt8(5)
