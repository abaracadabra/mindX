"""
Test Suite — Sovereign Debt Registry + Global Currency Basket
==============================================================

Tests the basket layer: weight computation from registry, baseline
initialization, multi-currency debasement measurement under various
scenarios, and deviation circuit breaker on registry updates.
"""

from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Bytes, UInt64, arc4
import pytest

from contracts.stage1_core.sovereign_debt_registry import (
    SovereignDebtRegistry,
    CountryRecord,
)
from contracts.stage1_core.global_currency_basket import (
    GlobalCurrencyBasket,
    CurrencyConfig,
)


# ── HELPERS ──────────────────────────────────────────────────────────

USD = Bytes(b"USD")
EUR = Bytes(b"EUR")
JPY = Bytes(b"JPY")
GBP = Bytes(b"GBP")
CNY = Bytes(b"CNY")

PRECISION = 1_000_000_000_000_000_000  # 1e18

# Realistic 2025 sovereign debt in USD-equivalent (6-decimal representation)
US_DEBT =  38_300_000_000_000_000_000  # $38.3T × 1e6
US_GDP  =  28_000_000_000_000_000_000  # $28T × 1e6
EU_DEBT =  21_000_000_000_000_000_000
EU_GDP  =  17_500_000_000_000_000_000
JP_DEBT =   9_800_000_000_000_000_000
JP_GDP  =   4_400_000_000_000_000_000
UK_DEBT =   3_500_000_000_000_000_000
UK_GDP  =   3_400_000_000_000_000_000
CN_DEBT =  18_700_000_000_000_000_000
CN_GDP  =  18_000_000_000_000_000_000

TOTAL_DEBT = US_DEBT + EU_DEBT + JP_DEBT + UK_DEBT + CN_DEBT


# ── REGISTRY TESTS ──────────────────────────────────────────────────

class TestSovereignDebtRegistry:
    """Registry weight computation and deviation checks."""

    def test_register_country(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            reg = SovereignDebtRegistry()
            reg.create(admin, admin)

            reg.register_country(USD, UInt64(US_DEBT), UInt64(US_GDP))

            record = reg.get_record(USD)
            assert record.total_debt_usd_e6.native == US_DEBT
            assert record.registered.native is True
            assert reg.country_count.value == UInt64(1)
            assert reg.total_global_debt_e6.value == UInt64(US_DEBT)

    def test_weights_sum_proportionally(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            reg = SovereignDebtRegistry()
            reg.create(admin, admin)

            reg.register_country(USD, UInt64(US_DEBT), UInt64(US_GDP))
            reg.register_country(EUR, UInt64(EU_DEBT), UInt64(EU_GDP))
            reg.register_country(JPY, UInt64(JP_DEBT), UInt64(JP_GDP))
            reg.register_country(GBP, UInt64(UK_DEBT), UInt64(UK_GDP))
            reg.register_country(CNY, UInt64(CN_DEBT), UInt64(CN_GDP))

            us_weight = reg.weight_bps(USD)
            # 38.3T / 91.3T ≈ 41.95%
            assert 4190 <= us_weight <= 4200

            jp_weight = reg.weight_bps(JPY)
            # 9.8T / 91.3T ≈ 10.73%
            assert 1070 <= jp_weight <= 1080

    def test_total_global_debt_aggregates(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            reg = SovereignDebtRegistry()
            reg.create(admin, admin)

            reg.register_country(USD, UInt64(US_DEBT), UInt64(US_GDP))
            reg.register_country(EUR, UInt64(EU_DEBT), UInt64(EU_GDP))
            reg.register_country(JPY, UInt64(JP_DEBT), UInt64(JP_GDP))
            reg.register_country(GBP, UInt64(UK_DEBT), UInt64(UK_GDP))
            reg.register_country(CNY, UInt64(CN_DEBT), UInt64(CN_GDP))

            assert reg.total_global_debt_e6.value == UInt64(TOTAL_DEBT)

    def test_update_within_deviation_succeeds(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            reg = SovereignDebtRegistry()
            reg.create(admin, admin)
            reg.register_country(USD, UInt64(US_DEBT), UInt64(US_GDP))

            # 10% increase — within 20% limit
            new_debt = US_DEBT + (US_DEBT * 10 // 100)
            reg.update_country(USD, UInt64(new_debt), UInt64(US_GDP))
            record = reg.get_record(USD)
            assert record.total_debt_usd_e6.native == new_debt

    def test_update_exceeding_deviation_reverts(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            reg = SovereignDebtRegistry()
            reg.create(admin, admin)
            reg.register_country(USD, UInt64(US_DEBT), UInt64(US_GDP))

            # 30% increase — exceeds 20% limit
            new_debt = US_DEBT + (US_DEBT * 30 // 100)
            with pytest.raises(AssertionError, match="deviation too large"):
                reg.update_country(USD, UInt64(new_debt), UInt64(US_GDP))

    def test_delist_removes_weight(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            reg = SovereignDebtRegistry()
            reg.create(admin, admin)
            reg.register_country(USD, UInt64(US_DEBT), UInt64(US_GDP))
            reg.register_country(EUR, UInt64(EU_DEBT), UInt64(EU_GDP))

            reg.delist_country(EUR)

            eur_weight = reg.weight_bps(EUR)
            assert eur_weight == UInt64(0)
            assert reg.total_global_debt_e6.value == UInt64(US_DEBT)

    def test_debt_to_gdp_ratio(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            reg = SovereignDebtRegistry()
            reg.create(admin, admin)
            # Japan: 9.8T / 4.4T ≈ 222%
            reg.register_country(JPY, UInt64(JP_DEBT), UInt64(JP_GDP))
            record = reg.get_record(JPY)
            ratio = record.debt_to_gdp_bps.native
            # 22272 bps ≈ 222.7%
            assert 22200 <= ratio <= 22400


# ── BASKET TESTS ────────────────────────────────────────────────────

class TestGlobalCurrencyBasket:
    """Basket measurement under different debasement scenarios."""

    def test_baseline_debasement_equals_one(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            basket = GlobalCurrencyBasket()
            basket.create(admin, UInt64(100), UInt64(200), UInt64(0))

            # Configure two currencies.
            basket.configure_currency(USD, UInt64(0), UInt64(7200))
            basket.configure_currency(EUR, UInt64(1), UInt64(7200))

            # Initialize baseline: BTC $60k, EUR 0.92/USD.
            btc_baseline = 60_000 * PRECISION
            fx_rates = arc4.DynamicArray[arc4.UInt64](
                arc4.UInt64(PRECISION),                # USD/USD = 1.0
                arc4.UInt64(92 * PRECISION // 100),    # EUR/USD = 0.92
            )
            basket.initialize_baseline(UInt64(btc_baseline), fx_rates)

            # At baseline, debasement should be 1.0
            weights = arc4.DynamicArray[arc4.UInt16](
                arc4.UInt16(5000),  # equal weight for simplicity
                arc4.UInt16(5000),
            )
            deb = basket.compute_fiat_debasement(
                UInt64(btc_baseline), fx_rates, weights
            )
            # Should be very close to PRECISION (1e18)
            assert abs(int(deb) - PRECISION) < PRECISION // 100

    def test_btc_rally_increases_debasement(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            basket = GlobalCurrencyBasket()
            basket.create(admin, UInt64(100), UInt64(200), UInt64(0))

            basket.configure_currency(USD, UInt64(0), UInt64(7200))
            basket.configure_currency(EUR, UInt64(1), UInt64(7200))

            btc_baseline = 60_000 * PRECISION
            fx_rates = arc4.DynamicArray[arc4.UInt64](
                arc4.UInt64(PRECISION),
                arc4.UInt64(92 * PRECISION // 100),
            )
            basket.initialize_baseline(UInt64(btc_baseline), fx_rates)

            # BTC doubles. All fiat weakens by 2x.
            weights = arc4.DynamicArray[arc4.UInt16](
                arc4.UInt16(5000),
                arc4.UInt16(5000),
            )
            deb = basket.compute_fiat_debasement(
                UInt64(120_000 * PRECISION), fx_rates, weights
            )
            # Should be close to 2 * PRECISION
            assert abs(int(deb) - 2 * PRECISION) < PRECISION // 10

    def test_single_currency_weakening(self) -> None:
        with algopy_testing_context() as ctx:
            admin = ctx.default_sender
            basket = GlobalCurrencyBasket()
            basket.create(admin, UInt64(100), UInt64(200), UInt64(0))

            basket.configure_currency(USD, UInt64(0), UInt64(7200))
            basket.configure_currency(JPY, UInt64(1), UInt64(7200))

            btc_baseline = 60_000 * PRECISION
            fx_at_base = arc4.DynamicArray[arc4.UInt64](
                arc4.UInt64(PRECISION),
                arc4.UInt64(150 * PRECISION),  # 150 JPY/USD
            )
            basket.initialize_baseline(UInt64(btc_baseline), fx_at_base)

            # JPY weakens 50% (from 150 to 225), BTC unchanged.
            fx_now = arc4.DynamicArray[arc4.UInt64](
                arc4.UInt64(PRECISION),
                arc4.UInt64(225 * PRECISION),
            )
            weights = arc4.DynamicArray[arc4.UInt16](
                arc4.UInt16(8000),   # USD dominates
                arc4.UInt16(2000),   # JPY minor
            )
            deb = basket.compute_fiat_debasement(
                UInt64(btc_baseline), fx_now, weights
            )
            # JPY weakened 50% at 20% weight → ~10% basket debasement.
            # So debasement index ≈ 1.1
            assert int(deb) > PRECISION
            assert int(deb) < PRECISION + PRECISION // 5  # < 1.2
