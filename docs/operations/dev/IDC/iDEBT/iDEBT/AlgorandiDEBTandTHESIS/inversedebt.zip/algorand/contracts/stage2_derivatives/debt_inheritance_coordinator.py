"""
Debt Inheritance Coordinator — Stage 2 Capstone
================================================

The Algorand equivalent of DebtInheritanceProtocol.sol. Orchestrates the
full recursive inheritance flow in a single atomic group, mints and burns
sGDSI synthetic tokens against the oracle's composite value, and routes
fees to the LP staking pool.

Algorand-specific architectural insight:

    On EVM, expressThesis() makes four sequential internal calls, all
    executed within one outer transaction. The contract must handle every
    revert path and ensure the whole flow is atomic via the single EVM
    transaction's commit-or-revert semantics.

    On Algorand, the same atomicity is provided by the chain itself.
    The user submits an atomic transaction group containing:
        1. AssetTransfer of RWA to coordinator
        2. AppCall to vault.record_deposit
        3. AppCall to vault.borrow
        4. AppCall to perp.open_position
        5. AppCall to coordinator.record_thesis (this contract)
    The group either commits entirely or fails entirely. No contract
    needs to implement the "call-the-other-three" pattern because the
    coordinator's role is just to record the position, with the chain
    enforcing atomicity of the companion transactions.

    This is what the conclusion was getting at: Algorand's 16-transaction
    atomic groups solve composability at the protocol layer, whereas EVM
    needed the Router Proxy super-contract workaround. We get the same
    atomicity with less code and no 24KB size limit concerns.

The coordinator itself is also the sGDSI token issuer. It creates an ASA
on initialization where every sGDSI unit represents a claim on the
stablecoin backing held in this contract, redeemable at the current
oracle composite value.
"""

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    subroutine,
)


class ThesisPosition(arc4.Struct):
    """Recorded active thesis position."""
    rwa_asset_id: arc4.UInt64
    rwa_amount: arc4.UInt64
    borrowed_stable: arc4.UInt64
    perp_collateral: arc4.UInt64
    opened_at: arc4.UInt64
    open_index_e18: arc4.UInt64
    is_long: arc4.Bool
    leverage: arc4.UInt8
    active: arc4.Bool


class DebtInheritanceCoordinator(ARC4Contract):
    """
    Recursive debt inheritance orchestrator + sGDSI synthetic issuer.
    """

    BASE_INDEX = UInt64(1_000_000_000_000_000_000)  # 1e18
    BPS_DENOM = UInt64(10_000)
    PRECISION = UInt64(1_000_000_000_000_000_000)

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.stablecoin_asset_id = GlobalState(UInt64)
        self.sgdsi_asset_id = GlobalState(UInt64)
        self.oracle_app_id = GlobalState(UInt64)
        self.vault_app_id = GlobalState(UInt64)
        self.perp_app_id = GlobalState(UInt64)

        # Fee configuration
        self.mint_fee_bps = GlobalState(UInt64)
        self.burn_fee_bps = GlobalState(UInt64)
        self.pending_fees = GlobalState(UInt64)

        # Active thesis positions (one per trader).
        self.thesis_positions = BoxMap(Account, ThesisPosition)

        # Max sGDSI supply cap
        self.max_sgdsi_supply = GlobalState(UInt64)

        self.paused = GlobalState(UInt64)

    @arc4.abimethod(create="require")
    def create(
        self,
        admin: Account,
        stablecoin_asset_id: UInt64,
        oracle_app_id: UInt64,
        vault_app_id: UInt64,
        perp_app_id: UInt64,
    ) -> None:
        self.admin.value = admin
        self.stablecoin_asset_id.value = stablecoin_asset_id
        self.oracle_app_id.value = oracle_app_id
        self.vault_app_id.value = vault_app_id
        self.perp_app_id.value = perp_app_id
        self.mint_fee_bps.value = UInt64(30)
        self.burn_fee_bps.value = UInt64(30)
        self.pending_fees.value = UInt64(0)
        self.max_sgdsi_supply.value = UInt64(10_000_000_000_000)  # 10M sGDSI with 6 decimals
        self.paused.value = UInt64(0)

    @arc4.abimethod
    def issue_sgdsi_asa(self) -> UInt64:
        """Issue the sGDSI ASA. Called once after deployment."""
        assert Txn.sender == self.admin.value, "admin only"
        assert self.sgdsi_asset_id.value == UInt64(0), "already issued"

        itxn_result = itxn.AssetConfig(
            total=self.max_sgdsi_supply.value,
            decimals=6,
            default_frozen=False,
            asset_name=b"Synthetic GDSI",
            unit_name=b"sGDSI",
            manager=Global.current_application_address,
            reserve=Global.current_application_address,
            freeze=Global.zero_address,
            clawback=Global.zero_address,
            fee=UInt64(0),
        ).submit()

        self.sgdsi_asset_id.value = itxn_result.created_asset.id
        return itxn_result.created_asset.id

    # ------------------------------------------------------------------
    # sGDSI MINT / BURN
    # ------------------------------------------------------------------

    @arc4.abimethod
    def mint_sgdsi(
        self,
        stable_amount: UInt64,
        min_sgdsi_out: UInt64,
        current_index_e18: UInt64,
        xfer_index: UInt64,
    ) -> arc4.UInt64:
        """
        Mint sGDSI against stablecoin at the current oracle price.
        User includes stablecoin AssetTransfer in the same group.

        sGdsi_out = netStable * BASE_INDEX / current_index
        """
        assert self.paused.value == UInt64(0), "paused"
        assert stable_amount > UInt64(0), "zero amount"
        assert current_index_e18 > UInt64(0), "bad index"

        xfer = gtxn.AssetTransferTransaction(xfer_index)
        assert xfer.asset_receiver == Global.current_application_address, "bad receiver"
        assert xfer.xfer_asset.id == self.stablecoin_asset_id.value, "wrong asset"
        assert xfer.asset_amount == stable_amount, "amount mismatch"

        fee = (stable_amount * self.mint_fee_bps.value) // self.BPS_DENOM
        net = stable_amount - fee

        sgdsi_out = (net * self.BASE_INDEX) // current_index_e18
        assert sgdsi_out >= min_sgdsi_out, "slippage exceeded"

        self.pending_fees.value = self.pending_fees.value + fee

        # Send sGDSI to user via inner transfer.
        itxn.AssetTransfer(
            xfer_asset=Asset(self.sgdsi_asset_id.value),
            asset_receiver=Txn.sender,
            asset_amount=sgdsi_out,
            fee=UInt64(0),
        ).submit()

        return arc4.UInt64(sgdsi_out)

    @arc4.abimethod
    def burn_sgdsi(
        self,
        sgdsi_amount: UInt64,
        min_stable_out: UInt64,
        current_index_e18: UInt64,
        xfer_index: UInt64,
    ) -> arc4.UInt64:
        """
        Burn sGDSI for stablecoin at current oracle price.
        stable_out = sgdsi_amount * current_index / BASE_INDEX - fee

        If the index has risen since mint, stable_out exceeds deposit.
        """
        assert self.paused.value == UInt64(0), "paused"
        assert current_index_e18 > UInt64(0), "bad index"

        xfer = gtxn.AssetTransferTransaction(xfer_index)
        assert xfer.asset_receiver == Global.current_application_address, "bad receiver"
        assert xfer.xfer_asset.id == self.sgdsi_asset_id.value, "wrong asset"
        assert xfer.asset_amount == sgdsi_amount, "amount mismatch"

        gross = (sgdsi_amount * current_index_e18) // self.BASE_INDEX
        fee = (gross * self.burn_fee_bps.value) // self.BPS_DENOM
        stable_out = gross - fee

        assert stable_out >= min_stable_out, "slippage exceeded"

        self.pending_fees.value = self.pending_fees.value + fee

        itxn.AssetTransfer(
            xfer_asset=Asset(self.stablecoin_asset_id.value),
            asset_receiver=Txn.sender,
            asset_amount=stable_out,
            fee=UInt64(0),
        ).submit()

        return arc4.UInt64(stable_out)

    # ------------------------------------------------------------------
    # THESIS POSITION RECORDING
    # ------------------------------------------------------------------

    @arc4.abimethod
    def record_thesis(
        self,
        rwa_asset_id: UInt64,
        rwa_amount: UInt64,
        borrowed_stable: UInt64,
        leverage: UInt64,
        is_long: arc4.Bool,
        open_index_e18: UInt64,
    ) -> None:
        """
        Record an active thesis position. Called as the final transaction
        in the express-thesis atomic group. The chain has already enforced
        that the companion transactions (RWA deposit, borrow, perp open)
        executed atomically.

        This function does NOT re-verify the companion transactions because
        the coordinator trusts the atomic-group semantics: if those
        transactions had failed, the whole group would have aborted and
        this record would not be written. The user can only reach this
        line in a group where the sibling calls succeeded.
        """
        assert self.paused.value == UInt64(0), "paused"
        assert Txn.sender not in self.thesis_positions, "position exists"
        assert leverage >= UInt64(1) and leverage <= UInt64(20), "bad leverage"

        self.thesis_positions[Txn.sender] = ThesisPosition(
            rwa_asset_id=arc4.UInt64(rwa_asset_id),
            rwa_amount=arc4.UInt64(rwa_amount),
            borrowed_stable=arc4.UInt64(borrowed_stable),
            perp_collateral=arc4.UInt64(borrowed_stable),
            opened_at=arc4.UInt64(Global.latest_timestamp),
            open_index_e18=arc4.UInt64(open_index_e18),
            is_long=is_long,
            leverage=arc4.UInt8(leverage),
            active=arc4.Bool(True),
        )

    @arc4.abimethod
    def close_thesis(self, close_index_e18: UInt64) -> arc4.UInt64:
        """
        Record closure of a thesis. Again, companion transactions in the
        group handle the actual perp close, debt repay, and RWA return;
        this method just marks the position as closed.
        """
        assert Txn.sender in self.thesis_positions, "no position"
        pos = self.thesis_positions[Txn.sender].copy()
        assert pos.active.native, "already closed"

        del self.thesis_positions[Txn.sender]
        return arc4.UInt64(close_index_e18)

    # ------------------------------------------------------------------
    # FEE ROUTING
    # ------------------------------------------------------------------

    @arc4.abimethod
    def route_fees(self, destination_app: UInt64, xfer_destination: Account) -> UInt64:
        """
        Route pending fees to an external destination (oracle LP pool in
        production). Anyone can call — it is pure accounting.
        """
        amount = self.pending_fees.value
        assert amount > UInt64(0), "no fees"

        self.pending_fees.value = UInt64(0)

        itxn.AssetTransfer(
            xfer_asset=Asset(self.stablecoin_asset_id.value),
            asset_receiver=xfer_destination,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

        return amount

    # ------------------------------------------------------------------
    # VIEWS
    # ------------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def get_thesis(self, user: Account) -> ThesisPosition:
        if user not in self.thesis_positions:
            return ThesisPosition(
                rwa_asset_id=arc4.UInt64(0),
                rwa_amount=arc4.UInt64(0),
                borrowed_stable=arc4.UInt64(0),
                perp_collateral=arc4.UInt64(0),
                opened_at=arc4.UInt64(0),
                open_index_e18=arc4.UInt64(0),
                is_long=arc4.Bool(False),
                leverage=arc4.UInt8(0),
                active=arc4.Bool(False),
            )
        return self.thesis_positions[user]

    @arc4.abimethod
    def pause(self) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.paused.value = UInt64(1)

    @arc4.abimethod
    def unpause(self) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.paused.value = UInt64(0)
