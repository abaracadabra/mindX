"""
Tests for RWAOracleHub.

Validates the hybrid push-pull model works correctly for both paths,
the composite aggregation handles stale sub-indices gracefully, and the
deviation circuit breaker stages updates that exceed the threshold.
"""

import pytest
from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, UInt64, arc4

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "contracts", "stage1_core"))
from rwa_oracle_hub import RWAOracleHub  # noqa: E402


@pytest.fixture()
def ctx() -> AlgopyTestContext:
    with algopy_testing_context() as context:
        yield context


@pytest.fixture()
def oracle(ctx: AlgopyTestContext) -> RWAOracleHub:
    admin = ctx.any.account()
    governor = ctx.any.account()
    contract = RWAOracleHub()
    with ctx.txn.create_group(
        [ctx.any.txn.application_call(sender=admin)]
    ):
        contract.create(admin=admin, governor=governor)
    return contract


@pytest.fixture()
def oracle_with_subindices(
    ctx: AlgopyTestContext, oracle: RWAOracleHub
) -> RWAOracleHub:
    """Oracle with 5 sub-indices at 2000 bps each (20% weights)."""
    reporter = ctx.any.account()
    with ctx.txn.create_group(
        [ctx.any.txn.application_call(sender=oracle.admin.value)]
    ):
        oracle.authorize_reporter(reporter, arc4.Bool(True))
        for i in range(5):
            oracle.configure_sub_index(
                sub_index_id=arc4.UInt8(i),
                weight_bps=arc4.UInt16(2000),
                max_staleness_s=arc4.UInt32(3600),
                enabled=arc4.Bool(True),
            )
    return oracle


class TestSubIndexConfig:
    def test_five_sub_indices_registered(
        self, ctx: AlgopyTestContext, oracle_with_subindices: RWAOracleHub
    ) -> None:
        assert oracle_with_subindices.active_sub_index_count.value == UInt64(5)

    def test_non_admin_cannot_configure(
        self, ctx: AlgopyTestContext, oracle: RWAOracleHub
    ) -> None:
        attacker = ctx.any.account()
        with pytest.raises(AssertionError):
            with ctx.txn.create_group(
                [ctx.any.txn.application_call(sender=attacker)]
            ):
                oracle.configure_sub_index(
                    sub_index_id=arc4.UInt8(0),
                    weight_bps=arc4.UInt16(2000),
                    max_staleness_s=arc4.UInt32(3600),
                    enabled=arc4.Bool(True),
                )


class TestPushPath:
    def test_reporter_submits_value(
        self,
        ctx: AlgopyTestContext,
        oracle_with_subindices: RWAOracleHub,
    ) -> None:
        reporter = next(iter(oracle_with_subindices.reporters))
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            oracle_with_subindices.submit_sub_index(
                sub_index_id=arc4.UInt8(0),
                new_value_e18=arc4.UInt256(1_000 * 10**18),
            )

        val = oracle_with_subindices.values[arc4.UInt8(0)]
        assert val.value_e18.native == 1_000 * 10**18

    def test_non_reporter_rejected(
        self,
        ctx: AlgopyTestContext,
        oracle_with_subindices: RWAOracleHub,
    ) -> None:
        attacker = ctx.any.account()
        with pytest.raises(AssertionError):
            with ctx.txn.create_group(
                [ctx.any.txn.application_call(sender=attacker)]
            ):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(0),
                    new_value_e18=arc4.UInt256(999999 * 10**18),
                )


class TestCompositeAggregation:
    def test_composite_averages_five_sub_indices(
        self,
        ctx: AlgopyTestContext,
        oracle_with_subindices: RWAOracleHub,
    ) -> None:
        reporter = next(iter(oracle_with_subindices.reporters))
        # Submit all five at 1000e18.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            for i in range(5):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(i),
                    new_value_e18=arc4.UInt256(1_000 * 10**18),
                )

        # Aggregate.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            oracle_with_subindices.update_composite()

        assert oracle_with_subindices.composite_value.value == UInt64(1_000 * 10**18)

    def test_deviation_circuit_breaker_stages_big_jump(
        self,
        ctx: AlgopyTestContext,
        oracle_with_subindices: RWAOracleHub,
    ) -> None:
        reporter = next(iter(oracle_with_subindices.reporters))
        # First pass: establish baseline at 1000e18.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            for i in range(5):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(i),
                    new_value_e18=arc4.UInt256(1_000 * 10**18),
                )
            oracle_with_subindices.update_composite()

        # Second pass: submit values 50% higher — exceeds 10% default threshold.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            for i in range(5):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(i),
                    new_value_e18=arc4.UInt256(1_500 * 10**18),
                )
            oracle_with_subindices.update_composite()

        # Composite should be unchanged (still 1000e18) but pending flag set.
        assert oracle_with_subindices.composite_value.value == UInt64(1_000 * 10**18)
        assert oracle_with_subindices.has_pending_update.value == UInt64(1)

    def test_governor_approves_pending_update(
        self,
        ctx: AlgopyTestContext,
        oracle_with_subindices: RWAOracleHub,
    ) -> None:
        reporter = next(iter(oracle_with_subindices.reporters))
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            for i in range(5):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(i),
                    new_value_e18=arc4.UInt256(1_000 * 10**18),
                )
            oracle_with_subindices.update_composite()

        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            for i in range(5):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(i),
                    new_value_e18=arc4.UInt256(1_500 * 10**18),
                )
            oracle_with_subindices.update_composite()

        # Governor approves.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(
                sender=oracle_with_subindices.governor.value
            )]
        ):
            oracle_with_subindices.approve_pending_update()

        assert oracle_with_subindices.composite_value.value == UInt64(1_500 * 10**18)
        assert oracle_with_subindices.has_pending_update.value == UInt64(0)


class TestStressLevel:
    def _set_composite(self, ctx, oracle_with_subindices, value_e18):
        reporter = next(iter(oracle_with_subindices.reporters))
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            for i in range(5):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(i),
                    new_value_e18=arc4.UInt256(value_e18),
                )
            oracle_with_subindices.update_composite()

    def test_stress_level_moderate(self, ctx, oracle_with_subindices):
        self._set_composite(ctx, oracle_with_subindices, 900 * 10**18)
        assert oracle_with_subindices.stress_level().native == 1  # Moderate

    def test_stress_level_critical(self, ctx, oracle_with_subindices):
        self._set_composite(ctx, oracle_with_subindices, 1_800 * 10**18)
        assert oracle_with_subindices.stress_level().native == 4  # Critical

    def test_stress_level_systemic(self, ctx, oracle_with_subindices):
        # Systemic level requires composite > 2000 on the 1e18 scale.
        # We bypass the circuit breaker by governor-approving.
        reporter = next(iter(oracle_with_subindices.reporters))
        # Establish baseline first.
        self._set_composite(ctx, oracle_with_subindices, 1_000 * 10**18)
        # Jump to 2500 — triggers breaker.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=reporter)]
        ):
            for i in range(5):
                oracle_with_subindices.submit_sub_index(
                    sub_index_id=arc4.UInt8(i),
                    new_value_e18=arc4.UInt256(2_500 * 10**18),
                )
            oracle_with_subindices.update_composite()
        # Governor approves the pending update.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(
                sender=oracle_with_subindices.governor.value
            )]
        ):
            oracle_with_subindices.approve_pending_update()
        assert oracle_with_subindices.stress_level().native == 5  # Systemic
