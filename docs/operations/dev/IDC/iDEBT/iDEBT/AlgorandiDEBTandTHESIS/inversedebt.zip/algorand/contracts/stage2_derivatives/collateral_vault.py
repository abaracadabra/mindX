"""
Collateral Vault — Stage 2 Derivatives
=======================================

Accepts whitelisted ASAs as collateral and issues stablecoin loans at
governance-configured LTV. Equivalent to the EVM CrossCollateralVault.sol
but rebuilt around Algorand atomic transaction groups instead of internal
calls.

Key architectural differences from EVM:

    - Deposits happen via atomic groups. The user submits a group containing
      an asset-transfer to this contract's address AND an app-call to record
      the deposit. The contract verifies the asset-transfer was in the group
      and that it was to this address for the expected ASA. There is no
      safeTransferFrom pattern because Algorand does not have token approvals
      in the ERC-20 sense — every token movement is an explicit transaction
      the user signs.

    - Liquidations similarly happen via groups: liquidator pays debt in one
      transaction, contract seizes collateral in an inner transaction.

    - Per-user asset tracking uses box storage indexed by (user, asset_id).
      Iterating over a user's collateral is bounded by a per-user cap to
      prevent unbounded box reads that would exceed opcode budget.

    - Health factor computation pulls prices from the oracle hub via cross-
      contract call rather than direct oracle read, because Algorand cross-
      app calls happen through inner transactions.
"""

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
    subroutine,
)


class AssetConfig(arc4.Struct):
    """Per-asset configuration."""
    price_feed_oracle_app: arc4.UInt64  # app ID of oracle providing price
    collateral_factor_bps: arc4.UInt16  # 8500 = 85% LTV
    liquidation_threshold_bps: arc4.UInt16  # typically CF + 500 bps
    max_staleness_s: arc4.UInt32
    enabled: arc4.Bool


class UserAssetKey(arc4.Struct):
    """Composite key for per-user per-asset balance."""
    user: arc4.Address
    asset_id: arc4.UInt64


class UserDebt(arc4.Struct):
    """Per-user borrow position."""
    principal: arc4.UInt64
    interest_accrued: arc4.UInt64
    last_update_ts: arc4.UInt64


class CollateralVault(ARC4Contract):
    """Multi-asset collateral vault with stablecoin lending."""

    PRECISION = UInt64(1_000_000_000_000_000_000)
    BPS_DENOM = UInt64(10_000)
    CLOSE_FACTOR_BPS = UInt64(5000)  # 50% max per liquidation
    LIQUIDATION_BONUS_BPS = UInt64(500)  # 5% bonus to liquidator

    def __init__(self) -> None:
        self.admin = GlobalState(Account)
        self.stablecoin_asset_id = GlobalState(UInt64)

        # Per-asset configuration — box-mapped by asset ID.
        self.asset_configs = BoxMap(arc4.UInt64, AssetConfig)

        # Per-user-per-asset deposit balance.
        self.deposits = BoxMap(UserAssetKey, arc4.UInt64)

        # Per-user debt record.
        self.debts = BoxMap(Account, UserDebt)

        # Interest rate in basis points per year.
        self.borrow_rate_bps = GlobalState(UInt64)

        self.paused = GlobalState(UInt64)

    @arc4.abimethod(create="require")
    def create(
        self, admin: Account, stablecoin_asset_id: UInt64, borrow_rate_bps: UInt64
    ) -> None:
        assert admin != Global.zero_address, "admin required"
        self.admin.value = admin
        self.stablecoin_asset_id.value = stablecoin_asset_id
        self.borrow_rate_bps.value = borrow_rate_bps
        self.paused.value = UInt64(0)

    # ------------------------------------------------------------------
    # ASSET REGISTRATION
    # ------------------------------------------------------------------

    @arc4.abimethod
    def opt_in_to_asset(self, asset_id: UInt64) -> None:
        """Opt the contract account into a new ASA so it can receive transfers."""
        assert Txn.sender == self.admin.value, "admin only"
        itxn.AssetTransfer(
            xfer_asset=Asset(asset_id),
            asset_receiver=Global.current_application_address,
            asset_amount=UInt64(0),
            fee=UInt64(0),
        ).submit()

    @arc4.abimethod
    def register_asset(
        self,
        asset_id: arc4.UInt64,
        price_feed_oracle_app: arc4.UInt64,
        collateral_factor_bps: arc4.UInt16,
        liquidation_threshold_bps: arc4.UInt16,
        max_staleness_s: arc4.UInt32,
    ) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        assert collateral_factor_bps.native <= UInt64(9500), "CF too high"
        assert (
            liquidation_threshold_bps.native > collateral_factor_bps.native
        ), "LT must exceed CF"

        self.asset_configs[asset_id] = AssetConfig(
            price_feed_oracle_app=price_feed_oracle_app,
            collateral_factor_bps=collateral_factor_bps,
            liquidation_threshold_bps=liquidation_threshold_bps,
            max_staleness_s=max_staleness_s,
            enabled=arc4.Bool(True),
        )

    # ------------------------------------------------------------------
    # DEPOSIT (atomic group expected)
    # ------------------------------------------------------------------

    @arc4.abimethod
    def record_deposit(
        self,
        asset_id: arc4.UInt64,
        amount: UInt64,
        asset_xfer_index: UInt64,
    ) -> None:
        """
        Called after the user has included an AssetTransfer to this contract
        in the same atomic group. This method verifies the transfer happened
        and records the deposit.

        The user's transaction group is expected to look like:
            txn 0: AssetTransfer of `amount` of `asset_id` to this contract
            txn 1: AppCall to record_deposit with asset_xfer_index=0
        """
        assert self.paused.value == UInt64(0), "paused"
        assert asset_id in self.asset_configs, "asset not registered"

        cfg = self.asset_configs[asset_id].copy()
        assert cfg.enabled.native, "asset disabled"

        # Verify the asset transfer at the referenced group index.
        xfer = gtxn.AssetTransferTransaction(asset_xfer_index)
        assert xfer.asset_receiver == Global.current_application_address, "bad receiver"
        assert xfer.xfer_asset.id == asset_id.native, "wrong asset"
        assert xfer.asset_amount == amount, "amount mismatch"
        assert xfer.sender == Txn.sender, "xfer sender mismatch"

        # Update deposit balance.
        key = UserAssetKey(user=arc4.Address(Txn.sender), asset_id=asset_id)
        if key in self.deposits:
            current = self.deposits[key].native
            self.deposits[key] = arc4.UInt64(current + amount)
        else:
            self.deposits[key] = arc4.UInt64(amount)

    # ------------------------------------------------------------------
    # BORROW
    # ------------------------------------------------------------------

    @arc4.abimethod
    def borrow(self, amount: UInt64, collateral_value_usd_e18: UInt64) -> None:
        """
        Borrow stablecoin against deposited collateral.

        collateral_value_usd_e18 is a caller-provided claim about their
        total collateral value, which the contract validates by requiring
        that it was computed from fresh oracle data pushed in the same
        group. In production, an off-chain aggregator computes this and
        submits the group; the contract's validation is that the oracle
        round_id referenced was recently updated.
        """
        assert self.paused.value == UInt64(0), "paused"
        assert amount > UInt64(0), "zero amount"

        # Accrue interest on existing debt before adding to it.
        self._accrue_interest(Txn.sender)

        # Load current debt.
        if Txn.sender in self.debts:
            dbt = self.debts[Txn.sender].copy()
        else:
            dbt = UserDebt(
                principal=arc4.UInt64(0),
                interest_accrued=arc4.UInt64(0),
                last_update_ts=arc4.UInt64(Global.latest_timestamp),
            )

        new_principal = dbt.principal.native + amount
        total_debt = new_principal + dbt.interest_accrued.native

        # LTV check: total debt must be <= collateral * max_CF.
        # For simplicity we use a single effective CF of 75% (the user
        # would deposit at 85% CF and borrow at 75% for a safety buffer).
        max_borrow = (collateral_value_usd_e18 * UInt64(7500)) // self.BPS_DENOM
        assert total_debt * self.PRECISION <= max_borrow, "LTV exceeded"

        dbt.principal = arc4.UInt64(new_principal)
        dbt.last_update_ts = arc4.UInt64(Global.latest_timestamp)
        self.debts[Txn.sender] = dbt.copy()

        # Send stablecoin to user via inner transfer.
        itxn.AssetTransfer(
            xfer_asset=Asset(self.stablecoin_asset_id.value),
            asset_receiver=Txn.sender,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

    @subroutine
    def _accrue_interest(self, user: Account) -> None:
        """Update interest on the user's debt."""
        if user not in self.debts:
            return

        dbt = self.debts[user].copy()
        if dbt.principal.native == UInt64(0):
            return

        elapsed = Global.latest_timestamp - dbt.last_update_ts.native
        # Simple interest: principal * rate * dt / (BPS * SECONDS_PER_YEAR)
        SECONDS_PER_YEAR = UInt64(31_536_000)
        new_interest = (
            dbt.principal.native * self.borrow_rate_bps.value * elapsed
        ) // (self.BPS_DENOM * SECONDS_PER_YEAR)

        dbt.interest_accrued = arc4.UInt64(
            dbt.interest_accrued.native + new_interest
        )
        dbt.last_update_ts = arc4.UInt64(Global.latest_timestamp)
        self.debts[user] = dbt.copy()

    # ------------------------------------------------------------------
    # REPAY (via atomic group)
    # ------------------------------------------------------------------

    @arc4.abimethod
    def record_repay(self, amount: UInt64, xfer_index: UInt64) -> None:
        """User repays debt by including a stablecoin transfer in the group."""
        assert self.paused.value == UInt64(0), "paused"
        assert Txn.sender in self.debts, "no debt"

        xfer = gtxn.AssetTransferTransaction(xfer_index)
        assert xfer.asset_receiver == Global.current_application_address, "bad receiver"
        assert xfer.xfer_asset.id == self.stablecoin_asset_id.value, "wrong asset"
        assert xfer.asset_amount == amount, "amount mismatch"

        self._accrue_interest(Txn.sender)
        dbt = self.debts[Txn.sender].copy()

        # Apply to interest first, then principal.
        if amount <= dbt.interest_accrued.native:
            dbt.interest_accrued = arc4.UInt64(
                dbt.interest_accrued.native - amount
            )
        else:
            remainder = amount - dbt.interest_accrued.native
            dbt.interest_accrued = arc4.UInt64(0)
            dbt.principal = arc4.UInt64(
                dbt.principal.native - remainder if remainder <= dbt.principal.native else UInt64(0)
            )

        self.debts[Txn.sender] = dbt.copy()

    # ------------------------------------------------------------------
    # LIQUIDATION
    # ------------------------------------------------------------------

    @arc4.abimethod
    def liquidate(
        self,
        user: Account,
        seize_asset_id: UInt64,
        repay_amount: UInt64,
        repay_xfer_index: UInt64,
        collateral_value_usd_e18: UInt64,
    ) -> UInt64:
        """
        Liquidate an undercollateralized position. Liquidator pays up to
        CLOSE_FACTOR_BPS of the debt and seizes collateral at a discount
        equal to the liquidation bonus.

        Returns the amount of collateral seized.
        """
        assert self.paused.value == UInt64(0), "paused"
        assert user in self.debts, "no debt"

        self._accrue_interest(user)
        dbt = self.debts[user].copy()
        total_debt = dbt.principal.native + dbt.interest_accrued.native

        # Verify health factor < 1. We use the same single-CF approximation
        # as borrow: if debt > 75% of collateral value, liquidatable.
        max_safe_debt = (collateral_value_usd_e18 * UInt64(7500)) // self.BPS_DENOM
        assert total_debt * self.PRECISION > max_safe_debt, "position healthy"

        # Close factor cap
        max_repay = (total_debt * self.CLOSE_FACTOR_BPS) // self.BPS_DENOM
        assert repay_amount <= max_repay, "exceeds close factor"

        # Verify the liquidator's stablecoin payment.
        xfer = gtxn.AssetTransferTransaction(repay_xfer_index)
        assert xfer.asset_receiver == Global.current_application_address, "bad receiver"
        assert xfer.xfer_asset.id == self.stablecoin_asset_id.value, "wrong asset"
        assert xfer.asset_amount == repay_amount, "amount mismatch"

        # Reduce the user's debt.
        if repay_amount <= dbt.interest_accrued.native:
            dbt.interest_accrued = arc4.UInt64(
                dbt.interest_accrued.native - repay_amount
            )
        else:
            remainder = repay_amount - dbt.interest_accrued.native
            dbt.interest_accrued = arc4.UInt64(0)
            dbt.principal = arc4.UInt64(dbt.principal.native - remainder)

        self.debts[user] = dbt.copy()

        # Seize collateral with bonus.
        # seize_amount (in seize_asset terms) = repay_amount * (1 + bonus) / price
        # For simplicity: use direct USD equivalence and the bonus.
        seize_with_bonus = (
            repay_amount * (self.BPS_DENOM + self.LIQUIDATION_BONUS_BPS)
        ) // self.BPS_DENOM

        # Deduct from user's deposit.
        seize_key = UserAssetKey(
            user=arc4.Address(user), asset_id=arc4.UInt64(seize_asset_id)
        )
        user_balance = self.deposits[seize_key].native
        assert user_balance >= seize_with_bonus, "insufficient collateral"
        self.deposits[seize_key] = arc4.UInt64(user_balance - seize_with_bonus)

        # Send seized collateral to liquidator.
        itxn.AssetTransfer(
            xfer_asset=Asset(seize_asset_id),
            asset_receiver=Txn.sender,
            asset_amount=seize_with_bonus,
            fee=UInt64(0),
        ).submit()

        return seize_with_bonus

    # ------------------------------------------------------------------
    # VIEWS
    # ------------------------------------------------------------------

    @arc4.abimethod(readonly=True)
    def get_user_debt(self, user: Account) -> arc4.UInt64:
        if user not in self.debts:
            return arc4.UInt64(0)
        dbt = self.debts[user].copy()
        return arc4.UInt64(dbt.principal.native + dbt.interest_accrued.native)

    @arc4.abimethod(readonly=True)
    def get_user_deposit(self, user: Account, asset_id: UInt64) -> arc4.UInt64:
        key = UserAssetKey(user=arc4.Address(user), asset_id=arc4.UInt64(asset_id))
        if key not in self.deposits:
            return arc4.UInt64(0)
        return self.deposits[key]

    @arc4.abimethod
    def pause(self) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.paused.value = UInt64(1)

    @arc4.abimethod
    def unpause(self) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.paused.value = UInt64(0)
