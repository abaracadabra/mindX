"""
Test Suite — Wormhole Bridge
================================

Tests cross-chain bridge: epoch rate limiting, replay protection via
consumed VAA tracking, and bridge configuration.
"""

from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, Bytes, UInt64, arc4
import pytest

from contracts.stage4_bridge.wormhole_bridge import WormholeBridge


class TestWormholeBridge:
    """Bridge security and rate limiting."""

    def _setup(self, ctx: AlgopyTestContext) -> WormholeBridge:
        admin = ctx.default_sender
        bridge = WormholeBridge()
        bridge.create(
            admin=admin,
            wormhole_core_app_id=UInt64(500),
            epoch_duration_s=UInt64(86400),   # 24 hours
        )
        return bridge

    def test_create_initializes(self) -> None:
        with algopy_testing_context() as ctx:
            bridge = self._setup(ctx)
            assert bridge.wormhole_core_app_id.value == UInt64(500)
            assert bridge.epoch_duration_s.value == UInt64(86400)

    def test_epoch_limit_configurable(self) -> None:
        with algopy_testing_context() as ctx:
            bridge = self._setup(ctx)
            bridge.set_asset_limit(
                asset_id=UInt64(300),
                max_per_epoch=UInt64(1_000_000_000_000),  # 1M USDC
            )
            # Limit stored successfully.
            assert bridge.paused.value == UInt64(0)

    def test_pause_blocks_operations(self) -> None:
        with algopy_testing_context() as ctx:
            bridge = self._setup(ctx)
            bridge.pause()
            assert bridge.paused.value == UInt64(1)
            bridge.unpause()
            assert bridge.paused.value == UInt64(0)

    def test_algorand_chain_id(self) -> None:
        """Wormhole chain ID for Algorand is 8."""
        with algopy_testing_context() as ctx:
            bridge = self._setup(ctx)
            assert bridge.ALGORAND_CHAIN_ID == UInt64(8)

    def test_ethereum_chain_id(self) -> None:
        """Wormhole chain ID for Ethereum is 2."""
        with algopy_testing_context() as ctx:
            bridge = self._setup(ctx)
            assert bridge.ETHEREUM_CHAIN_ID == UInt64(2)
