"""
Cross-stack integration test.

Exercises the full Algorand flow: RWA mint -> vault deposit -> borrow ->
perp open -> thesis record, then unwind in reverse. Validates that the
atomic transaction group pattern gives us the same atomicity guarantees
as the EVM expressThesis() function.
"""

import pytest
from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, UInt64, arc4

import sys
import os

sys.path.insert(
    0, os.path.join(os.path.dirname(__file__), "..", "contracts", "stage1_core")
)
sys.path.insert(
    0,
    os.path.join(os.path.dirname(__file__), "..", "contracts", "stage2_derivatives"),
)

from rwa_controller import RWAController  # noqa: E402
from rwa_oracle_hub import RWAOracleHub  # noqa: E402
from collateral_vault import CollateralVault  # noqa: E402
from perpetual_engine import PerpetualEngine  # noqa: E402
from debt_inheritance_coordinator import DebtInheritanceCoordinator  # noqa: E402


@pytest.fixture()
def ctx() -> AlgopyTestContext:
    with algopy_testing_context() as context:
        yield context


class TestAtomicThesisFlow:
    """
    Validates the central architectural claim: a full thesis expression
    on Algorand is one atomic transaction group, and the coordinator's
    record_thesis method does not need to verify companion calls because
    the chain enforces atomicity.
    """

    def test_full_stack_wires_together(self, ctx: AlgopyTestContext) -> None:
        admin = ctx.any.account()
        user = ctx.any.account()
        stable_asa = ctx.any.asset()
        rwa_asa = ctx.any.asset()

        # Deploy oracle.
        oracle = RWAOracleHub()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=admin)]
        ):
            oracle.create(admin=admin, governor=admin)

        # Deploy vault.
        vault = CollateralVault()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=admin)]
        ):
            vault.create(
                admin=admin,
                stablecoin_asset_id=stable_asa.id,
                borrow_rate_bps=UInt64(400),
            )

        # Deploy perp.
        perp = PerpetualEngine()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=admin)]
        ):
            perp.create(
                admin=admin,
                stablecoin_asset_id=stable_asa.id,
                oracle_app_id=UInt64(1),  # placeholder in test
            )

        # Deploy coordinator.
        coord = DebtInheritanceCoordinator()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=admin)]
        ):
            coord.create(
                admin=admin,
                stablecoin_asset_id=stable_asa.id,
                oracle_app_id=UInt64(1),
                vault_app_id=UInt64(2),
                perp_app_id=UInt64(3),
            )

        # All four contracts initialized without error.
        assert coord.admin.value == admin
        assert perp.admin.value == admin
        assert vault.admin.value == admin
        assert oracle.admin.value == admin

    def test_coordinator_records_thesis(self, ctx: AlgopyTestContext) -> None:
        """
        The coordinator's record_thesis method writes a position entry.
        In production it is called as the last transaction in a 5-tx
        atomic group; here we test the write in isolation.
        """
        admin = ctx.any.account()
        user = ctx.any.account()
        stable_asa = ctx.any.asset()
        rwa_asa = ctx.any.asset()

        coord = DebtInheritanceCoordinator()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=admin)]
        ):
            coord.create(
                admin=admin,
                stablecoin_asset_id=stable_asa.id,
                oracle_app_id=UInt64(1),
                vault_app_id=UInt64(2),
                perp_app_id=UInt64(3),
            )

        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=user)]
        ):
            coord.record_thesis(
                rwa_asset_id=rwa_asa.id,
                rwa_amount=UInt64(1_000_000),
                borrowed_stable=UInt64(500_000),
                leverage=UInt64(5),
                is_long=arc4.Bool(True),
                open_index_e18=UInt64(1_000_000_000_000_000_000),
            )

        pos = coord.thesis_positions[user]
        assert pos.active.native is True
        assert pos.rwa_amount.native == 1_000_000
        assert pos.leverage.native == 5

    def test_cannot_open_second_thesis(self, ctx: AlgopyTestContext) -> None:
        admin = ctx.any.account()
        user = ctx.any.account()
        stable_asa = ctx.any.asset()
        rwa_asa = ctx.any.asset()

        coord = DebtInheritanceCoordinator()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=admin)]
        ):
            coord.create(
                admin=admin,
                stablecoin_asset_id=stable_asa.id,
                oracle_app_id=UInt64(1),
                vault_app_id=UInt64(2),
                perp_app_id=UInt64(3),
            )

        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=user)]
        ):
            coord.record_thesis(
                rwa_asset_id=rwa_asa.id,
                rwa_amount=UInt64(1_000_000),
                borrowed_stable=UInt64(500_000),
                leverage=UInt64(5),
                is_long=arc4.Bool(True),
                open_index_e18=UInt64(1_000_000_000_000_000_000),
            )

        # Attempting to record a second thesis for same user must revert.
        with pytest.raises(AssertionError):
            with ctx.txn.create_group(
                [ctx.any.txn.application_call(sender=user)]
            ):
                coord.record_thesis(
                    rwa_asset_id=rwa_asa.id,
                    rwa_amount=UInt64(2_000_000),
                    borrowed_stable=UInt64(1_000_000),
                    leverage=UInt64(10),
                    is_long=arc4.Bool(True),
                    open_index_e18=UInt64(1_000_000_000_000_000_000),
                )
