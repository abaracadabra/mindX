"""
Tests for RWAController.

Uses the algorand-python-testing framework which provides a local AVM
simulator. Tests validate the controller's behavior against specification
requirements stated in the contract docstring.
"""

import pytest
from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, UInt64, arc4

# Import the contract under test.
# Path: contracts/stage1_core/rwa_controller.py
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "contracts", "stage1_core"))
from rwa_controller import RWAController  # noqa: E402


@pytest.fixture()
def ctx() -> AlgopyTestContext:
    with algopy_testing_context() as context:
        yield context


@pytest.fixture()
def controller(ctx: AlgopyTestContext) -> RWAController:
    admin = ctx.any.account()
    compliance = ctx.any.account()
    yield_asa = ctx.any.asset()

    contract = RWAController()
    with ctx.txn.create_group([ctx.any.txn.application_call(sender=admin)]):
        contract.create(
            admin=admin,
            compliance_officer=compliance,
            yield_token=yield_asa.id,
            maturity_ts=UInt64(4_102_444_800),  # Jan 2100
            coupon_bps=UInt64(400),
            supply_cap=UInt64(100_000_000_000_000),
        )
    return contract


class TestInitialization:
    def test_admin_set(self, ctx: AlgopyTestContext, controller: RWAController) -> None:
        # After create(), admin global state should be populated.
        assert controller.admin.value != Account()

    def test_paused_false(self, ctx: AlgopyTestContext, controller: RWAController) -> None:
        assert controller.paused.value == UInt64(0)

    def test_supply_cap_honored(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        assert controller.supply_cap.value == UInt64(100_000_000_000_000)


class TestCompliance:
    def test_whitelist_account(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        account = ctx.any.account()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=controller.admin.value)]
        ):
            controller.whitelist_account(account)
        assert account in controller.whitelist

    def test_revoke_whitelist(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        account = ctx.any.account()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=controller.admin.value)]
        ):
            controller.whitelist_account(account)
            controller.revoke_whitelist(account)
        assert account not in controller.whitelist

    def test_non_admin_cannot_whitelist(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        attacker = ctx.any.account()
        target = ctx.any.account()
        with pytest.raises(AssertionError):
            with ctx.txn.create_group(
                [ctx.any.txn.application_call(sender=attacker)]
            ):
                controller.whitelist_account(target)


class TestFreezeAndSeize:
    def test_compliance_can_freeze(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        account = ctx.any.account()
        # Must be whitelisted first for the freeze to be meaningful.
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=controller.admin.value)]
        ):
            controller.whitelist_account(account)

        with ctx.txn.create_group(
            [ctx.any.txn.application_call(
                sender=controller.compliance_officer.value
            )]
        ):
            controller.freeze_account(account)

        assert account in controller.frozen

    def test_admin_cannot_freeze(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        account = ctx.any.account()
        with pytest.raises(AssertionError):
            with ctx.txn.create_group(
                [ctx.any.txn.application_call(sender=controller.admin.value)]
            ):
                controller.freeze_account(account)

    def test_unfreeze_restores_whitelist(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        account = ctx.any.account()
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=controller.admin.value)]
        ):
            controller.whitelist_account(account)
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(
                sender=controller.compliance_officer.value
            )]
        ):
            controller.freeze_account(account)
            controller.unfreeze_account(account)

        assert account not in controller.frozen


class TestPausability:
    def test_pause_by_admin(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=controller.admin.value)]
        ):
            controller.pause()
        assert controller.paused.value == UInt64(1)

    def test_unpause_by_admin(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        with ctx.txn.create_group(
            [ctx.any.txn.application_call(sender=controller.admin.value)]
        ):
            controller.pause()
            controller.unpause()
        assert controller.paused.value == UInt64(0)

    def test_non_admin_cannot_pause(
        self, ctx: AlgopyTestContext, controller: RWAController
    ) -> None:
        attacker = ctx.any.account()
        with pytest.raises(AssertionError):
            with ctx.txn.create_group(
                [ctx.any.txn.application_call(sender=attacker)]
            ):
                controller.pause()
