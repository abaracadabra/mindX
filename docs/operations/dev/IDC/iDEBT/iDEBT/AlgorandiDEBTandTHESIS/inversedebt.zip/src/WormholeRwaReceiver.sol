// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

interface IWormholeCore {
    function parseAndVerifyVM(bytes calldata encodedVM)
        external view returns (
            VM memory vm,
            bool valid,
            string memory reason
        );

    struct VM {
        uint8 version;
        uint32 timestamp;
        uint32 nonce;
        uint16 emitterChainId;
        bytes32 emitterAddress;
        uint64 sequence;
        uint8 consistencyLevel;
        bytes payload;
        uint32 guardianSetIndex;
        bytes32 hash;
        bytes signatures;
    }
}

/**
 * @title WormholeRwaReceiver
 * @author Professor Codephreak — DELTAVERSE Ecosystem
 * @notice EVM-side of the Algorand ↔ Ethereum RWA bridge. Receives signed
 *         Wormhole VAAs originated from the Algorand WormholeBridge, verifies
 *         them against the Wormhole core bridge, and mints a wrapped ERC-20
 *         representation of the bridged RWA. The wrapped token is depositable
 *         into the existing CrossCollateralVault as collateral for iDEBT.
 *
 * @dev The bridging model follows the Wormhole TokenBridge pattern:
 *
 *      Algorand side locks the original ASA and emits a signed VAA.
 *      Wormhole guardians (19 independent validators) sign the message off-chain
 *      with 13-of-19 consensus. A relayer submits the signed VAA to this
 *      contract's completeTransfer method. The contract:
 *
 *        1. Calls the Wormhole core bridge to parse and verify signatures.
 *        2. Checks the emitter matches our registered Algorand peer.
 *        3. Checks the VAA has not been consumed (replay protection).
 *        4. Decodes the payload to extract source asset, amount, recipient.
 *        5. Mints the wrapped ERC-20 representation to the recipient.
 *
 *      Reverse direction works through burn-and-message: user calls bridgeOut
 *      with amount to bridge back, contract burns the wrapped tokens and emits
 *      a Wormhole message that the Algorand bridge consumes to unlock the
 *      original ASA.
 *
 *      The wrapped token is a standard ERC-20 with 6 decimals matching the
 *      Algorand ASA's decimal count. It is registerable in CrossCollateralVault
 *      via the standard addAsset() flow, with a Chainlink or Pyth oracle
 *      providing its USD price feed (in production the oracle would read from
 *      the Algorand RWA's off-chain NAV provider).
 */
contract WormholeRwaReceiver is ERC20, AccessControl, ReentrancyGuard, Pausable {

    bytes32 public constant GOVERNOR_ROLE = keccak256("GOVERNOR_ROLE");
    bytes32 public constant RELAYER_ROLE = keccak256("RELAYER_ROLE");

    // Wormhole constants
    uint16 public constant ALGORAND_CHAIN_ID = 8;
    uint16 public constant THIS_CHAIN_ID = 2;  // Ethereum mainnet

    error InvalidVAA(string reason);
    error VAAAlreadyConsumed(bytes32 hash);
    error InvalidEmitter(uint16 chainId, bytes32 emitter);
    error InvalidPayload();
    error EpochLimitExceeded();
    error ZeroAddress();
    error ZeroAmount();

    IWormholeCore public immutable wormholeCore;

    /// @notice Algorand source asset ID that this wrapped token represents.
    uint64 public immutable sourceAssetId;

    /// @notice Algorand peer bridge address (bytes32 padded).
    bytes32 public immutable algorandPeerAddress;

    /// @notice Consumed VAAs to prevent replay.
    mapping(bytes32 => bool) public consumedVAAs;

    /// @notice Per-epoch transfer limit.
    uint256 public epochLimit;
    uint256 public currentEpoch;
    uint256 public transferredThisEpoch;
    uint256 public constant EPOCH_DURATION = 1 days;

    event Bridged(
        address indexed recipient, uint256 amount, bytes32 indexed vaaHash
    );
    event BridgedOut(
        address indexed sender, bytes32 indexed recipient,
        uint256 amount, uint64 nonce
    );

    constructor(
        address admin,
        address _wormholeCore,
        uint64 _sourceAssetId,
        bytes32 _algorandPeerAddress,
        string memory name_,
        string memory symbol_
    ) ERC20(name_, symbol_) {
        if (admin == address(0) || _wormholeCore == address(0)) revert ZeroAddress();
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(GOVERNOR_ROLE, admin);
        _grantRole(RELAYER_ROLE, admin);
        wormholeCore = IWormholeCore(_wormholeCore);
        sourceAssetId = _sourceAssetId;
        algorandPeerAddress = _algorandPeerAddress;
        epochLimit = type(uint256).max;  // unlimited until governance sets one
    }

    function decimals() public pure override returns (uint8) {
        return 6;  // match Algorand ASA decimals
    }

    // ------------------------------------------------------------------
    // INBOUND: CONSUME VAA AND MINT WRAPPED
    // ------------------------------------------------------------------

    function completeTransfer(bytes calldata encodedVM)
        external
        nonReentrant
        whenNotPaused
    {
        (IWormholeCore.VM memory vm, bool valid, string memory reason) =
            wormholeCore.parseAndVerifyVM(encodedVM);

        if (!valid) revert InvalidVAA(reason);

        // Emitter must be our registered Algorand peer.
        if (vm.emitterChainId != ALGORAND_CHAIN_ID
            || vm.emitterAddress != algorandPeerAddress) {
            revert InvalidEmitter(vm.emitterChainId, vm.emitterAddress);
        }

        // Replay protection.
        if (consumedVAAs[vm.hash]) revert VAAAlreadyConsumed(vm.hash);
        consumedVAAs[vm.hash] = true;

        // Decode payload (see Algorand bridge docs for exact layout):
        //   [1 byte] version
        //   [32 bytes] source token (asset_id padded)
        //   [2 bytes] source chain id
        //   [32 bytes] destination recipient (as EVM address, padded)
        //   [2 bytes] destination chain id
        //   [8 bytes] amount
        //   [8 bytes] nonce
        (
            uint64 sourceAsset,
            address recipient,
            uint256 amount
        ) = _decodePayload(vm.payload);

        if (sourceAsset != sourceAssetId) revert InvalidPayload();
        if (recipient == address(0)) revert ZeroAddress();
        if (amount == 0) revert ZeroAmount();

        _enforceEpochLimit(amount);

        _mint(recipient, amount);
        emit Bridged(recipient, amount, vm.hash);
    }

    function _decodePayload(bytes memory payload)
        internal pure returns (uint64 sourceAsset, address recipient, uint256 amount)
    {
        if (payload.length < 85) revert InvalidPayload();
        // Skip version (1) + source token (32) = 33 start
        uint256 offset;
        assembly {
            // Read version
            let version := byte(0, mload(add(payload, 32)))
            // Read source token (last 8 bytes of 32-byte field)
            sourceAsset := shr(192, mload(add(payload, 57)))
            offset := 33
            // Skip source chain id (2)
            offset := add(offset, 2)
            // Read recipient (last 20 bytes of 32-byte field)
            recipient := and(
                mload(add(payload, add(offset, 20))),
                0xffffffffffffffffffffffffffffffffffffffff
            )
            offset := add(offset, 32)
            // Skip destination chain id (2)
            offset := add(offset, 2)
            // Read amount (8 bytes)
            amount := shr(192, mload(add(payload, add(offset, 8))))
        }
    }

    // ------------------------------------------------------------------
    // OUTBOUND: BURN WRAPPED AND EMIT MESSAGE
    // ------------------------------------------------------------------

    function bridgeOut(uint256 amount, bytes32 algorandRecipient)
        external
        nonReentrant
        whenNotPaused
    {
        if (amount == 0) revert ZeroAmount();

        _enforceEpochLimit(amount);

        _burn(msg.sender, amount);

        // In production this would call the Wormhole core's publishMessage
        // with a payload mirroring the inbound format. The relayer picks up
        // the message and submits it to the Algorand bridge, which unlocks
        // the original ASA.
        //
        // Sequence nonce would come from the core bridge call.
        uint64 nonce = 0;

        emit BridgedOut(msg.sender, algorandRecipient, amount, nonce);
    }

    // ------------------------------------------------------------------
    // EPOCH LIMITS
    // ------------------------------------------------------------------

    function _enforceEpochLimit(uint256 amount) internal {
        uint256 epoch = block.timestamp / EPOCH_DURATION;
        if (epoch > currentEpoch) {
            currentEpoch = epoch;
            transferredThisEpoch = amount;
        } else {
            uint256 newTotal = transferredThisEpoch + amount;
            if (newTotal > epochLimit) revert EpochLimitExceeded();
            transferredThisEpoch = newTotal;
        }
    }

    function setEpochLimit(uint256 limit) external onlyRole(GOVERNOR_ROLE) {
        epochLimit = limit;
    }

    // ------------------------------------------------------------------
    // PAUSE & EMERGENCY
    // ------------------------------------------------------------------

    function pause() external onlyRole(DEFAULT_ADMIN_ROLE) { _pause(); }
    function unpause() external onlyRole(GOVERNOR_ROLE) { _unpause(); }
}
