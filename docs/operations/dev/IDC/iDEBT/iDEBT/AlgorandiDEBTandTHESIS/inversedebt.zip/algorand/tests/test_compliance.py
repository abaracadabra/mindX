"""
Test Suite — DELTAVERSE Compliance Integrator
==============================================

Tests the compliance layer that queries AlgoIDNFT (identity), BONAFIDE
(reputation), DAIO (governance), and x402 (payments) subsystems.
"""

from algopy_testing import AlgopyTestContext, algopy_testing_context
from algopy import Account, UInt64, arc4
import pytest

from contracts.stage3_compliance.compliance_integrator import (
    ComplianceIntegrator,
)


class TestComplianceIntegrator:
    """Compliance subsystem configuration and cache behavior."""

    def _setup(self, ctx: AlgopyTestContext) -> ComplianceIntegrator:
        admin = ctx.default_sender
        comp = ComplianceIntegrator()
        comp.create(
            admin=admin,
            algoidnft_app_id=UInt64(1001),
            bonafide_app_id=UInt64(1002),
            daio_app_id=UInt64(1003),
            x402_app_id=UInt64(1004),
            cache_ttl_s=UInt64(3600),  # 1 hour
        )
        return comp

    def test_create_initializes_subsystems(self) -> None:
        with algopy_testing_context() as ctx:
            comp = self._setup(ctx)
            assert comp.algoidnft_app_id.value == UInt64(1001)
            assert comp.bonafide_app_id.value == UInt64(1002)
            assert comp.daio_app_id.value == UInt64(1003)
            assert comp.x402_app_id.value == UInt64(1004)

    def test_cache_ttl_set(self) -> None:
        with algopy_testing_context() as ctx:
            comp = self._setup(ctx)
            assert comp.cache_ttl_s.value == UInt64(3600)

    def test_update_subsystem_app_id(self) -> None:
        with algopy_testing_context() as ctx:
            comp = self._setup(ctx)
            comp.update_algoidnft_app(UInt64(2001))
            assert comp.algoidnft_app_id.value == UInt64(2001)

    def test_min_reputation_configurable(self) -> None:
        with algopy_testing_context() as ctx:
            comp = self._setup(ctx)
            comp.set_min_reputation(UInt64(500))  # minimum BONAFIDE score
            assert comp.min_reputation_score.value == UInt64(500)

    def test_pause_unpause(self) -> None:
        with algopy_testing_context() as ctx:
            comp = self._setup(ctx)
            comp.pause()
            assert comp.paused.value == UInt64(1)
            comp.unpause()
            assert comp.paused.value == UInt64(0)

    def test_admin_transfer(self) -> None:
        with algopy_testing_context() as ctx:
            comp = self._setup(ctx)
            new_admin = ctx.any.account()
            comp.transfer_admin(new_admin)
            assert comp.admin.value == new_admin
