"""
RWA Controller — Stage 1 Core
==============================

Controller contract for a tokenized sovereign debt instrument deployed as an
Algorand Standard Asset (ASA). Unlike the EVM RWAToken.sol which extends ERC-20
with compliance overrides, this contract does NOT replicate the token — it
manages the ASA's lifecycle through Algorand's native asset-control primitives.

Design rationale:

    Algorand ASAs have freeze and clawback addresses baked into the protocol.
    Setting this contract as the ASA's freeze address means the contract's
    logic gates every transfer: a transfer succeeds only if the sender and
    receiver are both unfrozen, and only this contract can toggle the freeze
    bit. That is fundamentally cleaner than the EVM pattern of overriding
    _beforeTokenTransfer on every token instance, because the enforcement
    happens at the consensus layer rather than in contract code.

    The controller also owns the ASA's reserve address so it can mint (for
    initial issuance and later supply increases) and burn (for maturity
    redemption) via inner asset-config transactions.

    Yield distribution uses inner payment transactions rather than the ERC-20
    _transfer approach. At distribution time, the admin calls distribute_yield
    with a snapshot of holder balances passed in via boxes; the contract then
    issues one inner payment per holder. Because Algorand supports 256 inner
    transactions per outer app call, a single call can pay up to 256 holders
    atomically. For larger holder sets, the distribution is paginated.

Key differences from RWAToken.sol:
    - No ERC-20 transfer logic — handled natively by the ASA
    - Freeze/unfreeze = asset-freeze inner transaction, not mapping update
    - Compliance check = box lookup against whitelist, not mapping read
    - Yield distribution = inner payment group, not _transfer loop
    - Maturity = one-shot asset-config to burn supply, not boolean flag
"""

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Global,
    GlobalState,
    LocalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    op,
    subroutine,
)


class RWAController(ARC4Contract):
    """
    Manages the lifecycle of a tokenized sovereign debt ASA.
    """

    def __init__(self) -> None:
        # The ASA this controller manages. Set once at initialization.
        self.rwa_asset_id = GlobalState(UInt64)

        # Admin controlling lifecycle. Future deploys should transfer to
        # the DAIO governance contract after bootstrap.
        self.admin = GlobalState(Account)

        # Compliance officer — can freeze/seize individual accounts for
        # regulatory action. Separate from admin to allow delegation.
        self.compliance_officer = GlobalState(Account)

        # Yield token — the ASA in which coupons are paid (typically USDC ASA).
        self.yield_token = GlobalState(UInt64)

        # Maturity timestamp (Unix seconds). After this, transfers are
        # disabled and only redemption flows are allowed.
        self.maturity_ts = GlobalState(UInt64)

        # Coupon rate in basis points (400 = 4% annual).
        self.coupon_bps = GlobalState(UInt64)

        # Supply cap — maximum asset units that can ever exist.
        self.supply_cap = GlobalState(UInt64)

        # Total yield ever distributed (cumulative), for NAV tracking.
        self.total_yield_distributed = GlobalState(UInt64)

        # Pause switch — emergency halt for transfers and yield.
        self.paused = GlobalState(UInt64)

        # Per-account whitelist for compliance-gated transfers.
        # Box key = account address, value = 1 byte (enabled flag).
        self.whitelist = BoxMap(Account, arc4.Bool)

        # Per-account frozen state for regulatory action.
        self.frozen = BoxMap(Account, arc4.Bool)

    # ------------------------------------------------------------------
    # INITIALIZATION
    # ------------------------------------------------------------------

    @arc4.abimethod(create="require")
    def create(
        self,
        admin: Account,
        compliance_officer: Account,
        yield_token: UInt64,
        maturity_ts: UInt64,
        coupon_bps: UInt64,
        supply_cap: UInt64,
    ) -> None:
        """Initialize the controller. Called once on app creation."""
        assert admin != Global.zero_address, "admin required"
        assert coupon_bps <= UInt64(10_000), "coupon too high"
        assert maturity_ts > Global.latest_timestamp, "maturity in past"

        self.admin.value = admin
        self.compliance_officer.value = compliance_officer
        self.yield_token.value = yield_token
        self.maturity_ts.value = maturity_ts
        self.coupon_bps.value = coupon_bps
        self.supply_cap.value = supply_cap
        self.paused.value = UInt64(0)

    @arc4.abimethod
    def issue_asa(
        self,
        name: arc4.String,
        unit_name: arc4.String,
        metadata_hash: arc4.DynamicBytes,
    ) -> UInt64:
        """
        Issue the underlying ASA with this contract as manager/freeze/clawback.

        The freeze address being the contract is what enforces compliance:
        every holder starts frozen until whitelisted, and transfers require
        the contract to have explicitly unfrozen both parties.
        """
        assert Txn.sender == self.admin.value, "admin only"
        assert self.rwa_asset_id.value == UInt64(0), "already issued"

        # Create the ASA via inner transaction. The contract itself holds
        # the manager/reserve/freeze/clawback roles.
        itxn_result = itxn.AssetConfig(
            total=self.supply_cap.value,
            decimals=6,
            default_frozen=True,  # every holder starts frozen
            asset_name=name.native,
            unit_name=unit_name.native,
            manager=Global.current_application_address,
            reserve=Global.current_application_address,
            freeze=Global.current_application_address,
            clawback=Global.current_application_address,
            metadata_hash=metadata_hash.native,
            fee=UInt64(0),
        ).submit()

        self.rwa_asset_id.value = itxn_result.created_asset.id
        return itxn_result.created_asset.id

    # ------------------------------------------------------------------
    # COMPLIANCE & WHITELIST
    # ------------------------------------------------------------------

    @arc4.abimethod
    def whitelist_account(self, account: Account) -> None:
        """Add an account to the compliance whitelist."""
        assert (
            Txn.sender == self.admin.value
            or Txn.sender == self.compliance_officer.value
        ), "admin or compliance only"
        self.whitelist[account] = arc4.Bool(True)

        # Unfreeze the account for this ASA so transfers work.
        itxn.AssetFreeze(
            freeze_account=account,
            freeze_asset=Asset(self.rwa_asset_id.value),
            frozen=False,
            fee=UInt64(0),
        ).submit()

    @arc4.abimethod
    def revoke_whitelist(self, account: Account) -> None:
        """Remove an account from the whitelist and refreeze."""
        assert (
            Txn.sender == self.admin.value
            or Txn.sender == self.compliance_officer.value
        ), "admin or compliance only"
        del self.whitelist[account]

        itxn.AssetFreeze(
            freeze_account=account,
            freeze_asset=Asset(self.rwa_asset_id.value),
            frozen=True,
            fee=UInt64(0),
        ).submit()

    @arc4.abimethod
    def freeze_account(self, account: Account) -> None:
        """
        Freeze an already-whitelisted account for regulatory action
        without removing them from the whitelist. Used when an
        investigation is pending.
        """
        assert Txn.sender == self.compliance_officer.value, "compliance only"
        self.frozen[account] = arc4.Bool(True)

        itxn.AssetFreeze(
            freeze_account=account,
            freeze_asset=Asset(self.rwa_asset_id.value),
            frozen=True,
            fee=UInt64(0),
        ).submit()

    @arc4.abimethod
    def unfreeze_account(self, account: Account) -> None:
        """Lift a regulatory freeze."""
        assert Txn.sender == self.compliance_officer.value, "compliance only"
        del self.frozen[account]

        # Only unfreeze if still whitelisted.
        if account in self.whitelist:
            itxn.AssetFreeze(
                freeze_account=account,
                freeze_asset=Asset(self.rwa_asset_id.value),
                frozen=False,
                fee=UInt64(0),
            ).submit()

    @arc4.abimethod
    def seize(self, from_account: Account, to: Account, amount: UInt64) -> None:
        """
        Regulatory clawback. Moves tokens from a frozen account to a
        designated treasury. Only callable by compliance officer, only
        against accounts already marked frozen.
        """
        assert Txn.sender == self.compliance_officer.value, "compliance only"
        assert from_account in self.frozen, "target not frozen"

        itxn.AssetTransfer(
            xfer_asset=Asset(self.rwa_asset_id.value),
            asset_sender=from_account,
            asset_receiver=to,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

    # ------------------------------------------------------------------
    # MINTING & BURNING
    # ------------------------------------------------------------------

    @arc4.abimethod
    def mint(self, to: Account, amount: UInt64) -> None:
        """
        Issue new ASA units to a whitelisted recipient. Uses reserve address
        as the source, which the contract controls.
        """
        assert Txn.sender == self.admin.value, "admin only"
        assert to in self.whitelist, "recipient not whitelisted"
        assert self.paused.value == UInt64(0), "paused"

        itxn.AssetTransfer(
            xfer_asset=Asset(self.rwa_asset_id.value),
            asset_receiver=to,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

    @arc4.abimethod
    def burn(self, amount: UInt64) -> None:
        """
        Burn ASA units that the contract holds (after maturity redemption
        has pulled them back). Reduces circulating supply.
        """
        assert Txn.sender == self.admin.value, "admin only"
        itxn.AssetTransfer(
            xfer_asset=Asset(self.rwa_asset_id.value),
            asset_receiver=Global.current_application_address,
            asset_amount=amount,
            close_asset_to=Global.current_application_address,
            fee=UInt64(0),
        ).submit()

    # ------------------------------------------------------------------
    # YIELD DISTRIBUTION
    # ------------------------------------------------------------------

    @arc4.abimethod
    def distribute_yield_to(
        self,
        holder: Account,
        holder_balance: UInt64,
        total_supply_at_snapshot: UInt64,
        total_yield_amount: UInt64,
    ) -> UInt64:
        """
        Pay one holder their pro-rata share of a yield distribution.
        Called once per holder by the distribution keeper. Returns the
        amount paid so the caller can sum for audit.

        For the full set of holders, the keeper submits many calls in an
        atomic group.
        """
        assert Txn.sender == self.admin.value, "admin only"
        assert self.paused.value == UInt64(0), "paused"
        assert total_supply_at_snapshot > UInt64(0), "zero supply"

        # pro-rata share
        share = (holder_balance * total_yield_amount) // total_supply_at_snapshot
        if share == UInt64(0):
            return UInt64(0)

        itxn.AssetTransfer(
            xfer_asset=Asset(self.yield_token.value),
            asset_receiver=holder,
            asset_amount=share,
            fee=UInt64(0),
        ).submit()

        self.total_yield_distributed.value = (
            self.total_yield_distributed.value + share
        )
        return share

    # ------------------------------------------------------------------
    # MATURITY
    # ------------------------------------------------------------------

    @arc4.abimethod
    def is_mature(self) -> arc4.Bool:
        """Has the instrument reached maturity?"""
        return arc4.Bool(Global.latest_timestamp >= self.maturity_ts.value)

    @arc4.abimethod
    def redeem_at_maturity(self, holder: Account, amount: UInt64) -> None:
        """
        After maturity, holders can redeem their ASA units for the yield
        token at par. The contract must have pre-funded redemption reserves.
        """
        assert Global.latest_timestamp >= self.maturity_ts.value, "not mature"
        assert holder in self.whitelist, "not whitelisted"

        # Pull ASA from holder (clawback privilege).
        itxn.AssetTransfer(
            xfer_asset=Asset(self.rwa_asset_id.value),
            asset_sender=holder,
            asset_receiver=Global.current_application_address,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

        # Pay out in yield token at 1:1 face value.
        itxn.AssetTransfer(
            xfer_asset=Asset(self.yield_token.value),
            asset_receiver=holder,
            asset_amount=amount,
            fee=UInt64(0),
        ).submit()

    # ------------------------------------------------------------------
    # PAUSE & ADMIN
    # ------------------------------------------------------------------

    @arc4.abimethod
    def pause(self) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.paused.value = UInt64(1)

    @arc4.abimethod
    def unpause(self) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.paused.value = UInt64(0)

    @arc4.abimethod
    def transfer_admin(self, new_admin: Account) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.admin.value = new_admin
