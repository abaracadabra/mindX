"""
DELTAVERSE Compliance Integrator — Stage 3
============================================

Integrates the DELTAVERSE ecosystem's compliance primitives into the RWA
protocol stack. This is the contract that turns "DeFi protocol that
happens to tokenize RWA" into "regulated financial product using blockchain
rails."

The four DELTAVERSE subsystems it queries:

    AlgoIDNFT — sovereign identity NFTs. Each verified participant holds
        an AlgoIDNFT issued by their jurisdiction's compliance authority.
        For RWA access, the protocol checks that the holder's AlgoIDNFT
        carries an "accredited investor" credential and is valid in the
        relevant jurisdiction.

    BONAFIDE — reputation tokens. Reflects a participant's on-chain
        history including settled trades, repaid loans, governance
        participation. Vault deposits above certain thresholds require
        a BONAFIDE reputation score exceeding a governance-set floor,
        preventing Sybil attacks on undercollateralized positions.

    DAIO — governance. Decentralized Autonomous Investment Organization
        holds admin roles across the stack. The integrator verifies that
        proposed parameter changes originated from a passed DAIO proposal
        before applying them.

    x402 — payment rails. The HTTP-402-compliant micropayment system used
        for protocol fees, keeper incentives, and cross-chain bridge tolls.
        The integrator checks that the caller has a current x402
        subscription before executing fee-charged operations.

The integrator does NOT reimplement any of these subsystems. It queries
them via app-ID references passed at deployment time, reading their
public state. The subsystems themselves are assumed to exist as separate
deployments in the broader DELTAVERSE mesh.

This design maps to ERC-3643's ONCHAINID compliance model (the EU-
sanctioned standard for tokenized securities) but using Algorand-native
primitives. ONCHAINID stores claims about an identity on-chain in a
registry queried by the token contract before every transfer. AlgoIDNFT
does the same thing but as an ASA with structured metadata, which is
cheaper and composable with the rest of the Algorand tooling.
"""

from algopy import (
    ARC4Contract,
    Account,
    Asset,
    BoxMap,
    Global,
    GlobalState,
    Txn,
    UInt64,
    arc4,
    gtxn,
    itxn,
    subroutine,
)


class ComplianceCheck(arc4.Struct):
    """Bundle of subsystem assertions for a compliance decision."""
    algoidnft_valid: arc4.Bool
    bonafide_score: arc4.UInt32
    daio_approved: arc4.Bool
    x402_active: arc4.Bool
    jurisdiction: arc4.StaticArray[arc4.Byte, arc4.Literal[2]]
    check_timestamp: arc4.UInt64


class ComplianceIntegrator(ARC4Contract):
    """
    Single entry point for compliance checks required by the RWA stack.
    """

    def __init__(self) -> None:
        self.admin = GlobalState(Account)

        # App IDs of the four DELTAVERSE subsystems.
        self.algoidnft_app = GlobalState(UInt64)
        self.bonafide_app = GlobalState(UInt64)
        self.daio_app = GlobalState(UInt64)
        self.x402_app = GlobalState(UInt64)

        # Minimum reputation scores for different operation types.
        self.min_score_vault_deposit = GlobalState(UInt64)
        self.min_score_thesis_open = GlobalState(UInt64)
        self.min_score_leverage_above_5x = GlobalState(UInt64)

        # Allowed jurisdictions for RWA holders (bitmap via box).
        # Key = ISO 3166-1 alpha-2 country code, value = bool.
        self.allowed_jurisdictions = BoxMap(
            arc4.StaticArray[arc4.Byte, arc4.Literal[2]], arc4.Bool
        )

        # Cache of recent compliance checks to avoid re-querying.
        # Key = account, value = ComplianceCheck with timestamp.
        self.compliance_cache = BoxMap(Account, ComplianceCheck)

        # Cache TTL in seconds.
        self.cache_ttl_s = GlobalState(UInt64)

    @arc4.abimethod(create="require")
    def create(
        self,
        admin: Account,
        algoidnft_app: UInt64,
        bonafide_app: UInt64,
        daio_app: UInt64,
        x402_app: UInt64,
    ) -> None:
        self.admin.value = admin
        self.algoidnft_app.value = algoidnft_app
        self.bonafide_app.value = bonafide_app
        self.daio_app.value = daio_app
        self.x402_app.value = x402_app
        self.min_score_vault_deposit.value = UInt64(100)
        self.min_score_thesis_open.value = UInt64(250)
        self.min_score_leverage_above_5x.value = UInt64(500)
        self.cache_ttl_s.value = UInt64(3600)  # 1 hour

    # ------------------------------------------------------------------
    # SUBSYSTEM QUERIES
    # ------------------------------------------------------------------

    @subroutine
    def _query_algoidnft_valid(self, account: Account) -> arc4.Bool:
        """
        Query AlgoIDNFT: does this account hold a valid identity NFT with
        an accredited-investor credential?

        Implementation: reads the AlgoIDNFT app's local state for this
        account, checking the `credential_bitmap` field for the
        ACCREDITED_INVESTOR bit. Since cross-app reads use inner
        application calls, we call a read-only method on the AlgoIDNFT
        app.

        For the skeleton we return True if the account has opted into the
        AlgoIDNFT app; production integration would decode the full
        credential structure.
        """
        # In production: inner ApplicationCall to the algoidnft_app's
        # `is_accredited(account)` method. Using a placeholder here.
        return arc4.Bool(True)

    @subroutine
    def _query_bonafide_score(self, account: Account) -> arc4.UInt32:
        """Query BONAFIDE reputation score."""
        # Placeholder: production calls bonafide_app.get_score(account)
        return arc4.UInt32(500)

    @subroutine
    def _query_daio_approval(self, proposal_id: arc4.UInt64) -> arc4.Bool:
        """Query DAIO: was a given proposal approved and executed?"""
        # Placeholder: production calls daio_app.is_executed(proposal_id)
        return arc4.Bool(True)

    @subroutine
    def _query_x402_active(self, account: Account) -> arc4.Bool:
        """Query x402: does this account have an active subscription?"""
        # Placeholder: production calls x402_app.has_active_sub(account)
        return arc4.Bool(True)

    # ------------------------------------------------------------------
    # COMPOSITE COMPLIANCE CHECKS
    # ------------------------------------------------------------------

    @arc4.abimethod
    def check_rwa_transfer(
        self,
        sender: Account,
        receiver: Account,
    ) -> arc4.Bool:
        """
        Compliance gate for RWA transfers. Both parties must have valid
        AlgoIDNFT with accredited-investor credential AND allowed
        jurisdiction.
        """
        sender_valid = self._query_algoidnft_valid(sender)
        receiver_valid = self._query_algoidnft_valid(receiver)

        if not sender_valid.native:
            return arc4.Bool(False)
        if not receiver_valid.native:
            return arc4.Bool(False)

        # In production: also check jurisdiction codes via box lookup.
        return arc4.Bool(True)

    @arc4.abimethod
    def check_vault_deposit(
        self,
        account: Account,
        amount_usd_e6: UInt64,
    ) -> arc4.Bool:
        """
        Compliance gate for vault deposits. Requires AlgoIDNFT plus
        BONAFIDE score above the vault deposit threshold. Above $1M
        notional additionally requires x402 subscription for enhanced
        monitoring.
        """
        if not self._query_algoidnft_valid(account).native:
            return arc4.Bool(False)

        score = self._query_bonafide_score(account)
        if UInt64(score.native) < self.min_score_vault_deposit.value:
            return arc4.Bool(False)

        # Large deposit threshold
        LARGE_DEPOSIT = UInt64(1_000_000_000_000)  # $1M in 1e6 units
        if amount_usd_e6 > LARGE_DEPOSIT:
            if not self._query_x402_active(account).native:
                return arc4.Bool(False)

        return arc4.Bool(True)

    @arc4.abimethod
    def check_thesis_open(
        self,
        account: Account,
        leverage: UInt64,
    ) -> arc4.Bool:
        """
        Compliance gate for opening a recursive thesis position.
        Higher leverage requires higher BONAFIDE score.
        """
        if not self._query_algoidnft_valid(account).native:
            return arc4.Bool(False)

        score = UInt64(self._query_bonafide_score(account).native)
        required = self.min_score_thesis_open.value
        if leverage > UInt64(5):
            required = self.min_score_leverage_above_5x.value

        if score < required:
            return arc4.Bool(False)

        return arc4.Bool(True)

    @arc4.abimethod
    def check_governance_action(
        self,
        proposal_id: UInt64,
    ) -> arc4.Bool:
        """
        Compliance gate for admin actions that claim to originate from a
        DAIO proposal. Verifies the proposal actually passed.
        """
        return self._query_daio_approval(arc4.UInt64(proposal_id))

    # ------------------------------------------------------------------
    # CACHING
    # ------------------------------------------------------------------

    @arc4.abimethod
    def refresh_compliance_cache(self, account: Account) -> ComplianceCheck:
        """
        Fetch a fresh compliance snapshot for `account`, store it in the
        cache, and return it. Other contracts in the stack can then read
        the cache for TTL seconds without paying the cost of all four
        subsystem queries each time.
        """
        algoidnft_valid = self._query_algoidnft_valid(account)
        bonafide_score = self._query_bonafide_score(account)
        x402_active = self._query_x402_active(account)

        # Jurisdiction is read from AlgoIDNFT metadata; placeholder here.
        jurisdiction = arc4.StaticArray[arc4.Byte, arc4.Literal[2]](
            (arc4.Byte(ord('U')), arc4.Byte(ord('S')))
        )

        check = ComplianceCheck(
            algoidnft_valid=algoidnft_valid,
            bonafide_score=bonafide_score,
            daio_approved=arc4.Bool(True),  # not applicable for user checks
            x402_active=x402_active,
            jurisdiction=jurisdiction,
            check_timestamp=arc4.UInt64(Global.latest_timestamp),
        )
        self.compliance_cache[account] = check.copy()
        return check

    @arc4.abimethod(readonly=True)
    def get_cached_check(self, account: Account) -> ComplianceCheck:
        """Read the cached compliance snapshot without refreshing."""
        if account not in self.compliance_cache:
            return ComplianceCheck(
                algoidnft_valid=arc4.Bool(False),
                bonafide_score=arc4.UInt32(0),
                daio_approved=arc4.Bool(False),
                x402_active=arc4.Bool(False),
                jurisdiction=arc4.StaticArray[arc4.Byte, arc4.Literal[2]](
                    (arc4.Byte(0), arc4.Byte(0))
                ),
                check_timestamp=arc4.UInt64(0),
            )
        return self.compliance_cache[account]

    # ------------------------------------------------------------------
    # ADMIN
    # ------------------------------------------------------------------

    @arc4.abimethod
    def set_min_scores(
        self,
        vault: UInt64,
        thesis: UInt64,
        leverage: UInt64,
    ) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.min_score_vault_deposit.value = vault
        self.min_score_thesis_open.value = thesis
        self.min_score_leverage_above_5x.value = leverage

    @arc4.abimethod
    def allow_jurisdiction(
        self,
        code: arc4.StaticArray[arc4.Byte, arc4.Literal[2]],
    ) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        self.allowed_jurisdictions[code] = arc4.Bool(True)

    @arc4.abimethod
    def revoke_jurisdiction(
        self,
        code: arc4.StaticArray[arc4.Byte, arc4.Literal[2]],
    ) -> None:
        assert Txn.sender == self.admin.value, "admin only"
        del self.allowed_jurisdictions[code]
