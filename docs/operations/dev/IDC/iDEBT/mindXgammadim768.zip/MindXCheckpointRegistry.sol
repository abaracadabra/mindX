// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

/**
 * @title MindXCheckpointRegistry
 * @notice Anchors mindX AutoTune .ait artifact manifest hashes on-chain.
 *         Each unique manifest SHA-256 mints exactly one ERC-1155-style
 *         token whose id is `uint256(manifestHash)`. This makes a tuned
 *         mindX checkpoint into a verifiable, transferable provenance asset.
 *
 *         Designed to slot into the DELTAVERSE THOT (immutable memory unit)
 *         pattern. A separate BONAFIDE Tabularium contract can subscribe to
 *         CheckpointRegistered events to accrue reputation to registrants.
 *
 * @dev    Intentionally minimal. No royalties, no upgradability, no metadata
 *         contract — the manifest URI is the source of truth and is itself
 *         hash-verified off-chain.
 */
contract MindXCheckpointRegistry {
    // ---------------------------------------------------------------------
    // Events (ERC-1155 TransferSingle is intentionally NOT emitted — these
    // tokens are non-transferable provenance markers, not fungible assets)
    // ---------------------------------------------------------------------
    event CheckpointRegistered(
        uint256 indexed tokenId,
        bytes32 indexed manifestHash,
        address indexed registrant,
        string name,
        string uri
    );

    event CheckpointRevoked(
        uint256 indexed tokenId,
        address indexed revoker,
        string reason
    );

    // ---------------------------------------------------------------------
    // Storage
    // ---------------------------------------------------------------------
    struct Checkpoint {
        address registrant;
        uint64 registeredAt;
        bool revoked;
        string name;
        string uri;
    }

    /// manifestHash → tokenId (== uint256(manifestHash) for fast derivation)
    mapping(bytes32 => uint256) public tokenIdOf;
    /// tokenId → checkpoint record
    mapping(uint256 => Checkpoint) public checkpoints;
    /// total checkpoints registered (monotonically increasing)
    uint256 public totalRegistered;

    /// Optional governance — if set, only this address can revoke checkpoints.
    /// Set to address(0) to disable revocation entirely.
    address public immutable governor;

    // ---------------------------------------------------------------------
    constructor(address _governor) {
        governor = _governor;
    }

    // ---------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------
    error AlreadyRegistered(uint256 tokenId);
    error NotRegistered(bytes32 manifestHash);
    error EmptyName();
    error EmptyUri();
    error OnlyGovernor();
    error AlreadyRevoked();

    // ---------------------------------------------------------------------
    // Public API
    // ---------------------------------------------------------------------

    /**
     * @notice Register a new mindX checkpoint by its manifest SHA-256.
     * @param manifestHash SHA-256 of the canonical .manifest.json
     * @param name         Human-readable name (e.g. "mindx_v9.6.4")
     * @param uri          Where the .ait artifact lives (HTTPS or ipfs://)
     * @return tokenId     The ERC-1155-style token id (== uint256(manifestHash))
     */
    function register(
        bytes32 manifestHash,
        string calldata name,
        string calldata uri
    ) external returns (uint256 tokenId) {
        if (bytes(name).length == 0) revert EmptyName();
        if (bytes(uri).length == 0) revert EmptyUri();

        tokenId = uint256(manifestHash);
        if (checkpoints[tokenId].registeredAt != 0) {
            revert AlreadyRegistered(tokenId);
        }

        checkpoints[tokenId] = Checkpoint({
            registrant: msg.sender,
            registeredAt: uint64(block.timestamp),
            revoked: false,
            name: name,
            uri: uri
        });
        tokenIdOf[manifestHash] = tokenId;
        unchecked { ++totalRegistered; }

        emit CheckpointRegistered(tokenId, manifestHash, msg.sender, name, uri);
    }

    /**
     * @notice Verify a manifest hash exists and is not revoked.
     * @return tokenId        Token id, or 0 if not registered
     * @return registrant     Address that registered, or address(0)
     * @return registeredAt   Unix timestamp of registration, or 0
     */
    function verify(bytes32 manifestHash)
        external
        view
        returns (uint256 tokenId, address registrant, uint64 registeredAt)
    {
        tokenId = uint256(manifestHash);
        Checkpoint memory cp = checkpoints[tokenId];
        if (cp.registeredAt == 0 || cp.revoked) {
            return (0, address(0), 0);
        }
        return (tokenId, cp.registrant, cp.registeredAt);
    }

    /**
     * @notice Governor-only revocation for compromised or superseded checkpoints.
     */
    function revoke(bytes32 manifestHash, string calldata reason) external {
        if (msg.sender != governor) revert OnlyGovernor();
        uint256 tokenId = uint256(manifestHash);
        Checkpoint storage cp = checkpoints[tokenId];
        if (cp.registeredAt == 0) revert NotRegistered(manifestHash);
        if (cp.revoked) revert AlreadyRevoked();
        cp.revoked = true;
        emit CheckpointRevoked(tokenId, msg.sender, reason);
    }

    /**
     * @notice ERC-1155-compatible balanceOf — returns 1 if `account` registered
     *         the checkpoint identified by `tokenId`, else 0. Implements the
     *         minimum subset needed for indexers like The Graph to treat each
     *         checkpoint as a soulbound NFT-like asset.
     */
    function balanceOf(address account, uint256 tokenId) external view returns (uint256) {
        Checkpoint memory cp = checkpoints[tokenId];
        if (cp.registeredAt == 0 || cp.revoked) return 0;
        return cp.registrant == account ? 1 : 0;
    }

    /**
     * @notice Metadata URI per ERC-1155.
     */
    function uri(uint256 tokenId) external view returns (string memory) {
        return checkpoints[tokenId].uri;
    }
}
