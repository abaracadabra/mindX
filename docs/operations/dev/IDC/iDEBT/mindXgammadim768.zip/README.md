# mindX AutoTune

Post-training inference compilation for the mindX consciousness-vector stack,
built on top of NVIDIA AITune and integrated with the DELTAVERSE provenance layer.

**What it does:** takes a trained mindX checkpoint, benchmarks every available
inference backend (TensorRT, Torch-TensorRT AOT, TorchAO, Torch Inductor) on
each layer, picks the winner per layer, and produces a hash-verifiable `.ait`
artifact suitable for distribution via `mindx.pythai.net` and on-chain
anchoring as a THOT ERC-1155 token.

**Architectural premise:**
> AITune compiles, mindX trains, BONAFIDE attests, THOT remembers, AgenticPlace transacts.

---

## Install

```bash
# CPU dev (tests only)
pip install -e .[dev]

# GPU production
pip install --extra-index-url https://pypi.nvidia.com -e .[gpu,api,chain,dev]
```

Requires Linux, Python ≥ 3.10, PyTorch ≥ 2.7, TensorRT ≥ 10.5, an NVIDIA GPU.

---

## Quickstart

```python
import torch
from mindx.tune import AutoTune, AutoTuneConfig

# Your trained mindX pipeline + an evaluation batch
model = load_mindx_checkpoint("mindx_v9.6.4.pt")
sample = next(iter(eval_dataloader))

# Production preset: per-layer routing with TRT/AO/Inductor
cfg = AutoTuneConfig.production_default()
result = AutoTune(cfg).run(
    pipeline=model,
    sample_inputs=sample,
    artifact_name="mindx_v9.6.4",
)

print(result.summary())
# → checkpoints/mindx_v9.6.4.ait
# → checkpoints/mindx_v9.6.4.manifest.json
# → checkpoints/mindx_v9.6.4.manifest.json.sha256

# Anchor on Polygon as a THOT ERC-1155 token
from mindx.tune.chain import ChainConfig, CheckpointAnchor
anchor = CheckpointAnchor(ChainConfig.from_env())
receipt = anchor.anchor(
    manifest_sha256_hex=result.artifact_paths.sha256_hex,
    name="mindx_v9.6.4",
    uri="https://mindx.pythai.net/checkpoints/mindx_v9.6.4/ait",
)
print(f"Token id: {receipt['token_id']}, tx: {receipt['tx_hash']}")
```

---

## Module map

| File | Responsibility |
|---|---|
| `mindx/tune/base.py` | `MindXBackend` ABC, `TuneOutcome`, benchmark + correctness helpers |
| `mindx/tune/backends.py` | Concrete AITune wrappers (TRT, Torch-TRT, TorchAO, Inductor, Eager) |
| `mindx/tune/strategies.py` | `SafeFallback`, `GlobalThroughput`, `PerLayer` strategy patterns |
| `mindx/tune/inspect.py` | Pipeline walk + HTML/JSON inspection report |
| `mindx/tune/artifact.py` | `.ait` + manifest + SHA-256 sidecar with integrity verification |
| `mindx/tune/autotune.py` | The `AutoTune` orchestrator + `AutoTuneConfig` presets |
| `mindx/tune/chain.py` | `CheckpointAnchor` — web3.py wrapper for the registry contract |
| `mindx/tune/api.py` | FastAPI service for `mindx.pythai.net/checkpoints/...` |
| `contracts/MindXCheckpointRegistry.sol` | Solidity registry — manifest hash → ERC-1155 token id |
| `test/MindXCheckpointRegistry.t.sol` | Foundry tests for the registry |
| `tests/test_autotune.py` | Python tests (CPU-runnable) |

---

## Design decisions worth knowing

**JIT is forbidden in production.** AITune's just-in-time path can't extrapolate
batch sizes, can't benchmark across backends, can't save artifacts, and re-tunes
every Python session. `AutoTuneConfig.forbid_jit=True` (the default) hard-fails
if the JIT autowrapt env var is set. JIT is reserved for local exploration only.

**Per-layer strategy routing.** The 6-layer mindX architecture is heterogeneous:
the embedding wants quantization (TorchAO), attention wants TRT or Inductor,
the gamma-modulation head graph-breaks and needs Inductor. `PerLayerStrategy`
routes each layer to its appropriate backend. The `production_default()` preset
ships with sensible routes for the canonical mindX layer names.

**Correctness gate before benchmark.** Every compiled module is diff-checked
against the eager reference (max abs error vs `atol=1e-2` for FP16). A backend
that compiles but produces wrong outputs is rejected and the strategy moves on.
This is stricter than AITune, which leaves correctness to the caller.

**Manifest SHA-256 is the chain anchor.** The `.ait` binary is hardware-specific
and not the right thing to hash. The canonical JSON manifest — which records
the layer-to-backend mapping, latencies, speedups, and host environment — is
what gets SHA-256'd and minted as a THOT token. To verify a downloaded
checkpoint: re-hash its manifest, look up the hash in the registry, confirm
registrant + non-revoked status.

**Hardware-targeted artifacts.** `.ait` files are tied to the GPU they were
tuned on. Distribute one variant per target GPU class (e.g. `mindx_v9.6.4_a100.ait`,
`mindx_v9.6.4_rtx4090.ait`) or fall back to TorchInductor which is more portable.

---

## Foundry workflow

```bash
# Install Foundry deps (forge-std)
forge install foundry-rs/forge-std --no-commit

# Run all tests
forge test -vvv

# Run with full fuzz coverage
forge test --profile ci

# Deploy to Polygon mainnet
forge create contracts/MindXCheckpointRegistry.sol:MindXCheckpointRegistry \
    --rpc-url $POLYGON_RPC_URL \
    --private-key $MINDX_DEPLOYER_KEY \
    --constructor-args $GOVERNOR_ADDRESS \
    --etherscan-api-key $POLYGONSCAN_API_KEY \
    --verify
```

After deploy, set:
```bash
export MINDX_REGISTRY_ADDRESS=0x...
export MINDX_THOT_ADDRESS=0x...        # existing THOT ERC-1155
export MINDX_RPC_URL=https://polygon-rpc.com
export MINDX_CHAIN_ID=137
export MINDX_DEPLOYER_KEY=0x...
```

---

## API service

```bash
MINDX_CHECKPOINTS_DIR=./checkpoints \
MINDX_API_PORT=8765 \
python -m mindx.tune.api
```

Routes:
- `GET /checkpoints` — list all artifacts
- `GET /checkpoints/{name}` — manifest JSON
- `GET /checkpoints/{name}/ait` — binary download (also sets `X-Mindx-Sha256` header)
- `GET /checkpoints/{name}/sha256` — chain-anchored hash
- `POST /checkpoints/{name}/verify` — local + on-chain integrity check

This is what `mindx.pythai.net` should front. AgenticPlace agents pull from
`/ait`, verify against the registry via `/verify`, then use the checkpoint for
inference.

---

## Integration touchpoints

| System | How it connects |
|---|---|
| **mindX trainer** | Calls `AutoTune.run(trained_model, eval_batch)` after training completes |
| **mindx.pythai.net** | Hosts `mindx.tune.api:create_app()` — serves `.ait` + manifest |
| **AgenticPlace** | Agents pull `.ait` artifacts; verify via `/checkpoints/{name}/verify` |
| **BONAFIDE Tabularium** | Subscribes to `CheckpointRegistered` events for reputation accrual |
| **THOT (ERC-1155)** | Each manifest hash becomes one immutable memory unit token |
| **BANKON AlgoIDNFT** | Registrant address resolves to a sovereign identity via DID |
| **x402 / parsec** | Paid checkpoint access — gate `/ait` downloads behind x402 micropayment |

---

## License

Apache-2.0
