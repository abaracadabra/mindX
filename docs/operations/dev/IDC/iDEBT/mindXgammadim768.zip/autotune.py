"""AutoTune — the single public entry point for tuning a mindX pipeline.

Usage:
    from mindx.tune import AutoTune, AutoTuneConfig

    cfg = AutoTuneConfig.production_default()
    result = AutoTune(cfg).run(
        pipeline=mindx_model,
        sample_inputs=eval_batch,
        artifact_name="mindx_v9.6.4",
    )
    # result.artifact_paths.sha256_hex → anchor on-chain
    # result.report → write to mindx.pythai.net for AgenticPlace
"""
from __future__ import annotations

import dataclasses
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional

import torch
import torch.nn as nn

from mindx.tune.artifact import AitArtifact, ArtifactPaths, ArtifactSpec, build_spec
from mindx.tune.backends import (
    MindXEagerBackend,
    MindXTensorRTBackend,
    MindXTorchAOBackend,
    MindXTorchInductorBackend,
    available_backends,
)
from mindx.tune.base import BackendKind, MindXBackend, TuneOutcome
from mindx.tune.inspect import InspectionReport, inspect_pipeline
from mindx.tune.strategies import (
    GlobalThroughputStrategy,
    PerLayerStrategy,
    SafeFallbackStrategy,
    StrategyKind,
    TuneStrategy,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
@dataclasses.dataclass
class AutoTuneConfig:
    """All knobs in one place. Construct via .production_default() unless you
    know what you're doing."""

    strategy: TuneStrategy
    output_dir: Path = Path("./checkpoints")
    artifact_name: str = "mindx_tuned"
    inspection_min_params: int = 1024
    correctness_atol: float = 1e-2          # FP16 ONNX drift
    benchmark_warmup: int = 10
    benchmark_iters: int = 100
    enable_nvtx: bool = False               # set to True locally for Nsight
    forbid_jit: bool = True                 # never use AITune JIT in prod
    fall_back_to_eager: bool = True         # if every backend fails, keep module
    mindx_version: str = "9.6.4"
    autotune_version: str = "0.1.0"

    # ----- presets --------------------------------------------------------
    @classmethod
    def production_default(cls) -> "AutoTuneConfig":
        """Per-layer strategy tuned for the canonical 6-layer mindX architecture.

        Routing:
          * embedding   → TorchAO (quantization-friendly)
          * attention   → SafeFallback(TRT → Inductor)
          * gamma_head  → Inductor only (graph breaks expected)
          * default     → GlobalThroughput (pick the fastest)
        """
        backends_all = available_backends()
        if not backends_all:
            # CPU dev box — fall back to a no-op strategy that returns eager
            return cls(strategy=SafeFallbackStrategy(
                backends=[MindXEagerBackend()], require_correctness=False,
            ))

        trt = next((b for b in backends_all if b.kind == BackendKind.TENSORRT), None)
        ao = next((b for b in backends_all if b.kind == BackendKind.TORCH_AO), None)
        ind = next((b for b in backends_all if b.kind == BackendKind.TORCH_INDUCTOR), None)

        routes: dict[str, TuneStrategy] = {}
        if ao:
            routes["embedding"] = SafeFallbackStrategy(backends=[ao])
        if trt and ind:
            routes["attention"] = SafeFallbackStrategy(backends=[trt, ind])
        if ind:
            routes["gamma"] = SafeFallbackStrategy(backends=[ind])

        default = GlobalThroughputStrategy(backends=backends_all)
        strategy = PerLayerStrategy(routes=routes, default=default) if routes else default
        return cls(strategy=strategy)

    @classmethod
    def fastest_possible(cls) -> "AutoTuneConfig":
        """Benchmark every backend on every layer. Slow to tune, fastest at runtime."""
        return cls(strategy=GlobalThroughputStrategy(backends=available_backends()))

    @classmethod
    def safe_minimal(cls, backend: MindXBackend) -> "AutoTuneConfig":
        """Use exactly one backend everywhere — deterministic, fastest tune time."""
        return cls(strategy=SafeFallbackStrategy(backends=[backend]))


# ---------------------------------------------------------------------------
@dataclasses.dataclass
class AutoTuneResult:
    pipeline: nn.Module                          # tuned, ready for inference
    artifact_paths: ArtifactPaths
    inspection: InspectionReport
    layer_outcomes: dict[str, TuneOutcome]       # winner per layer
    all_attempts: dict[str, list[TuneOutcome]]   # full audit trail
    eager_baselines_ms: dict[str, float]
    total_tune_seconds: float

    def summary(self) -> str:
        lines = [
            f"AutoTune complete — {len(self.layer_outcomes)} layers tuned in "
            f"{self.total_tune_seconds:.1f}s",
            f"Artifact: {self.artifact_paths.ait}",
            f"Manifest SHA-256 (anchor this on-chain): {self.artifact_paths.sha256_hex}",
            "",
            "Per-layer winners:",
        ]
        for name, outcome in self.layer_outcomes.items():
            base = self.eager_baselines_ms.get(name)
            speedup = (base / outcome.latency_ms) if base and outcome.latency_ms else 0.0
            lines.append(
                f"  {name:50s} {outcome.backend.value:18s} "
                f"{outcome.latency_ms:7.3f} ms  ({speedup:.1f}× vs eager)"
            )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
class AutoTune:
    """Orchestrates the full inspect → tune → save → anchor pipeline."""

    def __init__(self, config: AutoTuneConfig):
        self.config = config
        if config.enable_nvtx:
            os.environ.setdefault("NVTX_ENABLE", "1")
            logger.info("[autotune] NVTX profiling enabled")

    # ----- main entry point -----------------------------------------------
    def run(
        self,
        pipeline: nn.Module,
        sample_inputs: Any,
        *,
        artifact_name: Optional[str] = None,
        dynamic_axes_per_layer: Optional[dict[str, dict]] = None,
    ) -> AutoTuneResult:
        if self.config.forbid_jit and os.environ.get("AUTOWRAPT_BOOTSTRAP") == "aitune_enable_jit_tuning":
            raise RuntimeError(
                "AUTOWRAPT_BOOTSTRAP=aitune_enable_jit_tuning is set but "
                "AutoTuneConfig.forbid_jit=True. JIT mode produces "
                "non-reproducible artifacts and is forbidden in production."
            )

        t_start = time.perf_counter()
        artifact_name = artifact_name or self.config.artifact_name

        # 1. Inspect
        logger.info("[autotune] inspecting pipeline %s", pipeline.__class__.__name__)
        inspection = inspect_pipeline(
            pipeline, sample_inputs, min_params=self.config.inspection_min_params,
        )
        logger.info("[autotune] %d tunable / %d skipped / %d total modules",
                    len(inspection.tunable_modules),
                    len(inspection.skipped_modules),
                    inspection.total_modules)

        # 2. Eager baselines for speedup reporting
        eager = MindXEagerBackend()
        eager_baselines: dict[str, float] = {}
        for module_report in inspection.tunable_modules:
            module = pipeline.get_submodule(module_report.name)
            try:
                # we don't know the per-layer sample inputs without hooks;
                # use forward-hook capture in a richer impl. For now we time
                # the whole pipeline as a single baseline and apportion later.
                pass
            except Exception:
                pass
        # Pipeline-level baseline
        try:
            mean_ms, _ = eager.benchmark(
                pipeline, sample_inputs,
                warmup=self.config.benchmark_warmup,
                iters=self.config.benchmark_iters,
            )
            eager_baselines["__pipeline__"] = mean_ms
            logger.info("[autotune] eager pipeline baseline: %.3f ms", mean_ms)
        except Exception as e:
            logger.warning("[autotune] eager baseline failed: %s", e)

        # 3. Tune each module via the configured strategy
        layer_outcomes: dict[str, TuneOutcome] = {}
        all_attempts: dict[str, list[TuneOutcome]] = {}

        for module_report in inspection.tunable_modules:
            name = module_report.name
            module = pipeline.get_submodule(name)
            per_layer_axes = (dynamic_axes_per_layer or {}).get(name)

            # Capture per-layer inputs with a forward hook
            captured: dict[str, Any] = {}
            handle = module.register_forward_pre_hook(
                lambda m, args, kwargs={}, store=captured: store.update({"args": args, "kwargs": kwargs}),
                with_kwargs=True,
            )
            try:
                with torch.inference_mode():
                    eager._invoke(pipeline, sample_inputs)
            finally:
                handle.remove()

            if "args" not in captured:
                logger.warning("[autotune] %s: no inputs captured, skipping", name)
                continue

            layer_inputs = captured["args"] if not captured.get("kwargs") else (
                {**dict(zip([], captured["args"])), **captured["kwargs"]}
            )

            compiled, attempts = self.config.strategy.select(
                module, name, layer_inputs, dynamic_axes=per_layer_axes,
            )
            all_attempts[name] = attempts

            if compiled is not None:
                _replace_submodule(pipeline, name, compiled)
                winner = next((a for a in attempts if a.success), None)
                if winner:
                    layer_outcomes[name] = winner
            else:
                logger.warning("[autotune] %s: every backend failed", name)
                if not self.config.fall_back_to_eager:
                    raise RuntimeError(
                        f"AutoTune failed on {name} and fall_back_to_eager=False"
                    )

        # 4. Build manifest and save
        spec = build_spec(
            name=artifact_name,
            mindx_version=self.config.mindx_version,
            autotune_version=self.config.autotune_version,
            layer_outcomes=layer_outcomes,
            eager_baselines={k: eager_baselines.get("__pipeline__", 0.0) for k in layer_outcomes},
        )
        artifact = AitArtifact(pipeline, spec)
        paths = artifact.save(self.config.output_dir / artifact_name)

        total_s = time.perf_counter() - t_start
        return AutoTuneResult(
            pipeline=pipeline,
            artifact_paths=paths,
            inspection=inspection,
            layer_outcomes=layer_outcomes,
            all_attempts=all_attempts,
            eager_baselines_ms=eager_baselines,
            total_tune_seconds=total_s,
        )


# ---------------------------------------------------------------------------
def _replace_submodule(root: nn.Module, dotted_name: str, new_module: nn.Module) -> None:
    """Swap `root.a.b.c` with `new_module`. Used to install compiled modules
    in-place so the pipeline's forward sees the tuned version transparently."""
    parts = dotted_name.split(".")
    parent = root
    for p in parts[:-1]:
        parent = getattr(parent, p)
    setattr(parent, parts[-1], new_module)
