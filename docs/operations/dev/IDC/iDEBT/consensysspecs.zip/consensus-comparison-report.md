# Consensus and Validation Across Three Architectures

## Ethereum Gasper vs. Polygon CDK zkEVM vs. Arc Malachite BFT

**Author:** codephreak / Professor Codephreak  
**Date:** March 30, 2026  
**References:** https://docs.arc.network/arc/references/ | https://github.com/0xPolygon

---

## 1. Executive Summary

This report provides a deep technical comparison of how block consensus and transaction validation are performed across three architecturally distinct blockchain systems: Ethereum mainnet (Gasper = LMD-GHOST + Casper FFG), the Polygon CDK/zkEVM stack (Proof of Efficiency with ZK validity proofs), and Circle's Arc Network (Malachite Tendermint BFT with Proof-of-Authority). These systems represent three fundamentally different philosophies for achieving agreement on the state of a distributed ledger — each making different trade-offs between decentralization, finality speed, throughput, and trust assumptions.

Ethereum prioritizes maximum decentralization and permissionless participation at the cost of ~13-minute finality. Polygon CDK inherits Ethereum's security through zero-knowledge validity proofs while enabling fast L2 throughput via a trusted sequencer model. Arc prioritizes institutional-grade performance and regulatory compliance through a permissioned validator set achieving sub-second deterministic finality. Understanding these trade-offs is essential for choosing which infrastructure layer serves which use case — and for understanding how cross-chain systems like AggLayer and CCTP bridge between them.

---

## 2. Ethereum Mainnet: Gasper Consensus

### 2.1 Architecture Overview

Ethereum's consensus mechanism, **Gasper**, is a composite protocol combining two subsystems that handle different aspects of chain agreement. **LMD-GHOST** (Latest Message Driven Greedy Heaviest Observed Sub-Tree) is the fork-choice rule that provides slot-by-slot liveness — it keeps the chain producing blocks. **Casper FFG** (Friendly Finality Gadget) is the finality overlay that periodically "blesses" checkpoint blocks with economic finality, making them irreversible.

This two-layer design reflects Ethereum's prioritization of **liveness over safety**. If Casper FFG cannot achieve finality (e.g., during a network partition), the chain continues growing via LMD-GHOST. Finality is desired but not required for continued operation.

### 2.2 How Blocks Are Proposed and Validated

Ethereum operates on a fixed time structure: **12-second slots** grouped into **32-slot epochs** (~6.4 minutes each).

**Block Proposal:** Each slot has one designated block proposer, selected pseudo-randomly from the active validator set (~1 million validators as of 2026, each staking 32 ETH). The proposer constructs a block containing transactions from the mempool and broadcasts it to the network.

**Attestation (Voting):** Every active validator is assigned to exactly one slot per epoch. In that slot, the validator produces an **attestation** — a signed message containing two votes: (1) an LMD-GHOST vote for the current head of the chain (the "head vote"), and (2) a Casper FFG vote consisting of a source-target checkpoint pair (the "FFG vote"). Attestations are aggregated by committees (128 validators each, ~64 committees per slot) and included in subsequent blocks.

**Fork Choice via LMD-GHOST:** When validators need to determine the canonical chain head, they apply the GHOST algorithm starting from the latest justified checkpoint. At each fork in the block tree, they follow the branch with the most accumulated attestation weight, considering only each validator's most recent message. This "greedy heaviest subtree" approach means the chain with the most aggregate validator support wins.

**Finalization via Casper FFG:** Checkpoints are the first block of each epoch. A checkpoint becomes **justified** when ≥2/3 of total stake attests to a source→target pair pointing to it. A justified checkpoint becomes **finalized** when the next epoch's checkpoint is also justified, creating a chain of supermajority links. Finalization requires two consecutive justified epochs, taking **2 epochs = 64 slots = ~12.8 minutes** under ideal conditions.

### 2.3 Finality Characteristics

| Property | Value |
|---|---|
| **Finality type** | Probabilistic (LMD-GHOST) + Economic (Casper FFG) |
| **Time to soft confirmation** | ~12 seconds (1 slot, with proposer boost) |
| **Time to finality** | ~12.8 minutes (2 epochs, 64 slots) |
| **Reorg protection** | Attestation weight accumulates rapidly; reorgs beyond ~2 blocks are extremely difficult |
| **Finality failure mode** | If <2/3 validators attest, finality stalls; chain continues via LMD-GHOST; inactivity leak gradually drains inactive validators' stake |
| **Slashing conditions** | Double voting (same slot), surround voting (contradictory FFG votes); penalties up to full stake destruction |
| **Validator count** | ~1,000,000+ (permissionless, 32 ETH minimum) |
| **Block time** | 12 seconds (fixed slots) |
| **Throughput** | ~15-30 TPS (L1 execution), ~1,500 TPS with blobs (for L2s) |

### 2.4 Security Model

Ethereum's security derives from **economic stake**. With ~34 million ETH staked (~$100B+ at current prices), attacking consensus requires controlling ≥1/3 of total stake to prevent finality, or ≥2/3 to finalize conflicting blocks (which would trigger mass slashing). The **accountable safety** property means that if two conflicting blocks are finalized, at least 1/3 of all validators can be provably identified and slashed — their ETH is destroyed. This creates a concrete economic deterrent: the cost of a successful attack exceeds $30 billion.

The **inactivity leak** is Gasper's recovery mechanism. If the chain fails to finalize for >4 epochs, validators who aren't participating begin losing stake at an accelerating rate until the remaining online validators represent ≥2/3 and finality can resume. This ensures that finality failures are temporary, at the cost of penalizing offline validators.

---

## 3. Polygon CDK/zkEVM: ZK Validity Proof Validation

### 3.1 Architecture Overview

The Polygon CDK stack uses a fundamentally different validation paradigm: rather than reaching consensus through voting, it achieves **computational verifiability** through zero-knowledge proofs. The L2 state is determined by a single **Trusted Sequencer** that orders transactions, while a **Trusted Aggregator** generates ZK proofs attesting to the correctness of those state transitions. These proofs are verified by an L1 smart contract (PolygonRollupManager) on Ethereum, inheriting Ethereum's security for state validity.

This model — called **Proof of Efficiency** — does not require L2 validators to reach agreement through message passing. Instead, the mathematical validity of the ZK proof serves as the consensus mechanism: if the proof verifies on L1, the state transition is correct by construction.

### 3.2 How Validation Works

The Polygon CDK validation pipeline has three distinct state levels, each with different security guarantees:

**Trusted State (Instant, ~2 seconds):** The Trusted Sequencer receives transactions from the L2 mempool, executes them in the cdk-erigon EVM, orders them into batches, and broadcasts the resulting state via a data stream to L2 nodes. Users get instant transaction confirmation, but this state relies on trusting the sequencer. If the sequencer is malicious, it could reorder or censor transactions (though it cannot steal funds, because invalid state transitions will fail ZK verification).

**Virtual State (~5-10 minutes):** The Sequence Sender component of the CDK node submits batch data to the L1 PolygonRollupManager contract. At this point, the batch data is on Ethereum — it's publicly auditable and cannot be censored. However, no proof of computational correctness has been submitted yet. The state is "virtual" because it's committed but unverified.

**Verified/Consolidated State (~30-60 minutes):** The Aggregator sends the batch data to the **zkProver** (a C++ implementation with 14 specialized state machines). The prover generates a STARK proof through a multi-stage pipeline:

1. **Execution:** The Main State Machine Executor re-executes all transactions, tracking every EVM opcode in polynomial form across 14 secondary state machines (arithmetic, binary, memory, storage, Keccak, Poseidon, etc.)
2. **STARK Generation:** Each state machine's execution trace is converted into a STARK proof using FRI (Fast Reed-Solomon Interactive Oracle Proof of Proximity)
3. **Proof Compression:** The c12a compressor reduces proof size through 4 compression stages (c12a → recursive1 → recursive2 → recursivef)
4. **SNARK Wrapping:** The final compressed STARK is converted to an FFLONK SNARK proof over the BN128 elliptic curve, reducing verification gas from ~5 million to ~350,000 gas

The Aggregator submits this SNARK proof to the L1 PolygonRollupManager contract, which calls the verifier contract. If the proof verifies, the state transitions from Virtual to Verified — this is **mathematical finality** backed by Ethereum's L1 security.

### 3.3 Consensus Contract Architecture

The L1 consensus contract (PolygonZkEVMEtrog.sol for rollup mode, PolygonValidiumEtrog.sol for validium mode) enforces the following rules:

**Sequencer obligations:** Must pay POL tokens to sequence batches. Must submit batch data (or data hash for validium) to L1. Can be replaced by the admin via governance. In the future, permissionless sequencing will allow anyone to force-include batches after a timeout.

**Aggregator obligations:** Must submit valid ZK proofs for sequenced batches. Receives POL rewards for successful proof submission. The AggLayer can also hold the TRUSTED_AGGREGATOR_ROLE, allowing it to submit proofs on behalf of multiple chains simultaneously.

**Verification logic:** The verifier contract checks the FFLONK proof against the public inputs (old state root, new state root, batch data hash). If verification passes, the new state root is committed on L1. This is not a vote or opinion — it's a mathematical statement that the state transition is correct.

### 3.4 AggLayer Pessimistic Proof (Post-2025)

For chains using **pessimistic proof consensus** (the default since late 2025), the validation pipeline changes. Instead of generating full ZK execution proofs, chains submit **certificates** to the AggLayer. The AggLayer generates a pessimistic proof using SP1 zkVM (Plonky3 STARK → SNARK wrapper) that verifies only bridge accounting — not internal state transitions. This provides:

- **Bridge safety:** No chain can withdraw more than it deposited (Local Balance Tree invariant)
- **Double-spend prevention:** Nullifier Tree prevents reuse of claimed exits
- **Cross-chain composability:** Certificates from multiple chains are aggregated and settled to L1 in a single proof

The critical trade-off: pessimistic proofs do NOT validate L2 state correctness on Ethereum. A malicious sequencer could finalize an invalid L2 state root. This is why L2BEAT classifies pessimistic-proof chains with a risk warning about state validation.

### 3.5 Finality Characteristics

| Property | Value |
|---|---|
| **Finality type** | Trusted (instant) → Virtual (L1 committed) → Verified (ZK proven) |
| **Time to trusted confirmation** | ~2 seconds |
| **Time to L1 data availability** | ~5-10 minutes (batch submission) |
| **Time to ZK-verified finality** | ~30-60 minutes (proof generation + L1 settlement) |
| **Time to pessimistic proof finality** | ~10-30 minutes (certificate settlement) |
| **Reorg protection** | No L2 reorgs once sequencer commits; L1 reorgs require Ethereum reorg |
| **Finality failure mode** | If sequencer goes down, forced batches can be submitted by anyone after timeout |
| **Validator count** | 1 Trusted Sequencer + 1 Trusted Aggregator (centralized, governance-replaceable) |
| **Block time** | ~2 seconds (L2, sequencer-determined) |
| **Throughput** | ~500-2,000 TPS (cdk-erigon, 60 Mgas/s burst) |

---

## 4. Arc Network: Malachite Tendermint BFT

### 4.1 Architecture Overview

Arc uses **Malachite**, a high-performance implementation of the Tendermint BFT consensus protocol, operating under a **Proof-of-Authority (PoA)** model. Unlike Ethereum's permissionless validator set or Polygon's single-sequencer model, Arc's validators are **known, regulated institutions** selected for their compliance credentials, operational SLAs, and geographic distribution.

This is a fundamentally different trust model: security comes from **institutional accountability** rather than economic stakes or mathematical proofs. Validators have real-world identities, SOC 2 certifications, and legal obligations — making malicious behavior costly through regulatory and reputational channels rather than on-chain slashing.

### 4.2 How Blocks Are Proposed and Validated

Arc's Malachite consensus follows the classic Tendermint four-phase pattern:

**Phase 1 — Propose:** One validator is deterministically selected as the proposer for the current round (block production rotates among validators for fairness). The proposer bundles pending transactions into a block and broadcasts it to all validators.

**Phase 2 — Pre-vote:** Each validator independently validates the proposed block (checks transaction validity, applies EVM state transitions, verifies USDC blocklist compliance) and broadcasts a **pre-vote** message indicating acceptance or rejection.

**Phase 3 — Pre-commit:** If a validator observes ≥2/3 of validators pre-voting for the same block, it broadcasts a **pre-commit** message. This second voting round is the critical safety step — it prevents validators from equivocating (voting for two different blocks).

**Phase 4 — Commit:** If ≥2/3 of validators pre-commit to the same block, the block is **committed and finalized**. It is immediately appended to the chain and all transactions within it are irreversible.

This entire four-phase process completes in **under 1 second** — with benchmarks showing ~350ms finality under optimal conditions.

### 4.3 Deterministic vs. Probabilistic Finality

Arc's finality model is categorically different from Ethereum's:

**On Ethereum:** A transaction goes through states: pending → included (1 confirmation) → accumulating confirmations → justified checkpoint → finalized. Even after finalization (~12.8 minutes), the guarantee is economic — it would cost >$10B to revert.

**On Arc:** A transaction is either **unconfirmed** or **final**. There is no intermediate state. Once a block is committed with ≥2/3 validator pre-commits, it is mathematically impossible to produce a conflicting finalized block without ≥1/3 validator collusion. This is not probabilistic — it's a theorem of BFT consensus.

The practical implication: applications on Arc can release funds, complete trades, and trigger off-chain effects **immediately** after block commitment. No confirmation counting, no reorg risk assessment, no rollback logic.

### 4.4 USDC-Native Gas and Blocklist Enforcement

Arc introduces a consensus-level innovation unique among L1s: **USDC blocklist enforcement at the consensus layer**. Before a transaction enters the mempool, the consensus layer checks whether the sender's address is on Circle's USDC blocklist. If blocklisted, the transaction is rejected pre-mempool — it never touches the execution layer. This is not a smart contract check (which can be circumvented by flash loans or proxy contracts) but a protocol-level enforcement.

Additionally, if a valid transaction attempts to transfer USDC to/from a blocklisted address, only that specific operation reverts — the transaction itself still executes and gas fees are collected. This selective enforcement prevents blocklisted addresses from griefing the network.

### 4.5 Finality Characteristics

| Property | Value |
|---|---|
| **Finality type** | Deterministic (BFT, single-slot) |
| **Time to finality** | <1 second (~350ms benchmarked) |
| **Reorg protection** | Mathematically impossible without ≥1/3 validator collusion |
| **Finality failure mode** | If <2/3 validators are online, chain halts (no unsafe blocks produced) |
| **Validator count** | ~20 (permissioned, institutional, SOC 2 certified) |
| **Block time** | Sub-second |
| **Throughput** | 3,000+ TPS (20 validators), 10,000+ TPS (4 validators) |
| **Trust model** | Proof-of-Authority (institutional identity, not economic stake) |
| **Slashing** | No on-chain slashing; accountability via legal/regulatory/reputational channels |
| **Planned evolution** | Multi-proposer (10x throughput), permissioned PoS transition |

---

## 5. Comparative Analysis

### 5.1 The Fundamental Trade-off Triangle

Each system occupies a different position on the decentralization-performance-trust triangle:

| Dimension | Ethereum (Gasper) | Polygon CDK (zkEVM) | Arc (Malachite) |
|---|---|---|---|
| **Decentralization** | Maximum (~1M validators, permissionless) | Minimal (1 sequencer, 1 aggregator) | Low (20 institutional validators, permissioned) |
| **Finality speed** | ~12.8 minutes | ~30-60 min (ZK), ~2s (trusted) | <1 second |
| **Throughput** | ~15-30 TPS | ~500-2,000 TPS | 3,000-10,000 TPS |
| **Trust model** | Economic (32 ETH stake, slashing) | Mathematical (ZK proofs) + Trust (sequencer) | Institutional (regulated entities) |
| **Reorg risk** | Low after finality, possible before | None (L2), depends on L1 | None (BFT guarantee) |
| **Permissionless** | Yes | Partially (sequencing centralized) | No (permissioned validators) |
| **Gas token** | ETH (volatile) | ETH or custom ERC-20 | USDC (stable, $-denominated) |
| **Blocklist enforcement** | None (censorship resistance) | Optional (sequencer choice) | Protocol-level (pre-mempool) |

### 5.2 Validation Method Comparison

**Ethereum validates by social consensus:** Thousands of validators independently execute transactions and vote on the correct chain. Security comes from the aggregate economic weight of honest participants. A dishonest validator risks losing 32+ ETH. The system is permissionless — anyone can validate.

**Polygon CDK validates by mathematical proof:** A single prover generates a ZK proof that state transitions are correct. Any node can verify this proof in ~350K gas on L1. Security comes from the mathematical soundness of the ZK circuit — not from validator count or economic stake. The proof is either valid or it isn't. However, the sequencer that proposes the transactions is centralized and trusted.

**Arc validates by institutional authority:** Known, regulated entities execute transactions and reach consensus through BFT voting. Security comes from the real-world consequences of institutional malfeasance — legal liability, regulatory action, reputational damage. The system is permissioned — you must be approved to validate.

### 5.3 Finality Model Comparison

```
Ethereum:
  tx submitted ──▶ included in block (12s) ──▶ accumulating attestations ──▶ justified (6.4min) ──▶ finalized (12.8min)
  │                      │                                                                              │
  │  probabilistic       │  increasingly difficult to revert                                            │  economic finality
  │  confirmation        │  (attestation weight)                                                        │  ($10B+ to attack)

Polygon CDK:
  tx submitted ──▶ sequencer executes (2s) ──▶ batch on L1 (5-10min) ──▶ ZK proof verified (30-60min)
  │                      │                          │                            │
  │  trusted state       │  trust sequencer         │  virtual state             │  mathematical finality
  │  (instant UX)        │  for ordering            │  (data available)          │  (L1 security)

Arc:
  tx submitted ──▶ propose ──▶ pre-vote ──▶ pre-commit ──▶ commit (<1s)
  │                                                            │
  │  unconfirmed                                               │  deterministic finality
  │                                                            │  (BFT guarantee, no reorgs)
```

### 5.4 What Arc Upgrades Over the Polygon Stack

Arc and Polygon CDK serve different use cases, but comparing their consensus mechanisms reveals what Arc offers differently:

**Finality speed:** Arc achieves sub-second deterministic finality vs. Polygon CDK's 2-second trusted confirmation (which requires trusting the sequencer) or 30-60 minute ZK-verified finality. For payment and settlement use cases, this is the critical difference.

**Finality type:** Arc provides deterministic BFT finality — mathematically proven irreversible. Polygon CDK's "trusted state" is not final (it depends on sequencer honesty), and its "verified state" is mathematically final but takes 30-60 minutes.

**Gas stability:** Arc uses USDC as native gas, meaning transaction fees are denominated in a stable dollar value (~$0.009/tx). Polygon CDK uses ETH (or custom tokens), meaning gas costs fluctuate with token price volatility.

**Compliance integration:** Arc enforces USDC blocklists at the consensus layer. Polygon CDK has no protocol-level compliance enforcement — this is left to application-level decisions.

**Trade-off:** Arc sacrifices decentralization (20 permissioned validators vs. Polygon CDK inheriting Ethereum's 1M+ validators via ZK proofs). Arc's validators are known institutions, making the chain more suitable for regulated finance but less censorship-resistant than Ethereum-settled L2s.

### 5.5 What Ethereum Provides That Neither L2/L1 Can

**Maximum censorship resistance:** With 1M+ validators globally, no entity can reliably censor Ethereum transactions. Both Polygon CDK (single sequencer) and Arc (permissioned validators) have centralized points of censorship.

**Permissionless validation:** Anyone with 32 ETH can become an Ethereum validator. Both Arc (institutional approval required) and Polygon CDK (sequencer role is governance-controlled) gate participation.

**Economic finality at scale:** Ethereum's finality is backed by ~$100B+ in staked assets. Arc's finality is backed by institutional reputation. Polygon CDK's finality is backed by mathematical proof — which is actually stronger than both, but limited by the centralization of the sequencer/aggregator roles.

**Neutral settlement layer:** Ethereum serves as the settlement layer for both Polygon CDK (via L1 contract verification) and potentially Arc (via CCTP cross-chain settlement). It is the only system of the three that functions as a credibly neutral base layer.

---

## 6. Cross-Chain Consensus Implications

### 6.1 How AggLayer Bridges Polygon CDK's Validation to Ethereum

When a CDK chain's ZK proof is verified on Ethereum's L1, it creates a **trust bridge** between two consensus systems. The CDK chain's state is validated by ZK proof (mathematical truth), settled on Ethereum (economic finality), and made available for cross-chain claims via the Unified Bridge (pessimistic proof safety). This three-layer validation stack — ZK proof + L1 settlement + pessimistic proof — is the most computationally rigorous approach to cross-chain security.

### 6.2 How CCTP Bridges Arc to Other Chains

Arc connects to other chains via Circle's CCTP burn-and-mint protocol. When USDC moves from Ethereum to Arc, it's burned on Ethereum (finalized via Gasper, ~12.8 min) and minted on Arc (finalized via Malachite, <1s). The cross-chain finality time is bounded by the **slower** of the two chains — in this case, Ethereum's 12.8-minute finality. Arc's sub-second finality is a local property that doesn't extend to cross-chain transfers.

### 6.3 The Convergence: Stablecoin Settlement Across Consensus Boundaries

The emerging architecture looks like this: Ethereum provides neutral, permissionless settlement security. Polygon CDK chains provide high-throughput EVM execution with ZK-verified state. Arc provides institutional-grade stablecoin infrastructure with sub-second finality. AggLayer's Unified Bridge and CCTP connect them, with stablecoins (USDC, AUSD) serving as the common liquidity substrate. Each consensus mechanism is optimized for its role, and cross-chain protocols abstract the consensus differences from end users and applications.

---

## 7. Arc Testnet Reference Data

### 7.1 Network Configuration

| Parameter | Value |
|---|---|
| **Network** | Arc Testnet |
| **Chain ID** | 5042002 |
| **Native Currency** | USDC (18 decimals for gas, 6 decimals for ERC-20 interface) |
| **RPC Endpoint** | `https://rpc.testnet.arc.network` |
| **WebSocket** | `wss://rpc.testnet.arc.network` |
| **Explorer** | `https://testnet.arcscan.app` |
| **Faucet** | `https://faucet.circle.com` |
| **Consensus** | Malachite (Tendermint BFT) |
| **Validator Model** | Proof-of-Authority (institutional) |
| **EVM Target** | Prague hard fork specification |

### 7.2 Key Contract Addresses (Testnet)

| Contract | Address | Function |
|---|---|---|
| **USDC (System)** | `0x3600000000000000000000000000000000000000` | Native gas token + optional ERC-20 interface |
| **EURC** | `0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a` | Euro stablecoin (6 decimals) |
| **USYC** | `0xe9185F0c5F296Ed1797AaE4238D26CCaBEadb86C` | Yield-bearing money market token |
| **TokenMessengerV2 (CCTP)** | `0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA` | Cross-chain USDC transfers |
| **MessageTransmitterV2** | `0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275` | CCTP message relay |
| **GatewayWallet** | `0x0077777d7EBA4688BDeF3E311b846F25870A19B9` | Unified USDC balance abstraction |
| **GatewayMinter** | `0x0022222ABE238Cc2C7Bb1f21003F0a260052475B` | Chain-abstracted minting |
| **StableFX FxEscrow** | `0x867650F5eAe8df91445971f14d89fd84F0C9a9f8` | Stablecoin FX settlement |
| **Permit2** | `0x000000000022D473030F116dDEE9F6B43aC78BA3` | Gasless token allowances |
| **Multicall3** | `0xcA11bde05977b3631167028862bE2a173976CA11` | Batched read calls |

---

## 8. Conclusion

The three consensus architectures represent three distinct answers to the same fundamental question: how do we agree on the state of a shared ledger?

**Ethereum's Gasper** answers with maximum decentralization — let a million validators vote, use economic incentives to keep them honest, and accept slow finality as the price of censorship resistance. This makes Ethereum the credibly neutral settlement layer for the entire ecosystem.

**Polygon CDK's Proof of Efficiency** answers with mathematical proof — let a single sequencer propose state, then prove its correctness through zero-knowledge cryptography verified on Ethereum. This provides fast user experience with eventual mathematical finality, at the cost of sequencer centralization.

**Arc's Malachite BFT** answers with institutional authority — let known, regulated entities reach consensus through classical BFT voting, achieving sub-second deterministic finality. This provides the performance characteristics needed for institutional finance, at the cost of permissioned access and reduced censorship resistance.

None of these systems is universally superior. They are complementary layers in an emerging multi-chain architecture where stablecoins serve as the common liquidity substrate, cross-chain protocols (AggLayer, CCTP) abstract consensus differences, and each layer is optimized for its specific role in the value chain. For the DELTAVERSE ecosystem and BONAFIDE protocol, understanding these consensus boundaries is essential for designing cross-chain agent interactions that correctly account for finality guarantees at each layer.

---

*Sources: ethereum.org/gasper, docs.polygon.technology/zkEVM/architecture, docs.arc.network/arc/concepts/consensus-layer, github.com/0xPolygon, docs.agglayer.dev*

*License: Apache 2.0 / MIT (dual licensed)*
