"""
Unit tests for the x402 integration layer.

These tests do NOT exercise the actual x402 SDK or real network calls.
They verify the configuration layer, pricing logic, and audit logging
in isolation.

End-to-end tests that hit Base Sepolia live are in test_e2e.py.
"""
import json
import tempfile
from pathlib import Path

import pytest

from mindx.x402_integration import audit, pricing


class TestPricing:
    def test_base_prices_configured(self):
        assert "GET /api/v1/reason" in pricing.BASE_PRICES
        assert pricing.BASE_PRICES["GET /api/v1/reason"] == "$0.001"

    def test_usd_to_float_roundtrip(self):
        assert pricing.usd_to_float("$0.001") == 0.001
        assert pricing.usd_to_float("$1.00") == 1.0

    def test_float_to_usd_format(self):
        assert pricing.float_to_usd(0.001) == "$0.001"
        # Trailing zeros are stripped
        assert pricing.float_to_usd(0.01).startswith("$0.01")

    def test_discounted_price_defaults_to_base_when_reputation_disabled(
        self, monkeypatch
    ):
        # Reputation is disabled by default in test env
        price = pricing.discounted_price_for(
            "GET /api/v1/reason",
            "0x0000000000000000000000000000000000000000",
        )
        assert price.startswith("$0.001")

    def test_discounted_price_raises_on_unknown_endpoint(self):
        with pytest.raises(KeyError):
            pricing.discounted_price_for("GET /nonexistent", "0x00")


class TestAudit:
    def test_payment_log_appends_jsonl(self, tmp_path, monkeypatch):
        log_path = tmp_path / "payments.jsonl"
        monkeypatch.setattr(audit, "PAYMENT_LOG_PATH", str(log_path))

        audit.log_payment(
            route="GET /api/v1/reason",
            payer="0xAbC",
            tx_hash="0xdeadbeef",
            amount_usdc_base_units="1000",
            network="eip155:84532",
            facilitator="https://x402.org/facilitator",
            asset="0x036CbD53842c5426634e7929541eC2318f3dCF7e",
        )

        lines = log_path.read_text().strip().splitlines()
        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["route"] == "GET /api/v1/reason"
        assert record["payer"] == "0xAbC"
        assert record["tx_hash"] == "0xdeadbeef"
        assert record["amount"] == "1000"

    def test_refund_log_appends_jsonl(self, tmp_path, monkeypatch):
        log_path = tmp_path / "refunds.jsonl"
        monkeypatch.setattr(audit, "REFUND_LOG_PATH", str(log_path))

        audit.log_refund(
            payer="0xAbC",
            original_tx_hash="0xorig",
            refund_tx_hash="0xrefund",
            amount_usdc_base_units="1000",
            reason="timeout",
            operator="test_operator",
        )

        record = json.loads(log_path.read_text().strip())
        assert record["reason"] == "timeout"
        assert record["operator"] == "test_operator"


class TestConfig:
    def test_config_exposes_required_constants(self):
        from mindx.x402_integration import config

        assert hasattr(config, "NETWORK")
        assert hasattr(config, "FACILITATOR_URL")
        assert hasattr(config, "USDC_ASSET")
        assert hasattr(config, "PAY_TO_ADDRESS")
        assert config.USDC_ASSET.startswith("0x")
        assert len(config.USDC_ASSET) == 42
