#!/usr/bin/env bash
# Manual USDC refund via cast.
#
# x402 has no native refund mechanism. When an operator decides a refund
# is warranted (failed inference, downtime, dispute), run this script.
#
# Usage:
#   ./scripts/refund.sh <payer_address> <amount_usd> <reason> <original_tx_hash>
#
# Example:
#   ./scripts/refund.sh 0xPayer 0.05 "inference_timeout" 0xOrigTx
#
# Requirements:
#   - cast (from Foundry)
#   - PAY_TO_PRIVATE_KEY environment variable (the receiving wallet's key)
#   - BASE_RPC environment variable
#
# After refund succeeds, the tx hash is logged to refunds.jsonl
# via the Python audit.py helper.

set -euo pipefail

if [ "$#" -ne 4 ]; then
    echo "Usage: $0 <payer_address> <amount_usd> <reason> <original_tx_hash>"
    exit 1
fi

PAYER="$1"
AMOUNT_USD="$2"
REASON="$3"
ORIGINAL_TX="$4"

# Validate environment
: "${PAY_TO_PRIVATE_KEY:?PAY_TO_PRIVATE_KEY must be set}"
: "${BASE_RPC:=https://mainnet.base.org}"

# USDC on Base mainnet
USDC_ADDRESS="0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"

# Convert USD to USDC base units (6 decimals)
# $0.05 → 50000
AMOUNT_BASE_UNITS=$(python3 -c "print(int(float('$AMOUNT_USD') * 1_000_000))")

echo "────────────────────────────────────────────"
echo " Refund request"
echo "────────────────────────────────────────────"
echo "  Payer:         $PAYER"
echo "  Amount (USD):  \$$AMOUNT_USD"
echo "  Amount (base): $AMOUNT_BASE_UNITS"
echo "  Reason:        $REASON"
echo "  Original tx:   $ORIGINAL_TX"
echo "  Network:       Base mainnet"
echo "  RPC:           $BASE_RPC"
echo "────────────────────────────────────────────"
read -p "Confirm send? [y/N] " confirm
[ "$confirm" = "y" ] || { echo "Aborted."; exit 1; }

# Send the refund
REFUND_TX=$(cast send "$USDC_ADDRESS" \
    "transfer(address,uint256)" \
    "$PAYER" "$AMOUNT_BASE_UNITS" \
    --rpc-url "$BASE_RPC" \
    --private-key "$PAY_TO_PRIVATE_KEY" \
    --json | python3 -c "import json,sys; print(json.load(sys.stdin)['transactionHash'])")

echo ""
echo "✓ Refund sent: $REFUND_TX"
echo "  View on Basescan: https://basescan.org/tx/$REFUND_TX"

# Log to refunds.jsonl
python3 -c "
from mindx.x402_integration.audit import log_refund
log_refund(
    payer='$PAYER',
    original_tx_hash='$ORIGINAL_TX',
    refund_tx_hash='$REFUND_TX',
    amount_usdc_base_units='$AMOUNT_BASE_UNITS',
    reason='$REASON',
    operator='$(whoami)',
)
print('✓ Logged to refunds.jsonl')
"
