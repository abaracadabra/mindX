#!/usr/bin/env python3
"""
Daily reconciliation: match audit log entries against on-chain state.

For every payment recorded in the last 24 hours:
  1. Fetch the transaction from Base
  2. Verify recipient matches PAY_TO_ADDRESS
  3. Verify amount matches the logged value
  4. Flag mismatches for investigation

Run as a nightly cron job:
  0 2 * * * cd /opt/mindx && python scripts/reconcile_daily.py
"""
import json
import sys
import time
from pathlib import Path

from web3 import Web3

from mindx.x402_integration.config import (
    NETWORK,
    PAY_TO_ADDRESS,
    PAYMENT_LOG_PATH,
    USDC_ASSET,
)

RPC_URLS = {
    "eip155:8453":  "https://mainnet.base.org",
    "eip155:84532": "https://sepolia.base.org",
}

USDC_ABI = [
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "name": "from", "type": "address"},
            {"indexed": True, "name": "to", "type": "address"},
            {"indexed": False, "name": "value", "type": "uint256"},
        ],
        "name": "Transfer",
        "type": "event",
    }
]


def load_recent_payments(hours: int = 24) -> list[dict]:
    """Return payment records from the last N hours."""
    if not Path(PAYMENT_LOG_PATH).exists():
        print(f"No payment log at {PAYMENT_LOG_PATH}")
        return []

    cutoff = time.time() - (hours * 3600)
    records = []
    with open(PAYMENT_LOG_PATH) as f:
        for line in f:
            try:
                r = json.loads(line)
                if r["ts"] >= cutoff:
                    records.append(r)
            except (json.JSONDecodeError, KeyError):
                continue
    return records


def reconcile(record: dict, w3: Web3, usdc) -> tuple[bool, str]:
    """
    Reconcile one payment against on-chain state.
    Returns (ok, message).
    """
    tx_hash = record["tx_hash"]
    try:
        receipt = w3.eth.get_transaction_receipt(tx_hash)
    except Exception as e:
        return False, f"failed to fetch tx: {e}"

    if receipt.status != 1:
        return False, "transaction reverted on-chain"

    # Find the USDC Transfer event
    transfer_events = usdc.events.Transfer().process_receipt(receipt)
    if not transfer_events:
        return False, "no Transfer event in receipt"

    # Look for the event matching our PAY_TO_ADDRESS
    for event in transfer_events:
        if event.args.to.lower() == PAY_TO_ADDRESS.lower():
            expected = int(record["amount"])
            actual = event.args.value
            if actual != expected:
                return False, (
                    f"amount mismatch: expected {expected}, on-chain {actual}"
                )
            return True, "ok"

    return False, f"no Transfer to {PAY_TO_ADDRESS} in receipt"


def main() -> int:
    records = load_recent_payments(hours=24)
    if not records:
        print("No payments in last 24h — nothing to reconcile")
        return 0

    print(f"Reconciling {len(records)} payments from last 24h...\n")

    rpc = RPC_URLS.get(NETWORK)
    if not rpc:
        print(f"ERROR: no RPC configured for network {NETWORK}")
        return 1

    w3 = Web3(Web3.HTTPProvider(rpc))
    usdc = w3.eth.contract(address=USDC_ASSET, abi=USDC_ABI)

    ok_count = 0
    fail_count = 0
    failures = []

    for record in records:
        ok, msg = reconcile(record, w3, usdc)
        if ok:
            ok_count += 1
        else:
            fail_count += 1
            failures.append((record, msg))
            print(f"✗ {record['tx_hash']}: {msg}")

    print(f"\nSummary: {ok_count} ok, {fail_count} failed")

    if failures:
        print("\nFailures require manual investigation:")
        for record, msg in failures:
            print(f"  - route={record['route']} payer={record['payer']}")
            print(f"    tx={record['tx_hash']} reason={msg}")
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
