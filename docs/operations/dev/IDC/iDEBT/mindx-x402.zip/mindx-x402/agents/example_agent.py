"""
Example AgenticPlace agent that pays for mindX endpoints via x402.

Verified against coinbase/x402/examples/python/clients/httpx.

The x402HttpxClient automatically:
  1. Sends the initial request
  2. Receives the 402 response
  3. Builds and signs an EIP-3009 authorization with the agent's key
  4. Retries with the X-PAYMENT header
  5. Returns the final 200 response

From the agent's perspective, paying is invisible — it just makes an HTTP call.
"""
import asyncio
import json
import os
import sys

from eth_account import Account

try:
    from x402.clients import x402HttpxClient
except ImportError:
    print("ERROR: x402 SDK not installed. Run: pip install 'x402[fastapi,httpx]'")
    sys.exit(1)


def load_agent_account() -> Account:
    """Load the agent's wallet from environment."""
    private_key = os.environ.get("AGENT_PRIVATE_KEY")
    if not private_key:
        print("ERROR: AGENT_PRIVATE_KEY environment variable not set")
        print("       Generate one with: cast wallet new")
        print("       Fund with test USDC from: https://faucet.circle.com")
        sys.exit(1)
    return Account.from_key(private_key)


async def run_demo(base_url: str = "http://localhost:8000") -> None:
    account = load_agent_account()
    print(f"Agent wallet address: {account.address}")
    print(f"Calling mindX at: {base_url}\n")

    async with x402HttpxClient(account=account, base_url=base_url) as client:
        # --- FREE endpoint, no payment ---
        print("1. GET /health (free)")
        r = await client.get("/health")
        print(f"   → {r.status_code} {r.json()}\n")

        # --- PAID endpoint via /pay/ mount ---
        print("2. GET /pay/api/v1/reason (paid — $0.001)")
        r = await client.get("/pay/api/v1/reason?question=what+is+being")
        print(f"   → {r.status_code}")
        print(f"   → answer: {r.json()['answer']}")
        receipt = r.headers.get("PAYMENT-RESPONSE")
        if receipt:
            print(f"   → settlement receipt: {receipt[:80]}...\n")

        # --- Another paid endpoint ---
        print("3. POST /pay/api/v1/socratic (paid — $0.01)")
        r = await client.post(
            "/pay/api/v1/socratic",
            json={"question": "what is consciousness", "depth": 2},
        )
        print(f"   → {r.status_code}")
        print(f"   → chain: {json.dumps(r.json(), indent=2)}\n")


if __name__ == "__main__":
    base_url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
    asyncio.run(run_demo(base_url))
