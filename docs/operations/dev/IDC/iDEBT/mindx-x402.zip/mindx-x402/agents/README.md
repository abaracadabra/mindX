# agents/

Client-side code for autonomous agents that pay for mindX endpoints via x402.

## Quick test

```bash
# 1. Generate an agent wallet (testnet)
cast wallet new
# Save the private key

# 2. Fund with Base Sepolia USDC
# Visit https://faucet.circle.com, select Base Sepolia, paste your address
# You only need a few cents — typical calls are $0.001-$0.05

# 3. Fund with Sepolia ETH (needed for some wallet operations, not payment itself)
# Visit https://bridge.base.org or https://coinbase.com/faucets/base-ethereum-sepolia-faucet

# 4. Run the agent
export AGENT_PRIVATE_KEY=0x...your-testnet-key...
python agents/example_agent.py http://localhost:8000
```

## Expected output

```
Agent wallet address: 0xYourAgent...
Calling mindX at: http://localhost:8000

1. GET /health (free)
   → 200 {'status': 'ok', 'version': '1.0.0'}

2. GET /pay/api/v1/reason (paid — $0.001)
   → 200
   → answer: The unexamined life is not worth living...
   → settlement receipt: eyJzdWNjZXNzIjp0cnVlLCJ0eEhhc2...

3. POST /pay/api/v1/socratic (paid — $0.01)
   → 200
   → chain: {...}
```

The settlement receipt is a base64-encoded JSON containing the on-chain
transaction hash. Decode it with:

```bash
echo "eyJzdWNjZXNz..." | base64 -d | jq
```

## Production wallet management

**Never put real mainnet private keys in environment variables.** For production
agents, use GCP Cloud KMS or AWS CloudHSM. The agent signs payments by calling
the KMS API; the private key material never leaves the HSM.

See `PLAYBOOK.md` Section 3 for production wallet patterns.
