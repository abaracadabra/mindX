"""
BANKON identity gating (optional layer).

Pattern: before x402 accepts payment from a wallet, check whether that
wallet is linked to a BANKON AlgoIDNFT (soulbound identity on Algorand).

Cross-chain mechanics:
  1. Lookup linked Algorand address via on-chain registry on Base
  2. Query Algorand indexer for AlgoIDNFT ASA balance
  3. Cache result for 5 minutes (identity changes rarely)

Modes:
  - off    — no checks, all payments accepted (default)
  - soft   — unverified payers allowed but with 2x price surcharge
  - strict — unverified payers rejected with 403
"""
import asyncio
from functools import lru_cache
from typing import Optional

import httpx

from mindx.x402_integration.config import (
    ALGORAND_INDEXER_URL,
    BANKON_ALGOIDNFT_ASSET_ID,
    BANKON_ENABLED,
    BANKON_MODE,
    BANKON_REGISTRY_CONTRACT,
)


# Minimal ABI for the registry — just the lookup function we need
REGISTRY_ABI = [
    {
        "inputs": [{"name": "evmAddress", "type": "address"}],
        "name": "algoAddressFor",
        "outputs": [{"name": "", "type": "string"}],
        "stateMutability": "view",
        "type": "function",
    }
]


@lru_cache(maxsize=10000)
def _cached_algo_address(evm_address: str, ttl_bucket: int) -> Optional[str]:
    """
    Internal cache. ttl_bucket is the current 5-minute window —
    when it changes, the cache key changes, forcing a fresh lookup.
    """
    if not BANKON_REGISTRY_CONTRACT:
        return None
    try:
        from web3 import Web3
        w3 = Web3(Web3.HTTPProvider("https://mainnet.base.org"))
        registry = w3.eth.contract(
            address=BANKON_REGISTRY_CONTRACT,
            abi=REGISTRY_ABI,
        )
        algo = registry.functions.algoAddressFor(evm_address).call()
        return algo if algo and algo != "" else None
    except Exception:
        return None


def _ttl_bucket(seconds: int = 300) -> int:
    """Returns the current TTL bucket — changes every `seconds` seconds."""
    import time
    return int(time.time() // seconds)


async def has_bankon_identity(evm_address: str) -> bool:
    """
    Check whether the given EVM address holds a BANKON AlgoIDNFT
    via its linked Algorand wallet.

    Returns False on any error — fail-closed for security in strict mode,
    fail-open is handled at the policy layer.
    """
    if not BANKON_ENABLED:
        return True   # gating disabled = everyone passes

    # Step 1: look up linked Algorand address (cached)
    algo_address = _cached_algo_address(evm_address.lower(), _ttl_bucket())
    if not algo_address:
        return False

    # Step 2: check AlgoIDNFT holding via Algorand indexer
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get(
                f"{ALGORAND_INDEXER_URL}/v2/accounts/{algo_address}/assets",
                params={"asset-id": BANKON_ALGOIDNFT_ASSET_ID},
            )
            if r.status_code != 200:
                return False
            data = r.json()
            for asset in data.get("assets", []):
                if (
                    asset.get("asset-id") == BANKON_ALGOIDNFT_ASSET_ID
                    and asset.get("amount", 0) > 0
                ):
                    return True
    except (httpx.HTTPError, asyncio.TimeoutError):
        return False

    return False


def price_multiplier(has_identity: bool) -> float:
    """
    Returns the price multiplier given the identity check result.

    strict mode: would have already rejected; this returns 1.0 for verified.
    soft mode:   2.0 for unverified, 1.0 for verified.
    off mode:    always 1.0.
    """
    if BANKON_MODE == "soft" and not has_identity:
        return 2.0
    return 1.0
