"""
mindX FastAPI application entry point.

Architecture: dual-mounted app
  /free/*  — API-key authenticated, free tier
  /pay/*   — x402 payment required
  /health  — always free, top-level
  /openapi.json, /redoc, /docs — top-level documentation

This lets the same routes serve both human developers (via API keys
with monthly billing) and autonomous agents (via x402 per-call payment).

Remove the `install_x402(paid_app)` line to disable payment entirely
without touching any route code.
"""
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from mindx import __version__
from mindx.api.routes import health, reasoning
from mindx.x402_integration.config import summary
from mindx.x402_integration.middleware import install_x402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s - %(message)s",
)
log = logging.getLogger("mindx")


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("mindX v%s starting with config: %s", __version__, summary())
    yield
    log.info("mindX shutting down")


# ----------------------------------------------------------
# Free-tier app (would add API key middleware here)
# ----------------------------------------------------------
free_app = FastAPI(
    title="mindX (free tier)",
    version=__version__,
    description="API-key authenticated access to mindX reasoning endpoints.",
)
free_app.include_router(reasoning.router)


# ----------------------------------------------------------
# Paid-tier app (x402 payment middleware)
# ----------------------------------------------------------
paid_app = FastAPI(
    title="mindX (paid tier)",
    version=__version__,
    description="x402 payment-gated access. Pay-per-call in USDC on Base.",
)
paid_app.include_router(reasoning.router)

# THE ONE LINE that turns on x402.
# Remove it to disable payment across all endpoints.
install_x402(paid_app)


# ----------------------------------------------------------
# Top-level app that mounts both
# ----------------------------------------------------------
app = FastAPI(
    title="mindX",
    version=__version__,
    description=(
        "Consciousness reasoning API with dual payment rails: "
        "API keys (/free) for developers, x402 (/pay) for autonomous agents."
    ),
    lifespan=lifespan,
)

# Health at top level — never gated
app.include_router(health.router)

# Mount the two tiers
app.mount("/free", free_app)
app.mount("/pay", paid_app)


if __name__ == "__main__":
    import uvicorn

    # CRITICAL: loop="asyncio" — do NOT use uvloop.
    # fastapi-x402 middleware has a known incompatibility with uvloop.
    uvicorn.run(app, host="0.0.0.0", port=8000, loop="asyncio")
