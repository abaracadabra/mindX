"""
x402 payment integration for mindX.

This entire module is removable. Delete the directory and the
`install_x402(app)` line in mindx/api/main.py and the API works
exactly as it did before — just without payment.
"""
