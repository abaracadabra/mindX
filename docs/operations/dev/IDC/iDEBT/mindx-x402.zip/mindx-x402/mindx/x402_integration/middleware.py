"""
x402 middleware installation.

Wires PaymentMiddlewareASGI into a FastAPI app with our
configured facilitator, network, and route pricing.

Verified against coinbase/x402/examples/python/servers/fastapi.
"""
import logging
from typing import TYPE_CHECKING

from mindx.x402_integration.config import (
    FACILITATOR_URL,
    NETWORK,
    PAY_TO_ADDRESS,
    summary,
)
from mindx.x402_integration.pricing import BASE_PRICES

if TYPE_CHECKING:
    from fastapi import FastAPI

log = logging.getLogger(__name__)


def install_x402(app: "FastAPI") -> None:
    """
    Install x402 payment middleware onto a FastAPI app.

    Call this AFTER all routers are included — the middleware
    intercepts requests before they reach route handlers.

    Remove this single call and all x402 behavior disappears.
    """
    # Imports deferred so the module is importable without the x402
    # SDK installed (useful for tests that don't exercise payment).
    from x402.http.middleware.fastapi import PaymentMiddlewareASGI
    from x402.http import (
        HTTPFacilitatorClient,
        FacilitatorConfig,
        PaymentOption,
    )
    from x402.http.types import RouteConfig
    from x402.server import x402ResourceServer
    from x402.mechanisms.evm.exact import ExactEvmServerScheme

    log.info("Installing x402 middleware with config: %s", summary())

    # Build facilitator client
    facilitator = HTTPFacilitatorClient(FacilitatorConfig(url=FACILITATOR_URL))

    # Build resource server and register the EVM 'exact' scheme
    server = x402ResourceServer(facilitator)
    server.register(NETWORK, ExactEvmServerScheme())

    # Translate our BASE_PRICES dict into x402 RouteConfig objects
    routes = {
        endpoint: RouteConfig(
            accepts=[
                PaymentOption(
                    scheme="exact",
                    price=price,
                    network=NETWORK,
                    pay_to=PAY_TO_ADDRESS,
                )
            ]
        )
        for endpoint, price in BASE_PRICES.items()
    }

    app.add_middleware(
        PaymentMiddlewareASGI,
        routes=routes,
        server=server,
    )

    log.info("x402 middleware installed with %d paid routes", len(routes))
