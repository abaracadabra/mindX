"""
BONAFIDE reputation-based pricing (optional layer).

Pattern: query the Tessera reputation contract for the payer's score,
return a multiplier to apply to base prices.

Score range (assumed): 0–1000
  >= 800: 50% off  (top-tier, trusted agents)
  >= 500: 25% off  (established agents)
  <  500: full price (new or low-reputation)

Caching: reputation changes slowly. LRU cache with TTL buckets.
For multi-process deployments, swap to Redis with 1-hour TTL.
"""
from functools import lru_cache

from mindx.x402_integration.config import (
    BONAFIDE_ENABLED,
    BONAFIDE_RPC_URL,
    BONAFIDE_TESSERA_CONTRACT,
)


TESSERA_ABI = [
    {
        "inputs": [{"name": "account", "type": "address"}],
        "name": "scoreOf",
        "outputs": [{"name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function",
    }
]


def _ttl_bucket(seconds: int = 3600) -> int:
    """Changes every hour — forces cache refresh."""
    import time
    return int(time.time() // seconds)


@lru_cache(maxsize=10000)
def _cached_score(address: str, ttl_bucket: int) -> int:
    if not BONAFIDE_ENABLED or not BONAFIDE_TESSERA_CONTRACT:
        return 0
    try:
        from web3 import Web3
        w3 = Web3(Web3.HTTPProvider(BONAFIDE_RPC_URL))
        contract = w3.eth.contract(
            address=BONAFIDE_TESSERA_CONTRACT,
            abi=TESSERA_ABI,
        )
        return int(contract.functions.scoreOf(address).call())
    except Exception:
        return 0


def score_of(address: str) -> int:
    """Returns BONAFIDE reputation score (0-1000)."""
    return _cached_score(address.lower(), _ttl_bucket())


def discount_factor(address: str) -> float:
    """
    Returns a multiplier to apply to base price.

    1.0  = full price
    0.75 = 25% discount
    0.5  = 50% discount
    """
    if not BONAFIDE_ENABLED:
        return 1.0

    score = score_of(address)
    if score >= 800:
        return 0.5
    elif score >= 500:
        return 0.75
    return 1.0
