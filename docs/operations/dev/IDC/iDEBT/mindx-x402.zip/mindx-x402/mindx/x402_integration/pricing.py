"""
Per-endpoint pricing.

Prices are USD-denominated; the x402 SDK converts to USDC base units
(USDC has 6 decimals, so $0.01 = 10_000 base units).

Set prices high enough to cover:
  (a) upstream LLM cost (Ollama, OpenAI, Anthropic)
  (b) facilitator fees (zero on CDP/Base)
  (c) gross margin (~70% target)
"""

# ----------------------------------------------------------
# Base prices per endpoint (USD strings as the SDK expects)
# ----------------------------------------------------------
BASE_PRICES = {
    "GET /api/v1/reason":          "$0.001",   # short reasoning
    "POST /api/v1/socratic":       "$0.01",    # full Socratic chain
    "POST /api/v1/dream":          "$0.05",    # generative reasoning
    "GET /api/v1/agents/discover": "$0.0001",  # marketplace discovery
}


def usd_to_float(price_str: str) -> float:
    """Convert '$0.01' → 0.01"""
    return float(price_str.lstrip("$"))


def float_to_usd(value: float) -> str:
    """Convert 0.01 → '$0.01'"""
    return f"${value:.6f}".rstrip("0").rstrip(".")


def discounted_price_for(endpoint: str, payer_address: str) -> str:
    """
    Compute the final price for a given endpoint and payer.

    Applies BONAFIDE reputation discount if enabled.
    Returns USD string in x402 SDK format.
    """
    base_str = BASE_PRICES.get(endpoint)
    if base_str is None:
        raise KeyError(f"No price configured for {endpoint!r}")

    base = usd_to_float(base_str)

    # Apply reputation discount if enabled
    from mindx.x402_integration.config import BONAFIDE_ENABLED
    if BONAFIDE_ENABLED:
        from mindx.x402_integration.reputation import discount_factor
        try:
            base *= discount_factor(payer_address)
        except Exception:
            # If reputation lookup fails, fall back to base price (don't error)
            pass

    return float_to_usd(base)
