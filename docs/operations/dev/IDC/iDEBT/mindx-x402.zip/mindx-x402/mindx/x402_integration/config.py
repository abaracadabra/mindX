"""
x402 environment configuration.

All chain-specific constants and runtime settings live here.
Switching between testnet and mainnet is a matter of MINDX_ENV.
"""
import os
from dotenv import load_dotenv

from mindx.config.secrets import get_secret

load_dotenv()

ENV = os.getenv("MINDX_ENV", "development")

# ----------------------------------------------------------
# USDC contract addresses (verified, official Circle issuances)
# ----------------------------------------------------------
USDC_ADDRESSES = {
    "eip155:1":      "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",   # Ethereum
    "eip155:8453":   "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",   # Base mainnet
    "eip155:84532":  "0x036CbD53842c5426634e7929541eC2318f3dCF7e",   # Base Sepolia
    "eip155:137":    "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",   # Polygon
}

# ----------------------------------------------------------
# Environment-driven settings
# ----------------------------------------------------------
if ENV == "production":
    NETWORK = "eip155:8453"
    FACILITATOR_URL = "https://api.cdp.coinbase.com/platform/v2/x402"
    PAY_TO_ADDRESS = get_secret("MINDX_MAINNET_PAY_TO")
    CDP_API_KEY_ID = get_secret("CDP_API_KEY_ID")
    CDP_API_KEY_SECRET = get_secret("CDP_API_KEY_SECRET")
elif ENV == "staging":
    NETWORK = "eip155:84532"
    FACILITATOR_URL = "https://x402.org/facilitator"
    PAY_TO_ADDRESS = os.environ["PAY_TO_ADDRESS"]
    CDP_API_KEY_ID = os.getenv("CDP_API_KEY_ID", "")
    CDP_API_KEY_SECRET = os.getenv("CDP_API_KEY_SECRET", "")
else:  # development
    NETWORK = os.getenv("X402_NETWORK", "eip155:84532")
    FACILITATOR_URL = os.getenv("FACILITATOR_URL", "https://x402.org/facilitator")
    PAY_TO_ADDRESS = os.getenv("PAY_TO_ADDRESS", "0x0000000000000000000000000000000000000000")
    CDP_API_KEY_ID = os.getenv("CDP_API_KEY_ID", "")
    CDP_API_KEY_SECRET = os.getenv("CDP_API_KEY_SECRET", "")

USDC_ASSET = USDC_ADDRESSES[NETWORK]

# Optional backup facilitator for graceful fallback
FACILITATOR_BACKUP_URL = os.getenv("FACILITATOR_BACKUP_URL", "")

# ----------------------------------------------------------
# Audit logging
# ----------------------------------------------------------
PAYMENT_LOG_PATH = os.getenv("PAYMENT_LOG_PATH", "/var/log/mindx/payments.jsonl")
REFUND_LOG_PATH = os.getenv("REFUND_LOG_PATH", "/var/log/mindx/refunds.jsonl")

# ----------------------------------------------------------
# Optional layers
# ----------------------------------------------------------
BANKON_ENABLED = os.getenv("BANKON_ENABLED", "false").lower() == "true"
BANKON_MODE = os.getenv("BANKON_MODE", "off")  # off | soft | strict
BANKON_ALGOIDNFT_ASSET_ID = int(os.getenv("BANKON_ALGOIDNFT_ASSET_ID", "0"))
BANKON_REGISTRY_CONTRACT = os.getenv("BANKON_REGISTRY_CONTRACT", "")
ALGORAND_INDEXER_URL = os.getenv("ALGORAND_INDEXER_URL", "https://mainnet-idx.algonode.cloud")

BONAFIDE_ENABLED = os.getenv("BONAFIDE_ENABLED", "false").lower() == "true"
BONAFIDE_TESSERA_CONTRACT = os.getenv("BONAFIDE_TESSERA_CONTRACT", "")
BONAFIDE_RPC_URL = os.getenv("BONAFIDE_RPC_URL", "https://mainnet.base.org")


def summary() -> dict:
    """Returns sanitized config summary for logging at startup."""
    return {
        "env": ENV,
        "network": NETWORK,
        "facilitator": FACILITATOR_URL,
        "usdc_asset": USDC_ASSET,
        "pay_to": PAY_TO_ADDRESS,
        "bankon_enabled": BANKON_ENABLED,
        "bankon_mode": BANKON_MODE,
        "bonafide_enabled": BONAFIDE_ENABLED,
    }
