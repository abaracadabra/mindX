"""
mindX reasoning endpoints.

These endpoints are gated by x402 payment middleware when mounted
under /pay. They include OpenAPI metadata so agents can discover
pricing machine-readably.
"""
from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/v1", tags=["reasoning"])


# ----------------------------------------------------------
# Request/response models
# ----------------------------------------------------------
class SocraticRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=1000)
    depth: int = Field(default=3, ge=1, le=10)


class SocraticResponse(BaseModel):
    chain: list[str]
    synthesis: str


class DreamRequest(BaseModel):
    seed: str = Field(..., min_length=1, max_length=500)
    temperature: float = Field(default=0.8, ge=0.0, le=2.0)


# ----------------------------------------------------------
# Endpoints
# ----------------------------------------------------------
@router.get(
    "/reason",
    openapi_extra={
        "x-402": {
            "schemes": ["exact"],
            "networks": ["eip155:8453", "eip155:84532"],
            "price": "$0.001",
            "description": "Short-form reasoning response",
        }
    },
)
async def reason(question: str) -> dict:
    """
    Short reasoning endpoint — $0.001 per call.

    In production this would call Ollama / your inference engine.
    """
    # Placeholder — replace with actual inference call
    return {
        "question": question,
        "answer": (
            "The unexamined life is not worth living. "
            "But the examined life requires constant questioning."
        ),
    }


@router.post(
    "/socratic",
    response_model=SocraticResponse,
    openapi_extra={
        "x-402": {
            "schemes": ["exact"],
            "networks": ["eip155:8453", "eip155:84532"],
            "price": "$0.01",
            "description": "Full Socratic reasoning chain",
        }
    },
)
async def socratic(payload: SocraticRequest) -> SocraticResponse:
    """Full Socratic reasoning chain — $0.01 per call."""
    # Placeholder — replace with actual reasoning chain
    chain = [
        f"What do you mean by '{payload.question}'?",
        "What evidence supports this?",
        "What might contradict it?",
    ][: payload.depth]
    return SocraticResponse(
        chain=chain,
        synthesis="Through questioning, clarity emerges.",
    )


@router.post(
    "/dream",
    openapi_extra={
        "x-402": {
            "schemes": ["exact"],
            "networks": ["eip155:8453", "eip155:84532"],
            "price": "$0.05",
            "description": "Generative reasoning (high compute)",
        }
    },
)
async def dream(payload: DreamRequest) -> dict:
    """Generative reasoning — $0.05 per call (high compute cost)."""
    return {
        "seed": payload.seed,
        "dream": f"From '{payload.seed}' emerges...",
        "temperature": payload.temperature,
    }


@router.get(
    "/agents/discover",
    openapi_extra={
        "x-402": {
            "schemes": ["exact"],
            "networks": ["eip155:8453", "eip155:84532"],
            "price": "$0.0001",
        }
    },
)
async def discover_agents(capability: str | None = None) -> dict:
    """Agent marketplace discovery — $0.0001 per call."""
    return {
        "query": capability,
        "agents": [
            {"id": "mindx-reasoner", "capabilities": ["reason", "socratic"]},
        ],
    }
