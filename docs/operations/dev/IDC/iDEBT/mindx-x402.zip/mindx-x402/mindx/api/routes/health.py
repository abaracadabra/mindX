"""Always-free health endpoints."""
from fastapi import APIRouter

from mindx import __version__
from mindx.x402_integration.config import summary

router = APIRouter(tags=["health"])


@router.get("/health")
async def health() -> dict:
    """Simple liveness probe."""
    return {"status": "ok", "version": __version__}


@router.get("/health/config")
async def health_config() -> dict:
    """Sanitized config summary for operational debugging."""
    return summary()
