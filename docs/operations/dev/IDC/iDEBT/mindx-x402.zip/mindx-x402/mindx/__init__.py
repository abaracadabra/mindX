"""mindX — consciousness reasoning API with x402 payment integration."""

__version__ = "1.0.0"
