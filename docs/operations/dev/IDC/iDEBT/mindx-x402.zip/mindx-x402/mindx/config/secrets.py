"""
Secrets management.

In development: read from environment variables (.env loaded by python-dotenv).
In production: read from Google Secret Manager.

Usage:
    from mindx.config.secrets import get_secret
    api_key = get_secret("CDP_API_KEY_ID")
"""
import os
from functools import lru_cache


def _is_production() -> bool:
    return os.getenv("MINDX_ENV") == "production"


@lru_cache(maxsize=64)
def get_secret(secret_id: str, project_id: str = "deltaverse-prod") -> str:
    """
    Fetch a secret by ID.

    Cached per-process — secrets are assumed stable for the lifetime of the process.
    For rotation, restart the process.
    """
    # Development path — plain env var
    if not _is_production():
        value = os.getenv(secret_id)
        if value is None:
            raise KeyError(f"Secret {secret_id!r} not in environment")
        return value

    # Production path — GCP Secret Manager
    try:
        from google.cloud import secretmanager
    except ImportError as e:
        raise RuntimeError(
            "google-cloud-secret-manager not installed. "
            "Run: pip install -e '.[gcp]'"
        ) from e

    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/{secret_id}/versions/latest"
    response = client.access_secret_version(request={"name": name})
    return response.payload.data.decode("UTF-8")
