"""
Payment audit log.

Append-only JSONL. Every settled payment writes one line.
Used for:
  - Nightly reconciliation against on-chain state
  - Customer support disputes
  - Tax/regulatory reporting (US: 7-year retention)

Schema:
  {
    "ts": float,           # unix timestamp
    "route": str,          # "GET /api/v1/reason"
    "payer": str,          # 0x... EVM address
    "tx_hash": str,        # 0x... settlement tx hash
    "amount": str,         # USDC base units as string (preserves precision)
    "network": str,        # "eip155:8453"
    "facilitator": str,    # which facilitator settled
    "asset": str,          # USDC contract address
  }
"""
import json
import time
from pathlib import Path
from typing import Any

from mindx.x402_integration.config import (
    PAYMENT_LOG_PATH,
    REFUND_LOG_PATH,
)


def log_payment(
    *,
    route: str,
    payer: str,
    tx_hash: str,
    amount_usdc_base_units: str,
    network: str,
    facilitator: str,
    asset: str,
    extra: dict[str, Any] | None = None,
) -> None:
    """Append a payment record to the audit log."""
    record: dict[str, Any] = {
        "ts": time.time(),
        "route": route,
        "payer": payer,
        "tx_hash": tx_hash,
        "amount": amount_usdc_base_units,
        "network": network,
        "facilitator": facilitator,
        "asset": asset,
    }
    if extra:
        record["extra"] = extra

    _append(PAYMENT_LOG_PATH, record)


def log_refund(
    *,
    payer: str,
    original_tx_hash: str,
    refund_tx_hash: str,
    amount_usdc_base_units: str,
    reason: str,
    operator: str,
) -> None:
    """Append a refund record to the refund log."""
    record = {
        "ts": time.time(),
        "payer": payer,
        "original_tx": original_tx_hash,
        "refund_tx": refund_tx_hash,
        "amount": amount_usdc_base_units,
        "reason": reason,
        "operator": operator,
    }
    _append(REFUND_LOG_PATH, record)


def _append(path: str, record: dict[str, Any]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(json.dumps(record) + "\n")
