# x402 Production Implementation Playbook
## Complete consolidated guide: mindX + AgenticPlace + BANKON on Base mainnet

This is the implementation companion to the prior x402 deep-dive. Where that report answered "what is x402 and does it fit," this one answers "exactly how do I ship it." Every code block below comes from real, verified sources — the official `coinbase/x402` repo, the published `x402` PyPI package (currently at v2.6.0), Coinbase Developer Platform docs, and GoPlausible's Algorand implementation.

The playbook is organized as 13 sequential sections. Execute them in order, day zero to production, in roughly two to three weeks of focused work.

---

## SECTION 1 — Prerequisites and environment setup

### Why this matters

Before writing any payment code, you need the toolchain installed correctly and the right wallets funded. Most x402 integration failures trace to either (a) the wrong USDC contract address for the chain you're on, or (b) signing with a key funded on testnet but pointed at mainnet config. This section eliminates both.

### Software versions

| Tool | Version | Purpose |
|------|---------|---------|
| Python | 3.11+ | FastAPI + x402 SDK runtime |
| Node.js | 20+ | Optional; TypeScript tooling and AlgoKit |
| Foundry | latest (via foundryup) | Solidity testing, anvil fork, cast |
| pip or uv | latest | Python package management |
| git | 2.30+ | Source control |
| Podman | 4.0+ | Container runtime |

```bash
curl -L https://foundry.paradigm.xyz | bash
foundryup

pip install "x402[fastapi]"
python -c "import x402; print(x402.__version__)"
```

The `[fastapi]` extra pulls in `PaymentMiddlewareASGI`. Other extras: `all, clients, evm, extensions, fastapi, flask, httpx, mcp, mechanisms, requests, servers, svm`.

### CDP account

For Base **mainnet**, you need CDP because the production facilitator at `https://api.cdp.coinbase.com/platform/v2/x402` requires API keys. For Base **Sepolia**, the public facilitator at `https://x402.org/facilitator` is free.

1. Sign up at `portal.cdp.coinbase.com`
2. Settings → API Keys → Create
3. Store `CDP_API_KEY_ID` and `CDP_API_KEY_SECRET` in secrets manager
4. CDP gives **fee-free USDC settlement on Base mainnet** with KYT/OFAC checks built in

### Wallet creation

```bash
cast wallet new
# Save the private key immediately to secrets manager
```

Fund testnet wallet from `faucet.circle.com` (Base Sepolia USDC) and `bridge.base.org` (Sepolia ETH).

### USDC contract addresses

| Network | Chain ID | USDC address |
|---------|----------|--------------|
| Base mainnet | 8453 | `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913` |
| Base Sepolia | 84532 | `0x036CbD53842c5426634e7929541eC2318f3dCF7e` |
| Ethereum mainnet | 1 | `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48` |
| Polygon | 137 | `0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359` |

Wrong address = `invalid_exact_evm_payload_signature`. USDC `name` is exactly `"USD Coin"`, `version` is `"2"`.

### Repo layout principle

x402 is **additive**. Drop the `x402_integration/` module and one line in `main.py` and the API works as before, just without payment.

---

## SECTION 2 — mindX FastAPI server-side integration

### The minimal working server

Verified against `github.com/coinbase/x402/tree/main/examples/python/servers/fastapi`:

```python
from fastapi import FastAPI
from x402.http.middleware.fastapi import PaymentMiddlewareASGI
from x402.http import HTTPFacilitatorClient, FacilitatorConfig, PaymentOption
from x402.http.types import RouteConfig
from x402.server import x402ResourceServer
from x402.mechanisms.evm.exact import ExactEvmServerScheme

facilitator = HTTPFacilitatorClient(FacilitatorConfig(url=FACILITATOR_URL))
server = x402ResourceServer(facilitator)
server.register(NETWORK, ExactEvmServerScheme())

routes = {
    "GET /api/v1/reason": RouteConfig(accepts=[PaymentOption(
        scheme="exact", price="$0.001",
        network=NETWORK, pay_to=PAY_TO_ADDRESS,
    )]),
}

app = FastAPI()
app.add_middleware(PaymentMiddlewareASGI, routes=routes, server=server)
```

See `mindx/x402_integration/middleware.py` for the production version.

### Free vs paid

Middleware only intercepts paths in the `routes` dict. `/health`, `/redoc`, `/openapi.json` stay out of it.

### Exact vs upto

- **exact** — fixed price per call. Use for predictable cost.
- **upto** — client authorizes max, server settles actual. Use for variable LLM cost. V2 implements this via Permit2 on EVM.

For first version, use `exact` with prices set at expected cost. Migrate to `upto` once your traffic justifies the complexity.

### Coexistence with API keys

Cleanest pattern: two FastAPI apps mounted under different paths.

```python
free_app = FastAPI()
free_app.add_middleware(APIKeyAuthMiddleware)

paid_app = FastAPI()
install_x402(paid_app)

main_app = FastAPI()
main_app.mount("/free", free_app)
main_app.mount("/pay", paid_app)
```

Same routes, two doors. Devs use `/free`; agents use `/pay`.

---

## SECTION 3 — AgenticPlace agent client

### The flow

1. Agent → request to `/pay/api/v1/reason`
2. Server → 402 with payment requirements
3. Agent's x402 client builds EIP-3009 authorization, signs with private key
4. Agent → retries with signed authorization in `X-PAYMENT` header
5. Server → forwards to facilitator, gets settlement, returns resource

The official SDK does steps 3-4 automatically.

### Minimal agent (verified, from `examples/python/clients/httpx`)

```python
from eth_account import Account
from x402.clients import x402HttpxClient

account = Account.from_key(os.environ["AGENT_PRIVATE_KEY"])

async with x402HttpxClient(account=account, base_url="https://mindx.pythai.net") as client:
    response = await client.get("/pay/api/v1/reason?question=what+is+being")
    receipt = response.headers.get("PAYMENT-RESPONSE")
```

### Funding patterns

- **A — operator pre-funds** each agent at registration (start here)
- **B — human owner funds** the agent's wallet themselves
- **C — earn-then-spend** closed-loop economy

### Wallet key management

Ranked by security: HSM-backed (GCP Cloud KMS, AWS CloudHSM) > encrypted in TEE > encrypted with passphrase > plain `.env` (testnet only). Production: GCP Cloud KMS with key-per-agent.

### Service discovery

x402 V2 introduced **Bazaar** discovery, but for AgenticPlace run your own discovery layer extending `allchain.html`. Agents fetch a JSON registry of services with their pricing.

---

## SECTION 4 — BANKON identity gating (optional)

Cross-chain wrinkle: payment is on Base, identity is on Algorand.

**Approach 1** — Registry contract on Base maps `EVM_address → Algorand_address`. Middleware queries it, then queries Algorand indexer for AlgoIDNFT.

**Approach 2** — Mint ERC-721 mirror of AlgoIDNFT on Base via oracle.

For first version, use Approach 1 — honest about cross-chain, no bridge risk.

See `mindx/x402_integration/identity.py` for the implementation.

---

## SECTION 5 — BONAFIDE reputation pricing (optional)

Query Tessera contract on Base, multiply base price by discount factor. Cache aggressively (1-hour TTL via Redis in multi-process deployment).

See `mindx/x402_integration/reputation.py`.

---

## SECTION 6 — Foundry-based testing

### Fork Base Sepolia locally

```bash
export BASE_SEPOLIA_RPC=https://sepolia.base.org
anvil --fork-url $BASE_SEPOLIA_RPC --chain-id 84532 --port 8545
```

For mainnet rehearsal: swap to `https://mainnet.base.org` and `--chain-id 8453`.

See `contracts/test/X402Settlement.t.sol` for the full settlement test.

### Pre-mainnet test matrix

| Test | Expected |
|------|----------|
| Valid payment, fresh nonce | 402 → sign → 200 with PAYMENT-RESPONSE |
| Expired authorization | Facilitator rejects |
| Replayed nonce | USDC contract reverts |
| Wrong chain ID in EIP-712 | Signature fails |
| Insufficient USDC | Settlement fails |
| Wrong USDC contract | Domain mismatch |
| Concurrent payments same payer | Both succeed if nonces differ |
| BANKON check fails | 403, no payment |
| Reputation discount | 402 with reduced price |
| Free endpoint | 200, no 402 |
| Valid API key | 200, x402 bypassed |

---

## SECTION 7 — Deployment to Base mainnet

### Pre-deployment checklist

- [ ] All Sepolia tests pass for 7 days of dogfooding
- [ ] CDP API keys in Google Secret Manager
- [ ] Mainnet receiving wallet confirmed
- [ ] Production env: `NETWORK=eip155:8453`, `FACILITATOR_URL=https://api.cdp.coinbase.com/platform/v2/x402`
- [ ] Audit log writable, retention decided
- [ ] Monitoring dashboards built
- [ ] Rollback plan tested (not just documented)

### Sequence

1. Deploy mainnet config to canary at 5% traffic
2. Make one $0.001 test payment from a wallet you control
3. Verify on Basescan: `https://basescan.org/address/<PAY_TO_ADDRESS>`
4. Verify audit log + CDP dashboard
5. Hold 5% for 24h, watch error rates
6. Ramp 25% → 50% → 100% over 3 days

### Facilitator comparison

| Facilitator | Pros | Cons |
|---|---|---|
| Coinbase CDP | Free on Base, KYT/OFAC, enterprise SLA | Requires API key |
| Cloudflare | Edge deployment | Newer |
| 0xmeta.ai | Multi-chain, webhooks | Smaller team |
| Self-hosted | Full control | You bear gas + ops |

**Start with CDP. Add 0xmeta as backup once volume justifies.**

### Rollback

1. **Immediate:** Set `FACILITATOR_URL=https://x402.org/facilitator` (testnet, rejects mainnet — pauses x402 safely)
2. **Better:** Remove `install_x402(app)` line, redeploy → endpoints become free
3. **Investigate:** audit log + CDP dashboard + Basescan
4. **Refund** affected payers if charged but not served
5. **Re-deploy** with canary

---

## SECTION 8 — Operational runbook

### Daily monitoring (5-min check)

- Total payments last 24h (count + USDC volume)
- Failed payment count + most common reason
- p50/p95/p99 settlement latency
- Facilitator uptime
- USDC balance growth on PAY_TO_ADDRESS
- KYT/OFAC flagged addresses

### Reconciliation (nightly)

For every payment in audit log: confirm on-chain tx exists, recipient matches, amount matches. Discrepancy investigated within 24h. See `scripts/reconcile_daily.py`.

### Manual refunds

x402 has no native refund. Operator reviews dispute → if warranted, send USDC back via `scripts/refund.sh`. Log to `refunds.jsonl`.

### Wallet key rotation (every 6-12 months)

1. Generate new wallet
2. Update `PAY_TO_ADDRESS` in secrets
3. Rolling restart
4. New 402s point to new address; in-flight signed authorizations to old still settle
5. Drain old: `cast send` remaining USDC to new
6. Archive old key

### Price changes

Update `pricing.py` and redeploy. New 402s reflect new price; in-flight signed authorizations honor old price.

---

## SECTION 9 — Algorand expansion via GoPlausible (future)

### When to add Algorand

- x402 volume > 10K/month and gas matters
- Agents already hold ALGO/USDC on Algorand
- Want BANKON identity at the payment chain
- Need sub-3-second deterministic finality

### Multi-chain routes

```python
"GET /api/v1/reason": RouteConfig(accepts=[
    PaymentOption(scheme="exact", price="$0.001",
        network="eip155:8453", pay_to=BASE_PAY_TO),
    PaymentOption(scheme="exact", price="$0.001",
        network="algorand:mainnet-v1.0", pay_to=ALGO_PAY_TO),
])
```

Server registers both schemes. Agent picks chain it has funds on.

### Algorand USDC

ASA ID **31566704**. Recipients **must opt in** before receiving. Test via AlgoKit (`algokit localnet start`).

GoPlausible facilitator: `facilitator.goplausible.xyz`. Their Go module: `github.com/GoPlausible/x402-avm`.

---

## SECTION 10 — PHP server-side: the honest answer

**No production PHP x402 library exists today.** Searched Packagist, GitHub, awesome-x402. Available SDKs: Python, TypeScript/JavaScript, Go, Rust, Java.

Options:

- **A — accept Python.** mindX is FastAPI. Stay.
- **B — Node.js sidecar.** Run small Node service for x402, proxy validated requests to PHP backend.
- **C — write a PHP x402 library.** ~2 weeks for a competent dev. Use `kornrunner/keccak` and `kornrunner/secp256k1` for EIP-712 signing. Publish as `pythai/x402-php`.

**Recommendation: A. Reserve C as community contribution opportunity.**

---

## SECTION 11 — Container, CI/CD

See `Containerfile`, `podman-compose.yml`, `.github/workflows/`.

Critical detail: `--loop asyncio` (not uvloop) for FastAPI + x402 — known compatibility issue.

---

## SECTION 12 — Consolidated checklist

### Day 0
- [ ] Foundry installed
- [ ] `pip install "x402[fastapi]"` verified
- [ ] CDP account, API key in secrets
- [ ] Sepolia wallet funded
- [ ] Mainnet receiving wallet generated

### Week 1
- [ ] `x402_integration/` module added
- [ ] PaymentMiddlewareASGI wired
- [ ] Two paid endpoints on Sepolia
- [ ] Free endpoints unaffected
- [ ] Audit logging works
- [ ] Local end-to-end passes

### Week 2
- [ ] Agent client makes successful payment
- [ ] Keys in GCP KMS (mainnet path)
- [ ] AgenticPlace `/api/v1/services` published
- [ ] `allchain.html` updated

### Week 3
- [ ] Foundry tests pass on Sepolia fork
- [ ] Pre-mainnet matrix all green
- [ ] Monitoring dashboard built
- [ ] Reconciliation script runs nightly on staging

### Week 4
- [ ] Mainnet canary at 5%
- [ ] First $0.001 test payment verified
- [ ] Basescan + audit log + CDP dashboard match
- [ ] Ramp to 100% over 3 days
- [ ] Rollback plan tested

### Decision points
- **Facilitator:** CDP | Cloudflare | 0xmeta | self-host
- **Pricing:** flat | upto | reputation-discounted
- **Identity gating:** off | soft | strict
- **Reputation pricing:** off | tiered | continuous
- **Second chain:** none | Algorand | Solana | Polygon

### Cost
| Item | Cost |
|------|------|
| CDP facilitator on Base | $0 (fee-free) |
| Gas per tx | $0 to payer |
| GCP Cloud KMS | ~$0.06/key/month + $0.03/10K signs |
| Secret Manager | ~$0.06/secret/month |
| Compute | $20-100/month moderate volume |
| Day 0 → production | 2-3 weeks focused work |

---

## SECTION 13 — Code deliverables

All in this repo. See:

- Server: `mindx/api/main.py` + `mindx/x402_integration/middleware.py`
- Agent: `agents/example_agent.py`
- Foundry test: `contracts/test/X402Settlement.t.sol`
- Reconciliation: `scripts/reconcile_daily.py`
- Refund: `scripts/refund.sh`
- CI: `.github/workflows/test.yml`

### Curl debugging

```bash
# Step 1 — get the 402
curl -i http://localhost:8000/api/v1/reason?question=test

# Step 2 — sign EIP-3009 (SDK does this automatically)
cast wallet sign-typed-data \
  --private-key $AGENT_PRIVATE_KEY \
  --data '{"types":{...},"domain":{...},"message":{...}}'

# Step 3 — retry with X-PAYMENT
curl -i http://localhost:8000/api/v1/reason?question=test \
  -H "X-PAYMENT: <base64-encoded-signed-payload>"
```

---

## Closing

x402 on Base mainnet via the official Python SDK is genuinely production-ready as of early 2026. The hard parts aren't the protocol — they're the operational discipline: secrets management, key rotation, reconciliation, refund handling, monitoring.

Start small. One paid endpoint. One canary deployment. One real test transaction. Watch for a week. Then expand.

The verdict: ship x402 on Base for AgenticPlace agent traffic, keep Stripe for human users, hold Algorand expansion until volume justifies. This repo is the path from that verdict to running production.
