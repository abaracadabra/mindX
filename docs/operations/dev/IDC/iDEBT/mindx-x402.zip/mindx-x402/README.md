# mindx-x402

> A complete, production-ready reference implementation for integrating the **x402 payment protocol** into a FastAPI service, with optional layers for **BANKON identity gating** and **BONAFIDE reputation pricing**, deployable to **Base mainnet** via **Coinbase Developer Platform**.

This repo is the working code companion to the x402 implementation playbook. It is opinionated, modular, and designed to be lifted directly into the `mindX` / `AgenticPlace` ecosystem — or any FastAPI service that wants to monetize endpoints with stablecoin micropayments.

---

## What is x402, in one paragraph

x402 is Coinbase's open protocol that turns the long-reserved HTTP `402 Payment Required` status code into a real payment rail. A client requests a paid resource, the server returns 402 with payment requirements, the client signs a USDC transfer authorization (EIP-3009, gasless), the server verifies and settles via a **facilitator**, and the resource is returned. The whole exchange happens within a single HTTP retry loop. It is designed for autonomous AI agents that cannot hold credit cards but can hold a wallet.

## Why this repo exists

The official Coinbase examples show isolated pieces — a server here, a client there. This repo assembles them into a complete production-shaped project: server, agent client, Solidity tests, container build, CI, audit logging, reconciliation scripts, and the optional BANKON/BONAFIDE layers that matter if you are building inside the DELTAVERSE ecosystem.

## Architecture in one diagram (described)

```
            ┌──────────────────────┐
            │  AgenticPlace agent  │  signs EIP-3009 authorization
            │  (holds USDC wallet) │  with its private key
            └──────────┬───────────┘
                       │ HTTPS + X-PAYMENT header
                       ▼
            ┌──────────────────────┐
            │   mindX FastAPI      │  PaymentMiddlewareASGI
            │  /pay/api/v1/reason  │  intercepts before route
            └──────────┬───────────┘
                       │ POST /verify, /settle
                       ▼
            ┌──────────────────────┐
            │  CDP Facilitator     │  api.cdp.coinbase.com
            │  (free on Base)      │
            └──────────┬───────────┘
                       │ submits signed tx
                       ▼
            ┌──────────────────────┐
            │   Base mainnet USDC  │  0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913
            │   transferWithAuth   │
            └──────────────────────┘
```

Optional sidecar checks **before payment is accepted**:

- **BANKON AlgoIDNFT** identity gate (cross-chain: query Algorand indexer)
- **BONAFIDE reputation** pricing (read Tessera contract on Base, discount or surcharge)

## Repo layout

```
mindx-x402/
├── README.md                    # this file
├── PLAYBOOK.md                  # full 13-section implementation playbook
├── pyproject.toml               # Python project + dependencies
├── foundry.toml                 # Solidity test config
├── Containerfile                # Podman/Docker build
├── podman-compose.yml           # local dev stack (mindX + anvil fork)
├── .env.example                 # all configuration variables
├── .gitignore
│
├── mindx/                       # the FastAPI service
│   ├── api/
│   │   ├── main.py              # app entry, dual /free + /pay mounts
│   │   └── routes/
│   │       ├── health.py        # always free
│   │       └── reasoning.py     # gated by x402
│   ├── x402_integration/        # all x402 code lives here — removable
│   │   ├── config.py            # facilitator URL, network, asset
│   │   ├── middleware.py        # PaymentMiddlewareASGI wiring
│   │   ├── pricing.py           # per-route price logic
│   │   ├── audit.py             # JSONL payment log
│   │   ├── identity.py          # BANKON cross-chain identity check
│   │   └── reputation.py        # BONAFIDE reputation pricing
│   └── config/
│       └── secrets.py           # GCP Secret Manager helper
│
├── agents/                      # client side
│   ├── example_agent.py         # async client paying for endpoints
│   └── README.md
│
├── contracts/                   # Foundry-based Solidity tests
│   ├── src/
│   │   └── BankonRegistry.sol   # cross-chain address registry
│   └── test/
│       └── X402Settlement.t.sol # full EIP-3009 settlement tests
│
├── scripts/
│   ├── refund.sh                # manual USDC refund via cast
│   └── reconcile_daily.py       # nightly on-chain reconciliation
│
├── tests/                       # Python unit + integration tests
│   ├── test_middleware.py
│   └── test_e2e.py
│
└── .github/workflows/
    ├── test.yml                 # CI: pytest + forge test
    └── deploy.yml               # mainnet deployment with canary
```

## Quick start (testnet, 5 minutes)

```bash
# 1. Install
pip install -e .

# 2. Configure
cp .env.example .env
# Edit .env: set PAY_TO_ADDRESS to a wallet you control

# 3. Get test USDC on Base Sepolia
# Visit https://faucet.circle.com — select Base Sepolia

# 4. Run the server
uvicorn mindx.api.main:app --port 8000 --loop asyncio

# 5. From another terminal, run the agent
export AGENT_PRIVATE_KEY=0x...your-test-key...
python agents/example_agent.py
```

You should see: 402 from the server, automatic signing by the SDK, 200 with the result, and a `PAYMENT-RESPONSE` header containing the on-chain transaction hash.

## Going to mainnet

See `PLAYBOOK.md` Section 7. Summary:

1. Sign up at `portal.cdp.coinbase.com` for a CDP API key
2. Set `MINDX_ENV=production` in your environment
3. Switch `X402_NETWORK=eip155:8453` and `FACILITATOR_URL=https://api.cdp.coinbase.com/platform/v2/x402`
4. Deploy to a canary instance at 5% traffic
5. Make one $0.001 test payment from your own wallet, verify on Basescan
6. Ramp to 100% over 3 days

## Verified sources

Every code pattern in this repo is taken from or verified against:

- `github.com/coinbase/x402` — official Coinbase x402 monorepo
- `github.com/coinbase/x402/tree/main/examples/python/servers/fastapi` — official FastAPI example
- `github.com/coinbase/x402/tree/main/examples/python/clients/httpx` — official async client example
- `pypi.org/project/x402/` — official Python SDK (currently v2.6.0)
- `docs.cdp.coinbase.com/x402` — Coinbase Developer Platform documentation
- `github.com/GoPlausible/x402-avm` — Algorand x402 implementation (for future expansion)

## License

MIT. Use freely. Attribution appreciated but not required.
