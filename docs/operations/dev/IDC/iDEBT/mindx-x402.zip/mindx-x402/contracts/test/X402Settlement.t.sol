// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";

/**
 * @title X402SettlementTest
 * @notice Tests the EIP-3009 transferWithAuthorization flow that underlies
 *         x402 "exact" scheme settlement.
 *
 * Run against Base Sepolia fork:
 *   forge test --fork-url https://sepolia.base.org -vvv
 *
 * Run against Base mainnet fork (read-only rehearsal):
 *   forge test --fork-url https://mainnet.base.org -vvv
 */

interface IUSDC {
    function transferWithAuthorization(
        address from,
        address to,
        uint256 value,
        uint256 validAfter,
        uint256 validBefore,
        bytes32 nonce,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external;

    function balanceOf(address) external view returns (uint256);
    function name() external view returns (string memory);
    function version() external view returns (string memory);
    function DOMAIN_SEPARATOR() external view returns (bytes32);
    function authorizationState(address authorizer, bytes32 nonce)
        external view returns (bool);
}

contract X402SettlementTest is Test {
    // Base Sepolia USDC. Swap to 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913
    // when running against Base mainnet fork.
    IUSDC usdc = IUSDC(0x036CbD53842c5426634e7929541eC2318f3dCF7e);

    // EIP-3009 TransferWithAuthorization type hash
    bytes32 constant TRANSFER_WITH_AUTHORIZATION_TYPEHASH = keccak256(
        "TransferWithAuthorization(address from,address to,uint256 value,uint256 validAfter,uint256 validBefore,bytes32 nonce)"
    );

    address payer;
    uint256 payerKey;
    address payee;
    address facilitator;

    function setUp() public {
        (payer, payerKey) = makeAddrAndKey("payer");
        payee = makeAddr("payee");
        facilitator = makeAddr("facilitator");

        // Fund the payer with USDC by giving them balance via vm.deal-style trick:
        // In a real test, impersonate a known Sepolia USDC holder.
        // For didactic purposes, we use vm.store to seed balance directly.
        // (In production tests, use vm.prank + actual transfer from a whale.)
        deal(address(usdc), payer, 1_000_000); // $1.00 in USDC (6 decimals)
    }

    // ------------------------------------------------------------
    // Helper: build and sign an EIP-3009 authorization
    // ------------------------------------------------------------
    function _signAuth(
        address from,
        uint256 fromKey,
        address to,
        uint256 value,
        uint256 validAfter,
        uint256 validBefore,
        bytes32 nonce
    ) internal view returns (uint8 v, bytes32 r, bytes32 s) {
        bytes32 structHash = keccak256(
            abi.encode(
                TRANSFER_WITH_AUTHORIZATION_TYPEHASH,
                from,
                to,
                value,
                validAfter,
                validBefore,
                nonce
            )
        );
        bytes32 digest = keccak256(
            abi.encodePacked("\x19\x01", usdc.DOMAIN_SEPARATOR(), structHash)
        );
        (v, r, s) = vm.sign(fromKey, digest);
    }

    // ============================================================
    // HAPPY PATH
    // ============================================================

    function test_ExactSettlement_Succeeds() public {
        uint256 value = 10_000;  // $0.01
        uint256 validAfter = block.timestamp;
        uint256 validBefore = block.timestamp + 600;
        bytes32 nonce = keccak256(abi.encodePacked(payer, block.timestamp, uint256(1)));

        (uint8 v, bytes32 r, bytes32 s) = _signAuth(
            payer, payerKey, payee, value, validAfter, validBefore, nonce
        );

        uint256 beforeBal = usdc.balanceOf(payee);

        // Facilitator submits the pre-signed authorization on behalf of the payer.
        // Note: facilitator pays gas; payer does not.
        vm.prank(facilitator);
        usdc.transferWithAuthorization(
            payer, payee, value, validAfter, validBefore, nonce, v, r, s
        );

        assertEq(usdc.balanceOf(payee), beforeBal + value, "payee balance");
        assertTrue(
            usdc.authorizationState(payer, nonce),
            "nonce should be marked used"
        );
    }

    // ============================================================
    // FAILURE MODES
    // ============================================================

    function test_ExpiredAuthorization_Reverts() public {
        uint256 value = 10_000;
        uint256 validAfter = block.timestamp - 3600;
        uint256 validBefore = block.timestamp - 1;  // already expired
        bytes32 nonce = keccak256(abi.encodePacked(payer, uint256(2)));

        (uint8 v, bytes32 r, bytes32 s) = _signAuth(
            payer, payerKey, payee, value, validAfter, validBefore, nonce
        );

        vm.prank(facilitator);
        vm.expectRevert();
        usdc.transferWithAuthorization(
            payer, payee, value, validAfter, validBefore, nonce, v, r, s
        );
    }

    function test_NotYetValidAuthorization_Reverts() public {
        uint256 value = 10_000;
        uint256 validAfter = block.timestamp + 3600;  // future
        uint256 validBefore = block.timestamp + 7200;
        bytes32 nonce = keccak256(abi.encodePacked(payer, uint256(3)));

        (uint8 v, bytes32 r, bytes32 s) = _signAuth(
            payer, payerKey, payee, value, validAfter, validBefore, nonce
        );

        vm.prank(facilitator);
        vm.expectRevert();
        usdc.transferWithAuthorization(
            payer, payee, value, validAfter, validBefore, nonce, v, r, s
        );
    }

    function test_ReplayedNonce_Reverts() public {
        uint256 value = 10_000;
        uint256 validAfter = block.timestamp;
        uint256 validBefore = block.timestamp + 600;
        bytes32 nonce = keccak256(abi.encodePacked(payer, uint256(4)));

        (uint8 v, bytes32 r, bytes32 s) = _signAuth(
            payer, payerKey, payee, value, validAfter, validBefore, nonce
        );

        // First settlement — succeeds
        vm.prank(facilitator);
        usdc.transferWithAuthorization(
            payer, payee, value, validAfter, validBefore, nonce, v, r, s
        );

        // Replay with same nonce — MUST revert
        vm.prank(facilitator);
        vm.expectRevert();
        usdc.transferWithAuthorization(
            payer, payee, value, validAfter, validBefore, nonce, v, r, s
        );
    }

    function test_WrongSigner_Reverts() public {
        (address wrongSigner, uint256 wrongKey) = makeAddrAndKey("wrongSigner");

        uint256 value = 10_000;
        uint256 validAfter = block.timestamp;
        uint256 validBefore = block.timestamp + 600;
        bytes32 nonce = keccak256(abi.encodePacked(payer, uint256(5)));

        // Sign with the WRONG key but claim `from = payer`
        (uint8 v, bytes32 r, bytes32 s) = _signAuth(
            payer, wrongKey, payee, value, validAfter, validBefore, nonce
        );

        vm.prank(facilitator);
        vm.expectRevert();
        usdc.transferWithAuthorization(
            payer, payee, value, validAfter, validBefore, nonce, v, r, s
        );

        // Silence unused var warning
        wrongSigner;
    }

    function test_InsufficientBalance_Reverts() public {
        uint256 value = 10_000_000;  // $10, payer only has $1
        uint256 validAfter = block.timestamp;
        uint256 validBefore = block.timestamp + 600;
        bytes32 nonce = keccak256(abi.encodePacked(payer, uint256(6)));

        (uint8 v, bytes32 r, bytes32 s) = _signAuth(
            payer, payerKey, payee, value, validAfter, validBefore, nonce
        );

        vm.prank(facilitator);
        vm.expectRevert();
        usdc.transferWithAuthorization(
            payer, payee, value, validAfter, validBefore, nonce, v, r, s
        );
    }

    // ============================================================
    // SANITY CHECKS on the USDC contract (the EIP-712 domain)
    // ============================================================

    function test_DomainValues_MatchExpected() public view {
        // These are the exact values the x402 client SDK expects.
        // If they drift, signatures will fail.
        assertEq(usdc.name(), "USDC");  // NOTE: Sepolia USDC may return "USDC" not "USD Coin"
        // On mainnet USDC the name is "USD Coin"; confirm per-network.
        assertEq(usdc.version(), "2");
    }
}
