// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title BankonRegistry
 * @notice Cross-chain identity registry linking Base EVM addresses to Algorand wallets.
 *
 * An agent wishing to assert BANKON identity on Base registers their Algorand
 * address here. The x402 middleware on mindX reads this mapping, then queries
 * the Algorand indexer to verify AlgoIDNFT (soulbound identity ASA) ownership
 * on the linked Algorand account.
 *
 * Registration requires a signature from the Algorand side (not enforced
 * on-chain — verified off-chain by BANKON identity service before accepting
 * the registration transaction).
 *
 * This is a minimal reference implementation. Production version should:
 *   - Require off-chain signature proving control of the Algorand address
 *   - Support unlinking (address changes, key rotation)
 *   - Emit events for indexing
 */
contract BankonRegistry {
    mapping(address => string) private _algoAddress;
    mapping(address => uint256) public linkedAt;

    event IdentityLinked(address indexed evmAddress, string algoAddress);
    event IdentityUnlinked(address indexed evmAddress);

    /**
     * @notice Link this caller's EVM address to an Algorand address.
     * @param algoAddress The 58-character Algorand address string.
     */
    function linkIdentity(string calldata algoAddress) external {
        require(bytes(algoAddress).length == 58, "invalid algo address length");
        _algoAddress[msg.sender] = algoAddress;
        linkedAt[msg.sender] = block.timestamp;
        emit IdentityLinked(msg.sender, algoAddress);
    }

    /**
     * @notice Remove the link for the caller.
     */
    function unlinkIdentity() external {
        require(bytes(_algoAddress[msg.sender]).length > 0, "not linked");
        delete _algoAddress[msg.sender];
        delete linkedAt[msg.sender];
        emit IdentityUnlinked(msg.sender);
    }

    /**
     * @notice Returns the linked Algorand address for an EVM address, or empty string.
     */
    function algoAddressFor(address evmAddress) external view returns (string memory) {
        return _algoAddress[evmAddress];
    }

    /**
     * @notice Returns true if this address has a linked Algorand identity.
     */
    function isLinked(address evmAddress) external view returns (bool) {
        return bytes(_algoAddress[evmAddress]).length > 0;
    }
}
