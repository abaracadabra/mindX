// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

import {IOmnipons} from "../interfaces/IOmnipons.sol";
import {IPons} from "../interfaces/IPons.sol";

/*
 * Omnipons — the all-bridge.
 *
 * Multi-bridge router that aggregates Pontem implementations behind a
 * single transire() call. Selects the optimal Pontem for each destination
 * based on the user's maxSigillumTier (trust ceiling) and the available
 * Limen on the destination side.
 *
 * Conceptual heritage from THRUSTDeltaV stargate router (handshake →
 * warpdrive → equilibrium → afterburner) — multi-stage bridge
 * composition. Reimplemented with xERC20 burn/mint primitives instead
 * of external-validator messaging. The trust model is per-Pontem and
 * always bounded by the Pons Limen.
 */

interface IPontem {
    function transire(
        uint32 destinationNetwork,
        address destinationAddress,
        uint256 amount
    ) external payable;
}

contract Omnipons is IOmnipons, Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // ============================================================
    // Storage
    // ============================================================

    /// pontemId → registration
    mapping(bytes32 => PontemRegistration) public pontems;

    /// All registered pontemIds (for iteration)
    bytes32[] public pontemIds;

    /// (pons, destinationChainId) → preferred pontemId for auto-routing
    mapping(address => mapping(uint64 => bytes32)) public preferredPontem;

    // ============================================================
    // Construction
    // ============================================================

    constructor(address initialOwner) Ownable(initialOwner) {}

    // ============================================================
    // Routing
    // ============================================================

    /// @inheritdoc IOmnipons
    function transire(TransitOrder calldata order)
        external payable override nonReentrant
    {
        if (block.timestamp > order.deadline) revert Omnipons_DeadlineExpired();

        // Resolve the Pontem
        bytes32 chosenId = order.pontemId;
        if (chosenId == bytes32(0)) {
            chosenId = eligePontem(
                order.pons,
                order.destinationChainId,
                order.amount,
                order.maxSigillumTier
            );
        }

        PontemRegistration memory reg = pontems[chosenId];
        if (reg.pontem == address(0) || !reg.active) {
            revert Omnipons_PontemNotRegistered();
        }
        if (uint8(reg.sigillumTier) > order.maxSigillumTier) {
            revert Omnipons_PontemNotRegistered();
        }

        // Verify the user's burn Limen on the chosen Pontem covers the amount
        uint256 limit = IPons(order.pons).burningCurrentLimitOf(reg.pontem);
        if (limit < order.amount) revert Omnipons_LimenInsufficient();

        // Pull Pons from user, then forward to Pontem.
        IERC20(order.pons).safeTransferFrom(
            msg.sender, address(this), order.amount
        );
        IERC20(order.pons).forceApprove(reg.pontem, order.amount);

        // Pontem will burn from this Omnipons' balance.
        // (Pontem's transire reads msg.sender to identify the burner;
        // the Omnipons becomes the apparent sender on the source side.
        // The destinationAddress field carries the user's intended
        // recipient through to the destination chain.)
        IPontem(reg.pontem).transire{value: msg.value}(
            uint32(order.destinationChainId),
            order.destinationAddress,
            order.amount
        );

        emit Transitus(
            msg.sender,
            order.pons,
            chosenId,
            order.destinationChainId,
            order.destinationAddress,
            order.amount
        );
    }

    /// @inheritdoc IOmnipons
    function quoteTransitus(TransitOrder calldata)
        external pure override returns (uint256 fee)
    {
        // Per-Pontem fee schedules vary by underlying transport (AggLayer is
        // gas-only, LayerZero charges fees, CCTP charges Circle fees).
        // Subclasses or off-chain quoters provide accurate quotes; this
        // base implementation returns 0 to signal "no router fee".
        return 0;
    }

    /// @inheritdoc IOmnipons
    function eligePontem(
        address pons,
        uint64 destinationChainId,
        uint256 amount,
        uint8 maxSigillumTier
    ) public view override returns (bytes32 chosenId) {
        // 1. Try preferred pontem first
        bytes32 preferred = preferredPontem[pons][destinationChainId];
        if (preferred != bytes32(0)) {
            PontemRegistration memory reg = pontems[preferred];
            if (
                reg.active &&
                uint8(reg.sigillumTier) <= maxSigillumTier &&
                IPons(pons).burningCurrentLimitOf(reg.pontem) >= amount
            ) {
                return preferred;
            }
        }

        // 2. Fall back to lowest-trust-tier Pontem with sufficient Limen
        uint8 bestTier = type(uint8).max;
        for (uint256 i = 0; i < pontemIds.length; i++) {
            PontemRegistration memory reg = pontems[pontemIds[i]];
            if (!reg.active) continue;
            if (uint8(reg.sigillumTier) > maxSigillumTier) continue;
            if (uint8(reg.sigillumTier) >= bestTier) continue;
            if (IPons(pons).burningCurrentLimitOf(reg.pontem) < amount) continue;

            bestTier = uint8(reg.sigillumTier);
            chosenId = pontemIds[i];
        }

        if (chosenId == bytes32(0)) revert Omnipons_DestinationUnreachable();
    }

    // ============================================================
    // Registration (owner / governance)
    // ============================================================

    /// @inheritdoc IOmnipons
    function registrarePontem(
        bytes32 pontemId,
        address pontem,
        SigillumTier sigillumTier
    ) external override onlyOwner {
        if (pontems[pontemId].pontem == address(0)) {
            pontemIds.push(pontemId);
        }

        pontems[pontemId] = PontemRegistration({
            pontem: pontem,
            sigillumTier: sigillumTier,
            active: true
        });

        emit PontemRegistered(pontemId, pontem, uint8(sigillumTier));
    }

    /// @inheritdoc IOmnipons
    function revocarePontem(bytes32 pontemId) external override onlyOwner {
        pontems[pontemId].active = false;
    }

    /// @notice Set the preferred Pontem for a (pons, destination) route.
    function setPreferredPontem(
        address pons,
        uint64 destinationChainId,
        bytes32 pontemId
    ) external onlyOwner {
        preferredPontem[pons][destinationChainId] = pontemId;
    }

    // ============================================================
    // View
    // ============================================================

    function pontemCount() external view returns (uint256) {
        return pontemIds.length;
    }
}
