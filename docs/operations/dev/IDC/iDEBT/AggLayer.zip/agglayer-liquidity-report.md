# AggLayer Liquidity Handling — Deep Technical Analysis

## zkEVM-Bridge, AggLayer Contracts & Bridge UI

**Repository:** [https://github.com/lair3/BDK6](https://github.com/lair3/BDK6)  
**Stack:** LAIR3-BDK6 — Layer 3 Blockchain Deployment Kit v6  
**Versions:** AggLayer v0.4.4 | Bridge Service v0.6.1 | Fork ID 12 (Banana)  
**Author:** codephreak / Professor Codephreak  
**Date:** March 30, 2026

---

## 1. Executive Summary

This report provides a comprehensive technical analysis of AggLayer liquidity handling as implemented in the LAIR3-BDK6 repository (https://github.com/lair3/BDK6). BDK6 is a Kurtosis-orchestrated blockchain deployment kit that deploys a complete Polygon CDK stack including the AggLayer v0.4.4 with pessimistic proof integration, the zkEVM bridge service v0.6.1 with unified bridge support, and a patched bridge UI enabling relative URL resolution through HAProxy reverse proxy.

The analysis covers the full liquidity lifecycle: contract deployment and role configuration on L1, bridge service synchronization and Merkle proof generation, AggLayer certificate settlement with pessimistic proof verification, and the claim transaction management subsystem. BDK6 represents a production-grade devnet environment that faithfully reproduces the AggLayer v0.3+ architecture including Local Balance Trees, Local Exit Trees, Nullifier Trees, and the SP1 zkVM / Plonky3 proving pipeline (operating in mock proof mode for development).

Key findings include a nine-role key management architecture derived from a single HD mnemonic, a dual-tree Merkle proof verification system for cross-chain asset claims, an automated ClaimTxManager that continuously monitors and settles bridge deposits, and a HAProxy-based reverse proxy that unifies L1 RPC, L2 RPC, bridge API, and bridge UI under a single HTTP endpoint.

---

## 2. System Architecture Overview

### 2.1 Deployment Stack

BDK6 orchestrates a multi-service deployment via Kurtosis Starlark scripts. The `main.star` entry point sequences six deployment phases: L1 genesis (Geth v1.17.1 + Lighthouse v8.1.3), zkEVM contract deployment (Fork ID 12 / Banana), PostgreSQL databases, CDK central environment (sequencer + prover), bridge infrastructure (AggLayer + bridge service + bridge UI), and observability stack (Prometheus + Grafana + Panoptichain).

The bridge infrastructure phase, orchestrated by `cdk_bridge_infra.star`, is the core of the liquidity handling system. It deploys three services simultaneously: the zkEVM bridge service (`hermeznetwork/zkevm-bridge-service:v0.6.1`), the AggLayer node (`ghcr.io/agglayer/agglayer-rs:v0.4.4`), and the bridge UI (`leovct/zkevm-bridge-ui:multi-network`) with its HAProxy reverse proxy.

| Component | Image | Port | Protocol |
|---|---|---|---|
| AggLayer | agglayer-rs:v0.4.4 | 4444 | HTTP JSON-RPC |
| Bridge Service | zkevm-bridge-service:v0.6.1 | 8080 / 9090 | HTTP / gRPC |
| Bridge UI | zkevm-bridge-ui:multi-network | 80 | HTTP (nginx) |
| Bridge Proxy | haproxy:3.1-bookworm | 80 | HTTP (reverse proxy) |
| PostgreSQL | postgres:17.4 | 5432 | PostgreSQL |
| cdk-erigon | cdk-erigon:v2.64.0-RC10 | 8123 / 8133 | JSON-RPC / WS |
| Prover | zkevm-prover:v8.0.0-RC16 | 50061 / 50071 | gRPC |
| Sequence Sender | zkevm-sequence-sender:v0.2.4 | N/A | Internal |

### 2.2 Starlark Orchestration Flow

The deployment follows a strict dependency chain. The `cdk_bridge_infra.run()` function first retrieves deployed contract addresses from the contracts service via the `service.get_contract_setup_addresses()` helper, which extracts eight critical addresses from `/opt/zkevm/combined.json`:

- `polygonZkEVMBridgeAddress`
- `rollupAddress`
- `polygonRollupManagerAddress`
- `deploymentRollupManagerBlockNumber`
- `polygonZkEVMGlobalExitRootAddress`
- `polygonZkEVMGlobalExitRootL2Address`
- `polTokenAddress`
- `admin`

These addresses are injected into TOML configuration templates via Kurtosis template rendering (`plan.render_templates`), producing the `bridge-config.toml`, `agglayer-config.toml`, and `.env` files that configure each service at runtime. The bridge service and AggLayer are started simultaneously via `plan.add_services()` with merged configuration dictionaries, followed by sequential startup of the bridge UI and reverse proxy.

### 2.3 Orchestration Dependency Graph

```
main.star
  ├── ethereum.star                → L1: Geth + Lighthouse
  ├── deploy_zkevm_contracts.star  → zkEVM contracts on L1
  ├── databases.star               → PostgreSQL (8 databases)
  ├── cdk_central_environment.star → Sequencer + Prover + CDK Node
  ├── cdk_bridge_infra.star        → AggLayer + Bridge Service + UI + Proxy
  │     ├── lib/service.star             → Extract contract addresses
  │     ├── lib/zkevm_agglayer.star      → AggLayer service config
  │     └── lib/zkevm_bridge.star        → Bridge + UI + Proxy configs
  ├── cdk_erigon.star              → cdk-erigon node
  ├── observability.star           → Prometheus + Grafana + Panoptichain
  └── blockscout.star              → Block explorer (optional)
```

---

## 3. Key Management and Role Architecture

BDK6 derives nine distinct roles from a single BIP-39 mnemonic using `polycli wallet inspect`. Each role has a dedicated Ethereum address and private key, enabling fine-grained access control across the bridge infrastructure.

| Role | Address (Prefix) | Liquidity Function |
|---|---|---|
| Sequencer | `0x5b06...` | Sequences L2 batches, pays POL bond (refunded on proof) |
| Aggregator | `0xCae5...` | Aggregates proofs, submits to L1 RollupManager |
| ClaimTxManager | `0x5f5d...` | Auto-claims bridge deposits on destination chain |
| Timelock | `0x130a...` | Governance delay for contract upgrades |
| Admin | `0xE34a...` | Deploys contracts, funds accounts, grants roles |
| Loadtest | `0x8145...` | Bridge workload testing (ERC20 transfers) |
| AggLayer | `0x351e...` | Submits pessimistic proofs, granted TRUSTED_AGGREGATOR_ROLE |
| DAC | `0x5951...` | Data Availability Committee member (validium mode) |
| ProofSigner | `0x7569...` | Signs proofs for AggLayer verification |

**Mnemonic (devnet only — treat as compromised):**
```
code code code code code code code code code code code quality
```

The contract deployment script (`run-contract-setup.sh`) performs critical role configuration for liquidity handling:

1. **Account Funding:** Funds all five liquidity-relevant accounts (admin, sequencer, aggregator, agglayer, claimtxmanager) with 100 ETH each from the L1 preallocated mnemonic.

2. **POL Token Approval:** The sequencer approves the rollup contract to spend its POL tokens (up to 10²⁷ wei) for batch sequencing bonds via:
   ```solidity
   approve(address,uint256)(bool) rollupAddress 1000000000000000000000000000
   ```

3. **AggLayer Role Grant:** The admin grants the AggLayer address the `TRUSTED_AGGREGATOR_ROLE` on the RollupManager contract:
   ```solidity
   grantRole(bytes32,address)
     0x084e94f375e9d647f87f5b2ceffba1e062c70f6009fdbcf80291e803b5c9edd4
     0x351e560852ee001d5D19b5912a269F849f59479a
   ```
   This allows the AggLayer to verify batches and settle proofs to L1.

---

## 4. AggLayer Liquidity Architecture

### 4.1 Pessimistic Proof System

The AggLayer v0.4.4 in BDK6 implements the pessimistic proof system — the core safety mechanism for cross-chain liquidity. The pessimistic proof cryptographically attests to two invariants:

1. **No over-withdrawal:** No chain withdraws more than it has deposited, enforced via Local Balance Tree accounting.
2. **Settled-state claims only:** A chain can only claim what has been received from a settled L1 state, enforced by verifying inclusion proofs against the L1 Info Tree.

The AggLayer configuration in BDK6 (`agglayer-config.toml`) enables pessimistic proof with `GenerateMockProof = true` for devnet operation. In production, this connects to a real SP1 zkVM prover generating Plonky3-based STARKs.

The proof system operates on **three Sparse Merkle Trees per connected chain:**

**Local Exit Tree:** Tracks all messages and token transfers originating from the chain. Each bridge deposit appends a leaf to this tree. The Local Exit Root is the root hash committed to L1.

**Local Balance Tree:** Tracks total token balances for the chain. Tokens originating from the chain itself are not tracked (unlimited withdrawal capacity as token supplier). Foreign tokens are tracked to ensure withdrawal amounts never exceed deposit amounts.

**Nullifier Tree:** Tracks all imported bridge exits that have been claimed, preventing double-claiming. Each successful claim registers a nullifier entry.

#### AggLayer Configuration (`agglayer-config.toml`)

```toml
[FullNodeRPCs]
1 = "http://cdk-erigon-node-001:8123"

[ProofSigners]
1 = "0x7569cc70950726784c8D3bB256F48e43259Cb445"

[RPC]
Host = "0.0.0.0"
Port = 4444
MaxRequestsPerIPAndSecond = 5000

[EthTxManager]
FrequencyToMonitorTxs = "1s"
WaitTxToBeMined = "2m"
GasPriceMarginFactor = 1

[L1]
ChainID = 271828
RollupManagerContract = "<from combined.json>"

[PessimisticProof]
Enabled = true
GenerateMockProof = true

[UnifiedBridge]
Enabled = true
OriginNetwork = 0
DestinationNetwork = 1

[CertificateSender]
Enabled = true
CheckInterval = "10s"
MaxRetries = 5

[State]
DBPath = "/data/agglayer-state"
```

### 4.2 Unified Bridge Contract Architecture

The Unified Bridge eliminates wrapped tokens across AggLayer-connected chains. BDK6 deploys the bridge contract via the v2 deployment pipeline (Hardhat scripts):

1. `prepareTestnet.ts` — Prepare test network state
2. `1_createGenesis.ts` — Generate L2 genesis with pre-deployed bridge contracts
3. `2_deployPolygonZKEVMDeployer.ts` — Deploy the deterministic deployer
4. `3_deployContracts.ts` — Deploy RollupManager, GlobalExitRoot, Bridge, POL token
5. `4_createRollup.ts` — Create the rollup instance and link to bridge

The bridge contract (`PolygonZkEVMBridge`) exposes two primary interfaces:

**`bridgeAsset()`** — Initiates a cross-chain asset transfer:
```solidity
bridgeAsset(
    uint32 destinationNetwork,
    address destinationAddress,
    uint256 amount,
    address token,
    bool forceUpdateGlobalExitRoot,
    bytes permitData
)
```

**`claimAsset()`** — Claims a bridged asset on the destination chain:
```solidity
claimAsset(
    bytes32[32] smtProofLocalExitRoot,
    bytes32[32] smtProofRollupExitRoot,
    uint256 globalIndex,
    bytes32 mainExitRoot,
    bytes32 rollupExitRoot,
    uint32 originNetwork,
    address originTokenAddress,
    uint32 destinationNetwork,
    address destinationAddress,
    uint256 amount,
    bytes metadata
)
```

### 4.3 Certificate Settlement Pipeline

The AggLayer configuration enables the `CertificateSender` with a 10-second check interval and 5 maximum retries. The settlement pipeline:

**Step 1 — State Collection:** The AggLayer connects to each chain's full node RPC (configured via `[FullNodeRPCs]` with network ID 1 mapping to the L2 RPC endpoint) and collects the latest Local Exit Root, balance changes, and nullifier updates.

**Step 2 — Pessimistic Proof Generation:** The AggLayer generates a pessimistic proof (mock in devnet, SP1/Plonky3 in production) attesting that the chain's withdrawal claims are backed by deposits and that no balance tree invariants are violated.

**Step 3 — L1 Settlement:** The AggLayer submits the certificate to the L1 RollupManager contract using its `TRUSTED_AGGREGATOR_ROLE`. The `EthTxManager` handles gas pricing with `GasPriceMarginFactor = 1`, a 2-minute `WaitTxToBeMined` timeout, and monitoring via 1-second `FrequencyToMonitorTxs` polling.

**Step 4 — Global Exit Root Update:** Upon successful settlement, the `GlobalExitRootManager` on L1 updates the Global Exit Root, which combines all chains' Local Exit Roots into a single Merkle tree. This makes the bridged assets claimable on destination chains.

```
Chain L2 ─── Local Exit Root ───┐
                                 ├──▶ Rollup Exit Root ──┐
Chain L2' ── Local Exit Root ───┘                        │
                                                          ├──▶ Global Exit Root (L1)
L1 (Mainnet Exit Root) ──────────────────────────────────┘
```

---

## 5. Bridge Service Deep Dive

### 5.1 Configuration Analysis

The `bridge-config.toml` reveals the service's internal architecture:

```toml
[Synchronizer]
SyncInterval = "5s"
SyncChunkSize = 100

[BridgeController]
Store = "postgres"
Height = 32    # Merkle tree height: supports 2^32 deposits

[BridgeServer]
GRPCPort = "9090"
HTTPPort = "8080"
DefaultPageLimit = 25
MaxPageLimit = 100
BridgeVersion = "v1"

[ClaimTxManager]
FrequencyToMonitorTxs = "5s"
Enabled = true
RetryInterval = "1s"
RetryNumber = 10

[BridgeController.UnifiedBridge]
Enabled = true
```

The synchronizer polls L1 and L2 every 5 seconds in chunks of 100 blocks, indexing all bridge events from the genesis block number recorded in `combined.json`. The BridgeController uses a PostgreSQL-backed store with a Merkle tree height of 32, supporting up to ~4.3 billion individual bridge deposits.

### 5.2 ClaimTxManager Subsystem

The ClaimTxManager is a critical automation component that monitors pending bridge deposits and automatically submits claim transactions on destination chains. Configuration:

| Parameter | Value | Description |
|---|---|---|
| `Enabled` | `true` | Auto-claiming active |
| `FrequencyToMonitorTxs` | `5s` | Poll interval for monitoring submitted claims |
| `RetryInterval` | `1s` | Delay between retries on failure |
| `RetryNumber` | `10` | Maximum retry attempts per claim |
| `PrivateKey.Path` | `/etc/zkevm/claimtxmanager.keystore` | Keystore for signing claims |

The ClaimTxManager uses a dedicated keystore (`claimtxmanager.keystore`) stored in `/opt/zkevm/` and extracted from the contracts service during deployment. This keystore is mounted into the bridge service container at `/etc/zkevm/claimtxmanager.keystore`.

### 5.3 Bridge API Endpoints

The bridge service HTTP API (port 8080) provides:

| Endpoint | Method | Description |
|---|---|---|
| `/bridges/{address}` | GET | Query deposits for an address (paginated) |
| `/merkle-proof` | GET | Generate dual SMT proofs for a deposit |
| `/claims/{address}` | GET | Query claim status for an address |

The `/merkle-proof` endpoint accepts `deposit_cnt` (deposit counter) and `net_id` (network ID) parameters and returns:
- `merkle_proof` — Local Exit Tree inclusion proof (32 siblings)
- `rollup_merkle_proof` — Rollup Exit Tree inclusion proof (32 siblings)
- `main_exit_root` — Current L1 Main Exit Root
- `rollup_exit_root` — Current Rollup Exit Root

### 5.4 Database Schema

| Database | User | Purpose |
|---|---|---|
| `bridge_db` | `bridge_user` | Bridge event index, Merkle trees, deposit tracking |
| `state_db` | `state_user` | L2 state storage (sequencer) |
| `prover_db` | `prover_user` | Proof generation state and batch data |
| `event_db` | `event_user` | Event synchronization tracking |
| `pool_db` | `pool_user` | Transaction pool management |
| `pool_manager_db` | `pool_manager_user` | Pool manager state (cdk-erigon) |
| `aggregator_db` | `aggregator_user` | Aggregator state and proof tracking |
| `dac_db` | `dac_user` | Data Availability Committee state |

---

## 6. Bridge UI and Reverse Proxy Architecture

### 6.1 Bridge UI Patches

BDK6 uses a custom-built bridge UI image (`leovct/zkevm-bridge-ui:multi-network`) built from the upstream `0xPolygonHermez/zkevm-bridge-ui` with two critical patches applied during Docker build:

**`env.ts.diff`** — Introduces a `VITE_RESOLVE_RELATIVE_URLS` environment variable. When enabled, the UI prepends `window.location.origin` to the L1 RPC URL, L2 RPC URL, and Bridge API URL, converting relative paths (`/l1rpc`, `/l2rpc`, `/bridgeservice`) into absolute URLs. This also relaxes Zod URL validation from `z.string().url()` to `z.string()` for these three fields.

**`deploy.sh.diff`** — Adds `RESOLVE_RELATIVE_URLS` to the deploy-time environment variable injection.

### 6.2 HAProxy Reverse Proxy

The bridge proxy (HAProxy 3.1) listens on port 80 and routes requests based on URL path prefixes:

| Path Prefix | Backend Service | Description |
|---|---|---|
| `/l1rpc` | `el-1-geth-lighthouse:8545` | L1 Ethereum JSON-RPC (Geth) |
| `/l2rpc` | `cdk-erigon-node:8123` | L2 zkEVM JSON-RPC (cdk-erigon) |
| `/bridgeservice` | `zkevm-bridge-service:8080` | Bridge REST API (deposits, proofs) |
| `/` (default) | `zkevm-bridge-ui:80` | Bridge web UI (nginx + Vite SPA) |

```
┌──────────────────────────────────────────────────────────┐
│                    HAProxy (:80)                          │
│                                                          │
│  /l1rpc  ─────────▶  Geth L1 (:8545)                    │
│  /l2rpc  ─────────▶  cdk-erigon (:8123)                 │
│  /bridgeservice ──▶  Bridge Service (:8080)              │
│  / (default) ─────▶  Bridge UI (nginx :80)               │
│                                                          │
│  Headers: Access-Control-Allow-Origin: *                 │
│           Access-Control-Allow-Methods: GET,POST,PUT,... │
└──────────────────────────────────────────────────────────┘
```

This architecture solves a critical deployment challenge: in Kurtosis enclaves, each service gets a dynamic IP address and port. By routing all traffic through a single HAProxy endpoint, the bridge UI can use relative URLs that resolve against its own origin.

### 6.3 Environment Configuration Chain

```
combined.json (contract addresses)
    │
    ▼
.env template (templates/bridge-infra/.env)
    │  Kurtosis plan.render_templates()
    ▼
.env artifact (mounted at /etc/zkevm/.env)
    │  deploy.sh: source + inject
    ▼
Vite .env (build-time SPA config)
    │
    ▼
Bridge UI SPA (browser runtime)
```

Key configuration values:
- `ETHEREUM_BRIDGE_CONTRACT_ADDRESS` — Bridge contract on L1
- `ETHEREUM_ROLLUP_MANAGER_ADDRESS` — RollupManager on L1
- `POLYGON_ZK_EVM_BRIDGE_CONTRACT_ADDRESS` — Bridge contract on L2
- `POLYGON_ZK_EVM_NETWORK_ID` — L2 network identifier (1)
- `VITE_RESOLVE_RELATIVE_URLS` — Enable relative URL resolution

---

## 7. Liquidity Flow Analysis

### 7.1 L1 → L2 Deposit Flow

The bridge workload script (`templates/workload/bridge.sh`) demonstrates the complete flow:

1. **ERC20 Deployment:** Deploy `ERC20PermitMock` on L1 using `forge create`, pre-minting 10²⁴ tokens to the admin address.

2. **Approval:** Call `approve()` on the ERC20 contract, granting the bridge contract permission to spend 100 tokens.

3. **Bridge Deposit:** Call `bridgeAsset()` on the bridge contract:
   ```
   bridgeAsset(1, adminAddr, 10, erc20Addr, true, 0x)
   ```
   - `destNet=1` (L2 network ID)
   - `amount=10` tokens
   - `forceUpdateGER=true`

4. **Exit Leaf Appendage:** The bridge contract appends an exit leaf to L1's Local Exit Tree and emits a deposit event.

5. **GER Update:** With `forceUpdateGER=true`, the bridge contract immediately updates the Global Exit Root Manager.

6. **L2 Sync:** The bridge synchronizer detects the new deposit via its 5-second polling interval and indexes it in `bridge_db`.

7. **Auto-Claim:** The ClaimTxManager detects the `ready_for_claim` deposit and automatically submits a `claimAsset()` transaction on L2.

### 7.2 L2 → L1 Withdrawal Flow

Withdrawals from L2 to L1 require additional steps for proof generation and AggLayer settlement:

1. **L2 Bridge Deposit:** Call `bridgeAsset()` on L2 with `destNet=0` (L1/Ethereum network ID).

2. **Batch Sequencing:** The sequencer includes the bridge transaction in an L2 batch, which is sequenced to L1.

3. **Proof Generation:** The prover generates a validity proof for the batch containing the withdrawal.

4. **AggLayer Settlement:** The AggLayer verifies the batch proof, generates a pessimistic proof ensuring withdrawal consistency, and submits the certificate to L1.

5. **GER Update:** The L1 Global Exit Root is updated to include the new L2 Local Exit Root.

6. **Merkle Proof Generation:** The bridge API generates dual SMT proofs via the `/merkle-proof` endpoint.

7. **L1 Claim:** The ClaimTxManager or manual claim script calls `claimAsset()` on L1 with the dual proofs, global index, exit roots, and deposit metadata.

### 7.3 Manual Claim Procedure

BDK6 includes a manual claim script (`scripts/bridge-manual-claim.sh`) that demonstrates the claim process:

```bash
# 1. Query claimable deposits
curl "$bridge_api_url/bridges/$destination_addr?limit=100&offset=0"

# 2. Filter for ready-to-claim, unclaimed deposits matching destination network
jq '[.deposits[] | select(.ready_for_claim == true and .claim_tx_hash == "" and .dest_net == 0)]'

# 3. Get Merkle proof for each deposit
curl "$bridge_api_url/merkle-proof?deposit_cnt=$cnt&net_id=$net_id"

# 4. Simulate claim
cast call $bridge_addr "claimAsset(...)" $merkle_proof $rollup_proof ...

# 5. Submit claim transaction
cast send --private-key $pk $bridge_addr "claimAsset(...)" $merkle_proof $rollup_proof ...
```

---

## 8. AggLayer-Contracts Analysis

### 8.1 Contract Deployment Pipeline

BDK6 deploys contracts using the `0xPolygonHermez/zkevm-contracts` repository (tag: `fork12`). The deployment pipeline consists of five sequential Hardhat scripts executed inside the contracts service container.

**`deploy_parameters.json`** configures:
- `pendingStateTimeout`: 604,799 seconds (~7 days)
- `trustedAggregatorTimeout`: 604,799 seconds
- `test`: `true`
- `salt`: `0x0001` (deterministic deployment)
- `forkID`: 12

**`create_rollup_parameters.json`** configures:
- `consensusContract`: `PolygonDataCommittee` (validium) or `PolygonZkEVMEtrog` (rollup)
- `chainID`: 10101
- `forkID`: 12
- `gasTokenAddress`: empty (ETH) or custom ERC20

### 8.2 Post-Deployment Configuration

After contract deployment, three critical configuration steps for the liquidity system:

1. **POL Token Approval:** The sequencer approves the rollup contract to spend 10²⁷ POL tokens for batch sequencing bonds. Without this, the sequencer cannot sequence batches and the bridge stops processing deposits.

2. **DAC Configuration (Validium only):** The Data Availability Committee is configured with `setupCommittee()` (1 required signature) and `setDataAvailabilityProtocol()` on the rollup contract.

3. **AggLayer Role Grant:** The admin grants `TRUSTED_AGGREGATOR_ROLE` to the AggLayer address on the RollupManager, allowing batch verification and proof settlement to L1.

### 8.3 Combined.json Contract Registry

The deployment produces `combined.json` — the single source of truth for all contract addresses:

```json
{
  "polygonZkEVMBridgeAddress": "0x...",
  "rollupAddress": "0x...",
  "polygonRollupManagerAddress": "0x...",
  "polygonZkEVMGlobalExitRootAddress": "0x...",
  "polygonZkEVMGlobalExitRootL2Address": "0x...",
  "polTokenAddress": "0x...",
  "admin": "0x...",
  "deploymentRollupManagerBlockNumber": N,
  "createRollupBlockNumber": N,
  "polygonDataCommitteeAddress": "0x..."
}
```

For fork IDs below 8, field name compatibility mapping is applied (e.g., `polygonRollupManager` → `polygonRollupManagerAddress`).

---

## 9. Security Analysis

### 9.1 Pessimistic Proof Security Model

The pessimistic proof system provides a critical security guarantee: the total withdrawals from any chain through the unified bridge can never exceed total deposits to that chain. This is enforced via the Local Balance Tree.

The proof treats every chain as potentially compromised, ensuring that even a fully malicious chain cannot drain funds from other chains on the shared bridge. The AggLayer does not extend security guarantees to individual chains — each chain retains its own finality mechanism. What the pessimistic proof ensures is **cross-chain security**: a security issue on any one chain cannot drain deposits made to any other chain.

In BDK6's devnet configuration, `GenerateMockProof = true` means the pessimistic proof is not actually verified by SP1 zkVM. For production deployment, this **must** be set to `false`.

### 9.2 Key Security Considerations

**Devnet Key Exposure:** All private keys in BDK6 are derived from a known mnemonic and hardcoded in `params.yml`. The mnemonic `code code code code code code code code code code code quality` must be treated as compromised.

**Single-Signature Architecture:** BDK6 uses individual EOAs for all roles. Production deployments should use multisig wallets (e.g., Safe) for admin, timelock, and aggregator roles. The `emergencyCouncilAddress` is set to the admin address — a single point of failure.

**ClaimTxManager Trust Model:** The auto-claiming system holds a private key that can submit claim transactions on behalf of any user. Claims are verified on-chain via Merkle proofs (trust-minimized), but the claiming key's availability affects liveness.

**Bridge Proxy CORS:** `Access-Control-Allow-Origin: *` allows any origin to interact with the bridge API. Should be restricted in production.

### 9.3 Proof Verification Flow

```
State Transition Proof
  └── Verifies internal chain operations (ECDSA or Validity Proof)
        │
        ▼
Aggchain Proof
  └── Verifies bridge constraints + combines internal verification
        │
        ▼
Pessimistic Proof
  └── Final verification of asset balance changes + nullifier updates
        │
        ▼
L1 Settlement (RollupManager.verifyBatches)
```

---

## 10. Data Availability Modes and Liquidity Impact

BDK6 supports two data availability modes:

**Rollup Mode** (`data_availability_mode: rollup`):
- Transaction data posted on-chain to L1
- All bridge deposit/withdrawal data fully verifiable
- Consensus contract: `PolygonZkEVMEtrog`
- Strongest DA guarantees, higher L1 gas cost

**CDK-Validium Mode** (`data_availability_mode: cdk-validium`):
- Transaction data stored off-chain by DAC
- Only data hash posted to L1
- Consensus contract: `PolygonDataCommittee`
- Lower L1 gas costs, trust assumption on DAC availability

Both modes settle through the AggLayer to L1 Ethereum and use the same unified bridge contract. The DA mode affects batch data storage only — not the bridge's Merkle proof verification or the pessimistic proof system.

---

## 11. Network Topology and Port Architecture

| Port | Service | Function | Liquidity Role |
|---|---|---|---|
| 4444 | AggLayer | JSON-RPC API | Proof settlement, certificate management |
| 8080 | Bridge Service | HTTP REST API | Deposit queries, Merkle proof generation |
| 9090 | Bridge Service | gRPC API | Internal bridge service communication |
| 8123 | cdk-erigon | L2 JSON-RPC | L2 transaction execution, state queries |
| 8133 | cdk-erigon | L2 WebSocket | Real-time L2 event streaming |
| 8545 | Geth (L1) | L1 JSON-RPC | L1 contract interaction, deposit monitoring |
| 80 | HAProxy | Reverse Proxy | Unified endpoint for UI + APIs |
| 9091 | Various | Prometheus | Metrics collection for all services |
| 5432 | PostgreSQL | Database | Bridge state, proofs, event index |

---

## 12. Recommendations for Production Deployment

1. **Disable Mock Proofs:** Set `GenerateMockProof = false` in `agglayer-config.toml` and configure a real SP1 zkVM prover endpoint.

2. **Replace Devnet Keys:** Generate fresh keys using an HSM or secure key management service. Deploy multisig wallets for admin, emergency council, and timelock roles.

3. **Restrict CORS:** Replace `Access-Control-Allow-Origin: *` with specific allowed origins in HAProxy.

4. **Enable TLS:** Add TLS termination to HAProxy or deploy behind a TLS-capable reverse proxy.

5. **Database Security:** Replace placeholder database passwords with strong, unique passwords. Enable PostgreSQL SSL connections.

6. **Monitoring:** Configure alerting on key bridge metrics: deposit queue depth, claim latency, AggLayer certificate settlement time, and EthTxManager gas usage.

7. **Gas Token Consideration:** If deploying with a custom gas token, ensure the ERC20 contract is audited. The devnet `ERC20PermitMock` is not suitable for production.

8. **Backup and Recovery:** Implement PostgreSQL backup procedures for `bridge_db`. Loss of this database requires full re-synchronization from L1.

---

## 13. Conclusion

BDK6 implements a production-faithful representation of the AggLayer v0.3+ liquidity architecture, deploying the complete stack from L1 contract deployment through AggLayer pessimistic proof settlement to end-user bridge UI interaction. The codebase demonstrates the four pillars of AggLayer liquidity handling: pessimistic proofs (via agglayer-rs v0.4.4 with mock proof generation), the unified bridge (via zkevm-bridge-service v0.6.1 with unified bridge enabled), proof aggregation (via the TRUSTED_AGGREGATOR_ROLE delegation), and the bridge UI (via patched zkevm-bridge-ui with relative URL resolution).

The Kurtosis-based orchestration provides a deterministic, reproducible deployment environment that accurately models the service dependencies, configuration injection, and networking topology of a production Polygon CDK deployment. The nine-role key architecture, dual Merkle proof verification system, automated ClaimTxManager, and HAProxy reverse proxy collectively enable a complete cross-chain liquidity lifecycle.

For the DELTAVERSE ecosystem and AgenticPlace marketplace, BDK6 provides the foundational infrastructure layer for cross-chain asset movement, enabling the BONAFIDE reputation system and BANKON AlgoIDNFT identity framework to operate across connected chains with cryptographic safety guarantees backed by the AggLayer's pessimistic proof system.

---

## Appendix A: File Reference Map

| File Path | Purpose |
|---|---|
| `main.star` | Top-level orchestration: sequences all deployment phases |
| `cdk_bridge_infra.star` | Bridge infrastructure: AggLayer + bridge service + UI + proxy |
| `lib/zkevm_agglayer.star` | AggLayer service configuration (container, ports, entrypoint) |
| `lib/zkevm_bridge.star` | Bridge service + UI + proxy service configurations |
| `lib/service.star` | Contract address extraction from combined.json |
| `deploy_zkevm_contracts.star` | L1 contract deployment orchestration |
| `templates/bridge-infra/agglayer-config.toml` | AggLayer TOML config template (pessimistic proof, settlement) |
| `templates/bridge-infra/bridge-config.toml` | Bridge service TOML config template (sync, claims, DB) |
| `templates/bridge-infra/.env` | Bridge UI environment variable template |
| `templates/bridge-infra/haproxy.cfg` | HAProxy reverse proxy routing configuration |
| `templates/contract-deploy/run-contract-setup.sh` | Contract deployment + role configuration script |
| `templates/contract-deploy/deploy_parameters.json` | Contract deployment parameters template |
| `templates/contract-deploy/create_rollup_parameters.json` | Rollup creation parameters template |
| `templates/workload/bridge.sh` | Bridge workload: ERC20 deploy + bridge + claim automation |
| `scripts/bridge-manual-claim.sh` | Manual bridge claim reference implementation |
| `docker/zkevm-bridge-ui/env.ts.diff` | UI patch: relative URL support + relaxed validation |
| `docker/zkevm-bridge-ui/deploy.sh.diff` | UI patch: RESOLVE_RELATIVE_URLS env injection |
| `docker/zkevm-contracts.Dockerfile` | Contract deployment container (Hardhat + Foundry + polycli) |
| `databases.star` | PostgreSQL configuration for all 8 databases |
| `input_parser.star` | Default parameter definitions and merge logic |
| `params.yml` | User-facing parameter file (keys, images, ports, chain IDs) |

---

*Report generated from codebase analysis of https://github.com/lair3/BDK6*  
*AggLayer documentation reference: https://docs.agglayer.dev/*  
*License: Apache 2.0 / MIT (dual licensed)*
