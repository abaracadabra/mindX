// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import {Script, console2} from "forge-std/Script.sol";

import {Pontifex} from "../src/core/Pontifex.sol";
import {Pons} from "../src/core/Pons.sol";
import {PontemAgglayer} from "../src/adapters/PontemAgglayer.sol";
import {Omnipons} from "../src/routers/Omnipons.sol";
import {IOmnipons} from "../src/interfaces/IOmnipons.sol";

/*
 * DeployPontifex
 *
 * Deploys the full Pontifex stack on a single chain:
 *   1. Pontifex (factory)
 *   2. A sample Pons (consecrarePontem)
 *   3. A Custodia for that Pons (consecrareCustodiam)
 *   4. A PontemAgglayer adapter
 *   5. An Omnipons router with the adapter registered
 *
 * For multi-chain deployment, run this script on each target chain with
 * the same DEPLOYER and the same {name, symbol} for the Pons. CREATE2
 * ensures identical addresses across chains.
 */

contract DeployPontifex is Script {

    // AggLayer Unified Bridge (same address on every connected chain)
    address constant UNIFIED_BRIDGE = 0x2a3DD3EB832aF982ec71669E178424b10Dca2EDe;

    // L1 USDC on Ethereum mainnet
    address constant L1_USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48;

    function run() external {
        uint256 deployerKey = vm.envUint("DEPLOYER_PRIVATE_KEY");
        address issuer = vm.envAddress("ISSUER_ADDRESS");
        address underlying = vm.envOr("UNDERLYING_TOKEN", L1_USDC);

        vm.startBroadcast(deployerKey);

        // 1. Deploy Pontifex
        Pontifex pontifex = new Pontifex();
        console2.log("Pontifex:", address(pontifex));

        // 2. Consecrate a Pons (caller becomes owner)
        // Switch to issuer for proper ownership
        vm.stopBroadcast();
        vm.startBroadcast(vm.envUint("ISSUER_PRIVATE_KEY"));

        address[] memory bridges = new address[](0);
        uint256[] memory mintLimits = new uint256[](0);
        uint256[] memory burnLimits = new uint256[](0);

        address ponsAddr = pontifex.consecrarePontem(
            "Pons USDC",
            "pUSDC",
            mintLimits,
            burnLimits,
            bridges
        );
        console2.log("Pons (pUSDC):", ponsAddr);

        // 3. Consecrate Custodia
        address custodia = pontifex.consecrareCustodiam(
            ponsAddr,
            underlying,
            false
        );
        console2.log("Custodia:", custodia);

        // 4. Deploy PontemAgglayer adapter
        PontemAgglayer pontemAgglayer = new PontemAgglayer(
            UNIFIED_BRIDGE,
            ponsAddr,
            issuer
        );
        console2.log("PontemAgglayer:", address(pontemAgglayer));

        // 5. Authorize the adapter on the Pons (1M daily limit)
        Pons(ponsAddr).setLimens(
            address(pontemAgglayer),
            1_000_000e6,  // mint limit (USDC has 6 decimals)
            1_000_000e6   // burn limit
        );

        // 6. Deploy Omnipons router
        Omnipons omnipons = new Omnipons(issuer);
        console2.log("Omnipons:", address(omnipons));

        // 7. Register the AggLayer adapter (highest trust tier)
        bytes32 agglayerId = keccak256("AGGLAYER_V1");
        omnipons.registrarePontem(
            agglayerId,
            address(pontemAgglayer),
            IOmnipons.SigillumTier.AGGLAYER
        );

        vm.stopBroadcast();

        console2.log("\n=== Deployment complete ===");
        console2.log("Pontifex:        ", address(pontifex));
        console2.log("Pons:            ", ponsAddr);
        console2.log("Custodia:        ", custodia);
        console2.log("PontemAgglayer:  ", address(pontemAgglayer));
        console2.log("Omnipons:        ", address(omnipons));
    }
}
