# Latin Naming Reference

Pontifex uses Latin component names because cypherpunk software does not need corporate branding. The bridge metaphor comes from Roman engineering, so its components do too.

## Core nouns

| Latin | English | In Pontifex |
|-------|---------|-------------|
| **pons** (m., gen. *pontis*) | bridge | The xERC20 token itself. The Pons IS the bridge between chain representations. |
| **pontifex** (m.) | bridge-builder | The factory contract that deploys Pons + Custodia pairs. The Roman *pontifex* was the office responsible for building and maintaining bridges over the Tiber. |
| **custodia** (f.) | custody, guard, lockbox | The 1:1 wrapper between a canonical token and its Pons. |
| **omnipons** (compound) | all-bridge | The multi-bridge router. Selects the optimal Pontem for a given destination. |
| **pontem** (m., acc.) | (the) bridge (object form) | Concrete bridge adapters. *PontemAgglayer*, *PontemCCTP*, *PontemLayerZero*. The accusative case is used because adapters are bridges *that the user crosses* — the object of the action. |
| **limen** (n.) | threshold, doorway | Per-bridge rate limit. A threshold beyond which the bridge cannot mint or burn within a 24h window. |
| **sigillum** (n.) | seal | Trust tier classification. The *sigillum* on a document indicated its source authority; in Pontifex it indicates the trust authority of a bridge. |

## Verb forms (used as function and event names)

| Latin | English | In Pontifex |
|-------|---------|-------------|
| **iungere** | to join, to link | Custodia deposit event. The user *joins* their canonical token to the bridge by depositing it in the Custodia. |
| **solvere** | to release, to unbind | Custodia withdraw event. The Custodia *releases* the canonical token back to the user. |
| **transire** | to cross, to pass over | The user-facing cross-chain transfer function. *transire(destination, amount)*. |
| **transitus** | a crossing, a transit | Event emitted on the source chain when transire is called. |
| **adventus** | an arrival, a coming | Event emitted on the destination chain when the message is claimed. |
| **consecrare** | to consecrate, to dedicate | Factory deployment functions: *consecrarePontem* (deploy a Pons), *consecrareCustodiam* (deploy a Custodia). The Roman *consecratio* was the dedication of a structure to a deity; here, of a contract to its purpose. |
| **eligere** | to choose, to select | Router selection function. *eligePontem* picks the optimal bridge for a route. |
| **registrare** | to register, to enroll | Governance action to add a bridge to the Omnipons whitelist. |
| **revocare** | to revoke, to recall | Governance action to disable a bridge in the Omnipons. |
| **predicare** | to predict, to declare | View function for CREATE2 address prediction. *predicarePons*, *predicareCustodiam*. |

## Why Latin

1. **Stable across centuries.** A function called `mint` or `bridge` carries connotations from current English usage that may shift. *Iungere* has meant "to join" for two thousand years and will continue to.

2. **Compositional.** Latin's productive prefix system (*omni-*, *per-*, *trans-*, *re-*) lets us coin precise compounds: *omnipons* (all-bridge), *transitus* (crossing), *revocare* (call-back, hence revoke).

3. **Distinct from existing namespaces.** No collision with OpenZeppelin, ERC standards, or chain-specific terminology. A `Pons` is unambiguous; a `Bridge` collides with hundreds of existing contracts.

4. **Cypherpunk aesthetic.** The cypherpunk tradition uses precise, terse, technical language. Latin names are precise (one meaning each), terse (most are one word), and technical (they require translation to read, which filters for engaged audiences).

5. **The bridge metaphor is Roman.** When we call something a "bridge contract" we are unconsciously invoking 2500 years of Roman engineering. Making this explicit honors the lineage.

## Pronunciation guide (classical Latin)

For when you discuss this codebase out loud:

- **pons** = "ponss" (rhymes with "donce")
- **pontifex** = "PON-ti-feks"
- **custodia** = "kuhs-TOH-di-ah"
- **omnipons** = "OM-ni-ponss"
- **pontem** = "PON-tem"
- **limen** = "LEE-men" (long *i*; not "LIE-men")
- **sigillum** = "si-GIL-lum"
- **iungere** = "YOON-geh-reh" (the *i* is consonantal, like English *y*)
- **transire** = "trahn-SEE-reh"
- **consecrare** = "kon-seh-KRAH-reh"
- **eligere** = "eh-LEE-geh-reh"

## Anti-patterns we avoid

- **No bird names**, no animals, no Greek gods, no celestial bodies. These are overused in current crypto naming and carry unwanted associations.
- **No corporate-sounding compounds** ("CrossChainFlexBridgePro"). Latin compounds are functional, not marketing.
- **No abbreviations within Latin terms.** *Pons* is already one syllable; abbreviating it serves nothing.
- **No mixing.** A function is either Latin (*transire*) or English (*transfer*), not "transireTo" or "doTransire". Where English is required for ERC-20 conformance (*mint*, *burn*, *balanceOf*), it is preserved verbatim.

## Reading the code

When you see *consecrarePontem* in the Pontifex factory, read it as "consecrates a bridge". When you see *eligePontem* in the Omnipons router, read it as "chooses a bridge". When you see *transire* in the PontemAgglayer adapter, read it as "to cross". The grammatical case of *Pontem* (accusative) signals that it is the object of an action — something done *to* the bridge, not the bridge itself acting.

The Pons (nominative) is what the user holds. The Pontem (accusative) is the path they take. The Pontifex (nominative agent) builds the bridges. The Limen (neuter) is what they cannot exceed.

This is grammar as type system.
