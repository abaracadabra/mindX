# Pontifex Design Rationale

Why xERC20 + AggLayer composition is the correct cross-chain strategy for openBDK, and why this repository exists.

## The two-layer thesis

openBDK has two distinct cross-chain problems, not one:

1. **Within the AggLayer ecosystem** (openBDK ↔ Polygon zkEVM ↔ X Layer ↔ Astar zKyoto ↔ ...): the Unified Bridge with pessimistic proofs is the optimal solution. It is zero-trust, has no validator committee, and has secured real value with zero exploits since 2023.

2. **Outside the AggLayer ecosystem** (openBDK ↔ Algorand ↔ Solana ↔ Cosmos ↔ Bitcoin): the Unified Bridge does not reach. Some other bridging mechanism is required, and every available mechanism — LayerZero, Wormhole, Axelar, CCTP, Hyperlane — has a different trust model with different failure modes.

A single bridging strategy cannot serve both problems. Pontifex is the compositional answer: use the AggLayer where it reaches; use xERC20 sovereignty + per-bridge rate limits everywhere else.

## Why xERC20 specifically

The xERC20 standard (EIP-7281) emerged from a concrete observation: traditional bridged tokens have three problems that fragment liquidity and concentrate risk.

### Problem 1: Bridge-controlled token contracts

When a user bridges USDC through Bridge A from Ethereum to Polygon, Bridge A deploys "USDC.Bridge_A" on Polygon. When another user bridges through Bridge B, they get "USDC.Bridge_B". These are different contracts. They are not fungible. A user holding USDC.Bridge_A cannot easily swap with a user holding USDC.Bridge_B without going through an AMM that has bootstrapped liquidity for both.

The token issuer (Circle, in this example) does not control these bridge-deployed tokens. They cannot enforce blacklist policies. They cannot upgrade the contract. They cannot revoke a bridge that turns malicious.

### Problem 2: Concentrated honeypots

Every bridge that uses lock-and-mint creates a per-chain escrow contract holding the locked tokens. These escrows accumulate value. Ronin's escrow held $624M when it was drained. Wormhole's held $320M. Each escrow is a single point of failure.

### Problem 3: No granular security controls

When a token issuer integrates a bridge, they have only two choices: trust the bridge fully, or do not integrate. There is no "trust this bridge for $1M/day but not more". A bridge bug or compromise can drain the entire token supply.

### How xERC20 solves all three

xERC20 inverts the relationship. The token issuer deploys and controls the token contract on every chain. Bridges are revocable whitelist entries — the issuer calls `setLimens(bridge, mintingLimit, burningLimit)` to authorize a bridge with specific daily caps.

Result:

- **One canonical token per chain**, controlled by the issuer
- **No per-bridge wrapped versions** — perfect fungibility
- **No escrow honeypots** — burn/mint instead of lock/mint
- **Per-bridge rate limits** — a bridge bug caps damage at the daily Limen
- **Revocable bridges** — `setLimens(bridge, 0, 0)` instantly disables a compromised bridge
- **Multi-bridge support without fragmentation** — same token can be minted by AggLayer, CCTP, LayerZero simultaneously

## How Pontifex composes xERC20 with the AggLayer

The Pons (xERC20) sits on top of the AggLayer Unified Bridge. The composition flow:

```
User holds canonical USDC on Ethereum
           |
           v
[Custodia.deposit(amount)]
           |
           v
User holds Pons (pUSDC) on Ethereum, 1:1 backed
           |
           v
[Omnipons.transire(destinationChainId=openBDK)]
           |
           v
Omnipons selects PontemAgglayer (highest trust tier)
           |
           v
[PontemAgglayer.transire(...)]
           |
           v
Pons.burn(user, amount)  on Ethereum    [consumes burn Limen]
           |
           v
AggLayer Unified Bridge.bridgeMessage(...)
           |
           v
AggLayer pessimistic proof commits to Ethereum L1
           |
           v
PontemAgglayer.onMessageReceived(...) on openBDK
           |
           v
Pons.mint(user, amount)  on openBDK     [consumes mint Limen]
           |
           v
User holds Pons (pUSDC) on openBDK
```

The user can either keep the Pons on openBDK (uses it directly in DeFi) or call `Custodia.withdraw()` on openBDK to receive canonical USDC there (if a Custodia exists for that chain).

## The defense-in-depth property

Two completely independent security mechanisms protect every transit:

**Layer 1: AggLayer pessimistic proof.** Cryptographically guarantees that the cross-chain message is authentic and that no chain can withdraw more than it deposited from the unified bridge. An attacker cannot forge a message claiming "mint 1B Pons on openBDK" because the message would not pass pessimistic proof verification.

**Layer 2: Pons Limen.** Even if Layer 1 ever fails (a soundness bug in SP1, Plonky3, or the pessimistic proof logic), the PontemAgglayer adapter still has a daily mint Limen. If the issuer set this to $10M, a successful attack on Layer 1 results in at most $10M of fake mints before the issuer can `setLimens(pontem, 0, 0)` to revoke.

This is architecturally what every bridge that has been exploited lacked. Ronin had no Layer 2: a 5-of-9 multisig compromise drained $624M because there was no bound on how much could be withdrawn.

## When to use which Pontem

The Sigillum trust tiers are intentionally exposed to the user:

- **AGGLAYER (tier 0)**: Use for openBDK ↔ any AggLayer-connected chain. No external trust assumptions beyond Ethereum L1 finality. Settlement time: ~30-60 minutes for ZK-verified pessimistic proofs.

- **CCTP (tier 1)**: Use for USDC specifically, when bridging to Solana, Avalanche, Arbitrum, or other CCTP-supported chains. Trust assumption: Circle's attestation service. Settlement time: ~15-20 minutes.

- **XERC20_LIMITED (tier 2)**: Use xERC20 over LayerZero / Hyperlane with conservative Limens for chains that do not support AggLayer or CCTP. Trust assumption: the underlying messaging protocol's validators, BUT bounded by the daily Limen.

- **EXTERNAL_VALIDATOR (tier 3)**: Use only when no higher-trust option exists (e.g., openBDK ↔ Algorand). Trust assumption: the bridge's external validator set. Bounded by daily Limen, but the user should choose conservative Limens because the trust assumption is weakest.

A user who only ever transacts within the AggLayer ecosystem can set `maxSigillumTier = 0` permanently and never touch a tier-2 or tier-3 bridge. A user bridging to Algorand has to accept tier 3 — but the Limen still caps their downside at one day's worth of compromised liquidity.

## Cost analysis

| Approach | Setup cost per chain | Marginal cost per new bridge |
|----------|---------------------|------------------------------|
| Custom L1Escrow + L2MinterBurner per chain (no xERC20) | $50K-$200K (deploy + audit) | Same again for each new chain |
| Pontifex (xERC20 + Custodia + adapters) | One audit covers all xERC20 deployments | ~$50 gas (`setLimens(newBridge, ...)`) |

For an openBDK ecosystem with 10 connected chains and 5 bridge providers, the difference is roughly:

- Without Pontifex: 50 deployments × $100K average = **$5M**
- With Pontifex: 1 audit + 10 chain deployments + 50 `setLimens` calls = **~$200K**

Liquidity bootstrapping savings are even larger: traditional bridged tokens require ~$1M+ in AMM liquidity per token-chain pair. xERC20 burn/mint requires zero bootstrap liquidity. For 10 chains: $9M+ in liquidity capital not required.

## What this repository does NOT replace

Pontifex is **additive** to the existing openBDK contracts:

- The `OpenBDKL1Escrow` + `OpenBDKL2MinterBurner` + `OpenBDKNativeConverter` trio (canonical Polygon pattern) remains the recommended primary path for AggLayer-bridged USDC. It is the most battle-tested option.
- `OpenBDKValidatorRegistry` (1+3 Relayer-Validator) is unaffected.
- The AggLayer Unified Bridge itself is unchanged.

Pontifex extends openBDK with the **sovereignty layer** for tokens that need cross-bridge optionality and rate-limit protection beyond what a single canonical bridge provides.

## When to deploy a Pons vs. use the canonical L1Escrow path

Use the canonical `OpenBDKL1Escrow` pattern when:
- You only need bridging within the AggLayer ecosystem
- You want maximum simplicity (one bridge, one path)
- The token is USDC (Circle has invested in the canonical pattern)

Deploy a Pons when:
- You need to bridge to non-AggLayer chains (Algorand, Solana, Cosmos)
- You want multi-bridge optionality (CCTP + AggLayer + LayerZero)
- You are issuing a new token and want sovereignty from day one
- You need per-bridge rate limits as a circuit breaker

Both patterns can coexist on the same chain. A user can hold both `USDC.b` (canonical, via L1Escrow) and `pUSDC` (sovereign, via Pons + Custodia) and use whichever serves their immediate routing need.

## References

- EIP-7281: <https://eips.ethereum.org/EIPS/eip-7281>
- xERC20 reference: <https://github.com/defi-wonderland/xERC20>
- xERC20 ecosystem: <https://github.com/rhlsthrm/awesome-xerc20>
- AggLayer: <https://github.com/agglayer>
- BuildOnPolygon canonical contracts: <https://github.com/BuildOnPolygon/usdc-lxly>

---

*The bridge is not a contract. The bridge is a token whose existence on multiple chains constitutes the route between them. Bridges (Pontem implementations) are merely the messengers. The Pons is the bridge.*
