// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
 * Omnipons — the all-bridge.
 *
 * The Omnipons is a router that aggregates multiple Pontem (bridge)
 * implementations behind a single transire() interface. Conceptual
 * heritage: the multi-stage routing pattern from THRUSTDeltaV
 * (handshake → warpdrive → equilibrium → afterburner), reimplemented
 * with xERC20 trust-minimized burn/mint instead of external validator
 * messaging.
 *
 * The Omnipons selects the optimal Pontem for each route based on:
 *   - Destination chain reachability
 *   - Available mint/burn limit on destination
 *   - Cost (gas + bridge fee)
 *   - User-specified trust tier (Sigillum class)
 */

interface IOmnipons {

    // ============================================================
    // Errors
    // ============================================================

    error Omnipons_PontemNotRegistered();
    error Omnipons_DestinationUnreachable();
    error Omnipons_LimenInsufficient();
    error Omnipons_DeadlineExpired();

    // ============================================================
    // Events
    // ============================================================

    /// Emitted when a new Pontem (bridge adapter) is registered.
    event PontemRegistered(
        bytes32 indexed pontemId,
        address pontem,
        uint8   sigillumTier
    );

    /// Emitted on every cross-chain transit.
    event Transitus(
        address indexed sender,
        address indexed pons,
        bytes32 indexed pontemId,
        uint64  destinationChainId,
        address destinationAddress,
        uint256 amount
    );

    // ============================================================
    // Types
    // ============================================================

    /// Trust tier for a Pontem implementation.
    /// AGGLAYER (highest)  — pessimistic-proof secured (zero-trust)
    /// CCTP                — Circle attestation (issuer-trusted)
    /// XERC20_LIMITED      — xERC20 with conservative rate limits
    /// EXTERNAL_VALIDATOR  — LayerZero / Wormhole / Axelar (lowest)
    enum SigillumTier { AGGLAYER, CCTP, XERC20_LIMITED, EXTERNAL_VALIDATOR }

    /// A registered bridge adapter.
    struct PontemRegistration {
        address      pontem;          // adapter contract address
        SigillumTier sigillumTier;    // trust tier
        bool         active;          // can be revoked without un-registering
    }

    /// Parameters for a cross-chain transit.
    struct TransitOrder {
        address pons;                 // Pons (xERC20) to transit
        uint256 amount;
        uint64  destinationChainId;
        address destinationAddress;
        bytes32 pontemId;             // chosen Pontem (or zero for auto-route)
        uint8   maxSigillumTier;      // user's trust tier ceiling
        uint256 deadline;             // tx deadline (revert past this)
        bytes   pontemData;           // adapter-specific payload
    }

    // ============================================================
    // Routing
    // ============================================================

    /// @notice Execute a cross-chain transit through the optimal Pontem.
    function transire(TransitOrder calldata order) external payable;

    /// @notice Quote the gas + bridge fee for a transit.
    function quoteTransitus(TransitOrder calldata order)
        external view returns (uint256 fee);

    /// @notice Auto-select the optimal Pontem for a destination.
    function eligePontem(
        address pons,
        uint64  destinationChainId,
        uint256 amount,
        uint8   maxSigillumTier
    ) external view returns (bytes32 pontemId);

    // ============================================================
    // Registration (governance)
    // ============================================================

    function registrarePontem(
        bytes32 pontemId,
        address pontem,
        SigillumTier sigillumTier
    ) external;

    function revocarePontem(bytes32 pontemId) external;
}
