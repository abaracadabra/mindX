// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";
import {Create2} from "@openzeppelin/contracts/utils/Create2.sol";

import {IPontifex} from "../interfaces/IPontifex.sol";
import {IPons} from "../interfaces/IPons.sol";
import {Pons} from "./Pons.sol";
import {Custodia} from "./Custodia.sol";

/*
 * Pontifex — the bridge-builder.
 *
 * The factory contract that deploys Pons + Custodia pairs deterministically
 * via CREATE2. The same {name, symbol, deployer} tuple produces the same
 * address on every chain — so a Pons named "USDC.b" deployed by the openBDK
 * Pontifex has the same address on Ethereum, Polygon, openBDK, and any
 * other chain where this Pontifex is itself deployed at the same address.
 *
 * Address determinism is the cypherpunk requirement: a token's identity
 * should not depend on which chain you ask. CREATE2 + a constant init code
 * delivers this without any cross-chain coordination.
 *
 * To achieve identical Pontifex addresses across chains, deploy this
 * contract via a known deterministic deployer such as the Arachnid
 * 0xkeyless deployer (0x4e59b44847b379578588920cA78FbF26c0B4956C),
 * which exists at the same address on every EVM chain.
 */

contract Pontifex is IPontifex {

    // ============================================================
    // Implementation references
    // ============================================================

    /// @inheritdoc IPontifex
    address public immutable override ponsImplementation;

    /// @inheritdoc IPontifex
    address public immutable override custodiaImplementation;

    // ============================================================
    // Bookkeeping (per chain)
    // ============================================================

    /// pons → custodia (zero if no Custodia deployed yet for this Pons)
    mapping(address => address) public custodiaOf;

    // ============================================================
    // Construction
    // ============================================================

    constructor() {
        ponsImplementation = address(new Pons());
        // Custodia is non-upgradeable; implementation is unused but logged
        custodiaImplementation = address(0);
    }

    // ============================================================
    // Deployment
    // ============================================================

    /// @inheritdoc IPontifex
    function consecrarePontem(
        string memory name,
        string memory symbol,
        uint256[] memory mintingLimits,
        uint256[] memory burningLimits,
        address[] memory pontems
    ) external override returns (address pons) {
        if (mintingLimits.length != burningLimits.length) {
            revert Pontifex_LimensMismatch();
        }
        if (mintingLimits.length != pontems.length) {
            revert Pontifex_PontemsMismatch();
        }

        // CREATE2 salt: deterministic per (name, symbol, deployer)
        bytes32 salt = keccak256(abi.encodePacked(name, symbol, msg.sender));

        bytes memory initCode = abi.encodePacked(
            type(ERC1967Proxy).creationCode,
            abi.encode(
                ponsImplementation,
                abi.encodeCall(
                    Pons.initialize,
                    (name, symbol, address(this))
                )
            )
        );

        pons = Create2.deploy(0, salt, initCode);

        // Configure initial Pontem allowlist
        for (uint256 i = 0; i < pontems.length; i++) {
            IPons(pons).setLimens(pontems[i], mintingLimits[i], burningLimits[i]);
        }

        // Transfer ownership of the Pons to the actual deployer (token issuer)
        // The Pontifex retains the ability to set the Custodia address via setCustodia
        // because we set the pontifex field in initialize, but ownership goes to msg.sender.
        Pons(pons).transferOwnership(msg.sender);

        emit PonsConsecratus(pons, name, symbol);
    }

    /// @inheritdoc IPontifex
    function consecrareCustodiam(
        address pons,
        address underlying,
        bool isNative
    ) external override returns (address custodia) {
        if (custodiaOf[pons] != address(0)) {
            revert Pontifex_CustodiaAlreadyExists();
        }

        bytes32 salt = keccak256(abi.encodePacked(pons, underlying, isNative));
        bytes memory initCode = abi.encodePacked(
            type(Custodia).creationCode,
            abi.encode(pons, underlying, isNative)
        );

        custodia = Create2.deploy(0, salt, initCode);
        custodiaOf[pons] = custodia;

        // Wire the Custodia into the Pons (bypasses rate limits)
        IPons(pons).setCustodia(custodia);

        emit CustodiaConsecrata(custodia, pons, underlying, isNative);
    }

    // ============================================================
    // Address prediction
    // ============================================================

    /// @notice Predict the Pons address for a given (name, symbol, deployer).
    function predicarePons(
        string memory name,
        string memory symbol,
        address deployer
    ) external view returns (address) {
        bytes32 salt = keccak256(abi.encodePacked(name, symbol, deployer));
        bytes memory initCode = abi.encodePacked(
            type(ERC1967Proxy).creationCode,
            abi.encode(
                ponsImplementation,
                abi.encodeCall(
                    Pons.initialize,
                    (name, symbol, address(this))
                )
            )
        );
        return Create2.computeAddress(salt, keccak256(initCode));
    }

    /// @notice Predict the Custodia address for a Pons.
    function predicareCustodiam(
        address pons,
        address underlying,
        bool isNative
    ) external view returns (address) {
        bytes32 salt = keccak256(abi.encodePacked(pons, underlying, isNative));
        bytes memory initCode = abi.encodePacked(
            type(Custodia).creationCode,
            abi.encode(pons, underlying, isNative)
        );
        return Create2.computeAddress(salt, keccak256(initCode));
    }
}
