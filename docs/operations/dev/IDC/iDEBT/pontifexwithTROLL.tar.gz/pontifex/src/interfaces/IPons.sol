// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
 * Pons — the bridge.
 *
 * The Pons IS the bridge. It is not a bridge contract; it is the token
 * contract whose existence on multiple chains constitutes the bridge.
 * Bridges (Pontem implementations) are merely the messengers that mint
 * and burn the Pons — the Pons itself is the canonical, sovereign,
 * issuer-controlled cross-chain token.
 *
 * Standard reference: EIP-7281 (xERC20)
 * Original implementation: defi-wonderland/xERC20
 *
 * Adapted for cypherpunk publication. Latin naming preserves the original
 * EIP-7281 semantics; the underlying mint/burn/limit logic is unchanged
 * from the audited reference implementation.
 */

interface IPons {

    // ============================================================
    // Errors
    // ============================================================

    /// Bridge attempted to mint or burn beyond its current limit.
    error Pons_LimenExceeded();

    /// Caller is not the recognized Pontifex (factory).
    error Pons_NotPontifex();

    /// Zero-value mint or burn rejected.
    error Pons_ZeroValue();

    // ============================================================
    // Events
    // ============================================================

    /// Emitted when the Custodia (lockbox) address is set by the Pontifex.
    event CustodiaSet(address indexed custodia);

    /// Emitted when a Pontem (bridge) has its mint/burn limits configured.
    /// @param mintingLimit  New maximum daily minting limit
    /// @param burningLimit  New maximum daily burning limit
    /// @param pontem        The bridge address being configured
    event PontemLimenSet(
        uint256 mintingLimit,
        uint256 burningLimit,
        address indexed pontem
    );

    // ============================================================
    // Types
    // ============================================================

    /// Per-bridge configuration: minter and burner parameters.
    struct Pontem {
        Limen minterLimen;
        Limen burnerLimen;
    }

    /// Rate-limit state for a single direction (mint or burn).
    /// @dev Limen replenishes linearly at ratePerSecond toward maxLimit
    ///      over a fixed _DURATION (typically 1 day).
    struct Limen {
        uint256 timestamp;       // last update
        uint256 ratePerSecond;   // replenishment rate
        uint256 maxLimit;        // maximum in any 24h window
        uint256 currentLimit;    // remaining capacity right now
    }

    // ============================================================
    // Token operations (called by Pontem implementations)
    // ============================================================

    /**
     * @notice Mint Pons to a recipient. Decrements the caller's mint Limen.
     * @dev    Caller is the Pontem (bridge) that received the cross-chain
     *         message. The Custodia bypasses limits (1:1 wrapper).
     * @param  to     Recipient address
     * @param  amount Amount to mint
     */
    function mint(address to, uint256 amount) external;

    /**
     * @notice Burn Pons from an account. Decrements the caller's burn Limen.
     * @dev    Caller is the Pontem (bridge). If caller != account,
     *         standard ERC-20 allowance is consumed.
     * @param  from   Account to burn from
     * @param  amount Amount to burn
     */
    function burn(address from, uint256 amount) external;

    // ============================================================
    // Configuration (called by the Pontifex / token issuer)
    // ============================================================

    /**
     * @notice Set the Custodia (lockbox) address. One per chain, immutable
     *         once set in production deployments.
     * @dev    Only callable by the Pontifex (factory).
     */
    function setCustodia(address custodia) external;

    /**
     * @notice Configure a Pontem's mint and burn rate limits.
     * @dev    Only callable by the token issuer (owner). Setting a limit to 0
     *         effectively revokes the bridge.
     * @param  pontem        Bridge address
     * @param  mintingLimit  New 24h minting cap
     * @param  burningLimit  New 24h burning cap
     */
    function setLimens(
        address pontem,
        uint256 mintingLimit,
        uint256 burningLimit
    ) external;

    // ============================================================
    // View functions
    // ============================================================

    /// @notice Maximum 24h mint limit for a Pontem.
    function mintingMaxLimitOf(address pontem) external view returns (uint256);

    /// @notice Maximum 24h burn limit for a Pontem.
    function burningMaxLimitOf(address pontem) external view returns (uint256);

    /// @notice Current remaining mint capacity (replenished over time).
    function mintingCurrentLimitOf(address pontem) external view returns (uint256);

    /// @notice Current remaining burn capacity (replenished over time).
    function burningCurrentLimitOf(address pontem) external view returns (uint256);

    /// @notice Custodia (lockbox) address for this Pons. address(0) if none.
    function custodia() external view returns (address);
}
