// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from
    "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

import {ICustodia} from "../interfaces/ICustodia.sol";
import {IPons} from "../interfaces/IPons.sol";

/*
 * Custodia — the custody.
 *
 * Immutable 1:1 wrapper between an existing canonical token and a Pons.
 * Modeled on defi-wonderland/xERC20 XERC20Lockbox with two semantic
 * additions:
 *   - Latin event names (Iungere = "to join the bridge", Solvere = "to release")
 *   - Reentrancy guard on all state-mutating paths
 *
 * The Custodia bypasses Pons rate limits because the 1:1 invariant is
 * structural: every Pons minted by the Custodia is backed by a locked
 * underlying token. There is no scenario in which the Custodia can mint
 * Pons exceeding the underlying it holds.
 */

contract Custodia is ICustodia, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // ============================================================
    // Immutable storage
    // ============================================================

    /// @inheritdoc ICustodia
    address public immutable override pons;

    /// @inheritdoc ICustodia
    address public immutable override underlying;

    /// @inheritdoc ICustodia
    bool public immutable override isNative;

    // ============================================================
    // Construction
    // ============================================================

    /**
     * @param  pons_       The Pons (xERC20) this Custodia wraps into
     * @param  underlying_ Underlying ERC-20 (any address if isNative=true)
     * @param  isNative_   True if wrapping native ETH; false for ERC-20
     */
    constructor(address pons_, address underlying_, bool isNative_) {
        pons = pons_;
        underlying = underlying_;
        isNative = isNative_;
    }

    // ============================================================
    // Native deposits
    // ============================================================

    receive() external payable {
        depositNative();
    }

    /// @inheritdoc ICustodia
    function depositNative() public payable override nonReentrant {
        if (!isNative) revert Custodia_NotNative();
        _deposit(msg.sender, msg.value);
    }

    /// @inheritdoc ICustodia
    function depositNativeTo(address to) public payable override nonReentrant {
        if (!isNative) revert Custodia_NotNative();
        _deposit(to, msg.value);
    }

    // ============================================================
    // ERC-20 deposits
    // ============================================================

    /// @inheritdoc ICustodia
    function deposit(uint256 amount) external override nonReentrant {
        if (isNative) revert Custodia_Native();
        IERC20(underlying).safeTransferFrom(msg.sender, address(this), amount);
        _deposit(msg.sender, amount);
    }

    /// @inheritdoc ICustodia
    function depositTo(address to, uint256 amount)
        external override nonReentrant
    {
        if (isNative) revert Custodia_Native();
        IERC20(underlying).safeTransferFrom(msg.sender, address(this), amount);
        _deposit(to, amount);
    }

    // ============================================================
    // Withdrawals
    // ============================================================

    /// @inheritdoc ICustodia
    function withdraw(uint256 amount) external override nonReentrant {
        _withdraw(msg.sender, amount);
    }

    /// @inheritdoc ICustodia
    function withdrawTo(address to, uint256 amount)
        external override nonReentrant
    {
        _withdraw(to, amount);
    }

    // ============================================================
    // Internal
    // ============================================================

    function _deposit(address to, uint256 amount) internal {
        IPons(pons).mint(to, amount);
        emit Iungere(to, amount);
    }

    function _withdraw(address to, uint256 amount) internal {
        // Burn from msg.sender; relies on standard ERC-20 allowance flow
        // when called via withdrawTo by an approved third party.
        IPons(pons).burn(msg.sender, amount);

        if (isNative) {
            (bool ok, ) = payable(to).call{value: amount}("");
            if (!ok) revert Custodia_NativeTransferFailed();
        } else {
            IERC20(underlying).safeTransfer(to, amount);
        }

        emit Solvere(to, amount);
    }
}
