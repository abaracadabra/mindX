// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
 * Troll — the toll-collector under the bridge.
 *
 * Mythological naming because the bridge-troll is the canonical figure
 * for "small fee for safe passage". Operations use Latin:
 *
 *   AURUM            golden ratio constant (φ × 10^18)
 *   portorium        a toll, customs duty (the fee itself)
 *   aerarium         the treasury that receives tolls
 *   exigere          to exact, to collect (the action)
 *   quaerere         to query, to ask the price (the view function)
 *
 * Default toll formula:
 *
 *   toll = φ × 10^(floor(log10(baseCost)) - 1)
 *
 * This positions the golden-ratio digit sequence one decimal place below
 * the leading significant digit of the base cost. For a baseCost of
 * 0.000046 ETH, the toll is 0.000001618033988749894848 ETH — about 3.5%
 * of the base cost, low enough that undercutting is not economically
 * viable but visible enough that bridge maintenance funds accumulate.
 *
 * Variable rate:
 *   The owner can override the default formula by setting customRate to a
 *   non-zero value. Custom rate is interpreted as: toll = baseCost × customRate / 1e18.
 *   Setting customRate back to 0 restores the default golden-ratio formula.
 *
 * The toll applies to the TRANSACTION FEE (gas, bridge fee, msg.value being
 * forwarded to the underlying bridge), NOT to the value being bridged. A
 * percentage of bridged value would be confiscatory; a percentage of the
 * transaction cost is nominal.
 */

interface ITroll {

    // ============================================================
    // Errors
    // ============================================================

    error Troll_AerariumZero();
    error Troll_NativeTransferFailed();
    error Troll_RateExceedsMaximum();

    // ============================================================
    // Events
    // ============================================================

    /// A toll was collected.
    /// @param payer    Account that paid (msg.sender to exigere)
    /// @param baseCost The baseCost the toll was computed against
    /// @param portorium The toll amount actually paid to the aerarium
    event Portorium(
        address indexed payer,
        uint256 baseCost,
        uint256 portorium
    );

    /// The aerarium (treasury address) was updated.
    event AerariumSet(address indexed previous, address indexed current);

    /// The custom rate was updated. rate=0 means default golden-ratio formula.
    event RateSet(uint256 previous, uint256 current);

    // ============================================================
    // Quoting
    // ============================================================

    /**
     * @notice Quote the toll for a given base cost.
     * @dev    Pure view; does not mutate state. Use this to compute the
     *         msg.value to send with a transire() call.
     * @param  baseCost The transaction fee or bridge fee in wei
     * @return toll     The toll amount in wei
     */
    function quaerere(uint256 baseCost) external view returns (uint256 toll);

    /**
     * @notice Quote tolls for an entire multi-hop route.
     * @dev    Each chain in a multi-hop route applies the toll formula to
     *         its own native gas cost; tolls are paid on each chain in
     *         that chain's gas token. This helper batches the calculation
     *         for off-chain quoters.
     * @param  baseCosts Per-hop bridge fees, each in its chain's native wei
     * @return tolls     Per-hop toll values, parallel to baseCosts
     */
    function quaerereRoute(uint256[] calldata baseCosts)
        external view returns (uint256[] memory tolls);

    // ============================================================
    // Collection
    // ============================================================

    /**
     * @notice Collect a toll for a transaction with the given base cost.
     * @dev    msg.value MUST equal exactly quaerere(baseCost). Forwards the
     *         toll to the aerarium and emits Portorium.
     * @param  baseCost The base cost the toll was computed against
     */
    function exigere(uint256 baseCost) external payable;

    // ============================================================
    // Configuration (owner only)
    // ============================================================

    /// @notice Set the aerarium (treasury) address.
    function setAerarium(address newAerarium) external;

    /// @notice Set a custom rate (overrides default). Set to 0 to restore default.
    /// @param  rate Multiplier in 1e18 fixed-point: toll = baseCost × rate / 1e18
    function setRate(uint256 rate) external;

    // ============================================================
    // View
    // ============================================================

    /// @notice Treasury address that receives all collected tolls.
    function aerarium() external view returns (address);

    /// @notice Current custom rate. 0 means default golden-ratio formula is in use.
    function customRate() external view returns (uint256);

    /// @notice The golden ratio constant: 1.618033988749894848 × 10^18.
    function AURUM_E18() external pure returns (uint256);
}
