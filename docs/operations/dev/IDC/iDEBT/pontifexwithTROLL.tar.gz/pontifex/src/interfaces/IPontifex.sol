// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
 * Pontifex — the bridge-builder.
 *
 * The Pontifex (lit. "bridge-maker", the Roman office that built and
 * maintained the bridges across the Tiber) is the factory contract.
 * It deploys Pons + Custodia pairs deterministically across chains
 * via CREATE2, ensuring the same token has the same address on every
 * chain it is deployed to.
 *
 * Original implementation: defi-wonderland/xERC20 XERC20Factory.sol
 */

interface IPontifex {

    // ============================================================
    // Errors
    // ============================================================

    /// Bridge limits arrays do not match (mintingLimits.length != burningLimits.length).
    error Pontifex_LimensMismatch();

    /// Pontem (bridge) and corresponding limit arrays do not match in length.
    error Pontifex_PontemsMismatch();

    /// Custodia already deployed for this Pons.
    error Pontifex_CustodiaAlreadyExists();

    /// Native token does not have a Custodia counterpart on this chain.
    error Pontifex_NotRegistered();

    // ============================================================
    // Events
    // ============================================================

    /// Emitted when a new Pons is deployed.
    event PonsConsecratus(
        address indexed pons,
        string  name,
        string  symbol
    );

    /// Emitted when a Custodia is deployed for a Pons.
    event CustodiaConsecrata(
        address indexed custodia,
        address indexed pons,
        address indexed underlying,
        bool isNative
    );

    // ============================================================
    // Deployment
    // ============================================================

    /**
     * @notice Deploy a new Pons (xERC20) with optional initial Pontem allowlist.
     * @param  name           Token name
     * @param  symbol         Token symbol
     * @param  mintingLimits  24h mint cap per initial bridge
     * @param  burningLimits  24h burn cap per initial bridge
     * @param  pontems        Initial bridge addresses (whitelist)
     * @return pons           Address of the deployed Pons
     */
    function consecrarePontem(
        string memory name,
        string memory symbol,
        uint256[] memory mintingLimits,
        uint256[] memory burningLimits,
        address[] memory pontems
    ) external returns (address pons);

    /**
     * @notice Deploy a Custodia (lockbox) for an already-deployed Pons.
     * @param  pons         The Pons this Custodia will wrap into
     * @param  underlying   Underlying ERC-20 (any address if isNative=true)
     * @param  isNative     Whether to wrap native ETH instead of an ERC-20
     * @return custodia     Address of the deployed Custodia
     */
    function consecrareCustodiam(
        address pons,
        address underlying,
        bool isNative
    ) external returns (address custodia);

    // ============================================================
    // View
    // ============================================================

    /// @notice CREATE2 salt strategy used for deterministic addresses.
    function ponsImplementation() external view returns (address);
    function custodiaImplementation() external view returns (address);
}
