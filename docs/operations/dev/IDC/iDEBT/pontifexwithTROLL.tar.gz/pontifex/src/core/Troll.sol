// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";

import {ITroll} from "../interfaces/ITroll.sol";

/*
 * Troll — the troll under the bridge.
 *
 * Collects a nominal toll on every cross-chain transit. The toll funds
 * bridge maintenance, monitoring infrastructure, validator reward top-ups,
 * and indexer operation. It is intentionally small enough that no rational
 * actor would build a competing bridge to undercut it (the savings would
 * not cover a competing bridge's operational costs).
 *
 * Default toll formula (positional golden ratio):
 *
 *   toll = AURUM_E18 × 10^trailingZeros(baseCost) / 10^18
 *
 * where AURUM_E18 = 1.618033988749894848 × 10^18 (the golden ratio scaled
 * to 18-decimal fixed point) and trailingZeros counts decimal trailing
 * zeros of baseCost.
 *
 * The toll's leading "1" is positioned at the lowest non-zero digit of
 * baseCost, so that adding the toll preserves and continues the φ digit
 * sequence "1618033988749894848..." into the lower decimals of the result.
 *
 * Single-hop example (ETH source chain):
 *   baseCost = 0.000046 ETH = 46_000_000_000_000 wei
 *   trailingZeros = 12
 *   toll = 1_618_033_988_749_894_848 × 10^12 / 10^18
 *        = 1_618_033_988_749 wei = 0.000001618033988749 ETH
 *   total = 0.000047618033988749 ETH
 *
 * Multi-hop example (ETH → POL → Base, charging at each intermediate hop):
 *   Hop 1 (ETH gas): as above, total = 0.000047618033988749 ETH
 *   Hop 2 (POL gas): baseCost = 0.002 POL = 2_000_000_000_000_000 wei
 *                    trailingZeros = 15
 *                    toll = 1_618_033_988_749_894 wei = 0.001618... POL
 *                    total = 0.003618033988749894 POL
 *   Hop 3 (Base):    user receives Pons; no toll on the destination chain
 *
 * The φ digit-sequence appears in EVERY chain's per-hop total cost,
 * functioning as a cypherpunk watermark on every Pontifex transit.
 *
 * Custom rate override:
 *   The owner may set a custom rate (in 1e18 fixed-point):
 *     toll = baseCost × customRate / 10^18
 *   Setting customRate = 0 restores the default golden-ratio formula.
 *   A maximum cap (MAX_CUSTOM_RATE) prevents the owner from imposing a
 *   confiscatory toll.
 */

contract Troll is ITroll, Ownable {

    // ============================================================
    // Constants
    // ============================================================

    /// @inheritdoc ITroll
    uint256 public constant override AURUM_E18 = 1_618_033_988_749_894_848;

    /// Maximum allowed custom rate: 10% of base cost (1e17 in 1e18 fixed-point).
    /// This caps the owner's ability to impose an extractive toll.
    uint256 public constant MAX_CUSTOM_RATE = 1e17;

    // ============================================================
    // Storage
    // ============================================================

    /// @inheritdoc ITroll
    address public override aerarium;

    /// @inheritdoc ITroll
    uint256 public override customRate;

    // ============================================================
    // Construction
    // ============================================================

    constructor(address initialOwner, address initialAerarium)
        Ownable(initialOwner)
    {
        if (initialAerarium == address(0)) revert Troll_AerariumZero();
        aerarium = initialAerarium;
        emit AerariumSet(address(0), initialAerarium);
    }

    // ============================================================
    // Quoting
    // ============================================================

    /// @inheritdoc ITroll
    function quaerere(uint256 baseCost)
        public view override returns (uint256 toll)
    {
        if (baseCost == 0) return 0;

        // Custom rate path
        if (customRate != 0) {
            return Math.mulDiv(baseCost, customRate, 1e18);
        }

        // Default: positional golden-ratio formula.
        // The toll's leading "1" is positioned at the lowest non-zero digit
        // of baseCost, so that adding the toll preserves and continues the
        // φ digit sequence "1618033988749894848..." into the lower decimals.
        //
        // Worked examples:
        //   baseCost = 46_000_000_000_000 wei (0.000046 ETH)
        //     trailing zeros = 12
        //     toll = AURUM × 10^12 / 1e18 = 1_618_033_988_749 wei
        //     total = 0.000047_618033988749 ETH
        //
        //   baseCost = 2_000_000_000_000_000 wei (0.002 ETH)
        //     trailing zeros = 15
        //     toll = AURUM × 10^15 / 1e18 = 1_618_033_988_749_894 wei
        //     total = 0.003_618033988749894 ETH
        //
        // For "round" base costs (typical of bridge/gas fees), this produces
        // a meaningful nominal toll. For arbitrary-precision base costs with
        // no trailing zeros, the toll is 1 wei (the user is offering a
        // pre-computed precise quote, so the toll is also minimal).

        uint256 trailingZeros = _countTrailingZeros(baseCost);
        return Math.mulDiv(AURUM_E18, 10 ** trailingZeros, 1e18);
    }

    /**
     * @notice Quote tolls for an entire multi-hop route.
     * @dev    Returns per-hop tolls. The total toll across hops only makes
     *         sense if all baseCosts are denominated in the same gas token,
     *         which is generally not the case in cross-chain routes — each
     *         chain's Troll is paid in that chain's native gas. Off-chain
     *         quoters use this helper to display the route's total cost
     *         when normalized to a common unit.
     * @param  baseCosts Per-hop bridge fee, in each chain's native wei
     * @return tolls     Per-hop toll, parallel to baseCosts
     */
    function quaerereRoute(uint256[] calldata baseCosts)
        external view returns (uint256[] memory tolls)
    {
        tolls = new uint256[](baseCosts.length);
        for (uint256 i = 0; i < baseCosts.length; i++) {
            tolls[i] = quaerere(baseCosts[i]);
        }
    }

    /// @notice Count decimal trailing zeros of a positive integer.
    /// @dev    Returns 0 for inputs without trailing zeros (e.g., 4_701).
    ///         Bounded at 77 to prevent gas exhaustion on degenerate inputs.
    function _countTrailingZeros(uint256 x) internal pure returns (uint256 count) {
        // x is guaranteed > 0 by the caller.
        unchecked {
            while (x % 10 == 0 && count < 77) {
                x /= 10;
                count++;
            }
        }
    }

    // ============================================================
    // Collection
    // ============================================================

    /// @inheritdoc ITroll
    function exigere(uint256 baseCost) external payable override {
        uint256 toll = quaerere(baseCost);
        require(msg.value == toll, "Troll: msg.value != toll");

        if (toll > 0) {
            (bool ok, ) = payable(aerarium).call{value: toll}("");
            if (!ok) revert Troll_NativeTransferFailed();
        }

        emit Portorium(msg.sender, baseCost, toll);
    }

    // ============================================================
    // Configuration
    // ============================================================

    /// @inheritdoc ITroll
    function setAerarium(address newAerarium) external override onlyOwner {
        if (newAerarium == address(0)) revert Troll_AerariumZero();
        emit AerariumSet(aerarium, newAerarium);
        aerarium = newAerarium;
    }

    /// @inheritdoc ITroll
    function setRate(uint256 rate) external override onlyOwner {
        if (rate > MAX_CUSTOM_RATE) revert Troll_RateExceedsMaximum();
        emit RateSet(customRate, rate);
        customRate = rate;
    }
}
