// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IPons} from "../interfaces/IPons.sol";

/*
 * PontemAgglayer — the AggLayer-bridged adaptation.
 *
 * A Pontem (bridge adapter) that uses the AggLayer Unified Bridge as the
 * underlying message transport. When a user wants to send Pons from chain
 * A to chain B (both AggLayer-connected), this adapter:
 *   1. Burns Pons from the user on chain A (consuming this Pontem's Limen)
 *   2. Calls bridgeMessage on the AggLayer Unified Bridge
 *   3. On chain B, the corresponding PontemAgglayer claims the message
 *   4. Calls Pons.mint(recipient, amount) on chain B (consuming Limen there)
 *
 * Security composition:
 *   - Pessimistic proof guarantees that the message itself was authentic
 *     (an attacker cannot forge cross-chain messages).
 *   - The Pons Limen guarantees that even if the message *is* malicious,
 *     the damage is bounded by the daily mint limit configured by the
 *     token issuer.
 *
 * This is defense-in-depth: AggLayer prevents the attack; xERC20 caps the
 * blast radius if the prevention ever fails.
 */

interface IPolygonZkEVMBridgeV2 {
    function bridgeMessage(
        uint32 destinationNetwork,
        address destinationAddress,
        bool forceUpdateGlobalExitRoot,
        bytes calldata metadata
    ) external payable;

    function networkID() external view returns (uint32);
}

interface IBridgeMessageReceiver {
    function onMessageReceived(
        address originAddress,
        uint32 originNetwork,
        bytes memory data
    ) external payable;
}

contract PontemAgglayer is IBridgeMessageReceiver {

    // ============================================================
    // Errors
    // ============================================================

    error PontemAgglayer_NotBridge();
    error PontemAgglayer_UntrustedOrigin();
    error PontemAgglayer_WrongOriginNetwork();
    error PontemAgglayer_NoMsgValue();
    error PontemAgglayer_NoZeroAmount();

    // ============================================================
    // Immutables
    // ============================================================

    /// AggLayer Unified Bridge (same address on every connected chain)
    IPolygonZkEVMBridgeV2 public immutable bridge;

    /// The Pons (xERC20) this adapter bridges
    IPons public immutable pons;

    // ============================================================
    // Storage
    // ============================================================

    /// Per-network counterpart adapter address.
    /// counterpart[networkId] = address of PontemAgglayer on that network
    mapping(uint32 => address) public counterpart;

    /// Owner (token issuer) — can set counterparts.
    address public immutable issuer;

    // ============================================================
    // Events
    // ============================================================

    event Transitus(
        address indexed sender,
        uint32  destinationNetwork,
        address destinationAddress,
        uint256 amount
    );

    event Adventus(
        uint32  originNetwork,
        address destinationAddress,
        uint256 amount
    );

    event CounterpartSet(uint32 indexed networkId, address counterpart);

    // ============================================================
    // Construction
    // ============================================================

    constructor(address bridge_, address pons_, address issuer_) {
        bridge = IPolygonZkEVMBridgeV2(bridge_);
        pons   = IPons(pons_);
        issuer = issuer_;
    }

    modifier onlyIssuer() {
        require(msg.sender == issuer, "Pontem: not issuer");
        _;
    }

    function setCounterpart(uint32 networkId, address counterpart_)
        external onlyIssuer
    {
        counterpart[networkId] = counterpart_;
        emit CounterpartSet(networkId, counterpart_);
    }

    // ============================================================
    // Outbound: burn locally, message remotely
    // ============================================================

    /**
     * @notice Send Pons cross-chain via the AggLayer.
     * @dev    Consumes this Pontem's burn Limen on the source chain,
     *         and the destination Pontem's mint Limen on arrival.
     */
    function transire(
        uint32 destinationNetwork,
        address destinationAddress,
        uint256 amount
    ) external payable {
        if (msg.value != 0) revert PontemAgglayer_NoMsgValue();
        if (amount == 0) revert PontemAgglayer_NoZeroAmount();

        // Burn from sender (consumes burn Limen)
        pons.burn(msg.sender, amount);

        // Send message to counterpart adapter on destination
        bridge.bridgeMessage(
            destinationNetwork,
            counterpart[destinationNetwork],
            true, // force GER update
            abi.encode(destinationAddress, amount)
        );

        emit Transitus(msg.sender, destinationNetwork, destinationAddress, amount);
    }

    // ============================================================
    // Inbound: claimMessage callback
    // ============================================================

    /// @notice Called by the Unified Bridge when a cross-chain message arrives.
    function onMessageReceived(
        address originAddress,
        uint32 originNetwork,
        bytes memory data
    ) external payable override {
        // The three security checks that prevent every historical bridge exploit:
        if (msg.sender != address(bridge)) revert PontemAgglayer_NotBridge();
        if (originAddress != counterpart[originNetwork]) {
            revert PontemAgglayer_UntrustedOrigin();
        }
        if (counterpart[originNetwork] == address(0)) {
            revert PontemAgglayer_WrongOriginNetwork();
        }

        (address destinationAddress, uint256 amount) =
            abi.decode(data, (address, uint256));

        // Mint to recipient (consumes mint Limen)
        pons.mint(destinationAddress, amount);

        emit Adventus(originNetwork, destinationAddress, amount);
    }
}
