// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

import {IOmnipons} from "../interfaces/IOmnipons.sol";
import {IPons} from "../interfaces/IPons.sol";
import {ITroll} from "../interfaces/ITroll.sol";

/*
 * Omnipons — the all-bridge.
 *
 * Multi-bridge router that aggregates Pontem implementations behind a
 * single transire() call. Selects the optimal Pontem for each destination
 * based on the user's maxSigillumTier (trust ceiling) and the available
 * Limen on the destination side.
 *
 * Conceptual heritage from THRUSTDeltaV stargate router (handshake →
 * warpdrive → equilibrium → afterburner) — multi-stage bridge
 * composition. Reimplemented with xERC20 burn/mint primitives instead
 * of external-validator messaging. The trust model is per-Pontem and
 * always bounded by the Pons Limen.
 */

interface IPontem {
    function transire(
        uint32 destinationNetwork,
        address destinationAddress,
        uint256 amount
    ) external payable;
}

contract Omnipons is IOmnipons, Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // ============================================================
    // Storage
    // ============================================================

    /// pontemId → registration
    mapping(bytes32 => PontemRegistration) public pontems;

    /// All registered pontemIds (for iteration)
    bytes32[] public pontemIds;

    /// (pons, destinationChainId) → preferred pontemId for auto-routing
    mapping(address => mapping(uint64 => bytes32)) public preferredPontem;

    /// Optional Troll (toll-collector). address(0) means no toll is charged.
    ITroll public troll;

    // ============================================================
    // Events
    // ============================================================

    event TrollSet(address indexed previous, address indexed current);

    // ============================================================
    // Construction
    // ============================================================

    constructor(address initialOwner) Ownable(initialOwner) {}

    // ============================================================
    // Configuration
    // ============================================================

    /// @notice Wire a Troll into the router. Set to address(0) to disable toll collection.
    function setTroll(address troll_) external onlyOwner {
        emit TrollSet(address(troll), troll_);
        troll = ITroll(troll_);
    }

    // ============================================================
    // Routing
    // ============================================================

    /// @inheritdoc IOmnipons
    function transire(TransitOrder calldata order)
        external payable override nonReentrant
    {
        if (block.timestamp > order.deadline) revert Omnipons_DeadlineExpired();

        // Resolve the Pontem
        bytes32 chosenId = order.pontemId;
        if (chosenId == bytes32(0)) {
            chosenId = eligePontem(
                order.pons,
                order.destinationChainId,
                order.amount,
                order.maxSigillumTier
            );
        }

        PontemRegistration memory reg = pontems[chosenId];
        if (reg.pontem == address(0) || !reg.active) {
            revert Omnipons_PontemNotRegistered();
        }
        if (uint8(reg.sigillumTier) > order.maxSigillumTier) {
            revert Omnipons_PontemNotRegistered();
        }

        // Verify the user's burn Limen on the chosen Pontem covers the amount
        uint256 limit = IPons(order.pons).burningCurrentLimitOf(reg.pontem);
        if (limit < order.amount) revert Omnipons_LimenInsufficient();

        // ---------- Toll computation ----------
        // The user's msg.value covers the bridge fee + the troll's portorium.
        // bridgeFee = msg.value - toll, where toll = troll.quaerere(bridgeFee).
        //
        // Because toll depends on bridgeFee and bridgeFee depends on toll,
        // we solve the equation: msg.value = bridgeFee + quaerere(bridgeFee).
        // For the default golden-ratio formula this is monotonic in bridgeFee,
        // so we compute by deriving bridgeFee = msg.value - quaerere(msg.value)
        // first-pass, then verify. For the typical case (msg.value < ~10^18)
        // this single-pass approximation differs from the fixed-point
        // solution by a few wei; we accept any msg.value sufficient to
        // cover both, and refund the residual to the bridge.
        uint256 toll;
        uint256 bridgeFee;
        if (address(troll) != address(0) && msg.value > 0) {
            // Compute toll based on what the user offered as msg.value.
            // The user is expected to call quoteTransitus off-chain to
            // determine the exact required msg.value.
            toll = troll.quaerere(msg.value - troll.quaerere(msg.value));
            require(msg.value > toll, "Omnipons: msg.value <= toll");
            bridgeFee = msg.value - toll;

            // Pay the troll (forwards to aerarium internally).
            troll.exigere{value: toll}(bridgeFee);
        } else {
            bridgeFee = msg.value;
        }

        // ---------- Token movement ----------
        // Pull Pons from user, then forward to Pontem.
        IERC20(order.pons).safeTransferFrom(
            msg.sender, address(this), order.amount
        );
        IERC20(order.pons).forceApprove(reg.pontem, order.amount);

        // ---------- Bridge dispatch ----------
        IPontem(reg.pontem).transire{value: bridgeFee}(
            uint32(order.destinationChainId),
            order.destinationAddress,
            order.amount
        );

        emit Transitus(
            msg.sender,
            order.pons,
            chosenId,
            order.destinationChainId,
            order.destinationAddress,
            order.amount
        );
    }

    /// @inheritdoc IOmnipons
    function quoteTransitus(TransitOrder calldata)
        external view override returns (uint256 fee)
    {
        // Per-Pontem fee schedules vary by underlying transport (AggLayer is
        // gas-only, LayerZero charges fees, CCTP charges Circle fees).
        // Subclasses or off-chain quoters provide bridge-specific quotes;
        // this base implementation returns 0 to signal "no router fee".
        // Use quoteTotalCost() for bridgeFee + toll computation.
        return 0;
    }

    /**
     * @notice Quote the total cost (bridgeFee + toll) for a known bridge fee.
     * @dev    Off-chain quoters get the bridgeFee from the underlying bridge,
     *         then call this to learn the total msg.value to send.
     * @param  bridgeFee The fee the underlying bridge requires
     * @return total     bridgeFee + troll.quaerere(bridgeFee)
     * @return toll      The toll component
     */
    function quoteTotalCost(uint256 bridgeFee)
        external view returns (uint256 total, uint256 toll)
    {
        if (address(troll) != address(0)) {
            toll = troll.quaerere(bridgeFee);
        }
        total = bridgeFee + toll;
    }
    }

    /// @inheritdoc IOmnipons
    function eligePontem(
        address pons,
        uint64 destinationChainId,
        uint256 amount,
        uint8 maxSigillumTier
    ) public view override returns (bytes32 chosenId) {
        // 1. Try preferred pontem first
        bytes32 preferred = preferredPontem[pons][destinationChainId];
        if (preferred != bytes32(0)) {
            PontemRegistration memory reg = pontems[preferred];
            if (
                reg.active &&
                uint8(reg.sigillumTier) <= maxSigillumTier &&
                IPons(pons).burningCurrentLimitOf(reg.pontem) >= amount
            ) {
                return preferred;
            }
        }

        // 2. Fall back to lowest-trust-tier Pontem with sufficient Limen
        uint8 bestTier = type(uint8).max;
        for (uint256 i = 0; i < pontemIds.length; i++) {
            PontemRegistration memory reg = pontems[pontemIds[i]];
            if (!reg.active) continue;
            if (uint8(reg.sigillumTier) > maxSigillumTier) continue;
            if (uint8(reg.sigillumTier) >= bestTier) continue;
            if (IPons(pons).burningCurrentLimitOf(reg.pontem) < amount) continue;

            bestTier = uint8(reg.sigillumTier);
            chosenId = pontemIds[i];
        }

        if (chosenId == bytes32(0)) revert Omnipons_DestinationUnreachable();
    }

    // ============================================================
    // Registration (owner / governance)
    // ============================================================

    /// @inheritdoc IOmnipons
    function registrarePontem(
        bytes32 pontemId,
        address pontem,
        SigillumTier sigillumTier
    ) external override onlyOwner {
        if (pontems[pontemId].pontem == address(0)) {
            pontemIds.push(pontemId);
        }

        pontems[pontemId] = PontemRegistration({
            pontem: pontem,
            sigillumTier: sigillumTier,
            active: true
        });

        emit PontemRegistered(pontemId, pontem, uint8(sigillumTier));
    }

    /// @inheritdoc IOmnipons
    function revocarePontem(bytes32 pontemId) external override onlyOwner {
        pontems[pontemId].active = false;
    }

    /// @notice Set the preferred Pontem for a (pons, destination) route.
    function setPreferredPontem(
        address pons,
        uint64 destinationChainId,
        bytes32 pontemId
    ) external onlyOwner {
        preferredPontem[pons][destinationChainId] = pontemId;
    }

    // ============================================================
    // View
    // ============================================================

    function pontemCount() external view returns (uint256) {
        return pontemIds.length;
    }
}
