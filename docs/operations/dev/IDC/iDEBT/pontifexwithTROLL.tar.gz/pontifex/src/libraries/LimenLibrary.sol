// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IPons} from "../interfaces/IPons.sol";

/*
 * LimenLibrary — the threshold mathematics.
 *
 * The Limen (Latin: threshold, boundary) is the rate-limit primitive.
 * Each Pontem (bridge) has two Limens — one for minting, one for burning —
 * each of which replenishes linearly over _DURATION (24 hours) toward
 * its maxLimit.
 *
 * This is the cypherpunk circuit breaker: even a fully compromised bridge
 * cannot mint or burn more than its 24h Limen. Catastrophic exploits like
 * Ronin ($624M) become bounded losses of "one day's worth" of liquidity.
 *
 * Math is unchanged from defi-wonderland/xERC20 reference implementation,
 * which has been audited and is in production use by Renzo, Connext,
 * Alchemix, Kelp DAO, and others.
 */

library LimenLibrary {

    /// Replenishment duration: limits fully refill over 24 hours.
    uint256 internal constant DURATION = 1 days;

    // ============================================================
    // View functions
    // ============================================================

    /**
     * @notice Compute the current limit, accounting for time-based replenishment.
     * @dev    The limit linearly increases from `currentLimit` toward `maxLimit`
     *         at `ratePerSecond` per second, but never exceeds `maxLimit`.
     */
    function getCurrentLimit(IPons.Limen memory l)
        internal view returns (uint256 limit)
    {
        limit = l.currentLimit;

        if (limit == l.maxLimit) {
            return limit;
        }

        if (l.timestamp + DURATION <= block.timestamp) {
            // A full duration has passed → fully replenished
            return l.maxLimit;
        }

        // Partial replenishment
        uint256 timePassed = block.timestamp - l.timestamp;
        uint256 calculated = limit + (timePassed * l.ratePerSecond);
        return calculated > l.maxLimit ? l.maxLimit : calculated;
    }

    // ============================================================
    // State mutation
    // ============================================================

    /**
     * @notice Decrement the current limit by `amount`. Updates timestamp.
     * @dev    Reverts via the caller if `amount > getCurrentLimit(l)`.
     *         The caller MUST check this before calling useLimen.
     */
    function useLimen(IPons.Limen storage l, uint256 amount) internal {
        uint256 current = getCurrentLimit(l);
        l.timestamp = block.timestamp;
        l.currentLimit = current - amount;
    }

    /**
     * @notice Reconfigure a Limen with a new max limit.
     * @dev    The current limit is adjusted by the difference between old and
     *         new max limits, preserving any "credit" the bridge had already
     *         accumulated, but never exceeding the new max.
     */
    function changeLimen(IPons.Limen storage l, uint256 newMaxLimit) internal {
        uint256 oldMax     = l.maxLimit;
        uint256 currentNow = getCurrentLimit(l);
        uint256 newCurrent = _calculateNewCurrent(newMaxLimit, oldMax, currentNow);

        l.maxLimit       = newMaxLimit;
        l.currentLimit   = newCurrent;
        l.ratePerSecond  = newMaxLimit / DURATION;
        l.timestamp      = block.timestamp;
    }

    // ============================================================
    // Internal
    // ============================================================

    function _calculateNewCurrent(
        uint256 newLimit,
        uint256 oldLimit,
        uint256 currentLimit
    ) private pure returns (uint256 newCurrent) {
        if (oldLimit > newLimit) {
            // Limit decreased — preserve unused capacity but cap at decrement
            uint256 difference = oldLimit - newLimit;
            newCurrent = currentLimit > difference
                ? currentLimit - difference
                : 0;
        } else {
            // Limit increased — credit the bridge with the increase
            uint256 difference = newLimit - oldLimit;
            newCurrent = currentLimit + difference;
        }
    }
}
