// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20Upgradeable} from
    "@openzeppelin/contracts-upgradeable/token/ERC20/ERC20Upgradeable.sol";
import {ERC20PermitUpgradeable} from
    "@openzeppelin/contracts-upgradeable/token/ERC20/extensions/ERC20PermitUpgradeable.sol";
import {OwnableUpgradeable} from
    "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import {Initializable} from
    "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";

import {IPons} from "../interfaces/IPons.sol";
import {LimenLibrary} from "../libraries/LimenLibrary.sol";

/*
 * Pons — the bridge.
 *
 * Reference implementation of xERC20 (EIP-7281) with cypherpunk Latin naming.
 * The mint/burn/limit semantics are mathematically identical to the
 * defi-wonderland/xERC20 reference, which is in production use securing
 * billions of dollars across multiple ecosystems.
 *
 * Token issuer (the Pontifex / owner) controls:
 *   - which Pontems (bridges) may mint/burn this Pons
 *   - the 24h Limen (rate limit) for each Pontem in each direction
 *   - the Custodia (lockbox) address for canonical-token wrapping
 *
 * The Pons is sovereign: no bridge operator deploys or controls it.
 * Bridges are revocable whitelist entries with bounded blast radius.
 */

contract Pons is
    Initializable,
    ERC20Upgradeable,
    OwnableUpgradeable,
    ERC20PermitUpgradeable,
    IPons
{
    using LimenLibrary for IPons.Limen;

    // ============================================================
    // Storage
    // ============================================================

    /// The factory (Pontifex) that deployed this Pons.
    address public pontifex;

    /// The Custodia (lockbox) address. address(0) if no canonical wrapping.
    address public override custodia;

    /// Per-bridge mint/burn configurations.
    mapping(address => Pontem) internal _pontems;

    // ============================================================
    // Construction
    // ============================================================

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    /**
     * @notice Initialize a new Pons.
     * @param  name_     Token name
     * @param  symbol_   Token symbol
     * @param  pontifex_ Factory address (becomes initial owner; transfers to issuer)
     */
    function initialize(
        string memory name_,
        string memory symbol_,
        address pontifex_
    ) public initializer {
        __ERC20_init(name_, symbol_);
        __ERC20Permit_init(name_);
        __Ownable_init(pontifex_);

        pontifex = pontifex_;
    }

    // ============================================================
    // Mint / Burn (called by Pontem implementations)
    // ============================================================

    /// @inheritdoc IPons
    function mint(address to, uint256 amount) external override {
        _mintWithCaller(msg.sender, to, amount);
    }

    /// @inheritdoc IPons
    function burn(address from, uint256 amount) external override {
        if (msg.sender != from) {
            _spendAllowance(from, msg.sender, amount);
        }
        _burnWithCaller(msg.sender, from, amount);
    }

    // ============================================================
    // Configuration
    // ============================================================

    /// @inheritdoc IPons
    function setCustodia(address custodia_) external override {
        if (msg.sender != pontifex) revert Pons_NotPontifex();
        custodia = custodia_;
        emit CustodiaSet(custodia_);
    }

    /// @inheritdoc IPons
    function setLimens(
        address pontem,
        uint256 mintingLimit,
        uint256 burningLimit
    ) external override onlyOwner {
        _changeMinterLimen(pontem, mintingLimit);
        _changeBurnerLimen(pontem, burningLimit);
        emit PontemLimenSet(mintingLimit, burningLimit, pontem);
    }

    // ============================================================
    // View
    // ============================================================

    /// @inheritdoc IPons
    function mintingMaxLimitOf(address pontem)
        external view override returns (uint256)
    {
        return _pontems[pontem].minterLimen.maxLimit;
    }

    /// @inheritdoc IPons
    function burningMaxLimitOf(address pontem)
        external view override returns (uint256)
    {
        return _pontems[pontem].burnerLimen.maxLimit;
    }

    /// @inheritdoc IPons
    function mintingCurrentLimitOf(address pontem)
        public view override returns (uint256)
    {
        return _pontems[pontem].minterLimen.getCurrentLimit();
    }

    /// @inheritdoc IPons
    function burningCurrentLimitOf(address pontem)
        public view override returns (uint256)
    {
        return _pontems[pontem].burnerLimen.getCurrentLimit();
    }

    // ============================================================
    // Internal
    // ============================================================

    function _mintWithCaller(
        address caller,
        address to,
        uint256 amount
    ) internal {
        if (amount == 0) revert Pons_ZeroValue();

        if (caller != custodia) {
            uint256 currentLimit = mintingCurrentLimitOf(caller);
            if (currentLimit < amount) revert Pons_LimenExceeded();
            _pontems[caller].minterLimen.useLimen(amount);
        }

        _mint(to, amount);
    }

    function _burnWithCaller(
        address caller,
        address from,
        uint256 amount
    ) internal {
        if (amount == 0) revert Pons_ZeroValue();

        if (caller != custodia) {
            uint256 currentLimit = burningCurrentLimitOf(caller);
            if (currentLimit < amount) revert Pons_LimenExceeded();
            _pontems[caller].burnerLimen.useLimen(amount);
        }

        _burn(from, amount);
    }

    function _changeMinterLimen(address pontem, uint256 newLimit) internal {
        _pontems[pontem].minterLimen.changeLimen(newLimit);
    }

    function _changeBurnerLimen(address pontem, uint256 newLimit) internal {
        _pontems[pontem].burnerLimen.changeLimen(newLimit);
    }
}
