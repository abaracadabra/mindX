// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
 * Custodia — the custody.
 *
 * The Custodia is the Lockbox: an immutable 1:1 wrapper that converts
 * an existing canonical token (USDC, ETH, etc.) into the Pons (xERC20)
 * and back. It is the gateway between the legacy ERC-20 world and the
 * sovereign cross-chain world.
 *
 * Standard reference: EIP-7281 Lockbox
 * Original implementation: defi-wonderland/xERC20 XERC20Lockbox.sol
 */

interface ICustodia {

    // ============================================================
    // Errors
    // ============================================================

    /// Operation requires native token (ETH); contract is configured for ERC-20.
    error Custodia_NotNative();

    /// Operation requires ERC-20; contract is configured for native token.
    error Custodia_Native();

    /// Native token transfer to recipient failed.
    error Custodia_NativeTransferFailed();

    // ============================================================
    // Events
    // ============================================================

    /// User locked underlying tokens; received Pons 1:1.
    event Iungere(address indexed user, uint256 amount);

    /// User burned Pons; received underlying tokens 1:1.
    event Solvere(address indexed user, uint256 amount);

    // ============================================================
    // Functions
    // ============================================================

    /// @notice Lock ERC-20 underlying; mint Pons 1:1 to msg.sender.
    function deposit(uint256 amount) external;

    /// @notice Lock ERC-20 underlying; mint Pons 1:1 to specified recipient.
    function depositTo(address to, uint256 amount) external;

    /// @notice Lock native ETH; mint Pons 1:1 to msg.sender.
    function depositNative() external payable;

    /// @notice Lock native ETH; mint Pons 1:1 to specified recipient.
    function depositNativeTo(address to) external payable;

    /// @notice Burn Pons from msg.sender; release underlying 1:1.
    function withdraw(uint256 amount) external;

    /// @notice Burn Pons from msg.sender; release underlying to recipient 1:1.
    function withdrawTo(address to, uint256 amount) external;

    // ============================================================
    // View
    // ============================================================

    /// @notice The Pons (xERC20) this Custodia is bonded to.
    function pons() external view returns (address);

    /// @notice The underlying ERC-20 (zero address if native).
    function underlying() external view returns (address);

    /// @notice True if this Custodia wraps native ETH instead of an ERC-20.
    function isNative() external view returns (bool);
}
