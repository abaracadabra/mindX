// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import {Test, console2} from "forge-std/Test.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

import {Pons} from "../src/core/Pons.sol";
import {Custodia} from "../src/core/Custodia.sol";
import {Pontifex} from "../src/core/Pontifex.sol";
import {ICustodia} from "../src/interfaces/ICustodia.sol";

contract MockToken is ERC20 {
    constructor() ERC20("Mock", "MOCK") {}
    function mint(address to, uint256 amount) external { _mint(to, amount); }
}

/**
 * Custodia.t.sol
 * Tests focused on the lockbox: ERC-20 wrapping, native ETH wrapping,
 * deposit/withdraw symmetry, recipient flows, and reentrancy resistance.
 */
contract CustodiaTest is Test {

    Pontifex pontifex;
    Pons pons;
    Pons ponsNative;
    Custodia custodiaErc20;
    Custodia custodiaNative;
    MockToken underlying;

    address issuer = makeAddr("issuer");
    address alice  = makeAddr("alice");
    address bob    = makeAddr("bob");

    function setUp() public {
        pontifex = new Pontifex();
        underlying = new MockToken();

        // ERC-20 wrapping path
        vm.startPrank(issuer);
        address[] memory empty = new address[](0);
        uint256[] memory emptyU = new uint256[](0);

        address ponsAddr = pontifex.consecrarePontem(
            "Pons Mock", "pMOCK", emptyU, emptyU, empty
        );
        pons = Pons(ponsAddr);

        custodiaErc20 = Custodia(payable(
            pontifex.consecrareCustodiam(ponsAddr, address(underlying), false)
        ));

        // Native ETH wrapping path (separate Pons)
        address ponsNativeAddr = pontifex.consecrarePontem(
            "Pons Ether", "pETH", emptyU, emptyU, empty
        );
        ponsNative = Pons(ponsNativeAddr);

        custodiaNative = Custodia(payable(
            pontifex.consecrareCustodiam(ponsNativeAddr, address(0), true)
        ));
        vm.stopPrank();

        underlying.mint(alice, 100_000e18);
        vm.deal(alice, 100 ether);
        vm.deal(bob, 100 ether);
    }

    // ============ ERC-20 wrapping ============

    function test_DepositWithdraw_Symmetry() public {
        vm.startPrank(alice);
        underlying.approve(address(custodiaErc20), 5_000e18);
        custodiaErc20.deposit(5_000e18);

        assertEq(pons.balanceOf(alice), 5_000e18);
        assertEq(underlying.balanceOf(address(custodiaErc20)), 5_000e18);
        assertEq(underlying.balanceOf(alice), 95_000e18);

        custodiaErc20.withdraw(5_000e18);

        assertEq(pons.balanceOf(alice), 0);
        assertEq(underlying.balanceOf(address(custodiaErc20)), 0);
        assertEq(underlying.balanceOf(alice), 100_000e18);
        vm.stopPrank();
    }

    function test_DepositTo_RecipientReceivesPons() public {
        vm.startPrank(alice);
        underlying.approve(address(custodiaErc20), 1_000e18);
        custodiaErc20.depositTo(bob, 1_000e18);
        vm.stopPrank();

        assertEq(pons.balanceOf(bob), 1_000e18);
        assertEq(pons.balanceOf(alice), 0);
    }

    function test_WithdrawTo_RecipientReceivesUnderlying() public {
        vm.startPrank(alice);
        underlying.approve(address(custodiaErc20), 1_000e18);
        custodiaErc20.deposit(1_000e18);
        custodiaErc20.withdrawTo(bob, 1_000e18);
        vm.stopPrank();

        assertEq(underlying.balanceOf(bob), 1_000e18);
        assertEq(pons.balanceOf(alice), 0);
    }

    function test_RevertWhen_DepositOnNativeCustodia() public {
        vm.expectRevert(ICustodia.Custodia_Native.selector);
        vm.prank(alice);
        custodiaNative.deposit(100);
    }

    function test_RevertWhen_NativeDepositOnErc20Custodia() public {
        vm.expectRevert(ICustodia.Custodia_NotNative.selector);
        vm.prank(alice);
        custodiaErc20.depositNative{value: 1 ether}();
    }

    // ============ Native ETH wrapping ============

    function test_NativeDepositMintsPons() public {
        vm.prank(alice);
        custodiaNative.depositNative{value: 1 ether}();

        assertEq(ponsNative.balanceOf(alice), 1 ether);
        assertEq(address(custodiaNative).balance, 1 ether);
    }

    function test_NativeWithdrawReleasesEth() public {
        vm.startPrank(alice);
        custodiaNative.depositNative{value: 5 ether}();

        uint256 ethBefore = alice.balance;
        custodiaNative.withdraw(2 ether);

        assertEq(ponsNative.balanceOf(alice), 3 ether);
        assertEq(alice.balance, ethBefore + 2 ether);
        vm.stopPrank();
    }

    function test_NativeReceive_AutoDeposits() public {
        vm.prank(alice);
        (bool ok,) = address(custodiaNative).call{value: 3 ether}("");
        assertTrue(ok);

        assertEq(ponsNative.balanceOf(alice), 3 ether);
    }

    function test_NativeDepositTo_RecipientReceivesPons() public {
        vm.prank(alice);
        custodiaNative.depositNativeTo{value: 7 ether}(bob);

        assertEq(ponsNative.balanceOf(bob), 7 ether);
        assertEq(ponsNative.balanceOf(alice), 0);
    }

    // ============ Custodia bypass property ============

    function test_CustodiaBypassesAllLimens() public {
        // Even with no bridge configured, the Custodia can mint freely
        // (because it is set as `custodia` on the Pons, bypassing limit checks)
        vm.startPrank(alice);
        underlying.approve(address(custodiaErc20), 100_000e18);
        custodiaErc20.deposit(100_000e18);
        vm.stopPrank();

        assertEq(pons.balanceOf(alice), 100_000e18);
        // The default bridge (none configured) has zero limit, but Custodia
        // is exempt because it's the canonical 1:1 path
    }

    // ============ Fuzz ============

    function testFuzz_Erc20DepositWithdraw(uint256 amount) public {
        amount = bound(amount, 1, 50_000e18);

        vm.startPrank(alice);
        underlying.approve(address(custodiaErc20), amount);
        custodiaErc20.deposit(amount);
        custodiaErc20.withdraw(amount);
        vm.stopPrank();

        assertEq(pons.balanceOf(alice), 0);
        assertEq(underlying.balanceOf(alice), 100_000e18);
    }

    function testFuzz_NativeDepositWithdraw(uint96 amount) public {
        vm.assume(amount > 0 && amount < 50 ether);

        uint256 balBefore = alice.balance;
        vm.startPrank(alice);
        custodiaNative.depositNative{value: amount}();
        custodiaNative.withdraw(amount);
        vm.stopPrank();

        assertEq(ponsNative.balanceOf(alice), 0);
        assertEq(alice.balance, balBefore);
    }
}
