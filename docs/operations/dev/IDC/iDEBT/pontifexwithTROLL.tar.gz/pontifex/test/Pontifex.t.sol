// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import {Test, console2} from "forge-std/Test.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

import {Pons} from "../src/core/Pons.sol";
import {Custodia} from "../src/core/Custodia.sol";
import {Pontifex} from "../src/core/Pontifex.sol";
import {IPons} from "../src/interfaces/IPons.sol";

/// Mock ERC-20 for testing the Custodia
contract MockERC20 is ERC20 {
    constructor() ERC20("Mock USDC", "USDC") {}
    function mint(address to, uint256 amount) external { _mint(to, amount); }
}

/// Mock Pontem (bridge) for testing limit enforcement
contract MockPontem {
    IPons public immutable pons;
    constructor(address pons_) { pons = IPons(pons_); }

    function callMint(address to, uint256 amount) external {
        pons.mint(to, amount);
    }

    function callBurn(address from, uint256 amount) external {
        pons.burn(from, amount);
    }
}

contract PontifexTest is Test {

    Pontifex pontifex;
    Pons pons;
    Custodia custodia;
    MockERC20 underlying;
    MockPontem pontemA;
    MockPontem pontemB;

    address issuer = makeAddr("issuer");
    address alice  = makeAddr("alice");
    address bob    = makeAddr("bob");

    uint256 constant MINT_LIMIT = 1_000_000e18;
    uint256 constant BURN_LIMIT = 1_000_000e18;

    function setUp() public {
        // Deploy factory
        pontifex = new Pontifex();
        underlying = new MockERC20();

        // Deploy Pons via factory (issuer becomes owner)
        vm.startPrank(issuer);
        address[] memory bridges = new address[](0);
        uint256[] memory mintLimits = new uint256[](0);
        uint256[] memory burnLimits = new uint256[](0);

        address ponsAddr = pontifex.consecrarePontem(
            "Pons USDC",
            "pUSDC",
            mintLimits,
            burnLimits,
            bridges
        );
        pons = Pons(ponsAddr);

        // Deploy Custodia for the Pons
        address custodiaAddr = pontifex.consecrareCustodiam(
            ponsAddr,
            address(underlying),
            false
        );
        custodia = Custodia(payable(custodiaAddr));
        vm.stopPrank();

        // Deploy mock bridges
        pontemA = new MockPontem(address(pons));
        pontemB = new MockPontem(address(pons));

        // Issuer authorizes bridges
        vm.prank(issuer);
        pons.setLimens(address(pontemA), MINT_LIMIT, BURN_LIMIT);
        vm.prank(issuer);
        pons.setLimens(address(pontemB), MINT_LIMIT / 2, BURN_LIMIT / 2);

        // Fund alice with underlying
        underlying.mint(alice, 100_000e18);
    }

    // ============ Custodia: 1:1 wrap/unwrap ============

    function test_Custodia_DepositMintsPons() public {
        vm.startPrank(alice);
        underlying.approve(address(custodia), 1_000e18);
        custodia.deposit(1_000e18);
        vm.stopPrank();

        assertEq(pons.balanceOf(alice), 1_000e18);
        assertEq(underlying.balanceOf(address(custodia)), 1_000e18);
    }

    function test_Custodia_WithdrawBurnsPons() public {
        // Deposit first
        vm.startPrank(alice);
        underlying.approve(address(custodia), 1_000e18);
        custodia.deposit(1_000e18);
        custodia.withdraw(500e18);
        vm.stopPrank();

        assertEq(pons.balanceOf(alice), 500e18);
        assertEq(underlying.balanceOf(alice), 99_500e18);
        assertEq(underlying.balanceOf(address(custodia)), 500e18);
    }

    function test_Custodia_BypassesLimens() public {
        // Custodia mints way more than any single bridge could
        vm.startPrank(alice);
        underlying.mint(alice, 100_000_000e18);
        underlying.approve(address(custodia), 100_000_000e18);
        custodia.deposit(100_000_000e18);
        vm.stopPrank();

        // 100M minted, even though no single bridge has 100M Limen
        assertEq(pons.balanceOf(alice), 100_000_100e18); // includes earlier 1k-test
    }

    // ============ Pons: Limen enforcement ============

    function test_Pons_BridgeCanMintWithinLimit() public {
        pontemA.callMint(alice, 100e18);
        assertEq(pons.balanceOf(alice), 100e18);

        // Verify Limen consumed
        assertLt(
            pons.mintingCurrentLimitOf(address(pontemA)),
            MINT_LIMIT
        );
    }

    function test_Pons_RevertWhen_BridgeMintsOverLimit() public {
        // Try to mint more than the configured max
        vm.expectRevert(IPons.Pons_LimenExceeded.selector);
        pontemA.callMint(alice, MINT_LIMIT + 1);
    }

    function test_Pons_LimenReplenishesOverTime() public {
        // Burn the entire limit
        pontemA.callMint(alice, MINT_LIMIT);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), 0);

        // Half the duration passes — half the limit should be replenished
        vm.warp(block.timestamp + 12 hours);
        uint256 currentLimit = pons.mintingCurrentLimitOf(address(pontemA));
        assertApproxEqAbs(currentLimit, MINT_LIMIT / 2, 1e15);

        // Full duration passes — fully replenished
        vm.warp(block.timestamp + 12 hours);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), MINT_LIMIT);
    }

    function test_Pons_PerBridgeLimensAreIndependent() public {
        // Pontem A drains its limit
        pontemA.callMint(alice, MINT_LIMIT);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), 0);

        // Pontem B is unaffected
        assertEq(
            pons.mintingCurrentLimitOf(address(pontemB)),
            MINT_LIMIT / 2
        );
    }

    function test_Pons_RevocationViaZeroLimit() public {
        // Issuer revokes pontemA by setting limits to 0
        vm.prank(issuer);
        pons.setLimens(address(pontemA), 0, 0);

        vm.expectRevert(IPons.Pons_LimenExceeded.selector);
        pontemA.callMint(alice, 1);
    }

    // ============ Pontifex: deterministic deployment ============

    function test_Pontifex_AddressPrediction() public view {
        address predicted = pontifex.predicarePons("Test Token", "TST", issuer);
        assertGt(uint160(predicted), 0);
    }

    function test_Pontifex_RevertsOnDuplicateCustodia() public {
        vm.prank(issuer);
        vm.expectRevert(); // Either Pontifex_CustodiaAlreadyExists or CREATE2 collision
        pontifex.consecrareCustodiam(
            address(pons),
            address(underlying),
            false
        );
    }

    // ============ Fuzz ============

    function testFuzz_LimenNeverExceedsMax(uint256 amount) public {
        amount = bound(amount, 1, MINT_LIMIT);
        pontemA.callMint(alice, amount);

        assertLe(
            pons.mintingCurrentLimitOf(address(pontemA)),
            MINT_LIMIT
        );
    }

    function testFuzz_DepositWithdrawSymmetry(uint256 amount) public {
        amount = bound(amount, 1, 50_000e18);

        vm.startPrank(alice);
        underlying.approve(address(custodia), amount);
        custodia.deposit(amount);

        uint256 ponsBalance = pons.balanceOf(alice);
        custodia.withdraw(ponsBalance);
        vm.stopPrank();

        assertEq(pons.balanceOf(alice), 0);
    }
}
