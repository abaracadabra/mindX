// SPDX-License-Identifier: MIT
pragma solidity ^0.8.23;

import {Test, console2} from "forge-std/Test.sol";

import {Pons} from "../src/core/Pons.sol";
import {Pontifex} from "../src/core/Pontifex.sol";
import {IPons} from "../src/interfaces/IPons.sol";

contract MockPontem {
    Pons public immutable pons;
    constructor(address pons_) { pons = Pons(pons_); }
    function callMint(address to, uint256 amount) external { pons.mint(to, amount); }
    function callBurn(address from, uint256 amount) external { pons.burn(from, amount); }
}

/**
 * Pons.t.sol
 * Tests focused on Limen mathematics: linear replenishment, time warping,
 * per-bridge isolation, revocation via zero-limit, and edge cases around
 * limit reconfiguration.
 */
contract PonsTest is Test {

    Pontifex pontifex;
    Pons pons;
    MockPontem pontemA;
    MockPontem pontemB;
    MockPontem pontemC;

    address issuer = makeAddr("issuer");
    address alice  = makeAddr("alice");

    uint256 constant LIMEN_A = 1_000e18;
    uint256 constant LIMEN_B = 500e18;
    uint256 constant LIMEN_C = 10_000e18;

    function setUp() public {
        pontifex = new Pontifex();

        vm.startPrank(issuer);
        address[] memory empty = new address[](0);
        uint256[] memory emptyU = new uint256[](0);
        address ponsAddr = pontifex.consecrarePontem(
            "Test Pons", "TPONS", emptyU, emptyU, empty
        );
        pons = Pons(ponsAddr);
        vm.stopPrank();

        pontemA = new MockPontem(address(pons));
        pontemB = new MockPontem(address(pons));
        pontemC = new MockPontem(address(pons));

        vm.startPrank(issuer);
        pons.setLimens(address(pontemA), LIMEN_A, LIMEN_A);
        pons.setLimens(address(pontemB), LIMEN_B, LIMEN_B);
        pons.setLimens(address(pontemC), LIMEN_C, LIMEN_C);
        vm.stopPrank();
    }

    // ============ Basic Limen behavior ============

    function test_InitialLimensAreFull() public view {
        assertEq(pons.mintingMaxLimitOf(address(pontemA)), LIMEN_A);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A);
    }

    function test_MintConsumesLimen() public {
        pontemA.callMint(alice, 100e18);

        assertEq(pons.balanceOf(alice), 100e18);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A - 100e18);
    }

    function test_RevertWhen_MintExceedsLimen() public {
        vm.expectRevert(IPons.Pons_LimenExceeded.selector);
        pontemA.callMint(alice, LIMEN_A + 1);
    }

    function test_RevertWhen_MintZero() public {
        vm.expectRevert(IPons.Pons_ZeroValue.selector);
        pontemA.callMint(alice, 0);
    }

    // ============ Time-based replenishment ============

    function test_LimenReplenishesLinearly() public {
        // Drain entire limit
        pontemA.callMint(alice, LIMEN_A);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), 0);

        // 1/4 of duration → 1/4 replenished
        vm.warp(block.timestamp + 6 hours);
        uint256 quarter = pons.mintingCurrentLimitOf(address(pontemA));
        assertApproxEqRel(quarter, LIMEN_A / 4, 0.001e18); // 0.1% tolerance

        // 1/2 of duration → 1/2 replenished
        vm.warp(block.timestamp + 6 hours);
        uint256 half = pons.mintingCurrentLimitOf(address(pontemA));
        assertApproxEqRel(half, LIMEN_A / 2, 0.001e18);

        // Full duration → fully replenished
        vm.warp(block.timestamp + 12 hours);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A);
    }

    function test_LimenNeverExceedsMax() public {
        pontemA.callMint(alice, LIMEN_A / 2);

        // Long time passes
        vm.warp(block.timestamp + 100 days);

        // Limit is fully replenished but not above max
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A);
    }

    function test_PartialUsageReplenishment() public {
        pontemA.callMint(alice, 600e18);  // 400 remaining

        vm.warp(block.timestamp + 12 hours);  // Half duration

        // Should now be: 400 + 500 = 900 (half of LIMEN_A added)
        uint256 current = pons.mintingCurrentLimitOf(address(pontemA));
        assertApproxEqRel(current, 900e18, 0.001e18);
    }

    // ============ Per-bridge isolation ============

    function test_DrainingBridgeADoesNotAffectBridgeB() public {
        pontemA.callMint(alice, LIMEN_A);

        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), 0);
        assertEq(pons.mintingCurrentLimitOf(address(pontemB)), LIMEN_B);
        assertEq(pons.mintingCurrentLimitOf(address(pontemC)), LIMEN_C);
    }

    function test_BurningLimenIsIndependentOfMintingLimen() public {
        // Mint a bunch to alice
        pontemA.callMint(alice, LIMEN_A);

        // Mint Limen drained, but burn Limen still full
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), 0);
        assertEq(pons.burningCurrentLimitOf(address(pontemA)), LIMEN_A);

        // Bridge can still burn (e.g., bridging back to source chain)
        pontemA.callBurn(alice, 100e18);
        assertEq(pons.burningCurrentLimitOf(address(pontemA)), LIMEN_A - 100e18);
    }

    // ============ Revocation ============

    function test_SetLimitToZero_RevokesBridge() public {
        vm.prank(issuer);
        pons.setLimens(address(pontemA), 0, 0);

        vm.expectRevert(IPons.Pons_LimenExceeded.selector);
        pontemA.callMint(alice, 1);
    }

    function test_RevokeAfterPartialUsage() public {
        pontemA.callMint(alice, 500e18);

        vm.prank(issuer);
        pons.setLimens(address(pontemA), 0, 0);

        vm.expectRevert(IPons.Pons_LimenExceeded.selector);
        pontemA.callMint(alice, 1);
    }

    // ============ Reconfiguration ============

    function test_IncreasingLimitCreditsBridge() public {
        // Use half of limit
        pontemA.callMint(alice, LIMEN_A / 2);
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A / 2);

        // Issuer doubles the limit
        vm.prank(issuer);
        pons.setLimens(address(pontemA), LIMEN_A * 2, LIMEN_A * 2);

        // Current limit is credited with the increase: 500 + 1000 = 1500
        uint256 current = pons.mintingCurrentLimitOf(address(pontemA));
        assertApproxEqRel(current, (LIMEN_A * 3) / 2, 0.001e18);
    }

    function test_DecreasingLimitDebitsBridge() public {
        // Use no limit
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A);

        // Issuer halves the limit
        vm.prank(issuer);
        pons.setLimens(address(pontemA), LIMEN_A / 2, LIMEN_A / 2);

        // New current limit is the new max
        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A / 2);
    }

    // ============ Access control ============

    function test_RevertWhen_NonOwnerSetsLimens() public {
        address attacker = makeAddr("attacker");
        vm.expectRevert();
        vm.prank(attacker);
        pons.setLimens(address(pontemA), 1e30, 1e30);
    }

    function test_OnlyPontifexCanSetCustodia() public {
        address attacker = makeAddr("attacker");
        vm.expectRevert(IPons.Pons_NotPontifex.selector);
        vm.prank(attacker);
        pons.setCustodia(attacker);
    }

    // ============ Fuzz ============

    function testFuzz_LimenNeverExceedsMaxAfterReplenishment(
        uint256 mintAmount,
        uint256 timeJump
    ) public {
        mintAmount = bound(mintAmount, 1, LIMEN_C);
        timeJump = bound(timeJump, 1, 365 days);

        pontemC.callMint(alice, mintAmount);
        vm.warp(block.timestamp + timeJump);

        uint256 current = pons.mintingCurrentLimitOf(address(pontemC));
        assertLe(current, LIMEN_C);
    }

    function testFuzz_PerBridgeIsolation(uint256 amountA, uint256 amountB) public {
        amountA = bound(amountA, 1, LIMEN_A);
        amountB = bound(amountB, 1, LIMEN_B);

        pontemA.callMint(alice, amountA);
        pontemB.callMint(alice, amountB);

        assertEq(pons.mintingCurrentLimitOf(address(pontemA)), LIMEN_A - amountA);
        assertEq(pons.mintingCurrentLimitOf(address(pontemB)), LIMEN_B - amountB);
        assertEq(pons.mintingCurrentLimitOf(address(pontemC)), LIMEN_C);
    }
}
