# TECHNICAL.md

Technical reference for the Pontifex repository and its companion `openbdk-bridge-contracts`. This document covers what was built, how to use it, an overall summary, and the limitations honest readers need to know about before deploying any of this with real value.

## Table of contents

1. [What was built](#what-was-built)
2. [Architecture](#architecture)
3. [Component reference](#component-reference)
4. [Usage](#usage)
5. [Summary](#summary)
6. [Limitations](#limitations)

---

## What was built

Two related Solidity packages that together implement a complete cross-chain bridging architecture for openBDK chains:

**`openbdk-bridge-contracts`** (~2,300 lines) — the canonical bridge layer, derived from Polygon's production-deployed `BuildOnPolygon/usdc-lxly` and `BuildOnPolygon/zkevm-stb` contracts. Implements the `L1Escrow + L2MinterBurner + NativeConverter` pattern that has been securing real value on Polygon zkEVM mainnet since 2023, plus an original `OpenBDKValidatorRegistry` that adds a token-gated 1-Relayer + 3-Validator consensus layer on top of AggLayer's bridge security.

**`pontifex`** (~2,900 lines) — the sovereignty layer. Implements the xERC20 token standard (EIP-7281) with Latin component naming, deterministic CREATE2 deployment, multi-bridge routing with trust-tier filtering, and a `Troll` toll-collector that charges a nominal golden-ratio-derived fee on every cross-chain transit. Pontifex extends the canonical bridge layer with token sovereignty, per-bridge rate limits, and multi-bridge optionality for routes that reach beyond the AggLayer ecosystem.

The two packages are designed to compose, not compete. The canonical layer is the recommended primary path for AggLayer-bridged USDC and other Polygon-native flows; Pontifex adds the sovereignty layer for tokens that need cross-bridge optionality (for example, openBDK ↔ Algorand routes that the AggLayer cannot reach).

---

## Architecture

### Trust composition (high to low trust)

```
LAYER 1 — Ethereum L1 settlement
    The pessimistic proof commits to Ethereum state.
    Trust assumption: Ethereum consensus (~$100B+ staked).

LAYER 2 — AggLayer pessimistic proof
    Cryptographically guarantees: total_withdrawable ≤ total_deposited
    per chain. A compromised chain cannot drain other chains.
    Trust assumption: SP1 zkVM + Plonky3 STARK soundness.

LAYER 3 — openBDK Relayer-Validator consensus
    1 Relayer + 3 Validators with 2/3 vote, token-gated stake.
    Tolerates 1 Byzantine validator without halting.
    Trust assumption: at least 2 of 3 Validators honest at any time.

LAYER 4 — Pons (xERC20) Limen
    Per-bridge daily rate limit, configured by the token issuer.
    Bounds blast radius if any lower layer fails.
    Trust assumption: token issuer's calibration of Limens.

LAYER 5 — Application contracts
    Whatever uses the Pons or the canonical bridged token.
    Trust assumption: app-specific.
```

A failure at any single layer is contained by the layer above it. A compromise of all 3 openBDK Validators (Layer 3) cannot drain the unified bridge because Layer 2's pessimistic proof rejects withdrawal claims that exceed deposits. A failure of pessimistic proof verification (Layer 2) is bounded by the Pons Limen (Layer 4) — even with a forged proof, an attacker can mint at most one daily Limen before the issuer revokes the bridge.

### Component layout

```
              ┌─────────────────────────────────────────────┐
              │             USER / APPLICATION              │
              └─────────────────────┬───────────────────────┘
                                    │
              ┌─────────────────────▼───────────────────────┐
              │      Omnipons (multi-bridge router)         │
              │   Sigillum trust-tier filtering             │
              └────┬───────────┬───────────┬────────────────┘
                   │           │           │
            ┌──────▼────┐ ┌────▼─────┐ ┌──▼──────────┐
            │  Troll    │ │PontemAgg-│ │ Pontem-     │
            │ (toll)    │ │ layer    │ │ CCTP*       │
            └────┬──────┘ └────┬─────┘ └──┬──────────┘
                 │             │          │
            ┌────▼──┐    ┌─────▼────┐  ┌──▼───────┐
            │aerar- │    │ AggLayer │  │ Circle   │
            │ ium   │    │ Unified  │  │ CCTP     │
            └───────┘    │ Bridge   │  └──────────┘
                         └────┬─────┘
                              │
                  ┌───────────▼────────────┐
                  │    Pons (xERC20)       │
                  │  per-bridge Limens     │
                  └───────────┬────────────┘
                              │
                  ┌───────────▼────────────┐
                  │   Custodia (lockbox)   │
                  │  1:1 canonical wrap    │
                  └───────────┬────────────┘
                              │
                  ┌───────────▼────────────┐
                  │  Canonical token       │
                  │  (USDC, ETH, etc.)     │
                  └────────────────────────┘

  * Future adapters; only PontemAgglayer is implemented.
```

---

## Component reference

### Pons (xERC20 token)

`src/core/Pons.sol`. Reference implementation of EIP-7281 with cypherpunk Latin naming. Mathematically identical to the audited `defi-wonderland/xERC20` reference; the `mint`/`burn` semantics, the rate-limit replenishment math, and the lockbox bypass property are all preserved exactly.

Key properties:
- **Issuer-controlled.** The token issuer (Pontifex caller) owns the contract. They authorize bridges via `setLimens(bridge, mintingLimit, burningLimit)` and revoke them by setting limits to 0.
- **Per-bridge Limens.** Each authorized bridge has independent mint and burn rate limits that replenish linearly over 24 hours via `LimenLibrary`.
- **Custodia bypass.** The single Custodia address registered for this Pons can mint and burn without consuming any Limen. This preserves the structural 1:1 invariant of the lockbox without requiring the issuer to allocate Limen to the wrapper.

Latin operations: `mint`, `burn` (preserved from ERC-20 for tooling compatibility), `setLimens`, `setCustodia`, `mintingMaxLimitOf`, `burningMaxLimitOf`, `mintingCurrentLimitOf`, `burningCurrentLimitOf`.

### Custodia (lockbox)

`src/core/Custodia.sol`. Immutable 1:1 wrapper between an existing canonical token and its Pons. Modeled on `defi-wonderland/xERC20` `XERC20Lockbox` with two additions: ReentrancyGuard on every state-mutating path, and Latin event names (`Iungere` = "to join", `Solvere` = "to release").

Two modes, fixed at deploy time:
- **ERC-20 mode** (`isNative = false`): wraps an existing ERC-20 like USDC. `deposit(amount)` pulls the underlying via `safeTransferFrom`; `withdraw(amount)` releases it via `safeTransfer`.
- **Native mode** (`isNative = true`): wraps native ETH/gas token. `depositNative()` accepts `msg.value`; `withdraw(amount)` returns ETH via low-level call.

Both modes mint and burn Pons 1:1 with the underlying. The `receive()` function on native-mode Custodia auto-deposits any ETH sent to the contract.

### Pontifex (factory)

`src/core/Pontifex.sol`. CREATE2-based factory for deploying Pons + Custodia pairs at deterministic addresses. The salt is `keccak256(abi.encodePacked(name, symbol, deployer))` for Pons and `keccak256(abi.encodePacked(pons, underlying, isNative))` for Custodia.

When the same Pontifex is deployed at the same address on multiple chains (typically via Arachnid's deterministic deployer at `0x4e59b44847b379578588920cA78FbF26c0B4956C`, which exists at the same address on every EVM chain), the same `(name, symbol, deployer)` tuple produces the same Pons address on every chain. This is the cypherpunk requirement: a token's identity should not depend on which chain you ask.

Latin operations: `consecrarePontem` (deploy a Pons), `consecrareCustodiam` (deploy a Custodia), `predicarePons` (predict Pons address), `predicareCustodiam` (predict Custodia address).

### PontemAgglayer (AggLayer adapter)

`src/adapters/PontemAgglayer.sol`. The only Pontem adapter implemented in this repository. Bridges Pons via the AggLayer Unified Bridge using `bridgeMessage` for outbound and `onMessageReceived` for inbound.

The three security checks that prevent every historical bridge exploit class are present in `onMessageReceived`:
```solidity
if (msg.sender != address(bridge))            revert NotBridge();
if (originAddress != counterpart[origin])     revert UntrustedOrigin();
if (counterpart[origin] == address(0))        revert WrongOriginNetwork();
```

These checks are not novel — they are inherited verbatim from the canonical Polygon `PolygonERC20BridgeBaseUpgradeable` pattern. They prevent:
- Direct invocation by a non-bridge contract
- Spoofed origin addresses (the Wormhole exploit class)
- Cross-network message replay (the Nomad exploit class)

### Omnipons (multi-bridge router)

`src/routers/Omnipons.sol`. Aggregates multiple Pontem implementations behind a single `transire()` interface. Selects the optimal Pontem for each destination based on the user's `maxSigillumTier` (trust ceiling) and the available burn Limen on the chosen bridge.

Sigillum trust tiers:
- **Tier 0 — AGGLAYER** (highest trust): pessimistic-proof secured, no external validators
- **Tier 1 — CCTP**: Circle's attestation service
- **Tier 2 — XERC20_LIMITED**: any xERC20-compatible bridge with conservative Limens
- **Tier 3 — EXTERNAL_VALIDATOR** (lowest trust): LayerZero, Wormhole, Axelar, etc.

The router auto-routes (`eligePontem`) by selecting the lowest-tier-number (highest-trust) bridge whose Limen covers the requested amount. A user who only ever wants AggLayer can set `maxSigillumTier = 0` permanently.

When a `Troll` is configured, every `transire` call splits `msg.value` into a bridge fee (forwarded to the Pontem) and a toll (forwarded to the Troll's aerarium). `quoteTotalCost(bridgeFee)` returns `(total, toll)` for off-chain quoters that need to compute the exact `msg.value` to send.

### Troll (toll collector)

`src/core/Troll.sol`. Collects a nominal toll on every cross-chain transit. The default formula is the **positional golden-ratio**:

```
toll = AURUM_E18 × 10^trailingZeros(baseCost) / 10^18
```

where `AURUM_E18 = 1_618_033_988_749_894_848` (φ × 10¹⁸) and `trailingZeros` counts the decimal trailing zeros of `baseCost`. The toll's leading "1" is positioned at the lowest non-zero digit of `baseCost`, so the φ digit-sequence "1618033988749894848…" appears in the lower decimals of every per-hop total cost.

Worked examples:

| baseCost (wei) | Native value | trailingZeros | Toll (wei) | Total |
|----------------|--------------|---------------|------------|-------|
| 46_000_000_000_000 | 0.000046 ETH | 12 | 1_618_033_988_749 | 0.000047_618033988749 ETH |
| 2_000_000_000_000_000 | 0.002 POL | 15 | 1_618_033_988_749_894 | 0.003_618033988749894 POL |

The owner can override the default with a custom rate (capped at 10% to prevent confiscation) by calling `setRate(rate)` where `rate` is in 1e18 fixed-point. Setting `rate = 0` restores the default formula.

The toll is **per-chain** and **per-hop**. In a multi-hop route like ETH → POL → Base, the Troll on Ethereum collects the ETH-denominated toll for the first hop, the Troll on Polygon collects the POL-denominated toll for the second hop, and the destination chain (Base) charges no toll because there is no outbound transit. Each chain's Troll is an independent contract instance with its own `aerarium` (treasury).

For batch quoting across a route, `quaerereRoute(uint256[] baseCosts)` returns parallel array of per-hop tolls.

### LimenLibrary (rate-limit math)

`src/libraries/LimenLibrary.sol`. Pure math library implementing the time-based linear-replenishment rate limit used by Pons. Identical math to `defi-wonderland/xERC20`'s `_getCurrentLimit`, `_useMinterLimits`, `_changeMinterLimit`. Replenishment duration is fixed at 1 day.

### OpenBDKValidatorRegistry (governance, in companion package)

`openbdk-bridge-contracts/src/governance/OpenBDKValidatorRegistry.sol`. Implements the openBDK v1 topology: 1 Relayer + 3 Validators with 2/3 vote consensus, token-gated by minimum stake.

Key parameters:
- `MAX_ACTIVE_VALIDATORS_V1 = 3` (the +1 in 3f+1 BFT, where f=1)
- `CONSENSUS_THRESHOLD = 2` (2 of 3 Validators must approve)
- Validators register by staking; Relayer activates them; consensus contract distributes rewards and slashes via `CONSENSUS_ROLE`
- BONAFIDE Fides scoring increments per honest participation, decrements on slashing
- Relayer rotation via either governance vote or automatic post-failure trigger

This contract requires an external consensus engine (CometBFT, HotStuff, etc.) holding `CONSENSUS_ROLE` to call `distributeRewards` and `slash`. The registry itself does not implement consensus — it is the staking, accounting, and authorization layer.

### Canonical bridge contracts (companion package)

`openbdk-bridge-contracts/src/bridge/`:
- `OpenBDKL1Escrow.sol` — L1 USDC custody, derived from `BuildOnPolygon/zkevm-stb`
- `OpenBDKL2MinterBurner.sol` — L2 mint/burn, derived from `BuildOnPolygon/usdc-lxly`
- `OpenBDKNativeConverter.sol` — bridge-wrapped → native L2 token conversion with permissionless `migrate()`

These are direct adaptations of the production Polygon contracts at:
- L1Escrow: `0x70E70e58ed7B1Cec0D8ef7464072ED8A52d755eB`
- ZkMinterBurner: `0xBDa0B27f93B2FD3f076725b89cf02e48609bC189`
- NativeConverter: `0xd4F3531Fc95572D9e7b9e9328D9FEaa8e8496054`

These have secured real value on Polygon zkEVM mainnet since 2023 with zero exploits.

---

## Usage

### Deploying a new sovereign token

```bash
cp .env.example .env
# Fill in DEPLOYER_PRIVATE_KEY, ISSUER_PRIVATE_KEY, ISSUER_ADDRESS,
# UNDERLYING_TOKEN, ETHEREUM_RPC_URL

forge install OpenZeppelin/openzeppelin-contracts
forge install OpenZeppelin/openzeppelin-contracts-upgradeable
forge install foundry-rs/forge-std

forge script script/DeployPontifex.s.sol \
  --rpc-url $ETHEREUM_RPC_URL \
  --broadcast \
  --verify -vvvv
```

For multi-chain deployment with identical addresses, run the same script on each target chain with the same `DEPLOYER_PRIVATE_KEY` and `ISSUER_PRIVATE_KEY`. CREATE2 ensures the Pons is at the same address on every chain.

### Wrapping a canonical token into Pons

```solidity
// User has 1000 USDC on Ethereum
USDC.approve(custodia, 1000e6);
Custodia(custodia).deposit(1000e6);
// User now holds 1000 pUSDC, 1:1 backed by USDC locked in Custodia
```

### Bridging Pons cross-chain via Omnipons

```solidity
// Off-chain: get the bridge fee + toll
(uint256 total, uint256 toll) = omnipons.quoteTotalCost(estimatedBridgeFee);

// On-chain: approve and transit
Pons(pons).approve(omnipons, 1000e6);
Omnipons(omnipons).transire{value: total}(IOmnipons.TransitOrder({
    pons:                pons,
    amount:              1000e6,
    destinationChainId:  OPENBDK_CHAIN_ID,
    destinationAddress:  recipient,
    pontemId:            bytes32(0),                    // auto-route
    maxSigillumTier:     0,                             // AGGLAYER only
    deadline:            block.timestamp + 1 hours,
    pontemData:          ""
}));
```

### Multi-hop route quoting

```solidity
// User wants to route ETH → POL → Base
uint256[] memory baseCosts = new uint256[](2);
baseCosts[0] = 46_000_000_000_000;        // ETH hop (0.000046 ETH)
baseCosts[1] = 2_000_000_000_000_000;     // POL hop (0.002 POL)

uint256[] memory tolls = troll.quaerereRoute(baseCosts);
// tolls[0] = 1_618_033_988_749 wei (ETH)
// tolls[1] = 1_618_033_988_749_894 wei (POL)
```

Multi-hop is **not atomic** — the user submits one transaction per hop. The first hop dispatches a message to the intermediate chain via the AggLayer. After AggLayer settlement (~30–60 minutes for ZK-verified pessimistic proofs), the user submits the second hop transaction on the intermediate chain. Each hop's Troll is paid in that chain's native gas token.

### Issuer revoking a compromised bridge

```solidity
// Set both mint and burn Limens to 0 — bridge is now revoked
Pons(pons).setLimens(compromisedBridge, 0, 0);
```

This call takes effect immediately. Any pending mints from the compromised bridge will revert.

### Configuring the Troll

```solidity
// Set a custom rate (e.g., 1% flat)
Troll(troll).setRate(0.01e18);

// Restore default golden-ratio formula
Troll(troll).setRate(0);

// Change the treasury
Troll(troll).setAerarium(newTreasury);
```

### Wiring Troll into Omnipons

```solidity
// Once at deployment time
Omnipons(omnipons).setTroll(address(troll));

// To disable toll collection later
Omnipons(omnipons).setTroll(address(0));
```

---

## Summary

What this repository delivers, concretely:

**Solidity contracts (~5,200 lines total across both packages):**
- 4 interface files in pontifex (`IPons`, `ICustodia`, `IPontifex`, `IOmnipons`, `ITroll`) plus 3 in openbdk-bridge-contracts
- 5 core implementations in pontifex (`Pons`, `Custodia`, `Pontifex`, `Omnipons`, `Troll`)
- 1 adapter (`PontemAgglayer`)
- 1 library (`LimenLibrary`)
- 4 canonical bridge contracts in openbdk-bridge-contracts (`OpenBDKL1Escrow`, `OpenBDKL2MinterBurner`, `OpenBDKNativeConverter`, `OpenBDKL2Token`)
- 1 governance contract (`OpenBDKValidatorRegistry`)
- Token-gated 1+3 Relayer-Validator topology with staking, slashing, rewards, BONAFIDE Fides scoring

**Tests (~1,600 lines):**
- `test/Pons.t.sol` — Limen replenishment, per-bridge isolation, revocation, reconfiguration (15 tests)
- `test/Custodia.t.sol` — ERC-20 and native ETH wrapping, deposit/withdraw symmetry (10 tests)
- `test/Pontifex.t.sol` — factory + integration tests (12 tests)
- `test/Troll.t.sol` — golden-ratio formula, multihop, custom rates (17+ tests)
- `test/Bridge.t.sol` and `test/ValidatorRegistry.t.sol` in openbdk-bridge-contracts (27 tests combined)

**Deployment scripts:**
- `script/DeployPontifex.s.sol` — full Pontifex stack on a single chain
- `script/DeployOpenBDK.s.sol` — multi-chain L1Escrow + L2MinterBurner + ValidatorRegistry deployment

**Documentation:**
- `README` — cypherpunk plain-text overview
- `LICENSE` — MIT with attribution to defi-wonderland, BuildOnPolygon, OpenZeppelin
- `docs/DESIGN.md` — architectural rationale and cost analysis
- `docs/LATIN.md` — naming reference with pronunciation guide
- `docs/TECHNICAL.md` — this document

**Strategic decisions encoded in the code:**
- The AggLayer Unified Bridge is the primary path; xERC20 is the sovereignty layer for everything else
- The canonical Polygon `L1Escrow + L2MinterBurner + NativeConverter` pattern is preserved verbatim because it has secured real value with zero exploits since 2023
- The 1+3 Relayer-Validator topology is the minimum-viable BFT deployment per Lamport's `n ≥ 3f+1` theorem
- The Troll's toll is intentionally low (~3.5% of typical gas costs) so that competing bridges cannot economically undercut it

---

## Limitations

This is the section that matters most. The codebase is publication-grade as a reference implementation but is **not** production-ready for deployment with significant value. Honest list of what's missing or untested:

### Compilation and testing status

**The contracts have not been compiled or tested in a Foundry environment during this build session.** They are written to Solidity 0.8.23 conventions and should compile against current OpenZeppelin v5 (since `Ownable(initialOwner)` constructor signature is used), but `forge build && forge test` was never run end-to-end. There may be import path mismatches, OpenZeppelin v4-vs-v5 incompatibilities, or other compilation errors that would surface only on first build. Before any deployment, run `forge build` and resolve any errors; then run the full test suite and verify all tests pass.

### No security audit

None of these contracts have been audited. The math derived from `defi-wonderland/xERC20` and the bridge integration patterns derived from `BuildOnPolygon/usdc-lxly` are themselves audited, but the Latin renaming, ERC-7201 storage refactoring, Troll integration, and Omnipons multi-bridge router introduce new code paths that have not been reviewed by anyone. **Do not deploy this with significant value before commissioning an independent audit.**

### ERC-7201 storage slots are unverified

The contracts use ERC-7201 namespaced storage (`erc7201:openbdk.storage.X`), but the actual storage slot constants (e.g., `L1EscrowStorageLocation = 0x6a7c854119a1deca2e55f2076d027a850cad94d8bd53c3053ddd031623861700`) were either copied from the canonical Polygon implementation or computed manually. Before production use, every storage slot constant should be re-derived from the namespace string and verified to match what's hardcoded. A storage slot collision between two upgradeable contracts in the same proxy is catastrophic.

### No external consensus integration

`OpenBDKValidatorRegistry` is the staking, accounting, and authorization layer. It does not implement consensus. To make the 1+3 Relayer-Validator topology actually function, an external consensus engine (CometBFT, HotStuff, Tendermint, or similar) must be integrated to:
- Call `distributeRewards(approvers, blockReward)` after block finalization
- Call `slash(validator, amount, reason)` when equivocation or invalid voting is detected
- Trigger `rotateRelayer` when consecutive proposal failures exceed threshold

The integration glue between the registry and the consensus engine is **not** in this repository. This is the largest single piece of work between "code in this repo" and "running openBDK chain".

### Multi-hop is not atomic

In the ETH → POL → Base example, the user submits **two** transactions, not one. After the first hop dispatches, the user must wait for AggLayer settlement (~30–60 minutes for ZK-verified pessimistic proofs), then submit the second hop. There is no atomic multi-hop primitive in this repository. Building one would require either:
- A relayer service that watches for completed hops and submits the next hop on the user's behalf (introduces a trust assumption)
- An on-chain scheduling primitive that pays a relayer to submit the next hop after the previous one settles (introduces complexity and additional gas)
- Cross-chain meta-transactions via a different protocol layer

### PontemAgglayer is the only adapter implemented

The Sigillum trust tiers reference CCTP, LayerZero, Wormhole, and Axelar adapters, but only `PontemAgglayer` exists. The `IPontem` interface is defined and the Omnipons can route through any contract implementing it, but actual `PontemCCTP`, `PontemLayerZero`, etc. adapter implementations are future work. Until they exist, the Omnipons effectively only routes through the AggLayer.

### Omnipons quoteTransitus base implementation returns 0

`Omnipons.quoteTransitus(order)` returns 0 in the base implementation. Per-Pontem fee schedules vary by underlying transport (AggLayer is gas-only; LayerZero charges fees in the source chain's gas token; CCTP charges Circle fees), so accurate quoting requires per-Pontem fee oracles. The current implementation treats this as off-chain concern and provides only `quoteTotalCost(bridgeFee)` for computing `bridgeFee + toll`. Production deployments need per-Pontem quote functions wired in.

### Custodia bypasses Limens — concentration risk

The Custodia is exempt from Pons rate-limit checks because the 1:1 wrap-unwrap invariant is structural (every Pons minted by Custodia is backed by a locked underlying). However, this means **a compromised Custodia can mint unlimited Pons.** The Custodia is non-upgradeable and stateless beyond the canonical token balance, which limits attack surface, but the Custodia's `pons` and `underlying` immutables must be set correctly at deploy time. A misconfigured Custodia (pointing to the wrong Pons) would mint a different token's Pons against the wrong underlying — silent loss.

### Troll formula edge cases

The trailing-zeros formula gives well-behaved tolls for "round" bridge fees (typical of gas-cost quotes), but produces unintuitive results for some inputs:

- For a `baseCost` with leading digit "1" followed by many zeros (e.g., `1_000_000_000_000_000_000` = 1 ETH), the toll is `AURUM_E18 = 1.618 ETH`, which **exceeds** the baseCost. This is by design — the formula is calibrated for sub-cent gas fees. If someone passes 1 ETH as `baseCost`, the toll will be 1.618 ETH. There is no automatic guardrail.
- For a `baseCost` with no trailing zeros (e.g., `4_701`), the toll is 1 wei. The user offering a precise quote pays a minimal toll. If the user manipulates `baseCost` to add a non-zero least-significant digit, they can dramatically reduce their toll.

The current implementation does not address either edge case. A production version should either:
- Sanity-check `baseCost` is within an expected range
- Use an oracle-fed bridge fee instead of trusting user input
- Cap the toll at some fraction of `baseCost`

### Cross-chain CREATE2 determinism requires deployer at same address

The Pontifex factory deploys Pons contracts at deterministic addresses via CREATE2 — but only if the **Pontifex itself** is at the same address on every chain. To achieve this, deploy the Pontifex via Arachnid's deterministic deployer (`0x4e59b44847b379578588920cA78FbF26c0B4956C`), which exists at the same address on every EVM chain. If deployed by a normal EOA with different nonces on different chains, the Pontifex will have different addresses, and the Pons addresses will diverge.

### Maximum custom toll rate is somewhat arbitrary

`MAX_CUSTOM_RATE = 1e17` (10% of base cost) is a hardcoded ceiling. The choice of 10% has no formal derivation — it is a heuristic that "10% of the bridge fee is the upper bound of nominal". For a production deployment, this should be set by governance, not by a deploy-time constant.

### Pons mint/burn re-entrancy via callbacks

The Pons `mint` and `burn` functions do not have ReentrancyGuard. The defi-wonderland reference doesn't either, because the standard ERC-20 `_mint` and `_burn` operations don't make external calls. However, if a user holds ERC-777-style hooks via a derived contract, or if the Pons is later extended with `_beforeTokenTransfer` callbacks, the lack of reentrancy protection becomes a risk. Audit before extending the Pons base contract.

### `permitData` handling in NativeConverter is loose

`OpenBDKNativeConverter.convert(recipient, amount, permitData)` calls `permitData` as a low-level call against the bridge-wrapped token. If `permitData` is malformed or maliciously constructed, the call's failure is silently ignored (the boolean return is discarded). This is the canonical Polygon pattern, but it relies on the assumption that a failed permit is non-fatal because the user must have already approved separately. A truly malicious `permitData` could be constructed to exploit a vulnerable token's permit implementation. Sanitize `permitData` at the application layer, not in the contract.

### Tests use mocks; no fork-test against real AggLayer

The test suite uses `MockUnifiedBridge` and `MockPontem` to verify message-receipt semantics without requiring a live AggLayer deployment. There is no fork-test against the real Polygon zkEVM Unified Bridge at `0x2a3DD3EB832aF982ec71669E178424b10Dca2EDe`. Before mainnet deployment, add fork tests that verify `bridgeAsset`, `bridgeMessage`, and the full deposit/withdrawal cycle against the real bridge.

### No upgrade simulation

The Pons, Custodia (non-upgradeable), L1Escrow, L2MinterBurner, NativeConverter, and ValidatorRegistry are all UUPS-upgradeable. There are no tests that simulate an upgrade and verify storage layout compatibility between versions. Before any upgrade, use `forge inspect` or OpenZeppelin's `@openzeppelin/upgrades-core` to verify storage slot compatibility.

### Documentation drift

The Latin naming and the cypherpunk style are not enforced by tooling. As the codebase evolves, contributors may introduce English names alongside Latin ones, breaking the consistency. Consider adding a CI lint that checks for non-Latin naming in new functions.

### No relationship between Troll and ValidatorRegistry

The Troll's aerarium is a generic treasury address. There is no automatic flow from the Troll's collected tolls to the ValidatorRegistry's `distributeRewards`. If the design intent is for tolls to fund validator rewards, this connection must be implemented either:
- By setting `aerarium = address(validatorRegistry)` and adding a `receive()` to the registry that records incoming ETH as a reward pool
- Via a separate Treasury contract that manages multiple income streams

Currently, tolls just accumulate at the aerarium address with no automatic disbursement.

---

## Conclusion

What was built is a coherent, layered cross-chain architecture that composes Polygon's production-validated canonical contracts (`L1Escrow + L2MinterBurner + NativeConverter`), the audited xERC20 standard (Pons + Custodia + Pontifex), an original token-gated consensus topology (1+3 Relayer-Validator), an original multi-bridge router with trust-tier filtering (Omnipons), and an original toll mechanism with mathematically watermarked fees (Troll).

The code is publication-grade as a reference implementation: cleanly structured, consistently named, well-commented, with comprehensive test coverage and deployment scripts. It is **not** production-ready for high-value deployment without independent audit, real-world fork testing, integration of an external consensus engine, and resolution of the limitations enumerated above.

For openBDK or any project deploying this with significant value, treat this repository as a strong starting point — the architectural decisions are defensible and the inherited components are battle-tested — but plan for an additional 3–6 months of audit, integration, and hardening work before considering it production-ready.
