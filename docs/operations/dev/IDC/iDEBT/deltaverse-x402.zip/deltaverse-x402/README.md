# deltaverse-x402

> DELTAVERSE integration layer: x402 payments across **mindx.pythai.net**, **bankon.pythai.net**, and **agenticplace.pythai.net**. Multi-chain (Base + Algorand via Parsec/GoPlausible), BANKON identity gating, BONAFIDE reputation pricing.

This package sits on top of [`pythai/x402-php`](https://github.com/pythai/x402-php) and ties your three DELTAVERSE services into one coherent payment-and-identity system.

## Architecture in one picture

```
┌─────────────────────┐     ┌──────────────────────┐     ┌─────────────────────┐
│   Agent / Client    │────▶│  mindx.pythai.net    │────▶│ Coinbase CDP /      │
│  (EVM or Algorand)  │     │  (x402-gated PHP)    │     │ Parsec facilitator  │
└─────────────────────┘     └──────────┬───────────┘     └──────────┬──────────┘
         │                             │                             │
         │ discovers via               │ identity check              │ on-chain
         ▼                             ▼                             ▼
┌──────────────────────┐    ┌──────────────────────┐    ┌─────────────────────┐
│ agenticplace.pythai  │    │  bankon.pythai.net   │    │    Base / Algorand  │
│ /api/v1/services     │    │  AlgoIDNFT registry  │    │    USDC transfer    │
└──────────────────────┘    └──────────────────────┘    └─────────────────────┘
```

## What you get

- **`DeltaVerseMiddleware`** — drop-in PSR-15 middleware for mindX with BANKON identity gating + BONAFIDE reputation observation.
- **`ParsecFacilitator`** — Algorand x402 facilitator client (Parsec→GoPlausible fallback, honest about what exists today).
- **`IdentityGate`** — off / soft / strict modes for cross-chain BANKON verification.
- **`ReputationClient`** — BONAFIDE Tessera score lookups with tiered discounting.
- **`DiscoveryService`** + **`AllchainMapper`** — JSON registries for AgenticPlace.
- **`DeltaVerseFactory`** — one-call setup for production or testnet.

## Install

```bash
composer require pythai/deltaverse-x402
```

Requires PHP 8.1+, `ext-gmp`, `ext-openssl`, `ext-sodium`.

## Quick start

```php
use DeltaVerse\X402\Integration\DeltaVerseFactory;
use Slim\Psr7\Factory\ResponseFactory;

$middleware = DeltaVerseFactory::forMindX(
    payToEvm: $_ENV['PAY_TO_EVM'],
    payToAlgorand: $_ENV['PAY_TO_ALGORAND'],
    responseFactory: new ResponseFactory(),
    mode: 'testnet',              // or 'production'
    bankonMode: 'off',            // or 'soft' / 'strict'
    bonafideEnabled: false,
);

$app->add($middleware);
```

Full runnable example: `examples/mindx-server.php`

## About "Parsec"

The library includes a `ParsecFacilitator` and `ParsecAlgorandWallet`. These are PYTHAI-branded abstractions that:

- Are ready for a future PYTHAI-operated Algorand facilitator at `parsec.pythai.net/facilitator`
- **Fall back to GoPlausible** (`facilitator.goplausible.xyz`) automatically today, since no "parsec-wallet" x402 library exists publicly

When your Parsec facilitator launches, just point the URL at it and everything switches over without code changes. See `docs/explanation.md` for the full rationale.

## Documentation

- **`docs/explanation.md`** — the "why": what this is, what it's not, how the pieces fit
- **`docs/technical.md`** — the "how": class-by-class breakdown and runtime flow
- **`docs/usage.md`** — the "do": operator's manual, deployment, monitoring, troubleshooting

## License

MIT — see [LICENSE](LICENSE).

## Related

- [`pythai/x402-php`](https://github.com/pythai/x402-php) — base x402 protocol library (required dependency)
- [`coinbase/x402`](https://github.com/coinbase/x402) — reference x402 implementation (TypeScript, Python, Go)
- [`GoPlausible/x402-avm`](https://github.com/GoPlausible/x402-avm) — Algorand x402 (the facilitator we fall back to)
- `mindx-x402` — the Python/FastAPI version of this integration for the reference mindX implementation
