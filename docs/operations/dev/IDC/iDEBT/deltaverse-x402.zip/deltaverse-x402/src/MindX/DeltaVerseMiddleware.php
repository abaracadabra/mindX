<?php

declare(strict_types=1);

namespace DeltaVerse\X402\MindX;

use DeltaVerse\X402\BANKON\IdentityGate;
use DeltaVerse\X402\BONAFIDE\ReputationClient;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use X402\Server\PaymentConfig;
use X402\Server\PaymentMiddleware as BaseMiddleware;

/**
 * DELTAVERSE-aware payment middleware.
 *
 * Wraps the stock X402\Server\PaymentMiddleware with two extra layers:
 *
 *   1. BANKON identity gate (applied BEFORE x402 payment)
 *      - strict mode: reject unverified payers with 403
 *      - soft mode:   allow but note that price was surcharged
 *
 *   2. BONAFIDE reputation observation
 *      - logs the discount the payer would receive (actual pricing
 *        adjustment happens in the 402 response via custom PaymentConfig)
 *
 * NOTE: The x402 protocol binds the price INTO the signed authorization.
 * You cannot change the price after signing. So reputation discounts
 * must be applied when constructing the initial 402 response, not after
 * payment. That logic belongs in a subclass of PaymentConfig — see
 * ReputationAwarePaymentConfig if you want it.
 *
 * For the first version, this middleware just:
 *   - gates at the identity layer
 *   - observes/logs reputation for analytics
 *   - delegates the actual payment protocol to the base x402 middleware
 */
final class DeltaVerseMiddleware implements MiddlewareInterface
{
    private readonly BaseMiddleware $inner;

    public function __construct(
        PaymentConfig $config,
        ResponseFactoryInterface $responseFactory,
        private readonly IdentityGate $identity,
        private readonly ReputationClient $reputation,
        private readonly LoggerInterface $logger = new NullLogger(),
    ) {
        $this->inner = new BaseMiddleware($config, $responseFactory, $logger);
    }

    public function process(
        ServerRequestInterface $request,
        RequestHandlerInterface $handler,
    ): ResponseInterface {
        // We can only do identity checks on requests that have
        // already presented a payment (because pre-payment we don't
        // know who the payer is). So we do a pre-decode of the
        // X-PAYMENT header here — if present, peek at the payer
        // and check identity before letting x402 run.

        $paymentHeader = $request->getHeaderLine('X-PAYMENT');
        if ($paymentHeader !== '') {
            try {
                $payload = \X402\Types\PaymentPayload::fromBase64($paymentHeader);
                $payer = $payload->authorization->from;

                if ($this->identity->shouldReject($payer)) {
                    $this->logger->info('bankon.rejected', [
                        'payer' => $payer,
                        'mode' => $this->identity->mode(),
                    ]);
                    return $this->forbiddenResponse($payer);
                }

                // Observe reputation — no-op if disabled
                $discount = $this->reputation->discountFactor($payer);
                if ($discount < 1.0) {
                    $this->logger->info('bonafide.discount_eligible', [
                        'payer' => $payer,
                        'discount_factor' => $discount,
                    ]);
                }
            } catch (\Throwable $e) {
                // Fall through — let the base middleware handle malformed headers
                $this->logger->debug('payment_header.peek_failed', [
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return $this->inner->process($request, $handler);
    }

    private function forbiddenResponse(string $payer): ResponseInterface
    {
        // We need a ResponseFactory but we wrapped our base middleware with one.
        // Rather than require it twice, just build a minimal response via the
        // factory inside the inner middleware using reflection would be ugly.
        // Instead, throw a specific exception that the framework can translate.
        throw new \DeltaVerse\X402\BANKON\IdentityRejectedException(
            "BANKON identity verification required. Register at https://bankon.pythai.net"
        );
    }
}
