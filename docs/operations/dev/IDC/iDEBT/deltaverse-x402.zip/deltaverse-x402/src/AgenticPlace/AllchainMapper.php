<?php

declare(strict_types=1);

namespace DeltaVerse\X402\AgenticPlace;

use DeltaVerse\X402\Config\NetworkConfig;

/**
 * Generates the chain metadata that populates allchain.html
 * on agenticplace.pythai.net.
 *
 * For each supported chain, emits:
 *   - CAIP-2 network ID
 *   - Human-friendly name
 *   - Native currency (for informational display)
 *   - USDC contract/ASA address
 *   - Facilitator URL
 *   - Block explorer base URL
 *   - RPC/indexer endpoints
 *
 * Intended use: fetch this JSON server-side, render into allchain.html
 * at build time, or consume client-side for dynamic updates.
 */
final class AllchainMapper
{
    public function build(): array
    {
        return [
            'generated_at' => date('c'),
            'chains' => [
                $this->baseMainnet(),
                $this->baseSepolia(),
                $this->algorandMainnet(),
                $this->algorandTestnet(),
            ],
        ];
    }

    public function toJson(int $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES): string
    {
        return json_encode($this->build(), $flags);
    }

    /**
     * Optional: render as an HTML table fragment for dropping into allchain.html.
     */
    public function toHtmlFragment(): string
    {
        $doc = $this->build();
        $rows = '';
        foreach ($doc['chains'] as $chain) {
            $live = $chain['live'] ? '✓' : '—';
            $rows .= sprintf(
                "  <tr>\n    <td>%s</td>\n    <td><code>%s</code></td>\n    <td>%s</td>\n    <td><code>%s</code></td>\n    <td>%s</td>\n    <td>%s</td>\n  </tr>\n",
                htmlspecialchars($chain['name']),
                htmlspecialchars($chain['network_id']),
                htmlspecialchars($chain['native']),
                htmlspecialchars((string)$chain['usdc']),
                sprintf('<a href="%s" target="_blank">facilitator</a>', htmlspecialchars($chain['facilitator'])),
                $live,
            );
        }

        return <<<HTML
<table class="allchain-table">
  <thead>
    <tr>
      <th>Chain</th><th>Network ID</th><th>Native</th><th>USDC</th><th>Facilitator</th><th>Live</th>
    </tr>
  </thead>
  <tbody>
$rows  </tbody>
</table>

HTML;
    }

    private function baseMainnet(): array
    {
        $spec = NetworkConfig::spec(NetworkConfig::BASE_MAINNET);
        return [
            'name' => 'Base',
            'network_id' => NetworkConfig::BASE_MAINNET,
            'kind' => 'evm',
            'chain_id' => $spec['chainId'],
            'native' => 'ETH',
            'usdc' => $spec['usdc'],
            'facilitator' => $spec['facilitator'],
            'rpc' => $spec['rpc'],
            'explorer' => 'https://basescan.org',
            'live' => true,
        ];
    }

    private function baseSepolia(): array
    {
        $spec = NetworkConfig::spec(NetworkConfig::BASE_SEPOLIA);
        return [
            'name' => 'Base Sepolia',
            'network_id' => NetworkConfig::BASE_SEPOLIA,
            'kind' => 'evm',
            'chain_id' => $spec['chainId'],
            'native' => 'ETH (test)',
            'usdc' => $spec['usdc'],
            'facilitator' => $spec['facilitator'],
            'rpc' => $spec['rpc'],
            'explorer' => 'https://sepolia.basescan.org',
            'live' => true,
        ];
    }

    private function algorandMainnet(): array
    {
        $spec = NetworkConfig::spec(NetworkConfig::ALGORAND_MAINNET);
        return [
            'name' => 'Algorand',
            'network_id' => NetworkConfig::ALGORAND_MAINNET,
            'kind' => 'algorand',
            'genesis' => $spec['genesisId'],
            'native' => 'ALGO',
            'usdc' => $spec['usdc'], // ASA ID (int)
            'facilitator' => $spec['facilitator'],
            'algod' => $spec['algod'],
            'indexer' => $spec['indexer'],
            'explorer' => 'https://allo.info',
            'live' => true, // via GoPlausible fallback
            'note' => 'Parsec facilitator pending; falls back to GoPlausible',
        ];
    }

    private function algorandTestnet(): array
    {
        $spec = NetworkConfig::spec(NetworkConfig::ALGORAND_TESTNET);
        return [
            'name' => 'Algorand Testnet',
            'network_id' => NetworkConfig::ALGORAND_TESTNET,
            'kind' => 'algorand',
            'genesis' => $spec['genesisId'],
            'native' => 'ALGO (test)',
            'usdc' => $spec['usdc'],
            'facilitator' => $spec['facilitator'],
            'algod' => $spec['algod'],
            'indexer' => $spec['indexer'],
            'explorer' => 'https://testnet.allo.info',
            'live' => true,
        ];
    }
}
