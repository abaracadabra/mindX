<?php

declare(strict_types=1);

namespace DeltaVerse\X402\Algorand;

/**
 * Parsec Algorand wallet abstraction.
 *
 * ─── IMPORTANT NOTE ON "PARSEC" ─────────────────────────────────
 * As of early 2026, there is NO publicly available `parsec-wallet`
 * library that implements x402 for Algorand. The only production
 * Algorand x402 implementation is GoPlausible's (at github.com/
 * GoPlausible/x402-avm and facilitator.goplausible.xyz).
 *
 * This class is intentionally an ABSTRACTION. It defines the
 * interface a PYTHAI-operated Parsec wallet WILL implement when
 * it exists. Until then, instances of this class delegate to
 * GoPlausible's facilitator for signing/settlement, using whatever
 * Algorand signing mechanism you provide.
 *
 * When Parsec launches under pythai.net, swap the delegate out —
 * no consumer code will change.
 * ────────────────────────────────────────────────────────────────
 *
 * Signing on Algorand differs from EVM:
 *   - EVM: private key signs an EIP-712 typed-data hash via ECDSA
 *   - Algorand: Ed25519 private key signs a transaction payload
 *
 * The x402 "exact" scheme on Algorand signs a TEMPLATED atomic
 * transaction group containing the USDC ASA transfer + metadata.
 * The facilitator submits the signed group on behalf of the payer.
 */
final class ParsecAlgorandWallet
{
    private function __construct(
        public readonly string $address,        // 58-char Algorand address
        private readonly string $privateKeyB64, // base64 Ed25519 private key (64 bytes)
    ) {
        if (strlen($address) !== 58) {
            throw new \InvalidArgumentException("Algorand addresses are 58 characters; got: " . strlen($address));
        }
    }

    /**
     * Construct from a base64-encoded 64-byte Ed25519 private key.
     *
     * The corresponding public key is the last 32 bytes.
     * The Algorand address is base32(pubkey || checksum).
     */
    public static function fromPrivateKey(string $privateKeyB64, string $address): self
    {
        return new self(address: $address, privateKeyB64: $privateKeyB64);
    }

    /**
     * Construct from a 25-word mnemonic (Algorand's BIP-39 variant).
     *
     * NOTE: This is a stub. A full implementation requires Algorand's
     * mnemonic wordlist and sodium-based seed derivation. For now,
     * use fromPrivateKey() directly. When Parsec launches this will
     * delegate to Parsec's keystore.
     */
    public static function fromMnemonic(string $mnemonic): self
    {
        throw new \RuntimeException(
            'Mnemonic derivation not yet implemented. '
            . 'Install "rootsoft/algorand-php-sdk" and extend this class, '
            . 'or wait for the Parsec wallet launch.'
        );
    }

    /**
     * Sign an arbitrary byte payload with Ed25519.
     *
     * Requires ext-sodium (standard in PHP 7.2+).
     *
     * @return string Raw 64-byte signature (not base64 encoded)
     */
    public function signBytes(string $payload): string
    {
        if (!function_exists('sodium_crypto_sign_detached')) {
            throw new \RuntimeException(
                'ext-sodium required for Algorand signing. '
                . 'Enable with: apt-get install php-sodium (or equivalent)'
            );
        }

        $privateKey = base64_decode($this->privateKeyB64, true);
        if ($privateKey === false || strlen($privateKey) !== 64) {
            throw new \RuntimeException('Invalid Ed25519 private key: expected 64 bytes decoded');
        }

        return sodium_crypto_sign_detached($payload, $privateKey);
    }

    /**
     * Sign a base64-encoded payload (Algorand transactions are typically
     * msgpack-encoded, then the bytes are signed).
     */
    public function signBase64(string $payloadB64): string
    {
        $bytes = base64_decode($payloadB64, true);
        if ($bytes === false) {
            throw new \InvalidArgumentException('Invalid base64 payload');
        }
        return base64_encode($this->signBytes($bytes));
    }

    /**
     * Return the public key (32 bytes) decoded from the Algorand address.
     */
    public function publicKey(): string
    {
        // Algorand address format: base32(pubkey || sha512_256(pubkey)[:4])
        // We don't strictly need to decode here for signing, but it's useful
        // for address verification.
        $decoded = self::base32Decode($this->address);
        if ($decoded === null || strlen($decoded) !== 36) {
            throw new \RuntimeException('Invalid Algorand address format');
        }
        return substr($decoded, 0, 32);
    }

    /**
     * Minimal base32 decoder for Algorand addresses (RFC 4648, no padding).
     */
    private static function base32Decode(string $address): ?string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $address = strtoupper($address);
        $binary = '';
        $buffer = 0;
        $bits = 0;
        foreach (str_split($address) as $char) {
            $index = strpos($alphabet, $char);
            if ($index === false) {
                return null;
            }
            $buffer = ($buffer << 5) | $index;
            $bits += 5;
            if ($bits >= 8) {
                $bits -= 8;
                $binary .= chr(($buffer >> $bits) & 0xFF);
            }
        }
        return $binary;
    }
}
