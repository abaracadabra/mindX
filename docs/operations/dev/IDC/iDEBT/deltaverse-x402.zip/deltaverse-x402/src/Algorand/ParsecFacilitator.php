<?php

declare(strict_types=1);

namespace DeltaVerse\X402\Algorand;

use DeltaVerse\X402\Config\NetworkConfig;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use X402\Exception\FacilitatorException;
use X402\Facilitator\FacilitatorClient;
use X402\Facilitator\VerificationResult;
use X402\Types\PaymentOption;
use X402\Types\PaymentPayload;
use X402\Types\SettlementReceipt;

/**
 * Parsec Algorand facilitator client.
 *
 * ─── HONEST DESIGN NOTE ───────────────────────────────────────────
 * "Parsec" is the name PYTHAI intends to use for its own Algorand
 * facilitator when deployed. Today, no such facilitator exists
 * publicly. The ONLY production Algorand x402 facilitator right now
 * is GoPlausible's at facilitator.goplausible.xyz.
 *
 * This client:
 *   1. Tries the Parsec URL first (parsec.pythai.net/facilitator)
 *   2. On connection failure or 404, falls back to GoPlausible
 *   3. Logs the fallback so you know which one handled the tx
 *
 * Swap the primary URL to GoPlausible directly if you prefer to skip
 * the fallback probe (saves ~200ms latency).
 * ──────────────────────────────────────────────────────────────────
 */
final class ParsecFacilitator implements FacilitatorClient
{
    private Client $parsec;
    private Client $fallback;

    public function __construct(
        ?Client $parsecClient = null,
        ?Client $fallbackClient = null,
        private readonly LoggerInterface $logger = new NullLogger(),
        private readonly bool $useFallbackImmediately = false,
    ) {
        $this->parsec = $parsecClient ?? new Client([
            'base_uri' => rtrim(NetworkConfig::FACILITATOR_PARSEC, '/') . '/',
            'timeout' => 10.0,
            'http_errors' => false,
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'User-Agent' => 'deltaverse-x402/1.0',
            ],
        ]);
        $this->fallback = $fallbackClient ?? new Client([
            'base_uri' => rtrim(NetworkConfig::FACILITATOR_GOPLAUSIBLE, '/') . '/',
            'timeout' => 10.0,
            'http_errors' => false,
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'User-Agent' => 'deltaverse-x402/1.0',
            ],
        ]);
    }

    public function verify(PaymentPayload $payload, PaymentOption $option): VerificationResult
    {
        $body = [
            'paymentPayload' => $payload->toArray(),
            'paymentRequirements' => $option->toArray(),
        ];
        $response = $this->postWithFallback('verify', $body);
        return VerificationResult::fromArray($response);
    }

    public function settle(PaymentPayload $payload, PaymentOption $option): SettlementReceipt
    {
        $body = [
            'paymentPayload' => $payload->toArray(),
            'paymentRequirements' => $option->toArray(),
        ];
        $response = $this->postWithFallback('settle', $body);
        $receipt = SettlementReceipt::fromArray($response);

        if (!$receipt->success) {
            throw new FacilitatorException(
                'Algorand settlement failed: ' . ($receipt->errorReason ?? 'unknown'),
                errorReason: $receipt->errorReason,
                facilitatorResponse: $response,
            );
        }

        $this->logger->info('algorand.settled', [
            'tx' => $receipt->transaction,
            'network' => $receipt->network,
        ]);

        return $receipt;
    }

    public function supported(): array
    {
        try {
            $response = $this->parsec->get('supported');
            if ($response->getStatusCode() < 400) {
                $data = json_decode((string)$response->getBody(), true);
                return $data['kinds'] ?? $data['supported'] ?? [];
            }
        } catch (GuzzleException) {
            // fall through
        }

        $response = $this->fallback->get('supported');
        $data = json_decode((string)$response->getBody(), true);
        return $data['kinds'] ?? $data['supported'] ?? [];
    }

    /**
     * Try Parsec first, fall back to GoPlausible if it's unreachable.
     *
     * @return array Decoded JSON response
     */
    private function postWithFallback(string $endpoint, array $body): array
    {
        if (!$this->useFallbackImmediately) {
            try {
                $response = $this->parsec->post($endpoint, ['json' => $body]);
                $status = $response->getStatusCode();
                if ($status < 500 && $status !== 404) {
                    $decoded = json_decode((string)$response->getBody(), true);
                    if (is_array($decoded)) {
                        $this->logger->debug('facilitator.parsec.ok', ['endpoint' => $endpoint]);
                        return $decoded;
                    }
                }
                $this->logger->info('facilitator.parsec.unavailable', [
                    'endpoint' => $endpoint, 'status' => $status,
                ]);
            } catch (GuzzleException $e) {
                $this->logger->info('facilitator.parsec.error', [
                    'endpoint' => $endpoint, 'error' => $e->getMessage(),
                ]);
            }
        }

        // Fall back to GoPlausible
        try {
            $response = $this->fallback->post($endpoint, ['json' => $body]);
            $decoded = json_decode((string)$response->getBody(), true);
            if (!is_array($decoded)) {
                throw new FacilitatorException(
                    "GoPlausible /$endpoint returned non-JSON response"
                );
            }
            $this->logger->info('facilitator.goplausible.ok', ['endpoint' => $endpoint]);
            return $decoded;
        } catch (GuzzleException $e) {
            throw new FacilitatorException(
                "Both Parsec and GoPlausible failed for /$endpoint: " . $e->getMessage(),
                previous: $e,
            );
        }
    }
}
