<?php

declare(strict_types=1);

namespace DeltaVerse\X402\AgenticPlace;

use DeltaVerse\X402\Config\DomainConfig;
use DeltaVerse\X402\Config\NetworkConfig;

/**
 * Builds the machine-readable service registry for AgenticPlace.
 *
 * Output format mirrors the x402 Bazaar discovery shape so any
 * agent that understands Bazaar can consume PYTHAI services too.
 *
 * Serve this JSON at agenticplace.pythai.net/api/v1/services.
 * Link it from allchain.html so human browsers can see it.
 */
final class DiscoveryService
{
    /**
     * @param string[] $networks Accepted networks (e.g. ["eip155:8453", "algorand:mainnet-v1.0"])
     */
    public function __construct(
        private readonly string $basePayToEvm,
        private readonly string $basePayToAlgorand,
        private readonly array $networks = [
            NetworkConfig::BASE_MAINNET,
            NetworkConfig::ALGORAND_MAINNET,
        ],
        private readonly bool $bankonRequired = false,
    ) {
    }

    /**
     * @return array The full discovery document.
     */
    public function build(): array
    {
        return [
            'version' => '1.0',
            'generated_at' => date('c'),
            'registry_url' => DomainConfig::AGENTICPLACE_DISCOVERY,
            'services' => [
                $this->mindxService(),
                $this->bankonService(),
                $this->agenticplaceSelf(),
            ],
        ];
    }

    public function toJson(int $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES): string
    {
        return json_encode($this->build(), $flags);
    }

    private function mindxService(): array
    {
        $endpoints = [];
        foreach (DomainConfig::MINDX_ENDPOINTS as $key => $meta) {
            [$method, $path] = explode(' ', $key, 2);
            $endpoints[] = [
                'method' => $method,
                'path' => $path,
                'full_url' => DomainConfig::MINDX_API_BASE . $path,
                'price' => $meta['price'],
                'description' => $meta['description'] ?? null,
            ];
        }

        $paymentOptions = [];
        foreach ($this->networks as $network) {
            $spec = NetworkConfig::spec($network);
            $paymentOptions[] = [
                'scheme' => 'exact',
                'network' => $network,
                'asset' => (string)$spec['usdc'],
                'pay_to' => $spec['kind'] === 'evm' ? $this->basePayToEvm : $this->basePayToAlgorand,
                'facilitator' => $spec['facilitator'],
            ];
        }

        return [
            'id' => 'mindx',
            'name' => 'mindX reasoning API',
            'description' => 'Consciousness reasoning, Socratic chains, and generative inference',
            'base_url' => DomainConfig::MINDX_API_BASE,
            'openapi_url' => DomainConfig::MINDX_OPENAPI_JSON,
            'redoc_url' => DomainConfig::MINDX_OPENAPI_URL,
            'x402' => [
                'supported' => true,
                'payment_options' => $paymentOptions,
                'endpoints' => $endpoints,
            ],
            'bankon_required' => $this->bankonRequired,
        ];
    }

    private function bankonService(): array
    {
        return [
            'id' => 'bankon',
            'name' => 'BANKON identity',
            'description' => 'Cross-chain identity registry — link your wallet to a BANKON AlgoIDNFT',
            'base_url' => DomainConfig::BANKON_BASE_URL,
            'registry_api' => DomainConfig::BANKON_REGISTRY_API,
            'algoidnft_asset_id' => DomainConfig::BANKON_ALGOIDNFT_ASSET_ID,
            'x402' => ['supported' => false],
            'free' => true,
        ];
    }

    private function agenticplaceSelf(): array
    {
        return [
            'id' => 'agenticplace',
            'name' => 'AgenticPlace discovery',
            'description' => 'This registry. Free to query.',
            'base_url' => DomainConfig::AGENTICPLACE_BASE_URL,
            'discovery_url' => DomainConfig::AGENTICPLACE_DISCOVERY,
            'allchain_url' => DomainConfig::AGENTICPLACE_ALLCHAIN,
            'x402' => ['supported' => false],
            'free' => true,
        ];
    }
}
