<?php

declare(strict_types=1);

namespace DeltaVerse\X402\Config;

/**
 * Multi-chain network configuration.
 *
 * DELTAVERSE accepts payments on:
 *   - Base mainnet (primary, for EVM-native agents)
 *   - Algorand mainnet (for BANKON-native agents, lower fees)
 *
 * Each network has:
 *   - x402 network identifier (CAIP-2 format)
 *   - Chain ID (EVM) or genesis ID (Algorand)
 *   - USDC token contract/asset
 *   - Facilitator URL
 *   - Token metadata (for EIP-712 on EVM; ASA params on Algorand)
 */
final class NetworkConfig
{
    // ─── Chain identifiers ─────────────────────────────────────
    public const BASE_MAINNET       = 'eip155:8453';
    public const BASE_SEPOLIA       = 'eip155:84532';
    public const ALGORAND_MAINNET   = 'algorand:mainnet-v1.0';
    public const ALGORAND_TESTNET   = 'algorand:testnet-v1.0';

    // ─── EVM USDC addresses ────────────────────────────────────
    public const BASE_MAINNET_USDC  = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';
    public const BASE_SEPOLIA_USDC  = '0x036CbD53842c5426634e7929541eC2318f3dCF7e';

    // ─── Algorand USDC ASA IDs ─────────────────────────────────
    public const ALGORAND_MAINNET_USDC_ASSET_ID = 31566704;
    public const ALGORAND_TESTNET_USDC_ASSET_ID = 10458941;

    // ─── Facilitator URLs ──────────────────────────────────────
    public const FACILITATOR_CDP_MAINNET   = 'https://api.cdp.coinbase.com/platform/v2/x402';
    public const FACILITATOR_PUBLIC_TEST   = 'https://x402.org/facilitator';
    public const FACILITATOR_GOPLAUSIBLE   = 'https://facilitator.goplausible.xyz';

    /**
     * Parsec facilitator URL — placeholder for a future PYTHAI-operated
     * Algorand facilitator. Until deployed, this falls back to GoPlausible
     * at runtime (see ParsecFacilitator).
     */
    public const FACILITATOR_PARSEC        = 'https://parsec.pythai.net/facilitator';

    // ─── RPC endpoints ─────────────────────────────────────────
    public const BASE_MAINNET_RPC   = 'https://mainnet.base.org';
    public const BASE_SEPOLIA_RPC   = 'https://sepolia.base.org';
    public const ALGORAND_MAINNET_ALGOD   = 'https://mainnet-api.algonode.cloud';
    public const ALGORAND_MAINNET_INDEXER = 'https://mainnet-idx.algonode.cloud';
    public const ALGORAND_TESTNET_ALGOD   = 'https://testnet-api.algonode.cloud';
    public const ALGORAND_TESTNET_INDEXER = 'https://testnet-idx.algonode.cloud';

    /**
     * Return the full network spec for a given network ID.
     *
     * @return array{
     *   chainId?: int,
     *   genesisId?: string,
     *   usdc: string|int,
     *   facilitator: string,
     *   rpc?: string,
     *   algod?: string,
     *   indexer?: string,
     *   kind: "evm"|"algorand"
     * }
     */
    public static function spec(string $network): array
    {
        return match ($network) {
            self::BASE_MAINNET => [
                'kind' => 'evm',
                'chainId' => 8453,
                'usdc' => self::BASE_MAINNET_USDC,
                'facilitator' => self::FACILITATOR_CDP_MAINNET,
                'rpc' => self::BASE_MAINNET_RPC,
                'usdcName' => 'USD Coin',
                'usdcVersion' => '2',
            ],
            self::BASE_SEPOLIA => [
                'kind' => 'evm',
                'chainId' => 84532,
                'usdc' => self::BASE_SEPOLIA_USDC,
                'facilitator' => self::FACILITATOR_PUBLIC_TEST,
                'rpc' => self::BASE_SEPOLIA_RPC,
                'usdcName' => 'USDC',
                'usdcVersion' => '2',
            ],
            self::ALGORAND_MAINNET => [
                'kind' => 'algorand',
                'genesisId' => 'mainnet-v1.0',
                'usdc' => self::ALGORAND_MAINNET_USDC_ASSET_ID,
                'facilitator' => self::FACILITATOR_PARSEC, // runtime fallback to GoPlausible
                'algod' => self::ALGORAND_MAINNET_ALGOD,
                'indexer' => self::ALGORAND_MAINNET_INDEXER,
            ],
            self::ALGORAND_TESTNET => [
                'kind' => 'algorand',
                'genesisId' => 'testnet-v1.0',
                'usdc' => self::ALGORAND_TESTNET_USDC_ASSET_ID,
                'facilitator' => self::FACILITATOR_GOPLAUSIBLE,
                'algod' => self::ALGORAND_TESTNET_ALGOD,
                'indexer' => self::ALGORAND_TESTNET_INDEXER,
            ],
            default => throw new \InvalidArgumentException("Unknown network: $network"),
        };
    }

    public static function isEvm(string $network): bool
    {
        return str_starts_with($network, 'eip155:');
    }

    public static function isAlgorand(string $network): bool
    {
        return str_starts_with($network, 'algorand:');
    }
}
