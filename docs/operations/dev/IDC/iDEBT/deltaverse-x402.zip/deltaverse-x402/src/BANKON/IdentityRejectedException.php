<?php

declare(strict_types=1);

namespace DeltaVerse\X402\BANKON;

/**
 * Thrown when BANKON identity gate rejects a request in strict mode.
 *
 * The calling framework should catch this and return HTTP 403 Forbidden
 * with a body explaining the registration URL.
 */
final class IdentityRejectedException extends \RuntimeException
{
}
