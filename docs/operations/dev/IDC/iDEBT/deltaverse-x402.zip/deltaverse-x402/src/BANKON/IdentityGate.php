<?php

declare(strict_types=1);

namespace DeltaVerse\X402\BANKON;

use DeltaVerse\X402\Config\DomainConfig;
use DeltaVerse\X402\Config\NetworkConfig;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;

/**
 * BANKON identity gating.
 *
 * Checks whether a payer's wallet is linked to a verified BANKON
 * AlgoIDNFT (soulbound identity ASA on Algorand).
 *
 * Three modes:
 *   off     — never check (default)
 *   soft    — allow unverified payers but apply 2x surcharge
 *   strict  — reject unverified payers with 403
 *
 * Cross-chain lookup:
 *   1. Payer signs on Base (or Algorand) with address X
 *   2. BANKON registry at bankon.pythai.net maps X → Algorand address Y
 *   3. Algorand indexer confirms Y holds the AlgoIDNFT ASA
 *
 * Results are cached for 5 minutes to avoid hammering the registry.
 */
final class IdentityGate
{
    public const MODE_OFF    = 'off';
    public const MODE_SOFT   = 'soft';
    public const MODE_STRICT = 'strict';

    /** @var array<string, array{verified: bool, expires: int}> */
    private array $cache = [];

    public function __construct(
        private readonly string $mode = self::MODE_OFF,
        private readonly int $algoidnftAssetId = DomainConfig::BANKON_ALGOIDNFT_ASSET_ID,
        private readonly string $bankonApiUrl = DomainConfig::BANKON_REGISTRY_API,
        private readonly string $algoIndexerUrl = NetworkConfig::ALGORAND_MAINNET_INDEXER,
        private readonly ?Client $http = null,
        private readonly LoggerInterface $logger = new NullLogger(),
        private readonly int $cacheTtlSeconds = 300,
    ) {
    }

    public function mode(): string
    {
        return $this->mode;
    }

    public function isEnabled(): bool
    {
        return $this->mode !== self::MODE_OFF;
    }

    /**
     * Check whether a wallet is BANKON-verified.
     *
     * Accepts either an EVM address (0x...) or an Algorand address (58 chars).
     * Returns true if the wallet's linked Algorand account holds the AlgoIDNFT.
     *
     * Returns false on any error — fail-closed, so strict mode rejects on failures.
     */
    public function isVerified(string $walletAddress): bool
    {
        if ($this->mode === self::MODE_OFF) {
            return true;
        }

        // Cache hit?
        $key = strtolower($walletAddress);
        if (isset($this->cache[$key]) && $this->cache[$key]['expires'] > time()) {
            return $this->cache[$key]['verified'];
        }

        $verified = $this->doCheck($walletAddress);

        $this->cache[$key] = [
            'verified' => $verified,
            'expires' => time() + $this->cacheTtlSeconds,
        ];

        return $verified;
    }

    /**
     * Price multiplier to apply based on verification status.
     *
     * In soft mode, unverified payers pay 2x. In strict mode they don't
     * get here (rejected earlier). In off mode, everyone pays 1x.
     */
    public function priceMultiplier(string $walletAddress): float
    {
        if ($this->mode !== self::MODE_SOFT) {
            return 1.0;
        }
        return $this->isVerified($walletAddress) ? 1.0 : 2.0;
    }

    /**
     * Should the request be rejected at the identity layer?
     */
    public function shouldReject(string $walletAddress): bool
    {
        if ($this->mode !== self::MODE_STRICT) {
            return false;
        }
        return !$this->isVerified($walletAddress);
    }

    /**
     * Perform the actual two-hop check:
     *   1. Ask bankon.pythai.net for the Algorand address linked to this wallet
     *   2. Ask the Algorand indexer if that Algo address holds the AlgoIDNFT
     */
    private function doCheck(string $walletAddress): bool
    {
        if ($this->algoidnftAssetId === 0) {
            $this->logger->warning('bankon.identity.check_skipped', [
                'reason' => 'ALGOIDNFT_ASSET_ID not configured',
            ]);
            return false;
        }

        $http = $this->http ?? new Client(['timeout' => 5.0, 'http_errors' => false]);

        // Hop 1: wallet → Algorand address
        $algoAddress = $this->lookupAlgorandAddress($walletAddress, $http);
        if ($algoAddress === null) {
            $this->logger->info('bankon.identity.unlinked', ['wallet' => $walletAddress]);
            return false;
        }

        // If the input was already an Algorand address, hop 1 is a no-op
        if ($algoAddress === $walletAddress) {
            $algoAddress = $walletAddress;
        }

        // Hop 2: Algorand indexer → ASA balance
        try {
            $url = rtrim($this->algoIndexerUrl, '/')
                 . "/v2/accounts/$algoAddress/assets?asset-id={$this->algoidnftAssetId}";
            $response = $http->get($url);
            if ($response->getStatusCode() !== 200) {
                return false;
            }
            $data = json_decode((string)$response->getBody(), true);
            foreach ($data['assets'] ?? [] as $asset) {
                if (
                    (int)($asset['asset-id'] ?? 0) === $this->algoidnftAssetId
                    && (int)($asset['amount'] ?? 0) > 0
                ) {
                    return true;
                }
            }
        } catch (GuzzleException $e) {
            $this->logger->warning('bankon.indexer.error', ['error' => $e->getMessage()]);
        }

        return false;
    }

    private function lookupAlgorandAddress(string $walletAddress, Client $http): ?string
    {
        // If input is already an Algorand address, no registry hop needed
        if (strlen($walletAddress) === 58 && ctype_alnum($walletAddress)) {
            return $walletAddress;
        }

        try {
            $url = rtrim($this->bankonApiUrl, '/') . "/lookup?wallet=" . urlencode($walletAddress);
            $response = $http->get($url);
            if ($response->getStatusCode() !== 200) {
                return null;
            }
            $data = json_decode((string)$response->getBody(), true);
            $algo = $data['algorand_address'] ?? null;
            return is_string($algo) && strlen($algo) === 58 ? $algo : null;
        } catch (GuzzleException $e) {
            $this->logger->warning('bankon.registry.error', ['error' => $e->getMessage()]);
            return null;
        }
    }
}
