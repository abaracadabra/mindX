<?php

declare(strict_types=1);

namespace DeltaVerse\X402\Config;

/**
 * Canonical configuration for the three DELTAVERSE domains.
 *
 *   mindx.pythai.net          — reasoning API (the product being sold)
 *   agenticplace.pythai.net   — marketplace / discovery (the town square)
 *   bankon.pythai.net         — identity / tokenization (the ID card)
 *
 * This is the single source of truth for URLs. Don't hardcode
 * these elsewhere — pull from here.
 */
final class DomainConfig
{
    // ─── Domain URLs ─────────────────────────────────────────
    public const MINDX_BASE_URL        = 'https://mindx.pythai.net';
    public const MINDX_API_BASE        = 'https://mindx.pythai.net/pay';
    public const MINDX_OPENAPI_URL     = 'https://mindx.pythai.net/redoc';
    public const MINDX_OPENAPI_JSON    = 'https://mindx.pythai.net/openapi.json';

    public const AGENTICPLACE_BASE_URL = 'https://agenticplace.pythai.net';
    public const AGENTICPLACE_DISCOVERY = 'https://agenticplace.pythai.net/api/v1/services';
    public const AGENTICPLACE_ALLCHAIN  = 'https://agenticplace.pythai.net/allchain.html';

    public const BANKON_BASE_URL       = 'https://bankon.pythai.net';
    public const BANKON_REGISTRY_API   = 'https://bankon.pythai.net/api/v1/identity';
    public const BANKON_ALGOIDNFT_ASSET_ID = 0; // set this to your real ASA ID

    // ─── mindX paid endpoint catalog ─────────────────────────
    // Maps endpoint → price in USD. x402 SDK converts to base units.
    public const MINDX_ENDPOINTS = [
        'GET /api/v1/reason'          => ['price' => '$0.001', 'description' => 'Short reasoning'],
        'POST /api/v1/socratic'       => ['price' => '$0.01',  'description' => 'Full Socratic chain'],
        'POST /api/v1/dream'          => ['price' => '$0.05',  'description' => 'Generative reasoning'],
        'GET /api/v1/agents/discover' => ['price' => '$0.0001','description' => 'Agent marketplace discovery'],
    ];

    // ─── BONAFIDE reputation contracts (fill in after deploy) ─
    public const BONAFIDE_GENIUS       = '';
    public const BONAFIDE_TESSERA      = '';
    public const BONAFIDE_BONATOKEN    = '';

    public static function mindxEndpointKeys(): array
    {
        return array_keys(self::MINDX_ENDPOINTS);
    }

    public static function mindxPriceFor(string $endpointKey): string
    {
        if (!isset(self::MINDX_ENDPOINTS[$endpointKey])) {
            throw new \InvalidArgumentException("Unknown mindX endpoint: $endpointKey");
        }
        return self::MINDX_ENDPOINTS[$endpointKey]['price'];
    }
}
