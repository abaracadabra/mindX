<?php

declare(strict_types=1);

namespace DeltaVerse\X402\BONAFIDE;

use DeltaVerse\X402\Config\DomainConfig;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;

/**
 * BONAFIDE reputation-based pricing discounts.
 *
 * BONAFIDE is the PYTHAI constitutional reputation system
 * (Genius, BonaToken, Tabularium, Fides, SponsioPactum,
 * Censura, Senatus, Tessera — 9 contracts in total). The
 * Tessera contract publishes reputation scores for addresses.
 *
 * Default pricing tiers:
 *   score >= 800  → 50% off  (top-tier, established agents)
 *   score >= 500  → 25% off  (verified, reputable)
 *   score <  500  → full price (new or low-reputation)
 *
 * Scores are cached for 1 hour — reputation changes slowly.
 *
 * If BONAFIDE contracts aren't deployed yet, set `enabled: false`
 * and this becomes a no-op returning 1.0 for everyone.
 */
final class ReputationClient
{
    /** @var array<string, array{score: int, expires: int}> */
    private array $cache = [];

    public function __construct(
        private readonly bool $enabled = false,
        private readonly string $tesseraAddress = DomainConfig::BONAFIDE_TESSERA,
        private readonly string $rpcUrl = 'https://mainnet.base.org',
        private readonly ?Client $http = null,
        private readonly LoggerInterface $logger = new NullLogger(),
        private readonly int $cacheTtlSeconds = 3600,
    ) {
    }

    /**
     * Returns a price multiplier in (0, 1] based on reputation.
     *
     *   1.0  = full price (default)
     *   0.75 = 25% discount (mid-tier)
     *   0.5  = 50% discount (top-tier)
     */
    public function discountFactor(string $address): float
    {
        if (!$this->enabled) {
            return 1.0;
        }

        $score = $this->scoreOf($address);
        if ($score >= 800) {
            return 0.5;
        }
        if ($score >= 500) {
            return 0.75;
        }
        return 1.0;
    }

    public function scoreOf(string $address): int
    {
        if (!$this->enabled || $this->tesseraAddress === '') {
            return 0;
        }

        $key = strtolower($address);
        if (isset($this->cache[$key]) && $this->cache[$key]['expires'] > time()) {
            return $this->cache[$key]['score'];
        }

        $score = $this->fetchScore($address);

        $this->cache[$key] = [
            'score' => $score,
            'expires' => time() + $this->cacheTtlSeconds,
        ];

        return $score;
    }

    /**
     * Call Tessera.scoreOf(address) via eth_call.
     *
     * This uses raw JSON-RPC so we don't need a heavyweight web3 PHP library.
     * Function selector for scoreOf(address) is the first 4 bytes of
     * keccak256("scoreOf(address)") = 0xbf715a86
     */
    private function fetchScore(string $address): int
    {
        $http = $this->http ?? new Client(['timeout' => 5.0, 'http_errors' => false]);

        // ABI-encode the call: selector (4 bytes) + padded address (32 bytes)
        $selector = '0xbf715a86';
        $paddedAddress = str_pad(substr($address, 2), 64, '0', STR_PAD_LEFT);
        $data = $selector . $paddedAddress;

        $payload = [
            'jsonrpc' => '2.0',
            'method' => 'eth_call',
            'params' => [
                ['to' => $this->tesseraAddress, 'data' => $data],
                'latest',
            ],
            'id' => 1,
        ];

        try {
            $response = $http->post($this->rpcUrl, ['json' => $payload]);
            $data = json_decode((string)$response->getBody(), true);
            if (!isset($data['result'])) {
                return 0;
            }
            $hex = $data['result'];
            if ($hex === '0x' || $hex === '0x0') {
                return 0;
            }
            // Decode uint256 result — GMP handles big numbers
            return (int)gmp_strval(gmp_init($hex, 16), 10);
        } catch (GuzzleException $e) {
            $this->logger->warning('bonafide.rpc.error', ['error' => $e->getMessage()]);
            return 0;
        }
    }
}
