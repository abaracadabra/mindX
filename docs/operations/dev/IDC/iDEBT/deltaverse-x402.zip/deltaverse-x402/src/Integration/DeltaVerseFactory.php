<?php

declare(strict_types=1);

namespace DeltaVerse\X402\Integration;

use DeltaVerse\X402\Algorand\ParsecFacilitator;
use DeltaVerse\X402\BANKON\IdentityGate;
use DeltaVerse\X402\BONAFIDE\ReputationClient;
use DeltaVerse\X402\Config\DomainConfig;
use DeltaVerse\X402\Config\NetworkConfig;
use DeltaVerse\X402\MindX\DeltaVerseMiddleware;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Log\LoggerInterface;
use Psr\Log\NullLogger;
use X402\Facilitator\FacilitatorClient;
use X402\Facilitator\HttpFacilitatorClient;
use X402\Server\PaymentConfig;

/**
 * One-stop factory for assembling a production DELTAVERSE middleware.
 *
 * Usage:
 *   $mw = DeltaVerseFactory::forMindX(
 *       payToEvm: '0x...',
 *       payToAlgorand: 'ALGO58CHAR...',
 *       responseFactory: $psr17ResponseFactory,
 *       mode: 'production',           // or 'testnet'
 *       bankonMode: 'soft',           // off | soft | strict
 *       bonafideEnabled: true,
 *   );
 *   $app->add($mw);
 */
final class DeltaVerseFactory
{
    /**
     * Build a full DELTAVERSE payment middleware for mindX.
     *
     * In production mode: Base mainnet + Algorand mainnet (via Parsec→GoPlausible fallback).
     * In testnet mode:    Base Sepolia + Algorand testnet.
     */
    public static function forMindX(
        string $payToEvm,
        string $payToAlgorand,
        ResponseFactoryInterface $responseFactory,
        string $mode = 'production',
        string $bankonMode = IdentityGate::MODE_OFF,
        bool $bonafideEnabled = false,
        ?string $cdpApiKeyId = null,
        ?string $cdpApiKeySecret = null,
        LoggerInterface $logger = new NullLogger(),
    ): DeltaVerseMiddleware {
        $isTestnet = $mode !== 'production';
        $evmNetwork = $isTestnet ? NetworkConfig::BASE_SEPOLIA : NetworkConfig::BASE_MAINNET;

        // Build the EVM facilitator (CDP in prod, public in testnet)
        $evmFacilitator = self::buildEvmFacilitator(
            $isTestnet,
            $cdpApiKeyId,
            $cdpApiKeySecret,
            $logger,
        );

        // PaymentConfig governs Base endpoints. For Algorand we'd register
        // a second PaymentConfig or use a multi-chain server — for this
        // reference implementation we gate Base via x402-php stock middleware
        // and offer Algorand as a parallel track.
        $paymentConfig = new PaymentConfig(
            payToAddress: $payToEvm,
            network: $evmNetwork,
            facilitator: $evmFacilitator,
            routes: DomainConfig::MINDX_ENDPOINTS,
        );

        // BANKON identity gate
        $identity = new IdentityGate(
            mode: $bankonMode,
            logger: $logger,
        );

        // BONAFIDE reputation client
        $reputation = new ReputationClient(
            enabled: $bonafideEnabled,
            logger: $logger,
        );

        return new DeltaVerseMiddleware(
            config: $paymentConfig,
            responseFactory: $responseFactory,
            identity: $identity,
            reputation: $reputation,
            logger: $logger,
        );
    }

    /**
     * Build an Algorand-specific facilitator (Parsec→GoPlausible fallback).
     *
     * Use this for an Algorand-only payment track or to register alongside
     * the EVM facilitator in a multi-chain server.
     */
    public static function algorandFacilitator(
        LoggerInterface $logger = new NullLogger(),
        bool $useFallbackImmediately = false,
    ): ParsecFacilitator {
        return new ParsecFacilitator(
            logger: $logger,
            useFallbackImmediately: $useFallbackImmediately,
        );
    }

    private static function buildEvmFacilitator(
        bool $isTestnet,
        ?string $cdpApiKeyId,
        ?string $cdpApiKeySecret,
        LoggerInterface $logger,
    ): FacilitatorClient {
        if ($isTestnet) {
            return new HttpFacilitatorClient(
                baseUrl: NetworkConfig::FACILITATOR_PUBLIC_TEST,
                logger: $logger,
            );
        }

        if ($cdpApiKeyId === null || $cdpApiKeySecret === null) {
            throw new \InvalidArgumentException(
                'Production mode requires CDP credentials. '
                . 'Pass cdpApiKeyId and cdpApiKeySecret, or set mode="testnet".'
            );
        }

        return new HttpFacilitatorClient(
            baseUrl: NetworkConfig::FACILITATOR_CDP_MAINNET,
            apiKeyId: $cdpApiKeyId,
            apiKeySecret: $cdpApiKeySecret,
            logger: $logger,
        );
    }
}
