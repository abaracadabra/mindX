# technical.md
## How `deltaverse-x402` is built, class by class

This document is the architect's reference. It walks through every namespace, every class, every non-obvious decision, and the runtime flow of a paid request from wire to handler and back.

---

## 1. Package layout

```
deltaverse-x402/
├── composer.json
├── config/deltaverse.php           # env-driven runtime config
├── src/
│   ├── Config/
│   │   ├── DomainConfig.php        # pythai.net URLs + endpoint catalog
│   │   └── NetworkConfig.php       # chain/facilitator/USDC specs
│   ├── Algorand/
│   │   ├── ParsecAlgorandWallet.php    # Ed25519 signer abstraction
│   │   └── ParsecFacilitator.php       # Parsec→GoPlausible fallback
│   ├── BANKON/
│   │   ├── IdentityGate.php            # cross-chain identity check
│   │   └── IdentityRejectedException.php
│   ├── BONAFIDE/
│   │   └── ReputationClient.php        # Tessera score lookup + discount
│   ├── MindX/
│   │   └── DeltaVerseMiddleware.php    # wraps x402 middleware with BANKON+BONAFIDE
│   ├── AgenticPlace/
│   │   ├── DiscoveryService.php        # /api/v1/services JSON
│   │   └── AllchainMapper.php          # /api/v1/allchain + allchain.html fragment
│   └── Integration/
│       └── DeltaVerseFactory.php       # one-stop assembly
└── examples/
    ├── mindx-server.php
    ├── agenticplace-discovery.php
    ├── parsec-agent.php
    └── bankon-register.php
```

## 2. Dependency chain

```
deltaverse-x402
    ├── depends on → pythai/x402-php   (protocol primitives, base middleware)
    ├── depends on → guzzlehttp/guzzle (HTTP client for facilitator + registry calls)
    └── depends on → psr/log           (log interface)

pythai/x402-php
    ├── depends on → kornrunner/keccak       (Keccak-256 for EIP-712)
    ├── depends on → simplito/elliptic-php   (secp256k1 signing)
    └── depends on → psr/http-*              (PSR-7, PSR-15, PSR-17)
```

You get ~20 transitive packages total. No Laravel, Symfony, or Slim dependency at the library level — those are only needed in your application.

## 3. Class-by-class walkthrough

### `Config\DomainConfig`

Pure constants. The three pythai.net URLs, the mindX endpoint catalog (`MINDX_ENDPOINTS` mapping route → price), and placeholder constants for BONAFIDE contract addresses and the BANKON AlgoIDNFT asset ID.

**Why constants, not env vars?** URLs rarely change. If you redeploy mindX to a different domain tomorrow, it's a code change with a commit — you *want* that to show up in git history. Env vars are for secrets and per-environment variation, not for stable architectural facts.

**The `MINDX_ENDPOINTS` dict** is the single source of truth for pricing. Change a price here, and everyone (mindX server, AgenticPlace discovery service) sees the change.

### `Config\NetworkConfig`

Chain specs for Base (mainnet + Sepolia) and Algorand (mainnet + testnet). For each network, returns a spec array with:

- `kind`: `"evm"` or `"algorand"` (used by callers to branch logic)
- `chainId` / `genesisId`: the on-chain identifier
- `usdc`: the contract address (EVM) or ASA ID (Algorand)
- `facilitator`: which facilitator URL to use
- `rpc` / `algod` / `indexer`: node endpoints
- EVM only: `usdcName` and `usdcVersion` for EIP-712 domain

**The subtle bit:** Base Sepolia USDC's `name()` returns `"USDC"`, while Base mainnet USDC returns `"USD Coin"`. Getting this wrong is the #1 cause of signature verification failures. `NetworkConfig::spec()` has the correct values hardcoded per network so you can't mix them up.

### `Algorand\ParsecAlgorandWallet`

Wraps an Ed25519 private key. Two factory methods (`fromPrivateKey`, `fromMnemonic`), two signing methods (`signBytes`, `signBase64`), and a `publicKey()` method that decodes the address.

**Uses `ext-sodium`** (`sodium_crypto_sign_detached`) — standard in PHP 7.2+, no composer dependency needed. This means signing works anywhere, including shared hosting.

**The mnemonic method throws intentionally.** Algorand's BIP-39 variant requires its own wordlist and checksum algorithm. Rather than half-implement it, we throw a clear message pointing to `rootsoft/algorand-php-sdk` for full mnemonic support.

**Base32 decoding** is done inline to avoid a dependency. The algorithm is 15 lines and the decoder is only used by `publicKey()` which isn't on the hot path.

### `Algorand\ParsecFacilitator`

Implements `X402\Facilitator\FacilitatorClient` (from the base library). Holds two Guzzle clients — one pointing at `parsec.pythai.net/facilitator`, one at `facilitator.goplausible.xyz`.

The key method is `postWithFallback`:

```
1. Try primary (Parsec)
2. If HTTP status < 500 and ≠ 404 and body is valid JSON → use response
3. Otherwise, log the fallback and call GoPlausible
4. If GoPlausible also fails → throw FacilitatorException
```

**Why both `< 500` and `≠ 404`?** `< 500` catches transport errors and 5xx server errors. `≠ 404` catches "endpoint doesn't exist yet" — which is the state Parsec will be in until you deploy it. The response must also parse as JSON, catching cases where something returned HTML or garbage.

**The `useFallbackImmediately` flag** is a simple skip — useful in production once you're confident Parsec isn't responding, to avoid burning 200ms on every request probing the primary.

### `BANKON\IdentityGate`

State: a mode (`off`/`soft`/`strict`), an ASA ID, two URLs (registry + indexer), and an in-memory cache keyed by lowercased wallet address with 5-minute TTL.

Three methods callers use:

- `isVerified($wallet)` → bool
- `priceMultiplier($wallet)` → 1.0 or 2.0 (soft mode)
- `shouldReject($wallet)` → bool (strict mode)

The internal `doCheck` is a two-hop:

1. Query `bankon.pythai.net/api/v1/identity/lookup?wallet=X` — returns the Algorand address linked to this wallet (or nothing)
2. Query Algorand indexer `/v2/accounts/{algo}/assets?asset-id=N` — returns holdings

If the input wallet is already a 58-char Algorand address, hop 1 is skipped. This handles the case where the agent is paying on Algorand natively — identity and payment chain are the same.

**Fail-closed:** any error (registry unreachable, indexer down, malformed response) returns `false` from `isVerified`. In strict mode this means the request is rejected; in soft mode it means the surcharge is applied. Neither is catastrophic, and this is safer than fail-open (which would let anyone skip the gate by DDoS'ing the indexer).

### `BONAFIDE\ReputationClient`

Reads `Tessera.scoreOf(address)` via raw JSON-RPC `eth_call`. No web3 PHP library dependency — we hand-encode the selector (`0xbf715a86`, first 4 bytes of keccak256 of `"scoreOf(address)"`) and the address (padded to 32 bytes) and decode the uint256 response via GMP.

**In-memory cache with 1-hour TTL.** Reputation changes slowly; hammering the RPC on every request would be wasteful. For multi-process deployments, replace this with Redis.

**Discount tiers are hardcoded:**

- 800+: 0.5x
- 500+: 0.75x
- below: 1.0x

Tune these by editing the `discountFactor` method. Consider making them configurable when you have actual reputation distribution data from production.

### `MindX\DeltaVerseMiddleware`

The orchestrator. Implements `Psr\Http\Server\MiddlewareInterface`. On every request:

1. **Pre-decode X-PAYMENT** — if the header is present, decode the payload to see who the payer is. If the header is malformed or absent, skip this step.
2. **BANKON gate** — if `IdentityGate::shouldReject()`, throw `IdentityRejectedException`. The framework catches this and returns 403.
3. **Reputation observation** — query `ReputationClient::discountFactor()` and log if a discount would apply. This doesn't change the price (see "honest gaps" in explanation.md) but provides signal for future product decisions.
4. **Delegate to base middleware** — hand off to `X402\Server\PaymentMiddleware` which does the actual protocol work (signature verification, facilitator verify/settle, route handler invocation).

**Why this structure?** Because the base middleware doesn't know about BANKON or BONAFIDE and shouldn't. Those are DELTAVERSE-specific layers. By wrapping rather than extending, we preserve the base library's single responsibility and make this library's value-add clean.

### `BANKON\IdentityRejectedException`

Domain-specific `RuntimeException`. The middleware throws it instead of returning a 403 directly because building a 403 response requires the response factory, which the middleware already has but would need to expose for this specific path. Throwing-and-catching is cleaner — the framework's error handler translates it to 403 with a helpful body (see `examples/mindx-server.php`).

### `AgenticPlace\DiscoveryService`

Pure data shaping. Builds a JSON document describing three services (mindX, BANKON, AgenticPlace itself). For mindX, reads prices from `DomainConfig::MINDX_ENDPOINTS` and builds payment options from the configured networks.

Output shape mirrors the x402 Bazaar discovery format so any agent that speaks Bazaar can consume this.

### `AgenticPlace\AllchainMapper`

Also pure data shaping. Emits chain metadata for four networks. Has a JSON output mode and an HTML fragment mode that renders a table for dropping into `allchain.html`.

**The HTML fragment is intentionally simple** — no JS, no styles beyond a basic table. If you want richer UI, build the table dynamically in JS from `/api/v1/allchain`.

### `Integration\DeltaVerseFactory`

The "rails" that assemble everything. Two static methods:

- `forMindX(...)` — returns a fully-wired `DeltaVerseMiddleware`
- `algorandFacilitator(...)` — returns just the `ParsecFacilitator` for Algorand-only tracks

**The production/testnet switch** is driven by the `mode` parameter. In production, it requires CDP credentials. In testnet, it uses the public facilitator. This prevents accidentally deploying to mainnet with testnet config.

## 4. Runtime flow for a paid request

```
HTTP request
    ↓
nginx / php-fpm
    ↓
Slim / Laravel / Symfony router
    ↓
DeltaVerseMiddleware::process()
    │
    ├─► peek X-PAYMENT, extract payer
    │   ├─► if strict BANKON mode && !verified → throw IdentityRejectedException → 403
    │   └─► log reputation discount eligibility
    │
    └─► PaymentMiddleware::process()   [base x402 library]
        │
        ├─► matchesRoute? → no → pass through
        │
        ├─► X-PAYMENT absent? → emit 402
        │
        ├─► decode payload
        │
        ├─► validatePayload (scheme, network, recipient, amount, window, sig format)
        │
        ├─► verifySignatureLocally (recover signer, compare to claimed `from`)
        │
        ├─► facilitator.verify(payload, option)
        │   └─► (ParsecFacilitator if Algorand, HttpFacilitatorClient if EVM)
        │
        ├─► facilitator.settle(payload, option)   ← on-chain USDC transfer
        │
        ├─► attach tx_hash, payer, amount to $request attributes
        │
        └─► handler ($req → $res)
            └─► mindX reasoning backend runs
    │
    └─► add PAYMENT-RESPONSE header with base64 settlement receipt
    │
    ↓
HTTP response
```

## 5. Environment variables (summary)

All optional; empty string means "not set, use defaults."

| Variable | Purpose | Default |
|----------|---------|---------|
| `DELTAVERSE_ENV` | production / testnet | testnet |
| `PAY_TO_EVM` | Base receiving wallet | — |
| `PAY_TO_ALGORAND` | Algorand receiving wallet | — |
| `CDP_API_KEY_ID` | Coinbase CDP key ID (prod only) | — |
| `CDP_API_KEY_SECRET` | Coinbase CDP key secret | — |
| `BANKON_MODE` | off / soft / strict | off |
| `BANKON_ALGOIDNFT_ASSET_ID` | AlgoIDNFT ASA ID | 0 (disabled) |
| `BANKON_REGISTRY_API` | BANKON lookup endpoint | pythai.net default |
| `BONAFIDE_ENABLED` | enable reputation pricing | false |
| `BONAFIDE_TESSERA_CONTRACT` | Tessera address on Base | empty |
| `BONAFIDE_RPC_URL` | RPC for reputation reads | mainnet.base.org |
| `USE_PARSEC` | try Parsec facilitator first | false |
| `PARSEC_FACILITATOR_URL` | custom Parsec URL | pythai.net default |
| `PAYMENT_LOG_PATH` | audit log destination | /var/log/deltaverse/payments.jsonl |

## 6. Gotchas and pitfalls

**USDC name/version per network.** Hardcoded in `NetworkConfig::spec()`. If you point at a network not in the hardcoded list, signatures will fail silently. To add a network, extend `NetworkConfig::spec()` and verify the live `name()` and `version()` from the contract match what you set.

**Algorand requires opt-in.** Before your Algorand `PAY_TO_ALGORAND` address can receive USDC, it must execute an opt-in transaction for ASA 31566704. If you skip this, Algorand settlements fail with "account does not hold this asset." Use `goal asset optin` or AlgoKit.

**Laravel requires PSR bridges.** The `X402\Server\Laravel\PaymentMiddleware` (from the base library) requires `symfony/psr-http-message-bridge` + `nyholm/psr7`. These aren't pulled in automatically because not everyone uses Laravel. Add them explicitly:
```
composer require symfony/psr-http-message-bridge nyholm/psr7
```

**uvloop not applicable.** That's the Python pitfall, doesn't affect PHP.

**Facilitator auth.** CDP uses bearer token auth. The `HttpFacilitatorClient` adds `Authorization: Bearer <secret>` + `CDP-API-Key-Id: <id>` headers. Public facilitators (x402.org, GoPlausible) use no auth. Don't accidentally send CDP headers to a non-CDP facilitator — most will ignore them, but it's wasteful.

**BANKON cache across processes.** The in-memory cache is per-process. In a 10-worker setup you'll see 10x the registry/indexer load on cache-miss. Add Redis before production scale.

**Reputation discount is currently passive.** The `ReputationClient` reads scores but doesn't actually reduce prices. To do active discounting, subclass `X402\Server\PaymentConfig` and override the price lookup to multiply by `ReputationClient::discountFactor()`. This is a v2 extension.

## 7. Testing this library

Three layers:

**Unit tests** — pure logic (NetworkConfig lookups, DiscoveryService output shape, AllchainMapper). No network, fast.

**Integration against testnet** — run `examples/mindx-server.php` with `DELTAVERSE_ENV=testnet` and a Base Sepolia receiving wallet. Hit it with `examples/parsec-agent.php` using a funded Sepolia agent wallet. Verify the 402 → 200 flow, check Basescan for the transaction.

**End-to-end with BANKON** — deploy the `BankonRegistry` contract to Base mainnet (contract in `mindx-x402` playbook), configure `BANKON_REGISTRY_CONTRACT` + `BANKON_ALGOIDNFT_ASSET_ID`, set `BANKON_MODE=strict`, verify unverified wallets get 403 and verified wallets pay successfully.

## 8. When to extend this library

**Add a new chain:** extend `NetworkConfig::spec()`, add a case to `DeltaVerseFactory::buildEvmFacilitator()` (or create a new factory method for non-EVM), add it to `AllchainMapper`.

**Add active reputation discounting:** create `ReputationAwarePaymentConfig extends PaymentConfig`, override the price computation to multiply by `ReputationClient::discountFactor()`, use it in `DeltaVerseFactory::forMindX`.

**Add a new service (beyond mindX/BANKON/AgenticPlace):** add its URLs to `DomainConfig`, add an entry to `DiscoveryService::build()`, optionally add a factory method `DeltaVerseFactory::forNewService()`.

**Add real Parsec facilitator:** once you deploy `parsec.pythai.net/facilitator`, just ensure `PARSEC_FACILITATOR_URL` points there and `USE_PARSEC=true`. No code changes.

**Add Algorand msgpack client:** install `rybakit/msgpack`, extend `ParsecAlgorandWallet` with transaction assembly methods, implement the Algorand-side of `X402Client`. This is a significant piece of work — budget a week.

Everything else is probably a signal that this library has outgrown its scope and you should split it into domain-specific sub-packages.
