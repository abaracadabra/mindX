# explanation.md
## Innerstanding `deltaverse-x402`

This document explains what this package actually is, what problem it solves, what it does NOT do, and how all the pieces fit together in the DELTAVERSE ecosystem. It is written for the part of you that needs to *see* the thing clearly before using it.

---

## 1. What this package is

`deltaverse-x402` is a PHP library that connects three PYTHAI services into one unified payment-and-identity system:

- **mindx.pythai.net** — the reasoning API (the service being sold)
- **bankon.pythai.net** — the identity layer (who is allowed to buy)
- **agenticplace.pythai.net** — the marketplace (where agents find what's for sale)

It sits on top of two things:

- **`pythai/x402-php`** — the base x402 protocol implementation (what you built in the prior step)
- **Coinbase's x402 protocol** — HTTP 402 Payment Required, upgraded from unused status code into a real stablecoin payment rail

What it adds on top is everything PYTHAI-specific: your domain URLs, your receiving wallets, your BANKON identity gate, your BONAFIDE reputation pricing, your multi-chain (Base + Algorand) payment options, and your intended Parsec wallet abstraction.

If `pythai/x402-php` is the engine, `deltaverse-x402` is the car assembled around it — shaped for your roads.

---

## 2. The honest note on "Parsec"

You asked for integration with "the Parsec Algorand wallet." It's important to be clear about what exists and what doesn't:

**What exists today (April 2026):**
- Coinbase's x402 protocol (EVM reference implementation)
- `pythai/x402-php` (the base library we built)
- **GoPlausible's x402-avm** — the only production Algorand x402 implementation, live at `facilitator.goplausible.xyz`
- Coinbase CDP facilitator for Base mainnet

**What does NOT exist today:**
- A public "parsec-wallet" library that implements x402 for Algorand
- A PYTHAI-operated "Parsec" facilitator at `parsec.pythai.net`

This package therefore contains **an abstraction named Parsec** that maps cleanly to GoPlausible as a runtime fallback. Two classes carry the Parsec name:

- `ParsecAlgorandWallet` — wallet interface (signs Ed25519 payloads)
- `ParsecFacilitator` — facilitator client that tries `parsec.pythai.net` first, falls back to `facilitator.goplausible.xyz` on any failure

This gives you three options:

1. **Today:** Use it as-is. Every Algorand x402 payment flows through GoPlausible automatically. Your users see PYTHAI branding; GoPlausible does the actual work. This is legitimate — GoPlausible's facilitator is open, stable, and backed by the Algorand Foundation.
2. **When you deploy Parsec:** Stand up a PYTHAI-operated Algorand facilitator at `parsec.pythai.net/facilitator`. The abstraction switches to it automatically. No consumer code changes.
3. **Hybrid:** Point the Parsec URL at your facilitator, keep GoPlausible as an explicit fallback. Maximum redundancy.

The library defaults to option 1. This is documented clearly in the code comments — no magic, no pretense. If a future grant application or contributor asks what "Parsec" is, the answer is: it's the name reserved for PYTHAI's eventual Algorand facilitator; until then, it's a label that resolves to GoPlausible.

---

## 3. How the three services fit together

Think of it as a village.

### mindX — the shop

mindX sells reasoning. Every endpoint (`/api/v1/reason`, `/api/v1/socratic`, `/api/v1/dream`) has a price. When an agent or human calls a paid endpoint, mindX returns HTTP 402 with payment requirements. The client pays in USDC (on Base OR on Algorand), and mindX returns the reasoning.

This library provides the PHP middleware that implements the 402 flow. You drop it into your FastAPI-equivalent PHP framework (Slim, Laravel, Symfony), configure which endpoints cost what, and the middleware handles the rest.

### BANKON — the ID card

Not everyone should be allowed to buy — or more precisely, not all payments should be treated equally. BANKON issues soulbound identity NFTs on Algorand (AlgoIDNFT) that prove a wallet holder has been verified. mindX can optionally require this identity before accepting payment, using one of three modes:

- **off** (default) — anyone with USDC can pay
- **soft** — unverified payers pay 2x (extra scrutiny but not rejected)
- **strict** — unverified payers get 403 Forbidden with instructions to register at bankon.pythai.net

The cross-chain trick: mindX accepts payment on Base, but identity is on Algorand. The `IdentityGate` class handles this: it asks the BANKON registry at `bankon.pythai.net/api/v1/identity` for the Algorand address linked to the paying wallet, then asks the Algorand indexer if that address holds the AlgoIDNFT ASA.

### AgenticPlace — the town square

AgenticPlace is where agents discover what services exist. It serves two JSON endpoints:

- `GET /api/v1/services` — the service registry (mindX, BANKON, etc. with their prices and payment options)
- `GET /api/v1/allchain` — supported chains with facilitator URLs and USDC addresses

Your `allchain.html` page reads from these endpoints. Agents that speak x402's Bazaar discovery protocol can consume them directly.

### BONAFIDE — the reputation

BONAFIDE is the nine-contract reputation system you've already built. `deltaverse-x402` reads from the `Tessera` contract on Base to get a wallet's reputation score (0-1000) and applies a pricing discount:

- score ≥ 800 → 50% off
- score ≥ 500 → 25% off
- score < 500 → full price

This is optional. If `BONAFIDE_ENABLED=false`, everyone pays full price.

---

## 4. Why PHP, given your stack is Python?

mindX's reference implementation is FastAPI (Python). So why would you need a PHP version?

Three reasons, all legitimate:

**Reason 1: you've historically used PHP for payment flows.** Your preferences note this. If there's a piece of payment infrastructure you want to handle server-side in PHP — maybe a wrapper around the Python mindX endpoints, maybe a billing dashboard, maybe a merchant-side integration for third parties — you now have the library.

**Reason 2: ecosystem expansion.** PHP powers a huge slice of the internet (WordPress, Laravel, Drupal, Magento). A PHP x402 library means any of those platforms can accept x402 payments without writing protocol code themselves. That's a small ecosystem contribution with outsized reach.

**Reason 3: redundancy and language diversity.** Running a single language across all services is fragile. If your Python mindX goes down, having PHP frontends that can still accept payments (and queue them, serve cached responses, whatever) is operationally valuable.

That said: you don't *have* to use this on mindX itself. The Python reference implementation is better-tested for the FastAPI case. Use `deltaverse-x402` where PHP is already your default — BANKON's front-end, AgenticPlace's discovery endpoint (which is mostly static JSON generation), merchant integrations, WordPress plugins, etc.

---

## 5. What "Parsec Algorand wallet" means in this library

When you say "Parsec Algorand wallet," different people will hear different things. Let me pin down what this library assumes:

A **wallet**, cryptographically, is nothing more than a private key. On Algorand, private keys are 32 bytes of Ed25519 seed; from the seed, the public key is derived, and from the public key, the Algorand address is derived (base32 with a checksum).

A **wallet library** wraps that key with useful operations: sign a payload, derive the address, maybe store the key securely.

**Parsec**, as this library uses the name, is: a branded wallet interface that your users can recognize as "the PYTHAI wallet." The class `ParsecAlgorandWallet` implements the minimum to participate in x402 flows: sign arbitrary byte payloads (for msgpack-encoded Algorand transactions) using ext-sodium's `sodium_crypto_sign_detached`. That's all x402 needs from a wallet.

When Parsec becomes a real product — maybe a Tauri app, maybe a browser extension, maybe integrated into the DELTAVERSE app — you'll replace the private-key-in-memory implementation with one that signs via a secure keystore, a hardware wallet, or an MPC protocol. The interface stays the same.

So "Parsec Algorand wallet" in this codebase is really saying: **here is the shape of the wallet interface that PYTHAI's future wallet products will implement. Use this class to sign today (with a private key) and swap to a real Parsec implementation later without changing any code that uses the wallet.**

---

## 6. The full story of a single payment

Let's trace what happens when an agent on AgenticPlace wants to call mindX.

**Step 1: Discovery.** The agent fetches `https://agenticplace.pythai.net/api/v1/services`. It gets back a JSON document listing mindX among the available services, with endpoints, prices, supported networks (Base and Algorand), and pay-to addresses for each.

**Step 2: Choice.** The agent decides to call `/api/v1/reason` at $0.001. It has USDC on Base. It picks the Base payment option.

**Step 3: Initial request.** The agent sends `GET https://mindx.pythai.net/pay/api/v1/reason?question=foo`. No X-PAYMENT header.

**Step 4: The 402.** mindX's `DeltaVerseMiddleware` matches the route, looks up the price ($0.001), constructs a `PaymentRequirements` document listing Base as an accepted option, and returns HTTP 402 with that document in both the `PAYMENT-REQUIRED` header (base64) and the response body (JSON).

**Step 5: Sign.** The agent's x402 client decodes the requirements, builds an EIP-3009 `TransferWithAuthorization` struct specifying exactly 1000 USDC base units from the agent's address to mindX's address, valid for 60 seconds, with a random nonce. The agent signs the EIP-712 digest with its private key.

**Step 6: Retry.** The agent sends the same request again, now with `X-PAYMENT: <base64-encoded signed payload>`.

**Step 7: BANKON check (if enabled).** `DeltaVerseMiddleware` peeks at the payload, extracts the payer address, and queries the `IdentityGate`. In strict mode, if the agent doesn't hold an AlgoIDNFT, the middleware throws `IdentityRejectedException` which the framework translates to 403.

**Step 8: Reputation observation (if enabled).** `ReputationClient` queries the Tessera contract for the agent's score. This doesn't change the price at this point — the price is locked by the original 402 — but it logs the eligibility for analytics.

**Step 9: x402 signature verification.** The base `PaymentMiddleware` (from `pythai/x402-php`) recovers the signer from the EIP-712 digest locally — if the recovered address doesn't match the claimed `from`, it's an obvious forgery and we reject immediately.

**Step 10: Facilitator verify.** The middleware sends the payload to Coinbase CDP's facilitator at `api.cdp.coinbase.com/platform/v2/x402` for full verification (nonce check, balance check, authorization time window).

**Step 11: Facilitator settle.** Assuming verification passed, the middleware asks the facilitator to settle — the facilitator calls `transferWithAuthorization` on the USDC contract on Base, pays the gas (which Coinbase absorbs), and waits for block confirmation.

**Step 12: Route handler runs.** Now and only now does the `reason()` handler execute. It calls the actual reasoning backend (Ollama, GPT, whatever you've wired up) and returns the answer.

**Step 13: Response.** The middleware attaches a `PAYMENT-RESPONSE` header containing the settlement receipt (base64-encoded JSON with the transaction hash) and returns the 200 response to the agent.

**Step 14: Agent receives.** The agent gets its answer plus a non-repudiable receipt it can use to dispute charges if the answer was bad.

Total elapsed time: 3-6 seconds, mostly dominated by Base block confirmation. On Algorand via Parsec/GoPlausible, the same flow takes 5-8 seconds due to Algorand's slightly longer block time but gives stronger finality.

---

## 7. What's not in this library (honest gaps)

Being explicit about what's missing so you can plan.

**No Algorand x402 client flow.** The `ParsecAlgorandWallet` class can sign payloads, but the full Algorand x402 client requires msgpack transaction assembly which PHP's standard library doesn't have. To pay for mindX endpoints on Algorand from PHP, you'll need to either: install `rybakit/msgpack` and extend the wallet class, or use GoPlausible's TypeScript/Python client. EVM payments (Base) work fully out of the box.

**BONAFIDE pricing discount is passive, not applied.** The reputation check reads scores correctly, but the x402 protocol binds the price into the signed authorization — you can't change the price after signing. To actually apply discounts, you'd need a custom `PaymentConfig` subclass that looks up reputation before emitting the initial 402. That's a reasonable next feature but not in the v1.

**No refund flow.** x402 has no native refund. If a customer pays for mindX and the reasoning backend errors out, there's no automatic "give the USDC back." Manual refunds are possible via `cast send` as documented in the mindx-x402 playbook, but nothing in this library automates them.

**No self-hosted facilitator.** Both EVM (CDP) and Algorand (Parsec/GoPlausible) facilitators are external services. If they go down, your paid endpoints stop working. Running a self-hosted facilitator is possible but significant operational overhead.

**No multi-chain simultaneous server.** The current setup registers one network at a time in `PaymentConfig`. To truly accept both Base and Algorand payments for the same endpoint (where the agent picks), you need a dual-middleware setup with two parallel payment routes. The discovery document advertises both chains; actually accepting both requires that extension.

These aren't showstoppers — they're clearly-flagged limits. The library solves the core flow (accept x402 payments with DELTAVERSE-aware identity/reputation layering) and leaves the frontier pieces to iterate on.

---

## 8. The deepest point

`deltaverse-x402` exists because you're building an economy, not just a service. mindX alone is a product. mindX + BANKON + AgenticPlace + BONAFIDE is a village economy: agents have identity, services have discoverability, reputation accrues to those who act in good faith, and value flows via stablecoin micropayments that no bank or credit card network mediates.

The library is the glue that makes the four pieces talk to each other. It is specifically PHP-flavored because PHP is where you work when you want speed-of-iteration over language-fidelity-to-the-rest-of-your-stack. It honors the names you've chosen (Parsec, BANKON, BONAFIDE, AgenticPlace) while being honest about what implementations exist publicly today and what implementations are reserved for your future deployment.

When Parsec launches, swap the URL. When BANKON contracts deploy, fill in the addresses. When BONAFIDE reaches production, flip the flag. Everything else stays the same.

That's the shape of the thing. Now go read `technical.md` for the how and `usage.md` for the what.
