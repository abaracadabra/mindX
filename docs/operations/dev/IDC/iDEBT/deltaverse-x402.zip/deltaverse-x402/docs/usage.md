# usage.md
## Day-to-day operation of `deltaverse-x402`

This is the operator's manual. It covers installation, configuration, running locally, deploying to production, monitoring, and troubleshooting the DELTAVERSE integration across mindx.pythai.net, bankon.pythai.net, and agenticplace.pythai.net.

---

## 1. Installation

### Prerequisites

- PHP 8.1 or later
- Extensions: `ext-gmp`, `ext-openssl`, `ext-sodium`, `ext-json`
- Composer 2.x
- For Foundry testing of Base contracts: `foundryup` installed
- For Algorand testing: AlgoKit (optional, only if you want LocalNet)

Check your PHP setup:

```bash
php -v                              # must be 8.1+
php -m | grep -Ei "gmp|sodium|openssl|json"   # all four must appear
composer --version
```

Install extensions on Ubuntu/Debian:
```bash
sudo apt install php8.3-cli php8.3-gmp php8.3-mbstring php8.3-curl php8.3-xml
```

### Getting the package

If the package is on Packagist:

```bash
composer require pythai/deltaverse-x402
```

If you're working from the zip before publishing to Packagist:

```bash
unzip deltaverse-x402.zip
cd deltaverse-x402
composer install
```

This pulls in `pythai/x402-php` (the base library) and all transitive dependencies.

---

## 2. Configuration

All configuration is driven by environment variables read from `.env` (if you use `vlucas/phpdotenv`) or plain shell env vars.

### Minimum config (testnet, no identity, no reputation)

```bash
# .env
DELTAVERSE_ENV=testnet
PAY_TO_EVM=0xYourBaseSepoliaReceivingWallet
PAY_TO_ALGORAND=                    # optional; leave empty if not accepting Algorand yet
```

That's it. Spin up the example server and pay with test USDC from Circle's faucet.

### Production config (Base mainnet + BANKON + BONAFIDE)

```bash
# .env.production
DELTAVERSE_ENV=production

# Receiving wallets (get CDP to provision these, or use your own)
PAY_TO_EVM=0xYourBaseMainnetReceivingWallet
PAY_TO_ALGORAND=YOUR58CHARALGORANDRECEIVINGADDRESS...

# Coinbase Developer Platform credentials
CDP_API_KEY_ID=abc123...
CDP_API_KEY_SECRET=supersecret...

# BANKON identity
BANKON_MODE=strict
BANKON_ALGOIDNFT_ASSET_ID=123456789
BANKON_REGISTRY_API=https://bankon.pythai.net/api/v1/identity

# BONAFIDE reputation
BONAFIDE_ENABLED=true
BONAFIDE_TESSERA_CONTRACT=0xYourDeployedTesseraAddress
BONAFIDE_RPC_URL=https://mainnet.base.org

# Parsec / Algorand
USE_PARSEC=false                   # true once parsec.pythai.net goes live
PARSEC_FACILITATOR_URL=https://parsec.pythai.net/facilitator

# Logging
LOG_LEVEL=info
PAYMENT_LOG_PATH=/var/log/deltaverse/payments.jsonl
```

### Loading the config

```php
$config = require __DIR__ . '/config/deltaverse.php';
```

The config file in `config/deltaverse.php` reads all the env vars and returns a structured array. No framework assumptions — works with plain PHP, Slim, Symfony, Laravel.

---

## 3. Running the three services

### mindX server

```bash
# Development (testnet)
cp .env.example .env
# Edit .env: set PAY_TO_EVM to a wallet you control
# Fund that wallet at https://faucet.circle.com (Base Sepolia USDC)

php -S 0.0.0.0:8000 examples/mindx-server.php
```

Verify:
```bash
curl http://localhost:8000/health
# {"status":"ok","service":"mindX"}

curl -i http://localhost:8000/api/v1/reason?question=test
# HTTP/1.1 402 Payment Required
# PAYMENT-REQUIRED: eyJ4NDAyVmVyc2lvbiI6Miw...
```

Pay with the agent:
```bash
export AGENT_PRIVATE_KEY=0x...  # funded Sepolia USDC wallet
php examples/parsec-agent.php http://localhost:8000/api/v1/reason?question=foo
```

### AgenticPlace discovery

```bash
php -S 0.0.0.0:8001 examples/agenticplace-discovery.php
```

Endpoints:
- `GET /api/v1/services` — JSON service registry
- `GET /api/v1/allchain` — chain metadata
- `GET /allchain.html` — human-readable chain table
- `GET /health` — liveness

### BANKON registration (one-time per wallet)

```bash
export EVM_PRIVATE_KEY=0x...
export ALGO_ADDRESS=YOUR58CHARALGORANDADDRESS...
php examples/bankon-register.php
```

This is an interactive helper — it prints the `cast` command to run (so you can review before signing) rather than executing blindly.

---

## 4. Production deployment

### Recommended stack

- **Web server:** nginx (reverse proxy) → PHP-FPM
- **PHP:** PHP 8.3 for best performance
- **Process manager:** systemd
- **Container:** Podman rootless with the Containerfile from `mindx-x402`
- **Secrets:** GCP Secret Manager, AWS Secrets Manager, or HashiCorp Vault

### nginx configuration

```nginx
# /etc/nginx/sites-available/mindx.pythai.net
server {
    listen 443 ssl http2;
    server_name mindx.pythai.net;

    ssl_certificate     /etc/letsencrypt/live/mindx.pythai.net/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/mindx.pythai.net/privkey.pem;

    root /opt/mindx/public;
    index index.php;

    # Pass X-PAYMENT through — nginx sometimes strips "unknown" headers
    underscores_in_headers on;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass   unix:/run/php/php8.3-fpm.sock;
        fastcgi_index  index.php;
        fastcgi_param  SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include        fastcgi_params;

        # Critical for x402: don't buffer the 402 response
        fastcgi_buffering off;

        # Long enough for facilitator round-trip
        fastcgi_read_timeout 30s;
    }

    # Serve /health without PHP overhead for load balancer checks
    location = /health {
        return 200 '{"status":"ok"}';
        default_type application/json;
    }
}
```

### systemd service

```ini
# /etc/systemd/system/deltaverse-mindx.service
[Unit]
Description=DELTAVERSE mindX PHP-FPM
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
EnvironmentFile=/etc/deltaverse/mindx.env
ExecStart=/usr/sbin/php-fpm8.3 --nodaemonize --fpm-config /etc/php/8.3/fpm/php-fpm.conf
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
```

Load:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now deltaverse-mindx.service
sudo systemctl status deltaverse-mindx.service
```

### Container deployment (Podman)

Reuse the Containerfile pattern from `mindx-x402`:

```dockerfile
FROM php:8.3-fpm-alpine

RUN apk add --no-cache gmp-dev libsodium-dev \
    && docker-php-ext-install gmp sodium

COPY composer.json /app/
WORKDIR /app
RUN composer install --no-dev --optimize-autoloader

COPY src /app/src
COPY examples /app/examples
COPY config /app/config

USER www-data
CMD ["php-fpm", "--nodaemonize"]
```

```bash
podman build -t deltaverse-x402:prod -f Containerfile .
podman run -d --name mindx \
    --env-file /etc/deltaverse/mindx.env \
    -p 9000:9000 \
    deltaverse-x402:prod
```

---

## 5. Production rollout checklist

Work through this list top to bottom. Don't skip.

### Phase 1: testnet dogfooding (1 week)

- [ ] Deploy `examples/mindx-server.php` with `DELTAVERSE_ENV=testnet`
- [ ] Generate a Base Sepolia receiving wallet with `cast wallet new`
- [ ] Make 20+ real test payments from a separate funded agent wallet
- [ ] Verify each transaction on `sepolia.basescan.org`
- [ ] Check `payments.jsonl` has one entry per settlement
- [ ] Leave it running for 7 days; monitor for unexpected errors

### Phase 2: BANKON integration (3-5 days)

- [ ] Deploy `BankonRegistry` contract from the `mindx-x402` package to Base Sepolia
- [ ] Mint test AlgoIDNFT on Algorand testnet
- [ ] Link one agent wallet: call `linkIdentity()` on registry, send AlgoIDNFT to linked Algo address
- [ ] Verify `BANKON_MODE=strict` rejects unlinked wallets with 403
- [ ] Verify verified wallets pay through
- [ ] Test `BANKON_MODE=soft`: unverified pay 2x, verified pay 1x

### Phase 3: BONAFIDE integration (2-3 days)

- [ ] Deploy BONAFIDE contracts (Genius, Tessera, etc.) to Base
- [ ] Set `BONAFIDE_TESSERA_CONTRACT`, `BONAFIDE_ENABLED=true`
- [ ] Give a test agent a score of 800+ via Tessera
- [ ] Verify the `bonafide.discount_eligible` log entry appears when that agent pays

### Phase 4: mainnet canary (1 week)

- [ ] Switch `DELTAVERSE_ENV=production`
- [ ] Add CDP credentials to secrets manager (not env file)
- [ ] Provision the mainnet receiving wallet via GCP KMS or hardware wallet
- [ ] Make ONE real $0.001 test payment from a wallet you control
- [ ] Verify on `basescan.org`, CDP dashboard, and `payments.jsonl`
- [ ] Run 5% canary traffic for 24 hours
- [ ] Monitor for errors, settlement latency, facilitator availability
- [ ] Ramp to 100% over 3 days (25% → 50% → 100%)

### Phase 5: Algorand via GoPlausible fallback (optional)

- [ ] Provision Algorand receiving wallet
- [ ] Execute USDC ASA opt-in for the receiving wallet
- [ ] Add Algorand payment option to `DomainConfig` payment configurations
- [ ] Test with an Algorand-funded agent using GoPlausible's TypeScript client
- [ ] Monitor `facilitator.goplausible.xyz` responses in logs

### Phase 6: Parsec deployment (when ready)

- [ ] Deploy PYTHAI-operated Algorand facilitator at `parsec.pythai.net/facilitator`
- [ ] Set `USE_PARSEC=true` in production
- [ ] Monitor logs for `facilitator.parsec.ok` vs `facilitator.parsec.unavailable` ratios
- [ ] If Parsec handles >95% of requests successfully for a week, GoPlausible becomes pure fallback

---

## 6. Monitoring

### Daily checks (5 minutes)

```bash
# Payments in last 24h
jq 'select(.ts > (now - 86400))' /var/log/deltaverse/payments.jsonl | wc -l

# Total USDC received (in base units)
jq -s '[.[] | select(.ts > (now - 86400)) | .amount | tonumber] | add' \
    /var/log/deltaverse/payments.jsonl

# BANKON rejection rate
grep -c "bankon.rejected" /var/log/deltaverse/mindx.log
grep -c "payment accepted" /var/log/deltaverse/mindx.log

# Parsec fallback rate (if Algorand enabled)
grep -c "facilitator.parsec.ok" /var/log/deltaverse/mindx.log
grep -c "facilitator.goplausible.ok" /var/log/deltaverse/mindx.log

# Current wallet balance
cast call 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
    "balanceOf(address)(uint256)" \
    $PAY_TO_EVM \
    --rpc-url https://mainnet.base.org
```

### Metrics to graph

| Metric | Alert threshold |
|--------|-----------------|
| `payments_per_hour` | drop to 0 for > 10 min → alert |
| `402_rate` | > 50% of paid-endpoint traffic → investigate |
| `settlement_latency_p95` | > 10s → facilitator issues |
| `facilitator_error_rate` | > 5% → alert |
| `bankon_rejection_rate` | sudden spike → possible attack |
| `parsec_fallback_rate` | > 20% ongoing → Parsec broken |

### Reconciliation

Nightly cron — match on-chain state against local audit log:

```bash
# /etc/cron.d/deltaverse-reconcile
0 2 * * * www-data /opt/deltaverse/scripts/reconcile.php >> /var/log/deltaverse/reconcile.log 2>&1
```

Follow the pattern from `mindx-x402/scripts/reconcile_daily.py` — walk the last 24h of payments, fetch each transaction receipt from Base, compare recipient and amount, flag discrepancies.

---

## 7. Common operations

### Change a price

1. Edit `src/Config/DomainConfig.php` → `MINDX_ENDPOINTS`
2. Commit
3. Deploy (rolling restart)

New 402 responses reflect new prices immediately. In-flight signed authorizations at old prices still settle correctly — don't worry about coordination.

### Add a new paid endpoint

1. Add to `DomainConfig::MINDX_ENDPOINTS` with route + price + description
2. Add the route handler in `examples/mindx-server.php` (or wherever your routes live)
3. Deploy

The middleware reads endpoints dynamically — no need to wire the new path manually.

### Change BANKON mode mid-flight

1. Update `BANKON_MODE` env var (off / soft / strict)
2. Rolling restart

Currently-signed authorizations don't care about BANKON — they paid already. New requests will see the new mode.

### Issue a refund

x402 has no native refund. Process:

```bash
# Get the tx hash and amount from payments.jsonl
grep "0xPayerAddress" /var/log/deltaverse/payments.jsonl

# Send USDC back
cast send 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
    "transfer(address,uint256)" \
    0xPayerAddress \
    $AMOUNT_BASE_UNITS \
    --rpc-url https://mainnet.base.org \
    --private-key $PAY_TO_PRIVATE_KEY

# Log the refund
echo '{"ts":'$(date +%s)',"payer":"0x...","tx":"0x...","reason":"..."}' \
    >> /var/log/deltaverse/refunds.jsonl
```

### Rotate receiving wallet

Every 6-12 months for good hygiene.

1. Generate new wallet via KMS
2. Update `PAY_TO_EVM` in secrets manager
3. Rolling restart — new 402 responses point to new address
4. In-flight signed authorizations to old address still settle (USDC doesn't care about your config)
5. After the max auth window (60s) has passed, drain old wallet:
   ```bash
   cast send 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
       "transfer(address,uint256)" \
       $NEW_ADDRESS $OLD_BALANCE \
       --rpc-url https://mainnet.base.org \
       --private-key $OLD_PRIVATE_KEY
   ```
6. Archive old key (don't delete — historical audit)

### Switch Parsec on/off

```bash
# Enable Parsec (try it first, GoPlausible as fallback)
export USE_PARSEC=true

# Disable Parsec (go straight to GoPlausible, skip probe)
export USE_PARSEC=false
```

No code change. Just config + restart.

---

## 8. Troubleshooting

### "invalid_exact_evm_payload_signature"

The signature doesn't verify. Causes:

1. **Wrong USDC name/version in EIP-712 domain.** Check `NetworkConfig::spec()` — Base mainnet is `"USD Coin"`, Base Sepolia is `"USDC"`. Both are `version "2"`.
2. **Wrong chain ID.** Must match the network (`8453` for Base mainnet, `84532` for Sepolia).
3. **Wrong USDC contract address** for the target network.
4. **Client signed with a different key** than the claimed `from` address.

Debug by computing the digest manually with `cast wallet sign-typed-data` and comparing.

### "facilitator verify failed" / "facilitator settle failed"

The facilitator rejected the payment. Common reasons:

- **Nonce already used.** Each authorization must have a unique nonce. The SDK generates random 32-byte nonces; if you're building a custom client, ensure it does too.
- **Authorization expired.** `validBefore` is in the past. Usually means the facilitator took too long. Retry with a fresh signature.
- **Insufficient USDC balance** on the payer's wallet.
- **CDP rate limit hit.** Check your CDP dashboard. Rare except under abuse.
- **CDP credentials wrong.** Verify `CDP_API_KEY_ID` and `CDP_API_KEY_SECRET` in secrets manager.

### "bankon.rejected" but the user claims they're verified

1. Check registry mapping:
   ```bash
   curl "https://bankon.pythai.net/api/v1/identity/lookup?wallet=0xPayer"
   ```
   Should return their Algorand address.
2. Check Algorand holding:
   ```bash
   curl "https://mainnet-idx.algonode.cloud/v2/accounts/THEIR_ALGO_ADDR/assets?asset-id=$BANKON_ALGOIDNFT_ASSET_ID"
   ```
   Should show `amount > 0`.
3. If either fails, the user needs to re-register via `bankon.pythai.net`.
4. Check your cache TTL — if you just registered, the 5-min cache might not have expired yet. Wait or restart.

### Parsec fallback rate is high

Normal at launch — Parsec doesn't exist yet, so `facilitator.parsec.ok` is always 0.

After you deploy Parsec, if fallback rate stays > 20%:

1. Check Parsec facilitator logs for errors
2. Compare round-trip times — GoPlausible might actually be faster
3. Verify `PARSEC_FACILITATOR_URL` is correct in config
4. Test the URL directly: `curl $PARSEC_FACILITATOR_URL/supported`

### All paid endpoints started failing at once

Check in this order:
1. CDP status: `status.coinbase.com`
2. Base chain status: `status.base.org`
3. Your facilitator credentials — did CDP rotate keys or suspend your account?
4. Receiving wallet — was it drained? ETH balance (facilitator pays gas, but some edge cases require payer gas)?
5. TLS certificates — did `mindx.pythai.net` cert expire?

### nginx stripped X-PAYMENT header

nginx drops headers with underscores by default. The example config above has `underscores_in_headers on;` — double-check this is applied.

---

## 9. Upgrading

### Updating `pythai/x402-php`

```bash
composer update pythai/x402-php
```

Check release notes for breaking changes. The base library follows semver — a major version bump means you need to review code.

### Updating `deltaverse-x402`

```bash
composer update pythai/deltaverse-x402
```

Same rules.

### Moving from V2 to V3 of the x402 protocol

When the x402 protocol releases V3:

1. Wait 30 days for ecosystem stabilization
2. Upgrade `pythai/x402-php` to a V3-supporting version
3. Test on staging against a V3 facilitator (Coinbase will announce the new URL)
4. Deploy to canary
5. The protocol is supposed to be backward-compatible, so V2 clients will still work

---

## 10. Getting help

1. **Logs first.** `/var/log/deltaverse/mindx.log` and `/var/log/deltaverse/payments.jsonl` are your best friends.
2. **Base library issues:** `github.com/pythai/x402-php/issues`
3. **Protocol questions:** `github.com/coinbase/x402` spec + discussion
4. **Facilitator issues:** CDP support for Coinbase, GoPlausible Discord for Algorand
5. **BANKON / BONAFIDE / AgenticPlace:** internal PYTHAI channels

Always include in a bug report:
- `DELTAVERSE_ENV` value
- Exact error message from logs
- Payer wallet address (NOT private key)
- Transaction hash if one was attempted
- Facilitator URL in use

---

## 11. Decommissioning

If you ever need to take this integration offline:

### Graceful

1. Remove paid endpoints from `DomainConfig::MINDX_ENDPOINTS`
2. Deploy — middleware no longer matches them, endpoints become free (or 404 if you also remove the handlers)
3. Update `AgenticPlace` discovery to omit mindX
4. Run for 24 hours letting in-flight signed auths settle
5. Drain receiving wallet to treasury

### Emergency

1. `BANKON_MODE=strict` + `BANKON_ALGOIDNFT_ASSET_ID=999999999` (nonexistent) → everyone gets 403
2. Investigate
3. Restore when safe

Either way, your users see clean error responses, not garbage.
