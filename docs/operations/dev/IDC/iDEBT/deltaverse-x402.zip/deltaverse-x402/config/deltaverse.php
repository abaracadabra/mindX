<?php

/**
 * DELTAVERSE x402 configuration.
 *
 * Loaded by the factory and any application that wants runtime
 * overrides. In production, prefer env vars over hardcoded values.
 */

return [
    'mode' => getenv('DELTAVERSE_ENV') ?: 'testnet',      // 'production' | 'testnet'

    // ─── Receiving wallets ─────────────────────────────────
    'pay_to' => [
        'evm' => getenv('PAY_TO_EVM') ?: '',              // 0x... on Base
        'algorand' => getenv('PAY_TO_ALGORAND') ?: '',    // 58-char Algo address
    ],

    // ─── Facilitator credentials ──────────────────────────
    'cdp' => [
        'api_key_id' => getenv('CDP_API_KEY_ID') ?: null,
        'api_key_secret' => getenv('CDP_API_KEY_SECRET') ?: null,
    ],

    // ─── BANKON identity gating ──────────────────────────
    'bankon' => [
        'mode' => getenv('BANKON_MODE') ?: 'off',         // off | soft | strict
        'algoidnft_asset_id' => (int)(getenv('BANKON_ALGOIDNFT_ASSET_ID') ?: 0),
        'registry_api' => getenv('BANKON_REGISTRY_API') ?: 'https://bankon.pythai.net/api/v1/identity',
    ],

    // ─── BONAFIDE reputation pricing ─────────────────────
    'bonafide' => [
        'enabled' => (bool)(getenv('BONAFIDE_ENABLED') ?: false),
        'tessera_contract' => getenv('BONAFIDE_TESSERA_CONTRACT') ?: '',
        'rpc_url' => getenv('BONAFIDE_RPC_URL') ?: 'https://mainnet.base.org',
    ],

    // ─── Algorand / Parsec ────────────────────────────────
    'algorand' => [
        'use_parsec' => (bool)(getenv('USE_PARSEC') ?: false),
        'parsec_url' => getenv('PARSEC_FACILITATOR_URL') ?: 'https://parsec.pythai.net/facilitator',
        'fallback_immediately' => !((bool)(getenv('USE_PARSEC') ?: false)),
    ],

    // ─── Logging ──────────────────────────────────────────
    'log_level' => getenv('LOG_LEVEL') ?: 'info',
    'payment_log_path' => getenv('PAYMENT_LOG_PATH') ?: '/var/log/deltaverse/payments.jsonl',
    'refund_log_path' => getenv('REFUND_LOG_PATH') ?: '/var/log/deltaverse/refunds.jsonl',
];
