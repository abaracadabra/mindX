# Changelog

All notable changes to this project will be documented here.

Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). Versioning follows [SemVer](https://semver.org/).

## [1.0.0] - 2026-04-14

### Added

- Initial release of `pythai/deltaverse-x402`.
- `DeltaVerseMiddleware` — PSR-15 middleware wrapping `X402\Server\PaymentMiddleware` with BANKON identity gating and BONAFIDE reputation observation.
- `ParsecAlgorandWallet` — Ed25519 wallet abstraction for Algorand (via `ext-sodium`).
- `ParsecFacilitator` — Algorand x402 facilitator client with automatic Parsec→GoPlausible fallback.
- `IdentityGate` — BANKON cross-chain identity verification (`off` / `soft` / `strict` modes).
- `IdentityRejectedException` — 403-mappable exception for strict-mode rejections.
- `ReputationClient` — BONAFIDE Tessera score lookup with tiered discount factors.
- `DiscoveryService` — emits `/api/v1/services` JSON for AgenticPlace.
- `AllchainMapper` — emits `/api/v1/allchain` JSON and HTML fragment for `allchain.html`.
- `DeltaVerseFactory` — one-call middleware assembly.
- `DomainConfig` — canonical pythai.net URLs and mindX endpoint catalog.
- `NetworkConfig` — Base (mainnet/Sepolia) + Algorand (mainnet/testnet) specs with correct USDC addresses and ASA IDs.
- Four runnable examples: `mindx-server`, `agenticplace-discovery`, `parsec-agent`, `bankon-register`.
- Three long-form docs: `docs/explanation.md`, `docs/technical.md`, `docs/usage.md`.

### Known limitations (v1.0)

- Algorand x402 **client-side** flow not fully implemented in PHP (wallet can sign; full msgpack transaction assembly requires `rybakit/msgpack`). EVM payments work end-to-end.
- BONAFIDE reputation is observational — discounts are logged but not applied to prices. Active discounting requires a `PaymentConfig` subclass (planned for v1.1).
- `ParsecFacilitator` falls back to GoPlausible by default because no public "parsec-wallet" x402 library exists yet. This is documented honestly in `explanation.md`.
- No self-hosted facilitator support — external services only (CDP for Base, GoPlausible/Parsec for Algorand).
- Single-chain per `PaymentConfig`. Multi-chain simultaneous serving requires two middleware registrations.
- BANKON identity cache is in-process only. For multi-worker deployments, swap to Redis.

### Acknowledgements

- Coinbase x402 protocol team for the specification
- GoPlausible for the Algorand reference implementation
- Simplito for `elliptic-php` (used by the base library)
- Kornrunner for `keccak` (used by the base library)
