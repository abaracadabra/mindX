<?php

declare(strict_types=1);

/**
 * AgenticPlace discovery + allchain endpoint.
 *
 * Serves two JSON endpoints at agenticplace.pythai.net:
 *   GET /api/v1/services    — the service registry (mindX, bankon, etc.)
 *   GET /api/v1/allchain    — supported chains with facilitator URLs
 *
 * Also optionally renders an HTML fragment for allchain.html.
 *
 * Drop this behind nginx or run via:
 *   php -S 0.0.0.0:8001 examples/agenticplace-discovery.php
 */

require __DIR__ . '/../vendor/autoload.php';

use DeltaVerse\X402\AgenticPlace\AllchainMapper;
use DeltaVerse\X402\AgenticPlace\DiscoveryService;

$config = require __DIR__ . '/../config/deltaverse.php';

// Simple request routing — in production use Slim/Symfony/etc.
$path = $_SERVER['REQUEST_URI'] ?? '/';
$path = strtok($path, '?');

switch ($path) {
    case '/api/v1/services':
        $discovery = new DiscoveryService(
            basePayToEvm: $config['pay_to']['evm'],
            basePayToAlgorand: $config['pay_to']['algorand'],
            bankonRequired: $config['bankon']['mode'] === 'strict',
        );
        header('Content-Type: application/json');
        header('Cache-Control: public, max-age=300');
        echo $discovery->toJson();
        break;

    case '/api/v1/allchain':
        $mapper = new AllchainMapper();
        header('Content-Type: application/json');
        header('Cache-Control: public, max-age=3600');
        echo $mapper->toJson();
        break;

    case '/allchain.html':
    case '/allchain.htm':
        $mapper = new AllchainMapper();
        header('Content-Type: text/html; charset=utf-8');
        $fragment = $mapper->toHtmlFragment();
        echo <<<HTML
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>AgenticPlace — Supported Chains</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 960px; margin: 2em auto; padding: 0 1em; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background: #f5f5f5; }
    code { font-size: 0.9em; }
  </style>
</head>
<body>
  <h1>Supported chains</h1>
  <p>These chains accept x402 payments for DELTAVERSE services.</p>
  $fragment
  <p><a href="/api/v1/allchain">machine-readable JSON</a> · <a href="/api/v1/services">service registry</a></p>
</body>
</html>
HTML;
        break;

    case '/health':
        header('Content-Type: application/json');
        echo json_encode(['status' => 'ok', 'service' => 'AgenticPlace discovery']);
        break;

    default:
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'not_found',
            'available' => ['/api/v1/services', '/api/v1/allchain', '/allchain.html', '/health'],
        ]);
}
