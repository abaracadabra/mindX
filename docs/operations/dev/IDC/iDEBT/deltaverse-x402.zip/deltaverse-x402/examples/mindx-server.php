<?php

declare(strict_types=1);

/**
 * mindx.pythai.net server — Slim-based, full DELTAVERSE stack.
 *
 * Install:
 *   composer require pythai/deltaverse-x402 slim/slim:"^4.12" slim/psr7
 *
 * Run:
 *   cp config/deltaverse.php.example .env (or set env vars)
 *   php -S 0.0.0.0:8000 examples/mindx-server.php
 *
 * Test:
 *   curl http://localhost:8000/health
 *   php examples/parsec-agent.php http://localhost:8000/api/v1/reason?question=foo
 */

require __DIR__ . '/../vendor/autoload.php';

use DeltaVerse\X402\BANKON\IdentityRejectedException;
use DeltaVerse\X402\Config\DomainConfig;
use DeltaVerse\X402\Integration\DeltaVerseFactory;
use Slim\Factory\AppFactory;
use Slim\Psr7\Factory\ResponseFactory;

$config = require __DIR__ . '/../config/deltaverse.php';

$responseFactory = new ResponseFactory();

$middleware = DeltaVerseFactory::forMindX(
    payToEvm: $config['pay_to']['evm'] ?: '0x0000000000000000000000000000000000000001',
    payToAlgorand: $config['pay_to']['algorand'] ?: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    responseFactory: $responseFactory,
    mode: $config['mode'],
    bankonMode: $config['bankon']['mode'],
    bonafideEnabled: $config['bonafide']['enabled'],
    cdpApiKeyId: $config['cdp']['api_key_id'],
    cdpApiKeySecret: $config['cdp']['api_key_secret'],
);

$app = AppFactory::create();
$app->add($middleware);

// Error handling for BANKON rejection
$errorMiddleware = $app->addErrorMiddleware(true, true, true);
$errorMiddleware->setErrorHandler(
    IdentityRejectedException::class,
    function ($request, \Throwable $exception, $displayErrorDetails) use ($responseFactory) {
        $response = $responseFactory->createResponse(403);
        $response->getBody()->write(json_encode([
            'error' => 'bankon_identity_required',
            'message' => $exception->getMessage(),
            'register_at' => DomainConfig::BANKON_BASE_URL,
        ]));
        return $response->withHeader('Content-Type', 'application/json');
    }
);

// ─── Free endpoints ─────────────────────────────────────────
$app->get('/health', function ($req, $res) {
    $res->getBody()->write(json_encode(['status' => 'ok', 'service' => 'mindX']));
    return $res->withHeader('Content-Type', 'application/json');
});

$app->get('/', function ($req, $res) {
    $res->getBody()->write(json_encode([
        'service' => 'mindX reasoning API',
        'docs' => DomainConfig::MINDX_OPENAPI_URL,
        'discovery' => DomainConfig::AGENTICPLACE_DISCOVERY,
        'identity' => DomainConfig::BANKON_BASE_URL,
    ]));
    return $res->withHeader('Content-Type', 'application/json');
});

// ─── Paid endpoints (x402-gated by middleware) ──────────────
$app->get('/api/v1/reason', function ($req, $res) {
    $payer = $req->getAttribute('x402_payer');
    $tx = $req->getAttribute('x402_tx_hash');
    $question = $req->getQueryParams()['question'] ?? '';

    // This is where you'd actually call your reasoning backend
    $answer = "Reasoning about: $question. The unexamined life is not worth living.";

    $res->getBody()->write(json_encode([
        'question' => $question,
        'answer' => $answer,
        'paid_by' => $payer,
        'tx' => $tx,
    ]));
    return $res->withHeader('Content-Type', 'application/json');
});

$app->post('/api/v1/socratic', function ($req, $res) {
    $body = json_decode((string)$req->getBody(), true) ?? [];
    $res->getBody()->write(json_encode([
        'chain' => [
            'What do you mean by that?',
            'What evidence supports it?',
            'What might contradict it?',
        ],
        'synthesis' => 'Through questioning, clarity emerges.',
        'input' => $body,
    ]));
    return $res->withHeader('Content-Type', 'application/json');
});

$app->post('/api/v1/dream', function ($req, $res) {
    $body = json_decode((string)$req->getBody(), true) ?? [];
    $res->getBody()->write(json_encode([
        'dream' => 'From seed "' . ($body['seed'] ?? 'void') . '" emerges a recursive insight...',
    ]));
    return $res->withHeader('Content-Type', 'application/json');
});

$app->get('/api/v1/agents/discover', function ($req, $res) {
    $res->getBody()->write(json_encode([
        'agents' => [
            ['id' => 'mindx-reasoner', 'capabilities' => ['reason', 'socratic']],
        ],
    ]));
    return $res->withHeader('Content-Type', 'application/json');
});

$app->run();
