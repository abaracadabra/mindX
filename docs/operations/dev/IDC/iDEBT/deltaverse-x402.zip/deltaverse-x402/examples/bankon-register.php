<?php

declare(strict_types=1);

/**
 * Helper: link a wallet to a BANKON AlgoIDNFT identity.
 *
 * This is a one-time operation per wallet. After linking, mindX
 * and any other DELTAVERSE service can verify the payer's identity
 * via the BANKON registry → Algorand indexer flow.
 *
 * Two steps:
 *   1. Register the EVM → Algorand address mapping on-chain
 *      (via the BankonRegistry contract on Base)
 *   2. Ensure the Algorand address holds the AlgoIDNFT ASA
 *
 * This example uses cast (Foundry) for the EVM side — install Foundry
 * first: curl -L https://foundry.paradigm.xyz | bash && foundryup
 *
 * For the Algorand side, use goal CLI or AlgoKit to send the AlgoIDNFT
 * to the address after BANKON issues it.
 *
 * Usage:
 *   export EVM_PRIVATE_KEY=0x...
 *   export ALGO_ADDRESS=ALGO58CHAR...
 *   php examples/bankon-register.php
 */

require __DIR__ . '/../vendor/autoload.php';

use DeltaVerse\X402\Config\DomainConfig;
use DeltaVerse\X402\Config\NetworkConfig;

$evmKey = getenv('EVM_PRIVATE_KEY');
$algoAddress = getenv('ALGO_ADDRESS');

if (!$evmKey || !$algoAddress) {
    fwrite(STDERR, "ERROR: Set EVM_PRIVATE_KEY and ALGO_ADDRESS\n");
    exit(1);
}

if (strlen($algoAddress) !== 58) {
    fwrite(STDERR, "ERROR: ALGO_ADDRESS must be 58 characters\n");
    exit(1);
}

echo "╔══════════════════════════════════════════════════════╗\n";
echo "║         BANKON Identity Registration Helper          ║\n";
echo "╠══════════════════════════════════════════════════════╣\n";
echo "║ Links your EVM wallet to an Algorand address holding ║\n";
echo "║ the BANKON AlgoIDNFT (soulbound identity ASA).       ║\n";
echo "╚══════════════════════════════════════════════════════╝\n\n";

echo "Step 1: Register the EVM → Algorand mapping\n";
echo "─────────────────────────────────────────────\n\n";

// The BankonRegistry contract address will be published at
// bankon.pythai.net once deployed. For now, this is a placeholder.
$registryAddress = DomainConfig::BONAFIDE_GENIUS ?: '0x0000000000000000000000000000000000000000';

if ($registryAddress === '0x0000000000000000000000000000000000000000') {
    fwrite(STDERR, "WARNING: BankonRegistry contract address not yet configured.\n");
    fwrite(STDERR, "         Once deployed, update DomainConfig::BANKON_REGISTRY_API\n");
    fwrite(STDERR, "         and set BONAFIDE_GENIUS constant.\n\n");
    fwrite(STDERR, "For now, the command would be:\n\n");
}

$rpcUrl = NetworkConfig::BASE_MAINNET_RPC;

$command = sprintf(
    "cast send %s \\\n  'linkIdentity(string)' '%s' \\\n  --rpc-url %s \\\n  --private-key \$EVM_PRIVATE_KEY",
    $registryAddress,
    $algoAddress,
    $rpcUrl,
);

echo "$command\n\n";
echo "Step 2: Ensure Algorand address holds the AlgoIDNFT\n";
echo "────────────────────────────────────────────────────\n\n";
echo "Your Algorand address: $algoAddress\n";
echo "Expected ASA ID:       " . DomainConfig::BANKON_ALGOIDNFT_ASSET_ID . "\n\n";

if (DomainConfig::BANKON_ALGOIDNFT_ASSET_ID === 0) {
    echo "WARNING: AlgoIDNFT asset ID not yet configured in DomainConfig.\n";
    echo "         Once the ASA is minted, update BANKON_ALGOIDNFT_ASSET_ID.\n\n";
}

echo "To verify current holding, run:\n\n";
echo "curl '" . NetworkConfig::ALGORAND_MAINNET_INDEXER
    . "/v2/accounts/$algoAddress/assets?asset-id="
    . DomainConfig::BANKON_ALGOIDNFT_ASSET_ID . "' | jq\n\n";

echo "If the response shows a positive 'amount', you're linked and verified.\n";
echo "mindX and any DELTAVERSE service will now recognize your identity.\n";
