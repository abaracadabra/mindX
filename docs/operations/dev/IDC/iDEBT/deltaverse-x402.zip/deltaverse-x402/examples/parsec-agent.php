<?php

declare(strict_types=1);

/**
 * Example DELTAVERSE agent that pays for mindX endpoints.
 *
 * Supports two modes:
 *   EVM mode:   agent has an Ethereum private key, pays on Base
 *   Algorand:   agent uses ParsecAlgorandWallet, pays on Algorand
 *
 * Usage:
 *   # EVM (simpler to get started):
 *   export AGENT_PRIVATE_KEY=0x...
 *   php examples/parsec-agent.php https://mindx.pythai.net/pay/api/v1/reason?question=what+is+being
 *
 *   # Algorand (once Parsec/GoPlausible pipeline is tested):
 *   export PARSEC_ALGO_ADDRESS=ALGO58CHAR...
 *   export PARSEC_ALGO_KEY=base64encoded64bytes
 *   php examples/parsec-agent.php --algo https://mindx.pythai.net/pay/api/v1/reason
 */

require __DIR__ . '/../vendor/autoload.php';

use DeltaVerse\X402\Algorand\ParsecAlgorandWallet;
use X402\Client\X402Client;
use X402\Crypto\Wallet;
use X402\Types\SettlementReceipt;

// ─── Argument parsing ─────────────────────────────────────
$args = $argv;
array_shift($args); // script name

$useAlgorand = in_array('--algo', $args, true);
$args = array_values(array_filter($args, fn($a) => $a !== '--algo'));
$url = $args[0] ?? 'http://localhost:8000/api/v1/reason?question=test';

echo "Target:  $url\n";
echo "Chain:   " . ($useAlgorand ? 'Algorand (via Parsec)' : 'Base EVM') . "\n\n";

if ($useAlgorand) {
    // ─── Algorand path ────────────────────────────────────
    $algoAddress = getenv('PARSEC_ALGO_ADDRESS');
    $algoKey = getenv('PARSEC_ALGO_KEY');
    if (!$algoAddress || !$algoKey) {
        fwrite(STDERR, "ERROR: PARSEC_ALGO_ADDRESS and PARSEC_ALGO_KEY required for --algo\n");
        fwrite(STDERR, "       Use algokit or goplausible to generate a test wallet\n");
        fwrite(STDERR, "       Fund from https://bank.testnet.algorand.network/ on testnet\n");
        exit(1);
    }

    $wallet = ParsecAlgorandWallet::fromPrivateKey($algoKey, $algoAddress);
    echo "Wallet:  {$wallet->address}\n\n";

    fwrite(STDERR, "\nNOTE: Full Algorand x402 client flow requires msgpack transaction\n");
    fwrite(STDERR, "      assembly that is out of scope for this reference example.\n");
    fwrite(STDERR, "      Use GoPlausible's TypeScript client or the mindX Python agent\n");
    fwrite(STDERR, "      for end-to-end Algorand payments today.\n\n");
    fwrite(STDERR, "      This example validates the wallet abstraction only:\n");

    // Demonstrate that the wallet can sign — integration with a real
    // Algorand transaction group requires msgpack which PHP doesn't have
    // in stdlib. Install rybakit/msgpack when you're ready.
    $testPayload = 'test payload — hello DELTAVERSE';
    $signature = $wallet->signBytes($testPayload);
    echo "Test signature (hex): 0x" . bin2hex($signature) . "\n";
    echo "Signature length:     " . strlen($signature) . " bytes (expected 64)\n";
    exit(0);
}

// ─── EVM path (fully working) ───────────────────────────
$privateKey = getenv('AGENT_PRIVATE_KEY');
if (!$privateKey) {
    fwrite(STDERR, "ERROR: AGENT_PRIVATE_KEY env var not set\n");
    fwrite(STDERR, "       Generate with: cast wallet new\n");
    fwrite(STDERR, "       Fund from: https://faucet.circle.com (Base Sepolia USDC)\n");
    exit(1);
}

$wallet = Wallet::fromPrivateKey($privateKey);
echo "Wallet:  {$wallet->address()}\n\n";

$client = new X402Client($wallet);
$response = $client->get($url);

echo "Status:  {$response->getStatusCode()}\n";
echo "Body:    " . (string)$response->getBody() . "\n";

if ($response->hasHeader('PAYMENT-RESPONSE')) {
    $receipt = SettlementReceipt::fromBase64($response->getHeaderLine('PAYMENT-RESPONSE'));
    echo "\nSettlement:\n";
    echo "  Success: " . ($receipt->success ? 'yes' : 'no') . "\n";
    echo "  Tx:      {$receipt->transaction}\n";
    echo "  Network: {$receipt->network}\n";

    $scanUrl = match ($receipt->network) {
        'eip155:8453'  => "https://basescan.org/tx/{$receipt->transaction}",
        'eip155:84532' => "https://sepolia.basescan.org/tx/{$receipt->transaction}",
        'algorand:mainnet-v1.0' => "https://allo.info/tx/{$receipt->transaction}",
        default => null,
    };
    if ($scanUrl) {
        echo "  View:    $scanUrl\n";
    }
}
