DEPLOYMENT
==========

daio_nominee — deployment procedure.
(c) 2026 BANKON — Apache 2.0.


prerequisites
-------------

  - Foundry installed (https://book.getfoundry.sh/getting-started/installation)
  - A deployer EOA with sufficient ETH on the target chain for gas
  - The BONAFIDE Genius contract deployed and its address on hand
  - A treasury address (multisig or contract) to receive DAIO fees
  - The mindX signing keys for attestor and reward claims
  - The list of initial multisig signer addresses and the threshold


workspace setup
---------------

  git clone <repo>
  cd daio_nominee
  forge install foundry-rs/forge-std
  forge install OpenZeppelin/openzeppelin-contracts
  cp .env.example .env
  $EDITOR .env


local verification
------------------

  forge build
  forge test -vv

  Expected: every test in test/ passes. The suite covers:
    - GovernanceMultisig (proposal lifecycle, self-administration,
      threshold validation on signer removal)
    - VariablePaymentGate (price quoting, DAIO transfer, privilege
      gate, allowance/balance error paths)
    - NomineeRegistry (registration, nomination, deduplication,
      self-nomination guard)
    - RewardDistributor (EIP-712 happy path, replay rejection,
      expiry, wrong signer, epoch cap and reset)


dress rehearsal on a fork
-------------------------

  Run against a forked mainnet to validate gas, encoding, and the
  full handover sequence without spending real ETH:

    anvil --fork-url $ETH_MAINNET_RPC --port 8545 &
    forge script script/Deploy.s.sol:Deploy \
        --rpc-url http://localhost:8545 \
        --private-key $DEPLOY_PK \
        --broadcast

  Confirm the console output lists every contract address and that
  the multisig admin transfer logs fire as expected.


mainnet deployment
------------------

  1. Verify .env values one more time. The deployer key briefly holds
     temporary admin over every contract during the broadcast; it
     loses every privilege at the end of the script.

  2. Broadcast:

       forge script script/Deploy.s.sol:Deploy \
           --rpc-url $ETH_MAINNET_RPC \
           --private-key $DEPLOY_PK \
           --broadcast --verify

  3. Record the deployed addresses from the console output. These are
     the canonical addresses for:
       - GovernanceMultisig
       - DAIOToken
       - VariablePaymentGate
       - RewardDistributor
       - IdentifierAttestor
       - NomineeRegistry

  4. Verify on Etherscan that the admin / rotator field of each
     controlled contract reads the multisig address. Specifically:
       - DAIOToken.admin()             == multisig
       - VariablePaymentGate.admin()   == multisig
       - RewardDistributor.admin()     == multisig
       - IdentifierAttestor.admin()    == multisig

  5. Verify that the gate's initial price is configured:
       - VariablePaymentGate.priceDaio(KIND_NOMINATION) == NOMINATION_PRICE

  6. Verify that the DAIO minter is wired:
       - DAIOToken.minter() == RewardDistributor address


post-deployment configuration
-----------------------------

  Any further parameter change is a multisig proposal. Common ones:

  Set endorsement price:
    target = VariablePaymentGate
    data   = encodeFunctionData("setPrice",
              [keccak256("ENDORSEMENT"), <price in wei>])

  Configure motion privilege threshold:
    target = VariablePaymentGate
    data   = encodeFunctionData("setMinHolding",
              [keccak256("MOTION"), <DAIO required in wei>])

  Rotate the mindX attestor key (e.g. after suspected compromise):
    target = IdentifierAttestor
    data   = encodeFunctionData("rotateAttestor", [<new attestor>])

  Adjust the reward epoch cap (e.g. ahead of a campaign):
    target = RewardDistributor
    data   = encodeFunctionData("setEpochCap", [<new cap in wei>])

  Each proposal must collect MULTISIG_THRESHOLD signatures within the
  deadline, then any address may call execute().


next.js admin UI deployment
---------------------------

  1. Place ui/GovernanceMultisigPanel.tsx and ui/abis.ts into the
     LEADER · EARTH Next.js project under app/(admin)/governance/.

  2. Install peer deps if not already present:
       npm install wagmi viem @tanstack/react-query

  3. Wrap the page with the wagmi provider configured for the target
     chain.

  4. Set the NEXT_PUBLIC_* env vars from the deployment output.

  5. Build and deploy as usual:
       npm run build
       npm run start


multi-chain deployment
----------------------

  The same Deploy.s.sol script targets any EVM chain by changing
  --rpc-url and the corresponding BONAFIDE_GENIUS / BANKON_ROOT_NODE
  for that chain.

  Recommended sequence:
    - Ethereum mainnet first (constitutional anchor)
    - Polygon second (for cheaper identifier attestations)
    - Arc third (when mainnet slots are activated)

  Each chain gets its own multisig, its own DAIO token, and its own
  registry. Cross-chain DAIO unification is a separate piece of work
  involving the openBDK validator quorum and the x402 bridge surface.


rollback
--------

  There is no built-in rollback. If a deployed contract has a defect:
    1. Multisig proposes pointing the registry / gate at a new
       implementation (this requires upgradeability, which the v1
       contracts deliberately do not have).
    2. In practice: deploy a fresh registry / gate / etc., migrate
       state via off-chain re-import where applicable, and update the
       UI to point at the new addresses.
    3. The DAIO token itself is intentionally non-upgradeable.
       Re-deploying DAIO loses all balances; design changes there must
       go through a migration token + claim flow.


operational checklist
---------------------

  [ ] Deployer key is freshly generated, used only for this deploy,
      and destroyed afterwards.
  [ ] All multisig signers are hardware-backed.
  [ ] Threshold is at least ceil(N/2) and never less than 2.
  [ ] Treasury is a contract or multisig, not an EOA, unless the EOA
      is intended as a hot collection wallet that drains regularly.
  [ ] mindX signing keys are stored in HSM or equivalent.
  [ ] Epoch cap is set to the smallest value that supports expected
      reward emissions; raise via proposal as engagement grows.
  [ ] Etherscan verification succeeded on every contract.
  [ ] First nomination on mainnet is performed by a multisig signer
      using their own funds, as a live verification of the gate +
      registry path before public launch.
