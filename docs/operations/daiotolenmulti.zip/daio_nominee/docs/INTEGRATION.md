INTEGRATION
===========

daio_nominee — integration points with the PYTHAI/DELTAVERSE/BANKON
ecosystem.
(c) 2026 BANKON — Apache 2.0.


agenticplace.pythai.net
-----------------------

  Role: dossier UI surface (LEADER · EARTH) and public nominee search.

  Reads from on-chain:
    - NomineeRegistry.nominees(identity)         dossier header
    - NomineeRegistry.nominationCount(identity)  the count badge
    - IdentifierAttestor.kindsOf(identity)       identifier list
    - IdentifierAttestor.identifiers(id, kind)   per-identifier record
    - VariablePaymentGate.priceDaio(KIND)        the "$0.50" label
    - VariablePaymentGate.canPerform(actor, KIND) button state

  Writes via user-signed tx:
    - NomineeRegistry.registerNominee(ensNode)
    - NomineeRegistry.nominate(nominee)
    - IdentifierAttestor.declare(kind, value)

  Subscribes to events:
    - NomineeRegistered, Nominated, NomineeDeactivated
    - IdentifierDeclared, IdentifierVerified, IdentifierRevoked


mindx.pythai.net
----------------

  Role: identifier verification, reward issuance, attestor key.

  Authenticated endpoints (mindX backend):
    POST /v1/attest/github
      Verifies a GitHub claim by checking a gist signed under the
      user's session, then submits an on-chain
      IdentifierAttestor.verify(identity, keccak256("github"),
      evidenceHash). The mindX server signs the transaction with the
      attestor key configured at deployment.

    POST /v1/attest/x
      Verifies an X (Twitter) handle by checking a tweet or bio
      reference. Same on-chain settle path.

    POST /v1/attest/website
      Verifies a website by checking a DNS TXT record or a well-known
      file. Same on-chain settle path.

    POST /v1/reward/claim
      Given the authenticated session and the current activity log,
      computes a reward amount per the mindX policy and returns an
      EIP-712 signed RewardClaim:
        { recipient, amount, nonce, deadline, signature }
      The client submits this to RewardDistributor.claim on-chain.
      The mindX server signs with the MINDX_SIGNER key configured at
      deployment.

  Key rotation: if either signing key is suspected compromised, the
  multisig proposes IdentifierAttestor.rotateAttestor or rotates the
  RewardDistributor attestor via the existing rotation path. The
  compromised key cannot rotate itself.

  Allchain registry: mindx.pythai.net/allchain.html serves the
  authoritative chain list. The Deploy.s.sol script reads its target
  chain from the --rpc-url; the chain list itself is used by the UI
  to render the chain selector in the admin panel and by the
  agenticplace.pythai.net dossier surface to render per-chain nominee
  counts.


bankon.pythai.net
-----------------

  Role: ENS subname issuance under bankon.eth.

  Each nominee owns a subname like codephreak.bankon.eth. The
  BANKON ENS registrar issues the subname and points its resolver at
  the nominee's identity address. Once owned, the nominee calls
  NomineeRegistry.registerNominee(namehash) passing the subname's
  namehash.

  Resolver records (recommended off-chain wiring):
    addr               nominee identity
    text "url"         agenticplace.pythai.net/dossier/<subname>
    text "avatar"      IPFS hash of nominee photo
    text "description" nominee bio / role
    text "com.github"  github handle (mirrors IdentifierAttestor)
    text "com.x"       x handle
    text "url.website" personal website

  The agenticplace dossier renders from a combination of ENS text
  records (off-chain, cheap to update) and IdentifierAttestor
  on-chain records (authoritative, verified). The UI surfaces the
  on-chain record as the green checkmark; the ENS text records are
  the unverified hints used for initial discovery.


parsec / parsec-wallet
----------------------

  Role: x402 signing surface for cross-chain DAIO flows.

  Initial v1 release does not require parsec-wallet for the EVM-
  native path. A user with any EVM wallet (MetaMask, WalletConnect,
  etc.) can approve DAIO and call nominate / claim directly.

  parsec-wallet integration enters when:
    - DAIO is mirrored as an Algorand ASA
    - Algorand-originated users want to participate in DAIO governance
      on the EVM side without bridging manually
    - Reward recipients want DAIO dispensed natively on Algorand

  Required adapter contracts (out of scope for v1):
    EvmCreditAdapter
      Listens to X402SatpayBridge.PaymentConsumed; credits the gate
      treasury on behalf of the user identified in the receipt.

    AlgoMintBridge
      RewardDistributor mints to an escrow contract; an off-chain
      relayer (openBDK validator quorum, 2-of-3) attests the mint
      and dispenses equivalent DAIO ASA on Algorand.

  Both adapters operate through the existing X402SatpayBridge
  interface; the bridge does not require changes to support DAIO
  alongside SATPAY.


CONCLAVE protocol
-----------------

  Role: private mesh coordination for nominee deliberation.

  Where the public dossier surface uses NomineeRegistry, the
  CONCLAVE "1 Convener + 7 Counsellors" architecture supports
  private deliberation among signers ahead of public nomination.
  The gating contract for CONCLAVE membership is BONAFIDE, not
  NomineeRegistry, so the integration point is at the BONAFIDE
  Senatus layer rather than within daio_nominee directly. The
  reward distributor can be configured to mint to CONCLAVE
  participants on deliberation milestones via the standard claim
  flow.


BONAFIDE constitutional substrate
---------------------------------

  Role: identity (Genius), reputation (Fides), claims (Tessera).

  daio_nominee consumes three BONAFIDE interfaces:
    IGenius.isEnrolled(subject)         enrollment gate
    IGenius.identityOf(subject)         wallet → identity resolution
    IFides.scoreOf(identity)            reputation (reserved for
                                        future discount mechanic)
    ITessera.hasClaim(identity, claim)  on-chain claim verification

  The full BONAFIDE nine-contract suite (Genius, BonaToken,
  Tabularium, Fides, SponsioPactum, Censura, Senatus, Tessera,
  Curia) is not re-implemented here. Vendor it through Foundry
  remappings in lib/bonafide or via git submodule.


x402 + 0G + AgenticPlace
------------------------

  Role: agent-driven nominations and ERC-7857 INFT alignment.

  When mindX agents are themselves nominees (the agenticplace × 0G
  unified submission case), the agent's identity is its ERC-8004
  identity record, and its dossier nodes resolve to the agent's
  0G storage manifest. The reward signer can be the agent's own
  signing key under mindX delegation rules, allowing agents to
  earn DAIO from successful task execution and use it to vote on
  marketplace governance.

  This is fully supported by v1 contracts without modification: the
  gate, registry, and distributor do not distinguish between human
  and agent identities; both are addresses indexed by Genius.
