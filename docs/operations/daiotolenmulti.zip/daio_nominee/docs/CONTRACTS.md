CONTRACTS
=========

daio_nominee — per-contract API reference.
(c) 2026 BANKON — Apache 2.0.


DAIOToken
---------

  ERC-20 governance token with EIP-2612 permit.

  Constructor:
    constructor(address admin_)
      name   = "DAIO"
      symbol = "DAIO"
      Sets initial admin; admin can rotate itself or rotate minter.

  Storage:
    minter   address authorised to mint
    admin    address authorised to rotate minter and admin itself

  Functions:
    mint(address to, uint256 amount)
      Restricted to minter. Mints `amount` to `to`.

    setMinter(address newMinter)
      Restricted to admin. Sets minter address.

    rotateAdmin(address newAdmin)
      Restricted to admin. Transfers admin role.

    Standard ERC-20 surface: transfer, transferFrom, approve,
    balanceOf, allowance, totalSupply, name, symbol, decimals.

    EIP-2612 permit surface: permit, nonces, DOMAIN_SEPARATOR.

  Errors:
    NotMinter, NotAdmin

  Events:
    MinterSet(address previous, address next)
    AdminRotated(address previous, address next)
    Standard ERC-20 Transfer, Approval events.


VariablePaymentGate
-------------------

  DAIO-denominated fee schedule and privilege gate.

  Constructor:
    constructor(IERC20 daio_, address treasury_, address admin_)

  Constants:
    KIND_NOMINATION   = keccak256("NOMINATION")
    KIND_ENDORSEMENT  = keccak256("ENDORSEMENT")
    KIND_MOTION       = keccak256("MOTION")
    KIND_COMMENT      = keccak256("COMMENT")

  Storage:
    daio                  immutable token reference
    treasury              fee recipient
    admin                 governance role (multisig)
    priceDaio[kind]       DAIO charge for action kind (18 dec)
    minHoldingDaio[kind]  required holding to clear privilege (18 dec)

  Functions:
    quote(actor, kind) -> uint256
      View. Returns the price for `actor` to perform `kind`. Reverts
      with UnpricedAction(kind) if the price is zero (unpriced).

    canPerform(actor, kind) -> bool
      View. True iff `kind` is priced and `actor` holds at least
      max(priceDaio[kind], minHoldingDaio[kind]).

    settle(actor, kind) -> uint256
      Charges `actor` the quoted price, routing to treasury via
      ERC-20 transferFrom. Reverts on insufficient holding, on
      insufficient allowance, or on transfer failure.

    setPrice(kind, priceDaio_) [admin]
    setMinHolding(kind, minHolding_) [admin]
    setTreasury(newTreasury) [admin]
    rotateAdmin(newAdmin) [admin]

  Errors:
    NotAdmin, UnpricedAction, InsufficientHolding, TransferFailed

  Events:
    PriceSet, MinHoldingSet, TreasurySet, AdminRotated
    Quoted, Settled


RewardDistributor
-----------------

  EIP-712 signed reward claim minter.

  Constructor:
    constructor(
      DAIOToken daio_,
      address attestor_,
      address admin_,
      uint256 epochLength_,
      uint256 epochCap_
    )

  Typed data:
    RewardClaim(address recipient, uint256 amount,
                uint256 nonce, uint256 deadline)
    Domain: "DAIO RewardDistributor v1"

  Storage:
    daio          immutable
    attestor      EIP-712 signer
    admin         governance role (multisig)
    epochLength   immutable
    genesis       immutable (deployment time)
    epochCap      adjustable per-epoch mint ceiling
    mintedInEpoch[e]
    nonces[recipient]

  Functions:
    currentEpoch() -> uint256
      View. (block.timestamp - genesis) / epochLength.

    claim(RewardClaim c, bytes signature)
      Verifies deadline, nonce, signer, epoch cap; mints DAIO.

    rotateAttestor(newAttestor) [admin]
    rotateAdmin(newAdmin) [admin]
    setEpochCap(cap) [admin]

  Errors:
    NotAdmin, BadSigner, ClaimExpired,
    WrongNonce, EpochCapExceeded

  Events:
    Claimed, AttestorRotated, AdminRotated, EpochCapSet


IdentifierAttestor
------------------

  Registry of external identifiers bound to Genius identities.

  Constructor:
    constructor(IGenius genius_, address attestor_, address admin_)

  Storage:
    genius             immutable
    attestor           operational mindX signing key
    admin              governance role (multisig)
    identifiers[id][kind] -> Identifier
    kindsOf[id]        bytes32[] of declared kinds

  Identifier struct:
    bytes32 kind
    string  value
    bool    verified
    bytes32 evidence
    uint64  updatedAt

  Functions:
    declare(kind, value)
      Restricted to enrolled identities. Adds or replaces an
      identifier; clears the verified flag.

    verify(identity, kind, evidence) [attestor]
      Marks the identifier verified.

    revoke(identity, kind) [attestor]
      Clears the verified flag without removing the declaration.

    rotateAttestor(newAttestor) [admin]
    rotateAdmin(newAdmin) [admin]

    kindCount(identity) -> uint256
      View. Number of declared kinds for `identity`.

  Errors:
    NotIdentity, NotAttestor, NotAdmin, NotEnrolled, UnknownKind

  Events:
    IdentifierDeclared, IdentifierVerified, IdentifierRevoked
    AttestorRotated, AdminRotated


NomineeRegistry
---------------

  ENS-bound nominee dossier substrate.

  Constructor:
    constructor(IGenius genius_, VariablePaymentGate gate_,
                bytes32 bankonRootNode_)

  Constants:
    ACTION_KIND = keccak256("NOMINATION")

  Storage:
    genius           immutable
    gate             immutable
    bankonRootNode   immutable (namehash of bankon.eth)
    nominees[id] -> Nominee
    nodeToIdentity[ensNode] -> identity
    hasNominated[nominator][nominee] -> bool

  Nominee struct:
    address identity
    bytes32 ensNode
    uint64  registeredAt
    uint64  nominationCount
    bool    active

  Functions:
    registerNominee(ensNode)
      Caller's enrolled identity is registered against the ENS node.

    deactivate()
      Sets the caller's nominee record active=false. Re-activation
      is intentionally not supported.

    nominate(nominee)
      Caller's identity submits a nomination for `nominee`.
      Requires: enrolled, not self, nominee active, not already
      voted for this nominee. Pays through gate.settle.

    nominationCount(nominee) -> uint64 (view)
    isNominee(identity) -> bool (view)

  Errors:
    NotEnrolled, AlreadyRegistered, UnknownNominee,
    DuplicateNomination, SelfNomination, NomineeInactive

  Events:
    NomineeRegistered, NomineeDeactivated, Nominated


GovernanceMultisig
------------------

  On-chain N-of-M operational controller.

  Constructor:
    constructor(address[] initialSigners, uint256 initialThreshold)

  Storage:
    isSigner[address] -> bool
    _signers internal array of current signers
    threshold
    proposalCount
    _proposals[id] -> Proposal
    hasSigned[id][signer] -> bool

  Proposal struct:
    address target
    uint256 value
    bytes   data
    uint64  deadline
    uint32  signatureCount
    bool    executed

  Functions:
    propose(target, data, value, deadline) -> id [signer]
      Creates a proposal and counts the proposer as first signer.

    sign(id) [signer]
      Adds the caller's signature.

    execute(id) -> bytes
      Permissionless. Requires signatures >= threshold and
      deadline >= now. Performs (target).call{value: value}(data).

    addSigner(signer) [self]
    removeSigner(signer) [self]
    setThreshold(newThreshold) [self]

    signers() -> address[] (view)
    signerCount() -> uint256 (view)
    getProposal(id) -> (target, value, data, deadline,
                       signatureCount, executed) (view)
    canExecute(id) -> bool (view)

    receive() external payable

  Errors:
    NotSigner, NotSelf, AlreadySigner, UnknownSigner,
    InvalidThreshold, UnknownProposal, AlreadyExecuted,
    AlreadySigned, DeadlinePassed, BelowThreshold, ExecutionFailed

  Events:
    SignerAdded, SignerRemoved, ThresholdChanged
    ProposalCreated, ProposalSigned, ProposalExecuted


X402SatpayBridge
----------------

  Reference EVM-side surface for Algorand-settled payments. Not in
  the critical path for EVM-native voting; preserved for cross-chain
  DAIO mirroring.

  Constructor:
    constructor(address relayer_, address admin_)

  Storage:
    receipts[txid] -> Receipt
    relayer, consumer, admin

  Receipt struct:
    address payer
    uint256 amountSatpay
    uint64  algoRound
    bool    consumed

  Functions:
    recordPayment(algoTxid, payer, amount, algoRound) [relayer]
    consumePayment(algoTxid, minAmount, expectedPayer) -> amount
      [consumer; one-shot]
    paymentOf(algoTxid) -> uint256 (view, 0 if consumed/unknown)
    setConsumer(consumer_) [admin]
    rotateRelayer(relayer_) [admin]
    rotateAdmin(admin_) [admin]

  Errors:
    NotRelayer, NotConsumer, NotAdmin,
    AlreadyRecorded, UnknownReceipt, AlreadyConsumed,
    PayerMismatch, UnderQuoted

  Events:
    PaymentRecorded, PaymentConsumed
