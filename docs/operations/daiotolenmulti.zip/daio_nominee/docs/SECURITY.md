SECURITY
========

daio_nominee — threat model and operational security.
(c) 2026 BANKON — Apache 2.0.

This document describes the assumed threat model, the mechanisms used
to mitigate each class of attack, and the residual risks that remain
after those mitigations. It is intended for auditors, signers, and
operators rather than end users.


actors
------

  end user                  holds an EVM wallet; participates in
                            voting and nominee dossiers

  nominee                   an end user who has registered their
                            identity for the dossier surface

  multisig signer           a member of the GovernanceMultisig signer
                            set; can propose and approve operational
                            changes

  mindX attestor key        the operational signing key used by the
                            mindX backend to attest identifier
                            verifications

  mindX claim signer        the operational signing key used by the
                            mindX backend to issue EIP-712 reward
                            claims

  openBDK relayer           the cross-chain attestation quorum
                            (1-relayer-plus-3-validators, 2-of-3),
                            used only for the x402 bridge path

  treasury                  the address that receives DAIO fees

  attacker                  external party with arbitrary
                            computational capability but no
                            privileged keys


trust assumptions
-----------------

  T1  BONAFIDE Genius correctly distinguishes enrolled identities
      from non-enrolled addresses. A compromised Genius would let an
      attacker register fake nominees and cast fake nominations.

  T2  The multisig signer set is not majority-compromised. The
      threshold provides resistance up to (threshold - 1) compromised
      signers.

  T3  The mindX attestor and claim signing keys are not compromised.
      A compromised attestor can mark arbitrary identifiers verified;
      a compromised claim signer can mint up to the per-epoch cap of
      DAIO to arbitrary recipients per epoch.

  T4  The deployer key, used only during the deployment broadcast,
      is generated fresh and destroyed afterwards. All admin roles
      transfer to the multisig before the broadcast ends, so a
      retained deployer key has no further privilege.

  T5  Underlying chain consensus is honest. Reorgs longer than the
      finality window can replay or invalidate events; consumers of
      Nominated / Claimed events should wait for finality before
      taking irreversible actions.


threat classes and mitigations
------------------------------

  spam / sybil amplification

    Threat: an attacker creates many wallets and casts many
    nominations to manipulate the dossier ranking.

    Mitigations:
      - Identity enrolment gates the nominate path; non-enrolled
        wallets cannot vote at all.
      - Each nomination costs DAIO, paid to the treasury. Bulk
        amplification requires bulk DAIO acquisition.
      - Per-(nominator, nominee) deduplication prevents the same
        identity from voting twice for the same nominee.
      - Self-nomination is rejected explicitly.

    Residual: an attacker willing to spend DAIO can still pad
    counts up to their budget. The cost ratchets the attack from
    free to expensive but does not make it impossible.


  unauthorized parameter change

    Threat: an attacker tries to change the nomination price, drain
    the treasury, or rotate a signing key.

    Mitigations:
      - Every parameter is admin-gated, and every admin is the
        multisig.
      - Multisig proposals require threshold signatures.
      - Signer set changes route through the multisig itself, so an
        attacker who compromises one signer cannot unilaterally add
        their own signer.

    Residual: an attacker who compromises threshold signers can do
    anything the multisig can do. Mitigate by hardware-backing
    signers and by setting threshold conservatively.


  reward minting abuse

    Threat: an attacker tries to mint DAIO to themselves without
    legitimate engagement.

    Mitigations:
      - All mints go through RewardDistributor.claim, which requires
        an EIP-712 signature from the configured claim signer.
      - Per-recipient nonces prevent replay of a single signed claim.
      - Per-claim deadline limits the validity window.
      - Per-epoch cap bounds total emissions even under a key
        compromise; the cap is governance-adjustable.

    Residual: a compromised claim signer can mint up to the per-
    epoch cap per epoch until the multisig rotates the signer.
    Mitigate by setting the cap conservatively and by monitoring
    Claimed events for anomalies.


  identifier impersonation

    Threat: an attacker tries to declare and "verify" a github
    handle they do not control.

    Mitigations:
      - Declarations are open (any enrolled identity can claim any
        string), but only the attestor key can flip the verified
        bit.
      - The mindX backend performs the off-chain verification (gist
        signature, DNS TXT record, X bio) before issuing the
        verify() transaction.
      - Re-declaration clears the verified bit; a verified claim is
        always tied to the most recent declaration.

    Residual: a compromised attestor key can mark any declaration
    verified. Mitigate by hardware-backing the attestor and
    rotating it via the multisig at the first sign of trouble.


  treasury redirection

    Threat: an attacker tries to redirect the DAIO fee stream to
    their own address.

    Mitigations:
      - gate.setTreasury is admin-gated; only the multisig can
        change the treasury.
      - Treasury changes emit a TreasurySet event that off-chain
        monitoring should watch for.

    Residual: a compromised multisig (threshold signers) can
    redirect treasury. No on-chain mitigation possible; mitigate
    operationally as for any other multisig action.


  governance lockout

    Threat: a sequence of signer removals or threshold changes
    leaves the multisig unable to act (threshold > signers, or no
    legitimate signers remain).

    Mitigations:
      - removeSigner checks that threshold <= remaining signer
        count and reverts otherwise.
      - setThreshold rejects threshold = 0 and threshold > signer
        count.

    Residual: a malicious threshold majority could still execute a
    proposal that adds an attacker-controlled signer; this is
    standard multisig governance risk.


  bridge replay

    Threat: an attacker tries to replay an Algorand-side x402
    payment receipt to redeem the gated action multiple times.

    Mitigations:
      - X402SatpayBridge marks receipts as consumed on first
        redemption; the consumed flag is set before the gated call
        proceeds.
      - Receipts bind to expectedPayer at consumption time, so
        receipts cannot be redirected.

    Residual: relies on the openBDK quorum to attest only real
    Algorand payments. A compromised quorum can record fictitious
    receipts. Mitigate by the 2-of-3 validator design and by
    rotating relayer / admin via the multisig.


  upgrade and migration

    The v1 contracts are intentionally non-upgradeable. There is no
    proxy, no admin slot for implementation switching, no UUPS or
    transparent proxy pattern. This is a deliberate choice to keep
    the audit surface small and to make supply behaviour
    predictable.

    Consequence: a defect in any contract requires fresh deployment
    and state migration. The token in particular cannot be migrated
    without losing balances unless an explicit migration contract
    is deployed alongside the new token to claim from the old.


reentrancy
----------

  All state mutations precede external calls in every contract.
  Specifically:
    - gate.settle increments allowance state implicitly via
      transferFrom (handled by OpenZeppelin ERC20), reads balance,
      then performs the transfer. No reentrancy hazard.
    - registry.nominate marks hasNominated and increments the count
      BEFORE calling gate.settle. Even if the gate could reenter,
      the duplicate-nomination check would block the second call.
    - distributor.claim advances the nonce and the epoch tally
      BEFORE calling daio.mint. Mint is a privileged action on a
      token under our own control; no untrusted call path.
    - multisig.execute marks executed = true before the low-level
      call. A reentrant call back into execute() finds executed=true
      and reverts via AlreadyExecuted.


operational hardening
---------------------

  Signer key management:
    - Use hardware wallets (Ledger, Trezor) or equivalent HSM
      for every multisig signer.
    - Do not share signers between this multisig and any other
      operational responsibility.
    - Geographically distribute signers.

  mindX key management:
    - Attestor and claim signer keys live in an HSM behind the
      mindX backend.
    - Rotation procedure is documented and rehearsed.
    - Per-epoch cap is set such that worst-case key compromise
      caps DAIO loss at an acceptable fraction of total supply.

  Monitoring:
    - Index every event from every contract.
    - Alert on unusual patterns: surge in Nominated events from a
      single nominator, near-cap Claimed emissions, any
      AdminRotated or AttestorRotated event, any TreasurySet event.

  Incident response:
    - Have a written runbook for key compromise that lists the
      multisig proposal calldata for every rotation operation.
    - Pre-sign at least one signer's portion of the rotation
      proposal where the threat model permits, to reduce time-to-
      response.


reporting
---------

  Security issues to: security@bankon.pythai.net (or the public
  contact channel documented at bankon.pythai.net at the time of
  reading). Coordinated disclosure preferred.
