ARCHITECTURE
============

daio_nominee — system architecture and data flow.
(c) 2026 BANKON — Apache 2.0.


overview
--------

  The daio_nominee system is the on-chain substrate for the LEADER ·
  EARTH nominee dossier surface, extended into a closed-loop DAIO
  governance economy. Seven contracts cooperate to bind off-chain
  identity claims to on-chain identity records, charge a DAIO fee for
  each governance action, reward authenticated participation, gate
  privileged actions by token holdings, and route every operational
  parameter change through a multisig-controlled proposal flow.


contract topology
-----------------

  GovernanceMultisig
       │
       │ holds admin role over each of:
       ▼
  ┌───────────────┬───────────────┬────────────────┬───────────────┐
  │  DAIOToken    │  PaymentGate  │  RewardDist.   │  Attestor     │
  │               │               │                │               │
  │ ERC-20 +      │ price + min   │ EIP-712        │ identifier    │
  │ permit        │ holding per   │ signed claims  │ declarations  │
  │ minter slot   │ action kind   │ epoch cap      │ + verifications│
  └───────────────┴───────────────┴────────────────┴───────────────┘
       ▲                ▲                ▲                ▲
       │                │                │                │
       │ mints to       │ transferFrom   │ mints to       │ verify /
       │ recipients     │ actor → tres.  │ claim signer   │ revoke
       │                │                │                │
  RewardDistributor   actors (users)   mindX backend    mindX backend

       ┌──────────────────────────────────┐
       │  NomineeRegistry                 │
       │                                  │
       │  binds Genius identity ↔ ENS     │
       │  node under bankon.eth; counts   │
       │  nominations; deduplicates per   │
       │  nominator; gates via            │
       │  PaymentGate.settle()            │
       └──────────────────────────────────┘
                     ▲
                     │ reads identity from
                     │
            BONAFIDE Genius (external)


data flow — nomination
----------------------

  1. User opens LEADER · EARTH dossier page for a nominee.
  2. UI checks gate.canPerform(user, KIND_NOMINATION). If false because
     the user lacks DAIO, UI prompts to earn or acquire.
  3. UI calls daio.permit(user, gate, amount, deadline, v, r, s) to
     grant allowance gaslessly (or daio.approve in a prior tx).
  4. UI calls registry.nominate(nomineeAddress).
  5. Registry validates: user enrolled in Genius, not self-nominating,
     nominee exists and active, no prior nomination from this user.
  6. Registry calls gate.settle(user, KIND_NOMINATION).
  7. Gate quotes the configured DAIO price, checks min-holding
     threshold (zero by default for nominations), and pulls DAIO from
     user to treasury via transferFrom.
  8. Registry increments nominee.nominationCount and emits Nominated.
  9. UI subscribes to the Nominated event and updates the dossier.


data flow — reward claim
------------------------

  1. Off-chain: mindX backend observes user activity (login, votes,
     dossier engagement) and computes reward amount per its policy.
  2. mindX backend constructs a RewardClaim struct, signs it under the
     EIP-712 domain "DAIO RewardDistributor v1" with the MINDX_SIGNER
     key, and returns the signature to the user's session.
  3. User submits distributor.claim(claim, signature).
  4. Distributor verifies deadline, nonce, signer; checks per-epoch
     cap; advances nonce; mints DAIO to claim.recipient.
  5. UI subscribes to Claimed event and updates the balance display.


data flow — governance change
-----------------------------

  1. A multisig signer opens the GovernanceMultisigPanel UI.
  2. Signer selects a template (e.g. "set nomination price") and fills
     in the new value.
  3. UI encodes the calldata via viem and calls multisig.propose(
        target, calldata, value, deadline).
  4. The proposing signer is automatically counted as the first signer.
  5. Other signers see the pending proposal in the panel, review it,
     and call multisig.sign(id).
  6. Once the signature count reaches threshold, any address may call
     multisig.execute(id).
  7. The multisig performs a low-level call to (target, calldata).
  8. Target contract validates msg.sender == admin (== multisig
     address) and applies the change.


role separation
---------------

  Every contract that admits a privileged operational key separates
  it from the rotation authority. The operational key (minter,
  attestor, claim signer, relayer) performs high-frequency operations
  but cannot rotate itself. The admin role (multisig) holds the
  rotation power and never performs the operational call directly.

  Summary table:

    contract              operational role        admin role
    ─────────────────────────────────────────────────────────
    DAIOToken             minter (= RewardDist.)  multisig
    VariablePaymentGate   —                       multisig
    RewardDistributor     attestor (= MINDX_SIG)  multisig
    IdentifierAttestor    attestor (= mindX key)  multisig
    X402SatpayBridge      relayer (= openBDK)     multisig
    NomineeRegistry       —                       (no admin role)


cross-chain surface
-------------------

  The EVM-native flow described above does not depend on the x402
  bridge. The bridge interface is preserved for future use when DAIO
  is mirrored as an Algorand ASA:

    inbound  parsec-wallet user pays DAIO ASA on Algorand
             openBDK relayer attests
             EVM adapter consumes receipt and credits the gate treasury
             on behalf of the user

    outbound RewardDistributor mints to a bridge escrow
             openBDK relayer dispenses DAIO ASA on Algorand
             parsec-wallet user sees increased balance

  Both adapter paths are deliberately out of scope for v1. They will
  be added when the Algorand DAIO ASA is issued and the openBDK
  validator quorum is configured for DAIO.


storage layout invariants
-------------------------

  GovernanceMultisig
    _signers          dynamic array, no holes; deletion is swap-and-pop
    isSigner          mirrors _signers; always kept in sync
    threshold         always 1 ≤ threshold ≤ _signers.length

  VariablePaymentGate
    priceDaio[kind]      0 means "kind unpriced; cannot settle"
    minHoldingDaio[kind] 0 means "no privilege threshold"

  RewardDistributor
    nonces[recipient]    monotonically increasing; claims must use the
                         current value
    mintedInEpoch[e]     resets at each new epoch (epochs are
                         non-overlapping windows of epochLength seconds)

  NomineeRegistry
    nominees[id].active  false means the identity was deactivated;
                         registration cannot be re-attempted
    hasNominated[a][b]   monotonic; once true, never false
