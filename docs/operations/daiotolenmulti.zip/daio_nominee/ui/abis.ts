// (c) 2026 BANKON — all rights reserved
// Apache-2.0

// Minimal ABIs sufficient for the admin UI. Generate the full ABIs
// from Foundry artifacts (out/*.json) for production use.

export const multisigAbi = [
  {
    type: "function",
    name: "threshold",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "signerCount",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "signers",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "address[]" }],
  },
  {
    type: "function",
    name: "isSigner",
    stateMutability: "view",
    inputs: [{ name: "who", type: "address" }],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    type: "function",
    name: "proposalCount",
    stateMutability: "view",
    inputs: [],
    outputs: [{ name: "", type: "uint256" }],
  },
  {
    type: "function",
    name: "getProposal",
    stateMutability: "view",
    inputs: [{ name: "id", type: "uint256" }],
    outputs: [
      { name: "target",         type: "address" },
      { name: "value",          type: "uint256" },
      { name: "data",           type: "bytes"   },
      { name: "deadline",       type: "uint64"  },
      { name: "signatureCount", type: "uint32"  },
      { name: "executed",       type: "bool"    },
    ],
  },
  {
    type: "function",
    name: "hasSigned",
    stateMutability: "view",
    inputs: [
      { name: "id",     type: "uint256" },
      { name: "signer", type: "address" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    type: "function",
    name: "canExecute",
    stateMutability: "view",
    inputs: [{ name: "id", type: "uint256" }],
    outputs: [{ name: "", type: "bool" }],
  },
  {
    type: "function",
    name: "propose",
    stateMutability: "nonpayable",
    inputs: [
      { name: "target",   type: "address" },
      { name: "data",     type: "bytes"   },
      { name: "value",    type: "uint256" },
      { name: "deadline", type: "uint64"  },
    ],
    outputs: [{ name: "id", type: "uint256" }],
  },
  {
    type: "function",
    name: "sign",
    stateMutability: "nonpayable",
    inputs: [{ name: "id", type: "uint256" }],
    outputs: [],
  },
  {
    type: "function",
    name: "execute",
    stateMutability: "nonpayable",
    inputs: [{ name: "id", type: "uint256" }],
    outputs: [{ name: "returnData", type: "bytes" }],
  },
  {
    type: "event",
    name: "ProposalCreated",
    inputs: [
      { name: "id",       type: "uint256", indexed: true  },
      { name: "proposer", type: "address", indexed: true  },
      { name: "target",   type: "address", indexed: true  },
      { name: "value",    type: "uint256", indexed: false },
      { name: "deadline", type: "uint64",  indexed: false },
    ],
    anonymous: false,
  },
  {
    type: "event",
    name: "ProposalSigned",
    inputs: [
      { name: "id",       type: "uint256", indexed: true  },
      { name: "signer",   type: "address", indexed: true  },
      { name: "newCount", type: "uint32",  indexed: false },
    ],
    anonymous: false,
  },
  {
    type: "event",
    name: "ProposalExecuted",
    inputs: [
      { name: "id",         type: "uint256", indexed: true },
      { name: "success",    type: "bool",    indexed: false },
      { name: "returnData", type: "bytes",   indexed: false },
    ],
    anonymous: false,
  },
] as const;

// Selectors for common targeted actions, exposed for the proposal builder.
export const gateAbi = [
  {
    type: "function",
    name: "setPrice",
    stateMutability: "nonpayable",
    inputs: [
      { name: "kind",      type: "bytes32" },
      { name: "priceDaio", type: "uint256" },
    ],
    outputs: [],
  },
  {
    type: "function",
    name: "setMinHolding",
    stateMutability: "nonpayable",
    inputs: [
      { name: "kind",           type: "bytes32" },
      { name: "minHoldingDaio", type: "uint256" },
    ],
    outputs: [],
  },
  {
    type: "function",
    name: "setTreasury",
    stateMutability: "nonpayable",
    inputs: [{ name: "newTreasury", type: "address" }],
    outputs: [],
  },
] as const;

export const daioAbi = [
  {
    type: "function",
    name: "setMinter",
    stateMutability: "nonpayable",
    inputs: [{ name: "newMinter", type: "address" }],
    outputs: [],
  },
] as const;
