// (c) 2026 BANKON — all rights reserved
// Apache-2.0
//
// GovernanceMultisigPanel
// -----------------------
// Admin UI for the DAIO GovernanceMultisig. Embedded in the LEADER · EARTH
// admin route. Reads the signer set, threshold, and proposal stream from
// the multisig contract; allows signers to propose new actions, sign
// pending proposals, and execute proposals that have reached threshold.
//
// Stack: Next.js / React, wagmi v2 for contract calls, viem for encoding,
// Tailwind for styling. Drop the file into app/(admin)/governance/ or
// equivalent and ensure the wagmi provider wraps the page.

"use client";

import { useMemo, useState } from "react";
import {
  useAccount,
  useReadContract,
  useReadContracts,
  useWriteContract,
} from "wagmi";
import { type Address, type Hex, encodeFunctionData, isAddress } from "viem";
import { multisigAbi, gateAbi, daioAbi } from "./abis";

// -----------------------------------------------------------------------
// Configuration — supply through environment or context in production
// -----------------------------------------------------------------------

const MULTISIG_ADDRESS = process.env
  .NEXT_PUBLIC_MULTISIG_ADDRESS as Address | undefined;

const GATE_ADDRESS = process.env.NEXT_PUBLIC_GATE_ADDRESS as
  | Address
  | undefined;

const DAIO_ADDRESS = process.env.NEXT_PUBLIC_DAIO_ADDRESS as
  | Address
  | undefined;

// -----------------------------------------------------------------------
// Visual primitives (LEADER · EARTH palette)
// -----------------------------------------------------------------------

const navy = "bg-[#0B1426] text-[#E6E6E6]";
const gold = "text-[#D4AF37]";
const goldBorder = "border-[#D4AF37]";
const goldFill = "bg-[#D4AF37] text-[#0B1426] hover:brightness-110";
const ghostButton = `border ${goldBorder} ${gold} px-4 py-2 tracking-widest text-xs hover:bg-[#D4AF37]/10`;
const primaryButton = `${goldFill} px-4 py-2 tracking-widest text-xs font-semibold`;
const labelStyle = `${gold} text-xs tracking-[0.2em]`;

// -----------------------------------------------------------------------
// Panel
// -----------------------------------------------------------------------

export default function GovernanceMultisigPanel() {
  if (!MULTISIG_ADDRESS) {
    return (
      <div className={`${navy} p-8`}>
        <p className={labelStyle}>
          NEXT_PUBLIC_MULTISIG_ADDRESS is not configured.
        </p>
      </div>
    );
  }

  return (
    <div className={`${navy} min-h-screen p-6 md:p-10 font-serif`}>
      <header className="mb-10 border-b border-[#1F2A40] pb-6">
        <p className={labelStyle}>GOVERNANCE · MULTISIG</p>
        <h1 className="text-4xl md:text-5xl mt-2 tracking-wide">DAIO Council</h1>
      </header>
      <SignerSummary />
      <ProposalList />
      <Propose />
    </div>
  );
}

// -----------------------------------------------------------------------
// Signer summary
// -----------------------------------------------------------------------

function SignerSummary() {
  const signers = useReadContract({
    address: MULTISIG_ADDRESS,
    abi: multisigAbi,
    functionName: "signers",
  });
  const threshold = useReadContract({
    address: MULTISIG_ADDRESS,
    abi: multisigAbi,
    functionName: "threshold",
  });

  return (
    <section className="mb-12">
      <p className={labelStyle}>SIGNERS · THRESHOLD</p>
      <div className="mt-3 flex items-baseline gap-6">
        <span className="text-3xl">
          {threshold.data?.toString() ?? "—"}
          <span className="text-[#94A3B8] mx-2">of</span>
          {signers.data?.length ?? "—"}
        </span>
      </div>
      <ul className="mt-4 space-y-1 text-sm font-mono">
        {(signers.data as Address[] | undefined)?.map((s) => (
          <li key={s} className="text-[#94A3B8]">
            {s}
          </li>
        ))}
      </ul>
    </section>
  );
}

// -----------------------------------------------------------------------
// Proposal list
// -----------------------------------------------------------------------

function ProposalList() {
  const count = useReadContract({
    address: MULTISIG_ADDRESS,
    abi: multisigAbi,
    functionName: "proposalCount",
  });

  const total = Number(count.data ?? 0n);
  const ids = useMemo(() => {
    const out: bigint[] = [];
    for (let i = total; i >= 1 && out.length < 25; i--) out.push(BigInt(i));
    return out;
  }, [total]);

  if (total === 0) {
    return (
      <section className="mb-12">
        <p className={labelStyle}>PROPOSALS</p>
        <p className="mt-3 text-[#94A3B8]">No proposals submitted.</p>
      </section>
    );
  }

  return (
    <section className="mb-12">
      <p className={labelStyle}>PROPOSALS</p>
      <div className="mt-3 space-y-3">
        {ids.map((id) => (
          <ProposalRow key={id.toString()} id={id} />
        ))}
      </div>
    </section>
  );
}

function ProposalRow({ id }: { id: bigint }) {
  const { address: account } = useAccount();
  const { writeContract, isPending } = useWriteContract();

  const reads = useReadContracts({
    contracts: [
      {
        address: MULTISIG_ADDRESS,
        abi: multisigAbi,
        functionName: "getProposal",
        args: [id],
      },
      {
        address: MULTISIG_ADDRESS,
        abi: multisigAbi,
        functionName: "canExecute",
        args: [id],
      },
      {
        address: MULTISIG_ADDRESS,
        abi: multisigAbi,
        functionName: "hasSigned",
        args: [id, (account ?? "0x0000000000000000000000000000000000000000") as Address],
      },
      {
        address: MULTISIG_ADDRESS,
        abi: multisigAbi,
        functionName: "isSigner",
        args: [(account ?? "0x0000000000000000000000000000000000000000") as Address],
      },
    ],
  });

  if (!reads.data) return null;
  const [pRes, execRes, signedRes, isSignerRes] = reads.data;
  if (pRes.status !== "success") return null;
  const [target, value, data, deadline, signatureCount, executed] =
    pRes.result as readonly [Address, bigint, Hex, bigint, number, boolean];

  const canExecute = execRes.status === "success" && (execRes.result as boolean);
  const hasSigned  = signedRes.status === "success" && (signedRes.result as boolean);
  const isSigner   = isSignerRes.status === "success" && (isSignerRes.result as boolean);
  const expired    = BigInt(Math.floor(Date.now() / 1000)) > deadline;

  const status = executed
    ? "EXECUTED"
    : expired
    ? "EXPIRED"
    : canExecute
    ? "READY"
    : "PENDING";

  return (
    <div className="border border-[#1F2A40] p-4 hover:border-[#D4AF37]/30 transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <p className={`${gold} text-xs tracking-widest`}>
            #{id.toString()} · {status}
          </p>
          <p className="mt-1 font-mono text-sm break-all">{target}</p>
          <p className="mt-1 font-mono text-xs text-[#94A3B8] break-all">
            {data.slice(0, 66)}…
          </p>
          <p className="mt-2 text-xs text-[#94A3B8]">
            Signatures {signatureCount} · Deadline{" "}
            {new Date(Number(deadline) * 1000).toISOString().slice(0, 16)}Z
          </p>
        </div>
        <div className="flex flex-col gap-2 shrink-0">
          {!executed && !expired && isSigner && !hasSigned && (
            <button
              disabled={isPending}
              onClick={() =>
                writeContract({
                  address: MULTISIG_ADDRESS!,
                  abi: multisigAbi,
                  functionName: "sign",
                  args: [id],
                })
              }
              className={ghostButton}
            >
              SIGN
            </button>
          )}
          {canExecute && (
            <button
              disabled={isPending}
              onClick={() =>
                writeContract({
                  address: MULTISIG_ADDRESS!,
                  abi: multisigAbi,
                  functionName: "execute",
                  args: [id],
                })
              }
              className={primaryButton}
            >
              EXECUTE
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------------
// Propose
// -----------------------------------------------------------------------

type Template =
  | "RAW"
  | "GATE_SET_NOMINATION_PRICE"
  | "GATE_SET_TREASURY"
  | "DAIO_SET_MINTER";

function Propose() {
  const { writeContract, isPending } = useWriteContract();
  const [tpl, setTpl] = useState<Template>("GATE_SET_NOMINATION_PRICE");
  const [target, setTarget] = useState<string>(GATE_ADDRESS ?? "");
  const [rawData, setRawData] = useState<string>("0x");
  const [arg1, setArg1] = useState<string>("");
  const [hours, setHours] = useState<string>("72");

  const NOMINATION_KIND =
    "0x0756de917fa4ae2eac6429f8eb629ae6570a902dbbfb107afac9c00e8a8750ad";

  const built = useMemo(() => {
    try {
      if (tpl === "GATE_SET_NOMINATION_PRICE") {
        if (!GATE_ADDRESS) return null;
        const priceWei = BigInt(arg1 || "0");
        const data = encodeFunctionData({
          abi: gateAbi,
          functionName: "setPrice",
          args: [NOMINATION_KIND as Hex, priceWei],
        });
        return { target: GATE_ADDRESS, data };
      }
      if (tpl === "GATE_SET_TREASURY") {
        if (!GATE_ADDRESS) return null;
        if (!isAddress(arg1)) return null;
        const data = encodeFunctionData({
          abi: gateAbi,
          functionName: "setTreasury",
          args: [arg1 as Address],
        });
        return { target: GATE_ADDRESS, data };
      }
      if (tpl === "DAIO_SET_MINTER") {
        if (!DAIO_ADDRESS) return null;
        if (!isAddress(arg1)) return null;
        const data = encodeFunctionData({
          abi: daioAbi,
          functionName: "setMinter",
          args: [arg1 as Address],
        });
        return { target: DAIO_ADDRESS, data };
      }
      if (tpl === "RAW") {
        if (!isAddress(target)) return null;
        if (!rawData.startsWith("0x")) return null;
        return { target: target as Address, data: rawData as Hex };
      }
    } catch {
      return null;
    }
    return null;
  }, [tpl, arg1, rawData, target]);

  const submit = () => {
    if (!built) return;
    const deadline = BigInt(Math.floor(Date.now() / 1000) + Number(hours) * 3600);
    writeContract({
      address: MULTISIG_ADDRESS!,
      abi: multisigAbi,
      functionName: "propose",
      args: [built.target, built.data, 0n, deadline],
    });
  };

  return (
    <section className="border-t border-[#1F2A40] pt-8">
      <p className={labelStyle}>NEW PROPOSAL</p>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <label className="block">
          <span className={`${gold} text-xs tracking-widest`}>TEMPLATE</span>
          <select
            value={tpl}
            onChange={(e) => setTpl(e.target.value as Template)}
            className="mt-1 w-full bg-transparent border border-[#1F2A40] p-2 text-sm"
          >
            <option value="GATE_SET_NOMINATION_PRICE">
              Gate — set nomination price (DAIO wei)
            </option>
            <option value="GATE_SET_TREASURY">Gate — set treasury address</option>
            <option value="DAIO_SET_MINTER">DAIO — set minter</option>
            <option value="RAW">Raw target + calldata</option>
          </select>
        </label>

        {tpl !== "RAW" ? (
          <label className="block">
            <span className={`${gold} text-xs tracking-widest`}>
              {tpl === "GATE_SET_NOMINATION_PRICE"
                ? "PRICE (DAIO WEI)"
                : "ADDRESS"}
            </span>
            <input
              type="text"
              value={arg1}
              onChange={(e) => setArg1(e.target.value)}
              className="mt-1 w-full bg-transparent border border-[#1F2A40] p-2 font-mono text-sm"
              placeholder={
                tpl === "GATE_SET_NOMINATION_PRICE"
                  ? "500000000000000000"
                  : "0x..."
              }
            />
          </label>
        ) : (
          <>
            <label className="block">
              <span className={`${gold} text-xs tracking-widest`}>TARGET</span>
              <input
                type="text"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="mt-1 w-full bg-transparent border border-[#1F2A40] p-2 font-mono text-sm"
                placeholder="0x..."
              />
            </label>
            <label className="block md:col-span-2">
              <span className={`${gold} text-xs tracking-widest`}>CALLDATA</span>
              <textarea
                value={rawData}
                onChange={(e) => setRawData(e.target.value)}
                className="mt-1 w-full bg-transparent border border-[#1F2A40] p-2 font-mono text-xs h-24"
                placeholder="0x..."
              />
            </label>
          </>
        )}

        <label className="block">
          <span className={`${gold} text-xs tracking-widest`}>
            DEADLINE (HOURS FROM NOW)
          </span>
          <input
            type="number"
            value={hours}
            onChange={(e) => setHours(e.target.value)}
            className="mt-1 w-full bg-transparent border border-[#1F2A40] p-2 text-sm"
          />
        </label>
      </div>

      <div className="mt-6">
        <button
          disabled={!built || isPending}
          onClick={submit}
          className={`${primaryButton} disabled:opacity-40 disabled:cursor-not-allowed`}
        >
          {isPending ? "SUBMITTING…" : "SUBMIT PROPOSAL"}
        </button>
        {!built && (
          <p className="mt-2 text-xs text-[#94A3B8]">
            Fill in all fields to enable submission.
          </p>
        )}
      </div>
    </section>
  );
}
