// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

/// @title  IX402SatpayBridge
/// @notice Cross-chain consumption surface for x402 payments settled on
///         Algorand and bridged through the BANKON SATPAY layer. The
///         openBDK relayer-and-validator quorum (1 + 3, 2-of-3) writes
///         payment receipts; consumers redeem them one-shot to gate an
///         on-chain action.

interface IX402SatpayBridge {
    /// @notice Emitted when a relayer posts a settled Algorand payment.
    event PaymentRecorded(
        bytes32 indexed algoTxid,
        address indexed payer,
        uint256 amountSatpay,
        uint64  algoRound
    );

    /// @notice Emitted when a consumer redeems a payment to gate an action.
    event PaymentConsumed(
        bytes32 indexed algoTxid,
        address indexed consumer,
        uint256 amountSatpay
    );

    /// @notice Returns the recorded payment amount in SATPAY for `algoTxid`.
    ///         Zero if the receipt is unknown or already consumed.
    function paymentOf(bytes32 algoTxid) external view returns (uint256);

    /// @notice One-shot consumption of a recorded payment. Reverts unless
    ///         `msg.sender` is an authorised consumer and the recorded
    ///         amount is at least `minAmount`. The payer of record must
    ///         match `expectedPayer` to bind the receipt to its originator.
    function consumePayment(
        bytes32 algoTxid,
        uint256 minAmount,
        address expectedPayer
    ) external returns (uint256 amountConsumed);
}
