// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

/// @title  IBonafide
/// @notice Minimal surface of the BONAFIDE constitutional substrate consumed
///         by the DAIO nominee registry. The full nine-contract suite
///         (Genius, BonaToken, Tabularium, Fides, SponsioPactum, Censura,
///         Senatus, Tessera, Curia) lives in the bonafide repository; only
///         the read paths required for nomination accounting are reproduced
///         here as external interfaces.

interface IGenius {
    /// @notice Returns the canonical identity address bound to `subject`.
    ///         For DAIO purposes `subject` is the wallet that signs and
    ///         the returned address is the durable identity anchor.
    function identityOf(address subject) external view returns (address);

    /// @notice True once `subject` has completed Genius onboarding.
    function isEnrolled(address subject) external view returns (bool);
}

interface IFides {
    /// @notice Reputation score for `identity`, scaled 1e18. Used by the
    ///         variable payment gate to discount established participants.
    function scoreOf(address identity) external view returns (uint256);
}

interface ITessera {
    /// @notice Verifies that `claim` has been issued to `identity` by an
    ///         attestor recognised under the BONAFIDE schema registry.
    function hasClaim(address identity, bytes32 claim)
        external
        view
        returns (bool);
}
