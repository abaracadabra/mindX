// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {IX402SatpayBridge} from "./interfaces/IX402SatpayBridge.sol";

/// @title  X402SatpayBridge
/// @notice Reference EVM-side surface for the BANKON SATPAY bridge. In
///         production the `record` path is driven by the openBDK
///         1-relayer/3-validator quorum (2-of-3 attestations); this
///         contract enforces only the local invariants of receipt
///         storage and one-shot consumption so that the upstream
///         attestation rules can be layered on without changing the
///         consumer-facing interface.
contract X402SatpayBridge is IX402SatpayBridge {
    // ---------------------------------------------------------------------
    // Types
    // ---------------------------------------------------------------------

    struct Receipt {
        address payer;
        uint256 amountSatpay;
        uint64  algoRound;
        bool    consumed;
    }

    // ---------------------------------------------------------------------
    // Roles
    // ---------------------------------------------------------------------

    /// @notice Address authorised to record Algorand-side payment receipts.
    ///         In production this is the openBDK relayer multisig.
    address public relayer;

    /// @notice Address authorised to redeem receipts to gate actions.
    ///         Typically the VariablePaymentGate contract.
    address public consumer;

    /// @notice Admin role for rotating relayer/consumer. The DAIO points
    ///         this at the BONAFIDE Curia governance executor.
    address public admin;

    // ---------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------

    mapping(bytes32 => Receipt) public receipts;

    // ---------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------

    error NotRelayer();
    error NotConsumer();
    error NotAdmin();
    error AlreadyRecorded();
    error UnknownReceipt();
    error AlreadyConsumed();
    error PayerMismatch();
    error UnderQuoted(uint256 required, uint256 available);

    // ---------------------------------------------------------------------
    // Modifiers
    // ---------------------------------------------------------------------

    modifier onlyRelayer()  { if (msg.sender != relayer)  revert NotRelayer();  _; }
    modifier onlyConsumer() { if (msg.sender != consumer) revert NotConsumer(); _; }
    modifier onlyAdmin()    { if (msg.sender != admin)    revert NotAdmin();    _; }

    // ---------------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------------

    constructor(address relayer_, address admin_) {
        require(relayer_ != address(0), "relayer=0");
        require(admin_   != address(0), "admin=0");
        relayer = relayer_;
        admin   = admin_;
    }

    // ---------------------------------------------------------------------
    // Admin
    // ---------------------------------------------------------------------

    function setConsumer(address consumer_) external onlyAdmin {
        require(consumer_ != address(0), "consumer=0");
        consumer = consumer_;
    }

    function rotateRelayer(address relayer_) external onlyAdmin {
        require(relayer_ != address(0), "relayer=0");
        relayer = relayer_;
    }

    function rotateAdmin(address admin_) external onlyAdmin {
        require(admin_ != address(0), "admin=0");
        admin = admin_;
    }

    // ---------------------------------------------------------------------
    // Relayer: record a settled Algorand payment
    // ---------------------------------------------------------------------

    function recordPayment(
        bytes32 algoTxid,
        address payer,
        uint256 amountSatpay,
        uint64  algoRound
    ) external onlyRelayer {
        require(payer != address(0), "payer=0");
        require(amountSatpay > 0, "amount=0");

        Receipt storage r = receipts[algoTxid];
        if (r.amountSatpay != 0) revert AlreadyRecorded();

        r.payer        = payer;
        r.amountSatpay = amountSatpay;
        r.algoRound    = algoRound;
        emit PaymentRecorded(algoTxid, payer, amountSatpay, algoRound);
    }

    // ---------------------------------------------------------------------
    // Consumer: one-shot redemption
    // ---------------------------------------------------------------------

    function paymentOf(bytes32 algoTxid) external view returns (uint256) {
        Receipt storage r = receipts[algoTxid];
        return r.consumed ? 0 : r.amountSatpay;
    }

    function consumePayment(
        bytes32 algoTxid,
        uint256 minAmount,
        address expectedPayer
    ) external onlyConsumer returns (uint256) {
        Receipt storage r = receipts[algoTxid];
        if (r.amountSatpay == 0) revert UnknownReceipt();
        if (r.consumed)           revert AlreadyConsumed();
        if (r.payer != expectedPayer) revert PayerMismatch();
        if (r.amountSatpay < minAmount) revert UnderQuoted(minAmount, r.amountSatpay);

        r.consumed = true;
        emit PaymentConsumed(algoTxid, msg.sender, r.amountSatpay);
        return r.amountSatpay;
    }
}
