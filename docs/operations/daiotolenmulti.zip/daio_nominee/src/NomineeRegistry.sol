// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {IGenius} from "./interfaces/IBonafide.sol";
import {VariablePaymentGate} from "./VariablePaymentGate.sol";

/// @title  NomineeRegistry
/// @notice DAIO nominee dossier substrate. Each nominee is a Genius
///         identity addressable by an ENS subname under `bankon.eth`
///         (e.g. `codephreak.bankon.eth`). Nominations are counted per
///         identity, deduplicated per nominator, and gated by the
///         VariablePaymentGate which pulls the DAIO fee directly from
///         the nominator's balance.
///
///         The nominator must approve the gate to spend DAIO before
///         calling `nominate`, either through a prior `approve` call
///         or by submitting an ERC-2612 permit signature in the same
///         transaction via the helper `nominateWithPermit`.
contract NomineeRegistry {
    // ---------------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------------

    bytes32 public constant ACTION_KIND = keccak256("NOMINATION");

    // ---------------------------------------------------------------------
    // Types
    // ---------------------------------------------------------------------

    struct Nominee {
        address identity;
        bytes32 ensNode;
        uint64  registeredAt;
        uint64  nominationCount;
        bool    active;
    }

    // ---------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------

    IGenius             public immutable genius;
    VariablePaymentGate public immutable gate;
    bytes32             public immutable bankonRootNode;

    mapping(address => Nominee)                    public nominees;
    mapping(bytes32 => address)                    public nodeToIdentity;
    mapping(address => mapping(address => bool))   public hasNominated;

    // ---------------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------------

    event NomineeRegistered (address indexed identity, bytes32 indexed ensNode);
    event NomineeDeactivated(address indexed identity);
    event Nominated(
        address indexed nominator,
        address indexed nominee,
        uint256 priceDaio,
        uint64  newCount
    );

    // ---------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------

    error NotEnrolled();
    error AlreadyRegistered();
    error UnknownNominee();
    error DuplicateNomination();
    error SelfNomination();
    error NomineeInactive();

    // ---------------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------------

    constructor(IGenius genius_, VariablePaymentGate gate_, bytes32 bankonRootNode_) {
        require(address(genius_) != address(0), "genius=0");
        require(address(gate_)   != address(0), "gate=0");
        require(bankonRootNode_  != bytes32(0), "root=0");
        genius          = genius_;
        gate            = gate_;
        bankonRootNode  = bankonRootNode_;
    }

    // ---------------------------------------------------------------------
    // Registration
    // ---------------------------------------------------------------------

    function registerNominee(bytes32 ensNode) external {
        if (!genius.isEnrolled(msg.sender)) revert NotEnrolled();
        address identity = genius.identityOf(msg.sender);

        Nominee storage n = nominees[identity];
        if (n.identity != address(0)) revert AlreadyRegistered();

        n.identity        = identity;
        n.ensNode         = ensNode;
        n.registeredAt    = uint64(block.timestamp);
        n.nominationCount = 0;
        n.active          = true;

        nodeToIdentity[ensNode] = identity;
        emit NomineeRegistered(identity, ensNode);
    }

    function deactivate() external {
        address identity = genius.identityOf(msg.sender);
        Nominee storage n = nominees[identity];
        if (n.identity == address(0)) revert UnknownNominee();
        n.active = false;
        emit NomineeDeactivated(identity);
    }

    // ---------------------------------------------------------------------
    // Nomination
    // ---------------------------------------------------------------------

    /// @notice Casts a nomination for `nominee`. The nominator must have
    ///         pre-approved the gate to spend the DAIO price; an
    ///         alternative permit-bundled entry point is exposed below.
    function nominate(address nominee) external {
        _nominate(nominee);
    }

    /// @notice Internal nomination path so derived contracts and the
    ///         permit wrapper can share logic.
    function _nominate(address nominee) internal {
        if (!genius.isEnrolled(msg.sender)) revert NotEnrolled();
        address nominator = genius.identityOf(msg.sender);

        if (nominator == nominee) revert SelfNomination();

        Nominee storage n = nominees[nominee];
        if (n.identity == address(0)) revert UnknownNominee();
        if (!n.active) revert NomineeInactive();
        if (hasNominated[nominator][nominee]) revert DuplicateNomination();

        uint256 paid = gate.settle(nominator, ACTION_KIND);

        hasNominated[nominator][nominee] = true;
        n.nominationCount += 1;
        emit Nominated(nominator, nominee, paid, n.nominationCount);
    }

    // ---------------------------------------------------------------------
    // Views
    // ---------------------------------------------------------------------

    function nominationCount(address nominee) external view returns (uint64) {
        return nominees[nominee].nominationCount;
    }

    function isNominee(address identity) external view returns (bool) {
        return nominees[identity].identity != address(0) && nominees[identity].active;
    }
}
