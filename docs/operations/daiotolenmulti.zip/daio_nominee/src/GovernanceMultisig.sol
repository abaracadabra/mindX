// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

/// @title  GovernanceMultisig
/// @notice On-chain multisig controller for the DAIO operational layer.
///         Consolidates the admin roles of DAIOToken, VariablePaymentGate,
///         RewardDistributor, IdentifierAttestor, and X402SatpayBridge
///         under a single N-of-M signer set with on-chain signature
///         collection.
///
///         Every privileged action is a proposal: target address, calldata,
///         value, deadline. Signers call `sign(id)` to register approval.
///         Once the signature count reaches `threshold`, any address can
///         call `execute(id)`, which low-level-calls the target with the
///         encoded calldata. The multisig administers itself through the
///         same flow: adding signers, removing signers, and rotating the
///         threshold are functions guarded by `msg.sender == address(this)`.
contract GovernanceMultisig {
    // ---------------------------------------------------------------------
    // Types
    // ---------------------------------------------------------------------

    struct Proposal {
        address target;
        uint256 value;
        bytes   data;
        uint64  deadline;
        uint32  signatureCount;
        bool    executed;
    }

    // ---------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------

    address[] internal _signers;
    mapping(address => bool) public isSigner;
    uint256 public threshold;

    uint256 public proposalCount;
    mapping(uint256 => Proposal) internal _proposals;
    mapping(uint256 => mapping(address => bool)) public hasSigned;

    // ---------------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------------

    event SignerAdded     (address indexed signer);
    event SignerRemoved   (address indexed signer);
    event ThresholdChanged(uint256 newThreshold);
    event ProposalCreated (uint256 indexed id, address indexed proposer, address indexed target, uint256 value, uint64 deadline);
    event ProposalSigned  (uint256 indexed id, address indexed signer, uint32 newCount);
    event ProposalExecuted(uint256 indexed id, bool success, bytes returnData);

    // ---------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------

    error NotSigner();
    error NotSelf();
    error AlreadySigner();
    error UnknownSigner();
    error InvalidThreshold(uint256 threshold, uint256 signerCount);
    error UnknownProposal();
    error AlreadyExecuted();
    error AlreadySigned();
    error DeadlinePassed();
    error BelowThreshold(uint32 have, uint256 need);
    error ExecutionFailed(bytes returnData);

    // ---------------------------------------------------------------------
    // Modifiers
    // ---------------------------------------------------------------------

    modifier onlySigner() {
        if (!isSigner[msg.sender]) revert NotSigner();
        _;
    }

    modifier onlySelf() {
        if (msg.sender != address(this)) revert NotSelf();
        _;
    }

    // ---------------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------------

    constructor(address[] memory initialSigners, uint256 initialThreshold) {
        require(initialSigners.length > 0, "no signers");
        require(initialThreshold > 0,      "threshold=0");
        require(initialThreshold <= initialSigners.length, "threshold>signers");

        for (uint256 i = 0; i < initialSigners.length; i++) {
            address s = initialSigners[i];
            require(s != address(0),  "signer=0");
            require(!isSigner[s],     "duplicate signer");
            isSigner[s] = true;
            _signers.push(s);
            emit SignerAdded(s);
        }
        threshold = initialThreshold;
        emit ThresholdChanged(initialThreshold);
    }

    // ---------------------------------------------------------------------
    // Proposals
    // ---------------------------------------------------------------------

    function propose(address target, bytes calldata data, uint256 value, uint64 deadline)
        external
        onlySigner
        returns (uint256 id)
    {
        require(target  != address(0),            "target=0");
        require(deadline > block.timestamp,       "deadline<=now");

        id = ++proposalCount;
        Proposal storage p = _proposals[id];
        p.target   = target;
        p.value    = value;
        p.data     = data;
        p.deadline = deadline;

        emit ProposalCreated(id, msg.sender, target, value, deadline);

        // The proposer counts as the first signer.
        _sign(id);
    }

    function sign(uint256 id) external onlySigner {
        _sign(id);
    }

    function execute(uint256 id) external returns (bytes memory returnData) {
        Proposal storage p = _proposals[id];
        if (p.target == address(0)) revert UnknownProposal();
        if (p.executed)             revert AlreadyExecuted();
        if (block.timestamp > p.deadline) revert DeadlinePassed();
        if (p.signatureCount < threshold) {
            revert BelowThreshold(p.signatureCount, threshold);
        }

        p.executed = true;
        bool ok;
        (ok, returnData) = p.target.call{value: p.value}(p.data);
        emit ProposalExecuted(id, ok, returnData);
        if (!ok) revert ExecutionFailed(returnData);
    }

    function _sign(uint256 id) internal {
        Proposal storage p = _proposals[id];
        if (p.target == address(0)) revert UnknownProposal();
        if (p.executed)             revert AlreadyExecuted();
        if (block.timestamp > p.deadline) revert DeadlinePassed();
        if (hasSigned[id][msg.sender]) revert AlreadySigned();

        hasSigned[id][msg.sender] = true;
        p.signatureCount += 1;
        emit ProposalSigned(id, msg.sender, p.signatureCount);
    }

    // ---------------------------------------------------------------------
    // Self-administration (callable only through executed proposals)
    // ---------------------------------------------------------------------

    function addSigner(address signer) external onlySelf {
        require(signer != address(0), "signer=0");
        if (isSigner[signer]) revert AlreadySigner();
        isSigner[signer] = true;
        _signers.push(signer);
        emit SignerAdded(signer);
    }

    function removeSigner(address signer) external onlySelf {
        if (!isSigner[signer]) revert UnknownSigner();
        isSigner[signer] = false;

        uint256 n = _signers.length;
        for (uint256 i = 0; i < n; i++) {
            if (_signers[i] == signer) {
                _signers[i] = _signers[n - 1];
                _signers.pop();
                break;
            }
        }
        if (threshold > _signers.length) {
            revert InvalidThreshold(threshold, _signers.length);
        }
        emit SignerRemoved(signer);
    }

    function setThreshold(uint256 newThreshold) external onlySelf {
        if (newThreshold == 0 || newThreshold > _signers.length) {
            revert InvalidThreshold(newThreshold, _signers.length);
        }
        threshold = newThreshold;
        emit ThresholdChanged(newThreshold);
    }

    // ---------------------------------------------------------------------
    // Views
    // ---------------------------------------------------------------------

    function signers() external view returns (address[] memory) {
        return _signers;
    }

    function signerCount() external view returns (uint256) {
        return _signers.length;
    }

    function getProposal(uint256 id)
        external
        view
        returns (
            address target,
            uint256 value,
            bytes memory data,
            uint64 deadline,
            uint32 signatureCount,
            bool executed
        )
    {
        Proposal storage p = _proposals[id];
        return (p.target, p.value, p.data, p.deadline, p.signatureCount, p.executed);
    }

    function canExecute(uint256 id) external view returns (bool) {
        Proposal storage p = _proposals[id];
        return p.target != address(0)
            && !p.executed
            && block.timestamp <= p.deadline
            && p.signatureCount >= threshold;
    }

    // ---------------------------------------------------------------------
    // Receive ether for proposal execution that requires value transfer
    // ---------------------------------------------------------------------

    receive() external payable {}
}
