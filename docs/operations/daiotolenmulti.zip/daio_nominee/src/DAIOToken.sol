// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {ERC20}        from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Permit}  from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";

/// @title  DAIOToken
/// @notice Governance and engagement token for the DAIO. Functions as
///         the unit of account for voting (fee paid on each action),
///         as the reward currency (minted to authenticated participants
///         by the RewardDistributor), and as the privilege credential
///         (held balances gate access to higher-tier action kinds).
///
///         The token is ERC-20 with EIP-2612 permit, so users can grant
///         spending allowance to the VariablePaymentGate in the same
///         transaction that performs an action. Minting is restricted
///         to a single minter address, which is set by the admin to
///         the RewardDistributor contract after deployment. The admin
///         role itself can be rotated to a governance multisig.
contract DAIOToken is ERC20, ERC20Permit {
    address public minter;
    address public admin;

    event MinterSet(address indexed previous, address indexed next);
    event AdminRotated(address indexed previous, address indexed next);

    error NotMinter();
    error NotAdmin();

    constructor(address admin_)
        ERC20("DAIO", "DAIO")
        ERC20Permit("DAIO")
    {
        require(admin_ != address(0), "admin=0");
        admin = admin_;
        emit AdminRotated(address(0), admin_);
    }

    function mint(address to, uint256 amount) external {
        if (msg.sender != minter) revert NotMinter();
        _mint(to, amount);
    }

    function setMinter(address newMinter) external {
        if (msg.sender != admin) revert NotAdmin();
        require(newMinter != address(0), "minter=0");
        emit MinterSet(minter, newMinter);
        minter = newMinter;
    }

    function rotateAdmin(address newAdmin) external {
        if (msg.sender != admin) revert NotAdmin();
        require(newAdmin != address(0), "admin=0");
        emit AdminRotated(admin, newAdmin);
        admin = newAdmin;
    }
}
