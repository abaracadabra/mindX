// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {IGenius} from "./interfaces/IBonafide.sol";

/// @title  IdentifierAttestor
/// @notice Registry of external identifiers (github, x, website, ...) bound
///         to a Genius identity. Identifiers are declared by the identity
///         itself and marked verified by an attestor role that runs the
///         off-chain checks (e.g. the mindX API confirming a GitHub gist,
///         a DNS TXT record on the website, or an X bio reference).
///
///         The contract stores only the minimum needed to render a dossier
///         page deterministically: identifier kind, value, and verification
///         flag. Full evidence (signature, attestor address, timestamp) is
///         held off-chain and referenced by the attestation hash.
contract IdentifierAttestor {
    // ---------------------------------------------------------------------
    // Types
    // ---------------------------------------------------------------------

    struct Identifier {
        bytes32 kind;        // keccak256("github") | keccak256("x") | ...
        string  value;       // raw handle or URL
        bool    verified;    // set by attestor on successful off-chain proof
        bytes32 evidence;    // keccak hash of off-chain attestation payload
        uint64  updatedAt;
    }

    // ---------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------

    IGenius public immutable genius;

    /// @notice Operational attestor authorised to flip the verified bit
    ///         on identifier records. In production this is the mindX
    ///         API signing key, which performs high-frequency operations.
    address public attestor;

    /// @notice Governance role authorised to rotate the attestor key.
    ///         In production this is the GovernanceMultisig address.
    ///         Separating this from the attestor itself prevents the
    ///         operational key from rotating its own privilege.
    address public admin;

    /// @notice identifiers[identity][kind] — one record per (identity, kind).
    mapping(address => mapping(bytes32 => Identifier)) public identifiers;

    /// @notice kindsOf[identity] — enumerable list of kinds declared by
    ///         an identity, so the dossier UI can render them in order.
    mapping(address => bytes32[]) public kindsOf;

    // ---------------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------------

    event IdentifierDeclared(address indexed identity, bytes32 indexed kind, string value);
    event IdentifierVerified(address indexed identity, bytes32 indexed kind, bytes32 evidence);
    event IdentifierRevoked (address indexed identity, bytes32 indexed kind);
    event AttestorRotated   (address indexed previousAttestor, address indexed newAttestor);
    event AdminRotated      (address indexed previousAdmin, address indexed newAdmin);

    // ---------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------

    error NotIdentity();
    error NotAttestor();
    error NotAdmin();
    error NotEnrolled();
    error UnknownKind();

    // ---------------------------------------------------------------------
    // Modifiers
    // ---------------------------------------------------------------------

    modifier onlyAttestor() {
        if (msg.sender != attestor) revert NotAttestor();
        _;
    }

    modifier onlyAdmin() {
        if (msg.sender != admin) revert NotAdmin();
        _;
    }

    // ---------------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------------

    constructor(IGenius genius_, address attestor_, address admin_) {
        require(address(genius_) != address(0), "genius=0");
        require(attestor_        != address(0), "attestor=0");
        require(admin_           != address(0), "admin=0");
        genius   = genius_;
        attestor = attestor_;
        admin    = admin_;
        emit AttestorRotated(address(0), attestor_);
        emit AdminRotated   (address(0), admin_);
    }

    // ---------------------------------------------------------------------
    // Declaration (called by the identity itself)
    // ---------------------------------------------------------------------

    /// @notice Declares (or replaces) an identifier value for the caller.
    ///         The caller's Genius identity must be enrolled. Declaring
    ///         clears the verified flag — a fresh attestation is required.
    function declare(bytes32 kind, string calldata value) external {
        if (!genius.isEnrolled(msg.sender)) revert NotEnrolled();
        address identity = genius.identityOf(msg.sender);

        Identifier storage rec = identifiers[identity][kind];
        bool isNew = rec.kind == bytes32(0);

        rec.kind      = kind;
        rec.value     = value;
        rec.verified  = false;
        rec.evidence  = bytes32(0);
        rec.updatedAt = uint64(block.timestamp);

        if (isNew) kindsOf[identity].push(kind);
        emit IdentifierDeclared(identity, kind, value);
    }

    // ---------------------------------------------------------------------
    // Verification (called by the attestor)
    // ---------------------------------------------------------------------

    function verify(address identity, bytes32 kind, bytes32 evidence)
        external
        onlyAttestor
    {
        Identifier storage rec = identifiers[identity][kind];
        if (rec.kind == bytes32(0)) revert UnknownKind();

        rec.verified  = true;
        rec.evidence  = evidence;
        rec.updatedAt = uint64(block.timestamp);
        emit IdentifierVerified(identity, kind, evidence);
    }

    function revoke(address identity, bytes32 kind) external onlyAttestor {
        Identifier storage rec = identifiers[identity][kind];
        if (rec.kind == bytes32(0)) revert UnknownKind();
        rec.verified  = false;
        rec.evidence  = bytes32(0);
        rec.updatedAt = uint64(block.timestamp);
        emit IdentifierRevoked(identity, kind);
    }

    function rotateAttestor(address newAttestor) external onlyAdmin {
        require(newAttestor != address(0), "attestor=0");
        emit AttestorRotated(attestor, newAttestor);
        attestor = newAttestor;
    }

    function rotateAdmin(address newAdmin) external onlyAdmin {
        require(newAdmin != address(0), "admin=0");
        emit AdminRotated(admin, newAdmin);
        admin = newAdmin;
    }

    // ---------------------------------------------------------------------
    // Views
    // ---------------------------------------------------------------------

    function kindCount(address identity) external view returns (uint256) {
        return kindsOf[identity].length;
    }
}
