// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {ECDSA}  from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {DAIOToken} from "./DAIOToken.sol";

/// @title  RewardDistributor
/// @notice Mints DAIO to authenticated participants on the basis of
///         EIP-712 signed claims issued by the mindX attestor key. The
///         mindX backend tracks login state and voting activity off
///         chain; whenever a participant is eligible for a reward, the
///         backend signs a typed claim that the participant can submit
///         to this contract for redemption.
///
///         Replay protection is enforced through per-recipient nonces.
///         Each claim carries an explicit deadline. A per-epoch emission
///         cap bounds total DAIO issued per epoch so that a compromised
///         attestor cannot drain the supply faster than governance can
///         rotate it.
contract RewardDistributor is EIP712 {
    using ECDSA for bytes32;

    // ---------------------------------------------------------------------
    // Typed data
    // ---------------------------------------------------------------------

    bytes32 public constant CLAIM_TYPEHASH = keccak256(
        "RewardClaim(address recipient,uint256 amount,uint256 nonce,uint256 deadline)"
    );

    struct RewardClaim {
        address recipient;
        uint256 amount;
        uint256 nonce;
        uint256 deadline;
    }

    // ---------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------

    DAIOToken public immutable daio;

    /// @notice EIP-712 signer authorised to issue reward claims. In
    ///         production this is a mindX-controlled signing key.
    address public attestor;

    /// @notice Governance role for rotating attestor and limits.
    address public admin;

    /// @notice Length of an emission epoch in seconds.
    uint256 public immutable epochLength;
    uint256 public immutable genesis;

    /// @notice Maximum DAIO mintable per epoch across all recipients.
    uint256 public epochCap;

    /// @notice mintedInEpoch[epoch] — total DAIO minted in that epoch.
    mapping(uint256 => uint256) public mintedInEpoch;

    /// @notice nonces[recipient] — next expected nonce for recipient.
    mapping(address => uint256) public nonces;

    // ---------------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------------

    event Claimed       (address indexed recipient, uint256 amount, uint256 nonce);
    event AttestorRotated(address indexed previous, address indexed next);
    event AdminRotated   (address indexed previous, address indexed next);
    event EpochCapSet    (uint256 cap);

    // ---------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------

    error NotAdmin();
    error BadSigner();
    error ClaimExpired();
    error WrongNonce(uint256 expected, uint256 provided);
    error EpochCapExceeded(uint256 cap, uint256 used, uint256 requested);

    modifier onlyAdmin() {
        if (msg.sender != admin) revert NotAdmin();
        _;
    }

    // ---------------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------------

    constructor(
        DAIOToken daio_,
        address   attestor_,
        address   admin_,
        uint256   epochLength_,
        uint256   epochCap_
    ) EIP712("DAIO RewardDistributor", "1") {
        require(address(daio_) != address(0), "daio=0");
        require(attestor_      != address(0), "attestor=0");
        require(admin_         != address(0), "admin=0");
        require(epochLength_   > 0,           "epoch=0");

        daio        = daio_;
        attestor    = attestor_;
        admin       = admin_;
        epochLength = epochLength_;
        genesis     = block.timestamp;
        epochCap    = epochCap_;

        emit AttestorRotated(address(0), attestor_);
        emit AdminRotated   (address(0), admin_);
        emit EpochCapSet(epochCap_);
    }

    // ---------------------------------------------------------------------
    // Governance
    // ---------------------------------------------------------------------

    function rotateAttestor(address newAttestor) external onlyAdmin {
        require(newAttestor != address(0), "attestor=0");
        emit AttestorRotated(attestor, newAttestor);
        attestor = newAttestor;
    }

    function rotateAdmin(address newAdmin) external onlyAdmin {
        require(newAdmin != address(0), "admin=0");
        emit AdminRotated(admin, newAdmin);
        admin = newAdmin;
    }

    function setEpochCap(uint256 cap) external onlyAdmin {
        epochCap = cap;
        emit EpochCapSet(cap);
    }

    // ---------------------------------------------------------------------
    // Claims
    // ---------------------------------------------------------------------

    function currentEpoch() public view returns (uint256) {
        return (block.timestamp - genesis) / epochLength;
    }

    /// @notice Redeems a signed reward claim. The signature must be
    ///         issued by the attestor over the EIP-712 typed claim. The
    ///         recipient may be msg.sender or any other address — the
    ///         attestor decides who receives the mint.
    function claim(RewardClaim calldata c, bytes calldata signature) external {
        if (block.timestamp > c.deadline) revert ClaimExpired();

        uint256 expectedNonce = nonces[c.recipient];
        if (c.nonce != expectedNonce) revert WrongNonce(expectedNonce, c.nonce);

        bytes32 structHash = keccak256(
            abi.encode(CLAIM_TYPEHASH, c.recipient, c.amount, c.nonce, c.deadline)
        );
        bytes32 digest = _hashTypedDataV4(structHash);
        address signer = digest.recover(signature);
        if (signer != attestor) revert BadSigner();

        uint256 epoch = currentEpoch();
        uint256 used  = mintedInEpoch[epoch];
        if (used + c.amount > epochCap) {
            revert EpochCapExceeded(epochCap, used, c.amount);
        }

        nonces[c.recipient] = expectedNonce + 1;
        mintedInEpoch[epoch] = used + c.amount;

        daio.mint(c.recipient, c.amount);
        emit Claimed(c.recipient, c.amount, c.nonce);
    }
}
