// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/// @title  VariablePaymentGate
/// @notice DAIO-denominated fee schedule and privilege gate. Each action
///         kind carries a DAIO price set by governance, and an optional
///         minimum DAIO holding required to perform the action at all.
///         The gate pulls the fee from the actor's balance through the
///         standard ERC-20 allowance pattern, routing it to the treasury
///         address. The actor must therefore approve the gate beforehand
///         (or use ERC-2612 permit in a wrapper call).
///
///         Privilege control: holding ≥ minHolding[kind] is required to
///         clear the gate for `kind`. The held DAIO is not spent by the
///         privilege check; only the fee amount transfers out. This
///         creates a soft stake-and-act mechanic where larger holdings
///         unlock higher-tier actions without consuming the holding.
///
///         The gate retains the action-kind taxonomy from earlier
///         iterations so that distinct prices and thresholds can be
///         configured for nominations, endorsements, motions, and
///         comments without recompiling the contract.
contract VariablePaymentGate {
    // ---------------------------------------------------------------------
    // Canonical action kinds
    // ---------------------------------------------------------------------

    bytes32 public constant KIND_NOMINATION  = keccak256("NOMINATION");
    bytes32 public constant KIND_ENDORSEMENT = keccak256("ENDORSEMENT");
    bytes32 public constant KIND_MOTION      = keccak256("MOTION");
    bytes32 public constant KIND_COMMENT     = keccak256("COMMENT");

    // ---------------------------------------------------------------------
    // Configuration
    // ---------------------------------------------------------------------

    IERC20  public immutable daio;
    address public treasury;
    address public admin;

    /// @notice DAIO price for each action kind, 18 decimals.
    mapping(bytes32 => uint256) public priceDaio;

    /// @notice Minimum DAIO balance the actor must hold to perform the
    ///         action, 18 decimals. Held balance is not spent.
    mapping(bytes32 => uint256) public minHoldingDaio;

    // ---------------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------------

    event PriceSet      (bytes32 indexed kind, uint256 priceDaio);
    event MinHoldingSet (bytes32 indexed kind, uint256 minHoldingDaio);
    event TreasurySet   (address indexed previous, address indexed next);
    event AdminRotated  (address indexed previous, address indexed next);

    event Quoted (address indexed actor, bytes32 indexed kind, uint256 priceDaio);
    event Settled(address indexed actor, bytes32 indexed kind, uint256 paidDaio);

    // ---------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------

    error NotAdmin();
    error UnpricedAction(bytes32 kind);
    error InsufficientHolding(uint256 required, uint256 actual);
    error TransferFailed();

    modifier onlyAdmin() {
        if (msg.sender != admin) revert NotAdmin();
        _;
    }

    // ---------------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------------

    constructor(IERC20 daio_, address treasury_, address admin_) {
        require(address(daio_) != address(0), "daio=0");
        require(treasury_      != address(0), "treasury=0");
        require(admin_         != address(0), "admin=0");
        daio     = daio_;
        treasury = treasury_;
        admin    = admin_;
        emit TreasurySet(address(0), treasury_);
        emit AdminRotated(address(0), admin_);
    }

    // ---------------------------------------------------------------------
    // Governance
    // ---------------------------------------------------------------------

    function setPrice(bytes32 kind, uint256 priceDaio_) external onlyAdmin {
        priceDaio[kind] = priceDaio_;
        emit PriceSet(kind, priceDaio_);
    }

    function setMinHolding(bytes32 kind, uint256 minHolding_) external onlyAdmin {
        minHoldingDaio[kind] = minHolding_;
        emit MinHoldingSet(kind, minHolding_);
    }

    function setTreasury(address newTreasury) external onlyAdmin {
        require(newTreasury != address(0), "treasury=0");
        emit TreasurySet(treasury, newTreasury);
        treasury = newTreasury;
    }

    function rotateAdmin(address newAdmin) external onlyAdmin {
        require(newAdmin != address(0), "admin=0");
        emit AdminRotated(admin, newAdmin);
        admin = newAdmin;
    }

    // ---------------------------------------------------------------------
    // Quoting
    // ---------------------------------------------------------------------

    /// @notice Returns the DAIO price for `actor` to perform `kind`.
    ///         Reverts if `kind` is unpriced; this is deliberate so that
    ///         action kinds cannot be settled by accident.
    function quote(address /*actor*/, bytes32 kind) public view returns (uint256) {
        uint256 p = priceDaio[kind];
        if (p == 0) revert UnpricedAction(kind);
        return p;
    }

    /// @notice True if `actor` clears both the privilege threshold and
    ///         has sufficient balance to pay the fee. The UI uses this
    ///         to render the action button as enabled or disabled.
    function canPerform(address actor, bytes32 kind) external view returns (bool) {
        if (priceDaio[kind] == 0) return false;
        uint256 needed = minHoldingDaio[kind];
        if (priceDaio[kind] > needed) needed = priceDaio[kind];
        return daio.balanceOf(actor) >= needed;
    }

    // ---------------------------------------------------------------------
    // Settlement
    // ---------------------------------------------------------------------

    /// @notice Charges `actor` the price for `kind` and routes the
    ///         payment to the treasury. Reverts if the actor's balance
    ///         falls below the privilege threshold or if the ERC-20
    ///         allowance is insufficient. Returns the DAIO amount paid.
    function settle(address actor, bytes32 kind) external returns (uint256) {
        uint256 price = quote(actor, kind);
        emit Quoted(actor, kind, price);

        uint256 holding = daio.balanceOf(actor);
        uint256 threshold = minHoldingDaio[kind];
        if (holding < threshold) revert InsufficientHolding(threshold, holding);

        bool ok = daio.transferFrom(actor, treasury, price);
        if (!ok) revert TransferFailed();

        emit Settled(actor, kind, price);
        return price;
    }
}
