// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import "forge-std/Script.sol";
import {IGenius}             from "../src/interfaces/IBonafide.sol";
import {DAIOToken}           from "../src/DAIOToken.sol";
import {VariablePaymentGate} from "../src/VariablePaymentGate.sol";
import {RewardDistributor}   from "../src/RewardDistributor.sol";
import {IdentifierAttestor}  from "../src/IdentifierAttestor.sol";
import {NomineeRegistry}     from "../src/NomineeRegistry.sol";
import {GovernanceMultisig}  from "../src/GovernanceMultisig.sol";

/// @notice Mainnet deployment script. Performs the full DAIO bring-up
///         in a single broadcast: deploys the multisig with the initial
///         signer set, deploys the operational contracts with the
///         deployer as a temporary admin, performs all configuration
///         calls that require admin privilege, then rotates every
///         admin role to the multisig address before exiting.
///
///         After this script runs, the deployer key has no remaining
///         privilege over any contract in the system. All further
///         changes must be proposed and approved through the multisig.
///
///             forge script script/Deploy.s.sol:Deploy \
///                 --rpc-url $ETH_MAINNET_RPC \
///                 --private-key $DEPLOY_PK \
///                 --broadcast --verify
contract Deploy is Script {
    function run() external {
        // -------- environment --------
        address genius       = vm.envAddress("BONAFIDE_GENIUS");
        address treasury     = vm.envAddress("TREASURY");
        address attestorKey  = vm.envAddress("ATTESTOR");
        address mindxSigner  = vm.envAddress("MINDX_SIGNER");
        bytes32 root         = vm.envBytes32("BANKON_ROOT_NODE");

        // Initial multisig signer set, comma-separated in MULTISIG_SIGNERS.
        // Threshold from MULTISIG_THRESHOLD.
        address[] memory initialSigners = _envAddressArray("MULTISIG_SIGNERS");
        uint256 multisigThreshold       = vm.envUint("MULTISIG_THRESHOLD");

        // Schedule
        uint256 nominationPrice = vm.envOr("NOMINATION_PRICE", uint256(0.5 ether));
        uint256 rewardEpoch     = vm.envOr("REWARD_EPOCH",     uint256(1 days));
        uint256 rewardEpochCap  = vm.envOr("REWARD_EPOCH_CAP", uint256(10_000 ether));

        vm.startBroadcast();

        // -------- deploy multisig --------
        GovernanceMultisig multisig = new GovernanceMultisig(
            initialSigners,
            multisigThreshold
        );

        // -------- deploy operational contracts with deployer as admin --------
        // The deployer must therefore equal msg.sender during broadcast;
        // Forge supplies that from --private-key.
        address deployer = msg.sender;

        DAIOToken daio = new DAIOToken(deployer);

        VariablePaymentGate gate = new VariablePaymentGate(
            daio,
            treasury,
            deployer
        );

        RewardDistributor dist = new RewardDistributor(
            daio,
            mindxSigner,
            deployer,
            rewardEpoch,
            rewardEpochCap
        );

        IdentifierAttestor attestor = new IdentifierAttestor(
            IGenius(genius),
            attestorKey,
            deployer
        );

        NomineeRegistry registry = new NomineeRegistry(
            IGenius(genius),
            gate,
            root
        );

        // -------- initial configuration --------
        gate.setPrice(gate.KIND_NOMINATION(), nominationPrice);
        daio.setMinter(address(dist));

        // -------- hand over to multisig --------
        daio.rotateAdmin    (address(multisig));
        gate.rotateAdmin    (address(multisig));
        dist.rotateAdmin    (address(multisig));
        attestor.rotateAdmin(address(multisig));

        vm.stopBroadcast();

        // -------- emit final state --------
        console2.log("GovernanceMultisig  :", address(multisig));
        console2.log("DAIOToken           :", address(daio));
        console2.log("VariablePaymentGate :", address(gate));
        console2.log("RewardDistributor   :", address(dist));
        console2.log("IdentifierAttestor  :", address(attestor));
        console2.log("NomineeRegistry     :", address(registry));
        console2.log("NOMINATION price    :", nominationPrice);
        console2.log("Multisig threshold  :", multisigThreshold);
        console2.log("Signer count        :", initialSigners.length);
    }

    /// @notice Reads a comma-separated list of addresses from the
    ///         environment. Forge's vm.envString returns the raw value,
    ///         which we then parse through a delimiter helper.
    function _envAddressArray(string memory key)
        internal
        view
        returns (address[] memory)
    {
        // vm.envAddress(string,string) splits by the second argument.
        return vm.envAddress(key, ",");
    }
}
