// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import "forge-std/Test.sol";
import {DAIOToken}           from "../src/DAIOToken.sol";
import {VariablePaymentGate} from "../src/VariablePaymentGate.sol";

contract VariablePaymentGateTest is Test {
    DAIOToken           internal daio;
    VariablePaymentGate internal gate;

    address internal constant ADMIN    = address(0xA11CE);
    address internal constant TREASURY = address(0x77EA);
    address internal constant ALICE    = address(0xA1);
    address internal constant CAROL    = address(0xCA);

    uint256 internal constant NOMINATION_PRICE = 0.5 ether; // 0.5 DAIO

    function setUp() public {
        daio = new DAIOToken(ADMIN);

        // For tests, allow ADMIN to mint by routing through admin-controlled
        // minter slot. In production the minter is RewardDistributor.
        vm.prank(ADMIN);
        daio.setMinter(ADMIN);

        gate = new VariablePaymentGate(daio, TREASURY, ADMIN);

        vm.prank(ADMIN);
        gate.setPrice(gate.KIND_NOMINATION(), NOMINATION_PRICE);

        // Seed Alice with DAIO and approve the gate.
        vm.prank(ADMIN);
        daio.mint(ALICE, 100 ether);
        vm.prank(ALICE);
        daio.approve(address(gate), type(uint256).max);
    }

    // -----------------------------------------------------------------
    // Pricing
    // -----------------------------------------------------------------

    function test_quote_ReturnsConfiguredPrice() public view {
        assertEq(gate.quote(ALICE, gate.KIND_NOMINATION()), NOMINATION_PRICE);
    }

    function test_quote_RevertsForUnpricedAction() public {
        bytes32 unknown = keccak256("UNKNOWN");
        vm.expectRevert(
            abi.encodeWithSelector(VariablePaymentGate.UnpricedAction.selector, unknown)
        );
        gate.quote(ALICE, unknown);
    }

    // -----------------------------------------------------------------
    // Settlement
    // -----------------------------------------------------------------

    function test_settle_TransfersPriceToTreasury() public {
        uint256 treasuryBefore = daio.balanceOf(TREASURY);
        uint256 aliceBefore    = daio.balanceOf(ALICE);

        uint256 paid = gate.settle(ALICE, gate.KIND_NOMINATION());
        assertEq(paid, NOMINATION_PRICE);

        assertEq(daio.balanceOf(TREASURY), treasuryBefore + NOMINATION_PRICE);
        assertEq(daio.balanceOf(ALICE),    aliceBefore    - NOMINATION_PRICE);
    }

    function test_settle_RevertsOnInsufficientAllowance() public {
        // Carol has DAIO but has not approved the gate.
        vm.prank(ADMIN);
        daio.mint(CAROL, 100 ether);

        vm.expectRevert(); // ERC20InsufficientAllowance
        gate.settle(CAROL, gate.KIND_NOMINATION());
    }

    function test_settle_RevertsOnInsufficientBalance() public {
        address pauper = address(0xDEAD);
        vm.prank(pauper);
        daio.approve(address(gate), type(uint256).max);

        vm.expectRevert(); // ERC20InsufficientBalance
        gate.settle(pauper, gate.KIND_NOMINATION());
    }

    // -----------------------------------------------------------------
    // Privilege gate
    // -----------------------------------------------------------------

    function test_settle_RevertsBelowMinHolding() public {
        bytes32 motion = gate.KIND_MOTION();
        vm.startPrank(ADMIN);
        gate.setPrice     (motion, 1 ether);
        gate.setMinHolding(motion, 50 ether);
        vm.stopPrank();

        // Alice holds 100 DAIO, clears 50 threshold.
        gate.settle(ALICE, motion);
        assertEq(daio.balanceOf(ALICE), 100 ether - 1 ether);

        // Carol holds 10 DAIO, fails 50 threshold.
        vm.prank(ADMIN);
        daio.mint(CAROL, 10 ether);
        vm.prank(CAROL);
        daio.approve(address(gate), type(uint256).max);
        vm.expectRevert(
            abi.encodeWithSelector(
                VariablePaymentGate.InsufficientHolding.selector,
                50 ether,
                10 ether
            )
        );
        gate.settle(CAROL, motion);
    }

    function test_canPerform_ReflectsBothChecks() public {
        bytes32 motion = gate.KIND_MOTION();
        vm.startPrank(ADMIN);
        gate.setPrice     (motion, 1 ether);
        gate.setMinHolding(motion, 50 ether);
        vm.stopPrank();

        assertTrue(gate.canPerform(ALICE, motion));

        vm.prank(ADMIN);
        daio.mint(CAROL, 10 ether);
        assertFalse(gate.canPerform(CAROL, motion));
    }

    // -----------------------------------------------------------------
    // Governance access control
    // -----------------------------------------------------------------

    function test_setPrice_RevertsForNonAdmin() public {
        vm.prank(ALICE);
        vm.expectRevert(VariablePaymentGate.NotAdmin.selector);
        gate.setPrice(gate.KIND_NOMINATION(), 999);
    }

    function test_setTreasury_RoutesToNewAddress() public {
        address newTreasury = address(0xCAFEBABE);
        vm.prank(ADMIN);
        gate.setTreasury(newTreasury);

        gate.settle(ALICE, gate.KIND_NOMINATION());
        assertEq(daio.balanceOf(newTreasury), NOMINATION_PRICE);
    }
}
