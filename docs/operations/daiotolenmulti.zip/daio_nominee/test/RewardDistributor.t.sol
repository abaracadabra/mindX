// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import "forge-std/Test.sol";
import {DAIOToken}         from "../src/DAIOToken.sol";
import {RewardDistributor} from "../src/RewardDistributor.sol";

contract RewardDistributorTest is Test {
    DAIOToken         internal daio;
    RewardDistributor internal distributor;

    address internal constant ADMIN     = address(0xA11CE);
    address internal RECIPIENT          = address(0xCAFE);

    uint256 internal constant ATTESTOR_PK = 0xA77E5701;
    address internal attestor;

    uint256 internal constant EPOCH    = 1 days;
    uint256 internal constant EPOCH_CAP = 1_000 ether;

    function setUp() public {
        attestor = vm.addr(ATTESTOR_PK);

        daio = new DAIOToken(ADMIN);

        distributor = new RewardDistributor(
            daio,
            attestor,
            ADMIN,
            EPOCH,
            EPOCH_CAP
        );

        // Wire distributor as DAIO minter.
        vm.prank(ADMIN);
        daio.setMinter(address(distributor));
    }

    // -----------------------------------------------------------------
    // Claim happy path
    // -----------------------------------------------------------------

    function test_claim_MintsToRecipient() public {
        RewardDistributor.RewardClaim memory c = RewardDistributor.RewardClaim({
            recipient: RECIPIENT,
            amount:    1 ether,
            nonce:     0,
            deadline:  block.timestamp + 1 hours
        });
        bytes memory sig = _sign(c);

        distributor.claim(c, sig);

        assertEq(daio.balanceOf(RECIPIENT), 1 ether);
        assertEq(distributor.nonces(RECIPIENT), 1);
    }

    function test_claim_SequentialNonces() public {
        for (uint256 i = 0; i < 3; i++) {
            RewardDistributor.RewardClaim memory c = RewardDistributor.RewardClaim({
                recipient: RECIPIENT,
                amount:    1 ether,
                nonce:     i,
                deadline:  block.timestamp + 1 hours
            });
            distributor.claim(c, _sign(c));
        }
        assertEq(daio.balanceOf(RECIPIENT), 3 ether);
        assertEq(distributor.nonces(RECIPIENT), 3);
    }

    // -----------------------------------------------------------------
    // Replay / expiry / signer
    // -----------------------------------------------------------------

    function test_claim_RejectsReplay() public {
        RewardDistributor.RewardClaim memory c = RewardDistributor.RewardClaim({
            recipient: RECIPIENT,
            amount:    1 ether,
            nonce:     0,
            deadline:  block.timestamp + 1 hours
        });
        bytes memory sig = _sign(c);
        distributor.claim(c, sig);

        vm.expectRevert(
            abi.encodeWithSelector(RewardDistributor.WrongNonce.selector, 1, 0)
        );
        distributor.claim(c, sig);
    }

    function test_claim_RejectsExpired() public {
        RewardDistributor.RewardClaim memory c = RewardDistributor.RewardClaim({
            recipient: RECIPIENT,
            amount:    1 ether,
            nonce:     0,
            deadline:  block.timestamp - 1
        });
        vm.expectRevert(RewardDistributor.ClaimExpired.selector);
        distributor.claim(c, _sign(c));
    }

    function test_claim_RejectsWrongSigner() public {
        RewardDistributor.RewardClaim memory c = RewardDistributor.RewardClaim({
            recipient: RECIPIENT,
            amount:    1 ether,
            nonce:     0,
            deadline:  block.timestamp + 1 hours
        });
        uint256 wrongPk = 0xBADD;
        bytes32 digest = _digest(c);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(wrongPk, digest);
        bytes memory sig = abi.encodePacked(r, s, v);

        vm.expectRevert(RewardDistributor.BadSigner.selector);
        distributor.claim(c, sig);
    }

    // -----------------------------------------------------------------
    // Epoch cap
    // -----------------------------------------------------------------

    function test_claim_EnforcesEpochCap() public {
        RewardDistributor.RewardClaim memory c = RewardDistributor.RewardClaim({
            recipient: RECIPIENT,
            amount:    EPOCH_CAP + 1,
            nonce:     0,
            deadline:  block.timestamp + 1 hours
        });
        vm.expectRevert(
            abi.encodeWithSelector(
                RewardDistributor.EpochCapExceeded.selector,
                EPOCH_CAP,
                0,
                EPOCH_CAP + 1
            )
        );
        distributor.claim(c, _sign(c));
    }

    function test_claim_EpochResetsCap() public {
        RewardDistributor.RewardClaim memory c1 = RewardDistributor.RewardClaim({
            recipient: RECIPIENT,
            amount:    EPOCH_CAP,
            nonce:     0,
            deadline:  block.timestamp + 1 hours
        });
        distributor.claim(c1, _sign(c1));

        vm.warp(block.timestamp + EPOCH + 1);

        RewardDistributor.RewardClaim memory c2 = RewardDistributor.RewardClaim({
            recipient: RECIPIENT,
            amount:    EPOCH_CAP,
            nonce:     1,
            deadline:  block.timestamp + 1 hours
        });
        distributor.claim(c2, _sign(c2));
        assertEq(daio.balanceOf(RECIPIENT), 2 * EPOCH_CAP);
    }

    // -----------------------------------------------------------------
    // EIP-712 helpers
    // -----------------------------------------------------------------

    function _digest(RewardDistributor.RewardClaim memory c) internal view returns (bytes32) {
        bytes32 structHash = keccak256(
            abi.encode(
                distributor.CLAIM_TYPEHASH(),
                c.recipient,
                c.amount,
                c.nonce,
                c.deadline
            )
        );
        bytes32 domainSeparator = _domainSeparator();
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator, structHash));
    }

    function _domainSeparator() internal view returns (bytes32) {
        return keccak256(
            abi.encode(
                keccak256(
                    "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
                ),
                keccak256(bytes("DAIO RewardDistributor")),
                keccak256(bytes("1")),
                block.chainid,
                address(distributor)
            )
        );
    }

    function _sign(RewardDistributor.RewardClaim memory c) internal view returns (bytes memory) {
        bytes32 digest = _digest(c);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(ATTESTOR_PK, digest);
        return abi.encodePacked(r, s, v);
    }
}
