// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import "forge-std/Test.sol";
import {GovernanceMultisig} from "../src/GovernanceMultisig.sol";

contract Target {
    uint256 public value;
    function setValue(uint256 v) external { value = v; }
}

contract GovernanceMultisigTest is Test {
    GovernanceMultisig internal ms;
    Target             internal target;

    address internal constant ALICE = address(0xA1);
    address internal constant BOB   = address(0xB0);
    address internal constant CAROL = address(0xCA);
    address internal constant DAVE  = address(0xDA);

    function setUp() public {
        address[] memory signers = new address[](3);
        signers[0] = ALICE;
        signers[1] = BOB;
        signers[2] = CAROL;
        ms = new GovernanceMultisig(signers, 2);

        target = new Target();
    }

    // -----------------------------------------------------------------
    // Construction
    // -----------------------------------------------------------------

    function test_construction_RegistersSignersAndThreshold() public view {
        assertEq(ms.signerCount(), 3);
        assertTrue(ms.isSigner(ALICE));
        assertTrue(ms.isSigner(BOB));
        assertTrue(ms.isSigner(CAROL));
        assertEq(ms.threshold(), 2);
    }

    function test_construction_RejectsZeroThreshold() public {
        address[] memory signers = new address[](1);
        signers[0] = ALICE;
        vm.expectRevert(bytes("threshold=0"));
        new GovernanceMultisig(signers, 0);
    }

    function test_construction_RejectsThresholdAboveSignerCount() public {
        address[] memory signers = new address[](2);
        signers[0] = ALICE;
        signers[1] = BOB;
        vm.expectRevert(bytes("threshold>signers"));
        new GovernanceMultisig(signers, 3);
    }

    // -----------------------------------------------------------------
    // Propose
    // -----------------------------------------------------------------

    function test_propose_RegistersProposalAndCountsProposerSignature() public {
        bytes memory data = abi.encodeCall(Target.setValue, (42));
        uint64 deadline = uint64(block.timestamp + 1 days);

        vm.prank(ALICE);
        uint256 id = ms.propose(address(target), data, 0, deadline);

        (address t,, bytes memory d, uint64 dl, uint32 count, bool exec) =
            ms.getProposal(id);
        assertEq(t,  address(target));
        assertEq(d,  data);
        assertEq(dl, deadline);
        assertEq(count, 1);
        assertFalse(exec);
        assertTrue(ms.hasSigned(id, ALICE));
    }

    function test_propose_RejectsNonSigner() public {
        bytes memory data = abi.encodeCall(Target.setValue, (42));
        vm.prank(DAVE);
        vm.expectRevert(GovernanceMultisig.NotSigner.selector);
        ms.propose(address(target), data, 0, uint64(block.timestamp + 1 days));
    }

    // -----------------------------------------------------------------
    // Sign
    // -----------------------------------------------------------------

    function test_sign_IncrementsCount() public {
        uint256 id = _propose();
        vm.prank(BOB);
        ms.sign(id);
        (,,,, uint32 count,) = ms.getProposal(id);
        assertEq(count, 2);
    }

    function test_sign_RejectsDoubleSignature() public {
        uint256 id = _propose();
        vm.prank(ALICE);
        vm.expectRevert(GovernanceMultisig.AlreadySigned.selector);
        ms.sign(id);
    }

    function test_sign_RejectsNonSigner() public {
        uint256 id = _propose();
        vm.prank(DAVE);
        vm.expectRevert(GovernanceMultisig.NotSigner.selector);
        ms.sign(id);
    }

    function test_sign_RejectsAfterDeadline() public {
        uint256 id = _propose();
        vm.warp(block.timestamp + 2 days);
        vm.prank(BOB);
        vm.expectRevert(GovernanceMultisig.DeadlinePassed.selector);
        ms.sign(id);
    }

    // -----------------------------------------------------------------
    // Execute
    // -----------------------------------------------------------------

    function test_execute_CallsTargetWhenThresholdMet() public {
        uint256 id = _propose();
        vm.prank(BOB);
        ms.sign(id);

        ms.execute(id);
        assertEq(target.value(), 42);

        (,,,,, bool exec) = ms.getProposal(id);
        assertTrue(exec);
    }

    function test_execute_RevertsBelowThreshold() public {
        uint256 id = _propose();
        vm.expectRevert(
            abi.encodeWithSelector(GovernanceMultisig.BelowThreshold.selector, 1, 2)
        );
        ms.execute(id);
    }

    function test_execute_RejectsReplay() public {
        uint256 id = _propose();
        vm.prank(BOB);
        ms.sign(id);
        ms.execute(id);

        vm.expectRevert(GovernanceMultisig.AlreadyExecuted.selector);
        ms.execute(id);
    }

    function test_execute_PropagatesRevertFromTarget() public {
        // Build a proposal that calls a non-existent function.
        bytes memory bogus = abi.encodeWithSignature("noSuchFunction()");
        uint64 deadline = uint64(block.timestamp + 1 days);
        vm.prank(ALICE);
        uint256 id = ms.propose(address(target), bogus, 0, deadline);
        vm.prank(BOB);
        ms.sign(id);

        vm.expectRevert();
        ms.execute(id);
    }

    // -----------------------------------------------------------------
    // Self-administration
    // -----------------------------------------------------------------

    function test_addSigner_ViaProposal() public {
        bytes memory data = abi.encodeCall(GovernanceMultisig.addSigner, (DAVE));
        uint64 deadline = uint64(block.timestamp + 1 days);

        vm.prank(ALICE);
        uint256 id = ms.propose(address(ms), data, 0, deadline);
        vm.prank(BOB);
        ms.sign(id);
        ms.execute(id);

        assertTrue(ms.isSigner(DAVE));
        assertEq(ms.signerCount(), 4);
    }

    function test_removeSigner_ViaProposal() public {
        bytes memory data = abi.encodeCall(GovernanceMultisig.removeSigner, (CAROL));
        uint64 deadline = uint64(block.timestamp + 1 days);

        vm.prank(ALICE);
        uint256 id = ms.propose(address(ms), data, 0, deadline);
        vm.prank(BOB);
        ms.sign(id);
        ms.execute(id);

        assertFalse(ms.isSigner(CAROL));
        assertEq(ms.signerCount(), 2);
    }

    function test_setThreshold_ViaProposal() public {
        bytes memory data = abi.encodeCall(GovernanceMultisig.setThreshold, (3));
        uint64 deadline = uint64(block.timestamp + 1 days);

        vm.prank(ALICE);
        uint256 id = ms.propose(address(ms), data, 0, deadline);
        vm.prank(BOB);
        ms.sign(id);
        ms.execute(id);

        assertEq(ms.threshold(), 3);
    }

    function test_addSigner_RejectsDirectCall() public {
        vm.prank(ALICE);
        vm.expectRevert(GovernanceMultisig.NotSelf.selector);
        ms.addSigner(DAVE);
    }

    function test_removeSigner_RejectsIfWouldInvalidateThreshold() public {
        // Threshold is 2, signer count is 3. Remove two signers in
        // sequence; the second should revert.
        _executeSelfCall(abi.encodeCall(GovernanceMultisig.removeSigner, (CAROL)));
        assertEq(ms.signerCount(), 2);

        bytes memory data = abi.encodeCall(GovernanceMultisig.removeSigner, (BOB));
        uint64 deadline = uint64(block.timestamp + 1 days);
        vm.prank(ALICE);
        uint256 id = ms.propose(address(ms), data, 0, deadline);
        vm.prank(BOB);
        ms.sign(id);
        vm.expectRevert();
        ms.execute(id);
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    function _propose() internal returns (uint256 id) {
        bytes memory data = abi.encodeCall(Target.setValue, (42));
        uint64 deadline = uint64(block.timestamp + 1 days);
        vm.prank(ALICE);
        id = ms.propose(address(target), data, 0, deadline);
    }

    function _executeSelfCall(bytes memory data) internal {
        uint64 deadline = uint64(block.timestamp + 1 days);
        vm.prank(ALICE);
        uint256 id = ms.propose(address(ms), data, 0, deadline);
        vm.prank(BOB);
        ms.sign(id);
        ms.execute(id);
    }
}
