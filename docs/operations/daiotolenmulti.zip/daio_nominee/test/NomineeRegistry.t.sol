// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import "forge-std/Test.sol";
import {DAIOToken}           from "../src/DAIOToken.sol";
import {VariablePaymentGate} from "../src/VariablePaymentGate.sol";
import {NomineeRegistry}     from "../src/NomineeRegistry.sol";
import {MockGenius}          from "./Mocks.sol";

contract NomineeRegistryTest is Test {
    DAIOToken           internal daio;
    MockGenius          internal genius;
    VariablePaymentGate internal gate;
    NomineeRegistry     internal registry;

    address internal constant ADMIN    = address(0xA11CE);
    address internal constant TREASURY = address(0x77EA);

    address internal constant NOMINEE_WALLET   = address(0xCAFE);
    address internal constant NOMINATOR_WALLET = address(0xFADE);

    bytes32 internal constant BANKON_ROOT  = keccak256("bankon.eth");
    bytes32 internal constant NOMINEE_NODE = keccak256("codephreak.bankon.eth");

    uint256 internal constant NOMINATION_PRICE = 0.5 ether;

    function setUp() public {
        daio  = new DAIOToken(ADMIN);
        vm.prank(ADMIN);
        daio.setMinter(ADMIN);

        genius = new MockGenius();
        gate   = new VariablePaymentGate(daio, TREASURY, ADMIN);

        vm.prank(ADMIN);
        gate.setPrice(gate.KIND_NOMINATION(), NOMINATION_PRICE);

        registry = new NomineeRegistry(genius, gate, BANKON_ROOT);

        genius.enrol(NOMINEE_WALLET,   NOMINEE_WALLET);
        genius.enrol(NOMINATOR_WALLET, NOMINATOR_WALLET);

        // Fund and approve.
        vm.prank(ADMIN);
        daio.mint(NOMINATOR_WALLET, 10 ether);
        vm.prank(NOMINATOR_WALLET);
        daio.approve(address(gate), type(uint256).max);
    }

    // -----------------------------------------------------------------
    // Registration
    // -----------------------------------------------------------------

    function test_register_BindsIdentityToNode() public {
        vm.prank(NOMINEE_WALLET);
        registry.registerNominee(NOMINEE_NODE);

        (address identity, bytes32 node,, uint64 count, bool active) =
            registry.nominees(NOMINEE_WALLET);

        assertEq(identity, NOMINEE_WALLET);
        assertEq(node,     NOMINEE_NODE);
        assertEq(count,    0);
        assertTrue(active);
    }

    function test_register_RevertsOnDuplicate() public {
        vm.prank(NOMINEE_WALLET);
        registry.registerNominee(NOMINEE_NODE);

        vm.prank(NOMINEE_WALLET);
        vm.expectRevert(NomineeRegistry.AlreadyRegistered.selector);
        registry.registerNominee(NOMINEE_NODE);
    }

    function test_register_RevertsIfNotEnrolled() public {
        address stranger = address(0xDEAD);
        vm.prank(stranger);
        vm.expectRevert(NomineeRegistry.NotEnrolled.selector);
        registry.registerNominee(NOMINEE_NODE);
    }

    // -----------------------------------------------------------------
    // Nomination
    // -----------------------------------------------------------------

    function test_nominate_IncrementsCountAndChargesDaio() public {
        _registerNominee();
        uint256 before = daio.balanceOf(NOMINATOR_WALLET);

        vm.prank(NOMINATOR_WALLET);
        registry.nominate(NOMINEE_WALLET);

        assertEq(registry.nominationCount(NOMINEE_WALLET), 1);
        assertTrue(registry.hasNominated(NOMINATOR_WALLET, NOMINEE_WALLET));
        assertEq(daio.balanceOf(NOMINATOR_WALLET), before - NOMINATION_PRICE);
        assertEq(daio.balanceOf(TREASURY), NOMINATION_PRICE);
    }

    function test_nominate_DeduplicatesPerNominator() public {
        _registerNominee();

        vm.prank(NOMINATOR_WALLET);
        registry.nominate(NOMINEE_WALLET);

        vm.prank(NOMINATOR_WALLET);
        vm.expectRevert(NomineeRegistry.DuplicateNomination.selector);
        registry.nominate(NOMINEE_WALLET);
    }

    function test_nominate_RejectsSelfNomination() public {
        _registerNominee();
        vm.prank(ADMIN);
        daio.mint(NOMINEE_WALLET, 10 ether);
        vm.prank(NOMINEE_WALLET);
        daio.approve(address(gate), type(uint256).max);

        vm.prank(NOMINEE_WALLET);
        vm.expectRevert(NomineeRegistry.SelfNomination.selector);
        registry.nominate(NOMINEE_WALLET);
    }

    function test_nominate_PriceConstantAcrossMultipleNominees() public {
        _registerNominee();
        address secondNominee = address(0xBA5E);
        genius.enrol(secondNominee, secondNominee);
        vm.prank(secondNominee);
        registry.registerNominee(keccak256("second.bankon.eth"));

        uint256 before = daio.balanceOf(NOMINATOR_WALLET);
        vm.prank(NOMINATOR_WALLET);
        registry.nominate(NOMINEE_WALLET);
        vm.prank(NOMINATOR_WALLET);
        registry.nominate(secondNominee);

        assertEq(daio.balanceOf(NOMINATOR_WALLET), before - 2 * NOMINATION_PRICE);
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    function _registerNominee() internal {
        vm.prank(NOMINEE_WALLET);
        registry.registerNominee(NOMINEE_NODE);
    }
}
