// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity ^0.8.26;

import {IGenius, IFides} from "../src/interfaces/IBonafide.sol";

contract MockGenius is IGenius {
    mapping(address => bool)    public enrolled;
    mapping(address => address) public identity;

    function enrol(address subject, address id) external {
        enrolled[subject] = true;
        identity[subject] = id;
    }

    function isEnrolled(address subject) external view returns (bool) {
        return enrolled[subject];
    }

    function identityOf(address subject) external view returns (address) {
        return identity[subject];
    }
}

contract MockFides is IFides {
    mapping(address => uint256) public score;

    function setScore(address who, uint256 s) external { score[who] = s; }

    function scoreOf(address who) external view returns (uint256) {
        return score[who];
    }
}
