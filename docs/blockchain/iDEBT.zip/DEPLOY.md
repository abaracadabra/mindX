# DEPLOY.md — Mainnet Deployment Runbook

One-time path from audited code to self-governing mainnet protocol on both chains. Foundry for EVM, mainnet-only per cypherpunk2048 standard (no upgradeable proxies, no admin keys post-deploy). Execute top to bottom; every stage has a verification gate — do not proceed past a failed gate.

---

## 0. Preconditions

- [ ] `forge test` green (27 EVM tests), `pytest` green (Algorand suites), `slither` no high/critical
- [ ] AUDIT_V2.md findings A1–A5 confirmed fixed in the artifact being deployed
- [ ] Deployer wallets funded: ~0.5 ETH equivalent (EVM), ~50 ALGO (Algorand)
- [ ] Multisig for EmergencyPauser guardians created; DAIO app live on Algorand
- [ ] `.env` populated from `.env.example` — never commit it

```bash
# .env (EVM)
PRIVATE_KEY=
ADMIN_ADDRESS=            # deployer EOA now; roles transfer to Timelock in §5
STABLECOIN_ADDRESS=0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48   # USDC mainnet
PYTH_ADDRESS=0x4305FB66699C3B2702D4d05CF36551390A4c69C6
PYTH_BTC_FEED_ID=0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43
CHAINLINK_BTC_FEED=0xF4030086522a5bEEa4988F8cA5B36dbC97BeE88c
CL_EUR_USD_FEED=0xb49f677943BC038e9857d61E7d053CaA2C1734C1
CL_JPY_USD_FEED=0xBcE206caE7f0ec07b545EddE332A47C2F75bbeb3
CL_GBP_USD_FEED=0x5c0Ab2d9b5a7ed9f470386e82BB36A3613cDd4b5
CL_CNY_USD_FEED=0xeF8A4aF35cd47424672E3C590aBD37FBB7A7759a
CL_USD_USD_FEED=          # deploy the constant-1 wrapper first (§2 note)
ETHERSCAN_API_KEY=
RPC_URL=

# .env (Algorand)
DEPLOYER_MNEMONIC=
USDC_ASA_ID=31566704      # USDC on Algorand mainnet
ALGOIDNFT_APP_ID=
BONAFIDE_APP_ID=
DAIO_APP_ID=
X402_APP_ID=
WORMHOLE_CORE_APP_ID=
```

---

## 1. EVM — Base Stack

```bash
forge script script/Deploy.s.sol:Deploy \
  --rpc-url $RPC_URL --broadcast --verify --etherscan-api-key $ETHERSCAN_API_KEY
```

Deploys: RWAToken, DeltaVerseDebtOracle, CrossCollateralVault, PerpetualEngine, DebtInheritanceProtocol, Timelock, Governor, EmergencyPauser.

**Gate 1:** all 8 verified on Etherscan; `oracle.latestPrice()` returns the seeded composite; record addresses into `.env` as `GDSI_ORACLE_ADDRESS`, `DIP_ADDRESS`.

## 2. EVM — Inverse Debt Layer

```bash
forge script script/DeployInverseDebtLayer.s.sol:DeployInverseDebtLayer \
  --rpc-url $RPC_URL --broadcast --verify --etherscan-api-key $ETHERSCAN_API_KEY
```

Deploys BitcoinAnchorOracle (Chainlink 50% + Pyth 50%, seeded), DebasementIndex V1 (baseline locked), InverseDebtToken, BitcoinProfitRecognizer.

**Gate 2:** `btcOracle.compositeValue()` within 1% of spot BTC; `debasement.currentIndex() == 1e18 ±ε`. Record `BTC_ORACLE_ADDRESS`.

> **USD constant feed:** before §3, deploy the 8-decimal constant-1 wrapper (returns `1e8`, fresh timestamp) and set `CL_USD_USD_FEED`. ~15 lines; pattern in `script/DeployGlobalBasketLayer.s.sol` header.

## 3. EVM — Global Basket Layer

```bash
forge script script/DeployGlobalBasketLayer.s.sol:DeployGlobalBasketLayer \
  --rpc-url $RPC_URL --broadcast --verify --etherscan-api-key $ETHERSCAN_API_KEY
```

Deploys SovereignDebtRegistry (seeded: USD 38.3T / EUR 21T / JPY 9.8T / GBP 3.5T / CNY 18.7T), GlobalCurrencyBasket (**invertFeed=true on all Chainlink fiat feeds, false on the USD constant** — this is audit fix A1; do not deviate), DebasementIndexV2.

**Gate 3 (critical):** `basket.fiatDebasementIndex()` returns `1e18 ±0.5%` at baseline. If it returns ~`(fx)²`-scaled garbage, an invertFeed flag is wrong — halt. Sanity-check one currency by hand: EUR/USD feed 1.08 → `fxPerUsd ≈ 0.9259e18`.

Then point iDEBT at V2: deploy a fresh `InverseDebtToken` with the V2 index address (constructor-bound by design — no proxies), and route any V1 liquidity through `BitcoinProfitRecognizer`.

## 4. Algorand — Six Stages

```bash
cd algorand
# Replace deploy.py's illustrative AppFactory calls with generated typed clients first:
algokit compile py contracts/        # emits ARC-56 + typed clients (audit note A9)
poetry run python scripts/deploy.py --network mainnet --stage 0   # or stages 1..6 individually
```

Stage order: 1 core (controller, oracle hub) → 2 derivatives (vault, perp, coordinator) → 3 compliance → 4 bridge → 5 basket (registry + basket) → 6 iDEBT.

Post-deploy actions from the printed 16-item checklist, in order: issue RWA ASA; configure 5 oracle sub-indices + reporters; vault opt-ins (USDC ASA 31566704 + RWA); register collateral; seed insurance fund; issue sGDSI; register bridge peer (Ethereum = Wormhole chain 2) + epoch limits; seed registry (same five currencies, USD-equivalent e6); configure basket FX sub-index IDs; `initialize_baseline` with keeper-fetched prices; `issue_idebt_asa`; set iDEBT + basket reporters to the keeper address; `top_up_reserve`.

**Gate 4:** localnet dress-rehearsal of this exact sequence passed; on mainnet, a 1-USDC mint/burn round trip through the atomic group succeeds and returns ~99.4% (two 30bps fees).

## 5. Cross-Chain Wiring

1. EVM: deploy `WormholeRwaReceiver` with `algorandPeerAddress` = Algorand bridge app address (32-byte Wormhole format), `maxPerEpoch` conservative ($1M to start).
2. Algorand: register the receiver as the Ethereum peer.
3. **Gate 5:** bridge 1 unit Algorand→EVM; confirm `Bridged` event mints to the correct recipient with the correct amount (this exercises audit fix A2's decoder against a live VAA); bridge it back; confirm unlock. Verify replay: resubmitting the same VAA must revert `VAAAlreadyConsumed`.

## 6. Keepers + Observability

```bash
docker compose up -d        # keepers, prometheus
```

**Gate 6:** within 10 minutes — Pyth updates landing, `updateComposite` succeeding on both oracles, basketReporter pushing `update_index` on Algorand, liquidator scanning, Prometheus targets green.

## 7. Governance Handover (point of no return)

EVM — for each of the 13 contracts: grant `DEFAULT_ADMIN_ROLE` to Timelock, register in `EmergencyPauser.managedContracts`, then **renounce** the deployer's role. Algorand — `transfer_admin(DAIO_APP_ADDRESS)` on all 10 apps.

**Gate 7 (final):** a deployer-signed parameter change on any contract **fails**; a Timelock-queued change succeeds after the 48 h delay; EmergencyPauser can pause/unpause iDEBT. No admin keys post-deploy — the cypherpunk2048 invariant now holds.

## 8. Announce

Update `agenticplace.pythai.net/allchain.html` with all addresses (CAIP-2 format); point the `ui/dashboard.jsx` contract constants at mainnet; publish the deployment block numbers in `subgraph/subgraph.yaml` and deploy the subgraph; mindX publishes the deployment notice to rage.pythai.net.

---

## Rollback Reality

There is none — that is the design. Pre-handover (§1–6) a bad deploy is abandoned and redeployed fresh; post-handover (§7) the only levers are pause, governance parameter changes, and liquidity migration to a corrected deployment via the Recognizer pattern. Hence the gates: every one is cheaper than the lever that follows it.

*(c) 2026 BANKON — Professor Codephreak. Deploy when the gates say so, not before.*
