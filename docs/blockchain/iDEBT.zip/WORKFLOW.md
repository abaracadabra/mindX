# WORKFLOW.md — iDEBT Protocol Operational Workflows

This document describes every recurring workflow in the protocol's life: the developer loop, the user journeys, the keeper duties, the governance cycle, and incident response. DEPLOY.md covers the one-time act of getting to mainnet; this covers everything that happens before and after.

---

## 1. Developer Workflow

### EVM loop (Foundry)

```bash
# fresh checkout
forge install foundry-rs/forge-std OpenZeppelin/openzeppelin-contracts
forge build

# fast inner loop — run one suite
forge test --match-contract InverseDebtTest -vvv

# full suite with gas report
forge test --gas-report

# static analysis before any PR
slither . --config-file audit/slither.config.json
myth analyze src/InverseDebtToken.sol --solc-json audit/.mythril.yml
```

Rules of the loop: every behavioral change ships with a regression test in the same commit (see `test_12` / `test_14` / `test_15` for the v2.1 pattern); any change to an event signature requires a matching `subgraph/schema.graphql` update; any change to a constructor or external signature requires updating all three deploy scripts and grepping the test suites for call sites.

### Algorand loop (AlgoKit)

```bash
cd algorand
algokit localnet start
poetry install
poetry run pytest tests/ -v            # algopy_testing unit tests
algokit compile py contracts/          # produces TEAL + ARC-56 artifacts
poetry run python scripts/deploy.py --network localnet --stage 0
```

The Algopy tests run against the Python-level semantics; before any testnet push, also run the compiled TEAL through `algokit project run audit-teal` (opcode-budget and box-usage lint) because the unit layer does not measure opcode costs — the basket loop and 256-inner-txn distributions are the two places budgets bite.

### Cross-chain payload discipline

The Wormhole payload layout (85 bytes, defined in `WormholeRwaReceiver._decodePayload` and `CROSS_CHAIN.md`) is a shared contract between chains. Any change must update: the Algorand `bridge_out` builder, the EVM decoder, the layout table in CROSS_CHAIN.md, and a paired encode/decode test on each side. Treat it like an ABI — version byte bumps on any layout change.

---

## 2. User Workflows

### 2.1 Mint iDEBT (EVM)

1. Approve USDC to `InverseDebtToken`.
2. Read `debasementIndex.currentIndex()` and quote expected output off-chain: `iDEBT = usdc × (1 − 30bps) × 1e18 / index`.
3. Call `mint(usdcAmount, minIDebtOut)` with `minIDebtOut` set ~50bps below quote to absorb index drift between quote and inclusion.
4. The `Minted` event carries your entry index and BTC-satoshi snapshot for profit tracking.

### 2.2 Burn iDEBT (EVM)

1. Quote with `redemptionValue(iDebtAmount)`.
2. Call `burn(iDebtAmount, minUsdcOut)`.
3. Inspect the `Burned` event: `realizedBtcDeltaSatoshis` is your hard-money P&L; `haircutApplied=true` means the contract paid pro-rata under extreme debasement — the honest failure mode, not an error.

### 2.3 Migrate sGDSI gains into iDEBT

Approve sGDSI to `BitcoinProfitRecognizer`, then `recognizeProfit(sGdsiAmount, minUsdcFromBurn, minIDebtFromMint)`. One transaction, one oracle read, no naked-USDC window. The `RecognizedProfit` event carries the full trail for the subgraph.

### 2.4 Full thesis position (EVM)

`expressThesis(rwaToken, rwaAmount, borrowAmount, leverage, isLong)` — deposits RWA, borrows, opens the perp, records the position atomically. Close with `closeThesis()`. One open thesis per address; the unwind handles underwater positions deterministically (collateral stays in vault as partial backing, no surplus returned).

### 2.5 Algorand mint/burn (atomic groups)

Mint group: `[AssetTransfer USDC → app address, AppCall mint_idebt(usdc_amount, min_out, btc_sats)]`. Burn group: `[AssetTransfer iDEBT → app address, AppCall burn_idebt(amount, min_out)]`. The contract verifies the companion transfer via `gtxn` inspection; mismatched amounts fail the whole group. Wallets must opt in to the iDEBT ASA before first mint.

### 2.6 Bridge RWA Algorand → EVM → iDEBT

1. Atomic group: `[AssetTransfer RWA → bridge, AppCall bridge_out(amount, evm_recipient)]`.
2. Wait for 13-of-19 guardian signatures (typically < 1 min).
3. Relayer (or you) submits the signed VAA to `WormholeRwaReceiver.completeTransfer`.
4. Wrapped RWA arrives; deposit into `CrossCollateralVault`, borrow, mint iDEBT.

---

## 3. Keeper Workflows

Five keeper duties, all under `keepers/` (viem, Docker Compose `keepers` service):

| Keeper | Cadence | Action | Failure symptom |
|---|---|---|---|
| pythUpdater | 60s | Push Hermes price updates to Pyth, then `btcOracle.updateComposite()` | `OracleStale` reverts on mint/burn |
| subIndexFinalizer | 5 min | Finalize GDSI sub-indices, call oracle `updateComposite()` | composite drifts stale; `DeviationFlagged` backlog |
| liquidator | 15s | Scan vault health factors, liquidate < 1.0 | bad debt accrues to insurance fund |
| feeRouter | 1 h | Route protocol fees to oracle LPs | LP yield stalls (cosmetic) |
| basketReporter | 5 min | Read FX + BTC, compute basket, `update_index()` on Algorand iDEBT; quarterly `update_country()` on both registries from IMF releases | Algorand iDEBT index stale; basket weights drift |

The basketReporter's quarterly registry update is the only human-in-the-loop cadence: pull IMF Global Debt Database figures, convert to USD-equivalent, submit `updateCountry` per currency. The 20% deviation breaker means a fat-fingered figure reverts rather than reweighting the basket.

Monitoring: Prometheus (`monitoring/prometheus.yml`) scrapes keeper heartbeats; alert if any keeper's last-success age exceeds 3× its cadence, and alert immediately on any `DeviationFlagged` or `haircutApplied=true` event.

---

## 4. Governance Workflow

Parameter changes (fees, weights, staleness bounds, epoch limits) follow: propose on `DeltaVerseGovernor` → vote → queue in `DeltaVerseTimelock` (48 h delay) → execute. On Algorand the same flow runs through the DAIO app once admin roles are transferred per the deployment checklist.

Emergency path: `EmergencyPauser` guardians can pause any managed contract instantly — pause-only power, no parameter authority. The inverse-debt and basket layers pause independently of the base stack.

Reporter rotation: `setReporter` / `set_reporter` are admin-gated on both chains; rotate via governance, never by sharing keys. Before significant TVL, replace single reporters with N-of-M threshold submission (tracked in AUDIT_V2.md A5).

---

## 5. Incident Response

**Oracle divergence** (composite vs. external reference > 5%): pause iDEBT mint/burn via EmergencyPauser; inspect `DeviationFlagged` queue; governor approves or rejects the pending value; unpause.

**Bridge anomaly** (unexpected VAA, epoch limit hit unexpectedly): pause both bridge sides; the 24 h epoch caps bound worst-case extraction; audit consumed-VAA sets on both chains for replay attempts; rotate `algorandPeerAddress` only via governance.

**Haircut events**: a `haircutApplied=true` burn is by-design honesty, not an incident — but it signals the reserve is thin. Response is economic, not technical: governance tops up via `topUpReserve` and/or raises `reserveShareBps` so future fees rebuild the buffer.

**Key compromise**: EmergencyPauser guardian set is a multisig — single guardian compromise cannot unpause or change parameters. Admin keys post-handover are the Timelock/DAIO themselves; there is no EOA admin to compromise. This is the cypherpunk2048 invariant: no admin keys post-deploy.
