# Internal Audit Report — iDEBT Protocol v2.1

**Scope:** Full project — 16 EVM contracts, 10 Algorand contracts, tests, deployment scripts.
**Method:** Manual line-by-line review of all value-flow paths, oracle reads, payload decoding, and fee accounting, with regression tests added for every code fix.
**Result:** 3 high-severity findings fixed, 2 medium fixed, 4 low/informational documented.

---

## High Severity

### A1 — GlobalCurrencyBasket: FX feed convention inverted (FIXED)

**Location:** `src/GlobalCurrencyBasket.sol :: _readFxPerUsd`
**Impact:** Every real Chainlink fiat feed (EUR/USD, JPY/USD, GBP/USD, CNY/USD) quotes **USD-per-C**, but the basket math requires **C-per-USD**. The v2.0 code assumed the feed already returned C-per-USD and pointed the deployment script at standard Chainlink aggregators. On mainnet this would have silently inverted every non-USD currency's strength ratio: a weakening yen would have registered as a strengthening one, corrupting the debasement index that iDEBT settles against. Funds-at-risk severity because mint/burn settlement uses the corrupted index directly.
**Fix:** Added explicit `invertFeed` flag to `CurrencyConfig`. When true, the normalized 18-decimal reading is inverted (`1e36 / raw18`). Deployment script now sets `invertFeed=true` for EUR/JPY/GBP/CNY and `false` for the constant-1 USD wrapper. Regression test `test_14_InvertedFeedNormalization` proves a USD-per-C feed at 1.0870 produces the identical basket reading as its 0.92 C-per-USD reciprocal.

### A2 — WormholeRwaReceiver: payload decoder read wrong byte offsets (FIXED)

**Location:** `src/WormholeRwaReceiver.sol :: _decodePayload`
**Impact:** The assembly decoder read `recipient` at payload bytes 35–54 and `amount` at bytes 45–52. Under the declared layout (32-byte-padded fields), the recipient address actually lives at bytes 47–66 and the amount at 69–76. Every bridge completion would therefore have minted a wrong amount to a wrong (or zero) address — total failure of the inbound bridge path, discovered only on first live VAA.
**Fix:** Replaced with a canonical 85-byte layout decoder using a single audited word-read helper and explicit offsets: version at 0, ASA id right-aligned in bytes 1–32, source chain 33–34, recipient right-aligned in bytes 35–66, dest chain 67–68, amount (uint64 big-endian) 69–76, nonce 77–84. Version byte is now validated (must be 0x01). The Algorand `bridge_out` payload builder emits this exact layout per `CROSS_CHAIN.md`.

### A3 — InverseDebtToken (EVM + Algorand): haircut fee accounting could drain backing (FIXED)

**Location:** `src/InverseDebtToken.sol :: burn` and `algorand/.../inverse_debt_token.py :: burn_idebt`
**Impact:** The fee, `reserveCut`, and `treasuryCut` were computed from the **unclamped gross** redemption value before the solvency check. Under haircut (gross > balance), `treasuryFees` accrued claims the contract's balance could not cover. A subsequent `claimTreasury()` would then transfer out USDC that backs other holders' redemptions — an insolvency amplifier in exactly the stress scenario the haircut is meant to handle honestly.
**Fix (both chains):** Clamp `grossUsdc` to the contract's actual balance **first**, then derive fee/reserve/treasury from the clamped amount. Fees are now always proportional to what is actually paid. The EVM `Burned` event gained a `haircutApplied` flag so the subgraph and UI can mark stressed redemptions. Regression test `test_12_HaircutFeeAccountingStaysSolvent` asserts the invariant `treasuryFees <= contract balance` after a 3x-index haircut burn.

---

## Medium Severity

### A4 — GlobalCurrencyBasket: no staleness bound on the BTC anchor (FIXED)

**Location:** `src/GlobalCurrencyBasket.sol :: fiatStrengthIndex / initializeBaseline`
**Impact:** Per-currency FX reads carried `maxStaleness` checks, but the BTC price — which enters **every** per-currency ratio — was only checked for non-zero. A halted BTC oracle would freeze the basket at a phantom value while FX rates kept moving, skewing the index in whichever direction BTC had last printed.
**Fix:** Added `maxBtcStaleness` (default 2 hours, manager-settable) enforced in both `initializeBaseline` and `fiatStrengthIndex`. Regression test `test_15_StaleBtcOracleReverts` pins the revert.

### A5 — Algorand GlobalCurrencyBasket: unauthenticated index computation (FIXED)

**Location:** `algorand/contracts/stage1_core/global_currency_basket.py :: compute_fiat_debasement`
**Impact:** The method trusts caller-supplied prices by design (Algorand opcode budgets force off-chain pre-aggregation), but it was callable by anyone. An attacker could compute fabricated index values inside an atomic group and feed the return value to a composed consumer.
**Fix:** Added `reporter` state (set at `create`, rotatable by admin) and restricted the method to reporter-or-admin — the same trust boundary the iDEBT `update_index` already uses, making the two consistent. Production note retained: replace single reporter with N-of-M threshold before significant TVL.

---

## Low / Informational (documented, not code-changed)

### A6 — iDEBT position tracking is account-bound, not token-bound

`positions[msg.sender]` BTC-basis tracking desynchronizes if a user transfers iDEBT to another wallet (the recipient has tokens but no basis; the sender has basis but fewer tokens). Settlement math is unaffected — only the cosmetic `realizedBtcDelta` event field degrades, and the code already guards with `balanceOf(msg.sender) >= iDebtAmount`. Acceptable; documented for UI teams.

### A7 — WormholeRwaReceiver does not verify destination chain ID

The decoder skips bytes 67–68 (dest chain). Emitter + chain + replay checks make cross-deployment replay impractical, but adding a stored `wormholeChainId` equality check is recommended hardening for multi-EVM-chain deployments of the same receiver bytecode.

### A8 — SovereignDebtRegistry currency list never prunes

Delisted currencies stay in `currency_list` (Algorand) / `currencyList` (EVM) as inert entries. Intentional (stable indices for consumers); gas/box cost is bounded by the small currency count. Re-registering a delisted currency requires a new code path if ever needed — currently `register_country` rejects known codes even when delisted on the EVM side via `records` check semantics. Tracked for v2.2.

### A9 — deploy.py AppFactory API is illustrative

`AppFactory.from_path` pseudocode must be replaced with the project's generated typed clients (`algokit compile py` artifacts) before live deployment. DEPLOY.md now states this explicitly.

---

## Test Deltas

| Suite | v2.0 | v2.1 |
|---|---|---|
| `test/GlobalCurrencyBasket.t.sol` | 13 tests | 15 tests (+invertFeed, +BTC staleness) |
| `test/InverseDebtToken.t.sol` | 11 tests | 12 tests (+haircut solvency invariant) |
| Algorand suites | 9 files | 9 files (basket create signature updated) |

## Invariants Now Pinned by Tests

1. Quoting convention of any FX feed cannot change the basket reading (A1).
2. The basket cannot be read against a stale BTC anchor (A4).
3. `treasuryFees` can never exceed the contract's stablecoin balance (A3).
4. Payout on burn can never exceed the contract's stablecoin balance (pre-existing test_09, retained).

---

*(c) 2026 BANKON — Professor Codephreak. v2.1 audit pass complete.*
