# Pyth Network: The Definitive Usage Guide for the PYTHAI Ecosystem

**Version 2.0.0 — audited and verified against docs.pyth.network on 2026-07-08**
**Author:** Professor Codephreak · Apache-2.0 under BANKON copyright
**Scope:** AgenticPlace (agenticplace.pythai.net) · mindX (mindx.pythai.net) · BANKON
(bankon.pythai.net) · DAIO on-chain governance · PARSEC x402 Algorand payment rail ·
publication via rage.pythai.net

---

## Read This First: The July 31, 2026 Upgrade

Pyth Core upgrades on **July 31, 2026** — twenty-three days from this document's audit date.
Two consequences shape everything below. First, every Hermes consumer will require an API
key; the upgraded endpoint is `https://pyth.dourolabs.app/hermes` with an
`Authorization: Bearer $PYTH_API_KEY` header, and the legacy unauthenticated
`https://hermes.pyth.network` access model ends. Second, new EVM integrations should target
the **upgraded contract addresses** rather than the current ones; contracts on chains in the
upgrade set will be migrated automatically by the DAO, while chains outside the set (notably
Polygon PoS and 0G for our purposes) retain their current addresses indefinitely.

Obtain an API key and read the upgrade guide before deploying anything:
https://docs.pyth.network/price-feeds/core/upgrade/preparing

Every code sample in this guide is written for the post-upgrade world and degrades
gracefully in the pre-upgrade one.

---

## 1. What Pyth Actually Is

Pyth is a **pull oracle**. This single fact governs correct usage and was the root cause of
most defects found in the v1 audit. Over one hundred and twenty first-party publishers —
exchanges, market makers, trading firms — stream prices to Pythnet, where they are
aggregated roughly every 400 milliseconds into a price and a **confidence interval**. Those
aggregates are attested cross-chain and served by **Hermes**, Pyth's off-chain web service.
Nothing lands on your target chain automatically. Your application (or a scheduler you
operate) fetches a signed update from Hermes, submits it to the Pyth contract on your chain
with `updatePriceFeeds` (paying a small fee), and only then reads the fresh price.

The mental model, in one line:

    Hermes (fetch signed update) → updatePriceFeeds{value: fee} → getPriceNoOlderThan(id, maxAge)

If you read without updating, you get whatever the last unrelated caller pushed — possibly
hours old, possibly nothing at all. Never ship `getPriceUnsafe` on a hot path without an
update step or a documented freshness argument.

Reference: https://docs.pyth.network/price-feeds/core/pull-updates

---

## 2. Verified Contract Addresses (Mainnets Relevant to PYTHAI)

The canonical, always-current list lives at
https://docs.pyth.network/price-feeds/core/contract-addresses/evm — the table below was
transcribed from it on 2026-07-08 and covers the chains in the ALLCHAIN registry
(agenticplace.pythai.net/allchain.html).

| Network | Current Pyth address | Upgraded address (use for new work) |
|---|---|---|
| Ethereum Mainnet | `0x4305FB66699C3B2702D4d05CF36551390A4c69C6` | `0x14b9932cc9AC8Ee03301665a8644A753f46D8552` |
| Arbitrum One | `0xff1a0f4744e8582DF1aE09D5611b887B6a12925C` | `0xe15357fB7ab31E091583b9c4b4135BB2f176f38e` |
| OP Mainnet | `0xff1a0f4744e8582DF1aE09D5611b887B6a12925C` | `0xa78951b6bADC9F4740f6f456E9144705D5C5E4B2` |
| Base | `0x8250f4aF4B972684F7b336503E2D6dFeDeB1487a` | `0xbC16aee60f64864882BC6C4E428e148Fc0E272F5` |
| Polygon Mainnet | `0xff1a0f4744e8582DF1aE09D5611b887B6a12925C` | — not in upgrade set |
| 0G Mainnet | `0x2880aB155794e7179c9eE2e38200202908C17B43` | — not in upgrade set |

Note that several chains share bytecode-identical deployments at the same address
(`0xff1a…925C` appears on Arbitrum, OP, Polygon, Celo, Fantom) — but never assume; always
check the docs page for a chain before deploying against it.

**Algorand has no Pyth deployment.** The AVM is not among Pyth's supported target chains
(EVM, Solana/SVM, Aptos, Sui, IOTA, Movement, TON, Fuel, CosmWasm, NEAR, Starknet). Section
6 explains the correct pattern for the Algorand-side x402 rail.

---

## 3. Price Feed IDs and How to Treat Them

A feed ID is a 32-byte identifier per asset pair, identical across all EVM chains, distinct
between the Stable and Beta channels. Two IDs are verified against official documentation
and safe to hard-code:

- **BTC/USD** — `0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43`
- **ETH/USD** — `0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace`

Every other ID you need — ALGO/USD for x402 quoting, USDC/USD and USDT/USD for PAI collateral
checks, CAD-relevant FX pairs for FOUR BUCKS — must be looked up at the canonical catalogue
before use: https://insights.pyth.network/price-feeds (browsable) or
https://docs.pyth.network/price-feeds/core/price-feeds (reference). Two discipline points
learned from the audit: there is no "USD/USD" feed — USD is the quote side, so a dollar peg
is monitored via the *stablecoin's* feed (Crypto.USDC/USD) — and IDs pasted from third-party
tutorials are frequently Beta-channel IDs that will not resolve on Stable/Hermes-Stable.

For FOUR BUCKS specifically, the pair to verify in the catalogue is FX.USD/CAD (Pyth carries
major FX pairs); the CDP oracle then derives CAD prices as `asset/USD × USD/CAD`, for which
Pyth documents a cross-rate helper: https://docs.pyth.network/price-feeds/core/derive-cross-rate

---

## 4. Fetching Prices from Hermes (Off-Chain)

Hermes exposes three access modes. All three are demonstrated in the accompanying
`hermes_client.ts`, and the REST shapes below are copied from the live API reference.

**REST — latest update for one or more feeds.** The response carries `binary.data` (hex
payload for on-chain submission) and `parsed[]` (price, conf, expo, publish_time, plus an
EMA price) for direct off-chain consumption:

```bash
curl -H "Authorization: Bearer $PYTH_API_KEY" \
  'https://pyth.dourolabs.app/hermes/v2/updates/price/latest?ids[]=0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43&ids[]=0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace'
```

**Streaming — Server-Sent Events.** `GET /v2/updates/price/stream?ids[]=…` pushes updates
continuously. Connections close automatically after twenty-four hours; production consumers
(the mindX oracle route publishing to rage.pythai.net should be one) must implement
reconnection.

**SDK — HermesClient.** The correct package is `@pythnetwork/hermes-client` (not
`@pythnetwork/client`, which is the Solana on-chain reader):

```typescript
import { HermesClient } from "@pythnetwork/hermes-client";

const hermes = new HermesClient("https://pyth.dourolabs.app/hermes", {
  accessToken: process.env.PYTH_API_KEY,
});

const priceIds = [
  "0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43", // BTC/USD
  "0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace", // ETH/USD
];

const updates = await hermes.getLatestPriceUpdates(priceIds);
// updates.binary.data  → hex payloads for updatePriceFeeds on-chain
// updates.parsed       → [{ id, price: { price, conf, expo, publish_time }, ema_price, … }]
```

Interpreting a parsed price: the real value is `price × 10^expo`. A BTC/USD sample of
`price = "6140993501000"`, `expo = -8` reads as $61,409.94, with `conf` in the same scale
giving the one-sigma band. Full endpoint list: https://pyth.dourolabs.app/docs/

---

## 5. Consuming Prices On-Chain (EVM, Foundry)

Install the interface package (`forge install pyth-network/pyth-sdk-solidity` or the npm
mirror `@pythnetwork/pyth-sdk-solidity`) and follow the update-then-read pattern. The
contract below — shipped as `PythPriceConsumer.sol` — is the minimal correct consumer and
the base class for the DAIO components (Senatus voting-power valuation, DeadmansSwitch
crash detection, MUUTUM/ARRBY pricing legs):

```solidity
// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.20;

import "@pythnetwork/pyth-sdk-solidity/IPyth.sol";
import "@pythnetwork/pyth-sdk-solidity/PythStructs.sol";

contract PythPriceConsumer {
    IPyth public immutable pyth;
    uint256 public constant MAX_PRICE_AGE = 60;        // seconds
    uint256 public constant MAX_CONF_RATIO_BPS = 100;  // conf ≤ 1% of price

    error ConfidenceTooWide(uint256 confBps);

    constructor(address pythContract) { pyth = IPyth(pythContract); }

    /// Pull-model read: caller supplies Hermes update data and the fee.
    function getFreshPrice(bytes[] calldata updateData, bytes32 priceId)
        external payable returns (PythStructs.Price memory p)
    {
        uint256 fee = pyth.getUpdateFee(updateData);
        pyth.updatePriceFeeds{value: fee}(updateData);
        p = pyth.getPriceNoOlderThan(priceId, MAX_PRICE_AGE); // reverts if stale

        // Best practice: act on the confidence interval, don't ignore it.
        uint256 confBps = (uint256(p.conf) * 10_000) / uint256(uint64(p.price));
        if (confBps > MAX_CONF_RATIO_BPS) revert ConfidenceTooWide(confBps);
    }

    /// Normalise a Pyth price (price × 10^expo) to 18 decimals.
    function to18(PythStructs.Price memory p) public pure returns (uint256) {
        uint256 base = uint256(uint64(p.price));
        int32 e = p.expo; // typically -8
        return e >= 0
            ? base * 10 ** (18 + uint32(e))          // defensive; expo is normally negative
            : 18 >= uint32(-e)
                ? base * 10 ** (18 - uint32(-e))
                : base / 10 ** (uint32(-e) - 18);
    }
}
```

Points of doctrine, each traceable to the audit. Fees are mandatory: `getUpdateFee` then
forward exactly that value, refunding excess to callers in production paths. Staleness is
delegated to `getPriceNoOlderThan`, which reverts on old data — sixty seconds suits DeFi
legs, while governance snapshots (Senatus) can tolerate more and liquidation paths (FOUR
BUCKS CDP) should tolerate less. The confidence check protects against thin-market
manipulation: a 1% band on BTC is alarm-worthy; the same band on a long-tail asset may be
routine, so tune per feed. And under the cypherpunk2048 standard the Pyth address and limits
are `immutable`/`constant` — no admin keys, no post-deploy mutation.

**Testing without forking.** The SDK ships `MockPyth`, whose
`createPriceFeedUpdateData(...)` fabricates valid update payloads, letting the whole
update-then-read cycle run deterministically in Foundry. The accompanying
`PythPriceConsumer.t.sol` covers the happy path, staleness reverts, fee handling, wide
confidence, and exponent normalisation, and it is what `forge test` runs by default; a
separate `--match-contract ForkIntegration` profile hits live mainnet contracts when an RPC
is exported. Deployment then follows the standard sequence — test with MockPyth, deploy
with `forge create … --constructor-args <upgraded-pyth-address> --verify` per chain from the
Section 2 table, register each deployment in the ALLCHAIN registry.

**Keeping prices fresh.** Because nothing updates itself, choose one of the documented
scheduling options (https://docs.pyth.network/price-feeds/core/schedule-price-updates): let
each user transaction carry its own update data (simplest, fits ARRBY's transaction-bundled
arbitrage), run a keeper, or use Pyth's scheduler service where available.

---

## 6. The Algorand Reality and the x402 Rail

There is no Pyth contract on Algorand, and a definitive guide says so plainly. For the
PARSEC x402 payment system this turns out to be no loss, because an x402 gateway is already
the trusted party for its own quotes. The correct design, implemented in `x402_pricing.py`:

The gateway quotes in fiat terms (a mindX `query-mind` call costs five US cents), fetches
ALGO/USD from Hermes at quote time, converts to microALGO, and embeds amount, receiver,
nonce, and a short expiry in the HTTP 402 offer it signs. The client pays on Algorand with
the nonce in the transaction note field. Verification is the payment itself: the gateway
confirms via the Algorand Indexer that a transaction with that note paid at least the quoted
amount to the receiver within the validity window. No oracle attestation is needed on-chain
because the chain is only settling a quote the gateway itself issued — the earlier design's
HMAC "proof" signed by the gateway's own secret was circular and has been removed.

Should an *on-chain* Algorand consumer of Pyth prices ever become genuinely necessary (for
example, BONAFIDE contracts pricing bond amounts in USD), the only available pattern today
is a self-operated relayer posting Hermes prices into a custom Algopy application. That is a
trusted-relayer design, not a Pyth deployment; it must be labelled as such in the contract
docstring and the DAIO risk register, and the relayer key belongs in the DeadmansSwitch
scope.

---

## 7. Best Practices Checklist

Drawn from https://docs.pyth.network/price-feeds/core/best-practices and the audit, in
priority order. Always use the pull pattern — update, then read with `getPriceNoOlderThan`.
Always pay and forward the exact update fee. Always evaluate the confidence interval and
define per-feed rejection thresholds; prefer the EMA price where smoothing beats latency
(collateral valuation) and the spot price where latency beats smoothing (liquidations,
ARRBY). Verify every feed ID against insights.pyth.network before hard-coding, and confirm
the channel (Stable vs Beta). Pin the upgraded contract addresses for new EVM work; obtain
the API key before July 31, 2026. Respect Hermes rate limits
(https://docs.pyth.network/price-feeds/core/rate-limits) and cache parsed prices briefly
(the x402 gateway uses a five-second TTL). Test against MockPyth, not forks, in CI. Handle
the documented error codes (https://docs.pyth.network/price-feeds/core/error-codes) —
`PriceFeedNotFound` on a fresh chain means no one has ever pushed that feed there, which is
expected under the pull model. Finally, remember market hours: equities and FX feeds close;
crypto feeds do not (https://docs.pyth.network/price-feeds/core/market-hours) — relevant the
moment FOUR BUCKS touches USD/CAD.

---

## 8. Verified Reference Index

| Resource | URL |
|---|---|
| Developer Hub root | https://docs.pyth.network/ |
| Getting started | https://docs.pyth.network/price-feeds/core/getting-started |
| Pull oracle explainer | https://docs.pyth.network/price-feeds/core/pull-updates |
| Fetch price updates (REST/SSE/SDK) | https://docs.pyth.network/price-feeds/core/fetch-price-updates |
| EVM contract addresses | https://docs.pyth.network/price-feeds/core/contract-addresses/evm |
| Upgraded contract addresses | https://docs.pyth.network/price-feeds/core/upgrade/contracts |
| Upgrade preparation (API keys) | https://docs.pyth.network/price-feeds/core/upgrade/preparing |
| Price feed catalogue | https://insights.pyth.network/price-feeds |
| Feed ID reference | https://docs.pyth.network/price-feeds/core/price-feeds |
| Best practices | https://docs.pyth.network/price-feeds/core/best-practices |
| Cross-rate derivation | https://docs.pyth.network/price-feeds/core/derive-cross-rate |
| Schedule price updates | https://docs.pyth.network/price-feeds/core/schedule-price-updates |
| Hermes API reference | https://pyth.dourolabs.app/docs/ |
| pyth-crosschain monorepo | https://github.com/pyth-network/pyth-crosschain |
| Solidity SDK (incl. MockPyth) | https://github.com/pyth-network/pyth-sdk-solidity |
| Hermes JS client | https://github.com/pyth-network/pyth-crosschain/tree/main/apps/hermes/client/js |
| Example applications | https://github.com/pyth-network/pyth-examples/tree/main/price_feeds |
| PARSEC x402-avm | https://github.com/goplausible/x402-avm |

Every URL above was resolved during the 2026-07-08 audit. Where this guide and the live
documentation ever disagree, the live documentation wins — and the discrepancy should be
logged to rage.pythai.net.
