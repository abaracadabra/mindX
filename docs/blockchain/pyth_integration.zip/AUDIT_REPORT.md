# AUDIT REPORT — PYTHAI Pyth Integration Package v1.0.0

**Audit date:** 2026-07-08
**Method:** Every factual claim in v1.0.0 was checked against the live Pyth Developer Hub
(docs.pyth.network), the Hermes API reference, and the pyth-crosschain repository.
**Result:** v1.0.0 contained material errors. Version 2.0.0 (this package) corrects all of them.

---

## Findings

### CRITICAL-1 — Wrong / truncated contract addresses

v1.0.0 used `0xff1a0f4744e8582DF1aEe3650042bEA33c77e0FA4c9c0C5000` for Ethereum, Arbitrum,
Polygon and 0G. That string is 50 hex chars (invalid — addresses are 40) and is wrong for
Ethereum in any case. Verified current mainnet addresses:

| Network | Current address | Upgraded address (recommended for new integrations) |
|---|---|---|
| Ethereum Mainnet | `0x4305FB66699C3B2702D4d05CF36551390A4c69C6` | `0x14b9932cc9AC8Ee03301665a8644A753f46D8552` |
| Arbitrum One | `0xff1a0f4744e8582DF1aE09D5611b887B6a12925C` | `0xe15357fB7ab31E091583b9c4b4135BB2f176f38e` |
| OP Mainnet | `0xff1a0f4744e8582DF1aE09D5611b887B6a12925C` | `0xa78951b6bADC9F4740f6f456E9144705D5C5E4B2` |
| Base | `0x8250f4aF4B972684F7b336503E2D6dFeDeB1487a` | `0xbC16aee60f64864882BC6C4E428e148Fc0E272F5` |
| Polygon Mainnet | `0xff1a0f4744e8582DF1aE09D5611b887B6a12925C` | — (not in upgrade set) |
| 0G Mainnet | `0x2880aB155794e7179c9eE2e38200202908C17B43` | — (not in upgrade set) |

Source: https://docs.pyth.network/price-feeds/core/contract-addresses/evm

### CRITICAL-2 — Missed the Pyth Core upgrade (July 31, 2026 — 23 days from now)

The Pyth DAO upgrades Pyth Core on **July 31, 2026**. Consequences a July-2026 guide cannot
omit:

- **Every Hermes consumer will need an API key.** The unauthenticated
  `https://hermes.pyth.network` access model ends; the upgraded endpoint is
  `https://pyth.dourolabs.app/hermes` with `Authorization: Bearer $PYTH_API_KEY`.
- **New integrations should target the upgraded contract addresses** (table above). Existing
  integrations on upgrade-listed chains are migrated automatically by the DAO.
- Chains **not** in the upgrade list (including Polygon PoS and 0G) keep their current
  addresses.

Source: https://docs.pyth.network/price-feeds/core/upgrade/preparing

### CRITICAL-3 — Pull-oracle model was misused

v1.0.0's `PythConsumer` read prices with `getPriceUnsafe` and never called
`updatePriceFeeds`. Pyth is a **pull oracle**: nobody pushes prices to the contract for you.
The canonical flow is fetch update from Hermes → `pyth.getUpdateFee(updateData)` →
`pyth.updatePriceFeeds{value: fee}(updateData)` → `pyth.getPriceNoOlderThan(id, maxAge)`.
A contract that only calls `getPriceUnsafe` will read whatever stale price the last unrelated
caller happened to push — or revert if the feed was never pushed on that chain. Every
Solidity example in v2.0.0 uses the correct update-then-read pattern, and staleness is
enforced with `getPriceNoOlderThan` rather than hand-rolled timestamp checks.

### CRITICAL-4 — Fabricated Algorand deployment

v1.0.0 claimed a "Pyth Consumer App #888" on Algorand mainnet. **Pyth has no official
deployment on Algorand.** The supported target chains are EVM, Solana/SVM, Aptos, Sui, IOTA,
Movement, TON, Fuel, CosmWasm, NEAR, Starknet, and Pythnet — the AVM is not among them
(source: the Contract Addresses index at docs.pyth.network). The honest architecture for the
PARSEC x402 rail on Algorand is therefore:

1. **Off-chain pricing (recommended, what v2.0.0 implements):** the x402 gateway quotes
   service costs from Hermes directly. Payment amounts are computed server-side, signed into
   the 402 offer, and verified against the payment transaction. No on-chain oracle needed —
   the gateway is already the trusted party for the quote.
2. **Self-relayed on-chain prices (optional, trust-shifted):** run your own relayer that
   posts Hermes prices into a custom Algopy application. This is a *trusted-relayer* design,
   not a Pyth deployment, and must be documented as such. v2.0.0 includes the Algopy skeleton
   with this caveat stated in the contract docstring.

### HIGH-1 — Wrong Hermes API and wrong SDK class

v1.0.0 called `GET /api/latest_price_feeds` and used a `PythHttpClient` from
`@pythnetwork/client`. Corrections:

- REST: `GET /v2/updates/price/latest?ids[]=0x...&ids[]=0x...` (returns `binary.data` hex for
  on-chain submission and `parsed[]` for direct reads).
- Streaming: `GET /v2/updates/price/stream` (SSE; connections auto-close after 24 h —
  implement reconnection).
- TypeScript SDK: **`HermesClient`** from **`@pythnetwork/hermes-client`**
  (`@pythnetwork/client` is the Solana-specific package and does not talk to Hermes).

### HIGH-2 — Unverifiable feed IDs presented as fact

Verified against Pyth docs (Stable channel):

- BTC/USD `0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43` ✅
- ETH/USD `0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace` ✅

The ALGO/USD and "USD/USD" IDs in v1.0.0 could not be verified against official sources
during this audit ("Currencies.USD/USD" almost certainly does not exist as a feed — USD is
the quote currency, not an asset). v2.0.0 marks unverified IDs as **LOOK UP BEFORE USE** and
points to the canonical catalogue: https://insights.pyth.network/price-feeds and
https://docs.pyth.network/price-feeds/core/price-feeds. For stablecoin work (PAI), the
correct feed is USDC/USD or USDT/USD, not "USD/USD".

### MEDIUM-1 — Foundry tests forked mainnet instead of using MockPyth

v1.0.0 tests forked live RPCs, making them flaky and unable to exercise the update path.
The pyth-sdk-solidity package ships `MockPyth` with `createPriceFeedUpdateData(...)`
precisely for deterministic Foundry tests. v2.0.0's suite uses it, and reserves fork tests
for a separate, explicitly-labelled integration profile.

### MEDIUM-2 — Update frequency overstated

v1.0.0 said "prices update every 300 ms". Pyth's public materials state ~400 ms aggregate
cadence on Pythnet; what matters on EVM is that **prices are only as fresh as your last
`updatePriceFeeds` call**. v2.0.0 phrases freshness in terms of the pull model and
`getPriceNoOlderThan` age bounds.

### MEDIUM-3 — Confidence intervals fetched but never used

Best practice (docs: Best Practices page) is to act on `conf`, e.g. reject or widen spreads
when `conf/price` exceeds a threshold, and to use EMA price for smoothing. v2.0.0's consumer
enforces a configurable max confidence ratio.

### LOW-1 — Cosmetic/consistency issues

Non-existent npm packages (`@pythnetwork/contract-toolkit`, `@pythnetwork/solana` as named),
a `github.com/codephreak/openBDK` URL presented as live (private/unpublished), emoji-heavy
docs inconsistent with the flowing-prose standard for rage.pythai.net publication, and the
v1 x402 "proof" being HMAC-signed by the *gateway's own secret* (circular — v2.0.0 verifies
the Algorand payment transaction itself via the Indexer, which is the actual proof).

---

## Disposition

All nine findings are corrected in the v2.0.0 files accompanying this report:

- `PYTH_DEFINITIVE_GUIDE.md` — rewritten guide, prose format, every address and endpoint
  verified against docs.pyth.network as of 2026-07-08.
- `PythPriceConsumer.sol` + `PythPriceConsumer.t.sol` — pull-model consumer with MockPyth
  tests.
- `hermes_client.ts` — HermesClient (v2 API, API-key ready).
- `x402_pricing.py` — Hermes v2 off-chain pricing for the PARSEC x402 rail, with real
  Algorand Indexer payment verification.

Professor Codephreak — cypherpunk2048 standard: better a correct page than a flattering one.
