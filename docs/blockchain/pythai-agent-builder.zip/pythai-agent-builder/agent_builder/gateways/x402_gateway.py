"""gateways/x402_gateway.py — concrete x402 settlement gateway.

Implements the AgentBuilder X402GatewayPort against the GoPlausible
`algorand-remote-mcp-lite` + `x402-avm` substrate ("Parsec"). Provides the
HTTP 402 triple rail — Base USDC, Algorand ASA via Parsec, Tempo MPP — and
the deterministic PYTHAI treasury tithe split applied at settlement.

This sits at a service boundary mindX operates. The tithe is collected here,
not inside forkable agent code, which is what makes payment-back enforceable
rather than advisory.

Apache-2.0. snake_case. Python >= 3.12.

Notes
-----
- Amounts are computed with Decimal and quantized to the rail's smallest unit
  (USDC: 6dp; ALGO ASA: configurable; MPP: 6dp) before settlement.
- The facilitator/relayer call is abstracted behind FacilitatorClient so the
  same gateway works against Coinbase's Base facilitator, a Parsec Algorand
  facilitator, or a local dev facilitator without changing settlement logic.
- No private keys live here. Signing is delegated to the BANKON Vault via the
  SignerPort, so a node without vault access cannot settle.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from decimal import ROUND_DOWN, Decimal
from enum import Enum
from typing import Any, Protocol


class Rail(str, Enum):
    BASE_USDC = "base_usdc"
    ALGORAND_ASA = "algorand_asa_via_parsec"
    TEMPO_MPP = "tempo_mpp"


# smallest-unit precision per rail
_RAIL_DECIMALS: dict[Rail, int] = {
    Rail.BASE_USDC: 6,
    Rail.ALGORAND_ASA: 6,
    Rail.TEMPO_MPP: 6,
}


class SignerPort(Protocol):
    """Delegates payment authorization to the BANKON Vault. No key material here."""

    def sign_payment(self, rail: str, payload: dict[str, Any]) -> str:
        """Return a signature/authorization token for the payment payload."""
        ...


class FacilitatorClient(Protocol):
    """Abstracts the rail-specific facilitator/relayer that broadcasts settlement."""

    def settle(self, rail: str, payload: dict[str, Any], signature: str) -> dict[str, Any]:
        """Broadcast settlement; return {tx_hash, status, ...}."""
        ...


@dataclass(frozen=True)
class EndpointPricing:
    agent_id: str
    price_input_per_token: Decimal
    price_output_per_token: Decimal
    treasury_tithe: Decimal
    treasury_address: str
    rail: Rail


@dataclass
class Receipt:
    receipt_id: str
    endpoint_url: str
    rail: str
    base_amount: Decimal
    treasury_tithe_amount: Decimal
    provider_amount: Decimal
    total_amount: Decimal
    treasury_address: str
    tx_hash: str | None
    status: str
    timestamp: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        return {
            "receipt_id": self.receipt_id,
            "endpoint": self.endpoint_url,
            "rail": self.rail,
            "base_amount": str(self.base_amount),
            "treasury_tithe_amount": str(self.treasury_tithe_amount),
            "provider_amount": str(self.provider_amount),
            "total_amount": str(self.total_amount),
            "treasury_address": self.treasury_address,
            "tx_hash": self.tx_hash,
            "status": self.status,
            "timestamp": self.timestamp,
        }


class X402Gateway:
    """Triple-rail x402 settlement with the PYTHAI treasury tithe.

    Satisfies AgentBuilder.X402GatewayPort (bind_endpoint + settle).
    """

    def __init__(
        self,
        signer: SignerPort,
        facilitator: FacilitatorClient,
        base_url: str = "https://x402.agenticplace.pythai.net",
        default_rail: Rail = Rail.ALGORAND_ASA,
    ) -> None:
        self._signer = signer
        self._facilitator = facilitator
        self._base_url = base_url.rstrip("/")
        self._default_rail = default_rail
        self._endpoints: dict[str, EndpointPricing] = {}

    # --- port: bind_endpoint -------------------------------------------

    def bind_endpoint(
        self,
        agent_id: str,
        price_input_per_token: Decimal,
        price_output_per_token: Decimal,
        treasury_tithe: Decimal,
        treasury_address: str,
        rail: Rail | None = None,
    ) -> str:
        if not (Decimal(0) <= treasury_tithe < Decimal(1)):
            raise ValueError("treasury_tithe must be in [0, 1)")
        url = f"{self._base_url}/{agent_id}"
        self._endpoints[url] = EndpointPricing(
            agent_id=agent_id,
            price_input_per_token=price_input_per_token,
            price_output_per_token=price_output_per_token,
            treasury_tithe=treasury_tithe,
            treasury_address=treasury_address,
            rail=rail or self._default_rail,
        )
        return url

    # --- port: settle ---------------------------------------------------

    def settle(self, endpoint_url: str, usage_input: int, usage_output: int) -> dict[str, Any]:
        pricing = self._endpoints.get(endpoint_url)
        if pricing is None:
            raise KeyError(f"no bound endpoint: {endpoint_url}")

        base = (
            Decimal(usage_input) * pricing.price_input_per_token
            + Decimal(usage_output) * pricing.price_output_per_token
        )
        tithe = (base * pricing.treasury_tithe)
        total = base + tithe

        q = _quantum(pricing.rail)
        base = base.quantize(q, rounding=ROUND_DOWN)
        tithe = tithe.quantize(q, rounding=ROUND_DOWN)
        total = total.quantize(q, rounding=ROUND_DOWN)
        provider_amount = (total - tithe).quantize(q, rounding=ROUND_DOWN)

        payload = {
            "agent_id": pricing.agent_id,
            "rail": pricing.rail.value,
            "splits": [
                {"to": pricing.treasury_address, "amount": str(tithe), "role": "pythai_treasury"},
                {"to": pricing.agent_id, "amount": str(provider_amount), "role": "agent_provider"},
            ],
            "total": str(total),
            "usage": {"input_tokens": usage_input, "output_tokens": usage_output},
        }

        signature = self._signer.sign_payment(pricing.rail.value, payload)
        result = self._facilitator.settle(pricing.rail.value, payload, signature)

        receipt = Receipt(
            receipt_id=str(uuid.uuid4()),
            endpoint_url=endpoint_url,
            rail=pricing.rail.value,
            base_amount=base,
            treasury_tithe_amount=tithe,
            provider_amount=provider_amount,
            total_amount=total,
            treasury_address=pricing.treasury_address,
            tx_hash=result.get("tx_hash"),
            status=result.get("status", "settled"),
        )
        return receipt.as_dict()

    # --- HTTP 402 challenge helper -------------------------------------

    def payment_required(self, endpoint_url: str, est_input: int, est_output: int) -> dict[str, Any]:
        """Produce an HTTP 402 'Payment Required' body for the wire protocol."""
        pricing = self._endpoints[endpoint_url]
        est = (
            Decimal(est_input) * pricing.price_input_per_token
            + Decimal(est_output) * pricing.price_output_per_token
        )
        est_total = (est * (Decimal(1) + pricing.treasury_tithe)).quantize(
            _quantum(pricing.rail), rounding=ROUND_DOWN
        )
        return {
            "x402Version": 2,
            "accepts": [
                {
                    "scheme": "exact",
                    "network": pricing.rail.value,
                    "maxAmountRequired": str(est_total),
                    "payTo": pricing.agent_id,
                    "resource": endpoint_url,
                }
            ],
        }


def _quantum(rail: Rail) -> Decimal:
    return Decimal(1).scaleb(-_RAIL_DECIMALS[rail])
