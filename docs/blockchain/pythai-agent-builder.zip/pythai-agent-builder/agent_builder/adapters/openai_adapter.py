"""adapters/openai_adapter.py — OpenAI / GPT integration.

Native protocol: ACP (OpenAI + Stripe Agentic Commerce Protocol). When cross-
registered into AgenticPlace, the agent's native ACP checkout is bridged to the
neutral x402 rail so cross-vendor settlement does not route through Stripe.

Wire format: OpenAI Chat Completions API. Credentials from BANKON Vault.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import httpx

from agent_builder.provider_adapter import (
    CompletionRequest,
    CompletionResponse,
    ModelSpec,
    ProviderAdapter,
    ProviderProtocol,
    ToolCall,
    UsageRecord,
)

_BASE = "https://api.openai.com/v1/chat/completions"

OPENAI_MODELS: dict[str, ModelSpec] = {
    "gpt-5.5": ModelSpec(
        provider="openai",
        model_id="gpt-5.5",
        context_window=400_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.ACP,
        usd_per_mtok_input=Decimal("2.50"),
        usd_per_mtok_output=Decimal("10.00"),
    ),
    "gpt-5.5-mini": ModelSpec(
        provider="openai",
        model_id="gpt-5.5-mini",
        context_window=200_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.ACP,
        usd_per_mtok_input=Decimal("0.40"),
        usd_per_mtok_output=Decimal("1.60"),
    ),
}


class OpenAIAdapter(ProviderAdapter):
    provider_name = "openai"
    native_protocol = ProviderProtocol.ACP

    async def complete(self, request: CompletionRequest, model: ModelSpec) -> CompletionResponse:
        key = self._api_key()
        body: dict[str, Any] = {
            "model": model.model_id,
            "messages": request.messages,
            "max_completion_tokens": request.max_tokens,
            "temperature": request.temperature,
        }
        if request.tools:
            body["tools"] = [{"type": "function", "function": t} for t in request.tools]

        headers = {"authorization": f"Bearer {key}", "content-type": "application/json"}
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(_BASE, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        return self._from_openai(data, model)

    def agent_card_skills(self, model: ModelSpec) -> list[dict[str, Any]]:
        return [
            {
                "id": f"openai.{model.model_id}.reason",
                "name": "GPT reasoning + function calling",
                "description": "General reasoning, computer-use, and function calling via GPT.",
                "tags": ["reasoning", "function-calling", "computer-use", "acp-native"],
            }
        ]

    def price_per_token(self, model: ModelSpec) -> tuple[Decimal, Decimal]:
        million = Decimal(1_000_000)
        return (model.usd_per_mtok_input / million, model.usd_per_mtok_output / million)

    async def health(self) -> bool:
        try:
            key = self._api_key()
            headers = {"authorization": f"Bearer {key}"}
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get("https://api.openai.com/v1/models", headers=headers)
                return resp.status_code == 200
        except Exception:
            return False

    @staticmethod
    def _from_openai(data: dict[str, Any], model: ModelSpec) -> CompletionResponse:
        choice = (data.get("choices") or [{}])[0]
        msg = choice.get("message", {})
        text = msg.get("content") or ""
        tool_calls: list[ToolCall] = []
        for tc in msg.get("tool_calls", []) or []:
            fn = tc.get("function", {})
            import json

            try:
                args = json.loads(fn.get("arguments", "{}"))
            except json.JSONDecodeError:
                args = {"_raw": fn.get("arguments", "")}
            tool_calls.append(ToolCall(name=fn.get("name", ""), arguments=args, call_id=tc.get("id")))
        u = data.get("usage", {})
        usage = UsageRecord(
            input_tokens=u.get("prompt_tokens", 0),
            output_tokens=u.get("completion_tokens", 0),
        )
        return CompletionResponse(
            text=text, tool_calls=tool_calls, usage=usage, model_id=model.model_id, raw=data
        )
