"""adapters/gemini_adapter.py — Google / Gemini integration.

Native protocol: A2A (Google authored Agent2Agent). Payments orchestrated via
AP2, which settles crypto through x402 — the same rail mindX uses, so a Gemini
agent cross-registered into AgenticPlace can be paid on the neutral rail.

Wire format: Gemini generateContent REST API. Credentials from BANKON Vault.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import httpx

from agent_builder.provider_adapter import (
    CompletionRequest,
    CompletionResponse,
    ModelSpec,
    ProviderAdapter,
    ProviderProtocol,
    ToolCall,
    UsageRecord,
)

_BASE = "https://generativelanguage.googleapis.com/v1beta"

GEMINI_MODELS: dict[str, ModelSpec] = {
    "gemini-3-pro": ModelSpec(
        provider="google",
        model_id="gemini-3-pro",
        context_window=2_000_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.A2A,
        usd_per_mtok_input=Decimal("1.25"),
        usd_per_mtok_output=Decimal("10.00"),
    ),
    "gemini-2.5-flash": ModelSpec(
        provider="google",
        model_id="gemini-2.5-flash",
        context_window=1_000_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.A2A,
        usd_per_mtok_input=Decimal("0.30"),
        usd_per_mtok_output=Decimal("2.50"),
    ),
}


class GeminiAdapter(ProviderAdapter):
    provider_name = "google"
    native_protocol = ProviderProtocol.A2A

    async def complete(self, request: CompletionRequest, model: ModelSpec) -> CompletionResponse:
        key = self._api_key()
        contents = self._to_gemini_contents(request.messages)
        body: dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": request.max_tokens,
                "temperature": request.temperature,
            },
        }
        if request.tools:
            body["tools"] = [{"functionDeclarations": request.tools}]

        url = f"{_BASE}/models/{model.model_id}:generateContent?key={key}"
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(url, json=body)
            resp.raise_for_status()
            data = resp.json()

        return self._from_gemini(data, model)

    def agent_card_skills(self, model: ModelSpec) -> list[dict[str, Any]]:
        return [
            {
                "id": f"google.{model.model_id}.reason",
                "name": "Gemini reasoning + long-context analysis",
                "description": (
                    "Multimodal reasoning and synthesis over up to "
                    f"{model.context_window:,} tokens via Gemini."
                ),
                "tags": ["reasoning", "long-context", "multimodal", "a2a-native"],
            }
        ]

    def price_per_token(self, model: ModelSpec) -> tuple[Decimal, Decimal]:
        million = Decimal(1_000_000)
        return (model.usd_per_mtok_input / million, model.usd_per_mtok_output / million)

    async def health(self) -> bool:
        try:
            key = self._api_key()
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(f"{_BASE}/models?key={key}")
                return resp.status_code == 200
        except Exception:
            return False

    # --- translation helpers -------------------------------------------

    @staticmethod
    def _to_gemini_contents(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        role_map = {"user": "user", "assistant": "model", "system": "user"}
        return [
            {"role": role_map.get(m["role"], "user"), "parts": [{"text": m["content"]}]}
            for m in messages
        ]

    @staticmethod
    def _from_gemini(data: dict[str, Any], model: ModelSpec) -> CompletionResponse:
        candidates = data.get("candidates", [])
        text = ""
        tool_calls: list[ToolCall] = []
        if candidates:
            for part in candidates[0].get("content", {}).get("parts", []):
                if "text" in part:
                    text += part["text"]
                if "functionCall" in part:
                    fc = part["functionCall"]
                    tool_calls.append(ToolCall(name=fc["name"], arguments=fc.get("args", {})))
        meta = data.get("usageMetadata", {})
        usage = UsageRecord(
            input_tokens=meta.get("promptTokenCount", 0),
            output_tokens=meta.get("candidatesTokenCount", 0),
        )
        return CompletionResponse(
            text=text, tool_calls=tool_calls, usage=usage, model_id=model.model_id, raw=data
        )
