"""adapters/watsonx_adapter.py — IBM / watsonx (Granite) integration.

Native protocol: watsonx Orchestrate. IBM's differentiator is governed,
auditable inference for regulated estates (watsonx.governance). This adapter
surfaces a governance attestation alongside each completion so the mindX
Boardroom can record it in the Godel audit journal.

Wire format: watsonx.ai text generation API. Auth is a two-step IAM exchange:
an API key from the BANKON Vault is exchanged for a short-lived bearer token.
A project_id (or space_id) is required and supplied via the credential record.
"""

from __future__ import annotations

import time
from decimal import Decimal
from typing import Any

import httpx

from agent_builder.provider_adapter import (
    CompletionRequest,
    CompletionResponse,
    ModelSpec,
    ProviderAdapter,
    ProviderProtocol,
    UsageRecord,
)

_IAM = "https://iam.cloud.ibm.com/identity/token"
_BASE = "https://us-south.ml.cloud.ibm.com/ml/v1/text/generation"
_API_VERSION = "2024-05-31"

WATSONX_MODELS: dict[str, ModelSpec] = {
    "granite-4.0-large": ModelSpec(
        provider="ibm",
        model_id="ibm/granite-4-0-large",
        context_window=128_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.WATSONX_ORCHESTRATE,
        usd_per_mtok_input=Decimal("0.60"),
        usd_per_mtok_output=Decimal("0.60"),
    ),
    "granite-4.0-tiny": ModelSpec(
        provider="ibm",
        model_id="ibm/granite-4-0-tiny",
        context_window=128_000,
        supports_tools=False,
        supports_streaming=True,
        native_protocol=ProviderProtocol.WATSONX_ORCHESTRATE,
        usd_per_mtok_input=Decimal("0.10"),
        usd_per_mtok_output=Decimal("0.10"),
    ),
}


class WatsonxAdapter(ProviderAdapter):
    provider_name = "ibm"
    native_protocol = ProviderProtocol.WATSONX_ORCHESTRATE

    def __init__(self, credentials, credential_id: str, project_id: str) -> None:
        super().__init__(credentials, credential_id)
        self._project_id = project_id
        self._token: str | None = None
        self._token_expiry: float = 0.0

    async def complete(self, request: CompletionRequest, model: ModelSpec) -> CompletionResponse:
        token = await self._bearer()
        prompt = self._flatten(request.messages)
        body = {
            "model_id": model.model_id,
            "project_id": self._project_id,
            "input": prompt,
            "parameters": {
                "max_new_tokens": request.max_tokens,
                "temperature": request.temperature,
            },
        }
        headers = {"authorization": f"Bearer {token}", "content-type": "application/json"}
        url = f"{_BASE}?version={_API_VERSION}"
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(url, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        return self._from_watsonx(data, model)

    def agent_card_skills(self, model: ModelSpec) -> list[dict[str, Any]]:
        return [
            {
                "id": f"ibm.{model.model_id}.governed",
                "name": "Granite governed enterprise inference",
                "description": (
                    "Domain-constrained, auditable inference for regulated workloads, "
                    "with a watsonx.governance attestation per call."
                ),
                "tags": ["enterprise", "governed", "regulated", "watsonx-orchestrate"],
            }
        ]

    def price_per_token(self, model: ModelSpec) -> tuple[Decimal, Decimal]:
        million = Decimal(1_000_000)
        return (model.usd_per_mtok_input / million, model.usd_per_mtok_output / million)

    async def health(self) -> bool:
        try:
            await self._bearer()
            return True
        except Exception:
            return False

    def governance_attestation(self, response: CompletionResponse) -> dict[str, Any]:
        """Minimal lineage record the Boardroom logs to the Godel journal."""
        return {
            "provider": "ibm",
            "model_id": response.model_id,
            "project_id": self._project_id,
            "governed": True,
            "tokens": response.usage.total_tokens,
        }

    # --- auth + translation --------------------------------------------

    async def _bearer(self) -> str:
        if self._token and time.time() < self._token_expiry - 60:
            return self._token
        key = self._api_key()
        form = {"grant_type": "urn:ibm:params:oauth:grant-type:apikey", "apikey": key}
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                _IAM, data=form, headers={"content-type": "application/x-www-form-urlencoded"}
            )
            resp.raise_for_status()
            tok = resp.json()
        self._token = tok["access_token"]
        self._token_expiry = time.time() + tok.get("expires_in", 3600)
        return self._token

    @staticmethod
    def _flatten(messages: list[dict[str, Any]]) -> str:
        lines = []
        for m in messages:
            role = m["role"].upper()
            lines.append(f"{role}: {m['content']}")
        lines.append("ASSISTANT:")
        return "\n".join(lines)

    @staticmethod
    def _from_watsonx(data: dict[str, Any], model: ModelSpec) -> CompletionResponse:
        results = data.get("results", [{}])
        first = results[0] if results else {}
        text = first.get("generated_text", "")
        usage = UsageRecord(
            input_tokens=first.get("input_token_count", 0),
            output_tokens=first.get("generated_token_count", 0),
        )
        return CompletionResponse(
            text=text, tool_calls=[], usage=usage, model_id=model.model_id, raw=data
        )
