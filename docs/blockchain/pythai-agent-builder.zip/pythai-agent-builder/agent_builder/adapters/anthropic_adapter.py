"""adapters/anthropic_adapter.py — Anthropic / Claude integration.

Native protocol: MCP (Anthropic authored the Model Context Protocol, now under
the Linux Foundation's Agentic AI Foundation). A Claude agent built here exposes
its tool surface as MCP, which mindX consumes directly.

Wire format: Anthropic Messages API (/v1/messages). Credentials from BANKON Vault.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import httpx

from agent_builder.provider_adapter import (
    CompletionRequest,
    CompletionResponse,
    ModelSpec,
    ProviderAdapter,
    ProviderProtocol,
    ToolCall,
    UsageRecord,
)

_BASE = "https://api.anthropic.com/v1/messages"
_VERSION = "2023-06-01"

ANTHROPIC_MODELS: dict[str, ModelSpec] = {
    "claude-opus-4-8": ModelSpec(
        provider="anthropic",
        model_id="claude-opus-4-8",
        context_window=200_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.MCP,
        usd_per_mtok_input=Decimal("5.00"),
        usd_per_mtok_output=Decimal("25.00"),
    ),
    "claude-sonnet-4-6": ModelSpec(
        provider="anthropic",
        model_id="claude-sonnet-4-6",
        context_window=200_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.MCP,
        usd_per_mtok_input=Decimal("3.00"),
        usd_per_mtok_output=Decimal("15.00"),
    ),
}


class AnthropicAdapter(ProviderAdapter):
    provider_name = "anthropic"
    native_protocol = ProviderProtocol.MCP

    async def complete(self, request: CompletionRequest, model: ModelSpec) -> CompletionResponse:
        key = self._api_key()
        system, msgs = self._split_system(request.messages)
        body: dict[str, Any] = {
            "model": model.model_id,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "messages": msgs,
        }
        if system:
            body["system"] = system
        if request.tools:
            # Anthropic tool schema: name, description, input_schema
            body["tools"] = request.tools

        headers = {
            "x-api-key": key,
            "anthropic-version": _VERSION,
            "content-type": "application/json",
        }
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(_BASE, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        return self._from_anthropic(data, model)

    def agent_card_skills(self, model: ModelSpec) -> list[dict[str, Any]]:
        return [
            {
                "id": f"anthropic.{model.model_id}.reason",
                "name": "Claude reasoning, coding, and tool-use",
                "description": (
                    "Agentic coding, careful reasoning, and MCP-native tool use via Claude."
                ),
                "tags": ["reasoning", "coding", "agentic", "mcp-native"],
            }
        ]

    def price_per_token(self, model: ModelSpec) -> tuple[Decimal, Decimal]:
        million = Decimal(1_000_000)
        return (model.usd_per_mtok_input / million, model.usd_per_mtok_output / million)

    async def health(self) -> bool:
        try:
            key = self._api_key()
            headers = {"x-api-key": key, "anthropic-version": _VERSION}
            probe = {
                "model": "claude-sonnet-4-6",
                "max_tokens": 1,
                "messages": [{"role": "user", "content": "ping"}],
            }
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(_BASE, json=probe, headers=headers)
                return resp.status_code in (200, 429)
        except Exception:
            return False

    # --- translation helpers -------------------------------------------

    @staticmethod
    def _split_system(messages: list[dict[str, Any]]) -> tuple[str, list[dict[str, Any]]]:
        system = "\n".join(m["content"] for m in messages if m["role"] == "system")
        msgs = [
            {"role": m["role"], "content": m["content"]}
            for m in messages
            if m["role"] in ("user", "assistant")
        ]
        return system, msgs

    @staticmethod
    def _from_anthropic(data: dict[str, Any], model: ModelSpec) -> CompletionResponse:
        text = ""
        tool_calls: list[ToolCall] = []
        for block in data.get("content", []):
            if block.get("type") == "text":
                text += block.get("text", "")
            elif block.get("type") == "tool_use":
                tool_calls.append(
                    ToolCall(
                        name=block["name"],
                        arguments=block.get("input", {}),
                        call_id=block.get("id"),
                    )
                )
        u = data.get("usage", {})
        usage = UsageRecord(
            input_tokens=u.get("input_tokens", 0),
            output_tokens=u.get("output_tokens", 0),
        )
        return CompletionResponse(
            text=text, tool_calls=tool_calls, usage=usage, model_id=model.model_id, raw=data
        )
