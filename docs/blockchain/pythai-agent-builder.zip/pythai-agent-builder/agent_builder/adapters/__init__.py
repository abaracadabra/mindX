"""Provider integrations: one adapter per major model maker."""
