"""adapters/grok_adapter.py — xAI / Grok integration.

Native protocol: OpenAI-compatible API. xAI exposes an OpenAI-shaped surface,
so this adapter reuses that wire format against the xAI base URL. Grok's
differentiator is the real-time X data stream; the AgentCard advertises it.

Credentials from BANKON Vault.
"""

from __future__ import annotations

import json
from decimal import Decimal
from typing import Any

import httpx

from agent_builder.provider_adapter import (
    CompletionRequest,
    CompletionResponse,
    ModelSpec,
    ProviderAdapter,
    ProviderProtocol,
    ToolCall,
    UsageRecord,
)

_BASE = "https://api.x.ai/v1/chat/completions"

GROK_MODELS: dict[str, ModelSpec] = {
    "grok-5": ModelSpec(
        provider="xai",
        model_id="grok-5",
        context_window=256_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.OPENAI_COMPAT,
        usd_per_mtok_input=Decimal("3.00"),
        usd_per_mtok_output=Decimal("15.00"),
    ),
    "grok-4-fast": ModelSpec(
        provider="xai",
        model_id="grok-4-fast",
        context_window=128_000,
        supports_tools=True,
        supports_streaming=True,
        native_protocol=ProviderProtocol.OPENAI_COMPAT,
        usd_per_mtok_input=Decimal("0.50"),
        usd_per_mtok_output=Decimal("2.00"),
    ),
}


class GrokAdapter(ProviderAdapter):
    provider_name = "xai"
    native_protocol = ProviderProtocol.OPENAI_COMPAT

    async def complete(self, request: CompletionRequest, model: ModelSpec) -> CompletionResponse:
        key = self._api_key()
        body: dict[str, Any] = {
            "model": model.model_id,
            "messages": request.messages,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
        }
        if request.tools:
            body["tools"] = [{"type": "function", "function": t} for t in request.tools]
        # opt-in live X search when the caller asks for it
        if request.extra.get("live_search"):
            body["search_parameters"] = {"mode": "on", "sources": [{"type": "x"}]}

        headers = {"authorization": f"Bearer {key}", "content-type": "application/json"}
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(_BASE, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        return self._from_grok(data, model)

    def agent_card_skills(self, model: ModelSpec) -> list[dict[str, Any]]:
        return [
            {
                "id": f"xai.{model.model_id}.realtime",
                "name": "Grok reasoning + real-time X awareness",
                "description": (
                    "Reasoning with optional live access to the X real-time data stream."
                ),
                "tags": ["reasoning", "real-time", "social-signal", "openai-compat"],
            }
        ]

    def price_per_token(self, model: ModelSpec) -> tuple[Decimal, Decimal]:
        million = Decimal(1_000_000)
        return (model.usd_per_mtok_input / million, model.usd_per_mtok_output / million)

    async def health(self) -> bool:
        try:
            key = self._api_key()
            headers = {"authorization": f"Bearer {key}"}
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get("https://api.x.ai/v1/models", headers=headers)
                return resp.status_code == 200
        except Exception:
            return False

    @staticmethod
    def _from_grok(data: dict[str, Any], model: ModelSpec) -> CompletionResponse:
        choice = (data.get("choices") or [{}])[0]
        msg = choice.get("message", {})
        text = msg.get("content") or ""
        tool_calls: list[ToolCall] = []
        for tc in msg.get("tool_calls", []) or []:
            fn = tc.get("function", {})
            try:
                args = json.loads(fn.get("arguments", "{}"))
            except json.JSONDecodeError:
                args = {"_raw": fn.get("arguments", "")}
            tool_calls.append(ToolCall(name=fn.get("name", ""), arguments=args, call_id=tc.get("id")))
        u = data.get("usage", {})
        usage = UsageRecord(
            input_tokens=u.get("prompt_tokens", 0),
            output_tokens=u.get("completion_tokens", 0),
        )
        return CompletionResponse(
            text=text, tool_calls=tool_calls, usage=usage, model_id=model.model_id, raw=data
        )
