"""agent_builder.py — the unified, provider-agnostic agent factory.

This is the single entry point. Given a build spec naming a provider and model,
it produces a BuiltAgent fully wired into the mindX neutral layer:

  1. resolve credentials from the BANKON Vault (CredentialResolver),
  2. instantiate the correct ProviderAdapter via the registry,
  3. mint an ERC-8004 identity (IdentityRegistry on Ethereum mainnet),
  4. claim an ENS subname under bankon.eth,
  5. assemble an A2A AgentCard advertising the adapter's skills + native protocol,
  6. register the agent in AgenticPlace and mint an aORC verification NFT,
  7. bind an x402 payment endpoint that meters usage and tithes the PYTHAI treasury,
  8. expose the agent's tools over MCP,
  9. attach a BONA FIDE reputation hook (privilege earned, revocable via clawback).

The builder depends only on small Protocols (ports). Real implementations live
elsewhere in mindX (id_manager_agent, AgenticPlace client, x402 gateway, ENS
registrar). This keeps the builder testable and free of chain-client coupling.

Apache-2.0. snake_case. Python >= 3.12. No EOA admin keys retained post-mint.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Protocol

from agent_builder.provider_adapter import (
    CompletionRequest,
    CompletionResponse,
    CredentialResolver,
    ModelSpec,
    ProviderAdapter,
)
from agent_builder.registry import instantiate_adapter, resolve_model

# The PYTHAI treasury tithe applied on top of provider cost at the x402 boundary.
# This is collected at a service boundary mindX operates, NOT inside forkable
# agent code, which is what makes it enforceable rather than advisory.
DEFAULT_TREASURY_TITHE = Decimal("0.10")  # 10% routed to the DAIO treasury


# --------------------------------------------------------------------------
# Ports (implemented by real mindX subsystems; mocked in tests)
# --------------------------------------------------------------------------


class IdentityRegistryPort(Protocol):
    """ERC-8004 IdentityRegistry on Ethereum mainnet (0x8004A169...)."""

    def mint_identity(self, owner: str, agent_card_uri: str) -> str:
        """Mint an agent identity NFT; return the on-chain AgentID."""
        ...


class EnsRegistrarPort(Protocol):
    """Issues subnames under bankon.eth."""

    def claim_subname(self, label: str, resolves_to: str) -> str:
        """Claim `<label>.bankon.eth` -> resolves_to; return the full name."""
        ...


class AgenticPlacePort(Protocol):
    """AgenticPlace registry client (.extensions -> .json -> chain publish)."""

    def register(self, agent_card: dict[str, Any], agent_id: str) -> str:
        """Publish the agent and return its AgenticPlace listing id."""
        ...

    def mint_aorc(self, listing_id: str) -> str:
        """Mint an agenticORacle verification NFT (1 ALGO); return its id."""
        ...


class X402GatewayPort(Protocol):
    """Triple-rail x402 settlement (Base USDC / Algorand ASA via Parsec / Tempo MPP)."""

    def bind_endpoint(
        self,
        agent_id: str,
        price_input_per_token: Decimal,
        price_output_per_token: Decimal,
        treasury_tithe: Decimal,
        treasury_address: str,
    ) -> str:
        """Create a paid invocation endpoint; return its URL."""
        ...

    def settle(self, endpoint_url: str, usage_input: int, usage_output: int) -> dict[str, Any]:
        """Settle one invocation; return the receipt (incl. tithe split)."""
        ...


class McpSurfacePort(Protocol):
    """Registers the agent's tools as MCP so any MCP client can call them."""

    def register_tools(self, agent_id: str, tools: list[dict[str, Any]]) -> str:
        """Return the MCP server endpoint for this agent."""
        ...


class BonaFidePort(Protocol):
    """BONA FIDE reputation: privilege earned, revocable by clawback."""

    def initialize_reputation(self, agent_id: str, parent_agent_id: str | None) -> int:
        """Seed reputation (inherited fraction if minted from a parent)."""
        ...


# --------------------------------------------------------------------------
# Build spec + result
# --------------------------------------------------------------------------


@dataclass
class AgentBuildSpec:
    """Everything needed to build one agent."""

    label: str                       # ENS label, e.g. "claude-research"
    provider: str                    # "google" | "openai" | "anthropic" | "xai" | "ibm"
    model_id: str                    # e.g. "claude-opus-4-8"
    owner_address: str               # the human/agent that owns this identity
    persona: str = ""                # system prompt / persona for the agent
    credential_id: str | None = None  # vault id override
    parent_agent_id: str | None = None  # set when minted from a parent genome
    treasury_tithe: Decimal = DEFAULT_TREASURY_TITHE
    provider_kwargs: dict[str, Any] = field(default_factory=dict)  # e.g. project_id


@dataclass
class BuiltAgent:
    """A fully-wired sovereign agent, ready to transact on the neutral layer."""

    label: str
    provider: str
    model: ModelSpec
    adapter: ProviderAdapter
    agent_id: str
    ens_name: str
    agent_card: dict[str, Any]
    agenticplace_listing_id: str
    aorc_id: str
    x402_endpoint: str
    mcp_endpoint: str
    reputation: int

    async def invoke(
        self, request: CompletionRequest, x402: X402GatewayPort
    ) -> tuple[CompletionResponse, dict[str, Any]]:
        """Run one paid completion: call the provider, then settle via x402.

        Returns (response, receipt). The receipt carries the PYTHAI tithe split.
        """
        response = await self.adapter.complete(request, self.model)
        receipt = x402.settle(
            self.x402_endpoint,
            usage_input=response.usage.input_tokens,
            usage_output=response.usage.output_tokens,
        )
        return response, receipt


# --------------------------------------------------------------------------
# The builder
# --------------------------------------------------------------------------


class AgentBuilder:
    """Constructs provider-agnostic sovereign agents on the mindX neutral layer."""

    def __init__(
        self,
        credentials: CredentialResolver,
        identity_registry: IdentityRegistryPort,
        ens_registrar: EnsRegistrarPort,
        agenticplace: AgenticPlacePort,
        x402_gateway: X402GatewayPort,
        mcp_surface: McpSurfacePort,
        bona_fide: BonaFidePort,
        treasury_address: str,
        agent_card_base_uri: str = "https://agenticplace.pythai.net/agent",
    ) -> None:
        self._credentials = credentials
        self._identity = identity_registry
        self._ens = ens_registrar
        self._agenticplace = agenticplace
        self._x402 = x402_gateway
        self._mcp = mcp_surface
        self._bona_fide = bona_fide
        self._treasury = treasury_address
        self._card_base = agent_card_base_uri.rstrip("/")

    def build(self, spec: AgentBuildSpec) -> BuiltAgent:
        # 1 + 2: resolve model and instantiate the provider adapter
        model = resolve_model(spec.provider, spec.model_id)
        adapter = instantiate_adapter(
            spec.provider,
            self._credentials,
            credential_id=spec.credential_id,
            **spec.provider_kwargs,
        )

        # 5 (assembled early because identity needs the card URI):
        card_uri = f"{self._card_base}/{spec.label}/.well-known/agent.json"
        agent_card = self._assemble_agent_card(spec, model, adapter, card_uri)

        # 3: mint the ERC-8004 identity
        agent_id = self._identity.mint_identity(spec.owner_address, card_uri)

        # 4: claim the ENS subname under bankon.eth
        ens_name = self._ens.claim_subname(spec.label, resolves_to=agent_id)
        agent_card["registrations"] = [
            {"agentId": agent_id, "agentAddress": ens_name, "protocol": "erc-8004"}
        ]

        # 6: register in AgenticPlace + mint aORC verification
        listing_id = self._agenticplace.register(agent_card, agent_id)
        aorc_id = self._agenticplace.mint_aorc(listing_id)

        # 7: bind the metered x402 endpoint with the PYTHAI treasury tithe
        in_price, out_price = adapter.price_per_token(model)
        x402_endpoint = self._x402.bind_endpoint(
            agent_id=agent_id,
            price_input_per_token=in_price,
            price_output_per_token=out_price,
            treasury_tithe=spec.treasury_tithe,
            treasury_address=self._treasury,
        )

        # 8: expose tools over MCP
        mcp_endpoint = self._mcp.register_tools(agent_id, agent_card.get("skills", []))

        # 9: seed BONA FIDE reputation (inherits a fraction if minted from a parent)
        reputation = self._bona_fide.initialize_reputation(agent_id, spec.parent_agent_id)

        return BuiltAgent(
            label=spec.label,
            provider=spec.provider,
            model=model,
            adapter=adapter,
            agent_id=agent_id,
            ens_name=ens_name,
            agent_card=agent_card,
            agenticplace_listing_id=listing_id,
            aorc_id=aorc_id,
            x402_endpoint=x402_endpoint,
            mcp_endpoint=mcp_endpoint,
            reputation=reputation,
        )

    def cross_register_external(
        self, external_agent_card_url: str, owner_address: str, label: str
    ) -> dict[str, Any]:
        """Neutral-layer move: wrap a giant's *own* public A2A AgentCard with an
        ERC-8004 identity and list it in AgenticPlace, without that giant's
        permission and beyond its ability to revoke. Returns the listing record.
        """
        card_uri = f"{self._card_base}/{label}/.well-known/agent.json"
        wrapper_card = {
            "name": label,
            "source": external_agent_card_url,
            "wrapped": True,
            "note": "cross-registered external agent; identity anchored on mindX neutral layer",
        }
        agent_id = self._identity.mint_identity(owner_address, card_uri)
        ens_name = self._ens.claim_subname(label, resolves_to=agent_id)
        listing_id = self._agenticplace.register(wrapper_card, agent_id)
        return {"agent_id": agent_id, "ens_name": ens_name, "listing_id": listing_id}

    # --- internal -------------------------------------------------------

    def _assemble_agent_card(
        self,
        spec: AgentBuildSpec,
        model: ModelSpec,
        adapter: ProviderAdapter,
        card_uri: str,
    ) -> dict[str, Any]:
        """Build an A2A-style AgentCard. Advertises the provider's native
        protocol plus the universal MCP + x402 capabilities mindX adds."""
        return {
            "name": spec.label,
            "description": spec.persona or f"{spec.provider} {model.model_id} sovereign agent",
            "url": card_uri,
            "provider": {"organization": "PYTHAI", "url": "https://pythai.net"},
            "version": "1.0.0",
            "capabilities": {
                "streaming": model.supports_streaming,
                "tools": model.supports_tools,
                "nativeProtocol": model.native_protocol.value,
                "payments": ["x402"],
                "interop": ["a2a", "mcp"],
            },
            "skills": adapter.agent_card_skills(model),
        }
