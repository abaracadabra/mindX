"""clients/evm_chain.py — optional direct-EVM reads (no backend required).

For operators who want the builder to read chain state directly rather than
through the mindX backend. Provides a minimal, correct ABI codec for the exact
calls used by the identity layer and a JSON-RPC read client over httpx.

Writes (minting, setAgentCard) are NOT performed here: signing must go through
the BANKON Vault, so state-changing operations remain backend-brokered. This
module is read-only by design, which keeps key material out of the process.

Requires a keccak backend for function selectors:
    pip install "eth-hash[pycryptodome]"    # or eth-utils

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

from typing import Any

import httpx

try:  # keccak for function selectors
    from eth_utils import keccak as _keccak  # type: ignore
except Exception:  # pragma: no cover - exercised only when extra missing
    try:
        from eth_hash.auto import keccak as _keccak  # type: ignore
    except Exception:  # pragma: no cover
        _keccak = None  # type: ignore


# --- minimal ABI codec -----------------------------------------------------


def function_selector(signature: str) -> bytes:
    if _keccak is None:  # pragma: no cover
        raise RuntimeError(
            "keccak backend required for selectors; "
            'pip install "eth-hash[pycryptodome]" or eth-utils'
        )
    return _keccak(text=signature)[:4]


def encode_uint256(value: int) -> bytes:
    if value < 0 or value >= (1 << 256):
        raise ValueError("uint256 out of range")
    return value.to_bytes(32, "big")


def encode_address(addr: str) -> bytes:
    a = addr.lower().removeprefix("0x")
    if len(a) != 40:
        raise ValueError(f"bad address: {addr}")
    return bytes(12) + bytes.fromhex(a)


def decode_address(word: bytes) -> str:
    if len(word) != 32:
        raise ValueError("address word must be 32 bytes")
    return "0x" + word[12:].hex()


def decode_uint256(word: bytes) -> int:
    if len(word) != 32:
        raise ValueError("uint256 word must be 32 bytes")
    return int.from_bytes(word, "big")


def decode_string(return_data: bytes) -> str:
    """Decode a single dynamic `string` return value (head+tail ABI layout)."""
    if len(return_data) < 64:
        return ""
    offset = int.from_bytes(return_data[0:32], "big")
    length = int.from_bytes(return_data[offset : offset + 32], "big")
    start = offset + 32
    return return_data[start : start + length].decode("utf-8")


# --- JSON-RPC read client --------------------------------------------------


class EvmReadClient:
    """Read-only JSON-RPC client (eth_call) over httpx."""

    def __init__(self, rpc_url: str, timeout_s: float = 20.0) -> None:
        self._url = rpc_url
        self._client = httpx.Client(timeout=timeout_s)
        self._id = 0

    def call(self, to: str, data: bytes) -> bytes:
        self._id += 1
        payload = {
            "jsonrpc": "2.0",
            "id": self._id,
            "method": "eth_call",
            "params": [{"to": to, "data": "0x" + data.hex()}, "latest"],
        }
        resp = self._client.post(self._url, json=payload)
        resp.raise_for_status()
        body = resp.json()
        if "error" in body:
            raise RuntimeError(f"eth_call error: {body['error']}")
        return bytes.fromhex(body["result"].removeprefix("0x"))

    def close(self) -> None:
        self._client.close()


class IdentityReadAdapter:
    """Direct-chain reads for ERC-8004 identity + this repo's ERC8004Adapter.

    Provides owner_of (ERC-8004 IdentityRegistry) and resolve_agent_card
    (ERC8004Adapter). Complements the backend IdentityRegistryClient for
    operators who prefer to verify chain state without the backend.
    """

    _OWNER_OF = "ownerOf(uint256)"
    _RESOLVE = "resolve(uint256)"
    _PARENT_OF = "parentOf(uint256)"

    def __init__(self, read: EvmReadClient, identity_registry: str, adapter_address: str) -> None:
        self._read = read
        self._registry = identity_registry
        self._adapter = adapter_address

    def owner_of(self, agent_id: int) -> str:
        data = function_selector(self._OWNER_OF) + encode_uint256(agent_id)
        return decode_address(self._read.call(self._registry, data))

    def resolve_agent_card(self, agent_id: int) -> str:
        data = function_selector(self._RESOLVE) + encode_uint256(agent_id)
        return decode_string(self._read.call(self._adapter, data))

    def parent_of(self, agent_id: int) -> int:
        data = function_selector(self._PARENT_OF) + encode_uint256(agent_id)
        return decode_uint256(self._read.call(self._adapter, data))
