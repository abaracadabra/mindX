"""clients/config.py — production client configuration.

Reads from environment. The stream address book enforces isolation: every
bazaar income stream must have its own distinct destination address.

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from agent_builder.bazaar import StreamKind

_STREAM_ENV = {
    StreamKind.INFERENCE_TITHE: "STREAM_INFERENCE_TITHE_ADDR",
    StreamKind.SKILL_ROYALTY: "STREAM_SKILL_ROYALTY_ADDR",
    StreamKind.GENOME_MINT_ROYALTY: "STREAM_GENOME_MINT_ROYALTY_ADDR",
    StreamKind.REGISTRATION_FEE: "STREAM_REGISTRATION_FEE_ADDR",
    StreamKind.VERIFICATION_FEE: "STREAM_VERIFICATION_FEE_ADDR",
    StreamKind.STORAGE_FEE: "STREAM_STORAGE_FEE_ADDR",
    StreamKind.SETTLEMENT_FEE: "STREAM_SETTLEMENT_FEE_ADDR",
    StreamKind.MARKETING_REVENUE: "STREAM_MARKETING_REVENUE_ADDR",
}


@dataclass
class MindxClientConfig:
    """Everything the concrete clients need to reach the mindX backend + chains."""

    backend_base_url: str = "https://mindx.pythai.net"
    agenticplace_base_url: str = "https://agenticplace.pythai.net"
    api_token: str = ""
    treasury_address: str = ""
    ens_parent: str = "bankon.eth"
    agent_card_base_uri: str = "https://agenticplace.pythai.net/agent"
    request_timeout_s: float = 30.0
    max_retries: int = 3
    # optional direct-chain access (else on-chain writes go through the backend)
    eth_rpc_url: str = ""
    identity_registry: str = "0x8004A169FB4a3325136EB29fA0ceB6D2e539a432"
    reputation_registry: str = "0x8004BAa17C55a88189AE136b182e5fdA19dE9b63"
    erc8004_adapter: str = ""  # deployed ERC8004Adapter address (this repo's contract)
    stream_addresses: dict[StreamKind, str] = field(default_factory=dict)

    @classmethod
    def from_env(cls, environ: dict[str, str] | None = None) -> "MindxClientConfig":
        e = environ if environ is not None else os.environ
        stream_addresses = {
            kind: e[var] for kind, var in _STREAM_ENV.items() if e.get(var)
        }
        return cls(
            backend_base_url=e.get("MINDX_BACKEND_URL", "https://mindx.pythai.net"),
            agenticplace_base_url=e.get("AGENTICPLACE_URL", "https://agenticplace.pythai.net"),
            api_token=e.get("MINDX_API_TOKEN", ""),
            treasury_address=e.get("TREASURY_ADDRESS", ""),
            ens_parent=e.get("ENS_PARENT", "bankon.eth"),
            request_timeout_s=float(e.get("MINDX_TIMEOUT_S", "30")),
            max_retries=int(e.get("MINDX_MAX_RETRIES", "3")),
            eth_rpc_url=e.get("ETH_MAINNET_RPC", ""),
            identity_registry=e.get(
                "ERC8004_IDENTITY_REGISTRY", "0x8004A169FB4a3325136EB29fA0ceB6D2e539a432"
            ),
            reputation_registry=e.get(
                "ERC8004_REPUTATION_REGISTRY", "0x8004BAa17C55a88189AE136b182e5fdA19dE9b63"
            ),
            erc8004_adapter=e.get("ERC8004_ADAPTER", ""),
            stream_addresses=stream_addresses,
        )

    def require(self, *fields: str) -> None:
        missing = [f for f in fields if not getattr(self, f)]
        if missing:
            raise ValueError(f"missing required config: {', '.join(missing)}")
