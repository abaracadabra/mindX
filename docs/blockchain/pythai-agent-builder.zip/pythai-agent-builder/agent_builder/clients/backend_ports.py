"""clients/backend_ports.py — concrete AgentBuilder ports against the mindX backend.

These satisfy the Protocol ports the AgentBuilder depends on, implemented as
HTTP calls to the mindX backend API (mindx.pythai.net). This is the faithful
integration path: the backend holds the BANKON Vault and the chain
infrastructure, so on-chain minting is performed backend-side (by the ID
Manager Agent) and returned to the builder — no private keys ever reach this
process.

Every client is import-safe (httpx only) and testable via httpx.MockTransport.

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

from typing import Any

from agent_builder.clients.http import BackendClient


class VaultCredentialResolver:
    """Resolves provider API keys from the BANKON Vault via the backend.

    Implements agent_builder.provider_adapter.CredentialResolver. Secrets never
    persist in this process beyond the call that uses them. An optional local
    fallback map supports development only.
    """

    def __init__(self, backend: BackendClient, local_fallback: dict[str, str] | None = None) -> None:
        self._backend = backend
        self._fallback = local_fallback or {}

    def resolve(self, credential_id: str) -> str | None:
        try:
            data = self._backend.get(f"/vault/credential/{credential_id}")
            secret = data.get("secret")
            if secret:
                return secret
        except Exception:
            pass
        return self._fallback.get(credential_id)


class IdentityRegistryClient:
    """Implements AgentBuilder.IdentityRegistryPort.

    Delegates ERC-8004 minting to the backend ID Manager Agent, which signs with
    the vault and returns the on-chain AgentID.
    """

    def __init__(self, backend: BackendClient) -> None:
        self._backend = backend

    def mint_identity(self, owner: str, agent_card_uri: str) -> str:
        data = self._backend.post(
            "/identity/mint",
            {"owner": owner, "agent_card_uri": agent_card_uri, "standard": "erc-8004"},
        )
        agent_id = data.get("agent_id")
        if not agent_id:
            raise ValueError(f"backend did not return agent_id: {data}")
        return str(agent_id)

    def owner_of(self, agent_id: str) -> str | None:
        data = self._backend.get(f"/identity/{agent_id}/owner")
        return data.get("owner")


class EnsRegistrarClient:
    """Implements AgentBuilder.EnsRegistrarPort — subnames under a parent (bankon.eth)."""

    def __init__(self, backend: BackendClient, parent: str = "bankon.eth") -> None:
        self._backend = backend
        self._parent = parent

    def claim_subname(self, label: str, resolves_to: str) -> str:
        data = self._backend.post(
            "/ens/subname",
            {"label": label, "parent": self._parent, "resolves_to": resolves_to},
        )
        return data.get("name", f"{label}.{self._parent}")


class AgenticPlaceClient:
    """Implements AgentBuilder.AgenticPlacePort — registry listing + aORC verification."""

    def __init__(self, backend: BackendClient) -> None:
        self._backend = backend

    def register(self, agent_card: dict[str, Any], agent_id: str) -> str:
        data = self._backend.post(
            "/agenticplace/register", {"agent_card": agent_card, "agent_id": agent_id}
        )
        listing_id = data.get("listing_id")
        if not listing_id:
            raise ValueError(f"backend did not return listing_id: {data}")
        return str(listing_id)

    def mint_aorc(self, listing_id: str) -> str:
        data = self._backend.post("/agenticplace/aorc", {"listing_id": listing_id})
        return str(data.get("aorc_id", f"aorc:{listing_id}"))


class McpSurfaceClient:
    """Implements AgentBuilder.McpSurfacePort — registers agent tools as MCP."""

    def __init__(self, backend: BackendClient) -> None:
        self._backend = backend

    def register_tools(self, agent_id: str, tools: list[dict[str, Any]]) -> str:
        data = self._backend.post(
            "/mcp/register", {"agent_id": agent_id, "tools": tools}
        )
        return data.get("mcp_endpoint", f"mcp://agenticplace.pythai.net/{agent_id}")


class BonaFideClient:
    """Implements AgentBuilder.BonaFidePort — seeds constitutional reputation."""

    def __init__(self, backend: BackendClient) -> None:
        self._backend = backend

    def initialize_reputation(self, agent_id: str, parent_agent_id: str | None) -> int:
        data = self._backend.post(
            "/reputation/init",
            {"agent_id": agent_id, "parent_agent_id": parent_agent_id},
        )
        return int(data.get("rank", 1))
