"""clients/factory.py — assemble the live system from config.

This is the final step from mocks to mainnet: given a MindxClientConfig, it
wires a real AgentBuilder (backed by the mindX backend), a real X402Gateway
(backed by the vault signer + backend facilitator), and a Bazaar with isolated
per-stream destinations. No mock ports remain.

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

import httpx

from agent_builder.agent_builder import AgentBuilder
from agent_builder.bazaar import Bazaar, default_stream_configs
from agent_builder.clients.backend_ports import (
    AgenticPlaceClient,
    BonaFideClient,
    EnsRegistrarClient,
    IdentityRegistryClient,
    McpSurfaceClient,
    VaultCredentialResolver,
)
from agent_builder.clients.config import MindxClientConfig
from agent_builder.clients.http import BackendClient
from agent_builder.clients.x402_backend import BackendFacilitator, VaultSigner
from agent_builder.gateways import X402Gateway


def _backend(config: MindxClientConfig, base_url: str, transport: httpx.BaseTransport | None) -> BackendClient:
    return BackendClient(
        base_url=base_url,
        api_token=config.api_token,
        timeout_s=config.request_timeout_s,
        max_retries=config.max_retries,
        transport=transport,
    )


def build_agent_builder(
    config: MindxClientConfig,
    transport: httpx.BaseTransport | None = None,
    local_credential_fallback: dict[str, str] | None = None,
) -> AgentBuilder:
    """Assemble a live AgentBuilder from config.

    `transport` is for tests (httpx.MockTransport); leave None in production.
    """
    config.require("treasury_address")
    backend = _backend(config, config.backend_base_url, transport)
    agenticplace_backend = _backend(config, config.agenticplace_base_url, transport)

    return AgentBuilder(
        credentials=VaultCredentialResolver(backend, local_credential_fallback),
        identity_registry=IdentityRegistryClient(backend),
        ens_registrar=EnsRegistrarClient(backend, parent=config.ens_parent),
        agenticplace=AgenticPlaceClient(agenticplace_backend),
        x402_gateway=_x402_port_bridge(config, transport),
        mcp_surface=McpSurfaceClient(backend),
        bona_fide=BonaFideClient(backend),
        treasury_address=config.treasury_address,
        agent_card_base_uri=config.agent_card_base_uri,
    )


def build_x402_gateway(
    config: MindxClientConfig, transport: httpx.BaseTransport | None = None
) -> X402Gateway:
    """Assemble a live X402Gateway backed by the vault signer + facilitator."""
    backend = _backend(config, config.backend_base_url, transport)
    return X402Gateway(signer=VaultSigner(backend), facilitator=BackendFacilitator(backend))


def build_bazaar(config: MindxClientConfig) -> Bazaar:
    """Assemble the Bazaar with isolated per-stream destinations from config."""
    if not config.stream_addresses:
        raise ValueError("no stream_addresses configured; see .env.example")
    return Bazaar(default_stream_configs(config.stream_addresses))


def _x402_port_bridge(config: MindxClientConfig, transport: httpx.BaseTransport | None):
    """The AgentBuilder expects an X402GatewayPort (bind_endpoint + settle);
    the concrete X402Gateway satisfies exactly that interface."""
    return build_x402_gateway(config, transport)
