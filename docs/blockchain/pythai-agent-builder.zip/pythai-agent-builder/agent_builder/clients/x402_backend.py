"""clients/x402_backend.py — concrete x402 SignerPort + FacilitatorClient.

The gateway delegates signing to the vault (VaultSigner) and settlement
broadcast to a rail facilitator (BackendFacilitator). No key material lives in
this process; the backend holds the vault and brokers each rail's facilitator
(Coinbase for Base USDC, GoPlausible/Parsec for Algorand ASA, Tempo for MPP).

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

from typing import Any

from agent_builder.clients.http import BackendClient


class VaultSigner:
    """Implements X402Gateway.SignerPort by asking the backend vault to sign."""

    def __init__(self, backend: BackendClient) -> None:
        self._backend = backend

    def sign_payment(self, rail: str, payload: dict[str, Any]) -> str:
        data = self._backend.post("/x402/sign", {"rail": rail, "payload": payload})
        sig = data.get("signature")
        if not sig:
            raise ValueError(f"vault did not return a signature: {data}")
        return sig


class BackendFacilitator:
    """Implements X402Gateway.FacilitatorClient by brokering rail settlement."""

    def __init__(self, backend: BackendClient) -> None:
        self._backend = backend

    def settle(self, rail: str, payload: dict[str, Any], signature: str) -> dict[str, Any]:
        data = self._backend.post(
            "/x402/settle", {"rail": rail, "payload": payload, "signature": signature}
        )
        # normalized to what X402Gateway expects: {tx_hash, status}
        return {
            "tx_hash": data.get("tx_hash"),
            "status": data.get("status", "settled"),
        }
