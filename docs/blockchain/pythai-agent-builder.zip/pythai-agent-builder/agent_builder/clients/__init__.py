"""clients — concrete implementations of the AgentBuilder and X402Gateway ports.

The final step from mocks to mainnet. Backend-backed ports (identity, ens,
agenticplace, mcp, reputation, vault credentials), the x402 vault signer +
facilitator, an optional direct-EVM read client, and an assembly factory.

Public API:
    MindxClientConfig
    BackendClient, BackendError
    VaultCredentialResolver, IdentityRegistryClient, EnsRegistrarClient,
    AgenticPlaceClient, McpSurfaceClient, BonaFideClient
    VaultSigner, BackendFacilitator
    EvmReadClient, IdentityReadAdapter
    build_agent_builder, build_x402_gateway, build_bazaar
"""

from agent_builder.clients.backend_ports import (
    AgenticPlaceClient,
    BonaFideClient,
    EnsRegistrarClient,
    IdentityRegistryClient,
    McpSurfaceClient,
    VaultCredentialResolver,
)
from agent_builder.clients.config import MindxClientConfig
from agent_builder.clients.evm_chain import EvmReadClient, IdentityReadAdapter
from agent_builder.clients.factory import (
    build_agent_builder,
    build_bazaar,
    build_x402_gateway,
)
from agent_builder.clients.http import BackendClient, BackendError
from agent_builder.clients.x402_backend import BackendFacilitator, VaultSigner

__all__ = [
    "MindxClientConfig",
    "BackendClient",
    "BackendError",
    "VaultCredentialResolver",
    "IdentityRegistryClient",
    "EnsRegistrarClient",
    "AgenticPlaceClient",
    "McpSurfaceClient",
    "BonaFideClient",
    "VaultSigner",
    "BackendFacilitator",
    "EvmReadClient",
    "IdentityReadAdapter",
    "build_agent_builder",
    "build_x402_gateway",
    "build_bazaar",
]
