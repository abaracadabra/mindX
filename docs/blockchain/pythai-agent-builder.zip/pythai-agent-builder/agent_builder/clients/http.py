"""clients/http.py — shared backend HTTP client.

A thin, retrying httpx wrapper used by every concrete mindX client. Bearer-auth,
bounded retries with backoff on transient failures, and a single error type so
callers can handle backend failures uniformly.

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

import time
from typing import Any

import httpx


class BackendError(RuntimeError):
    """Raised when the mindX backend returns an error or is unreachable."""

    def __init__(self, message: str, status: int | None = None, body: Any = None) -> None:
        super().__init__(message)
        self.status = status
        self.body = body


class BackendClient:
    """Retrying JSON HTTP client for the mindX backend."""

    def __init__(
        self,
        base_url: str,
        api_token: str = "",
        timeout_s: float = 30.0,
        max_retries: int = 3,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        headers = {"content-type": "application/json"}
        if api_token:
            headers["authorization"] = f"Bearer {api_token}"
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers=headers,
            timeout=timeout_s,
            transport=transport,
        )
        self._max_retries = max_retries

    def post(self, path: str, json: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", path, json=json)

    def get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._request("GET", path, params=params)

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        last_exc: Exception | None = None
        for attempt in range(self._max_retries):
            try:
                resp = self._client.request(method, path, **kwargs)
                if resp.status_code >= 500:
                    raise BackendError(
                        f"backend {resp.status_code} on {method} {path}",
                        status=resp.status_code,
                        body=_safe_body(resp),
                    )
                if resp.status_code >= 400:
                    # client errors are not retried
                    raise BackendError(
                        f"backend {resp.status_code} on {method} {path}",
                        status=resp.status_code,
                        body=_safe_body(resp),
                    )
                return resp.json() if resp.content else {}
            except (httpx.TransportError, BackendError) as exc:
                last_exc = exc
                # do not retry deterministic 4xx
                if isinstance(exc, BackendError) and exc.status and exc.status < 500:
                    raise
                if attempt < self._max_retries - 1:
                    time.sleep(0.2 * (2**attempt))
        raise BackendError(f"backend unreachable after retries: {last_exc}")

    def close(self) -> None:
        self._client.close()


def _safe_body(resp: httpx.Response) -> Any:
    try:
        return resp.json()
    except Exception:
        return resp.text
