"""example_bazaar_streams.py — isolated income streams end to end.

Run:  python -m agent_builder.example_bazaar_streams
"""

from __future__ import annotations

from decimal import Decimal

from agent_builder.bazaar import Bazaar, IncomeEvent, StreamKind, default_stream_configs


def main() -> None:
    # Each stream MUST have its own isolated destination address.
    address_book = {
        StreamKind.INFERENCE_TITHE: "0xTREASURY_INFERENCE",
        StreamKind.SKILL_ROYALTY: "0xTREASURY_SKILL",
        StreamKind.GENOME_MINT_ROYALTY: "0xTREASURY_GENOME",
        StreamKind.REGISTRATION_FEE: "0xTREASURY_REGISTRATION",
        StreamKind.VERIFICATION_FEE: "0xTREASURY_VERIFICATION",
        StreamKind.STORAGE_FEE: "0xTREASURY_STORAGE",
        StreamKind.SETTLEMENT_FEE: "0xTREASURY_SETTLEMENT",
        StreamKind.MARKETING_REVENUE: "0xTREASURY_MARKETING",
    }
    bazaar = Bazaar(default_stream_configs(address_book))

    # 1) an x402 inference receipt -> inference tithe stream
    bazaar.ingest_x402_receipt(
        {"receipt_id": "rcpt-1", "treasury_tithe_amount": "0.0198", "rail": "algorand_asa_via_parsec"}
    )

    # 2) a skill invocation royalty -> 40/30/20/10
    bazaar.ingest_skill_royalty(
        amount=Decimal("12.00"),
        source_ref="skill-inft-77",
        role_addresses={
            "developer": "0xDEV_ALICE",
            "system": "0xSYS",
            "governance": "0xGOV",
            "treasury": "0xTREASURY_SKILL",
        },
    )

    # 3) a genome replication -> parent lineage takes the developer seat
    bazaar.ingest_genome_mint(
        amount=Decimal("5.00"), source_ref="genome-102", parent_lineage_address="0xPARENT_LINEAGE"
    )

    # 4) flat fees
    bazaar.ingest_fee(StreamKind.VERIFICATION_FEE, Decimal("1.00"), "aorc-9")
    bazaar.ingest_fee(StreamKind.REGISTRATION_FEE, Decimal("2.50"), "listing-9")

    # 5) marketing inflow -> 99/1 buyback
    bazaar.ingest(
        IncomeEvent(StreamKind.MARKETING_REVENUE, Decimal("100.00"), "campaign-3")
    )

    print("=== isolated stream statements ===")
    for kind in StreamKind:
        st = bazaar.statement(kind)
        print(f"{kind.value:22s} total={st['total']:>12s}  balances={st['balances']}")

    print("\n=== consolidated (informational only; funds stay isolated) ===")
    con = bazaar.consolidated_statement()
    print(f"grand_total_informational = {con['grand_total_informational']}")
    print(f"isolation: {con['isolation']}")

    print("\n=== destinations (all distinct) ===")
    for stream, addr in bazaar.destinations().items():
        print(f"{stream:22s} -> {addr}")


if __name__ == "__main__":
    main()
