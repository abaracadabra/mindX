"""agent_builder — provider-agnostic sovereign agent factory for the mindX neutral layer.

Public API:
    AgentBuilder, AgentBuildSpec, BuiltAgent
    ProviderAdapter, CompletionRequest, CompletionResponse
    PROVIDER_REGISTRY, resolve_model, instantiate_adapter
"""

from agent_builder.agent_builder import AgentBuilder, AgentBuildSpec, BuiltAgent
from agent_builder.provider_adapter import (
    CompletionRequest,
    CompletionResponse,
    ModelSpec,
    ProviderAdapter,
    ProviderProtocol,
)
from agent_builder.registry import PROVIDER_REGISTRY, instantiate_adapter, resolve_model

__all__ = [
    "AgentBuilder",
    "AgentBuildSpec",
    "BuiltAgent",
    "ProviderAdapter",
    "ProviderProtocol",
    "ModelSpec",
    "CompletionRequest",
    "CompletionResponse",
    "PROVIDER_REGISTRY",
    "resolve_model",
    "instantiate_adapter",
]
