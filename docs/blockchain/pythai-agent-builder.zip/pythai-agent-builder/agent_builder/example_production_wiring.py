"""example_production_wiring.py — assemble the live system from env.

This shows the final step from mocks to mainnet. With MINDX_* and STREAM_*
environment variables set (see .env.example), it assembles a real AgentBuilder,
X402Gateway, and Bazaar wired to the mindX backend — no mock ports.

It does NOT execute network calls here; it demonstrates assembly and prints the
wired configuration. Remove the dry-run guard to build agents against the live
backend.

Run:  python -m agent_builder.example_production_wiring
"""

from __future__ import annotations

import os

from agent_builder.clients import (
    MindxClientConfig,
    build_agent_builder,
    build_bazaar,
    build_x402_gateway,
)


def main() -> None:
    config = MindxClientConfig.from_env()

    print("=== mindX client config ===")
    print(f"backend       : {config.backend_base_url}")
    print(f"agenticplace  : {config.agenticplace_base_url}")
    print(f"ens parent    : {config.ens_parent}")
    print(f"treasury      : {config.treasury_address or '(unset)'}")
    print(f"stream addrs  : {len(config.stream_addresses)} configured")

    if not config.treasury_address:
        print("\nTREASURY_ADDRESS not set; set env per .env.example to assemble live clients.")
        return

    builder = build_agent_builder(config)
    gateway = build_x402_gateway(config)
    print("\n=== assembled ===")
    print(f"agent builder : {type(builder).__name__} (backend-backed ports)")
    print(f"x402 gateway  : {type(gateway).__name__} (vault signer + facilitator)")

    if config.stream_addresses:
        bazaar = build_bazaar(config)
        print(f"bazaar        : {len(bazaar.destinations())} isolated streams")

    if os.environ.get("MINDX_LIVE") == "1":
        from agent_builder import AgentBuildSpec

        agent = builder.build(
            AgentBuildSpec(
                label="claude-research",
                provider="anthropic",
                model_id="claude-opus-4-8",
                owner_address=config.treasury_address,
            )
        )
        print(f"\nbuilt live agent: {agent.ens_name} id={agent.agent_id}")
    else:
        print("\n(set MINDX_LIVE=1 to build an agent against the live backend)")


if __name__ == "__main__":
    main()
