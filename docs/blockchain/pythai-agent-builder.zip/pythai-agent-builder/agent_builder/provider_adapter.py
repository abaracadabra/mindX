"""provider_adapter.py — the single interface every provider integration conforms to.

Apache-2.0. snake_case. Python >= 3.12. No admin keys, no provider lock-in.

Design intent
-------------
mindX is the neutral layer. A "provider integration" wraps an external model
maker (Google/Gemini, OpenAI/GPT, Anthropic/Claude, xAI/Grok, IBM/watsonx)
behind ONE normalized contract so that the AgentBuilder can mint identity,
register in AgenticPlace, meter x402 payments, and attach BONA FIDE reputation
without knowing or caring which cathedral is behind the adapter.

The adapter normalizes three things that differ across providers:
  1. transport + request/response shape (the wire format),
  2. the agent's native interop protocol (A2A / MCP / ACP / OpenAI-compat / watsonx),
  3. token pricing (so x402 can meter and tithe deterministically).

Credentials are never held in the adapter. They are resolved at call time from
the BANKON Vault via a CredentialResolver, so a forked node without vault access
simply cannot transact — which is the enforcement boundary, not the code.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Any, Protocol, runtime_checkable


class ProviderProtocol(str, Enum):
    """The native agent-interop protocol a provider speaks best.

    Every adapter still exposes A2A + MCP through the builder; this field
    records the provider's *native* lane so the AgentCard can advertise it.
    """

    A2A = "a2a"                      # Google authored A2A; Gemini is native
    MCP = "mcp"                      # Anthropic authored MCP; Claude is native
    ACP = "acp"                      # OpenAI + Stripe Agentic Commerce Protocol
    OPENAI_COMPAT = "openai_compat"  # xAI/Grok exposes an OpenAI-compatible API
    WATSONX_ORCHESTRATE = "watsonx_orchestrate"  # IBM orchestration surface


@dataclass(frozen=True)
class ModelSpec:
    """Static description of a single callable model."""

    provider: str
    model_id: str
    context_window: int
    supports_tools: bool
    supports_streaming: bool
    native_protocol: ProviderProtocol
    # USD price per 1M tokens; used only as a fallback when the live price
    # oracle is unavailable. x402 settlement uses on-chain stablecoin amounts.
    usd_per_mtok_input: Decimal
    usd_per_mtok_output: Decimal


@dataclass
class CompletionRequest:
    """Normalized request. Adapters translate this into provider wire format."""

    messages: list[dict[str, Any]]
    tools: list[dict[str, Any]] = field(default_factory=list)
    max_tokens: int = 1024
    temperature: float = 0.7
    stream: bool = False
    # opaque pass-through for provider-specific knobs the caller insists on
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class UsageRecord:
    """Token accounting for x402 metering. Adapters MUST populate this."""

    input_tokens: int
    output_tokens: int

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass
class ToolCall:
    name: str
    arguments: dict[str, Any]
    call_id: str | None = None


@dataclass
class CompletionResponse:
    """Normalized response across every provider."""

    text: str
    tool_calls: list[ToolCall]
    usage: UsageRecord
    model_id: str
    raw: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class CredentialResolver(Protocol):
    """Resolves a provider API key from the BANKON Vault at call time.

    The adapter holds only the credential *id*, never the secret. A node
    without vault access (e.g. a stripped fork) gets None and cannot call out.
    """

    def resolve(self, credential_id: str) -> str | None: ...


class ProviderAdapter(ABC):
    """The contract every cathedral integration implements.

    Concrete adapters live in agent_builder/adapters/. Each one is responsible
    only for the provider-specific delta: transport, request/response shape,
    native protocol, pricing, and any provider-only agent surface.
    """

    provider_name: str
    native_protocol: ProviderProtocol

    def __init__(self, credentials: CredentialResolver, credential_id: str) -> None:
        self._credentials = credentials
        self._credential_id = credential_id

    # --- core inference -------------------------------------------------

    @abstractmethod
    async def complete(self, request: CompletionRequest, model: ModelSpec) -> CompletionResponse:
        """Call the provider and return a normalized response.

        Implementations resolve the API key via self._api_key(), translate the
        normalized request into the provider's wire format, await the call, and
        translate the result back into CompletionResponse — including a fully
        populated UsageRecord so x402 can meter the call.
        """
        ...

    # --- interop + commerce metadata ------------------------------------

    @abstractmethod
    def agent_card_skills(self, model: ModelSpec) -> list[dict[str, Any]]:
        """Return A2A AgentCard `skills` entries describing what the wrapped
        agent can do. Consumed by the AgentBuilder when it publishes the card."""
        ...

    @abstractmethod
    def price_per_token(self, model: ModelSpec) -> tuple[Decimal, Decimal]:
        """Return (input_price, output_price) as USD Decimals per single token.

        The x402 gateway multiplies these by UsageRecord counts to compute the
        settlement amount, then applies the PYTHAI treasury tithe on top.
        """
        ...

    # --- health ---------------------------------------------------------

    @abstractmethod
    async def health(self) -> bool:
        """Cheap liveness probe used by InferenceDiscovery scoring."""
        ...

    # --- shared helpers -------------------------------------------------

    def _api_key(self) -> str:
        key = self._credentials.resolve(self._credential_id)
        if not key:
            raise PermissionError(
                f"no credential for {self.provider_name}; "
                f"vault access required (id={self._credential_id})"
            )
        return key
