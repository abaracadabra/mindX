"""bazaar/streams.py — income-stream taxonomy and split policies.

The bazaar principle: every source of revenue is an ISOLATED stream. Each
stream has its own dedicated destination address, its own append-only ledger,
and its own split policy. Streams never commingle; the only cross-stream
movement is an explicit, logged TreasurySweep.

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

ONE = Decimal(1)


class StreamKind(str, Enum):
    """Every distinct source of bazaar income. One ledger per kind."""

    INFERENCE_TITHE = "inference_tithe"          # x402 tithe on paid inference
    SKILL_ROYALTY = "skill_royalty"              # ERC-7857 skill invocation royalty
    GENOME_MINT_ROYALTY = "genome_mint_royalty"  # replication from a parent genome
    REGISTRATION_FEE = "registration_fee"        # AgenticPlace listing fees
    VERIFICATION_FEE = "verification_fee"        # aORC verification (1 ALGO class)
    STORAGE_FEE = "storage_fee"                  # pay2store permanence margin
    SETTLEMENT_FEE = "settlement_fee"            # cross-vendor x402 basis fee
    MARKETING_REVENUE = "marketing_revenue"      # MarketingTreasury inflows


@dataclass(frozen=True)
class SplitPolicy:
    """role -> fraction. Fractions are Decimals and MUST sum to exactly 1."""

    name: str
    fractions: tuple[tuple[str, Decimal], ...]

    def __post_init__(self) -> None:
        total = sum(f for _, f in self.fractions)
        if total != ONE:
            raise ValueError(f"policy {self.name!r} fractions sum to {total}, not 1")
        roles = [r for r, _ in self.fractions]
        if len(roles) != len(set(roles)):
            raise ValueError(f"policy {self.name!r} has duplicate roles")

    def roles(self) -> list[str]:
        return [r for r, _ in self.fractions]


# The canonical 40/30/20/10 (developer / system / governance / treasury)
FOUR_THREE_TWO_ONE = SplitPolicy(
    name="40/30/20/10",
    fractions=(
        ("developer", Decimal("0.40")),
        ("system", Decimal("0.30")),
        ("governance", Decimal("0.20")),
        ("treasury", Decimal("0.10")),
    ),
)

# Genome replication: the parent lineage takes the developer seat.
GENOME_LINEAGE = SplitPolicy(
    name="genome-lineage 40/30/20/10",
    fractions=(
        ("parent_lineage", Decimal("0.40")),
        ("system", Decimal("0.30")),
        ("governance", Decimal("0.20")),
        ("treasury", Decimal("0.10")),
    ),
)

# Whole-stream-to-treasury policies (tithes and fees).
ALL_TREASURY = SplitPolicy(name="100 treasury", fractions=(("treasury", ONE),))

# MarketingTreasury 99/1 buyback rule.
NINETY_NINE_ONE = SplitPolicy(
    name="99/1 buyback",
    fractions=(("buyback", Decimal("0.99")), ("operations", Decimal("0.01"))),
)


DEFAULT_POLICIES: dict[StreamKind, SplitPolicy] = {
    StreamKind.INFERENCE_TITHE: ALL_TREASURY,
    StreamKind.SKILL_ROYALTY: FOUR_THREE_TWO_ONE,
    StreamKind.GENOME_MINT_ROYALTY: GENOME_LINEAGE,
    StreamKind.REGISTRATION_FEE: ALL_TREASURY,
    StreamKind.VERIFICATION_FEE: ALL_TREASURY,
    StreamKind.STORAGE_FEE: ALL_TREASURY,
    StreamKind.SETTLEMENT_FEE: ALL_TREASURY,
    StreamKind.MARKETING_REVENUE: NINETY_NINE_ONE,
}


@dataclass(frozen=True)
class StreamConfig:
    """Binds a stream kind to its isolated destination and policy."""

    kind: StreamKind
    destination_address: str  # dedicated address — never shared across streams
    policy: SplitPolicy
    asset: str = "USDC"       # accounting asset for this stream's ledger


def default_stream_configs(address_book: dict[StreamKind, str]) -> dict[StreamKind, StreamConfig]:
    """Build configs from an address book. Enforces address isolation:
    no two streams may share a destination address."""
    seen: dict[str, StreamKind] = {}
    configs: dict[StreamKind, StreamConfig] = {}
    for kind in StreamKind:
        addr = address_book.get(kind)
        if not addr:
            raise KeyError(f"no destination address for stream {kind.value}")
        if addr in seen:
            raise ValueError(
                f"address isolation violated: {addr} used by both "
                f"{seen[addr].value} and {kind.value}"
            )
        seen[addr] = kind
        configs[kind] = StreamConfig(
            kind=kind, destination_address=addr, policy=DEFAULT_POLICIES[kind]
        )
    return configs
