"""bazaar/ledger.py — isolated, append-only per-stream accounting.

Each StreamKind gets its own ledger. Entries are append-only. Balances are
tracked per role. Streams never share a ledger, so a compromised or disputed
stream cannot corrupt the accounting of any other stream.

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from decimal import Decimal

from agent_builder.bazaar.streams import StreamKind


@dataclass(frozen=True)
class LedgerEntry:
    """A single immutable credit to one role within one stream."""

    entry_id: str
    stream: StreamKind
    role: str
    destination_address: str
    amount: Decimal
    asset: str
    source_ref: str          # e.g. x402 receipt id, tx hash, listing id
    timestamp: float


class StreamLedger:
    """Append-only ledger for exactly one stream kind."""

    def __init__(self, kind: StreamKind, asset: str) -> None:
        self.kind = kind
        self.asset = asset
        self._entries: list[LedgerEntry] = []
        self._balances: dict[str, Decimal] = {}

    def credit(
        self, role: str, destination_address: str, amount: Decimal, source_ref: str
    ) -> LedgerEntry:
        if amount < 0:
            raise ValueError("ledger credit must be non-negative")
        entry = LedgerEntry(
            entry_id=str(uuid.uuid4()),
            stream=self.kind,
            role=role,
            destination_address=destination_address,
            amount=amount,
            asset=self.asset,
            source_ref=source_ref,
            timestamp=time.time(),
        )
        self._entries.append(entry)
        self._balances[role] = self._balances.get(role, Decimal(0)) + amount
        return entry

    def balance(self, role: str) -> Decimal:
        return self._balances.get(role, Decimal(0))

    def total(self) -> Decimal:
        return sum(self._balances.values(), Decimal(0))

    def entries(self) -> tuple[LedgerEntry, ...]:
        return tuple(self._entries)

    def statement(self) -> dict:
        return {
            "stream": self.kind.value,
            "asset": self.asset,
            "total": str(self.total()),
            "balances": {r: str(b) for r, b in sorted(self._balances.items())},
            "entry_count": len(self._entries),
        }


@dataclass
class LedgerBook:
    """The full set of isolated ledgers, one per stream kind."""

    ledgers: dict[StreamKind, StreamLedger] = field(default_factory=dict)

    def get(self, kind: StreamKind, asset: str) -> StreamLedger:
        if kind not in self.ledgers:
            self.ledgers[kind] = StreamLedger(kind, asset)
        return self.ledgers[kind]

    def consolidated_statement(self) -> dict:
        """Report every stream separately AND a grand total.
        The grand total is informational only; funds remain isolated."""
        per_stream = {k.value: lg.statement() for k, lg in self.ledgers.items()}
        grand_total = sum((lg.total() for lg in self.ledgers.values()), Decimal(0))
        return {
            "streams": per_stream,
            "grand_total_informational": str(grand_total),
            "isolation": "funds are isolated per stream; grand total is not a pooled balance",
        }
