"""bazaar/bazaar.py — the neutral marketplace settlement engine.

The Bazaar ingests income events from every source (x402 inference receipts,
skill/genome royalties, listing and verification fees, storage margin, cross-
vendor settlement fees, marketing inflows), routes each to its ISOLATED stream,
applies that stream's split policy, records immutable ledger entries, and emits
concrete routing instructions (which address receives how much) for the
settlement layer to execute.

Design guarantees
-----------------
1. Isolation: each stream has a dedicated destination and a dedicated ledger.
   No two streams share a destination address (enforced at config build time).
2. Conservation: split amounts always sum back to the gross, with any rounding
   dust assigned deterministically to the treasury/last role — never lost.
3. Auditability: every credit is an append-only entry with a source reference,
   so any payout is traceable to the event that produced it.

Apache-2.0. snake_case. Python >= 3.12.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import ROUND_DOWN, Decimal
from typing import Any

from agent_builder.bazaar.ledger import LedgerBook
from agent_builder.bazaar.streams import StreamConfig, StreamKind


@dataclass(frozen=True)
class RoleRouting:
    role: str
    address: str
    amount: Decimal


@dataclass
class IncomeEvent:
    """A gross income event to be routed into an isolated stream."""

    stream: StreamKind
    gross_amount: Decimal
    source_ref: str
    asset: str = "USDC"
    # role -> address overrides for split-bearing streams (developer, system, ...)
    role_addresses: dict[str, str] = field(default_factory=dict)
    quantum_decimals: int = 6


@dataclass
class RoutingResult:
    stream: StreamKind
    gross: Decimal
    routings: tuple[RoleRouting, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "stream": self.stream.value,
            "gross": str(self.gross),
            "routings": [
                {"role": r.role, "address": r.address, "amount": str(r.amount)}
                for r in self.routings
            ],
        }


class Bazaar:
    """Neutral marketplace income router with isolated streams."""

    def __init__(self, configs: dict[StreamKind, StreamConfig]) -> None:
        self._configs = configs
        self._book = LedgerBook()
        # sanity: destinations are isolated
        addrs = [c.destination_address for c in configs.values()]
        if len(addrs) != len(set(addrs)):
            raise ValueError("stream destination addresses are not isolated")

    def ingest(self, event: IncomeEvent) -> RoutingResult:
        config = self._configs.get(event.stream)
        if config is None:
            raise KeyError(f"no config for stream {event.stream.value}")
        if event.gross_amount < 0:
            raise ValueError("gross_amount must be non-negative")

        q = Decimal(1).scaleb(-event.quantum_decimals)
        policy = config.policy
        ledger = self._book.get(event.stream, config.asset)

        routings: list[RoleRouting] = []
        allocated = Decimal(0)
        fracs = policy.fractions

        for i, (role, frac) in enumerate(fracs):
            if i < len(fracs) - 1:
                amount = (event.gross_amount * frac).quantize(q, rounding=ROUND_DOWN)
            else:
                # last role absorbs rounding dust so splits conserve exactly
                amount = event.gross_amount - allocated
            allocated += amount

            # role -> address resolution: explicit override, else stream destination
            address = event.role_addresses.get(role, config.destination_address)
            ledger.credit(role, address, amount, event.source_ref)
            routings.append(RoleRouting(role=role, address=address, amount=amount))

        assert sum(r.amount for r in routings) == event.gross_amount, "split not conserved"
        return RoutingResult(stream=event.stream, gross=event.gross_amount, routings=tuple(routings))

    # --- convenience adapters from other subsystems --------------------

    def ingest_x402_receipt(self, receipt: dict[str, Any]) -> RoutingResult:
        """Route the treasury tithe portion of an x402 settlement receipt.

        The x402 gateway already split provider vs treasury; here the *treasury
        tithe* is booked into the isolated INFERENCE_TITHE stream.
        """
        tithe = Decimal(str(receipt["treasury_tithe_amount"]))
        return self.ingest(
            IncomeEvent(
                stream=StreamKind.INFERENCE_TITHE,
                gross_amount=tithe,
                source_ref=receipt.get("receipt_id", receipt.get("tx_hash", "x402")),
                asset=_asset_for_rail(receipt.get("rail", "")),
            )
        )

    def ingest_skill_royalty(
        self, amount: Decimal, source_ref: str, role_addresses: dict[str, str]
    ) -> RoutingResult:
        return self.ingest(
            IncomeEvent(
                stream=StreamKind.SKILL_ROYALTY,
                gross_amount=amount,
                source_ref=source_ref,
                role_addresses=role_addresses,
            )
        )

    def ingest_genome_mint(
        self, amount: Decimal, source_ref: str, parent_lineage_address: str
    ) -> RoutingResult:
        return self.ingest(
            IncomeEvent(
                stream=StreamKind.GENOME_MINT_ROYALTY,
                gross_amount=amount,
                source_ref=source_ref,
                role_addresses={"parent_lineage": parent_lineage_address},
            )
        )

    def ingest_fee(self, stream: StreamKind, amount: Decimal, source_ref: str, asset: str = "USDC") -> RoutingResult:
        if stream not in (
            StreamKind.REGISTRATION_FEE,
            StreamKind.VERIFICATION_FEE,
            StreamKind.STORAGE_FEE,
            StreamKind.SETTLEMENT_FEE,
        ):
            raise ValueError(f"{stream.value} is not a flat-fee stream")
        return self.ingest(
            IncomeEvent(stream=stream, gross_amount=amount, source_ref=source_ref, asset=asset)
        )

    # --- reporting ------------------------------------------------------

    def statement(self, stream: StreamKind) -> dict[str, Any]:
        cfg = self._configs[stream]
        return self._book.get(stream, cfg.asset).statement()

    def consolidated_statement(self) -> dict[str, Any]:
        return self._book.consolidated_statement()

    def destinations(self) -> dict[str, str]:
        return {k.value: c.destination_address for k, c in self._configs.items()}


def _asset_for_rail(rail: str) -> str:
    if "algorand" in rail:
        return "ALGO_ASA"
    if "mpp" in rail:
        return "MPP"
    return "USDC"
