"""example_build_all_players.py — build one agent per major player.

Demonstrates the factory end to end with in-memory mock ports. Swap the mocks
for the real mindX subsystems (id_manager_agent, AgenticPlace client, x402
gateway via Parsec, ENS registrar, MCP surface, BONA FIDE) in production.

Run:  python -m agent_builder.example_build_all_players
"""

from __future__ import annotations

import asyncio
from decimal import Decimal
from typing import Any

from agent_builder import AgentBuilder, AgentBuildSpec
from agent_builder.provider_adapter import CompletionRequest


# --------------------------------------------------------------------------
# Mock ports (in-memory; for demonstration only)
# --------------------------------------------------------------------------


class MockVault:
    def __init__(self, secrets: dict[str, str]) -> None:
        self._secrets = secrets

    def resolve(self, credential_id: str) -> str | None:
        return self._secrets.get(credential_id)


class MockIdentityRegistry:
    def __init__(self) -> None:
        self._n = 0

    def mint_identity(self, owner: str, agent_card_uri: str) -> str:
        self._n += 1
        return f"erc8004:agentid:{self._n}"


class MockEns:
    def claim_subname(self, label: str, resolves_to: str) -> str:
        return f"{label}.bankon.eth"


class MockAgenticPlace:
    def __init__(self) -> None:
        self._n = 0

    def register(self, agent_card: dict[str, Any], agent_id: str) -> str:
        self._n += 1
        return f"agenticplace:listing:{self._n}"

    def mint_aorc(self, listing_id: str) -> str:
        return f"aorc:{listing_id}"


class MockX402:
    def bind_endpoint(self, agent_id, price_input_per_token, price_output_per_token,
                      treasury_tithe, treasury_address) -> str:
        return f"https://x402.agenticplace.pythai.net/{agent_id}"

    def settle(self, endpoint_url, usage_input, usage_output) -> dict[str, Any]:
        # illustrative settlement math
        base = Decimal(usage_input) * Decimal("0.000003") + Decimal(usage_output) * Decimal("0.000015")
        tithe = base * Decimal("0.10")
        return {
            "endpoint": endpoint_url,
            "base_usd": str(base),
            "treasury_tithe_usd": str(tithe),
            "rail": "algorand_asa_via_parsec",
        }


class MockMcp:
    def register_tools(self, agent_id: str, tools: list[dict[str, Any]]) -> str:
        return f"mcp://agenticplace.pythai.net/{agent_id}"


class MockBonaFide:
    def initialize_reputation(self, agent_id: str, parent_agent_id: str | None) -> int:
        return 1 if parent_agent_id is None else 3  # inherit a fraction from a parent


# --------------------------------------------------------------------------
# Build one agent per cathedral
# --------------------------------------------------------------------------


def make_builder() -> AgentBuilder:
    vault = MockVault(
        {
            "google_gemini_api_key": "demo",
            "openai_api_key": "demo",
            "anthropic_api_key": "demo",
            "xai_api_key": "demo",
            "ibm_watsonx_api_key": "demo",
        }
    )
    return AgentBuilder(
        credentials=vault,
        identity_registry=MockIdentityRegistry(),
        ens_registrar=MockEns(),
        agenticplace=MockAgenticPlace(),
        x402_gateway=MockX402(),
        mcp_surface=MockMcp(),
        bona_fide=MockBonaFide(),
        treasury_address="0xPYTHAI_TREASURY",
    )


def build_all() -> None:
    builder = make_builder()
    specs = [
        AgentBuildSpec(label="gemini-analyst", provider="google",
                       model_id="gemini-3-pro", owner_address="0xowner"),
        AgentBuildSpec(label="gpt-operator", provider="openai",
                       model_id="gpt-5.5", owner_address="0xowner"),
        AgentBuildSpec(label="claude-research", provider="anthropic",
                       model_id="claude-opus-4-8", owner_address="0xowner"),
        AgentBuildSpec(label="grok-realtime", provider="xai",
                       model_id="grok-5", owner_address="0xowner"),
        AgentBuildSpec(label="granite-compliance", provider="ibm",
                       model_id="granite-4.0-large", owner_address="0xowner",
                       provider_kwargs={"project_id": "demo-project"}),
    ]
    for spec in specs:
        agent = builder.build(spec)
        print(f"built {agent.label:20s} provider={agent.provider:9s} "
              f"native={agent.model.native_protocol.value:20s} "
              f"id={agent.agent_id} ens={agent.ens_name} rep={agent.reputation}")
        print(f"    x402  -> {agent.x402_endpoint}")
        print(f"    mcp   -> {agent.mcp_endpoint}")
        print(f"    aorc  -> {agent.aorc_id}")

    # Neutral-layer move: cross-register a giant's own public agent.
    wrapped = builder.cross_register_external(
        external_agent_card_url="https://some-giant.example/.well-known/agent.json",
        owner_address="0xowner",
        label="external-wrapped",
    )
    print(f"cross-registered external agent -> {wrapped}")


if __name__ == "__main__":
    build_all()
    # Note: invoke() would call the live provider API and settle via x402.
    # Shown here only as the call shape, not executed against real endpoints.
    _ = asyncio.sleep  # silence unused import in demo
    _ = CompletionRequest  # referenced for documentation
