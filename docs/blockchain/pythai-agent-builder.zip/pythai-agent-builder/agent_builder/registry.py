"""registry.py — binds provider names to adapter classes and model catalogues.

Mirrors the mindX provider_registry.json pattern. The AgentBuilder consults
this to instantiate the right adapter for a requested provider/model, so adding
a sixth cathedral later is a one-line registration, not a builder change.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from agent_builder.adapters.anthropic_adapter import ANTHROPIC_MODELS, AnthropicAdapter
from agent_builder.adapters.gemini_adapter import GEMINI_MODELS, GeminiAdapter
from agent_builder.adapters.grok_adapter import GROK_MODELS, GrokAdapter
from agent_builder.adapters.openai_adapter import OPENAI_MODELS, OpenAIAdapter
from agent_builder.adapters.watsonx_adapter import WATSONX_MODELS, WatsonxAdapter
from agent_builder.provider_adapter import CredentialResolver, ModelSpec, ProviderAdapter


@dataclass(frozen=True)
class ProviderBinding:
    provider: str
    adapter_cls: type[ProviderAdapter]
    models: dict[str, ModelSpec]
    # default vault credential id; overridable per build
    default_credential_id: str
    # extra constructor kwargs (e.g. watsonx project_id) keyed by name
    requires: tuple[str, ...] = ()


PROVIDER_REGISTRY: dict[str, ProviderBinding] = {
    "google": ProviderBinding(
        provider="google",
        adapter_cls=GeminiAdapter,
        models=GEMINI_MODELS,
        default_credential_id="google_gemini_api_key",
    ),
    "openai": ProviderBinding(
        provider="openai",
        adapter_cls=OpenAIAdapter,
        models=OPENAI_MODELS,
        default_credential_id="openai_api_key",
    ),
    "anthropic": ProviderBinding(
        provider="anthropic",
        adapter_cls=AnthropicAdapter,
        models=ANTHROPIC_MODELS,
        default_credential_id="anthropic_api_key",
    ),
    "xai": ProviderBinding(
        provider="xai",
        adapter_cls=GrokAdapter,
        models=GROK_MODELS,
        default_credential_id="xai_api_key",
    ),
    "ibm": ProviderBinding(
        provider="ibm",
        adapter_cls=WatsonxAdapter,
        models=WATSONX_MODELS,
        default_credential_id="ibm_watsonx_api_key",
        requires=("project_id",),
    ),
}


def resolve_model(provider: str, model_id: str) -> ModelSpec:
    binding = PROVIDER_REGISTRY[provider]
    if model_id not in binding.models:
        raise KeyError(f"unknown model {model_id!r} for provider {provider!r}")
    return binding.models[model_id]


def instantiate_adapter(
    provider: str,
    credentials: CredentialResolver,
    credential_id: str | None = None,
    **extra: Any,
) -> ProviderAdapter:
    binding = PROVIDER_REGISTRY[provider]
    cid = credential_id or binding.default_credential_id
    for required in binding.requires:
        if required not in extra:
            raise ValueError(f"provider {provider!r} requires {required!r}")
    return binding.adapter_cls(credentials, cid, **extra)
