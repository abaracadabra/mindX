# Agent Builder and Provider Integrations — Design

**Package:** `agent_builder`
**Standard:** Apache 2.0 · snake_case · Python ≥3.12 · no EOA admin keys retained post-mint · no provider lock-in
**Purpose:** A single, provider-agnostic factory that builds sovereign agents wrapping any major model maker (Google/Gemini, OpenAI/GPT, Anthropic/Claude, xAI/Grok, IBM/watsonx) and wires each one into the mindX neutral layer — ERC-8004 identity, ENS subnames under `bankon.eth`, AgenticPlace listing, x402 metering with the PYTHAI treasury tithe, MCP tool surface, and BONA FIDE reputation.

---

## The Core Idea

The design separates two concerns that are usually entangled. A **provider integration** (an adapter) knows only how to talk to one cathedral: its wire format, its native interop protocol, and its token pricing. The **agent builder** knows only how to wire any adapter into the neutral layer. Because the builder never learns which provider is behind an adapter, adding a sixth cathedral later is a single registry entry, not a builder change. This is the same separation that lets mindX be the bazaar rather than a sixth cathedral: the value mindX adds is the wiring, not the model.

Every adapter conforms to one contract, `ProviderAdapter`, which normalizes exactly three things that differ across providers. The first is transport and request/response shape — the Gemini `generateContent` REST body is nothing like the Anthropic Messages API, which is nothing like the watsonx two-step IAM exchange, yet all of them resolve to the same `CompletionResponse`. The second is the native interop protocol, recorded as a `ProviderProtocol` enum so the published AgentCard can advertise it: A2A for Gemini because Google authored A2A, MCP for Claude because Anthropic authored MCP, ACP for GPT because OpenAI built it with Stripe, OpenAI-compatible for Grok, and watsonx Orchestrate for Granite. The third is token pricing, returned as `Decimal` per-token amounts so the x402 gateway can meter each call deterministically and apply the treasury tithe on top.

Credentials are deliberately not held inside any adapter. Each adapter holds only a credential *id* and resolves the actual secret at call time from the BANKON Vault through a `CredentialResolver`. This is the enforcement boundary discussed in the market-share analysis: a forked node that strips the tithe but lacks vault access simply cannot transact, because the secret never lived in the forkable code.

## The Five Integrations

Each adapter is a focused module that implements only the provider-specific delta. The **Gemini adapter** translates normalized messages into Gemini `contents`, handles the `functionCall` parts in responses, and advertises A2A as its native lane — which matters because Google's own AP2 payment protocol settles crypto through x402, the same rail mindX uses. The **Anthropic adapter** splits the system prompt out of the message list as the Messages API requires, handles `tool_use` content blocks, and advertises MCP, the protocol mindX consumes directly elsewhere in the stack. The **OpenAI adapter** uses the Chat Completions shape, parses `tool_calls` with JSON-decoded arguments, and advertises ACP, noting that cross-vendor settlement is bridged to x402 rather than routed through Stripe. The **Grok adapter** reuses the OpenAI-compatible wire format against the xAI base URL and adds an opt-in live-X-search parameter, advertising the real-time social signal as Grok's differentiator. The **watsonx adapter** is the most distinct: it performs a two-step IAM token exchange, requires a `project_id`, flattens messages into a single prompt as the text-generation API expects, and uniquely exposes a `governance_attestation` method so the Boardroom can record a lineage record in the Gödel audit journal — the neutral-layer equivalent of watsonx.governance.

## The Builder's Nine Steps

When `AgentBuilder.build(spec)` runs, it resolves the model and instantiates the correct adapter through the registry, then assembles an A2A-style AgentCard describing the agent's skills, its native protocol, and the universal MCP and x402 capabilities mindX adds. It mints an ERC-8004 identity against the live IdentityRegistry, claims an ENS subname under `bankon.eth`, registers the agent in AgenticPlace, and mints an aORC verification NFT. It then binds a metered x402 endpoint carrying the provider's per-token pricing and the PYTHAI treasury tithe, exposes the agent's tools over MCP, and seeds BONA FIDE reputation — inheriting a fraction when the agent is minted from a parent genome, which is the hook for the replication-and-payment model.

The builder depends only on small `Protocol` ports rather than concrete chain clients, so it is fully testable with in-memory mocks (see `example_build_all_players.py`, which builds all five agents and cross-registers an external one) and free of coupling to any specific wallet or RPC implementation. In production these ports are satisfied by the real mindX subsystems: the ID Manager Agent for identity, the AgenticPlace client, the Parsec/GoPlausible x402 gateway, the ENS registrar, the MCP surface, and the BONA FIDE Dojo.

## The Neutral-Layer Method

Beyond building first-party agents, the builder exposes `cross_register_external`, which implements the Switzerland strategy directly. Given the public A2A AgentCard URL of a giant's own agent, it mints an ERC-8004 identity wrapping that agent and lists it in AgenticPlace — without the giant's permission and beyond its ability to revoke, because the identity is anchored on Ethereum rather than in the giant's account system. This is the mechanism by which AgenticPlace becomes the one registry where every cathedral's agents appear as peers, which no cathedral can offer because each would have to neutrally host its rivals.

## Files

The package contains the interface (`provider_adapter.py`), the factory (`agent_builder.py`), the provider binding (`registry.py`), the five adapters under `adapters/`, a runnable example (`example_build_all_players.py`), and the package init. The example runs against in-memory mocks and prints a built agent per provider plus a cross-registered external agent; replacing the mock ports with the live mindX subsystems is the only step required to move from demonstration to mainnet.

## Integration Points With the Existing Roadmap

This package satisfies several tasks already in `complete.roadmap.md`. It is the implementation behind the Workstream 4 agent registration and listing tasks, the Workstream 8 cross-registration wrapper, and the x402 binding in Workstream 3. The adapters populate the provider registry referenced in Workstream 0, and the watsonx governance attestation feeds the Gödel audit journal in Workstream 7. The one new dependency it introduces is a treasury-routing parameter on the x402 endpoint, which is already present in the `X402GatewayPort.bind_endpoint` signature and corresponds to the per-invocation tithe described in the replication-and-payment analysis.

— Professor Codephreak
