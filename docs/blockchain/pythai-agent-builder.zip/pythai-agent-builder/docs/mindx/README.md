# mindX Documentation

This directory contains the mindX strategy and architecture documentation that accompanies the `pythai-agent-builder` implementation. It is written to be read in order by an engineer who intends to understand the strategy and then deploy the coordination layer.

## Read in this order

1. **[MINDX_STRATEGY.md](MINDX_STRATEGY.md)** — the affirmative doctrine. Compete on position not capital; give away the kernel and sell the network; replicate by consent and collect at the boundary you operate; reach density before the category is contested.

2. **[TRILLION_DOLLAR_BETS.md](TRILLION_DOLLAR_BETS.md)** — the competitive landscape. How mindX positions against the silicon tier (Nvidia, AMD, Micron) and the model tier (Google, OpenAI, Anthropic, xAI, IBM), and why the neutral layer is structurally uncapturable by any of them.

3. **[ARCHITECTURE.md](ARCHITECTURE.md)** — the four-layer system: cognitive substrate, orchestration tier, governance layer, economic substrate, and the dual-chain mesh.

4. **[IDENTITY_AND_REPUTATION.md](IDENTITY_AND_REPUTATION.md)** — ERC-8004 identity, BONA FIDE constitutional reputation, ENS subnames, cross-registration, and provenance.

5. **[AGENTICPLACE.md](AGENTICPLACE.md)** — the registry as a commons, the provider-agnostic agent builder, and the five provider integrations.

6. **[X402_AND_BAZAAR.md](X402_AND_BAZAAR.md)** — the x402 triple rail and the bazaar's isolated income streams.

7. **[GOVERNANCE.md](GOVERNANCE.md)** — the DAIO: Boardroom, Dojo, constitution, and War Council.

8. **[CLIENT_INTEGRATION.md](CLIENT_INTEGRATION.md)** — the mocks-to-mainnet client layer: backend-backed ports, the assembly factory, and the optional direct-EVM read client.

9. **[COMPLETE_ROADMAP.md](COMPLETE_ROADMAP.md)** — the dependency-ordered task plan across all workstreams, with no time measures.

## Canonical references

The live mindX documentation is published at [mindx.pythai.net/docs.html](https://mindx.pythai.net/docs.html). The essays in this directory are prepared for publication at [rage.pythai.net](https://rage.pythai.net). The marketplace is [agenticplace.pythai.net](https://agenticplace.pythai.net).

— Professor Codephreak. Apache-2.0 throughout.
