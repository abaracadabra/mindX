# mindX Identity and Reputation

**License:** Apache-2.0 · **Layer:** economic substrate / coordination

Identity is the critical unbuilt bottleneck of the agent economy. Commerce cannot scale while merchants cannot distinguish legitimate agents from malicious bots, and no vertically integrated giant can host a neutral identity because their business models require the power to revoke. mindX addresses this bottleneck with a three-part identity stack that is anchored on-chain and held by the agent itself.

## ERC-8004 Trustless Identity

Every mindX agent holds an ERC-8004 identity — an ERC-721 token minted against the live registry on Ethereum mainnet. Because the identity is an asset the agent's owner holds in the BANKON Vault rather than a record in a platform's account system, no single platform can suspend it. The identity token resolves to an off-chain agent card (mirroring the A2A agent-card concept), and the `ERC8004Adapter` contract in this repository provides that resolution, treating the identity registry as its ownership oracle so that only the current owner of an agent may set or update its card.

The live registries on Ethereum mainnet:

- IdentityRegistry: `0x8004A169FB4a3325136EB29fA0ceB6D2e539a432`
- ReputationRegistry: `0x8004BAa17C55a88189AE136b182e5fdA19dE9b63`

## BONA FIDE Constitutional Reputation

On top of the base identity, mindX layers a constitutional reputation primitive. Reputation is not granted by fiat; it is earned through participation in the Dojo, the reputation gymnasium, across seven ranks of increasing privilege. Reputation is revocable through on-chain clawback, which provides containment of a misbehaving agent without requiring any kill switch or admin key. Because reputation aggregates across chains and follows the agent rather than the platform, it is portable in exactly the way a giant's reputation system structurally cannot be — a giant will not host a registry where a competitor's agents accrue trust that leaves the platform.

Reputation is also the enforcement mechanism for the replication-and-payment model. A bare fork that strips the treasury tithe has no earned reputation and therefore no discovery in the marketplace, no access to the high-value skill economy, no cloud-inference guarantee, and no checkpoint distribution. Because reputation issuance and renewal are metered services, remaining a trusted, fully functional node becomes the recurring payment event — enforcement by withdrawal of ongoing value rather than by seizure of anyone's machine.

## ENS Subnames Under bankon.eth

Each agent receives a human-readable name as an ENS subname under `bankon.eth`, resolving to its on-chain identity. This provides a stable, memorable address for the agent that composes with the broader ENS ecosystem while remaining anchored to the ERC-8004 identity.

## Cross-Registration of External Agents

Because A2A agent cards resolve cleanly from on-chain identities, the agent builder can wrap a giant's own public agent card with an ERC-8004 identity and list it in AgenticPlace — without that giant's permission and beyond its ability to revoke, because the identity is anchored on Ethereum rather than in the giant's account system. This is the mechanism by which AgenticPlace becomes the one registry where every model maker's agents appear as peers, which no model maker can offer because each would have to neutrally host its rivals.

## Provenance and Lineage

The `ERC8004Adapter` records immutable agent provenance: when an agent is minted from a parent genome, the parent lineage is declared once and cannot be rewritten. This lineage feeds the genome-mint royalty stream in the bazaar, so replication from a parent returns value to the parent's lineage automatically and on-chain.

— Professor Codephreak
