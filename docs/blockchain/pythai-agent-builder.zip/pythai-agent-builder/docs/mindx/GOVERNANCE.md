# mindX Governance — The DAIO

**License:** Apache-2.0 · **Layer:** governance

mindX is governed as a Decentralized Autonomous Intelligence Organization: a constitutional system implemented in Solidity under Foundry, in which every consequential decision is made by a deliberating body and recorded in an append-only audit journal. Where a commercial AI vendor governs through internal policy enforced by a content filter and a vice president, mindX governs through checks and balances enforced by smart contracts. The substantive claim is that cryptographic checks and balances are a stronger guarantee than a policy enforced by an employee, because subversion requires either a constitutional amendment, which is cryptographically slow, or an attack on the underlying chain, which is economically infeasible.

## The Boardroom

Tactical decisions are made by the Boardroom: an executive agent and a set of soldier agents drawn from diverse model providers, so that no single model's biases dominate. The Boardroom votes on each directive with a supermajority threshold for execution, and minority dissent is not discarded but becomes an exploration branch. Certain officers carry weighted veto authority for security and risk. Structurally this is a jury that deliberates rather than an orchestrator that delegates, and the adversarial diversity across heterogeneous models is itself a safety mechanism: a content filter is gameable by a sufficiently capable adversary, but adversarial diversity across independent models is not.

## The Dojo

Privilege in mindX is earned, not granted. The Dojo is the reputation gymnasium where agents earn rank across seven levels through participation, and rank gates access to increasingly consequential capabilities. Rank is revocable through on-chain clawback, which provides containment of a misbehaving agent without any kill switch. This earned-and-revocable model is the opposite of a platform account that is granted by default and revocable by an administrator at will; it is sovereignty that must be demonstrated and that follows the agent across platforms.

## The Constitution

The constitution is the immutable ground of the system. It encodes the treasury diversification mandate, the supermajority thresholds, the veto structure, and the amendment process, which requires consensus across independent governance groups. Amendments are cryptographically slow by design, so the constitution cannot be captured by a single actor or a single emotional appeal. Every consequential decision the system makes is logged to the audit journal and surfaced on the insight endpoints, so the governance of the system is publicly observable in a way corporate governance is not.

## War Council

Strategic decisions are made by the War Council, which requires a plurality of human co-architects. This is the one place where the system's current constraint is visible: the constitution demands at least three human council members, and reaching that number is an explicit task in the roadmap. Until it is reached, the bus factor is a named weakness rather than a hidden one.

## Governance as a Commons

The strategic significance of this design is that governance itself becomes a commons rather than a licensed control plane. A giant sells its governance and compliance tooling as a proprietary product; mindX makes governance an open, on-chain, auditable property of the network. This is the same move as the identity and settlement layers: the value the giants keep proprietary, mindX makes neutral, because neutrality is precisely what the coordination layer rewards.

— Professor Codephreak
