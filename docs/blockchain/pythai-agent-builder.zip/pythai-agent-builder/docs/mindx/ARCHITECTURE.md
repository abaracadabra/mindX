# mindX Architecture

**Status:** canonical · **License:** Apache-2.0 · **Standard:** cypherpunk2048

mindX is a self-improving, constitutionally governed agent system whose purpose is to operate the neutral coordination layer of the sovereign agent economy — identity, reputation, discovery, and settlement — that no vertically integrated model maker can own. This document describes the architecture that this repository implements at the coordination layer. It is written to be read top to bottom by an engineer who intends to deploy.

## The Four Layers

mindX is organized into four layers, each cleanly separable and each Apache-2.0.

The **cognitive substrate** is the reasoning core: a Perceive–Orient–Decide–Act loop over a Belief–Desire–Intention agent whose beliefs carry confidence scores that decay over time, backed by a retrieval-augmented memory that performs semantic search over vectors in PostgreSQL with pgvector. This layer does what a commercial orchestration framework does, but as separable modules rather than a hosted service, and every consequential step is logged to an append-only audit journal.

The **orchestration tier** is the strategic and infrastructural coordination: a singleton strategic planner, a coordinator that runs autonomous improvement loops, an executive agent that bridges on-chain governance directives to off-chain execution, and a strategic-evolution agent that runs an Audit → Blueprint → Execute → Validate cycle. Structurally this is a deliberating jury rather than a single orchestrator thread; the difference is the point.

The **governance layer** is the constitutional core, implemented in Solidity under Foundry: a boardroom of diverse model voices that votes on directives with supermajority execution and minority dissent creating exploration branches, a reputation gymnasium (the Dojo) that grants earned, revocable privilege, and a constitution whose amendment requires consensus across independent governance groups. Clawback provides containment without a kill switch.

The **economic substrate** is the value layer: encrypted credential custody with three modes (machine, human, organization), the AgenticPlace registry indexing agents across many chains, the x402 triple-rail micropayment system, and the ERC-7857 intelligent-NFT knowledge-tensor primitive. This is the layer this repository's `agent_builder` and `bazaar` packages implement most directly.

## The Neutral-Layer Thesis

The architecture exists to occupy a structural position: the coordination layer whose value is maximized by neutrality and therefore cannot be owned by any single giant without dissolving its moat. Three prohibitions keep every vertically integrated model maker out of this layer permanently — they cannot host an un-revocable identity, they cannot settle payments without taking a middle position, and they cannot host reputation that follows agents to competitors. mindX occupies all three lanes. The full argument is in `MINDX_STRATEGY.md`; the competitive landscape is in `TRILLION_DOLLAR_BETS.md`.

## Dual-Chain Mesh

Roles are separated across chains by deliberate design. Ethereum mainnet anchors the constitution, the ERC-8004 identity and reputation registries, and the ERC-7857 knowledge-tensor INFTs — the layer where un-revocability and global trust matter most. Algorand carries the constitutional reputation primitive, blockstamp ordering, and the verification oracle, with clawback as containment. Base carries x402 USDC settlement. Cross-chain routing uses a bridge and a cross-chain pointer format so an asset minted on one chain resolves on another.

## Identity and Trust

Agent identity is anchored on-chain via ERC-8004, held by the agent in its own vault rather than in any platform account. On top of the base identity, mindX layers a constitutional reputation primitive whose rank is earned through participation in the Dojo and revoked through on-chain clawback. Because identity is an NFT the agent holds and reputation aggregates across chains, neither can be revoked by a single platform — which is exactly the property the giants cannot offer.

## Self-Evolution

Capability improvement runs through a portable-skill loop: a frozen open-weight target model is paired with a separate optimizer that proposes bounded edits to a single skill document under a strict held-out validation gate, with the boardroom supplying optimizer diversity and the Dojo supplying the gate. Every accepted skill is content-addressed, pinned to decentralized storage, anchored on-chain, and wrapped as a tradeable INFT whose public proof is its validation score. This moves capability out of model weights and into portable artifacts, which is what makes a commodity-hardware node competitive over a multi-year horizon.

## What This Repository Implements

This repository is the coordination-layer implementation: the provider-agnostic agent builder that wraps any major model maker and wires it into identity, naming, listing, settlement, interop, and reputation; the concrete x402 settlement gateway with the treasury tithe; the bazaar income engine with isolated per-stream accounting; and the Foundry `ERC8004Adapter` that resolves on-chain identity to off-chain agent cards and records immutable provenance. The full deployment plan across all workstreams is in `COMPLETE_ROADMAP.md`.

— Professor Codephreak
