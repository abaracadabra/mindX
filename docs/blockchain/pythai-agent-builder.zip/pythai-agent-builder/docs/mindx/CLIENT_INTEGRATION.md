# From Mocks to Mainnet — The Client Layer

**License:** Apache-2.0 · **Layer:** integration

The agent builder, the x402 gateway, and the bazaar all depend on small `Protocol` ports rather than concrete infrastructure, which is what lets them be tested against in-memory mocks. The `agent_builder.clients` package provides the concrete implementations of those ports, so the same code that runs against mocks in the test suite runs against the live mindX backend in production. This document describes that client layer and the single command that assembles the live system.

## The Faithful Integration Path

The concrete clients are HTTP clients against the mindX backend API rather than direct chain-signing code, and this is deliberate. The backend holds the BANKON Vault and the chain infrastructure, so on-chain minting is performed backend-side by the ID Manager Agent and returned to the builder. No private key ever reaches the Python process. This matches the architecture — the vault is the custody boundary — and it means a node running this package cannot leak key material even if compromised, because it never holds any.

Every port has a concrete client. The `VaultCredentialResolver` resolves provider API keys from the vault at call time, with a development-only local fallback. The `IdentityRegistryClient` delegates ERC-8004 minting to the backend and returns the on-chain AgentID. The `EnsRegistrarClient` claims subnames under `bankon.eth`. The `AgenticPlaceClient` registers agents and mints verification NFTs. The `McpSurfaceClient` registers agent tools as MCP. The `BonaFideClient` seeds constitutional reputation. For settlement, the `VaultSigner` asks the vault to authorize each payment and the `BackendFacilitator` brokers the rail-specific settlement, so the x402 gateway signs and settles without holding keys.

All of these are built on a shared `BackendClient` that provides bearer authentication, bounded retries with backoff on transient failures, and a single `BackendError` type so callers handle backend failures uniformly. Because the client accepts an injectable httpx transport, the entire integration is testable offline with `httpx.MockTransport`, which is exactly how the client test suite verifies the end-to-end build without touching the network.

## The Assembly Factory

The `build_agent_builder`, `build_x402_gateway`, and `build_bazaar` functions take a `MindxClientConfig` and return the fully wired live objects. Configuration is read from environment variables, and the stream address book enforces isolation at assembly time: every bazaar income stream must have its own distinct destination address, and the factory rejects any configuration that violates this. The `example_production_wiring.py` script demonstrates the assembly from environment and prints the wired configuration; setting `MINDX_LIVE=1` builds an agent against the live backend.

The practical consequence is that moving from demonstration to mainnet is a configuration task, not a code change. Set the `MINDX_*` and `STREAM_*` environment variables per `.env.example`, call `build_agent_builder(config)`, and the builder mints real identities, claims real subnames, lists in the real registry, and settles real payments — with the isolated income streams routing revenue to their dedicated destinations.

## Optional Direct-Chain Reads

For operators who want to verify chain state without the backend, the `evm_chain` module provides a read-only JSON-RPC client and a minimal, correct ABI codec for the exact calls the identity layer uses: `ownerOf` on the ERC-8004 IdentityRegistry, and `resolve` and `parentOf` on this repository's `ERC8004Adapter`. Function selectors are computed at runtime from a keccak backend, so they are correct by construction rather than hardcoded. This module is read-only by design; state-changing operations remain backend-brokered so that signing always passes through the vault. It requires the optional `chain` extra: `pip install -e .[chain]`.

## Test Coverage

The client layer is covered by a dedicated suite that runs the full agent build against a mocked backend, verifies parent-genome reputation inheritance and external cross-registration through the backend, settles an x402 payment through the mocked vault and facilitator, confirms the stream isolation enforced by the assembly factory, and validates the ABI codec including that the computed function selectors match the known keccak values. The suite is fully offline and deterministic.

— Professor Codephreak
