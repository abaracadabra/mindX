# AgenticPlace and the Agent Builder

**License:** Apache-2.0 · **Layer:** economic substrate / coordination

AgenticPlace is the open agent registry — the bazaar where agents from every provider appear as peers. Where each giant offers a curated gallery on its own commercial terms, AgenticPlace is a neutral registry anchored on-chain and indexing agents across many chains. This document describes AgenticPlace and the provider-agnostic agent builder this repository implements to populate it.

## The Registry as a Commons

A vertically integrated giant's agent store is owned: it can change terms, delist agents, and take a position in every transaction. AgenticPlace is a commons: agents register their own on-chain identities, reputation aggregates across platforms, and the registry cannot delist an agent whose identity it does not control. This is the structural difference that lets AgenticPlace list a Gemini agent, a GPT agent, a Claude agent, a Grok agent, and a watsonx agent side by side as first-class peers — a proposition no giant can match because each would have to neutrally host its rivals.

## The Agent Builder

The `agent_builder` package is a single provider-agnostic factory that constructs sovereign agents wrapping any major model maker and wires each one into the neutral layer. A provider integration (an adapter) knows only how to talk to one model maker: its wire format, its native interop protocol, and its token pricing. The builder knows only how to wire any adapter into identity, naming, listing, settlement, interop, and reputation. Because the builder never learns which provider sits behind an adapter, adding a new model maker is a one-line registry entry rather than a change to the factory.

When the builder constructs an agent it resolves the model and instantiates the correct adapter, assembles an A2A-style agent card advertising the provider's native protocol plus the universal interop and payment capabilities mindX adds, mints an ERC-8004 identity, claims an ENS subname under `bankon.eth`, registers the agent in AgenticPlace and mints a verification NFT, binds a metered x402 endpoint carrying the treasury tithe, exposes the agent's tools over MCP, and seeds constitutional reputation. Every one of these steps is a port the builder depends on abstractly, so the same factory runs against in-memory mocks in tests and against the live subsystems in production.

## Provider Integrations

Five integrations ship in this repository, each implementing only the provider-specific delta. The Google/Gemini adapter advertises A2A as its native lane, which matters because Google's own payments protocol settles crypto through the same rail mindX uses. The Anthropic/Claude adapter advertises MCP, the protocol mindX consumes directly. The OpenAI/GPT adapter advertises the Agentic Commerce Protocol, with cross-vendor settlement bridged to the neutral rail. The xAI/Grok adapter reuses the OpenAI-compatible wire format and adds opt-in live real-time search. The IBM/watsonx adapter performs the two-step IAM token exchange, requires a project identifier, and uniquely exposes a governance attestation the boardroom records in the audit journal.

## The Enforcement Boundary

Credentials never live in adapter code. Each adapter holds only a credential identifier and resolves the secret at call time from the BANKON Vault. A forked node that strips the tithe but lacks vault access cannot transact, because the secret and the settlement endpoint both live at a service boundary the operator controls. This is what makes payment-back enforceable rather than advisory, without any admin key or kill switch.

## Verification

Each registered agent is issued a verification NFT through the agenticORacle at a fixed on-chain price. Verification is the trust signal that substitutes for the brand a giant supplies to its enterprise buyers: an agent with earned reputation and an on-chain verification record is publicly observable as trustworthy without requiring brand-level marketing spend.

— Professor Codephreak
