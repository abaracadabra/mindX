# x402 Payments and the Bazaar

**License:** Apache-2.0 · **Layer:** economic substrate / settlement

Payment is the second unbuilt bottleneck of the agent economy. A neutral settlement layer must let any agent pay any other without the platform taking a middle position, yet platform billing exists precisely to be in the middle. When a giant needs permissionless on-chain settlement it points at a neutral protocol rather than cannibalize its own commerce. mindX is native to that neutral protocol. This document describes the x402 settlement gateway and the bazaar income engine this repository implements.

## The x402 Triple Rail

The `X402Gateway` implements HTTP 402 settlement across three rails: Base USDC, Algorand ASA through the Parsec substrate, and Tempo MPP. Amounts are computed with decimal arithmetic and quantized to each rail's smallest unit before settlement. The gateway binds a metered endpoint for each agent carrying the provider's per-token pricing, the treasury tithe fraction, and the treasury address; at settlement it computes the base cost from token usage, applies the tithe, splits the result between the agent provider and the treasury, and delegates signing to the BANKON Vault so no key material lives in the gateway. The provider-versus-treasury split happens here, at a service boundary the operator controls, which is what makes the tithe enforceable.

## The Bazaar: Isolated Income Streams

The bazaar is the marketplace settlement engine, and its defining principle is isolation: every source of revenue is a separate stream with its own dedicated destination address, its own append-only ledger, and its own split policy. Streams never commingle. A compromised or disputed stream cannot corrupt the accounting of any other stream, and every payout is traceable to the event that produced it.

Eight isolated streams ship in this repository. The inference tithe stream books the treasury portion of every paid agent invocation. The skill royalty stream books ERC-7857 royalties on skill invocation, split 40/30/20/10 across developer, system, governance, and treasury. The genome mint royalty stream books replication royalties, routing the developer share to the parent lineage. The registration, verification, storage, and settlement fee streams book their respective flat fees whole to the treasury. The marketing revenue stream applies the 99/1 buyback rule.

## Conservation and Auditability

The bazaar guarantees three properties. Isolation is enforced at configuration time: no two streams may share a destination address, and the builder rejects any configuration that violates this. Conservation is enforced at settlement: split amounts always sum back to the gross, with any rounding dust assigned deterministically to the last role so nothing is lost. Auditability is enforced by construction: every credit is an append-only ledger entry carrying a source reference, so any payout traces to its originating event. The consolidated statement reports every stream separately and offers a grand total only as an informational figure, explicitly noting that funds remain isolated per stream rather than pooled.

## Why Isolation Matters Strategically

Isolated income streams are the accounting expression of the sovereignty thesis. Because each stream is separately routed and separately ledgered, the constitution can apply different policies to different revenue sources, the treasury can reason about each stream independently, and an audit can verify each stream in isolation. This is treasury hygiene as a first-class property rather than an afterthought, and it is what allows the DAIO to make governance decisions about revenue with full transparency. It also directly supports the replication-and-payment model: the genome mint and skill royalty streams are the rails through which value returns to PYTHAI from replicas in the wild, and keeping them isolated makes that return auditable.

— Professor Codephreak
