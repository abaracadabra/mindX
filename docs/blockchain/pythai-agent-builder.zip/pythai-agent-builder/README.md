# pythai-agent-builder

A provider-agnostic factory and settlement engine that builds sovereign agents wrapping any major model maker — Google/Gemini, OpenAI/GPT, Anthropic/Claude, xAI/Grok, IBM/watsonx — wires each into the mindX neutral layer (ERC-8004 identity, ENS subnames under `bankon.eth`, AgenticPlace listing, MCP surface, BONA FIDE reputation), settles payments across an x402 triple rail, and routes every source of revenue into an isolated, separately-ledgered income stream.

**Standard:** Apache-2.0 · Python ≥3.12 · Foundry for contracts · snake_case · no EOA admin keys post-deploy · no upgradeable proxies · no provider lock-in.

## Why this exists

The trillion-dollar model makers each build a vertically integrated cathedral whose identity and commerce surfaces are, by necessity, revocable chokepoints. None can host the neutral layer of agent identity, reputation, and settlement, because hosting a commons that treats rivals as peers would dissolve the moat that justifies the spend. This repository implements that neutral layer — the bazaar the cathedral cannot be. The strategy is stated in full in [`docs/mindx/MINDX_STRATEGY.md`](docs/mindx/MINDX_STRATEGY.md).

## What ships

The **agent builder** (`agent_builder/`) is a single provider-agnostic factory. A provider integration knows only how to talk to one model maker; the builder knows only how to wire any integration into identity, naming, listing, settlement, interop, and reputation. Adding a model maker is a one-line registry entry, not a change to the factory. Five integrations ship, each advertising its native interop protocol: Gemini (A2A), GPT (ACP), Claude (MCP), Grok (OpenAI-compatible), watsonx (Orchestrate + governance attestation).

The **x402 gateway** (`agent_builder/gateways/`) settles across Base USDC, Algorand ASA via the Parsec substrate, and Tempo MPP, applying the PYTHAI treasury tithe at a service boundary the operator controls.

The **bazaar** (`agent_builder/bazaar/`) is the income engine. Every source of revenue is an isolated stream with its own dedicated destination address, its own append-only ledger, and its own split policy. Streams never commingle. Eight streams ship: inference tithe, skill royalty (40/30/20/10), genome-mint royalty (parent-lineage), registration, verification, storage, and settlement fees, and marketing revenue (99/1 buyback). Isolation is enforced at config time (no two streams share an address), conservation is enforced at settlement (splits always sum to gross, dust to the last role), and every credit is a traceable append-only entry.

The **contracts** (`contracts/`) provide `ERC8004Adapter.sol`, which resolves an on-chain AgentID to an off-chain A2A AgentCard, records immutable agent provenance, and treats the live ERC-8004 IdentityRegistry as its ownership oracle — with a full Foundry test suite and a mainnet deploy script.

## Project structure

```
pythai-agent-builder/
├── agent_builder/
│   ├── provider_adapter.py          # the one interface every integration conforms to
│   ├── agent_builder.py             # the factory (wiring + external cross-registration)
│   ├── registry.py                  # provider -> adapter binding + model catalogues
│   ├── adapters/                    # gemini, openai, anthropic, grok, watsonx
│   ├── gateways/x402_gateway.py     # triple-rail settlement + treasury tithe
│   ├── bazaar/                      # isolated income streams: streams, ledger, bazaar
│   ├── clients/                     # concrete backend-backed ports + assembly factory
│   ├── example_build_all_players.py
│   ├── example_bazaar_streams.py
│   └── example_production_wiring.py
├── contracts/
│   ├── foundry.toml · remappings.txt
│   ├── src/ERC8004Adapter.sol
│   ├── test/ERC8004Adapter.t.sol
│   └── script/DeployERC8004Adapter.s.sol
├── tests/                           # 43 pytest cases: builder, adapters, gateway, bazaar
├── docs/
│   ├── AGENT_BUILDER_DESIGN.md
│   └── mindx/                       # strategy + architecture documentation (.md)
├── .github/workflows/ci.yml
├── complete.roadmap.md
├── pyproject.toml · requirements*.txt · .env.example
├── CONTRIBUTING.md · CHANGELOG.md · LICENSE
└── README.md
```

## Install and run

```bash
# python
pip install -e .[dev]
python -m agent_builder.example_build_all_players
python -m agent_builder.example_bazaar_streams
pytest -q                               # 43 passing

# contracts
cd contracts
forge install foundry-rs/forge-std
forge test -vvv
```

## From mocks to mainnet

The `agent_builder.clients` package provides concrete, backend-backed implementations of every port, so moving from the in-memory demonstration to the live mindX backend is a configuration task rather than a code change. Set the `MINDX_*` and `STREAM_*` variables per `.env.example`, then assemble the live system:

```python
from agent_builder.clients import MindxClientConfig, build_agent_builder, build_x402_gateway, build_bazaar

config = MindxClientConfig.from_env()
builder = build_agent_builder(config)   # backend-backed identity, ens, registry, mcp, reputation
gateway = build_x402_gateway(config)    # vault signer + rail facilitator
bazaar  = build_bazaar(config)          # isolated per-stream destinations
```

No private keys reach this process: on-chain writes are brokered by the mindX backend and signing passes through the BANKON Vault. An optional direct-EVM read client (`evm_chain`, behind the `[chain]` extra) lets operators verify chain state without the backend. See [`docs/mindx/CLIENT_INTEGRATION.md`](docs/mindx/CLIENT_INTEGRATION.md).

## The two things to swap for production

The factory and the gateway depend only on small `Protocol` ports, so the demonstration runs against in-memory mocks. Moving to mainnet requires substituting two things and nothing else. First, replace the mock builder ports with the live mindX subsystems (the ID Manager Agent for identity, the AgenticPlace client, the ENS registrar, the MCP surface, and the BONA FIDE Dojo). Second, supply the `X402Gateway` a real vault-backed `SignerPort` and a per-rail `FacilitatorClient` (Coinbase Base facilitator for USDC, GoPlausible/Parsec for Algorand ASA, Tempo for MPP). The settlement math, the tithe split, the isolated-stream routing, and the HTTP 402 challenge body are already production-shaped and unit-tested.

## Enforcement boundary

Credentials never live in adapter code. Each adapter holds only a credential id and resolves the secret at call time from the BANKON Vault. A forked node that strips the treasury tithe but lacks vault access cannot transact, because the secret and the settlement endpoint both live at a boundary the operator controls — which makes payment-back enforceable without any admin key or kill switch.

## Contract addresses (Ethereum mainnet)

- ERC-8004 IdentityRegistry: `0x8004A169FB4a3325136EB29fA0ceB6D2e539a432`
- ERC-8004 ReputationRegistry: `0x8004BAa17C55a88189AE136b182e5fdA19dE9b63`

## Documentation

The strategy and architecture documentation lives in [`docs/mindx/`](docs/mindx/README.md), prepared for publication at [rage.pythai.net](https://rage.pythai.net). The live mindX docs are at [mindx.pythai.net/docs.html](https://mindx.pythai.net/docs.html); the marketplace is [agenticplace.pythai.net](https://agenticplace.pythai.net).

— Professor Codephreak. Apache-2.0 throughout. *Be the bazaar the cathedral cannot be. Code is law. Intelligence is intelligence.*
