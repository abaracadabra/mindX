"""tests/test_adapters.py — per-adapter normalization against mocked transport.

These tests verify that each adapter correctly translates a provider's wire
response into the normalized CompletionResponse, without making network calls.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from agent_builder.adapters.anthropic_adapter import ANTHROPIC_MODELS, AnthropicAdapter
from agent_builder.adapters.gemini_adapter import GEMINI_MODELS, GeminiAdapter
from agent_builder.adapters.grok_adapter import GROK_MODELS, GrokAdapter
from agent_builder.adapters.openai_adapter import OPENAI_MODELS, OpenAIAdapter
from agent_builder.adapters.watsonx_adapter import WATSONX_MODELS, WatsonxAdapter


class FakeVault:
    def resolve(self, credential_id: str) -> str | None:
        return "key"


def test_gemini_response_normalization():
    a = GeminiAdapter(FakeVault(), "google_gemini_api_key")
    data = {
        "candidates": [
            {"content": {"parts": [{"text": "hello"}, {"functionCall": {"name": "f", "args": {"x": 1}}}]}}
        ],
        "usageMetadata": {"promptTokenCount": 10, "candidatesTokenCount": 5},
    }
    resp = a._from_gemini(data, GEMINI_MODELS["gemini-3-pro"])
    assert resp.text == "hello"
    assert resp.tool_calls[0].name == "f"
    assert resp.tool_calls[0].arguments == {"x": 1}
    assert resp.usage.input_tokens == 10
    assert resp.usage.output_tokens == 5
    assert resp.usage.total_tokens == 15


def test_anthropic_response_normalization():
    a = AnthropicAdapter(FakeVault(), "anthropic_api_key")
    data = {
        "content": [
            {"type": "text", "text": "hi"},
            {"type": "tool_use", "id": "t1", "name": "lookup", "input": {"q": "z"}},
        ],
        "usage": {"input_tokens": 7, "output_tokens": 3},
    }
    resp = a._from_anthropic(data, ANTHROPIC_MODELS["claude-opus-4-8"])
    assert resp.text == "hi"
    assert resp.tool_calls[0].name == "lookup"
    assert resp.tool_calls[0].call_id == "t1"
    assert resp.usage.total_tokens == 10


def test_anthropic_splits_system_prompt():
    a = AnthropicAdapter(FakeVault(), "anthropic_api_key")
    system, msgs = a._split_system(
        [
            {"role": "system", "content": "be terse"},
            {"role": "user", "content": "hello"},
        ]
    )
    assert system == "be terse"
    assert msgs == [{"role": "user", "content": "hello"}]


def test_openai_response_normalization():
    a = OpenAIAdapter(FakeVault(), "openai_api_key")
    data = {
        "choices": [
            {
                "message": {
                    "content": "ok",
                    "tool_calls": [
                        {"id": "c1", "function": {"name": "fn", "arguments": '{"a": 2}'}}
                    ],
                }
            }
        ],
        "usage": {"prompt_tokens": 4, "completion_tokens": 6},
    }
    resp = a._from_openai(data, OPENAI_MODELS["gpt-5.5"])
    assert resp.text == "ok"
    assert resp.tool_calls[0].arguments == {"a": 2}
    assert resp.usage.total_tokens == 10


def test_grok_handles_malformed_tool_args():
    a = GrokAdapter(FakeVault(), "xai_api_key")
    data = {
        "choices": [
            {"message": {"content": "", "tool_calls": [{"id": "c", "function": {"name": "f", "arguments": "not-json"}}]}}
        ],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1},
    }
    resp = a._from_grok(data, GROK_MODELS["grok-5"])
    assert resp.tool_calls[0].arguments == {"_raw": "not-json"}


def test_watsonx_response_and_attestation():
    a = WatsonxAdapter(FakeVault(), "ibm_watsonx_api_key", project_id="proj")
    data = {
        "results": [
            {"generated_text": "governed answer", "input_token_count": 12, "generated_token_count": 8}
        ]
    }
    resp = a._from_watsonx(data, WATSONX_MODELS["granite-4.0-large"])
    assert resp.text == "governed answer"
    assert resp.usage.total_tokens == 20
    att = a.governance_attestation(resp)
    assert att["governed"] is True
    assert att["project_id"] == "proj"
    assert att["tokens"] == 20


def test_watsonx_prompt_flattening():
    a = WatsonxAdapter(FakeVault(), "ibm_watsonx_api_key", project_id="proj")
    prompt = a._flatten([{"role": "user", "content": "hi"}])
    assert "USER: hi" in prompt
    assert prompt.strip().endswith("ASSISTANT:")


@pytest.mark.parametrize(
    "adapter_cls,models,cid,kwargs",
    [
        (GeminiAdapter, GEMINI_MODELS, "google_gemini_api_key", {}),
        (AnthropicAdapter, ANTHROPIC_MODELS, "anthropic_api_key", {}),
        (OpenAIAdapter, OPENAI_MODELS, "openai_api_key", {}),
        (GrokAdapter, GROK_MODELS, "xai_api_key", {}),
        (WatsonxAdapter, WATSONX_MODELS, "ibm_watsonx_api_key", {"project_id": "p"}),
    ],
)
def test_price_per_token_is_positive(adapter_cls, models, cid, kwargs):
    a = adapter_cls(FakeVault(), cid, **kwargs)
    model = next(iter(models.values()))
    in_price, out_price = a.price_per_token(model)
    assert in_price > Decimal(0)
    assert out_price > Decimal(0)
    # per-token price must be the per-MTok price divided by one million
    assert in_price == model.usd_per_mtok_input / Decimal(1_000_000)


def test_skills_present_for_every_provider():
    for adapter_cls, models, cid, kwargs in [
        (GeminiAdapter, GEMINI_MODELS, "k", {}),
        (AnthropicAdapter, ANTHROPIC_MODELS, "k", {}),
        (OpenAIAdapter, OPENAI_MODELS, "k", {}),
        (GrokAdapter, GROK_MODELS, "k", {}),
        (WatsonxAdapter, WATSONX_MODELS, "k", {"project_id": "p"}),
    ]:
        a = adapter_cls(FakeVault(), cid, **kwargs)
        model = next(iter(models.values()))
        skills = a.agent_card_skills(model)
        assert skills and "id" in skills[0] and "tags" in skills[0]
