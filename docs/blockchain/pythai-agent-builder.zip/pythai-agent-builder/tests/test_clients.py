"""tests/test_clients.py — concrete clients against a mocked backend + ABI codec."""

from __future__ import annotations

import json

import httpx
import pytest

from agent_builder import AgentBuildSpec
from agent_builder.clients import (
    MindxClientConfig,
    build_agent_builder,
    build_bazaar,
)
from agent_builder.clients.evm_chain import (
    decode_address,
    decode_string,
    decode_uint256,
    encode_address,
    encode_uint256,
    function_selector,
)
from agent_builder.bazaar import StreamKind


# --- mocked backend --------------------------------------------------------


def _routes(request: httpx.Request) -> httpx.Response:
    path = request.url.path
    body = json.loads(request.content) if request.content else {}

    if path == "/vault/credential/anthropic_api_key":
        return httpx.Response(200, json={"secret": "sk-live"})
    if path == "/identity/mint":
        return httpx.Response(200, json={"agent_id": "erc8004:agentid:42"})
    if path == "/ens/subname":
        return httpx.Response(200, json={"name": f"{body['label']}.bankon.eth"})
    if path == "/agenticplace/register":
        return httpx.Response(200, json={"listing_id": "listing:7"})
    if path == "/agenticplace/aorc":
        return httpx.Response(200, json={"aorc_id": "aorc:listing:7"})
    if path == "/mcp/register":
        return httpx.Response(200, json={"mcp_endpoint": "mcp://agenticplace.pythai.net/42"})
    if path == "/reputation/init":
        rank = 3 if body.get("parent_agent_id") else 1
        return httpx.Response(200, json={"rank": rank})
    if path == "/x402/sign":
        return httpx.Response(200, json={"signature": "0xsig"})
    if path == "/x402/settle":
        return httpx.Response(200, json={"tx_hash": "0xdead", "status": "settled"})
    return httpx.Response(404, json={"error": f"no route {path}"})


@pytest.fixture
def config() -> MindxClientConfig:
    return MindxClientConfig(
        backend_base_url="https://mindx.test",
        agenticplace_base_url="https://mindx.test",
        api_token="t",
        treasury_address="0xTREASURY",
    )


@pytest.fixture
def transport() -> httpx.MockTransport:
    return httpx.MockTransport(_routes)


def test_build_agent_builder_end_to_end(config, transport):
    builder = build_agent_builder(config, transport=transport)
    agent = builder.build(
        AgentBuildSpec(
            label="claude-research",
            provider="anthropic",
            model_id="claude-opus-4-8",
            owner_address="0xowner",
        )
    )
    assert agent.agent_id == "erc8004:agentid:42"
    assert agent.ens_name == "claude-research.bankon.eth"
    assert agent.agenticplace_listing_id == "listing:7"
    assert agent.aorc_id == "aorc:listing:7"
    assert agent.mcp_endpoint.startswith("mcp://")
    assert agent.reputation == 1
    # credential resolves from the mocked vault
    assert agent.adapter._api_key() == "sk-live"


def test_parent_genome_reputation_via_backend(config, transport):
    builder = build_agent_builder(config, transport=transport)
    agent = builder.build(
        AgentBuildSpec(
            label="child", provider="openai", model_id="gpt-5.5",
            owner_address="0xo", parent_agent_id="erc8004:agentid:1",
        )
    )
    assert agent.reputation == 3


def test_cross_register_external_via_backend(config, transport):
    builder = build_agent_builder(config, transport=transport)
    rec = builder.cross_register_external(
        external_agent_card_url="https://giant.example/.well-known/agent.json",
        owner_address="0xo",
        label="wrapped",
    )
    assert rec["agent_id"] == "erc8004:agentid:42"
    assert rec["ens_name"] == "wrapped.bankon.eth"


def test_x402_gateway_settles_via_backend(config, transport):
    from decimal import Decimal
    from agent_builder.clients import build_x402_gateway

    gw = build_x402_gateway(config, transport=transport)
    url = gw.bind_endpoint(
        agent_id="erc8004:agentid:42",
        price_input_per_token=Decimal("0.000003"),
        price_output_per_token=Decimal("0.000015"),
        treasury_tithe=Decimal("0.10"),
        treasury_address="0xTREASURY",
    )
    receipt = gw.settle(url, usage_input=1000, usage_output=1000)
    assert receipt["tx_hash"] == "0xdead"
    assert receipt["treasury_tithe_amount"] == "0.001800"


def test_missing_treasury_rejected(transport):
    cfg = MindxClientConfig(treasury_address="")
    with pytest.raises(ValueError):
        build_agent_builder(cfg, transport=transport)


def test_build_bazaar_from_config():
    cfg = MindxClientConfig(
        treasury_address="0xT",
        stream_addresses={k: f"0x{k.value}" for k in StreamKind},
    )
    bazaar = build_bazaar(cfg)
    assert len(bazaar.destinations()) == len(StreamKind)


def test_config_from_env_reads_streams():
    env = {
        "MINDX_BACKEND_URL": "https://x",
        "TREASURY_ADDRESS": "0xT",
        "STREAM_INFERENCE_TITHE_ADDR": "0xA",
        "STREAM_SKILL_ROYALTY_ADDR": "0xB",
    }
    cfg = MindxClientConfig.from_env(env)
    assert cfg.backend_base_url == "https://x"
    assert cfg.stream_addresses[StreamKind.INFERENCE_TITHE] == "0xA"


# --- ABI codec (direct-EVM read path) --------------------------------------


def test_selectors_are_correct():
    # verified against keccak256(signature)[:4]
    assert function_selector("ownerOf(uint256)").hex() == "6352211e"
    assert function_selector("resolve(uint256)").hex() == "4f896d4f"


def test_encode_decode_roundtrip():
    assert decode_uint256(encode_uint256(123456)) == 123456
    addr = "0x8004A169FB4a3325136EB29fA0ceB6D2e539a432"
    assert decode_address(encode_address(addr)) == addr.lower()


def test_decode_string_abi():
    # ABI-encode "ipfs://card" as a single dynamic string return
    s = "ipfs://card"
    b = s.encode()
    head = (32).to_bytes(32, "big")
    length = len(b).to_bytes(32, "big")
    tail = b + bytes(32 - len(b) % 32 if len(b) % 32 else 0)
    assert decode_string(head + length + tail) == s


def test_encode_address_rejects_bad_input():
    with pytest.raises(ValueError):
        encode_address("0x1234")
