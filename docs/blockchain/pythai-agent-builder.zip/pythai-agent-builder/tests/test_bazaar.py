"""tests/test_bazaar.py — isolated income streams, split conservation, isolation."""

from __future__ import annotations

from decimal import Decimal

import pytest

from agent_builder.bazaar import (
    Bazaar,
    IncomeEvent,
    SplitPolicy,
    StreamConfig,
    StreamKind,
    default_stream_configs,
)


def _address_book() -> dict[StreamKind, str]:
    # every stream gets its own isolated destination
    return {kind: f"0x{kind.value}" for kind in StreamKind}


@pytest.fixture
def bazaar() -> Bazaar:
    return Bazaar(default_stream_configs(_address_book()))


def test_address_isolation_enforced_at_config():
    book = _address_book()
    book[StreamKind.SKILL_ROYALTY] = book[StreamKind.INFERENCE_TITHE]  # collide
    with pytest.raises(ValueError):
        default_stream_configs(book)


def test_all_default_policies_sum_to_one():
    from agent_builder.bazaar.streams import DEFAULT_POLICIES

    for kind, policy in DEFAULT_POLICIES.items():
        total = sum(f for _, f in policy.fractions)
        assert total == Decimal(1), f"{kind} policy does not sum to 1"


def test_split_policy_rejects_bad_sum():
    with pytest.raises(ValueError):
        SplitPolicy(name="bad", fractions=(("a", Decimal("0.5")), ("b", Decimal("0.4"))))


def test_split_policy_rejects_duplicate_roles():
    with pytest.raises(ValueError):
        SplitPolicy(name="dup", fractions=(("a", Decimal("0.5")), ("a", Decimal("0.5"))))


def test_inference_tithe_is_whole_treasury(bazaar: Bazaar):
    result = bazaar.ingest(
        IncomeEvent(stream=StreamKind.INFERENCE_TITHE, gross_amount=Decimal("1.50"), source_ref="r1")
    )
    assert len(result.routings) == 1
    assert result.routings[0].role == "treasury"
    assert result.routings[0].amount == Decimal("1.50")


def test_skill_royalty_40_30_20_10(bazaar: Bazaar):
    result = bazaar.ingest_skill_royalty(
        amount=Decimal("10.00"),
        source_ref="skill-mint-1",
        role_addresses={
            "developer": "0xDEV",
            "system": "0xSYS",
            "governance": "0xGOV",
            "treasury": "0xTRE",
        },
    )
    got = {r.role: r.amount for r in result.routings}
    assert got["developer"] == Decimal("4.000000")
    assert got["system"] == Decimal("3.000000")
    assert got["governance"] == Decimal("2.000000")
    assert got["treasury"] == Decimal("1.000000")
    assert sum(got.values()) == Decimal("10.00")


def test_split_conserves_with_rounding_dust(bazaar: Bazaar):
    # a gross that does not divide evenly forces dust into the last role
    result = bazaar.ingest_skill_royalty(
        amount=Decimal("0.0000001"),  # sub-quantum for most roles
        source_ref="dust",
        role_addresses={},
    )
    assert sum(r.amount for r in result.routings) == Decimal("0.0000001")


def test_genome_mint_routes_to_parent_lineage(bazaar: Bazaar):
    result = bazaar.ingest_genome_mint(
        amount=Decimal("5.00"), source_ref="genome-2", parent_lineage_address="0xPARENT"
    )
    roles = {r.role: r.address for r in result.routings}
    assert roles["parent_lineage"] == "0xPARENT"
    amount_parent = next(r.amount for r in result.routings if r.role == "parent_lineage")
    assert amount_parent == Decimal("2.000000")  # 40% of 5


def test_flat_fee_streams(bazaar: Bazaar):
    for kind in (
        StreamKind.REGISTRATION_FEE,
        StreamKind.VERIFICATION_FEE,
        StreamKind.STORAGE_FEE,
        StreamKind.SETTLEMENT_FEE,
    ):
        result = bazaar.ingest_fee(kind, Decimal("1.00"), source_ref=f"fee-{kind.value}")
        assert result.routings[0].role == "treasury"
        assert result.routings[0].amount == Decimal("1.00")


def test_fee_stream_rejects_non_fee_kind(bazaar: Bazaar):
    with pytest.raises(ValueError):
        bazaar.ingest_fee(StreamKind.SKILL_ROYALTY, Decimal("1"), "x")


def test_marketing_99_1(bazaar: Bazaar):
    result = bazaar.ingest(
        IncomeEvent(stream=StreamKind.MARKETING_REVENUE, gross_amount=Decimal("100.00"), source_ref="m1")
    )
    got = {r.role: r.amount for r in result.routings}
    assert got["buyback"] == Decimal("99.000000")
    assert got["operations"] == Decimal("1.000000")


def test_ingest_x402_receipt_books_tithe(bazaar: Bazaar):
    receipt = {
        "receipt_id": "rcpt-1",
        "treasury_tithe_amount": "0.0018",
        "rail": "algorand_asa_via_parsec",
    }
    result = bazaar.ingest_x402_receipt(receipt)
    assert result.stream == StreamKind.INFERENCE_TITHE
    assert result.routings[0].amount == Decimal("0.0018")


def test_streams_are_isolated_in_ledger(bazaar: Bazaar):
    bazaar.ingest(IncomeEvent(StreamKind.INFERENCE_TITHE, Decimal("2.00"), "a"))
    bazaar.ingest_fee(StreamKind.VERIFICATION_FEE, Decimal("1.00"), "b")

    tithe = bazaar.statement(StreamKind.INFERENCE_TITHE)
    verify = bazaar.statement(StreamKind.VERIFICATION_FEE)
    assert tithe["total"] == "2.00"
    assert verify["total"] == "1.00"

    consolidated = bazaar.consolidated_statement()
    assert consolidated["grand_total_informational"] == "3.00"
    # isolation is explicit in the report
    assert "isolated" in consolidated["isolation"]


def test_negative_amounts_rejected(bazaar: Bazaar):
    with pytest.raises(ValueError):
        bazaar.ingest(IncomeEvent(StreamKind.INFERENCE_TITHE, Decimal("-1"), "neg"))


def test_destinations_are_unique(bazaar: Bazaar):
    dests = list(bazaar.destinations().values())
    assert len(dests) == len(set(dests))
