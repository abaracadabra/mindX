"""tests/test_agent_builder.py — builder wiring and neutral-layer behavior."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import pytest

from agent_builder import AgentBuilder, AgentBuildSpec
from agent_builder.gateways import Rail, X402Gateway


# --- in-memory ports -------------------------------------------------------


class FakeVault:
    def __init__(self, secrets: dict[str, str]) -> None:
        self._secrets = secrets

    def resolve(self, credential_id: str) -> str | None:
        return self._secrets.get(credential_id)


class FakeIdentity:
    def __init__(self) -> None:
        self.n = 0
        self.minted: list[tuple[str, str]] = []

    def mint_identity(self, owner: str, agent_card_uri: str) -> str:
        self.n += 1
        self.minted.append((owner, agent_card_uri))
        return f"agentid:{self.n}"


class FakeEns:
    def claim_subname(self, label: str, resolves_to: str) -> str:
        return f"{label}.bankon.eth"


class FakeAgenticPlace:
    def __init__(self) -> None:
        self.n = 0
        self.cards: list[dict[str, Any]] = []

    def register(self, agent_card: dict[str, Any], agent_id: str) -> str:
        self.n += 1
        self.cards.append(agent_card)
        return f"listing:{self.n}"

    def mint_aorc(self, listing_id: str) -> str:
        return f"aorc:{listing_id}"


class FakeX402Port:
    def __init__(self) -> None:
        self.bound: list[dict[str, Any]] = []

    def bind_endpoint(self, agent_id, price_input_per_token, price_output_per_token,
                      treasury_tithe, treasury_address) -> str:
        self.bound.append(
            {
                "agent_id": agent_id,
                "in": price_input_per_token,
                "out": price_output_per_token,
                "tithe": treasury_tithe,
                "treasury": treasury_address,
            }
        )
        return f"https://x402.agenticplace.pythai.net/{agent_id}"

    def settle(self, endpoint_url, usage_input, usage_output) -> dict[str, Any]:
        return {"endpoint": endpoint_url, "status": "settled"}


class FakeMcp:
    def register_tools(self, agent_id: str, tools: list[dict[str, Any]]) -> str:
        return f"mcp://agenticplace.pythai.net/{agent_id}"


class FakeBonaFide:
    def initialize_reputation(self, agent_id: str, parent_agent_id: str | None) -> int:
        return 1 if parent_agent_id is None else 3


@pytest.fixture
def builder() -> AgentBuilder:
    vault = FakeVault(
        {
            "google_gemini_api_key": "x",
            "openai_api_key": "x",
            "anthropic_api_key": "x",
            "xai_api_key": "x",
            "ibm_watsonx_api_key": "x",
        }
    )
    return AgentBuilder(
        credentials=vault,
        identity_registry=FakeIdentity(),
        ens_registrar=FakeEns(),
        agenticplace=FakeAgenticPlace(),
        x402_gateway=FakeX402Port(),
        mcp_surface=FakeMcp(),
        bona_fide=FakeBonaFide(),
        treasury_address="0xTREASURY",
    )


# --- tests -----------------------------------------------------------------


@pytest.mark.parametrize(
    "provider,model_id,native,extra",
    [
        ("google", "gemini-3-pro", "a2a", {}),
        ("openai", "gpt-5.5", "acp", {}),
        ("anthropic", "claude-opus-4-8", "mcp", {}),
        ("xai", "grok-5", "openai_compat", {}),
        ("ibm", "granite-4.0-large", "watsonx_orchestrate", {"project_id": "p"}),
    ],
)
def test_builds_each_provider(builder, provider, model_id, native, extra):
    spec = AgentBuildSpec(
        label=f"{provider}-agent",
        provider=provider,
        model_id=model_id,
        owner_address="0xowner",
        provider_kwargs=extra,
    )
    agent = builder.build(spec)
    assert agent.provider == provider
    assert agent.model.native_protocol.value == native
    assert agent.agent_id.startswith("agentid:")
    assert agent.ens_name.endswith(".bankon.eth")
    assert agent.x402_endpoint.endswith(agent.agent_id)
    assert agent.mcp_endpoint.startswith("mcp://")
    assert agent.aorc_id.startswith("aorc:")
    assert agent.reputation == 1


def test_agent_card_advertises_universal_capabilities(builder):
    agent = builder.build(
        AgentBuildSpec(label="claude", provider="anthropic",
                       model_id="claude-opus-4-8", owner_address="0xo")
    )
    caps = agent.agent_card["capabilities"]
    assert caps["payments"] == ["x402"]
    assert set(caps["interop"]) == {"a2a", "mcp"}
    assert caps["nativeProtocol"] == "mcp"
    assert agent.agent_card["skills"]


def test_parent_genome_inherits_reputation(builder):
    agent = builder.build(
        AgentBuildSpec(label="child", provider="openai", model_id="gpt-5.5",
                       owner_address="0xo", parent_agent_id="agentid:parent")
    )
    assert agent.reputation == 3  # inherited fraction


def test_missing_credential_blocks_build(builder):
    # anthropic key present in fixture; remove via a fresh vault to prove gating
    builder._credentials = FakeVault({})  # no secrets
    agent = builder.build(
        AgentBuildSpec(label="claude", provider="anthropic",
                       model_id="claude-opus-4-8", owner_address="0xo")
    )
    # build wires metadata, but any live call must fail without a credential
    with pytest.raises(PermissionError):
        agent.adapter._api_key()


def test_ibm_requires_project_id(builder):
    with pytest.raises(ValueError):
        builder.build(
            AgentBuildSpec(label="granite", provider="ibm",
                           model_id="granite-4.0-large", owner_address="0xo")
        )


def test_cross_register_external_anchors_identity(builder):
    rec = builder.cross_register_external(
        external_agent_card_url="https://giant.example/.well-known/agent.json",
        owner_address="0xo",
        label="wrapped",
    )
    assert rec["agent_id"].startswith("agentid:")
    assert rec["ens_name"] == "wrapped.bankon.eth"
    assert rec["listing_id"].startswith("listing:")


def test_unknown_model_rejected(builder):
    with pytest.raises(KeyError):
        builder.build(
            AgentBuildSpec(label="x", provider="openai",
                           model_id="gpt-does-not-exist", owner_address="0xo")
        )


# --- x402 gateway tests ----------------------------------------------------


class FakeSigner:
    def sign_payment(self, rail: str, payload: dict[str, Any]) -> str:
        return f"sig:{rail}"


class FakeFacilitator:
    def settle(self, rail: str, payload: dict[str, Any], signature: str) -> dict[str, Any]:
        return {"tx_hash": "0xabc", "status": "settled"}


def test_x402_tithe_split_is_deterministic():
    gw = X402Gateway(FakeSigner(), FakeFacilitator(), default_rail=Rail.ALGORAND_ASA)
    url = gw.bind_endpoint(
        agent_id="agentid:1",
        price_input_per_token=Decimal("0.000003"),
        price_output_per_token=Decimal("0.000015"),
        treasury_tithe=Decimal("0.10"),
        treasury_address="0xTREASURY",
    )
    receipt = gw.settle(url, usage_input=1000, usage_output=1000)
    # base = 1000*0.000003 + 1000*0.000015 = 0.018; tithe = 0.0018; total = 0.0198
    assert receipt["base_amount"] == "0.018000"
    assert receipt["treasury_tithe_amount"] == "0.001800"
    assert receipt["total_amount"] == "0.019800"
    assert receipt["provider_amount"] == "0.018000"
    assert receipt["treasury_address"] == "0xTREASURY"
    assert receipt["tx_hash"] == "0xabc"


def test_x402_rejects_invalid_tithe():
    gw = X402Gateway(FakeSigner(), FakeFacilitator())
    with pytest.raises(ValueError):
        gw.bind_endpoint("a", Decimal("0"), Decimal("0"), Decimal("1.5"), "0xT")


def test_x402_settle_unknown_endpoint():
    gw = X402Gateway(FakeSigner(), FakeFacilitator())
    with pytest.raises(KeyError):
        gw.settle("https://unbound", 1, 1)


def test_x402_payment_required_body():
    gw = X402Gateway(FakeSigner(), FakeFacilitator(), default_rail=Rail.BASE_USDC)
    url = gw.bind_endpoint("a", Decimal("0.000003"), Decimal("0.000015"),
                           Decimal("0.10"), "0xT")
    body = gw.payment_required(url, est_input=100, est_output=100)
    assert body["x402Version"] == 2
    assert body["accepts"][0]["network"] == "base_usdc"
