# Changelog

## 1.1.0

The final step from mocks to mainnet: concrete client layer.

- `agent_builder.clients`: backend-backed implementations of every AgentBuilder
  port (identity, ENS, AgenticPlace, MCP, reputation, vault credentials) and the
  x402 gateway ports (vault signer + facilitator). No private keys reach the
  process; on-chain writes are brokered by the mindX backend / ID Manager Agent.
- `MindxClientConfig.from_env` with an isolation-enforcing stream address book.
- Assembly factory: `build_agent_builder`, `build_x402_gateway`, `build_bazaar`
  return the fully wired live system from config. Moving to mainnet is now a
  configuration task, not a code change.
- Optional direct-EVM read client (`evm_chain`) with a correct minimal ABI codec
  and keccak-derived function selectors, behind the `[chain]` extra.
- `example_production_wiring.py` demonstrating live assembly from environment.
- New tests: `tests/test_clients.py` (backend build end-to-end via
  httpx.MockTransport, x402 settlement, stream isolation, ABI codec). 54 passing.
- New docs: `docs/mindx/CLIENT_INTEGRATION.md`.

## 1.0.0

Initial public release.

- Provider-agnostic `AgentBuilder` with a single adapter interface.
- Five provider integrations: Google/Gemini (A2A-native), OpenAI/GPT (ACP),
  Anthropic/Claude (MCP-native), xAI/Grok (OpenAI-compatible), IBM/watsonx
  (Orchestrate + governance attestation).
- Concrete `X402Gateway`: triple-rail settlement (Base USDC, Algorand ASA via
  Parsec, Tempo MPP) with the PYTHAI treasury tithe split.
- `bazaar` income engine: eight isolated income streams with dedicated
  destinations, append-only per-stream ledgers, split-conservation, and
  consolidated reporting.
- Foundry `ERC8004Adapter.sol` with full test suite and mainnet deploy script.
- Full mindX strategy and architecture documentation under `docs/mindx/`.
