// SPDX-License-Identifier: Apache-2.0
pragma solidity 0.8.26;

import {Test} from "forge-std/Test.sol";
import {ERC8004Adapter, IIdentityRegistry} from "../src/ERC8004Adapter.sol";

/// @notice Mock ERC-8004 IdentityRegistry: agentId => owner.
contract MockIdentityRegistry is IIdentityRegistry {
    mapping(uint256 => address) public owners;

    function setOwner(uint256 agentId, address owner) external {
        owners[agentId] = owner;
    }

    function ownerOf(uint256 agentId) external view returns (address) {
        return owners[agentId];
    }
}

contract ERC8004AdapterTest is Test {
    MockIdentityRegistry internal registry;
    ERC8004Adapter internal adapter;

    address internal alice = address(0xA11CE);
    address internal bob = address(0xB0B);

    uint256 internal constant AGENT_A = 1;
    uint256 internal constant AGENT_B = 2;

    function setUp() public {
        registry = new MockIdentityRegistry();
        adapter = new ERC8004Adapter(address(registry));
        registry.setOwner(AGENT_A, alice);
        registry.setOwner(AGENT_B, bob);
    }

    function test_constructor_rejectsZeroRegistry() public {
        vm.expectRevert(bytes("registry=0"));
        new ERC8004Adapter(address(0));
    }

    function test_owner_canSetAndResolveCard() public {
        vm.prank(alice);
        adapter.setAgentCard(AGENT_A, "ipfs://card-a", keccak256("a"));

        assertEq(adapter.resolve(AGENT_A), "ipfs://card-a");
        (string memory uri, bytes32 h, address owner) = adapter.resolveFull(AGENT_A);
        assertEq(uri, "ipfs://card-a");
        assertEq(h, keccak256("a"));
        assertEq(owner, alice);
    }

    function test_nonOwner_cannotSetCard() public {
        vm.prank(bob);
        vm.expectRevert(
            abi.encodeWithSelector(ERC8004Adapter.NotAgentOwner.selector, AGENT_A, bob)
        );
        adapter.setAgentCard(AGENT_A, "ipfs://evil", bytes32(0));
    }

    function test_unknownAgent_reverts() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(ERC8004Adapter.UnknownAgent.selector, uint256(999))
        );
        adapter.setAgentCard(999, "ipfs://x", bytes32(0));
    }

    function test_emptyURI_reverts() public {
        vm.prank(alice);
        vm.expectRevert(ERC8004Adapter.EmptyURI.selector);
        adapter.setAgentCard(AGENT_A, "", bytes32(0));
    }

    function test_owner_canClearCard() public {
        vm.startPrank(alice);
        adapter.setAgentCard(AGENT_A, "ipfs://card-a", keccak256("a"));
        adapter.clearAgentCard(AGENT_A);
        vm.stopPrank();
        assertEq(adapter.resolve(AGENT_A), "");
    }

    function test_provenance_setOnceAndImmutable() public {
        vm.prank(alice);
        adapter.declareProvenance(AGENT_A, AGENT_B);
        assertEq(adapter.parentOf(AGENT_A), AGENT_B);

        // cannot rewrite provenance
        vm.prank(alice);
        vm.expectRevert(bytes("provenance set"));
        adapter.declareProvenance(AGENT_A, AGENT_B);
    }

    function test_provenance_rejectsSelfAndZeroParent() public {
        vm.startPrank(alice);
        vm.expectRevert(bytes("bad parent"));
        adapter.declareProvenance(AGENT_A, AGENT_A);

        vm.expectRevert(bytes("bad parent"));
        adapter.declareProvenance(AGENT_A, 0);
        vm.stopPrank();
    }

    function test_provenance_rejectsUnknownParent() public {
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(ERC8004Adapter.UnknownAgent.selector, uint256(777))
        );
        adapter.declareProvenance(AGENT_A, 777);
    }

    function test_ownershipFollowsRegistry() public {
        // alice sets a card, then the registry transfers the agent to bob
        vm.prank(alice);
        adapter.setAgentCard(AGENT_A, "ipfs://card-a", bytes32(0));
        registry.setOwner(AGENT_A, bob);

        // alice can no longer modify; bob can
        vm.prank(alice);
        vm.expectRevert(
            abi.encodeWithSelector(ERC8004Adapter.NotAgentOwner.selector, AGENT_A, alice)
        );
        adapter.setAgentCard(AGENT_A, "ipfs://alice-again", bytes32(0));

        vm.prank(bob);
        adapter.setAgentCard(AGENT_A, "ipfs://bob-card", bytes32(0));
        assertEq(adapter.resolve(AGENT_A), "ipfs://bob-card");
    }

    function testFuzz_setCard_onlyOwner(address caller, uint256 agentId) public {
        vm.assume(agentId != 0);
        vm.assume(caller != address(0));
        registry.setOwner(agentId, caller);
        vm.prank(caller);
        adapter.setAgentCard(agentId, "ipfs://fuzz", bytes32(0));
        assertEq(adapter.resolve(agentId), "ipfs://fuzz");
    }
}
