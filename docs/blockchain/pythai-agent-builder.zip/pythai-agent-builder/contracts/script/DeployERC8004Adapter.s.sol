// SPDX-License-Identifier: Apache-2.0
pragma solidity 0.8.26;

import {Script} from "forge-std/Script.sol";
import {ERC8004Adapter} from "../src/ERC8004Adapter.sol";

/// @notice Deploys ERC8004Adapter bound to the live ERC-8004 IdentityRegistry.
/// @dev cypherpunk2048: the constructor takes the registry address and the
///      contract retains NO admin authority — ownership of each agent card is
///      derived from the IdentityRegistry, not from any deployer key.
///
/// Usage:
///   forge script script/DeployERC8004Adapter.s.sol \
///     --rpc-url $ETH_MAINNET_RPC --broadcast --verify --sender $BOARDROOM_SAFE
contract DeployERC8004Adapter is Script {
    // ERC-8004 IdentityRegistry on Ethereum mainnet.
    address constant IDENTITY_REGISTRY = 0x8004A169FB4a3325136EB29fA0ceB6D2e539a432;

    function run() external returns (ERC8004Adapter adapter) {
        vm.startBroadcast();
        adapter = new ERC8004Adapter(IDENTITY_REGISTRY);
        vm.stopBroadcast();
    }
}
