// SPDX-License-Identifier: Apache-2.0
pragma solidity 0.8.26;

/// @notice Minimal surface of the ERC-8004 IdentityRegistry this adapter trusts
///         as the source of truth for who owns an AgentID.
interface IIdentityRegistry {
    /// @return The owner address of a given agentId (reverts/zero if unknown).
    function ownerOf(uint256 agentId) external view returns (address);
}

/// @title ERC8004Adapter
/// @notice Resolves an on-chain ERC-8004 AgentID to an off-chain A2A AgentCard
///         URI, mirroring the A2A "agent card" concept so that A2A-compliant
///         agents inherit ERC-8004 identity without a new protocol. Only the
///         identity owner (per the ERC-8004 IdentityRegistry) may set or update
///         the card for their agent.
/// @dev cypherpunk2048: no admin keys, no upgradeable proxy, no owner privileges
///      beyond what the IdentityRegistry already grants the agent's owner.
contract ERC8004Adapter {
    /// @notice The ERC-8004 IdentityRegistry treated as the ownership oracle.
    IIdentityRegistry public immutable identityRegistry;

    /// @notice agentId => A2A AgentCard URI (e.g. ipfs:// or https://.../agent.json)
    mapping(uint256 => string) private _agentCardURI;

    /// @notice agentId => optional content hash of the card (integrity anchor)
    mapping(uint256 => bytes32) private _agentCardHash;

    /// @notice agentId => parent agentId when minted from a parent genome (0 if root)
    mapping(uint256 => uint256) public parentOf;

    event AgentCardSet(uint256 indexed agentId, string uri, bytes32 contentHash);
    event AgentCardCleared(uint256 indexed agentId);
    event ProvenanceDeclared(uint256 indexed agentId, uint256 indexed parentAgentId);

    error NotAgentOwner(uint256 agentId, address caller);
    error EmptyURI();
    error UnknownAgent(uint256 agentId);

    constructor(address identityRegistry_) {
        require(identityRegistry_ != address(0), "registry=0");
        identityRegistry = IIdentityRegistry(identityRegistry_);
    }

    /// @dev Caller must be the current owner of the agentId per the registry.
    modifier onlyAgentOwner(uint256 agentId) {
        address owner = identityRegistry.ownerOf(agentId);
        if (owner == address(0)) revert UnknownAgent(agentId);
        if (owner != msg.sender) revert NotAgentOwner(agentId, msg.sender);
        _;
    }

    /// @notice Bind (or rebind) the A2A AgentCard URI for an agent.
    /// @param agentId    ERC-8004 identity token id.
    /// @param uri        AgentCard location (ipfs:// preferred for permanence).
    /// @param contentHash keccak256 of the card bytes, 0 if not anchoring integrity.
    function setAgentCard(uint256 agentId, string calldata uri, bytes32 contentHash)
        external
        onlyAgentOwner(agentId)
    {
        if (bytes(uri).length == 0) revert EmptyURI();
        _agentCardURI[agentId] = uri;
        _agentCardHash[agentId] = contentHash;
        emit AgentCardSet(agentId, uri, contentHash);
    }

    /// @notice Remove the AgentCard binding for an agent.
    function clearAgentCard(uint256 agentId) external onlyAgentOwner(agentId) {
        delete _agentCardURI[agentId];
        delete _agentCardHash[agentId];
        emit AgentCardCleared(agentId);
    }

    /// @notice Declare that this agent was minted from a parent genome.
    /// @dev Used by the replication/royalty model; provenance is set once and
    ///      cannot be rewritten (immutable lineage). Both ids must resolve to
    ///      the same owning caller to prevent provenance spoofing.
    function declareProvenance(uint256 agentId, uint256 parentAgentId)
        external
        onlyAgentOwner(agentId)
    {
        require(parentOf[agentId] == 0, "provenance set");
        require(parentAgentId != 0 && parentAgentId != agentId, "bad parent");
        // Parent must exist (its owner lookup must not be the zero address).
        if (identityRegistry.ownerOf(parentAgentId) == address(0)) {
            revert UnknownAgent(parentAgentId);
        }
        parentOf[agentId] = parentAgentId;
        emit ProvenanceDeclared(agentId, parentAgentId);
    }

    /// @notice Resolve an AgentID to its A2A AgentCard URI.
    function resolve(uint256 agentId) external view returns (string memory) {
        return _agentCardURI[agentId];
    }

    /// @notice Resolve the AgentCard URI together with its integrity hash and owner.
    function resolveFull(uint256 agentId)
        external
        view
        returns (string memory uri, bytes32 contentHash, address owner)
    {
        uri = _agentCardURI[agentId];
        contentHash = _agentCardHash[agentId];
        owner = identityRegistry.ownerOf(agentId);
    }
}
