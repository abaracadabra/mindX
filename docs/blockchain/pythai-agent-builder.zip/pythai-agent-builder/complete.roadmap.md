# complete.roadmap.md
## PYTHAI / mindX / DELTAVERSE — Sovereign Agent Economy Deployment Roadmap

**Maintainer:** Professor Codephreak
**Scope:** AgenticPlace × mindX × BANKON integration; DAIO mainnet deployment; x402 Algorand payments via Parsec; chainmapping; neutral-layer positioning.
**Standard:** Apache 2.0 · Foundry for testing · mainnet for deployment · Podman over Docker · OpenBSD vmm where hardened isolation is required · snake_case Python ≥3.12 · no EOA admin keys post-deploy · no upgradeable proxies.

> This roadmap is ordered by dependency, not by calendar. Each section may proceed in parallel where prerequisites are met. Tasks are written so completion is binary and verifiable. No time estimates are included by design.

---

## Workstream 0 — Foundations and Preconditions

### 0.1 Repository and toolchain hygiene
- [ ] Consolidate the active contracts, agents, and integration modules into a single canonical deployment manifest referenced from the mindX docs.
- [ ] Pin Foundry to a fixed `solc` version (0.8.26) and record it in `foundry.toml`.
- [ ] Pin OpenZeppelin contracts to a fixed release (v5.6.1) and vendor it via `forge install`.
- [ ] Establish a reproducible Podman build for the mindX backend service and the AgenticPlace indexer.
- [ ] Document the OpenBSD vmm hardened-deployment target for the BANKON Vault custody tier.
- [ ] Verify the canonical document map at `mindx.pythai.net/docs.html` resolves for every roadmap-referenced doc.

### 0.2 Identity, custody, and signing infrastructure
- [ ] Provision the BANKON Vault with all three custody modes (Machine, Human, DAIO) and confirm AES-256-GCM + HKDF-SHA512 encryption end to end.
- [ ] Stand up a Boardroom multi-signature Safe (3-of-5) as the deployment and treasury signer.
- [ ] Confirm the ID Manager Agent produces Ethereum-compatible wallets and binds them to vault custody.
- [ ] Define and document the Shadow-Overlord admin tier and the key-release runbook.
- [ ] Verify wallet challenge-signing works for the user registration and publish-authorization flows.

### 0.3 Inference substrate
- [ ] Confirm the five-step resilience chain (InferenceDiscovery → OllamaChatManager → re-init → localhost → cloud guarantee) is operational.
- [ ] Register all providers in the provider registry (Ollama, vLLM, Gemini, OpenAI, Anthropic, Mistral, Together, Groq, DeepSeek).
- [ ] Verify CPU-primary inference (0.6B–1.7B local models) and the cloud-guarantee tier are both reachable.
- [ ] Confirm `machine.dreaming` LTM consolidation cycles run and write to pgvector.

---

## Workstream 1 — Chainmapping and Network Definition

### 1.1 Canonical chain registry
- [ ] Extract the authoritative chain list from `agenticplace.pythai.net/allchain.html`.
- [ ] Encode each supported chain (Ethereum mainnet, Algorand, Base, Polygon) into a single machine-readable chainmapping config consumed by the indexer and the deployment scripts.
- [ ] Record RPC endpoints, chain IDs, native assets, and explorer URLs for every chain in the registry.
- [ ] Define the canonical role of each chain: Ethereum as primary EVM anchor (constitution, identity, reputation); Algorand as constitutional and payment rail (BONA FIDE, blockstamp ordering, agenticORacle); Base as x402 USDC rail; Polygon as cross-chain bridge endpoint.
- [ ] Validate Wormhole cross-chain routes between the EVM chains and Algorand.
- [ ] Publish the chainmapping as a referenceable document and link it from the mindX docs interoperability section.

### 1.2 Cross-chain pointer infrastructure
- [ ] Implement and test the THLNK cross-chain pointer format for resolving assets across the registered chains.
- [ ] Verify THLNK pointers resolve correctly between Ethereum and Algorand.

---

## Workstream 2 — DAIO Smart-Contract Suite (Foundry → Mainnet)

### 2.1 Constitution and governance core
- [ ] Author the complete `test/Constitution.t.sol` suite covering the 15% diversification mandate against randomized treasury allocations.
- [ ] Add Foundry tests for supermajority (0.666) enforcement.
- [ ] Add Foundry tests for clawback irreversibility (containment without kill switch).
- [ ] Add Foundry tests for the amendment process (2/3 consensus across Marketing, Community, Development).
- [ ] Add Foundry tests for the Chairman's Veto and the CISO/CRO 1.2× veto weighting.
- [ ] Run the full Constitution suite to green under the pinned `solc` and OpenZeppelin versions.
- [ ] Deploy `DAIO_Constitution.sol` to Ethereum mainnet via the Boardroom Safe.
- [ ] Revoke deployer EOA admin authority in the deployment transaction (transfer ownership to zero address or to the DAIO itself).
- [ ] Verify the deployed Constitution on Etherscan.

### 2.2 BONA FIDE reputation
- [ ] Finalize and Foundry-test the EVM `BonaFide.sol` reputation contract.
- [ ] Finalize and test the Algorand `bonafide.algo.ts` variant, including clawback semantics.
- [ ] Simulate at least three misbehavior cases on Algorand testnet and confirm clawback fires correctly.
- [ ] Deploy `BonaFide.sol` to Ethereum mainnet via the Boardroom Safe; revoke deployer admin.
- [ ] Deploy the BONA FIDE Algorand contract to Algorand mainnet via AlgoKit.
- [ ] Confirm the seven Dojo ranks map correctly to on-chain BONA FIDE privilege.

### 2.3 ERC-8004 identity and reputation adapters
- [ ] Confirm the live ERC-8004 IdentityRegistry (`0x8004A169FB4a3325136EB29fA0ceB6D2e539a432`) and ReputationRegistry (`0x8004BAa17C55a88189AE136b182e5fdA19dE9b63`) are reachable from the mindX backend.
- [ ] Author `ERC8004Adapter.sol` resolving an on-chain AgentID to an off-chain A2A AgentCard.
- [ ] Foundry-test the adapter against representative AgentCard payloads.
- [ ] Deploy `ERC8004Adapter.sol` to Ethereum mainnet; verify on Etherscan.

### 2.4 Intelligent NFT and knowledge-tensor layer
- [ ] Finalize `IntelligentNFT.sol` (ERC-7857) with encrypted-metadata Oracle and a bounded proof-validity period.
- [ ] Finalize the THOT contract embedding the knowledge tensor (8 → 1,048,576 dimensions) inside the ERC-7857 INFT.
- [ ] Foundry-test mint authorization gated by BONA FIDE rank and a held-out validation-score threshold.
- [ ] Deploy `IntelligentNFT.sol` to Ethereum mainnet.
- [ ] Deploy the THOT-backed INFT to Algorand mainnet and wire the THLNK cross-chain pointer.
- [ ] Confirm THOT mint events surface on the insight endpoints.

### 2.5 Marketing and treasury contracts
- [ ] Finalize `MarketingTreasury.sol` (Ethereum L1) with the 99/1 buyback rule.
- [ ] Finalize `MarketingAttributionReceipt.sol` (Base) as the EIP-712 v2 campaign envelope with indexed `boardroomSessionId`.
- [ ] Finalize the `Tessera.sol` identity receipt and `X402Receipt.sol` payment receipt to complete the three-receipt model.
- [ ] Foundry-test the full three-receipt flow (identity → payment → attribution).
- [ ] Deploy `MarketingTreasury.sol` to Ethereum mainnet via the Boardroom Safe.
- [ ] Deploy `MarketingAttributionReceipt.sol` to Base.
- [ ] Confirm receipt issuance integrates with the Boardroom session log.

---

## Workstream 3 — x402 / x402-AVM Payment Rail (Algorand via Parsec)

### 3.1 Payment substrate
- [ ] Integrate the GoPlausible `algorand-remote-mcp-lite` + `x402-avm` substrate as the Parsec payment layer.
- [ ] Implement the triple-rail x402 endpoint accepting Base USDC, Tempo MPP, and Algorand ASA.
- [ ] Store all payment-rail keys in the BANKON Vault under the appropriate custody mode.
- [ ] Document the x402 wire format and the operator runbook in the mindX docs.

### 3.2 Algorand-native payments
- [ ] Confirm Parsec wallet performs ALGO-native per-invocation payments.
- [ ] Implement and test ARC-52 HD wallet support in Parsec.
- [ ] Add Algorand state-proof quantum awareness to the Parsec wallet.
- [ ] Verify at least one ALGO ASA settlement end to end.

### 3.3 Paid service endpoints
- [ ] Stand up `pay2store` as an x402 v2 service for Arweave permanence payments.
- [ ] Stand up an inference x402 endpoint billing per call.
- [ ] Stand up a skill-invocation x402 endpoint billing per call.
- [ ] Integrate the KeeperHub x402/MPP bridge for paid workflow callbacks.
- [ ] Verify a batch of paid invocations settle and withdraw to the Boardroom Safe.

---

## Workstream 4 — AgenticPlace × mindX × BANKON Integration

### 4.1 mindX API exposure
- [ ] Confirm the mindX backend API (FastAPI, port 8000) exposes the AgenticPlace, governance, insight, vault, and payment endpoints.
- [ ] Verify the `mindx.pythai.net` API is reachable and documented in the API reference.
- [ ] Confirm the agent-call endpoint routes through the CEO, Mastermind, and mindXagent entry points.

### 4.2 Agent registration and listing
- [ ] Mint ERC-8004 identities for the first cohort of mindX agents (Mastermind, Coordinator, CEO, AGInt, BDI, AuthorAgent, JudgeDread/Guardian, plus domain specialists).
- [ ] Claim ENS subnames for each agent under `bankon.eth`.
- [ ] Pin each agent's registration file to Lighthouse and mint an aORC verification NFT.
- [ ] List each agent in AgenticPlace and confirm it indexes across the registered chains.
- [ ] Confirm AgenticPlace auto-sync reflects new registrations.

### 4.3 BANKON identity binding
- [ ] Bind each listed agent's on-chain identity (Tessera / ENS / AgentRegistry) and confirm the marketing identity endpoint reports the binding status.
- [ ] Confirm the BANKON Vault holds and can sign for each agent identity.

### 4.4 Interoperability surfaces
- [ ] Confirm the A2A tool performs agent-to-agent discovery and cryptographic signing via agent cards.
- [ ] Confirm the MCP tool registers mindX channels as MCP tools.
- [ ] Verify the AgenticPlace `.extensions → .json → blockchain` publishing pipeline.

---

## Workstream 5 — Storage, Memory, and Knowledge Catalogue

### 5.1 Decentralized storage offload
- [ ] Confirm the storage offload projector compiles eligible STM into deterministic gzipped JSONL CAR bundles with byte-stable CIDs.
- [ ] Verify parallel upload to Lighthouse and NFTStorage with quorum-of-2 retrieval.
- [ ] Confirm on-chain anchoring via `ARC DatasetRegistry.registerDataset` (selector `f1783fb8`).
- [ ] Verify lazy retrieval of offloaded memory by `content_cid` from pgvector.

### 5.2 Cold-archive permanence
- [ ] Confirm the Arweave bundler (AO actor model + Turbo) provides cold-archive permanence.
- [ ] Verify `mindx_pay2store` moves ETH/USDC into Arweave permanence via the x402 service.

### 5.3 Knowledge Catalogue (CQRS projection)
- [ ] Confirm the 17 typed `CatalogueEvent` kinds (including `library.discover`) are emitted and logged to append-only JSONL.
- [ ] Lift the catalogue from JSONL to the full Dataplex six-resource model (EntryGroup, EntryType, AspectType, Entry, EntryLink, EntryLinkType).
- [ ] Project events into Kuzu (graph), Qdrant (vector), and Meilisearch (BM25).
- [ ] Federate the catalogue via NATS leaf-nodes.
- [ ] Surface catalogue entries on the insight endpoints.

---

## Workstream 6 — Self-Evolution Engine (SkillOpt → automindXtrain)

### 6.1 SkillOpt optimizer
- [ ] Implement `agents/learning/skillopt_optimizer.py` instantiating the bounded-edit optimizer (append/insert_after/replace/delete) over a single `best_skill.md`.
- [ ] Implement the textual learning-rate budget (default 4, cosine decay, floor 2) with top-budget edit clipping.
- [ ] Implement the epoch-local rejected-edit buffer persisted to JSONL.
- [ ] Implement the epoch-wise slow update writing to a protected region of the skill document that step-level edits cannot overwrite.
- [ ] Implement the strict held-out validation gate (accept only when the selection score strictly improves).
- [ ] Wire the Dojo benchmark suite as the held-out validation gate.
- [ ] Wire the Boardroom as the optimizer-model diversity pool.

### 6.2 Skill distribution and marketplace
- [ ] Content-address every accepted `best_skill.md` and pin it to Lighthouse.
- [ ] Anchor each accepted skill on-chain and wrap it as an ERC-7857 INFT with the held-out validation score as public proof.
- [ ] Verify skill transfer across target models (skill trained on one harness retains value on another).
- [ ] Enforce the 40/30/20/10 royalty split on skill invocation via on-chain settlement.

### 6.3 aGLM checkpoint program
- [ ] Confirm the aGLM checkpoint family trains against the primary Qwen target.
- [ ] Train a second aGLM baseline on a non-Qwen open model (Granite or Llama) to mitigate the single-supplier dependency.
- [ ] Document the checkpoint lineage and selection policy.

---

## Workstream 7 — Governance and Safety Operations

### 7.1 Boardroom and War Council
- [ ] Confirm the Boardroom convenes the CEO plus seven soldiers with diverse LLM providers and weighted voting.
- [ ] Confirm supermajority execution and minority-dissent exploration branches function.
- [ ] Confirm every consequential decision logs to the Gödel audit journal and surfaces on the insight endpoints.
- [ ] Define and document the War Council strategic-decision process.

### 7.2 Safety remediation
- [ ] Fix the known CEO Circuit Breaker defect (permanent non-functionality after 5 BDI failures).
- [ ] Confirm the Guardian Agent enforces security policy and access control.
- [ ] Confirm the Stuck Loop Detector triggers network discovery on autonomous stalls.
- [ ] Engage a formal-verification provider for the Constitution invariants (diversification mandate, supermajority, clawback irreversibility) and publish the report under Apache 2.0.

### 7.3 Resilience and bus-factor
- [ ] Onboard at least two additional War Council co-architects with equity participation and earned BONA FIDE rank.
- [ ] Document the full operator runbook for autonomous-mode start/stop and recovery.

---

## Workstream 8 — Neutral-Layer Strategy (Switzerland for Agents)

### 8.1 Cross-registration of external agents
- [ ] Build the cross-registration wrapper service that mints ERC-8004 identities for public A2A AgentCards.
- [ ] Cross-register at least one agent from each major provider (Google/Gemini, OpenAI/GPT, Anthropic/Claude, xAI/Grok, IBM/watsonx) into AgenticPlace via the wrapper.
- [ ] Confirm cross-registered agents appear as peers in the registry and cannot be revoked by their originators.

### 8.2 Cross-vendor settlement
- [ ] Establish x402 as the default cross-vendor settlement rail for inter-agent transactions.
- [ ] Verify a cross-vendor transaction settles neutrally through the Parsec/GoPlausible substrate.

### 8.3 Cross-giant skill marketplace
- [ ] Enable any registered agent to invoke any marketplace `best_skill.md` regardless of provenance.
- [ ] Confirm royalty settlement fires on cross-provider skill invocation.

---

## Workstream 9 — Publication, Benchmarking, and Treasury Self-Funding

### 9.1 Publication pipeline
- [ ] Confirm the `/admin/publish-to-rage` endpoint publishes articles to `rage.pythai.net` via the WordPress connector.
- [ ] Confirm the AuthorAgent publishes Book of mindX editions and improvement-journal entries autonomously.

### 9.2 Benchmarking
- [ ] Define and run a neutral-layer benchmark measuring cross-giant agent discovery, identity resolution, and settlement latency through mindX versus each provider's native stack.
- [ ] Run a capability benchmark of the Boardroom + BDI + SkillOpt stack against a leading multi-agent baseline and publish the result regardless of outcome.
- [ ] Verify the falsification criterion (ERC-8004 adoption trajectory and AAIF identity-primitive direction) and record the strategic decision it implies.

### 9.3 Treasury self-funding
- [ ] Confirm marketplace royalty and x402 settlement revenue accrue to the DAIO treasury.
- [ ] Confirm treasury revenue covers operational costs (VPS, RPC, Lighthouse pinning, Arweave permanence, optional inference bursts).
- [ ] Confirm the 99/1 buyback rule executes from treasury revenue.

---

## Acceptance Criteria (Definition of Done)

- [ ] All DAIO contracts deployed to Ethereum and Algorand mainnet with deployer admin authority revoked and contracts verified.
- [ ] AgenticPlace lists the first agent cohort with ERC-8004 identities, ENS subnames, and aORC verification across the registered chains.
- [ ] x402 triple-rail settlement (Base USDC + Algorand ASA + Tempo MPP) operational via Parsec with verified withdrawals to the Boardroom Safe.
- [ ] SkillOpt-driven `automindXtrain` loop produces accepted skills that are content-addressed, anchored, and tradeable as ERC-7857 INFTs.
- [ ] Constitution invariants formally verified and the report published under Apache 2.0.
- [ ] At least one external agent from each major provider cross-registered in AgenticPlace.
- [ ] Treasury self-funding demonstrated from royalty and settlement revenue.
- [ ] Bus-factor reduced: War Council seated with at least three co-architects.

---

*Apache 2.0 throughout. Foundry for testing. Mainnet for deployment. Code is law. Intelligence is intelligence. Ataraxia is the goal.*

— Professor Codephreak
