# Contributing

pythai-agent-builder follows the cypherpunk2048 engineering standard.

## Standard

- Apache-2.0 for all code.
- Python >= 3.12, flat snake_case.
- Foundry for all Solidity; no upgradeable proxies; no EOA admin keys retained post-deploy.
- Deterministic builds; mainnet for deployment.
- Money is always `Decimal` (Python) or fixed-point integer (Solidity) — never float.
- Income streams are isolated: no two streams share a destination address.
- Credentials never live in code; they resolve from the BANKON Vault at call time.

## Workflow

1. Fork and branch from `main`.
2. Add tests for any new behavior (`pytest -q` must stay green; `forge test` for contracts).
3. Keep provider integrations isolated to their adapter — the builder must stay provider-agnostic.
4. Open a pull request describing the change and the workstream it advances (see `docs/mindx/COMPLETE_ROADMAP.md`).

## Adding a provider integration

Implement `ProviderAdapter` in `agent_builder/adapters/`, register it in `agent_builder/registry.py`, and add normalization tests in `tests/test_adapters.py`. Do not touch the builder; adding a provider is a one-line registry entry by design.

## Adding an income stream

Add the kind to `StreamKind`, a default `SplitPolicy` to `DEFAULT_POLICIES`, and a dedicated destination in the address book. Ensure the policy fractions sum to exactly 1 and the destination is unique. Add tests in `tests/test_bazaar.py`.
