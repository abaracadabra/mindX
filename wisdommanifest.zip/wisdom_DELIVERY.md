# WISDOM — Delivery to DeltaVerse for inclusion in login333

**Package:** `wisdom` · **License:** Apache-2.0 · **Dependencies:** none (pure Node core)
**Runtime target:** Node 24 LTS (→ 26 LTS Oct 2026) · Permission Model ON
**Settlement:** Algorand mainnet via parsec / parsec-wallet · EVM mirror = DAIO X402AccessGate (Foundry, mainnet-only)
**Integrity:** `sha256sum -c MANIFEST.sha256` (25 files, content-addressed)

## What this is
WISDOM is the DeltaVerse knowledge-delivery daemon: files born `0600`,
content-addressed, x402-gated, throttle-priced, owned and earning down a lineage
chain. It plugs into **login333** at the identity boundary — a CAIP-122 wallet
sign-in becomes the `X-PRINCIPAL`, and the same wallet pays x402.

## Verify on arrival
```bash
unzip wisdom.zip && cd wisdom
sha256sum -c MANIFEST.sha256        # integrity
npm test                            # 25 tests, all green
npm start                           # permissioned boot on :3333
```

## Read in this order
1. `INTEGRATION_LOGIN333.md` — the seam this delivery is for.
2. `README.md` — orientation, routes, run/deploy.
3. `REFERENCE.md` — complete technical reference (all three layers, full lifecycle, API, examples).
4. `docs/nodejs_review.md` — the Layer-1 foundation (Node as sovereign runtime).

## Layout
```
server.mjs                 pure node:http router (11 routes)
lib/                       throttle · vault · ledger · x402_gate · parsec_x402 · perms · deltaverse
mindx/                     catalogue (CQRS+MEMO) · ingest (rapid concurrent client)
integration/login333.mjs   CAIP-122 sign-in → X-PRINCIPAL adapter
test/                      25 tests across 6 suites
deploy/                    Containerfile + Podman quadlet
```

## cypherpunk2048
Apache-2.0 · no admin keys post-deploy · no upgradeable proxies · mainnet only ·
flat snake_case · zero dependencies.

*PYTHAI Knowledge Delivery © BANKON — all rights preserved.*
