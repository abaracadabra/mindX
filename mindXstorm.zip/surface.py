"""
surface.py  —  THE single entry point for delivery & provisioning.

One surface over the whole KaaS corpus. A consumer asks once; `request()`:

  1. resolves the route via the Marketspace doorway ("kaas" / "rage"),
  2. retrieves the relevant knowledge via rage (mindX's retrieval + voice),
  3. if the consumer already has access  -> DELIVERS (voice + provenance),
  4. if it is gated and not owned        -> returns a PROVISIONING quote:
        the price, a parsec x402-avm USDC payment, and the KaaSMarket.purchase
        calldata,
  5. once provisioned (payment settled)  -> DELIVERS.

Everything else — discovery (AgenticPlace), payment (x402/parsec on Algorand),
access (ERC-8004 + KaaSMarket), retrieval/voice (rage) — sits behind this one
functional delivery/provisioning surface. Consumers never touch the sub-systems
directly.
"""
from __future__ import annotations
import os
import sys
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

sys.path.insert(0, os.path.dirname(__file__))
from rage import Rage, KaaSDoc                       # noqa: E402
from marketspace import Marketspace                  # noqa: E402
from kaas import purchase_calldata                   # noqa: E402
import parsec_x402                                   # noqa: E402

# price lookup for a gated article (micro-USDC); 0/None => public
PriceFn = Callable[[str], int]


@dataclass
class SurfaceResponse:
    mode: str                       # "delivered" | "provision_required" | "empty"
    answer: Optional[str] = None
    citations: Optional[List[dict]] = None
    # provisioning fields (mode == "provision_required")
    article: Optional[str] = None
    title: Optional[str] = None
    price: Optional[int] = None
    x402_payment: Optional[dict] = None
    purchase_calldata: Optional[str] = None
    gateway: Optional[str] = None


class ProvisioningSurface:
    def __init__(self, rage: Rage, marketspace: Marketspace, price_fn: PriceFn,
                 grant: Callable[[str, str], None]):
        self.rage = rage
        self.ms = marketspace
        self.price_of = price_fn
        self._grant = grant            # grant(article, requester) -> records access

    # -------- the single entry point --------
    def request(self, query: str, requester: str, k: int = 3) -> SurfaceResponse:
        route = self.ms.route("rage")                 # one resolved gateway+doorway
        hits = self.rage.retrieve(query, requester, k)
        if hits:
            v = self.rage.voice(query, requester, k)
            return SurfaceResponse(mode="delivered", answer=str(v["answer"]),
                                   citations=v["citations"], gateway=route["gateway"])

        # nothing accessible — is there gated knowledge we could provision?
        gated = self._top_gated(query, requester)
        if gated is None:
            return SurfaceResponse(mode="empty", answer="mindX has no knowledge on that yet.",
                                   gateway=route["gateway"])

        price = self.price_of(gated.article)
        payment = parsec_x402.sign_with_parsec_wallet(parsec_x402.build_payment(price))
        return SurfaceResponse(
            mode="provision_required", title=gated.title, article=gated.article, price=price,
            x402_payment=payment.to_dict(), purchase_calldata=purchase_calldata(gated.article),
            gateway=route["gateway"],
        )

    # -------- provisioning: settle payment, grant access, then deliver --------
    def provision(self, article: str, requester: str, query: str, k: int = 3) -> SurfaceResponse:
        # (payment already built/submitted in request(); here we record the grant
        #  that KaaSMarket.purchase would produce, then deliver through the surface)
        self._grant(article, requester)
        return self.request(query, requester, k)

    def _top_gated(self, query: str, requester: str) -> Optional[KaaSDoc]:
        best, best_s = None, 0
        for doc in self.rage.corpus:
            if self.rage._readable(doc, requester):
                continue
            s = self.rage._score(doc, _q(query))
            if s > best_s:
                best, best_s = doc, s
        return best


def _q(query: str) -> List[str]:
    from rage import _tokens
    return _tokens(query)


if __name__ == "__main__":
    from rage import Rage, KaaSDoc
    from marketspace import Marketspace, Gateway, Doorway
    from kaas import article_id

    corpus = [
        KaaSDoc("kaas:ternary-attention", "Ternary attention under load",
                "Ternary attention stays stable under high token load with integer-exact accumulation",
                public=True, providers=["0xA1", "0xB2"]),
        KaaSDoc("kaas:thot-prefix-proofs", "Matryoshka prefix proofs for THOT",
                "Prefix proofs let a node verify and use a tensor prefix before the full shard arrives",
                public=False, providers=["0xC3"]),
    ]
    granted = set()
    access = lambda art, who: (art, who) in granted
    grant = lambda art, who: granted.add((art, who))
    price_fn = lambda art: 250_000          # 0.25 USDC for the gated article

    rage = Rage(corpus, access_fn=access)
    gateways = [Gateway("0x" + "a1" * 20, "https://gw1.agenticplace.pythai.net")]
    doorways = [Doorway("rage", "https://rage.pythai.net/api/retrieve", kind="api"),
                Doorway("kaas", "0x" + "caa5" + "0" * 36)]
    ms = Marketspace(gateways, doorways)

    surface = ProvisioningSurface(rage, ms, price_fn, grant)
    QUERY = "how do prefix proofs work for tensors"
    BUYER = "0xBUY"

    print("=" * 64)
    print("provisioning surface — single entry for delivery & provisioning")
    print("=" * 64)

    # 1) first ask: gated, not owned -> provisioning quote
    r1 = surface.request(QUERY, BUYER)
    print(f"\n[1] request -> {r1.mode}")
    assert r1.mode == "provision_required"
    print(f"    article : {r1.title}  ({r1.article[:14]}…)")
    print(f"    price   : {r1.price} uUSDC")
    print(f"    x402    : scheme={r1.x402_payment['scheme']} asset={r1.x402_payment['asset']} "
          f"txid={r1.x402_payment['txid']}")
    print(f"    purchase: {r1.purchase_calldata[:34]}…")
    print(f"    gateway : {r1.gateway}")

    # 2) provision (settle x402 + KaaSMarket.purchase) then deliver
    r2 = surface.provision(r1.article, BUYER, QUERY)
    print(f"\n[2] provision + deliver -> {r2.mode}")
    print(f"    {r2.answer}")
    print(f"    citations: {[c['title'] for c in (r2.citations or [])]}")
    assert r2.mode == "delivered" and r2.citations

    # public knowledge delivers immediately through the same single entry
    r3 = surface.request("ternary attention under load", "0xANYONE")
    print(f"\n[3] public request -> {r3.mode}  (no provisioning needed)")
    assert r3.mode == "delivered"

    print("\nsurface OK — one entry: provision when gated, deliver when owned  \u2714")
