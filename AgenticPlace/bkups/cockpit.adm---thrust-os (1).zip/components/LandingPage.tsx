
import React, { useState, useEffect } from 'react';
import { Rocket, Shield, ExternalLink, Zap, ChevronDown, Lock } from 'lucide-react';
import { generateSnapshot } from '../services/oracleService';
import { THRUST_ADDRESS, PANCAKESWAP_URL } from '../constants';

interface LandingPageProps {
  onEnterCockpit: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onEnterCockpit }) => {
  const [price, setPrice] = useState(0.000012389223171827);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      const snap = generateSnapshot();
      // Add more precision simulation
      setPrice(prev => prev + (Math.random() - 0.5) * 0.000000000001);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleBuy = () => {
    window.open(PANCAKESWAP_URL, '_blank');
  };

  return (
    <div className="min-h-screen bg-black text-green-500 font-mono flex flex-col selection:bg-green-500 selection:text-black">
      {/* HUD Header */}
      <nav className="p-6 flex justify-between items-center border-b border-green-900/20 bg-black/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-green-500 text-black flex items-center justify-center font-bold text-lg rounded-sm shadow-[0_0_10px_rgba(34,197,94,0.5)]">
            Δ
          </div>
          <span className="font-bold tracking-tighter text-lg glow-text">DELTA.V</span>
        </div>
        <div className="flex gap-8 items-center">
          <button 
            onClick={onEnterCockpit}
            className="text-[10px] uppercase font-bold tracking-widest text-zinc-500 hover:text-green-400 transition-colors flex items-center gap-2 group"
          >
            <Shield size={14} className="group-hover:rotate-12 transition-transform" />
            ENTER COCKPIT.ADM
          </button>
        </div>
      </nav>

      {/* Main Burn Portal */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-12 relative overflow-hidden">
        {/* Background Animation Elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-green-500/5 rounded-full blur-[120px]"></div>
          <div className="absolute top-0 w-full h-full opacity-10" style={{ backgroundImage: 'radial-gradient(#0f0 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        </div>

        {/* Live Price Display */}
        <div className="z-10 space-y-4 animate-in fade-in slide-in-from-top-10 duration-1000">
          <div className="flex items-center justify-center gap-3 text-zinc-500 text-xs uppercase tracking-[0.5em] mb-4">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            Real-Time Truth Feed
          </div>
          <h2 className="text-[10px] text-zinc-400 uppercase tracking-widest opacity-50">Current THRUST Price</h2>
          <div className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tighter text-white font-mono break-all px-4">
            ${price.toFixed(15)}
          </div>
          <div className="text-zinc-500 text-[10px] mt-2 font-mono">
            REFRESH RATE: 2000MS // BLOCK: LATEST_BSC
          </div>
        </div>

        {/* Action Button */}
        <div className="z-10 w-full max-w-md animate-in fade-in zoom-in-95 duration-1000 delay-300">
          <button 
            onClick={handleBuy}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            className="group relative w-full py-8 bg-green-500 text-black font-black text-2xl tracking-[0.2em] rounded-md overflow-hidden transition-all hover:scale-105 active:scale-95 shadow-[0_0_30px_rgba(34,197,94,0.3)]"
          >
            <div className={`absolute inset-0 bg-white/20 transition-transform duration-700 ${isHovered ? 'translate-x-0' : '-translate-x-full'}`}></div>
            <div className="relative flex items-center justify-center gap-4">
              <Rocket className={`${isHovered ? 'animate-bounce' : ''}`} size={32} />
              INITIATE IGNITION
            </div>
          </button>
          
          <div className="mt-4 flex justify-between px-2 text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
            <span className="flex items-center gap-1"><Zap size={10} /> Auto-Fill Enabled</span>
            <span className="flex items-center gap-1">DEX: PANCAKESWAP V2</span>
          </div>
        </div>

        {/* Quick Stats / Info */}
        <div className="z-10 grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl pt-12 animate-in fade-in slide-in-from-bottom-10 duration-1000 delay-500">
          <div className="p-6 border border-zinc-900 bg-zinc-900/20 rounded-lg backdrop-blur-sm group hover:border-green-500/30 transition-colors">
            <Lock className="text-green-500 mb-4 mx-auto" size={20} />
            <h4 className="text-white text-xs font-bold uppercase mb-2">LP Locked</h4>
            <p className="text-zinc-500 text-[10px] leading-relaxed">
              Liquidity is structurally locked for 100 years. Complete rug-protection enforced by smart-contract law.
            </p>
          </div>
          <div className="p-6 border border-zinc-900 bg-zinc-900/20 rounded-lg backdrop-blur-sm group hover:border-green-500/30 transition-colors">
            <Zap className="text-yellow-500 mb-4 mx-auto" size={20} />
            <h4 className="text-white text-xs font-bold uppercase mb-2">100% APY Potential</h4>
            <p className="text-zinc-500 text-[10px] leading-relaxed">
              DeltaV rebase mechanics reward attention and holding. Yield is generated every 15 minutes.
            </p>
          </div>
          <div className="p-6 border border-zinc-900 bg-zinc-900/20 rounded-lg backdrop-blur-sm group hover:border-green-500/30 transition-colors">
            <Shield className="text-blue-500 mb-4 mx-auto" size={20} />
            <h4 className="text-white text-xs font-bold uppercase mb-2">DeltaV Protocol</h4>
            <p className="text-zinc-500 text-[10px] leading-relaxed">
              The first high-velocity attention currency on BSC. Powered by custom BROBOT AI infrastructure.
            </p>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="mt-12 animate-bounce opacity-20">
          <ChevronDown />
        </div>
      </main>

      {/* Contract Address Section */}
      <section className="p-12 bg-zinc-950 border-t border-zinc-900 text-center">
        <div className="max-w-2xl mx-auto space-y-6">
          <h3 className="text-xs uppercase font-bold tracking-[0.3em] text-zinc-400">Secure Contract Interface</h3>
          <div className="bg-black border border-zinc-800 p-4 rounded-md flex flex-col md:flex-row items-center justify-between gap-4 group">
            <code className="text-[10px] md:text-xs text-green-500/70 group-hover:text-green-500 transition-colors break-all">
              {THRUST_ADDRESS}
            </code>
            <button 
              onClick={() => navigator.clipboard.writeText(THRUST_ADDRESS)}
              className="px-4 py-2 border border-zinc-800 text-[10px] hover:bg-zinc-900 transition-all rounded"
            >
              COPY ADDR
            </button>
          </div>
          <div className="flex justify-center gap-6">
            <a href={`https://bscscan.com/address/${THRUST_ADDRESS}`} target="_blank" className="text-zinc-500 hover:text-white flex items-center gap-2 text-[10px] uppercase font-bold">
              BSCSCAN <ExternalLink size={12} />
            </a>
            <a href={PANCAKESWAP_URL} target="_blank" className="text-zinc-500 hover:text-white flex items-center gap-2 text-[10px] uppercase font-bold">
              VIEW ON DEX <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </section>

      {/* Footer Branding */}
      <footer className="p-8 border-t border-zinc-900 text-center text-[10px] text-zinc-700 tracking-[0.2em] uppercase font-bold">
        Powered by <span className="text-white">BROBOT AI Onboarding</span> // © 2024 DeltaV Ecosystem
      </footer>
    </div>
  );
};
