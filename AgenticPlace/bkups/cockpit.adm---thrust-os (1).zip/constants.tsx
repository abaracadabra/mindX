
import React from 'react';
import { Network, ContractFunction } from './types';

export const COLORS = {
  PRIMARY: '#00ff00',
  SECONDARY: '#004400',
  BACKGROUND: '#000000',
  ERROR: '#ff0000',
  WARNING: '#ffff00',
};

export const THRUST_ADDRESS = '0x969F60Bfe17962E0f061B434596545C7b6Cd6Fc4';
export const PANCAKESWAP_URL = `https://pancakeswap.finance/swap?outputCurrency=${THRUST_ADDRESS}`;

export const MOCK_ABI: ContractFunction[] = [
  { name: "name", inputs: [], stateMutability: "view" },
  { name: "symbol", inputs: [], stateMutability: "view" },
  { name: "decimals", inputs: [], stateMutability: "view" },
  { name: "totalSupply", inputs: [], stateMutability: "view" },
  { name: "getCirculatingSupply", inputs: [], stateMutability: "view" },
  { name: "balanceOf", inputs: [{ name: "who", type: "address" }], stateMutability: "view" },
  { name: "getLiquidityBacking", inputs: [{ name: "accuracy", type: "uint256" }], stateMutability: "view" },
  { name: "isOverLiquified", inputs: [{ name: "target", type: "uint256" }, { name: "accuracy", type: "uint256" }], stateMutability: "view" },
  { name: "rewardYield", inputs: [], stateMutability: "view" },
  { name: "rebaseFrequency", inputs: [], stateMutability: "view" },
  { name: "totalBuyFee", inputs: [], stateMutability: "view" },
  { name: "totalSellFee", inputs: [], stateMutability: "view" },
  { name: "autoRebase", inputs: [], stateMutability: "view" },
  { name: "shouldSwapBack", inputs: [], stateMutability: "view" },
  { name: "manualSync", inputs: [], stateMutability: "nonpayable" },
  { name: "setAutoRebase", inputs: [{ name: "_autoRebase", type: "bool" }], stateMutability: "nonpayable" },
  { name: "setFees", inputs: [
    { name: "_liquidityFee", type: "uint256" },
    { name: "_treasuryFee", type: "uint256" },
    { name: "_burnFee", type: "uint256" },
    { name: "_buyFeeRFV", type: "uint256" },
    { name: "_sellFeeRFVAdded", type: "uint256" },
    { name: "_sellFeeTreasuryAdded", type: "uint256" },
    { name: "_feeDenominator", type: "uint256" }
  ], stateMutability: "nonpayable" },
  { name: "setTargetLiquidity", inputs: [{ name: "target", type: "uint256" }, { name: "accuracy", type: "uint256" }], stateMutability: "nonpayable" },
  { name: "clearStuckBalance", inputs: [{ name: "_receiver", type: "address" }], stateMutability: "nonpayable" },
  { name: "rescueToken", inputs: [{ name: "tokenAddress", type: "address" }, { name: "tokens", type: "uint256" }], stateMutability: "nonpayable" },
  { name: "transfer", inputs: [{ name: "to", type: "address" }, { name: "value", type: "uint256" }], stateMutability: "nonpayable" },
  { name: "approve", inputs: [{ name: "spender", type: "address" }, { name: "value", type: "uint256" }], stateMutability: "nonpayable" }
];

export const NETWORK_CONFIGS = {
  [Network.BSC_MAINNET]: {
    name: 'Binance Smart Chain',
    chainId: 56,
    explorer: 'https://bscscan.com',
    color: '#F3BA2F'
  },
  [Network.ARC_TESTNET]: {
    name: 'ARC Testnet',
    chainId: 12345,
    explorer: 'https://explorer.arc-testnet.url',
    color: '#00ffcc'
  }
};
