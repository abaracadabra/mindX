
import { OracleSnapshot } from '../types';

export interface ThrustSnapshot extends OracleSnapshot {
  liquidityBacking: number;
  circulatingSupply: number;
  rewardYield: number;
}

export function generateSnapshot(): ThrustSnapshot {
  const simulatedPrice = 0.00001193 + (Math.random() - 0.5) * 0.0000005;
  const simulatedVolume = 231239 + Math.floor(Math.random() * 5000);
  
  return {
    priceUSD: simulatedPrice,
    volume24h: simulatedVolume,
    liquidity: 20420000 + (Math.random() - 0.5) * 100000,
    timestamp: Date.now(),
    block: 31245000 + Math.floor(Math.random() * 100),
    deltaSinceLast: (Math.random() - 0.5) * 0.05,
    confirmed: true,
    liquidityBacking: 15.42 + (Math.random() - 0.5) * 0.1,
    circulatingSupply: 540230124 + (Math.random() - 0.5) * 1000,
    rewardYield: 0.0235 // Fixed yield simulation
  };
}
