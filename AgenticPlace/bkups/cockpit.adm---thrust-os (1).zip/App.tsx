
import React, { useState, useEffect } from 'react';
import { TabController } from './components/TabController';
import { LandingPage } from './components/LandingPage';
import { LayoutGrid, Maximize2, Minimize2, Power, Shield } from 'lucide-react';

const App: React.FC = () => {
  const [booted, setBooted] = useState(false);
  const [view, setView] = useState<'landing' | 'cockpit'>('landing');
  const [showMonitor, setShowMonitor] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setBooted(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  if (!booted) {
    return (
      <div className="h-screen w-screen bg-black flex flex-col items-center justify-center font-mono space-y-6">
        <div className="relative">
          <div className="w-24 h-24 border-4 border-green-500/20 border-t-green-500 rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center text-green-500 glow-text text-xl font-bold">Δ</div>
        </div>
        <div className="text-center">
          <h1 className="text-xl tracking-[0.5em] text-green-500 glow-text font-bold mb-2">DELTA.V</h1>
          <p className="text-[10px] text-green-800 animate-pulse uppercase">Syncing Price Feeds & Protocol Ops...</p>
        </div>
      </div>
    );
  }

  if (view === 'landing') {
    return <LandingPage onEnterCockpit={() => setView('cockpit')} />;
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-black text-green-500 selection:bg-green-500 selection:text-black">
      {/* Global Admin Header */}
      <header className="flex items-center justify-between px-6 py-3 border-b border-green-900/40 bg-black z-50">
        <div className="flex items-center gap-6">
          <button 
            onClick={() => setView('landing')}
            className="flex items-center gap-3 group"
          >
             <div className="bg-green-600 text-black p-1 font-bold rounded text-xs leading-none transition-transform group-hover:scale-110">Δ</div>
             <h1 className="font-bold tracking-tighter text-sm uppercase glow-text">COCKPIT.ADM</h1>
          </button>
          <div className="h-4 w-px bg-zinc-800 hidden md:block"></div>
          <div className="hidden lg:flex gap-6 text-[10px] font-mono opacity-50">
            <span className="hover:opacity-100 cursor-help">PID: 2840</span>
            <span className="hover:opacity-100 cursor-help uppercase">Admin Mode: Unrestricted</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
           <button 
             onClick={() => setShowMonitor(!showMonitor)}
             className={`p-1.5 border rounded transition-all ${showMonitor ? 'bg-green-900/30 border-green-500' : 'border-zinc-800 hover:border-zinc-600'}`}
             title="Toggle Price Monitor"
           >
             <LayoutGrid size={14} />
           </button>
           <button 
             onClick={() => setView('landing')}
             className="flex items-center gap-2 bg-zinc-900 border border-zinc-700 px-3 py-1 rounded-md text-[10px] hover:bg-zinc-800 transition-all text-zinc-400"
           >
             <Power size={12} className="text-red-500" />
             EXIT CONSOLE
           </button>
        </div>
      </header>

      {/* Main Layout Area */}
      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 relative">
           <TabController />
        </div>

        {/* Sidebar Price Monitor (Dexscreener) */}
        {showMonitor && (
          <aside className="w-[400px] border-l border-zinc-900 bg-black flex flex-col animate-in slide-in-from-right-full duration-500">
             <div className="p-4 border-b border-zinc-900 flex justify-between items-center bg-zinc-950/50">
               <h3 className="text-xs font-bold uppercase tracking-tighter">THRUST/USDC Monitor</h3>
               <button onClick={() => setShowMonitor(false)} className="text-zinc-500 hover:text-white"><Minimize2 size={14} /></button>
             </div>
             <div className="flex-1 relative">
               <iframe
                 src="https://dexscreener.com/bsc/0x762e1925Cc37Ac085dC81732113E0Eb1382C4D2B?embed=1&loadChartSettings=0&chartLeftToolbar=0&chartDefaultOnMobile=1&chartTheme=dark&theme=dark&chartStyle=0&chartType=usd&interval=15"
                 style={{ width: '100%', height: '100%', border: 'none' }}
               />
             </div>
          </aside>
        )}
      </div>
    </div>
  );
};

export default App;
