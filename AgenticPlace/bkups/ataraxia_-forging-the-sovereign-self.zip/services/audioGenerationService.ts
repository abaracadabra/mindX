import { generateGeminiSpeech } from './geminiService';
import { generateElevenLabsSpeech } from './elevenLabsService';
import { audioBufferToWav } from '../utils/audio';

export type VoiceEngine = 'gemini' | 'elevenlabs';

interface ServiceConfig {
    engine: VoiceEngine;
    text: string;
    apiKey?: string | null;
    geminiVoice?: string;
    elevenLabsVoiceId?: string | null;
}

const PREVIEW_TEXT = "This is a preview of the voice you have selected.";


export const generateChapterAudio = async (
    engine: VoiceEngine,
    text: string,
    elevenLabsApiKey: string | null,
    audioContext: AudioContext,
    geminiVoice: string,
    elevenLabsVoiceId: string | null
): Promise<AudioBuffer> => {
    switch (engine) {
        case 'gemini':
            return generateGeminiSpeech(text, audioContext, geminiVoice);
        case 'elevenlabs':
            if (!elevenLabsApiKey) {
                throw new Error("ElevenLabs API key is missing. Please provide it in the settings.");
            }
            if (!elevenLabsVoiceId) {
                throw new Error("ElevenLabs Voice ID is missing. Please select a voice in the settings.");
            }
            return generateElevenLabsSpeech(text, elevenLabsApiKey, elevenLabsVoiceId, audioContext);
        default:
            throw new Error(`Unsupported voice engine: ${engine}`);
    }
};

/**
 * Generates audio from text and returns it as a WAV Blob.
 * This function is self-contained and designed to be exposed as a service endpoint.
 * It creates and closes its own AudioContext.
 * @param {ServiceConfig} config - The configuration for audio generation.
 * @returns {Promise<Blob>} A promise that resolves with a WAV audio Blob.
 */
export const generateAudioAsService = async (
    config: ServiceConfig
): Promise<Blob> => {
    const { engine, text, apiKey = null, geminiVoice = 'Kore', elevenLabsVoiceId = null } = config;
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    try {
        const buffer = await generateChapterAudio(engine, text, apiKey, audioContext, geminiVoice, elevenLabsVoiceId);
        const wavBlob = audioBufferToWav(buffer);
        return wavBlob;
    } finally {
        if (audioContext.state !== 'closed') {
            await audioContext.close();
        }
    }
};

/**
 * Generates a short preview audio clip for a given voice.
 * @param engine The voice engine to use.
 * @param voiceIdentifier The voice name (for Gemini) or voice ID (for ElevenLabs).
 * @param elevenLabsApiKey Required if the engine is ElevenLabs.
 * @returns A promise that resolves with an audio Blob.
 */
export const generatePreviewAudio = async (
    engine: VoiceEngine,
    voiceIdentifier: string,
    elevenLabsApiKey: string | null
): Promise<Blob> => {
    // This function creates its own temporary AudioContext for generating the preview.
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    try {
        let buffer: AudioBuffer;
        if (engine === 'gemini') {
            buffer = await generateGeminiSpeech(PREVIEW_TEXT, audioContext, voiceIdentifier);
        } else if (engine === 'elevenlabs') {
            if (!elevenLabsApiKey) {
                throw new Error("ElevenLabs API key is required for voice previews.");
            }
            buffer = await generateElevenLabsSpeech(PREVIEW_TEXT, elevenLabsApiKey, voiceIdentifier, audioContext);
        } else {
            throw new Error(`Unsupported engine for preview: ${engine}`);
        }
        return audioBufferToWav(buffer);
    } finally {
        if (audioContext.state !== 'closed') {
            await audioContext.close();
        }
    }
};