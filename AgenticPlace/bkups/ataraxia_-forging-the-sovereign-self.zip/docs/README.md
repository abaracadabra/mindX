# Ataraxia: The Audiobook Application

This project is a modern, interactive audiobook application that brings the text of "Ataraxia: Forging the Sovereign Self" to life using cutting-edge AI voice generation. It provides a seamless listening experience with a polished UI and offers powerful, flexible audio generation capabilities.

## Features

- **Dual AI Voice Engines**: 
  - **Google Gemini**: A wide selection of clear, high-quality voices for narration.
  - **ElevenLabs**: High-fidelity, professional-grade voices with advanced customization.
- **Advanced ElevenLabs Integration**:
  - **Custom Voice Selection**: Use any voice from your ElevenLabs account, including pre-made and custom-cloned voices. The app fetches your voice library automatically.
  - **In-App Voice Cloning**: Add new voices to your ElevenLabs account directly from the app by uploading audio samples.
- **Interactive Player**: A full-featured audio player with play/pause, progress tracking, and chapter-specific download capabilities.
- **Full Audiobook Generation**: Generate and download the entire book as a single WAV or OGG file with a single click, using your selected voice.
- **Transcript Viewer**: Read along with the audio with a clean, scrollable transcript for each chapter.
- **Audio-as-a-Service**: Exposes a global API endpoint (`window.audiobookService`) allowing external AI agents, scripts, or browser extensions to use the app's audio generation capabilities on demand.

## Technology Stack

- **Frontend**: React, TypeScript, Tailwind CSS
- **AI Services**:
    - Google Gemini API (`@google/genai`)
    - ElevenLabs API
- **Core Browser APIs**:
    - Web Audio API for audio processing and playback.
    - Local Storage for secure API key and setting storage.

## Configuration

- **Google Gemini**: The application assumes the Gemini API key is available in the execution environment via `process.env.API_KEY`.
- **ElevenLabs**: To use the ElevenLabs voice engine, you must provide your own API key. This can be done directly in the app's "Tools & Settings" menu. The key is stored securely in your browser's local storage and is never transmitted anywhere else. Your custom voice selection is also saved.

## Getting Started

The application is designed to run directly in a modern web browser. No complex setup is required. Simply open the `index.html` file to launch the audiobook player.