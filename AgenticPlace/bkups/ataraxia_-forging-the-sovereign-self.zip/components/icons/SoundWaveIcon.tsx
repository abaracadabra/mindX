import React from 'react';

export const SoundWaveIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.5 14.5l-3-6-3 6m6-6l-3-6-3 6m6 6l-3 6-3-6" />
    </svg>
);
