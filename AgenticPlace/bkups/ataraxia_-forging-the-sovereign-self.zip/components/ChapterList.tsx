import React, { useState, useRef, useEffect, useMemo } from 'react';
import type { Chapter, FilterSettings, OscilloscopeTheme, ColorScheme } from '../types';
import { BookIcon } from './icons/BookIcon';
import type { VoiceEngine } from '../services/audioGenerationService';
import type { ElevenLabsVoice } from '../services/elevenLabsService';
import eventService from '../services/eventService';
import { PlaySymbolIcon } from './icons/PlaySymbolIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { SettingsIcon } from './icons/SettingsIcon';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import VoiceCloneModal from './VoiceCloneModal';
import { BookmarkIcon } from './icons/BookmarkIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { PlayCircleIcon } from './icons/PlayCircleIcon';
import { MixerIcon } from './icons/MixerIcon';
import VoiceSelectorModal from './VoiceSelectorModal';


interface SpectrogramSettings {
    minFrequency: number;
    maxFrequency: number;
    intensity: number;
    colorScheme: ColorScheme;
}

type FilterTypeOption = 'off' | 'lowpass' | 'highpass' | 'bandpass';

const COLOR_SCHEME_PREVIEWS: Record<ColorScheme, string> = {
    vibrant: 'linear-gradient(to right, hsl(240, 100%, 25%), hsl(120, 100%, 50%), hsl(0, 100%, 65%))',
    inferno: 'linear-gradient(to right, #000004, #720026, #f8961e, #fcf6bd)',
    viridis: 'linear-gradient(to right, #440154, #21908d, #fde725)',
    grayscale: 'linear-gradient(to right, #000000, #ffffff)',
    ocean: 'linear-gradient(to right, hsl(180, 100%, 15%), hsl(220, 100%, 75%))'
};


interface ChapterListProps {
    bookTitle: string;
    bookSubtitle: string;
    chapters: Chapter[];
    currentChapterIndex: number;
    isAlbumMode: boolean;
    isStartingAlbumMode: boolean;
    isDownloadingFullBook: boolean;
    voiceEngine: VoiceEngine;
    elevenLabsApiKey: string;
    elevenLabsVoices: ElevenLabsVoice[];
    elevenLabsVoiceId: string;
    playbackRate: number;
    preCacheBufferCount: number;
    geminiVoice: string;
    spectrogramSettings: SpectrogramSettings;
    onSpectrogramChange: (settings: Partial<SpectrogramSettings>) => void;
    filterSettings: FilterSettings;
    onFilterSettingsChange: (settings: Partial<FilterSettings>) => void;
    oscilloscopeTheme: OscilloscopeTheme;
    onOscilloscopeThemeChange: (theme: OscilloscopeTheme) => void;
    freqToSliderVal: (freq: number) => number;
    sliderValToFreq: (val: number) => number;
    intensityToSliderVal: (intensity: number) => number;
    sliderValToIntensity: (val: number) => number;
    completedChapters: Set<number>;
    bookmarkedChapters: Set<number>;
}

const getChapterDisplayTitle = (title: string): string => {
    const parts = title.split(':');
    if (parts.length > 1) {
        return parts.slice(1).join(':').trim();
    }
    return title.trim();
};

const ChapterList: React.FC<ChapterListProps> = ({ 
    bookTitle,
    bookSubtitle,
    chapters, 
    currentChapterIndex, 
    isAlbumMode,
    isStartingAlbumMode,
    isDownloadingFullBook,
    voiceEngine,
    elevenLabsApiKey,
    elevenLabsVoices,
    elevenLabsVoiceId,
    playbackRate,
    preCacheBufferCount,
    geminiVoice,
    spectrogramSettings,
    onSpectrogramChange,
    filterSettings,
    onFilterSettingsChange,
    oscilloscopeTheme,
    onOscilloscopeThemeChange,
    freqToSliderVal,
    sliderValToFreq,
    intensityToSliderVal,
    sliderValToIntensity,
    completedChapters,
    bookmarkedChapters,
}) => {
    const [isToolsMenuOpen, setIsToolsMenuOpen] = useState(false);
    const [isMixMenuOpen, setIsMixMenuOpen] = useState(false);
    const [isCloneModalOpen, setIsCloneModalOpen] = useState(false);
    const [currentApiKey, setCurrentApiKey] = useState(elevenLabsApiKey);
    const [localPreCacheBuffer, setLocalPreCacheBuffer] = useState(preCacheBufferCount);
    const [voiceSelectorOpenFor, setVoiceSelectorOpenFor] = useState<'gemini' | 'elevenlabs' | null>(null);
    const toolsMenuRef = useRef<HTMLDivElement>(null);
    const mixMenuRef = useRef<HTMLDivElement>(null);

     useEffect(() => {
        setCurrentApiKey(elevenLabsApiKey);
    }, [elevenLabsApiKey]);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (toolsMenuRef.current && !toolsMenuRef.current.contains(event.target as Node)) {
                setIsToolsMenuOpen(false);
            }
            if (mixMenuRef.current && !mixMenuRef.current.contains(event.target as Node)) {
                setIsMixMenuOpen(false);
            }
        };
        
        if (isToolsMenuOpen || isMixMenuOpen) {
            document.addEventListener('mousedown', handleClickOutside);
        }
        
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isToolsMenuOpen, isMixMenuOpen]);

    const handleAction = (action: () => void, menu: 'tools' | 'mix') => {
        action();
        if (menu === 'tools') setIsToolsMenuOpen(false);
        if (menu === 'mix') setIsMixMenuOpen(false);
    };

    const handleCloneSuccess = () => {
        setIsCloneModalOpen(false);
    }
    
    // Spectrogram Handlers
    const handleMinFrequencyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newMinFreq = sliderValToFreq(Number(e.target.value));
        if (newMinFreq < spectrogramSettings.maxFrequency) {
            onSpectrogramChange({ minFrequency: newMinFreq });
        }
    };
    const handleMaxFrequencyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newMaxFreq = sliderValToFreq(Number(e.target.value));
        if (newMaxFreq > spectrogramSettings.minFrequency) {
            onSpectrogramChange({ maxFrequency: newMaxFreq });
        }
    };
    const handleIntensityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onSpectrogramChange({ intensity: sliderValToIntensity(Number(e.target.value)) });
    };

    const filterTypeForUI: FilterTypeOption =
        filterSettings.type === 'lowpass' ? 'lowpass'
        : filterSettings.type === 'highpass' ? 'highpass'
        : filterSettings.type === 'bandpass' ? 'bandpass'
        : 'off';
    
    const selectedElevenLabsVoiceName = useMemo(() => {
        return elevenLabsVoices.find(v => v.voice_id === elevenLabsVoiceId)?.name || 'Select Voice';
    }, [elevenLabsVoices, elevenLabsVoiceId]);


    return (
        <>
            <aside className="w-full md:w-80 lg:w-96 bg-gray-900/70 border-b md:border-b-0 md:border-r border-gray-700/50 p-4 md:p-6 flex flex-col flex-shrink-0">
                
                <div className="flex items-start gap-3 mb-4">
                    <div className="relative group flex-shrink-0">
                        <BookIcon />
                        <button
                            onClick={() => eventService.emit('play:full_book')}
                            disabled={isStartingAlbumMode || isDownloadingFullBook}
                            className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 focus:opacity-100 focus:outline-none focus:ring-2 focus:ring-blue-400 disabled:opacity-0 disabled:cursor-wait"
                            aria-label="Play Full Audiobook"
                        >
                            <PlayCircleIcon />
                        </button>
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-blue-300 tracking-wide">{bookTitle}</h1>
                        <p className="text-sm text-gray-400 -mt-1">{bookSubtitle}</p>
                    </div>
                </div>

                <button
                    onClick={() => eventService.emit('play:full_book')}
                    disabled={isStartingAlbumMode || isDownloadingFullBook}
                    className="w-full flex items-center justify-center gap-3 p-3 mb-4 rounded-lg bg-green-600/80 text-white font-semibold hover:bg-green-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2 focus:ring-offset-gray-900 disabled:bg-gray-600 disabled:cursor-wait"
                >
                    {isStartingAlbumMode ? (
                        <>
                            <SpinnerIcon className="h-5 w-5" />
                            <span>Starting Audiobook...</span>
                        </>
                    ) : (
                        <>
                            <PlaySymbolIcon />
                            <span>Play Full Audiobook</span>
                        </>
                    )}
                </button>


                <nav className="flex-1 overflow-y-auto custom-scrollbar">
                    <ul>
                        {chapters.map((chapter, index) => (
                             <li key={index} className="mb-1">
                                <div
                                    className={`w-full text-left p-3 rounded-lg transition-colors duration-200 flex items-center justify-between ${
                                        currentChapterIndex === index
                                            ? 'bg-blue-600 text-white font-semibold shadow-lg'
                                            : 'text-gray-400 hover:bg-gray-800/60 hover:text-gray-200'
                                    }`}
                                >
                                    <button
                                        onClick={() => eventService.emit('chapter:select', index)}
                                        className="flex-1 text-left overflow-hidden mr-2"
                                        aria-current={currentChapterIndex === index}
                                    >
                                        <span className="block text-xs opacity-80">Chapter {index + 1}</span>
                                        <span className="text-sm leading-tight line-clamp-4">{getChapterDisplayTitle(chapter.title)}</span>
                                    </button>
                                    <div className="flex items-center gap-2 flex-shrink-0">
                                        {completedChapters.has(index) && (
                                            <div title="Completed" className="text-green-400">
                                                <CheckCircleIcon />
                                            </div>
                                        )}
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                eventService.emit('chapter:bookmark_toggle', index);
                                            }}
                                            className="p-1 rounded-full text-gray-400 hover:bg-gray-700/80 hover:text-yellow-400 transition-colors"
                                            title={bookmarkedChapters.has(index) ? "Remove Bookmark" : "Add Bookmark"}
                                            aria-label={bookmarkedChapters.has(index) ? "Remove Bookmark" : "Add Bookmark"}
                                            aria-pressed={bookmarkedChapters.has(index)}
                                        >
                                            <BookmarkIcon filled={bookmarkedChapters.has(index)} />
                                        </button>
                                    </div>
                                </div>
                            </li>
                        ))}
                    </ul>
                </nav>
                <div className="mt-auto pt-6 border-t border-gray-700/50">
                     <div className="flex items-center gap-2">
                        {/* Mix Settings Button */}
                        <div className="relative flex-1" ref={mixMenuRef}>
                            <button
                                onClick={() => setIsMixMenuOpen(prev => !prev)}
                                className="w-full flex items-center justify-center gap-2 p-3 rounded-lg bg-gray-700/80 text-white font-semibold hover:bg-gray-600 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-gray-900"
                                aria-haspopup="true"
                                aria-expanded={isMixMenuOpen}
                                disabled={isDownloadingFullBook}
                            >
                                <MixerIcon />
                                <span>Mix</span>
                            </button>
                             {isMixMenuOpen && (
                                <div className="absolute bottom-full left-0 right-0 mb-2 w-full max-h-[70vh] overflow-y-auto custom-scrollbar bg-gray-800 border border-gray-700 rounded-lg shadow-2xl z-10 p-2 animate-fade-in-up">
                                    <div className="space-y-3 p-1">
                                        <h3 className="text-sm font-bold text-gray-400">Audio Post-Processing</h3>
                                        <div className="px-1 space-y-3">
                                            <div>
                                                <label className="text-sm font-medium text-gray-300 mb-1 block">Audio Filter</label>
                                                <div className="grid grid-cols-4 gap-1 text-xs bg-gray-900/50 rounded-md p-0.5">
                                                    {(['off', 'lowpass', 'highpass', 'bandpass'] as FilterTypeOption[]).map(type => (
                                                        <button 
                                                            key={type}
                                                            onClick={() => onFilterSettingsChange({ type: type === 'off' ? 'allpass' : type })}
                                                            className={`capitalize text-center py-1.5 px-2 rounded transition-colors ${filterTypeForUI === type ? 'bg-blue-500 text-white font-semibold' : 'hover:bg-gray-700 text-gray-300'}`}
                                                        >
                                                            {type}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                            <div>
                                                <div className="flex justify-between items-baseline">
                                                    <label htmlFor="filter-frequency" className="text-sm font-medium text-gray-300">Frequency</label>
                                                    <span className="font-mono text-sm text-blue-300">{Math.round(filterSettings.frequency)} Hz</span>
                                                </div>
                                                <input 
                                                    id="filter-frequency" type="range" min="0" max="1" step="0.001"
                                                    value={freqToSliderVal(filterSettings.frequency)}
                                                    onChange={(e) => onFilterSettingsChange({ frequency: sliderValToFreq(Number(e.target.value)) })}
                                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                                    disabled={filterTypeForUI === 'off'}
                                                />
                                            </div>
                                            <div>
                                                <div className="flex justify-between items-baseline">
                                                    <label htmlFor="qfactor" className="text-sm font-medium text-gray-300">Q / Resonance</label>
                                                    <span className="font-mono text-sm text-blue-300">{filterSettings.q.toFixed(1)}</span>
                                                </div>
                                                <input 
                                                    id="qfactor" type="range" min="0.1" max="20" step="0.1"
                                                    value={filterSettings.q}
                                                    onChange={(e) => onFilterSettingsChange({ q: Number(e.target.value) })}
                                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                                    disabled={filterTypeForUI === 'off'}
                                                />
                                            </div>
                                        </div>

                                        <div className="border-t border-gray-700/50 !my-3" />
                                        
                                        <h3 className="text-sm font-bold text-gray-400">Visualizer</h3>
                                        <div className="px-1 space-y-3">
                                            <div>
                                                <label className="text-sm font-medium text-gray-300 mb-1 block">Oscilloscope Theme</label>
                                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 bg-gray-900/50 rounded-md p-0.5">
                                                    {(['cyberpunk', 'matrix', 'arcade', 'plasma'] as OscilloscopeTheme[]).map(theme => (
                                                        <button
                                                            key={theme}
                                                            onClick={() => onOscilloscopeThemeChange(theme)}
                                                            className={`flex-1 capitalize text-center py-1 px-2 rounded text-xs transition-colors ${oscilloscopeTheme === theme ? 'bg-blue-500' : 'hover:bg-gray-700'}`}
                                                        >
                                                            {theme}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                            <div className="border-t border-gray-700/50 !my-3" />
                                            <h4 className="text-sm font-medium text-gray-300">Spectrogram</h4>
                                            <div>
                                                <label className="text-sm font-medium text-gray-300 mb-2 block">Color Scheme</label>
                                                <div className="grid grid-cols-3 gap-2">
                                                    {(['vibrant', 'inferno', 'viridis', 'grayscale', 'ocean'] as ColorScheme[]).map(scheme => (
                                                        <button
                                                            key={scheme}
                                                            onClick={() => onSpectrogramChange({ colorScheme: scheme })}
                                                            className={`flex flex-col items-center justify-center p-1 rounded-md transition-all duration-200 ring-2 ring-offset-2 ring-offset-gray-900 ${spectrogramSettings.colorScheme === scheme ? 'ring-blue-500 bg-gray-700' : 'ring-transparent hover:ring-blue-500/50 bg-gray-900'}`}
                                                            title={`Set color scheme to ${scheme}`}
                                                        >
                                                            <div
                                                                className="w-full h-5 rounded-sm mb-1 border border-white/10"
                                                                style={{ background: COLOR_SCHEME_PREVIEWS[scheme] }}
                                                                aria-hidden="true"
                                                            />
                                                            <span className="capitalize text-xs text-gray-300">
                                                                {scheme === 'grayscale' ? 'Gray' : scheme}
                                                            </span>
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                            <div>
                                                <div className="flex justify-between items-baseline mb-1">
                                                    <label htmlFor="intensity" className="text-sm font-medium text-gray-300">Intensity</label>
                                                    <span className="font-mono text-sm text-blue-300">{spectrogramSettings.intensity.toFixed(2)}x</span>
                                                </div>
                                                <input 
                                                    id="intensity" type="range" min="0" max="1" step="0.005"
                                                    value={intensityToSliderVal(spectrogramSettings.intensity)}
                                                    onChange={handleIntensityChange}
                                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                                                />
                                            </div>
                                            <div>
                                                <div className="flex justify-between items-baseline mb-1">
                                                    <label htmlFor="min-frequency" className="text-sm font-medium text-gray-300">Min Frequency</label>
                                                    <span className="font-mono text-sm text-blue-300">{Math.round(spectrogramSettings.minFrequency)} Hz</span>
                                                </div>
                                                <input 
                                                    id="min-frequency" type="range" min="0" max="1" step="0.001"
                                                    value={freqToSliderVal(spectrogramSettings.minFrequency)}
                                                    onChange={handleMinFrequencyChange}
                                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                                                />
                                            </div>
                                            <div>
                                                <div className="flex justify-between items-baseline mb-1">
                                                    <label htmlFor="max-frequency" className="text-sm font-medium text-gray-300">Max Frequency</label>
                                                    <span className="font-mono text-sm text-blue-300">{Math.round(spectrogramSettings.maxFrequency)} Hz</span>
                                                </div>
                                                <input 
                                                    id="max-frequency" type="range" min="0" max="1" step="0.001"
                                                    value={freqToSliderVal(spectrogramSettings.maxFrequency)}
                                                    onChange={handleMaxFrequencyChange}
                                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Tools & Settings Button */}
                        <div className="relative flex-1" ref={toolsMenuRef}>
                            <button
                                onClick={() => setIsToolsMenuOpen(prev => !prev)}
                                className="w-full flex items-center justify-center gap-2 p-3 rounded-lg bg-blue-500/80 text-white font-semibold hover:bg-blue-600 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-gray-900"
                                aria-haspopup="true"
                                aria-expanded={isToolsMenuOpen}
                                disabled={isDownloadingFullBook}
                            >
                                <SettingsIcon />
                                <span>Settings</span>
                                <ChevronDownIcon className={`transition-transform duration-200 ${isToolsMenuOpen ? 'rotate-180' : ''}`} />
                            </button>

                            {isToolsMenuOpen && (
                                <div className="absolute bottom-full right-0 mb-2 w-full max-h-[70vh] overflow-y-auto custom-scrollbar bg-gray-800 border border-gray-700 rounded-lg shadow-2xl z-10 p-2 animate-fade-in-up">
                                    <div className="space-y-3 p-1">
                                        <h3 className="text-sm font-bold text-gray-400">Full Audiobook</h3>
                                        <div className="grid grid-cols-3 gap-1">
                                            <button title="Download as WAV (High Quality, Large File)" onClick={() => handleAction(() => eventService.emit('download:full_book', 'wav'), 'tools')} className="w-full p-2 rounded-md text-sm text-gray-300 hover:bg-blue-500/30 hover:text-white transition-colors">.wav</button>
                                            <button title="Download as OGG (Smaller File, Encoding May Take Time)" onClick={() => handleAction(() => eventService.emit('download:full_book', 'ogg'), 'tools')} className="w-full p-2 rounded-md text-sm text-gray-300 hover:bg-blue-500/30 hover:text-white transition-colors">.ogg</button>
                                            <button title="Cache all chapters in browser" onClick={() => handleAction(() => eventService.emit('cache:full_book'), 'tools')} className="w-full p-2 rounded-md text-sm text-gray-300 hover:bg-blue-500/30 hover:text-white transition-colors">Pre-cache</button>
                                        </div>
                                        
                                        <div className="border-t border-gray-700/50 !my-3" />

                                        <h3 className="text-sm font-bold text-gray-400">Playback Settings</h3>
                                        <div className="px-1 space-y-3">
                                            <div>
                                                <div className="flex justify-between items-baseline mb-1">
                                                    <label htmlFor="playback-speed" className="text-sm font-medium text-gray-300">Speed</label>
                                                    <span className="font-mono text-sm text-blue-300">{playbackRate.toFixed(2)}x</span>
                                                </div>
                                                <input id="playback-speed" type="range" min="0.5" max="2" step="0.05" value={playbackRate} onChange={(e) => eventService.emit('settings:playback_rate_change', parseFloat(e.target.value))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"/>
                                            </div>
                                            <div>
                                                <div className="flex justify-between items-baseline mb-1">
                                                    <label htmlFor="pre-cache-buffer" className="text-sm font-medium text-gray-300">Pre-cache Buffer</label>
                                                    <span className="font-mono text-sm text-blue-300">{localPreCacheBuffer} {localPreCacheBuffer > 1 ? 'chapters' : 'chapter'}</span>
                                                </div>
                                                <input 
                                                    id="pre-cache-buffer" 
                                                    type="range" 
                                                    min="1" 
                                                    max="5" 
                                                    step="1" 
                                                    value={localPreCacheBuffer} 
                                                    onChange={(e) => setLocalPreCacheBuffer(parseInt(e.target.value, 10))}
                                                    onMouseUp={() => eventService.emit('settings:pre_cache_change', localPreCacheBuffer)}
                                                    onTouchEnd={() => eventService.emit('settings:pre_cache_change', localPreCacheBuffer)}
                                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                                                />
                                                <p className="text-xs text-gray-500 mt-1">For 'Play Full Audiobook', caches upcoming chapters for seamless transitions.</p>
                                            </div>
                                        </div>
                                        
                                        <div className="border-t border-gray-700/50 !my-3" />

                                        <h3 className="text-sm font-bold text-gray-400">Voice Generation</h3>
                                        <div className='px-1 space-y-3'>
                                            <div>
                                                <label className="block text-sm font-medium text-gray-400 mb-2">Voice Engine</label>
                                                <div className="flex w-full bg-gray-900/50 rounded-lg p-1">
                                                    <button onClick={() => eventService.emit('settings:engine_change', 'gemini')} className={`w-1/2 p-2 rounded-md text-sm font-semibold transition-colors ${voiceEngine === 'gemini' ? 'bg-blue-500/80 text-white' : 'text-gray-300 hover:bg-gray-700/50'}`}>Gemini</button>
                                                    <button onClick={() => eventService.emit('settings:engine_change', 'elevenlabs')} className={`w-1/2 p-2 rounded-md text-sm font-semibold transition-colors ${voiceEngine === 'elevenlabs' ? 'bg-purple-500/80 text-white' : 'text-gray-300 hover:bg-gray-700/50'}`}>ElevenLabs</button>
                                                </div>
                                            </div>
                                            {voiceEngine === 'gemini' && (
                                                <div>
                                                    <label className="block text-sm font-medium text-gray-400 mb-2">Gemini Voice</label>
                                                    <button onClick={() => setVoiceSelectorOpenFor('gemini')} className="w-full flex justify-between items-center p-2 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:ring-blue-500 focus:border-blue-500">
                                                        <span>{geminiVoice}</span>
                                                        <ChevronDownIcon />
                                                    </button>
                                                </div>
                                            )}
                                            {voiceEngine === 'elevenlabs' && (
                                                <div className="space-y-3">
                                                    <div>
                                                        <label htmlFor="elevenlabs-api-key" className="block text-sm font-medium text-gray-400 mb-2">ElevenLabs API Key</label>
                                                        <div className="flex gap-2">
                                                            <input id="elevenlabs-api-key" type="password" value={currentApiKey} onChange={(e) => setCurrentApiKey(e.target.value)} placeholder="Enter your API key" className="flex-1 p-2 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:ring-purple-500 focus:border-purple-500" />
                                                            <button onClick={() => eventService.emit('settings:apikey_save', currentApiKey)} className="p-2 bg-purple-500/80 text-white font-semibold rounded-lg hover:bg-purple-500 transition-colors">Save</button>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <label className="block text-sm font-medium text-gray-400 mb-2">ElevenLabs Voice</label>
                                                        <div className="flex gap-2">
                                                            <button 
                                                                onClick={() => setVoiceSelectorOpenFor('elevenlabs')} 
                                                                className="flex-1 flex justify-between items-center p-2 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:ring-purple-500 focus:border-purple-500 disabled:opacity-50"
                                                                disabled={!elevenLabsApiKey || elevenLabsVoices.length === 0}
                                                            >
                                                                <span className="truncate">{selectedElevenLabsVoiceName}</span>
                                                                <ChevronDownIcon />
                                                            </button>

                                                            <button 
                                                                onClick={() => setIsCloneModalOpen(true)}
                                                                className="p-2 bg-purple-500/30 text-white font-semibold rounded-lg hover:bg-purple-500/50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                                                title="Add / Clone Voice"
                                                                disabled={!elevenLabsApiKey}
                                                            >
                                                                <PlusCircleIcon />
                                                            </button>
                                                        </div>
                                                        <div className="text-xs text-gray-500 pt-2 px-1">
                                                            Learn more about <a href="https://elevenlabs.io/voice-cloning" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">Voice Cloning</a> and the <a href="https://elevenlabs.io/docs/api-reference/introduction" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">API</a>.
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </aside>
            {isCloneModalOpen && (
                <VoiceCloneModal 
                    apiKey={elevenLabsApiKey}
                    onClose={() => setIsCloneModalOpen(false)}
                    onCloneSuccess={handleCloneSuccess}
                />
            )}
            {voiceSelectorOpenFor && (
                <VoiceSelectorModal
                    engine={voiceSelectorOpenFor}
                    isOpen={!!voiceSelectorOpenFor}
                    onClose={() => setVoiceSelectorOpenFor(null)}
                    elevenLabsVoices={elevenLabsVoices}
                    currentGeminiVoice={geminiVoice}
                    currentElevenLabsVoiceId={elevenLabsVoiceId}
                    onSelectGeminiVoice={(voice) => {
                        eventService.emit('settings:gemini_voice_change', voice);
                        setVoiceSelectorOpenFor(null);
                    }}
                    onSelectElevenLabsVoice={(voiceId) => {
                        eventService.emit('settings:elevenlabs_voice_change', voiceId);
                        setVoiceSelectorOpenFor(null);
                    }}
                    elevenLabsApiKey={elevenLabsApiKey}
                />
            )}
        </>
    );
};

export default ChapterList;