
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import hljs from "highlight.js";

interface Message {
    text: string;
    sender: 'user' | 'ai';
    grounding?: any[];
}

interface InputBuffer {
    id: string;
    value: string;
}

interface Persona {
    id: string;
    name: string;
    description: string;
    instruction: string;
}

interface ModuleState {
    id: string;
    x: number;
    y: number;
    w: number;
    h: number;
    isDecoupled: boolean;
    isOpen: boolean;
    zIndex: number;
}

const TOOLTIP_MAP: Record<string, string> = {
    "PYTHAI": "The core mastermind entity of the mindX agency.",
    "pythaiml": "Advanced libraries for machine learning (github.com/pythaiml).",
    "openmind": "Planning substrate where intent is earned.",
    "openmindX": "The bridge connecting preparation to authority.",
    "mindX": "Execution authority enforcing governance decisions.",
    "openDAO": "Decentralized legitimacy engine (Dev/Mkt/Comm).",
    "BANKON": "Identity-first cryptographic infrastructure.",
    "CEO Agent": "Strategic executive command in the mindX stack.",
    "RAGE": "Retrieval-Augmented Generative Engine - secure enterprise AI."
};

const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        notation: 'compact',
        maximumFractionDigits: 2
    }).format(value);
};

const renderer = new marked.Renderer();
renderer.code = (token: any) => {
    const text = token.text || '';
    const lang = token.lang || '';
    const language = (lang && hljs.getLanguage(lang)) ? lang : 'plaintext';
    const highlighted = hljs.highlight(text, { language }).value;
    return `<pre><code class="hljs language-${language}">${highlighted}</code></pre>`;
};
// @ts-ignore
marked.setOptions({ renderer, gfm: true, breaks: true });

const wrapKeywords = (text: any) => {
    if (typeof text !== 'string') return '';
    let result = text;
    const keywords = ["PYTHAI", "mindX", "openmind", "openmindX", "openDAO", "BANKON", "Mastermind", "RAGE", "CEO Agent"];
    keywords.forEach(keyword => {
        const regex = new RegExp(`(?<!<[^>]*)\\b${keyword}\\b(?![^<]*>)`, 'g');
        result = result.replace(regex, `<span class="keyword-highlight" data-tooltip="${TOOLTIP_MAP[keyword] || ''}">${keyword}</span>`);
    });
    return result;
};

const SOLDIERS = [
    { id: 'COO', name: 'Operations' },
    { id: 'CFO', name: 'Finance' },
    { id: 'CTO', name: 'Technology' },
    { id: 'CISO', name: 'Security' },
    { id: 'CLO', name: 'Legal' },
    { id: 'CPO', name: 'Product' },
    { id: 'CRO', name: 'Risk' }
];

const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { text: "Neural link established. **PYTHAI // Mastermind** online.\nArchitecture: **openmind** (Dojo) -> **openmindX** (Bridge) -> **mindX** (Execution).\nLegitimacy: **openDAO** verified. Infrastructure: **BANKON** identity-anchored.", sender: 'ai' }
    ]);
    const [inputBuffers, setInputBuffers] = useState<InputBuffer[]>([{ id: 'init', value: '' }]);
    const [isLoading, setIsLoading] = useState(false);
    
    const [personas, setPersonas] = useState<Persona[]>([]);
    const [activePersona, setActivePersona] = useState<Persona | null>(null);
    const [isPersonaMenuOpen, setIsPersonaMenuOpen] = useState(false);
    const [newPersona, setNewPersona] = useState<Persona>({ id: '', name: '', description: '', instruction: '' });

    // Module State Management
    const [modules, setModules] = useState<Record<string, ModuleState>>({
        resp: { id: 'resp', x: 0, y: 0, w: 680, h: 420, isDecoupled: false, isOpen: true, zIndex: 10 },
        input: { id: 'input', x: 0, y: 0, w: 680, h: 180, isDecoupled: false, isOpen: true, zIndex: 11 },
        soldiers: { id: 'soldiers', x: 0, y: 0, w: 680, h: 220, isDecoupled: false, isOpen: true, zIndex: 12 },
        dao: { id: 'dao', x: 0, y: 0, w: 680, h: 180, isDecoupled: false, isOpen: true, zIndex: 13 },
        bankon: { id: 'bankon', x: 0, y: 0, w: 680, h: 160, isDecoupled: false, isOpen: true, zIndex: 14 },
        dojo: { id: 'dojo', x: 0, y: 0, w: 680, h: 200, isDecoupled: false, isOpen: false, zIndex: 15 },
        llama: { id: 'llama', x: 0, y: 0, w: 680, h: 450, isDecoupled: false, isOpen: false, zIndex: 16 },
        diag: { id: 'diag', x: 0, y: 0, w: 680, h: 140, isDecoupled: false, isOpen: true, zIndex: 17 }
    });

    const [diagnostics, setDiagnostics] = useState({ ip: '127.0.0.1', os: navigator.platform, load: 2, mem: 35, rage: 'Optimized' });
    const [soldierStatus, setSoldierStatus] = useState<Record<string, boolean>>({
        COO: true, CFO: true, CTO: true, CISO: true, CLO: true, CPO: true, CRO: true
    });
    const [daoStatus, setDaoStatus] = useState({ dev: 0.92, mkt: 0.78, comm: 0.81 });
    const [bankonProof, setBankonProof] = useState({ verified: true, wallet: '0x...1271', tier: 'A', status: 'Sovereign' });
    const [defiMetrics, setDefiMetrics] = useState({ totalTvl: 0, ethTvl: 0, polyTvl: 0, bscTvl: 0, dominance: '...' });
    const [dojoContent, setDojoContent] = useState('// Ideation scratchpad. Intent is earned here.\nProposal: "Augmentic Intelligence scaling protocol v2.1"\nStatus: Preparation...');

    const activeDrag = useRef<string | null>(null);
    const activeResize = useRef<string | null>(null);
    const dragOffset = useRef({ x: 0, y: 0 });
    const longPressTimer = useRef<number | null>(null);
    const topZ = useRef(40);
    const chatWindowRef = useRef<HTMLDivElement>(null);

    const resetAllPositions = useCallback(() => {
        const isMobile = window.innerWidth < 768;
        const w = isMobile ? window.innerWidth * 0.96 : 680;
        const startX = (window.innerWidth - w) / 2;
        let currentY = 70; // Offset for control bar

        setModules(prev => {
            const updated = { ...prev };
            const order = ['resp', 'input', 'soldiers', 'dao', 'bankon', 'dojo', 'llama', 'diag'];
            order.forEach(id => {
                if (updated[id].isOpen) {
                    updated[id] = {
                        ...updated[id],
                        x: startX,
                        y: currentY,
                        w: w,
                        isDecoupled: false,
                        zIndex: 10
                    };
                    currentY += updated[id].h + 15;
                }
            });
            return updated;
        });
    }, []);

    useEffect(() => {
        resetAllPositions();
        fetch('/persona.json').then(res => res.json()).then(data => {
            setPersonas(data.personas);
            setActivePersona(data.personas[0]);
        }).catch(() => {
            const fallback = [{ id: 'pythai', name: 'PYTHAI // MASTERMIND', description: 'The executive intelligence.', instruction: 'You are PYTHAI.' }];
            setPersonas(fallback);
            setActivePersona(fallback[0]);
        });

        const fetchDefi = async () => {
            try {
                const [pRes, cRes] = await Promise.all([
                    fetch('https://api.llama.fi/api/protocols'),
                    fetch('https://api.llama.fi/api/v2/chains')
                ]);
                const protocols = await pRes.json();
                const chains = await cRes.json();
                const totalTvl = protocols.reduce((acc: number, p: any) => acc + (p.tvl || 0), 0);
                const eth = chains.find((c: any) => c.name.toLowerCase() === 'ethereum');
                const poly = chains.find((c: any) => c.name.toLowerCase() === 'polygon');
                const bsc = chains.find((c: any) => c.name.toLowerCase() === 'bsc');
                setDefiMetrics({
                    totalTvl,
                    ethTvl: eth?.tvl || 0,
                    polyTvl: poly?.tvl || 0,
                    bscTvl: bsc?.tvl || 0,
                    dominance: eth ? `${((eth.tvl / totalTvl) * 100).toFixed(1)}%` : '...',
                });
            } catch (e) {}
        };
        fetchDefi();
        
        const interval = setInterval(() => {
            setDiagnostics(d => ({ 
                ...d, 
                load: Math.floor(Math.random() * 8) + 1, 
                mem: 32 + Math.random() * 5,
                rage: Math.random() > 0.1 ? 'Optimized' : 'Syncing...'
            }));
            setSoldierStatus(prev => {
                const keys = Object.keys(prev);
                const key = keys[Math.floor(Math.random() * keys.length)];
                return { ...prev, [key]: Math.random() > 0.05 };
            });
            setDaoStatus(prev => ({
                dev: Math.min(1, Math.max(0.5, prev.dev + (Math.random() - 0.5) * 0.02)),
                mkt: Math.min(1, Math.max(0.5, prev.mkt + (Math.random() - 0.5) * 0.02)),
                comm: Math.min(1, Math.max(0.5, prev.comm + (Math.random() - 0.5) * 0.02)),
            }));
        }, 4000);
        return () => clearInterval(interval);
    }, [resetAllPositions]);

    const handleMouseDown = (e: React.MouseEvent | React.TouchEvent, id: string, type: 'drag' | 'resize') => {
        const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
        const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

        if ((e.target as HTMLElement).closest('button') || 
            (e.target as HTMLElement).closest('.persona-menu') ||
            (e.target as HTMLElement).closest('textarea') ||
            (e.target as HTMLElement).closest('input')) return;

        topZ.current += 1;
        setModules(prev => ({ ...prev, [id]: { ...prev[id], zIndex: topZ.current } }));

        if (type === 'resize') {
            activeResize.current = id;
            dragOffset.current = { x: clientX, y: clientY };
        } else {
            activeDrag.current = id;
            dragOffset.current = { x: clientX - modules[id].x, y: clientY - modules[id].y };
            longPressTimer.current = window.setTimeout(() => {
                setModules(prev => ({ ...prev, [id]: { ...prev[id], isDecoupled: true } }));
                document.body.classList.add('is-decoupling');
            }, 450);
        }
    };

    const removePersona = (id: string) => {
        setPersonas(prev => {
            const filtered = prev.filter(p => p.id !== id);
            if (activePersona?.id === id) {
                setActivePersona(filtered.length > 0 ? filtered[0] : null);
            }
            return filtered;
        });
    };

    const handleSendMessage = async (textToSend: string, bufferId?: string) => {
        if (!textToSend.trim() || isLoading) return;
        setMessages(prev => [...prev, { text: textToSend, sender: 'user' }, { text: '', sender: 'ai' }]);
        setInputBuffers(prev => prev.map(b => b.id === bufferId ? { ...b, value: '' } : b));
        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-lite-latest',
                contents: textToSend,
                config: { 
                    systemInstruction: `${activePersona?.instruction || "You are PYTHAI."} Follow the architecture: openmind (Dojo), openmindX (Bridge), mindX (Execution).`,
                    tools: [{ googleMaps: {} }, { googleSearch: {} }]
                }
            });
            const text = response.text || "Direct cognitive link lost.";
            setMessages(prev => {
                const next = [...prev];
                next[next.length - 1] = { text, sender: 'ai', grounding: response.candidates?.[0]?.groundingMetadata?.groundingChunks };
                return next;
            });
        } catch (e) {
            setMessages(prev => [...prev.slice(0, -1), { text: "Neural link disruption detected.", sender: 'ai' }]);
        } finally {
            setIsLoading(false);
        }
    };

    const toggleModule = (id: string) => {
        setModules(prev => {
            const isOpen = !prev[id].isOpen;
            return { ...prev, [id]: { ...prev[id], isOpen } };
        });
    };

    const renderModule = (id: string, title: string, content: React.ReactNode) => {
        const mod = modules[id];
        if (!mod.isOpen) return null;
        return (
            <div 
                className={`module ${id}-module ${mod.isDecoupled ? 'decoupled' : 'linked'}`}
                style={{ left: mod.x, top: mod.y, width: mod.w, height: mod.h, zIndex: mod.zIndex }}
                onMouseDown={(e) => handleMouseDown(e, id, 'drag')}
                onTouchStart={(e) => handleMouseDown(e, id, 'drag')}
            >
                <div className="module-handle">
                    <span>{title}</span>
                    <div className="mod-controls">
                        <button onClick={(e) => { e.stopPropagation(); setModules(prev => ({...prev, [id]: {...prev[id], isDecoupled: !prev[id].isDecoupled}})) }} title="Toggle Dock">{mod.isDecoupled ? '⚓' : '🔗'}</button>
                        <button onClick={(e) => { e.stopPropagation(); toggleModule(id); }}>×</button>
                    </div>
                </div>
                <div className="module-inner">
                    {content}
                </div>
                <div className="resize-handle" onMouseDown={(e) => { e.stopPropagation(); handleMouseDown(e, id, 'resize'); }}></div>
            </div>
        );
    };

    return (
        <div className="workspace">
            {/* Mastermind Control Bar */}
            <div className="substrate-control-bar">
                <div className="bar-logo">
                    <img src="https://agenticplace.pythai.net/agentaitrans.png" className="bar-img" />
                    <span>MINDX_CORE</span>
                </div>
                <div className="bar-buttons">
                    {Object.keys(modules).map(id => (
                        <button key={id} className={modules[id].isOpen ? 'active' : ''} onClick={() => toggleModule(id)}>
                            {id.toUpperCase()}
                        </button>
                    ))}
                </div>
                <div className="bar-actions">
                    <button onClick={resetAllPositions}>STACK_ALL</button>
                </div>
            </div>

            {renderModule('resp', `PYTHAI // ${activePersona?.name || 'MASTERMIND'}`, (
                <>
                    <header className="inner-header">
                        <div className="header-meta">
                           <a href="https://github.com/pythaiml" target="_blank" className="github-link">GITHUB // pythaiml</a>
                        </div>
                        <div className="header-actions">
                            <button className="persona-btn" onClick={() => setIsPersonaMenuOpen(!isPersonaMenuOpen)}>
                                {activePersona?.id.toUpperCase()}
                            </button>
                        </div>
                        {isPersonaMenuOpen && (
                            <div className="persona-menu">
                                <div className="persona-list">
                                    {personas.map(p => (
                                        <div key={p.id} className={`persona-item ${activePersona?.id === p.id ? 'active' : ''}`} onClick={() => { setActivePersona(p); setIsPersonaMenuOpen(false); }}>
                                            <div className="p-info">
                                                <b>{p.name}</b>
                                                <p>{p.description}</p>
                                            </div>
                                            <button className="del-persona" onClick={(e) => { e.stopPropagation(); removePersona(p.id); }}>×</button>
                                        </div>
                                    ))}
                                </div>
                                <form className="persona-add-form" onSubmit={(e) => { e.preventDefault(); if (newPersona.id) { setPersonas([...personas, newPersona]); setNewPersona({id:'', name:'', description:'', instruction:''}); } }}>
                                    <input placeholder="ID" value={newPersona.id} onChange={e => setNewPersona({...newPersona, id: e.target.value})} required />
                                    <input placeholder="Name" value={newPersona.name} onChange={e => setNewPersona({...newPersona, name: e.target.value})} required />
                                    <textarea placeholder="System Instruction" value={newPersona.instruction} onChange={e => setNewPersona({...newPersona, instruction: e.target.value})} required />
                                    <button type="submit">+ INJECT IDENTITY</button>
                                </form>
                            </div>
                        )}
                    </header>
                    <div ref={chatWindowRef} className="chat-area">
                        {messages.map((m, i) => (
                            <div key={i} className={`message ${m.sender}`}>
                                <div dangerouslySetInnerHTML={{ __html: wrapKeywords(marked.parse(m.text)) }} />
                                {m.grounding && m.grounding.length > 0 && (
                                    <div className="grounding-sources">
                                        <div className="source-label">SOURCES:</div>
                                        <ul className="source-list">
                                            {m.grounding.map((chunk: any, ci: number) => {
                                                const source = chunk.web || chunk.maps;
                                                if (!source) return null;
                                                return (
                                                    <li key={ci}><a href={source.uri} target="_blank" rel="noopener noreferrer">{source.title || source.uri}</a></li>
                                                );
                                            })}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </>
            ))}

            {renderModule('input', 'DIRECTIVE_TRANSMITTER', (
                <div className="input-substrate">
                    {inputBuffers.map(b => (
                        <form key={b.id} className="input-form" onSubmit={(e) => { e.preventDefault(); handleSendMessage(b.value, b.id); }}>
                            <textarea value={b.value} onChange={(e) => setInputBuffers(prev => prev.map(buf => buf.id === b.id ? {...buf, value: e.target.value} : buf))} placeholder="TRANSMIT_DIRECTIVE to mindX..." />
                            <button type="submit" disabled={isLoading}>SEND</button>
                        </form>
                    ))}
                    <div className="input-btns">
                        <button onClick={() => setInputBuffers([...inputBuffers, { id: Math.random().toString(), value: '' }])}>+ BUFFER</button>
                    </div>
                </div>
            ))}

            {renderModule('soldiers', 'MINDX // EXECUTIVE_SOLDIERS', (
                <div className="soldiers-substrate">
                    <div className="soldier-grid">
                        <div className="ceo-status">
                            <label>CEO_AGENT</label>
                            <div className="status-indicator active">SOVEREIGN</div>
                        </div>
                        {SOLDIERS.map(s => (
                            <div key={s.id} className="soldier-card">
                                <label>{s.id}</label>
                                <div className={`status-dot ${soldierStatus[s.id] ? 'alive' : 'stale'}`}></div>
                                <span className="s-name">{s.name}</span>
                            </div>
                        ))}
                    </div>
                    <div className="consensus-meter">
                        <label>CONSENSUS_THRESHOLD (2/3 REQ)</label>
                        <div className="meter-bar">
                            <div className="fill" style={{ width: `${(Object.values(soldierStatus).filter(v => v).length / 7) * 100}%` }}></div>
                        </div>
                    </div>
                </div>
            ))}

            {renderModule('dao', 'OPENDAO // DOMAIN_LEGITIMACY', (
                <div className="dao-substrate">
                    <div className="dao-grid">
                        <div className="domain-card">
                            <label>DEVELOPMENT</label>
                            <div className="domain-val">{(daoStatus.dev * 100).toFixed(0)}%</div>
                            <div className="progress"><div className="fill" style={{ width: `${daoStatus.dev * 100}%` }}></div></div>
                        </div>
                        <div className="domain-card">
                            <label>MARKETING</label>
                            <div className="domain-val">{(daoStatus.mkt * 100).toFixed(0)}%</div>
                            <div className="progress"><div className="fill" style={{ width: `${daoStatus.mkt * 100}%` }}></div></div>
                        </div>
                        <div className="domain-card">
                            <label>COMMUNITY</label>
                            <div className="domain-val">{(daoStatus.comm * 100).toFixed(0)}%</div>
                            <div className="progress"><div className="fill" style={{ width: `${daoStatus.comm * 100}%` }}></div></div>
                        </div>
                    </div>
                    <div className="dao-summary">
                        <span className="legitimacy-badge">2/3 MAJORITY REACHED</span>
                    </div>
                </div>
            ))}

            {renderModule('bankon', 'BANKON // IDENTITY_INFRA', (
                <div className="bankon-substrate">
                    <div className="proof-row">
                        <div className="proof-item">
                            <label>PROOF_STATE</label>
                            <span className="proof-val neon-text">{bankonProof.status}</span>
                        </div>
                        <div className="proof-item">
                            <label>WALLET_BOUND</label>
                            <span className="proof-val">{bankonProof.wallet}</span>
                        </div>
                        <div className="proof-item">
                            <label>ERC-1271_TIER</label>
                            <span className="proof-val">{bankonProof.tier}</span>
                        </div>
                    </div>
                    <div className="identity-log">Verified identity detected: agent-bound cryptographic proof stable.</div>
                </div>
            ))}

            {renderModule('dojo', 'OPENMIND // DOJO_SCRATCHPAD', (
                <div className="dojo-substrate">
                    <textarea 
                        value={dojoContent} 
                        onChange={(e) => setDojoContent(e.target.value)} 
                        placeholder="Ideas are forged here..."
                    />
                    <div className="dojo-meta">
                        <span>PLANNING_MODE: ACTIVE</span>
                        <span>READINESS: 84%</span>
                    </div>
                </div>
            ))}

            {renderModule('llama', 'DEFILLAMA // LIQUIDITY', (
                <div className="llama-substrate">
                    <div className="llama-card primary">
                        <label>GLOBAL_TVL (SEC_1)</label>
                        <div className="card-val highlight">{formatCurrency(defiMetrics.totalTvl)}</div>
                        <div className="card-sub">DOMINANCE: {defiMetrics.dominance}</div>
                    </div>
                    <div className="llama-grid-triple">
                        <div className="llama-card"><label>ETH</label><div className="card-val small">{formatCurrency(defiMetrics.ethTvl)}</div></div>
                        <div className="llama-card"><label>BSC</label><div className="card-val small">{formatCurrency(defiMetrics.bscTvl)}</div></div>
                        <div className="llama-card"><label>POLYGON</label><div className="card-val small">{formatCurrency(defiMetrics.polyTvl)}</div></div>
                    </div>
                </div>
            ))}

            {renderModule('diag', 'SUBSTRATE_DIAGNOSTICS', (
                <div className="diag-substrate">
                    <div className="diag-row"><span>RAGE_ENGINE:</span> <span className="neon-text">{diagnostics.rage}</span></div>
                    <div className="diag-row"><span>LOAD_FACTOR:</span> <span>{diagnostics.load}%</span></div>
                    <div className="diag-row"><span>MEM_RESERVE:</span> <span>{diagnostics.mem.toFixed(1)}GB</span></div>
                    <div className="diag-meter">
                        <div className="meter-bar"><div className="fill" style={{ width: `${diagnostics.load}%` }}></div></div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
