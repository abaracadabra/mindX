
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import { epistemic, LogEntry } from './epistemic.ts';
import { Visualizer, DAOBoard, PersonaSelector } from './SubstrateComponents.tsx';
import { personasData } from './persona.ts';

interface Message {
    text: string;
    sender: 'user' | 'ai';
    persona?: string;
}

interface ResponseWindowState {
    id: string; // Persona ID
    text: string;
    x: number;
    y: number;
    w: number;
    h: number;
    isDecoupled: boolean;
    isCollapsed: boolean;
    zIndex: number;
}

const SECTIONS = [
    { name: "CORE_COMMAND", id: 0, persona: 'pythai' },
    { name: "BOARD_CONSENSUS", id: 1, persona: 'mindx' },
    { name: "SUBSTRATE_TELEMETRY", id: 2, persona: 'rage' }
];

const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { text: "Neural link established. **PYTHAI // AGENTIC_MASTERMIND** ready for instruction.", sender: 'ai', persona: 'pythai' }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [activePersona, setActivePersona] = useState('pythai');
    const [showOverlay, setShowOverlay] = useState(false);
    const [overlayState, setOverlayState] = useState<'input' | 'thinking' | 'response'>('input');
    const [overlayResponse, setOverlayResponse] = useState<string>('');
    const [currentSection, setCurrentSection] = useState(0);
    const [logs, setLogs] = useState<LogEntry[]>([]);

    // Console State
    const [consolePos, setConsolePos] = useState({ x: 60, y: 140 });
    const [consoleSize, setConsoleSize] = useState({ w: 560, h: 320 });
    
    // Multi-Response Window State
    const [responseWindows, setResponseWindows] = useState<ResponseWindowState[]>([]);
    const [maxZIndex, setMaxZIndex] = useState(8001);

    const draggingConsole = useRef(false);
    const draggingResponseId = useRef<string | null>(null);
    const resizingConsole = useRef(false);
    const resizingResponseId = useRef<string | null>(null);
    const dragOffset = useRef({ x: 0, y: 0 });
    const lastScrollTime = useRef(0);

    const getSystemInstruction = (pid: string) => {
        const found = personasData.personas.find(p => p.id === pid) || personasData.personas[0];
        return found.instruction + " Use absolute authority. Format with Markdown.";
    };

    const togglePersonaWindow = (pid: string) => {
        setActivePersona(pid);
        setResponseWindows(prev => {
            const exists = prev.find(w => w.id === pid);
            if (exists) {
                return prev.map(w => w.id === pid ? { ...w, zIndex: maxZIndex + 1 } : w);
            } else {
                const offsetStep = 35;
                const windowCount = prev.length;
                const newWindow: ResponseWindowState = {
                    id: pid,
                    text: `**${pid.toUpperCase()}** SUBSTRATE_LINK: AWAITING_DIRECTIVE...`,
                    x: consolePos.x + 30 + (windowCount * offsetStep),
                    y: consolePos.y + consoleSize.h + 20 + (windowCount * offsetStep),
                    w: 560,
                    h: 300,
                    isDecoupled: false,
                    isCollapsed: false,
                    zIndex: maxZIndex + 1
                };
                return [...prev, newWindow];
            }
        });
        setMaxZIndex(prev => prev + 1);
    };

    const closeResponseWindow = (pid: string) => {
        setResponseWindows(prev => prev.filter(w => w.id !== pid));
    };

    const changeSection = (id: number) => {
        if (id < 0 || id >= SECTIONS.length) return;
        setCurrentSection(id);
        const suggestedPersona = SECTIONS.find(s => s.id === id)?.persona;
        if (suggestedPersona) {
            togglePersonaWindow(suggestedPersona);
        }
    };

    useEffect(() => {
        const handleWheel = (e: WheelEvent) => {
            if (showOverlay) return;
            const now = Date.now();
            if (now - lastScrollTime.current < 800) return; // Throttle scroll
            
            if (e.deltaY > 50) {
                changeSection(currentSection + 1);
                lastScrollTime.current = now;
            } else if (e.deltaY < -50) {
                changeSection(currentSection - 1);
                lastScrollTime.current = now;
            }
        };

        const handleKeyDown = (e: KeyboardEvent) => {
            if (showOverlay) return;
            if (e.key === 'ArrowDown') changeSection(currentSection + 1);
            if (e.key === 'ArrowUp') changeSection(currentSection - 1);
        };

        window.addEventListener('wheel', handleWheel, { passive: false });
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('wheel', handleWheel);
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [currentSection, showOverlay]);

    const handleSendMessage = async (text: string, isOverlay: boolean = false) => {
        if (!text.trim() || isLoading) return;
        
        if (isOverlay) {
            setOverlayState('thinking');
            setOverlayResponse('');
        } else {
            setMessages(prev => [...prev, { text, sender: 'user' }]);
            setInputValue('');
            const exists = responseWindows.find(w => w.id === activePersona);
            if (!exists) togglePersonaWindow(activePersona);
        }

        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const instruction = getSystemInstruction(activePersona);
            
            const response = await ai.models.generateContent({
                model: 'gemini-3-pro-preview',
                contents: text,
                config: { 
                    systemInstruction: instruction,
                    thinkingConfig: { thinkingBudget: 16000 } 
                }
            });

            const aiText = response.text || "SUBSTRATE_TIMEOUT: NO_DATA_RETURNED";
            
            if (isOverlay) {
                setOverlayResponse(aiText);
                setOverlayState('response');
            } else {
                setMessages(prev => [...prev, { text: aiText, sender: 'ai', persona: activePersona }]);
                setResponseWindows(prev => prev.map(w => 
                    w.id === activePersona 
                    ? { ...w, text: aiText, isCollapsed: false, zIndex: maxZIndex + 1 } 
                    : w
                ));
                setMaxZIndex(prev => prev + 1);
            }
            epistemic.logEvent("DirectiveProcessed", `Mode [${activePersona.toUpperCase()}] broadcast response.`);
        } catch (e: any) {
            const err = "CRITICAL_FAILURE: " + e.message;
            if (isOverlay) {
                setOverlayResponse(err);
                setOverlayState('response');
            } else {
                setMessages(prev => [...prev, { text: err, sender: 'ai', persona: activePersona }]);
            }
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (draggingConsole.current) {
                setConsolePos({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
            } else if (resizingConsole.current) {
                setConsoleSize({ w: Math.max(400, e.clientX - consolePos.x), h: Math.max(200, e.clientY - consolePos.y) });
            } else if (draggingResponseId.current) {
                const rid = draggingResponseId.current;
                setResponseWindows(prev => prev.map(w => 
                    w.id === rid 
                    ? { ...w, x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y, isDecoupled: true } 
                    : w
                ));
            } else if (resizingResponseId.current) {
                const rid = resizingResponseId.current;
                setResponseWindows(prev => prev.map(w => {
                    if (w.id !== rid) return w;
                    const originX = w.isDecoupled ? w.x : consolePos.x + 20;
                    const originY = w.isDecoupled ? w.y : (consolePos.y + consoleSize.h + 10);
                    return { ...w, w: Math.max(300, e.clientX - originX), h: Math.max(100, e.clientY - originY) };
                }));
            }
        };
        const handleMouseUp = () => {
            draggingConsole.current = false;
            draggingResponseId.current = null;
            resizingConsole.current = false;
            resizingResponseId.current = null;
        };
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [consolePos, consoleSize, responseWindows]);

    useEffect(() => {
        const unsubscribeLogs = epistemic.subscribe(() => setLogs(epistemic.getLogs()));
        return () => unsubscribeLogs();
    }, []);

    const copyText = (text: string) => {
        navigator.clipboard.writeText(text);
        epistemic.logEvent("DataTransfer", "Content cloned to clipboard.");
    };

    return (
        <div className="app-container">
            <div className="master-backdrop-substrate"></div>

            {/* Draggable Command Console */}
            {currentSection === 0 && !showOverlay && (
                <>
                <div 
                    className="master-console-floating"
                    style={{ left: consolePos.x, top: consolePos.y, width: consoleSize.w, height: consoleSize.h }}
                >
                    <div className="console-handle" onMouseDown={(e) => {
                        draggingConsole.current = true;
                        dragOffset.current = { x: e.clientX - consolePos.x, y: e.clientY - consolePos.y };
                    }}>
                        <div className="handle-left">
                           <div className="console-status-light"></div>
                           <span className="handle-text">PYTHAI // CORE_COMMAND_v8.2</span>
                        </div>
                        <div className="handle-dots">•••</div>
                    </div>
                    <div className="console-body">
                        <PersonaSelector current={activePersona} onSelect={togglePersonaWindow} />
                        <textarea 
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            placeholder={`INSTRUCT_${activePersona.toUpperCase()}_CORE...`}
                            onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(inputValue); } }}
                        />
                        <div className="console-toolkit">
                            <button className="tool-btn" onClick={() => { setOverlayState('input'); setShowOverlay(true); }}>ASCEND_COMMAND</button>
                            <button className="tool-btn transmit-btn" onClick={() => handleSendMessage(inputValue)}>TRANSMIT</button>
                        </div>
                    </div>
                    <div className="console-resize-handle" onMouseDown={() => resizingConsole.current = true}></div>
                </div>

                {responseWindows.map((rw, index) => {
                    const style: React.CSSProperties = rw.isDecoupled 
                        ? { left: rw.x, top: rw.y, width: rw.w, zIndex: rw.zIndex, position: 'fixed' }
                        : { left: consolePos.x + 20 + (index * 15), top: consolePos.y + consoleSize.h + 10 + (index * 35), width: consoleSize.w, zIndex: rw.zIndex, position: 'fixed' };
                    
                    if (!rw.isCollapsed) style.height = rw.h;
                    else style.height = 'auto';

                    return (
                        <div 
                            key={rw.id}
                            className={`response-window-floating ${rw.isDecoupled ? 'decoupled' : ''} ${rw.isCollapsed ? 'collapsed' : ''} ${activePersona === rw.id ? 'active-focus' : ''}`}
                            style={style}
                            onMouseDown={() => {
                                setResponseWindows(prev => prev.map(w => w.id === rw.id ? { ...w, zIndex: maxZIndex + 1 } : w));
                                setMaxZIndex(prev => prev + 1);
                                setActivePersona(rw.id);
                            }}
                        >
                            <div className="response-handle" onMouseDown={(e) => {
                                draggingResponseId.current = rw.id;
                                const startX = rw.isDecoupled ? rw.x : consolePos.x + 20 + (index * 15);
                                const startY = rw.isDecoupled ? rw.y : (consolePos.y + consoleSize.h + 10 + (index * 35));
                                dragOffset.current = { x: e.clientX - startX, y: e.clientY - startY };
                            }}>
                                <div className="handle-left">
                                    <span className="handle-text">{rw.id.toUpperCase()}</span>
                                    {rw.isDecoupled && <span className="decoupled-tag">DECOUPLED</span>}
                                </div>
                                <div className="handle-actions">
                                    <button className="action-btn" onClick={(e) => { e.stopPropagation(); copyText(rw.text); }}>COPY</button>
                                    <button className="action-btn" onClick={(e) => { e.stopPropagation(); setResponseWindows(p => p.map(w => w.id === rw.id ? {...w, isCollapsed: !w.isCollapsed} : w)); }}>
                                        {rw.isCollapsed ? 'MAX' : 'MIN'}
                                    </button>
                                    <button className="action-btn close-btn" onClick={(e) => { e.stopPropagation(); closeResponseWindow(rw.id); }}>✕</button>
                                </div>
                            </div>
                            {!rw.isCollapsed && (
                                <div className="response-content-area">
                                    <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(rw.text) as string }} />
                                </div>
                            )}
                            {!rw.isCollapsed && <div className="console-resize-handle" onMouseDown={(e) => { e.stopPropagation(); resizingResponseId.current = rw.id; }}></div>}
                        </div>
                    );
                })}
                </>
            )}

            {/* Vertical Side Navigation */}
            <div className="side-nav-substrate">
                {SECTIONS.map(s => (
                    <div 
                        key={s.id} 
                        className={`nav-item ${currentSection === s.id ? 'active' : ''}`}
                        onClick={() => changeSection(s.id)}
                    >
                        <div className="nav-dot"></div>
                        <div className="nav-label">{s.name.replace('_', ' ')}</div>
                    </div>
                ))}
            </div>

            {/* Supreme Directive Overlay */}
            {showOverlay && (
                <div className="supreme-overlay">
                    <button className="close-overlay" onClick={() => { setShowOverlay(false); setOverlayResponse(''); setOverlayState('input'); }}>×</button>
                    <div className={`overlay-portal-container overlay-state-${overlayState}`}>
                        
                        {overlayState === 'input' && (
                            <div className="directive-input-group animate-focus">
                                <div className="overlay-badge">AUTH_LEVEL: MASTERMIND // {activePersona.toUpperCase()}</div>
                                <h2>SUPREME_DIRECTIVE</h2>
                                <textarea 
                                    autoFocus
                                    placeholder="TYPE COMMAND..."
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSendMessage(e.currentTarget.value, true);
                                        }
                                    }}
                                />
                                <div className="overlay-hint">PRESS [ENTER] TO BROADCAST</div>
                            </div>
                        )}

                        {overlayState === 'thinking' && (
                            <div className="directive-thinking animate-probe">
                                <div className="thinking-center">
                                    <div className="scanning-effect">ANALYZING_NEURAL_STREAMS...</div>
                                    <div className="geometry-pulse">
                                        <div className="pulse-ring"></div>
                                        <div className="pulse-ring delay-1"></div>
                                        <div className="pulse-ring delay-2"></div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {overlayState === 'response' && (
                            <div className="directive-response-found animate-emerge">
                                <div className="found-content">
                                    <div className="response-header">BROADCAST_READY</div>
                                    <div className="response-body markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(overlayResponse) as string }} />
                                    <div className="found-footer">
                                        <button className="reset-directive" onClick={() => setOverlayState('input')}>NEW_DIRECTIVE</button>
                                    </div>
                                </div>
                            </div>
                        )}
                        
                    </div>
                </div>
            )}

            <div className="workspace" style={{ transform: `translateY(-${currentSection * 100}vh)` }}>
                <div className="substrate-control-bar">
                    <div className="bar-logo">
                        <img src="https://agenticplace.pythai.net/agentaitrans.png" className="bar-img" alt="logo" />
                        <div className="logo-text">
                           <span className="brand">PYTHAI</span>
                           <span className="subtitle">MASTERMIND // SUBSTRATE</span>
                        </div>
                    </div>
                    <div className="bar-tabs">
                        {SECTIONS.map(s => (
                            <button 
                              key={s.id} 
                              className={`tab-btn ${currentSection === s.id ? 'active' : ''}`} 
                              onClick={() => changeSection(s.id)}
                            >
                                {s.name}
                            </button>
                        ))}
                    </div>
                    <div className="bar-status">
                        <div className="status-label">AUTH_LEVEL: ROOT_MASTER</div>
                        <div className="status-value">CONNECTED</div>
                    </div>
                </div>

                <div className="section-container core-section">
                    <div className="main-grid-layout">
                        <div className="grid-left glass-module">
                            <div className="feed-header">NEURAL_FEED_STREAM</div>
                            <div className="chat-area">
                                {messages.map((m, i) => (
                                    <div key={i} className={`message ${m.sender}`}>
                                        <div className="m-tag">{m.sender === 'user' ? 'ROOT' : m.persona?.toUpperCase() || 'MASTERMIND'}</div>
                                        <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(m.text) as string }} />
                                    </div>
                                ))}
                                {isLoading && !showOverlay && (
                                    <div className="message ai thinking-dots">
                                        <div className="m-tag">{activePersona.toUpperCase()}</div>
                                        <div className="dots-pulse">TRANSMITTING...</div>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="grid-right glass-module">
                           <Visualizer />
                        </div>
                    </div>
                </div>

                <div className="section-container board-section">
                    <div className="consensus-module-full glass-module">
                        <div className="module-title-bar">
                           <span className="m-title">EXECUTIVE_CONSENSUS_GRID</span>
                           <span className="m-version">VERSION_9.2_SUBSTRATE</span>
                        </div>
                        <DAOBoard />
                    </div>
                </div>

                <div className="section-container logs-section">
                    <div className="logs-module-full glass-module">
                        <div className="logs-header">SUBSTRATE_TELEMETRY</div>
                        <div className="logs-scroll">
                            {logs.map((l, i) => (
                                <div key={i} className="log-line">
                                    <span className="l-time">[{l.timestamp.split('T')[1].slice(0,8)}]</span>
                                    <span className="l-type">{l.eventType.toUpperCase()}</span>
                                    <span className="l-msg">{l.message}</span>
                                </div>
                            ))}
                            {logs.length === 0 && <div className="no-logs">WAITING_FOR_DATA_STREAM...</div>}
                        </div>
                    </div>
                </div>
            </div>

            <div className="bottom-bar">
                <div className="nav-info">MASTERMIND_LINK: <span className="text-accent">ESTABLISHED</span></div>
                <div className="nav-info text-dim">LAYER_ID: {SECTIONS[currentSection].name}</div>
                <div className="nav-info text-dim">SUBSTRATE_TIME: {new Date().toLocaleTimeString()}</div>
            </div>
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
