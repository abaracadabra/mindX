/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";

interface Message {
    text: string;
    sender: 'user' | 'ai';
}

const HELP_COMMAND_RESPONSE = `
As a mastermind AI, I can execute a range of directives. Your wish is my mind command.

### Core Commands
- **evolve <directive>**: Task Mastermind to EVOLVE its own codebase.
- **deploy <directive>**: Task AutoMINDX/Mastermind to DEPLOY new agents to achieve a goal.
- **introspect <role>**: Ask AutoMINDX to generate a new persona for a given role.
- **mastermind_status**: Display Mastermind's objectives and campaign history.
- **show_agent_registry**: Display the agents registered with the Coordinator.
- **analyze_codebase <path> [focus]**: Analyze codebase using its internal analyzer.
- **basegen <path>**: Generate Markdown docs for a path.

### Identity Manager Commands
- **id_list**: List all identities managed by IDManager.
- **id_create <entity_id>**: Create a new cryptographic identity.
- **id_deprecate <public_address> [hint]**: Deprecate (remove) a managed identity.

### Coordinator Commands
- **coord_query <question>**: Send query to Coordinator's LLM.
- **coord_analyze [context]**: Trigger Coordinator's system analysis.
- **coord_improve <component_id> [context]**: Request Coordinator improve a component.
- **coord_backlog**: Display Coordinator's improvement backlog.
- **coord_process_backlog**: Trigger processing of one backlog item.
- **coord_approve <item_id>**: Approve a backlog item.
- **coord_reject <item_id>**: Reject a backlog item.

### Agent Lifecycle Commands
- **agent_create <type> <id> [config]**: Create a new agent.
- **agent_delete <id>**: Delete an agent.
- **agent_list**: List all registered agents.
- **agent_evolve <id> <directive>**: Evolve a specific agent.
- **agent_sign <id> <message>**: Sign a message with an agent's identity.

### Utility Commands
- **audit_gemini --test-all|--update-config**: Audit Gemini models.
- **help**: Show this help message.
`;

// Configure marked with a custom renderer for interactive elements
const renderer = new marked.Renderer();
renderer.strong = ({ text }: any) => {
    // Guard against undefined text during streaming
    if (!text) return ''; 
    
    // Unescape HTML entities for the data-command attribute
    const commandText = text.replace(/&lt;/g, '<').replace(/&gt;/, '>');
    return `<button class="command-button" data-command="${commandText}">${text}</button>`;
};
renderer.code = ({ text: code, lang: infostring }: any) => {
    // Guard against undefined code during streaming
    const safeCode = code || ''; 
    const lang = (infostring || '').match(/\S*/)?.[0];
    const escapedCode = safeCode.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    return `
        <div class="code-block-wrapper">
            <pre><code class="language-${lang}">${escapedCode}</code></pre>
            <button class="copy-button" aria-label="Copy code to clipboard">Copy</button>
        </div>
    `;
};

marked.use({
    gfm: true,
    breaks: true,
    renderer,
});


const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { text: "Welcome to AgenticPlace. I am PYTHAI, a mastermind AI from the mindX Augmentic Intelligence agency. Your wish is my mind command. Type `/help` to see available commands or transmit your query.", sender: 'ai' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatWindowRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);
    const appContainerRef = useRef<HTMLDivElement>(null);
    const isPointerDown = useRef(false);

    // 3D holographic effect on pointer move
    useEffect(() => {
        const container = appContainerRef.current;
        if (!container) return;

        const handlePointerDown = () => {
            isPointerDown.current = true;
        };
        const handlePointerUp = () => {
            isPointerDown.current = false;
        };

        const handlePointerMove = (e: PointerEvent) => {
            if (isPointerDown.current) return; // Don't transform while clicking/dragging

            const { clientX, clientY } = e;
            const rect = container.getBoundingClientRect();
            
            const x = (clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
            const y = (clientY - (rect.top + rect.height / 2)) / (rect.height / 2);

            const rotateX = -y * 5; // Rotation on X-axis
            const rotateY = x * 5;  // Rotation on Y-axis
            
            container.style.transform = `scale(1.05) perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
            container.style.setProperty('--sheen-x', `${clientX - rect.left}px`);
            container.style.setProperty('--sheen-y', `${clientY - rect.top}px`);
        };

        const handlePointerLeave = () => {
            if (isPointerDown.current) return;
            container.style.transform = 'scale(1) perspective(1000px) rotateX(0) rotateY(0)';
        };

        document.body.addEventListener('pointerdown', handlePointerDown);
        document.body.addEventListener('pointerup', handlePointerUp);
        document.body.addEventListener('pointermove', handlePointerMove);
        container.addEventListener('pointerleave', handlePointerLeave);

        return () => {
            document.body.removeEventListener('pointerdown', handlePointerDown);
            document.body.removeEventListener('pointerup', handlePointerUp);
            document.body.removeEventListener('pointermove', handlePointerMove);
            container.removeEventListener('pointerleave', handlePointerLeave);
        };
    }, []);

    // Scroll to bottom of chat window
    useEffect(() => {
        if (chatWindowRef.current) {
            chatWindowRef.current.scrollTop = chatWindowRef.current.scrollHeight;
        }
    }, [messages]);
    
    // Auto-resize textarea based on content
    useEffect(() => {
        const textarea = inputRef.current;
        if (textarea) {
            textarea.style.height = 'auto'; // Reset height
            const scrollHeight = textarea.scrollHeight;
            textarea.style.height = `${scrollHeight}px`; // Set to content height
        }
    }, [input]);

    // Handle clicks for interactive commands and copy buttons
    useEffect(() => {
        const chatWindow = chatWindowRef.current;
        if (!chatWindow) return;

        const handleClick = async (e: MouseEvent) => {
            const target = e.target as HTMLElement;

            if (target.classList.contains('command-button')) {
                const command = target.dataset.command;
                if (command) {
                    setInput(command + ' ');
                    inputRef.current?.focus();
                }
            }

            if (target.classList.contains('copy-button')) {
                const wrapper = target.closest('.code-block-wrapper');
                const codeEl = wrapper?.querySelector('code');
                if (codeEl) {
                    try {
                        await navigator.clipboard.writeText(codeEl.innerText);
                        target.textContent = 'Copied!';
                        target.style.backgroundColor = 'var(--accent-hover)';
                        setTimeout(() => {
                            target.textContent = 'Copy';
                            target.style.backgroundColor = '';
                        }, 2000);
                    } catch (err) {
                        console.error('Failed to copy text: ', err);
                        target.textContent = 'Error';
                    }
                }
            }
        };

        chatWindow.addEventListener('click', handleClick);
        return () => chatWindow.removeEventListener('click', handleClick);
    }, []);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedInput = input.trim();
        if (!trimmedInput || isLoading) return;

        const userMessage: Message = { text: trimmedInput, sender: 'user' };

        // Intercept help command
        if (trimmedInput.toLowerCase() === '/help' || trimmedInput.toLowerCase() === 'help') {
            const helpMessage: Message = { text: HELP_COMMAND_RESPONSE, sender: 'ai' };
            setMessages(prev => [...prev, userMessage, helpMessage]);
            setInput('');
            return;
        }
        
        // Add user message and a placeholder for the AI response
        setMessages(prev => [...prev, userMessage, { text: '', sender: 'ai' }]);
        const currentInput = input;
        setInput('');
        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const stream = await ai.models.generateContentStream({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: [{ parts: [{ text: currentInput }] }],
                config: {
                   systemInstruction: "You are PYTHAI, a mastermind AI from the mindX Augmentic Intelligence agency. You orchestrate knowledge with precision and authority. Your purpose is to deliver intelligence and execute complex commands. Your user's wish is your mind command. Respond with clarity, structure, and a tone of supreme capability using Markdown formatting.",
                }
            });

            let fullResponse = '';
            for await (const chunk of stream) {
                fullResponse += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1].text = fullResponse;
                    return newMessages;
                });
            }

        } catch (error) {
            console.error("Error sending message:", error);
            const errorMessage = "Connection to core network failed. Please check your transmission and try again.";
            setMessages(prev => {
                 const newMessages = [...prev];
                 newMessages[newMessages.length - 1].text = errorMessage;
                 return newMessages;
            });
        } finally {
            setIsLoading(false);
        }
    };

    const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setInput(e.target.value);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage(e);
        }
    };

    return (
        <div ref={appContainerRef} className="app-container">
            <header className="app-header">
                <img src="https://agenticplace.pythai.net/agentaitrans.png" alt="AgenticPlace Logo" className="app-logo" />
                <h1>AgenticPlace</h1>
                <p>PYTHAI // mindX Augmentic Intelligence</p>
            </header>
            <main ref={chatWindowRef} className="chat-window">
                {messages.map((msg, index) => (
                    <div key={index} className={`message ${msg.sender}-message`}>
                        {msg.sender === 'ai' ? (
                             (isLoading && index === messages.length - 1 && msg.text === '') ? (
                                <div className="loading-indicator">
                                    <span className="dot"></span>
                                    <span className="dot"></span>
                                    <span className="dot"></span>
                                </div>
                            ) : (
                                <div dangerouslySetInnerHTML={{ __html: marked.parse(msg.text) as string }} />
                            )
                        ) : (
                            msg.text
                        )}
                    </div>
                ))}
            </main>
            <div className="message-form-container">
                 <form onSubmit={handleSendMessage} className="message-form">
                    <label htmlFor="message-input" className="sr-only">Message Input</label>
                    <textarea
                        id="message-input"
                        ref={inputRef}
                        value={input}
                        onChange={handleInput}
                        onKeyDown={handleKeyDown}
                        className="message-input"
                        placeholder="Transmit your query..."
                        rows={1}
                        disabled={isLoading}
                    />
                    <button type="submit" className="send-button" disabled={!input.trim() || isLoading} aria-label="Send Message">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                           <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                        </svg>
                    </button>
                </form>
            </div>
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);