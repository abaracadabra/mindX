
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import { epistemic, LogEntry } from './epistemic.ts';
import { Visualizer, DAOBoard, PersonaSelector } from './SubstrateComponents.tsx';
import { personasData } from './persona.ts';

interface Message {
    text: string;
    sender: 'user' | 'ai';
    persona?: string;
}

const SECTIONS = [
    { name: "CORE_COMMAND", id: 0, persona: 'pythai' },
    { name: "BOARD_CONSENSUS", id: 1, persona: 'mindx' },
    { name: "SUBSTRATE_TELEMETRY", id: 2, persona: 'rage' }
];

const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { text: "Neural link established. **PYTHAI // AGENTIC_MASTERMIND** ready for instruction.", sender: 'ai', persona: 'pythai' }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [activePersona, setActivePersona] = useState('pythai');
    const [showOverlay, setShowOverlay] = useState(false);
    const [overlayState, setOverlayState] = useState<'input' | 'thinking' | 'response'>('input');
    const [overlayResponse, setOverlayResponse] = useState<string>('');
    const [currentSection, setCurrentSection] = useState(0);
    const [logs, setLogs] = useState<LogEntry[]>([]);

    const [consolePos, setConsolePos] = useState({ x: 60, y: 140 });
    const [consoleSize, setConsoleSize] = useState({ w: 560, h: 320 });
    const dragging = useRef(false);
    const resizing = useRef(false);
    const dragOffset = useRef({ x: 0, y: 0 });

    const getSystemInstruction = (pid: string) => {
        const found = personasData.personas.find(p => p.id === pid) || personasData.personas[0];
        return found.instruction + " Use absolute authority. Format with Markdown.";
    };

    // Auto-switch persona based on tab focus for seamless contextual experience
    const changeSection = (id: number) => {
        setCurrentSection(id);
        const suggestedPersona = SECTIONS.find(s => s.id === id)?.persona;
        if (suggestedPersona) {
            setActivePersona(suggestedPersona);
            epistemic.logEvent("ContextShift", `Substrate section changed to ${SECTIONS[id].name}. Re-orienting to ${suggestedPersona.toUpperCase()} persona.`);
        }
    };

    const handleSendMessage = async (text: string, isOverlay: boolean = false) => {
        if (!text.trim() || isLoading) return;
        
        if (isOverlay) {
            setOverlayState('thinking');
            setOverlayResponse('');
        } else {
            setMessages(prev => [...prev, { text, sender: 'user' }]);
            setInputValue('');
        }

        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const instruction = getSystemInstruction(activePersona);
            
            const response = await ai.models.generateContent({
                model: 'gemini-3-pro-preview',
                contents: text,
                config: { 
                    systemInstruction: instruction,
                    thinkingConfig: { thinkingBudget: 16000 } 
                }
            });

            const aiText = response.text || "SUBSTRATE_TIMEOUT: NO_DATA_RETURNED";
            
            if (isOverlay) {
                setOverlayResponse(aiText);
                setOverlayState('response');
            } else {
                setMessages(prev => [...prev, { text: aiText, sender: 'ai', persona: activePersona }]);
            }
            
            epistemic.logEvent("DirectiveProcessed", `Mode [${activePersona.toUpperCase()}] handled instruction: ${text.slice(0, 30)}...`);
        } catch (e: any) {
            const err = "CRITICAL_FAILURE: " + e.message;
            if (isOverlay) {
                setOverlayResponse(err);
                setOverlayState('response');
            } else {
                setMessages(prev => [...prev, { text: err, sender: 'ai', persona: activePersona }]);
            }
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (dragging.current) {
                setConsolePos({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
            } else if (resizing.current) {
                setConsoleSize({ w: Math.max(400, e.clientX - consolePos.x), h: Math.max(200, e.clientY - consolePos.y) });
            }
        };
        const handleMouseUp = () => {
            dragging.current = false;
            resizing.current = false;
        };
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [consolePos]);

    useEffect(() => {
        const unsubscribeLogs = epistemic.subscribe(() => setLogs(epistemic.getLogs()));
        return () => unsubscribeLogs();
    }, []);

    return (
        <div className="app-container">
            <div className="master-backdrop-substrate"></div>

            {/* Draggable Command Console */}
            {currentSection === 0 && !showOverlay && (
                <div 
                    className="master-console-floating"
                    style={{ left: consolePos.x, top: consolePos.y, width: consoleSize.w, height: consoleSize.h }}
                >
                    <div className="console-handle" onMouseDown={(e) => {
                        dragging.current = true;
                        dragOffset.current = { x: e.clientX - consolePos.x, y: e.clientY - consolePos.y };
                    }}>
                        <div className="handle-left">
                           <div className="console-status-light"></div>
                           <span className="handle-text">PYTHAI // {activePersona.toUpperCase()}_COMMAND_v6.4</span>
                        </div>
                        <div className="handle-dots">•••</div>
                    </div>
                    <div className="console-body">
                        <PersonaSelector current={activePersona} onSelect={setActivePersona} />
                        <textarea 
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            placeholder={`INSTRUCT_${activePersona.toUpperCase()}_CORE...`}
                            onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(inputValue); } }}
                        />
                        <div className="console-toolkit">
                            <button className="tool-btn" onClick={() => { setOverlayState('input'); setShowOverlay(true); }}>ASCEND_COMMAND</button>
                            <button className="tool-btn transmit-btn" onClick={() => handleSendMessage(inputValue)}>TRANSMIT</button>
                        </div>
                    </div>
                    <div className="console-resize-handle" onMouseDown={() => resizing.current = true}></div>
                </div>
            )}

            {/* Supreme Directive Overlay */}
            {showOverlay && (
                <div className="supreme-overlay">
                    <button className="close-overlay" onClick={() => { setShowOverlay(false); setOverlayResponse(''); setOverlayState('input'); }}>×</button>
                    <div className={`overlay-portal-container overlay-state-${overlayState}`}>
                        
                        {overlayState === 'input' && (
                            <div className="directive-input-group animate-focus">
                                <div className="overlay-badge">AUTH_LEVEL: ROOT_MASTERMIND // MODE: {activePersona.toUpperCase()}</div>
                                <h2>SUPREME_DIRECTIVE</h2>
                                <textarea 
                                    autoFocus
                                    placeholder="TYPE UNIVERSAL COMMAND..."
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSendMessage(e.currentTarget.value, true);
                                        }
                                    }}
                                />
                                <div className="overlay-hint">PRESS [ENTER] TO BROADCAST INTO SUBSTRATE</div>
                            </div>
                        )}

                        {overlayState === 'thinking' && (
                            <div className="directive-thinking animate-probe">
                                <div className="thinking-center">
                                    <div className="scanning-effect">PROBING_NEURAL_SUBSTRATE...</div>
                                    <div className="geometry-pulse">
                                        <div className="pulse-ring"></div>
                                        <div className="pulse-ring delay-1"></div>
                                        <div className="pulse-ring delay-2"></div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {overlayState === 'response' && (
                            <div className="directive-response-found animate-emerge">
                                <div className="found-content">
                                    <div className="response-header">DIRECTIVE_FOUND // EXECUTION_READY</div>
                                    <div className="response-body markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(overlayResponse) as string }} />
                                    <div className="found-footer">
                                        <button className="reset-directive" onClick={() => setOverlayState('input')}>REINIT_DIRECTIVE</button>
                                    </div>
                                </div>
                            </div>
                        )}
                        
                    </div>
                </div>
            )}

            <div className="workspace" style={{ transform: `translateY(-${currentSection * 100}vh)` }}>
                {/* Fixed Control Bar */}
                <div className="substrate-control-bar">
                    <div className="bar-logo">
                        <img src="https://agenticplace.pythai.net/agentaitrans.png" className="bar-img" alt="logo" />
                        <div className="logo-text">
                           <span className="brand">PYTHAI</span>
                           <span className="subtitle">MASTERMIND // SUBSTRATE</span>
                        </div>
                    </div>
                    <div className="bar-tabs">
                        {SECTIONS.map(s => (
                            <button 
                              key={s.id} 
                              className={`tab-btn ${currentSection === s.id ? 'active' : ''}`} 
                              onClick={() => changeSection(s.id)}
                            >
                                {s.name}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Section 0: CORE */}
                <div className="section-container core-section">
                    <div className="main-grid-layout">
                        <div className="grid-left glass-module">
                            <div className="feed-header">NEURAL_FEED_STREAM</div>
                            <div className="chat-area">
                                {messages.map((m, i) => (
                                    <div key={i} className={`message ${m.sender}`}>
                                        <div className="m-tag">{m.sender === 'user' ? 'ROOT' : m.persona?.toUpperCase() || 'ALPHA'}</div>
                                        <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(m.text) as string }} />
                                    </div>
                                ))}
                                {isLoading && !showOverlay && (
                                    <div className="message ai thinking-dots">
                                        <div className="m-tag">{activePersona.toUpperCase()}</div>
                                        <div className="dots-pulse">TRANSMITTING_COGNITION...</div>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="grid-right glass-module">
                           <Visualizer />
                        </div>
                    </div>
                </div>

                {/* Section 1: CONSENSUS */}
                <div className="section-container board-section">
                    <div className="consensus-module-full glass-module">
                        <div className="module-title-bar">
                           <span className="m-title">EXECUTIVE_BOARD_CONSENSUS</span>
                           <span className="m-version">PROTOCOL_v8.5_ENFORCED</span>
                        </div>
                        <DAOBoard />
                    </div>
                </div>

                {/* Section 2: TELEMETRY */}
                <div className="section-container logs-section">
                    <div className="logs-module-full glass-module">
                        <div className="logs-header">SUBSTRATE_TELEMETRY_LOGS</div>
                        <div className="logs-scroll">
                            {logs.map((l, i) => (
                                <div key={i} className="log-line">
                                    <span className="l-time">[{l.timestamp.split('T')[1].slice(0,8)}]</span>
                                    <span className="l-type">{l.eventType.toUpperCase()}</span>
                                    <span className="l-msg">{l.message}</span>
                                </div>
                            ))}
                            {logs.length === 0 && <div className="no-logs">WAITING_FOR_SIGNAL...</div>}
                        </div>
                    </div>
                </div>
            </div>

            <div className="bottom-bar">
                <div className="nav-info">MASTERMIND: <span className="text-accent">ONLINE_ROOT_AUTHORIZED</span></div>
                <div className="nav-info text-dim">LAYER: {SECTIONS[currentSection].name}</div>
                <div className="nav-info text-dim">SUBSTRATE_CLOCK: {new Date().toLocaleTimeString()}</div>
            </div>
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
