
import React, { useState, useEffect, useRef } from 'react';
import { Rocket, Shield, ExternalLink, Zap, Lock, Info, Activity, ArrowRight, RefreshCcw, TrendingUp, Users, Star, Globe, ShoppingCart, Target, Compass, CheckCircle2, Wifi, Scan, Layers, Heart } from 'lucide-react';
import { THRUST_ADDRESS, PANCAKESWAP_URL } from '../constants';
import { fetchLivePrice } from '../services/oracleService';

interface LandingPageProps {
  onEnterCockpit: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onEnterCockpit }) => {
  const [priceData, setPriceData] = useState({
    priceUsd: 0.00005398,
    liquidityUsd: 0,
    volume24h: 0,
    priceChange: 0
  });
  const [isSyncing, setIsSyncing] = useState(true);
  const [countdown, setCountdown] = useState(10);
  const [flash, setFlash] = useState(false);

  const syncPrice = async () => {
    setIsSyncing(true);
    setFlash(true);
    const data = await fetchLivePrice();
    if (data) {
      setPriceData(data);
    }
    setCountdown(10);
    setTimeout(() => {
      setIsSyncing(false);
      setFlash(false);
    }, 1200);
  };

  useEffect(() => {
    syncPrice();
    const interval = setInterval(syncPrice, 10000); 
    const timer = setInterval(() => {
      setCountdown(prev => prev > 0 ? prev - 1 : 10);
    }, 1000);
    return () => {
      clearInterval(interval);
      clearInterval(timer);
    };
  }, []);

  const handleBuy = () => {
    window.open(PANCAKESWAP_URL, '_blank');
  };

  const priceParts = priceData.priceUsd.toFixed(18).split('.');
  const whole = priceParts[0];
  const fractional = priceParts[1];

  return (
    <div className="min-h-screen bg-[#050505] text-green-500 font-mono flex flex-col selection:bg-green-500 selection:text-black overflow-x-hidden">
      {/* Cinematic Background Layer */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/10 via-black to-black"></div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-[1920px] opacity-40 mix-blend-screen bg-no-repeat bg-center bg-cover" 
             style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1614732414444-096e5f1122d5?q=80&w=1000&auto=format&fit=crop")' }}>
        </div>
        <div className="absolute top-0 left-1/4 w-[2px] h-full bg-blue-500/20 blur-sm"></div>
        <div className="absolute top-0 right-1/4 w-[2px] h-full bg-blue-500/20 blur-sm"></div>
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#0f0 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
      </div>

      {/* HUD Navigation */}
      <nav className="relative z-50 p-8 flex justify-between items-center border-b border-white/5 bg-black/40 backdrop-blur-3xl">
        <div className="flex items-center gap-6">
          <div className="relative group cursor-pointer">
            <div className="absolute inset-0 bg-green-500 blur-xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
            <div className="relative w-12 h-12 bg-black border border-green-500/50 text-green-500 flex items-center justify-center font-black text-2xl rounded-lg shadow-[0_0_20px_rgba(34,197,94,0.3)]">
              Δ
            </div>
          </div>
          <div className="hidden sm:block text-left">
            <span className="font-black tracking-[-0.05em] text-3xl text-white block leading-none">THRUST PROTOCOL</span>
            <span className="text-[9px] text-green-800 tracking-[0.5em] font-black uppercase mt-1 block">Ancient Tech / Modern Liquidity</span>
          </div>
        </div>
        
        <div className="flex items-center gap-8">
           <div className="hidden lg:flex flex-col items-end">
             <div className="text-[8px] text-zinc-600 font-black uppercase tracking-widest">Aperture Status</div>
             <div className="text-[10px] text-blue-400 font-black font-mono flex items-center gap-2">
               <Wifi size={10} className={isSyncing ? 'animate-pulse' : ''} />
               LOCK_SYNC_{countdown.toString().padStart(2, '0')}.42
             </div>
           </div>
           <button 
             onClick={onEnterCockpit}
             className="group flex items-center gap-4 px-8 py-3 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-green-500/40 transition-all rounded-full backdrop-blur-md"
           >
             <Compass size={18} className="text-zinc-500 group-hover:text-green-500 transition-colors group-hover:rotate-90 duration-500" />
             <span className="text-[10px] font-black uppercase text-zinc-400 group-hover:text-white transition-colors tracking-[0.2em]">Enter Cockpit</span>
           </button>
        </div>
      </nav>

      {/* Main Journey Portal */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center p-6 text-center space-y-16 py-20">
        
        <div className="space-y-12 animate-in fade-in slide-in-from-top-12 duration-1000">
          
          <div className="inline-flex items-center gap-6 px-10 py-3 border border-white/5 bg-black/40 rounded-full backdrop-blur-2xl shadow-2xl">
            <div className="relative">
              <div className={`w-3 h-3 rounded-full ${isSyncing ? 'bg-yellow-500 animate-ping' : 'bg-blue-500'} relative shadow-[0_0_15px_currentColor]`}></div>
            </div>
            <span className="text-zinc-500 text-[10px] uppercase tracking-[0.8em] font-black flex items-center gap-2">
              {isSyncing ? 'REFRESHING_APERTURE...' : `SYMGATEWAY_CONNECTED [${countdown}s]`}
            </span>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col items-center gap-2">
              <h2 className="text-[12px] text-zinc-500 uppercase tracking-[1.2em] font-black opacity-60">Symcryptosis Emerging Point</h2>
              <div className="flex items-center gap-3">
                 <span className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full text-[9px] font-black text-green-400 uppercase tracking-widest">1000%_POTENTIAL_APY</span>
                 <span className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-[9px] font-black text-blue-400 uppercase tracking-widest">TNT_LAYER_3</span>
              </div>
            </div>
            
            <div className="relative flex flex-col items-center group">
               <div className="relative">
                 {/* Rotating Runic Ring */}
                 <div className="absolute inset-0 -m-12 border-4 border-dashed border-green-500/10 rounded-full animate-spin-slow"></div>
                 <div className="absolute inset-0 -m-8 border border-blue-500/20 rounded-full animate-reverse-spin"></div>
                 
                 {/* Price Card Container */}
                 <div className={`relative z-10 bg-black/60 border ${flash ? 'border-green-500 shadow-[0_0_100px_rgba(34,197,94,0.2)]' : 'border-white/10'} p-16 md:p-24 rounded-[4rem] shadow-[0_0_150px_rgba(59,130,246,0.15)] backdrop-blur-[60px] transition-all duration-1000 group-hover:border-green-500/40 overflow-hidden`}>
                   
                   {/* Scanning Effect */}
                   {isSyncing && (
                     <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden">
                       <div className="w-full h-1 bg-green-500/50 shadow-[0_0_20px_#22c55e] animate-scan-y"></div>
                     </div>
                   )}

                   <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-green-500/50 to-transparent"></div>
                   
                   <div className="text-[11px] uppercase tracking-[1em] text-zinc-600 mb-10 font-black flex items-center justify-center gap-3">
                     <Scan size={14} className={isSyncing ? 'animate-pulse' : ''} />
                     LIVE_VALUE_STREAM
                   </div>
                   
                   <div className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-[-0.08em] text-white font-mono leading-none flex items-center justify-center relative tabular-nums">
                     <span className="text-blue-500/40 mr-4 md:mr-8 drop-shadow-[0_0_10px_rgba(59,130,246,0.5)]">$</span>
                     {whole}.<span className="text-zinc-200">{fractional.slice(0, 8)}</span><span className="text-zinc-600">{fractional.slice(8, 14)}</span>
                   </div>
                   
                   <div className="mt-12 flex items-center justify-center gap-12 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                      <div className="flex items-center gap-3 group/stat">
                        <Activity size={14} className="text-green-500 group-hover/stat:animate-bounce" />
                        <span>Vol_24H: <span className="text-white transition-colors group-hover/stat:text-green-400">${priceData.volume24h.toLocaleString()}</span></span>
                      </div>
                      <div className="w-px h-4 bg-zinc-800"></div>
                      <div className="flex items-center gap-3 group/stat">
                        <Target size={14} className="text-blue-500 group-hover/stat:scale-125 transition-transform" />
                        <span>Liq_Parity: <span className="text-white">Confirmed</span></span>
                      </div>
                   </div>
                 </div>
               </div>

               {/* Primary Gateway Activation Key (Buy Button) */}
               <div className="mt-[-40px] z-20 animate-in fade-in zoom-in-95 duration-1000 delay-300 flex flex-col items-center">
                  <button 
                    onClick={handleBuy}
                    className="relative group bg-green-500 text-black px-16 py-8 rounded-[2rem] font-black text-3xl uppercase tracking-[0.2em] shadow-[0_30px_60px_-15px_rgba(34,197,94,0.6)] hover:shadow-[0_0_80px_rgba(34,197,94,0.8)] hover:scale-[1.08] active:scale-95 transition-all border-b-[10px] border-green-700 active:border-b-0 flex flex-col items-center gap-1"
                  >
                    <div className="flex items-center gap-6">
                      <ShoppingCart size={32} className="group-hover:animate-bounce" />
                      ACTIVATE_THRUST
                    </div>
                    <div className="text-[10px] font-black opacity-40 flex items-center gap-2 mt-1 tracking-widest group-hover:opacity-100 transition-opacity">
                      <CheckCircle2 size={12} /> ROUTER_PRE_CALIBRATED
                    </div>
                  </button>
                  <div className="mt-6 flex flex-col items-center gap-2">
                    <div className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.6em] italic opacity-40">
                      Protocol Bridge: PancakeSwap Mainnet
                    </div>
                    <div className="px-4 py-1.5 bg-zinc-950 border border-zinc-900 rounded-full text-[9px] text-green-900 font-black uppercase tracking-tighter shadow-inner">
                      One-Click Buy Engaged: {THRUST_ADDRESS.slice(0, 10)}...
                    </div>
                  </div>
               </div>
            </div>
          </div>
        </div>

        {/* Secondary Navigation Hub */}
        <div className="z-10 w-full max-w-7xl pt-20 animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-700">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
             <div className="relative p-1 bg-white/5 border border-white/10 rounded-[3rem] group hover:border-green-500/50 transition-all overflow-hidden shadow-2xl">
                <div className="p-12 space-y-6 bg-black/40 rounded-[2.8rem] backdrop-blur-xl h-full flex flex-col items-center text-center">
                  <div className="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-3xl flex items-center justify-center text-green-500 group-hover:scale-110 group-hover:rotate-12 transition-transform">
                    <Layers size={32} />
                  </div>
                  <h4 className="text-white text-xl font-black uppercase tracking-widest">TNT LAYER 3</h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed italic font-bold uppercase tracking-tighter">
                    Scaling beyond boundaries. High-velocity blockchain infrastructure.
                  </p>
                </div>
             </div>

             <div className="relative p-1 bg-white/5 border border-white/10 rounded-[3rem] group hover:border-blue-500/50 transition-all overflow-hidden shadow-2xl">
                <div className="p-12 space-y-6 bg-black/40 rounded-[2.8rem] backdrop-blur-xl h-full flex flex-col items-center text-center">
                  <div className="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-3xl flex items-center justify-center text-blue-500 group-hover:scale-110 group-hover:-rotate-12 transition-transform">
                    <Star size={32} />
                  </div>
                  <h4 className="text-white text-xl font-black uppercase tracking-widest">DELTAVERSE</h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed italic font-bold uppercase tracking-tighter">
                    Interactive participant virtual world for the elite THRUST fleet.
                  </p>
                </div>
             </div>

             <div className="relative p-1 bg-white/5 border border-white/10 rounded-[3rem] group hover:border-red-500/50 transition-all overflow-hidden shadow-2xl">
                <div className="p-12 space-y-6 bg-black/40 rounded-[2.8rem] backdrop-blur-xl h-full flex flex-col items-center text-center">
                  <div className="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-3xl flex items-center justify-center text-red-500 group-hover:scale-110 transition-transform">
                    <Heart size={32} />
                  </div>
                  <h4 className="text-white text-xl font-black uppercase tracking-widest">PASSIVE YIELD</h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed italic font-bold uppercase tracking-tighter">
                    Auto-stake mechanisms returning high-yield potential passive income.
                  </p>
                </div>
             </div>

             <div className="relative p-1 bg-white/5 border border-white/10 rounded-[3rem] group hover:border-yellow-500/50 transition-all overflow-hidden shadow-2xl">
                <div className="p-12 space-y-6 bg-black/40 rounded-[2.8rem] backdrop-blur-xl h-full flex flex-col items-center text-center">
                  <div className="w-20 h-20 bg-zinc-900 border border-zinc-800 rounded-3xl flex items-center justify-center text-yellow-500 group-hover:scale-110 transition-transform">
                    <Zap size={32} />
                  </div>
                  <h4 className="text-white text-xl font-black uppercase tracking-widest">PROTOCOL MEAN</h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed italic font-bold uppercase tracking-tighter">
                    The equilibrium between liquidity depth and market rebase.
                  </p>
                </div>
             </div>
          </div>
        </div>
      </main>

      <footer className="relative z-10 p-20 border-t border-white/5 text-center space-y-12 bg-black/60 backdrop-blur-3xl">
        <div className="text-[14px] text-zinc-600 tracking-[1.5em] uppercase font-black opacity-30">
          ENGINEERED BY <span className="text-white">DELTAV CORE</span>
        </div>
        <div className="text-[10px] text-zinc-800 font-mono flex flex-col md:flex-row items-center justify-center gap-16 uppercase tracking-[0.4em] font-black">
          <span className="flex items-center gap-3"><Rocket size={14} /> © 2024 DELTAV ECOSYSTEM</span>
          <span className="flex items-center gap-3"><Star size={14} /> CAPTAIN'S LOG ENCRYPTED</span>
          <span className="flex items-center gap-3"><Shield size={14} /> GATE_A1_STABLE</span>
        </div>
      </footer>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes reverse-spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(-360deg); }
        }
        @keyframes scan-y {
          0% { transform: translateY(-100%); opacity: 0; }
          50% { opacity: 1; }
          100% { transform: translateY(1000%); opacity: 0; }
        }
        .animate-reverse-spin {
          animation: reverse-spin 20s linear infinite;
        }
        .animate-spin-slow {
          animation: spin 30s linear infinite;
        }
        .animate-scan-y {
          animation: scan-y 1.2s linear infinite;
        }
      `}} />
    </div>
  );
};
