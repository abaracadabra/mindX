
import React, { useState, useEffect } from 'react';
// Fix: Added Globe to the list of lucide-react imports to resolve 'Cannot find name Globe' error.
import { Rocket, Shield, ExternalLink, Zap, Lock, Info, Activity, ArrowRight, RefreshCcw, TrendingUp, Users, Star, Globe } from 'lucide-react';
import { THRUST_ADDRESS, PANCAKESWAP_URL } from '../constants';
import { fetchLivePrice } from '../services/oracleService';

interface LandingPageProps {
  onEnterCockpit: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onEnterCockpit }) => {
  const [priceData, setPriceData] = useState({
    priceUsd: 0.00005398,
    liquidityUsd: 0,
    volume24h: 0,
    priceChange: 0
  });
  const [isHovered, setIsHovered] = useState(false);
  const [isSyncing, setIsSyncing] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  const syncPrice = async () => {
    setIsSyncing(true);
    const data = await fetchLivePrice();
    if (data) {
      setPriceData(data);
    }
    setLastUpdate(Date.now());
    setTimeout(() => setIsSyncing(false), 1200);
  };

  useEffect(() => {
    syncPrice();
    const interval = setInterval(syncPrice, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleBuy = () => {
    window.open(PANCAKESWAP_URL, '_blank');
  };

  const thrustPerDollar = priceData.priceUsd > 0 ? 1 / priceData.priceUsd : 0;
  const priceParts = priceData.priceUsd.toFixed(18).split('.');
  const whole = priceParts[0];
  const fractional = priceParts[1];

  return (
    <div className="min-h-screen bg-black text-green-500 font-mono flex flex-col selection:bg-green-500 selection:text-black overflow-x-hidden">
      {/* HUD Navigation */}
      <nav className="p-6 flex justify-between items-center border-b border-green-900/20 bg-black/95 backdrop-blur-2xl sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-green-500 text-black flex items-center justify-center font-black text-xl rounded shadow-[0_0_30px_rgba(34,197,94,0.5)]">
            Δ
          </div>
          <div className="hidden sm:block">
            <span className="font-black tracking-tighter text-2xl text-white block leading-none">DeltaV THRUST</span>
            <span className="text-[8px] text-green-800 tracking-[0.4em] font-black uppercase">Symcryptosis Journey v7.0</span>
          </div>
        </div>
        
        <button 
          onClick={onEnterCockpit}
          className="group flex items-center gap-3 px-6 py-2.5 bg-zinc-950 border border-zinc-800 hover:border-green-500/50 transition-all rounded-md"
        >
          <Star size={16} className="text-zinc-600 group-hover:text-green-500 transition-colors" />
          <div className="text-left hidden md:block">
            <div className="text-[10px] font-black uppercase text-zinc-500 group-hover:text-white transition-colors tracking-widest leading-none">Bridge Deck</div>
            <div className="text-[8px] text-zinc-700 tracking-tighter uppercase font-mono">Captain Authorization Required</div>
          </div>
        </button>
      </nav>

      {/* Main Journey Portal */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-12 relative py-32">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1600px] h-[1600px] bg-green-500/[0.03] rounded-full blur-[250px]"></div>
          <div className="absolute top-0 w-full h-full opacity-[0.05]" style={{ backgroundImage: 'linear-gradient(#0f0 1px, transparent 1px), linear-gradient(90deg, #0f0 1px, transparent 1px)', backgroundSize: '120px 120px' }}></div>
        </div>

        <div className="z-10 space-y-10 animate-in fade-in slide-in-from-top-16 duration-1000">
          <div className="inline-flex items-center gap-5 px-6 py-2.5 border border-green-900/40 bg-green-950/50 rounded-full backdrop-blur-md">
            <div className="relative">
              <div className={`w-2.5 h-2.5 rounded-full ${isSyncing ? 'bg-yellow-500 animate-ping' : 'bg-green-500'} relative shadow-[0_0_20px_currentColor]`}></div>
            </div>
            <span className="text-zinc-400 text-[10px] uppercase tracking-[0.6em] font-black">
              {isSyncing ? 'STABILIZING_EQUILIBRIUM...' : 'SYMCRYPTOSIS_NOMINAL'}
            </span>
          </div>

          <div className="space-y-8">
            <h2 className="text-[14px] text-zinc-600 uppercase tracking-[1em] font-black">Journey Trajectory Index</h2>
            
            <div className="relative group flex flex-col items-center gap-8">
               <div className="bg-zinc-950/90 border border-zinc-800/80 p-10 md:p-14 rounded-[3rem] shadow-[0_0_120px_rgba(34,197,94,0.15)] backdrop-blur-xl transition-all hover:scale-[1.01] hover:border-green-500/40">
                 <div className="text-[11px] uppercase tracking-[0.8em] text-zinc-500 mb-6 font-black opacity-50">Emerging Price Point (USD)</div>
                 <div className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black tracking-tighter text-white font-mono leading-none flex items-center justify-center">
                   <span className="text-green-500 opacity-60 mr-4 md:mr-8">$</span>
                   {whole}.<span className="text-zinc-200">{fractional.slice(0, 8)}</span><span className="text-zinc-600">{fractional.slice(8, 14)}</span><span className="text-zinc-800">{fractional.slice(14)}</span>
                 </div>
               </div>

               <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-700 flex flex-col items-center group/deal">
                  <div className="h-10 w-px bg-gradient-to-b from-zinc-800 to-green-900/40 mb-2"></div>
                  <div className="bg-green-950/20 border border-zinc-900 px-10 py-6 rounded-2xl backdrop-blur-lg shadow-inner group-hover/deal:border-green-500/30 transition-all cursor-crosshair">
                    <span className="text-[11px] uppercase tracking-[0.6em] text-zinc-500 mr-6 font-black">Passenger Mass (per 1 USD):</span>
                    <span className="text-2xl md:text-4xl font-black font-mono text-green-400">
                      {thrustPerDollar.toLocaleString(undefined, { maximumFractionDigits: 6 })} <span className="text-green-800 text-base tracking-normal uppercase">Thrust</span>
                    </span>
                  </div>
               </div>
            </div>
          </div>
        </div>

        <div className="z-10 w-full max-w-2xl animate-in fade-in zoom-in-95 duration-1000 delay-500">
          <button 
            onClick={handleBuy}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            className="group relative w-full py-16 bg-green-500 text-black font-black text-4xl sm:text-5xl tracking-[0.1em] rounded-[2rem] overflow-hidden transition-all hover:scale-[1.04] active:scale-95 shadow-[0_0_150px_rgba(34,197,94,0.4)] border-b-[14px] border-green-700 active:border-b-0 hover:shadow-[0_0_180px_rgba(34,197,94,0.7)]"
          >
            <div className={`absolute inset-0 bg-white/40 transition-transform duration-700 ${isHovered ? 'translate-x-0' : '-translate-x-full'}`}></div>
            <div className="relative flex flex-col items-center gap-5">
              <div className="flex items-center gap-6">
                <Rocket className={`${isHovered ? 'animate-bounce' : ''}`} size={64} />
                START YOUR JOURNEY
              </div>
              <div className="flex items-center gap-4 text-[16px] tracking-[0.8em] opacity-80 font-black">
                ONBOARD VIA PANCAKESWAP <ArrowRight size={20} />
              </div>
            </div>
          </button>
        </div>

        <div className="z-10 w-full max-w-7xl py-16 animate-in fade-in slide-in-from-bottom-24 duration-1000 delay-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
             <div className="flex flex-col items-center space-y-8 p-14 bg-zinc-950/90 border border-zinc-900 rounded-[3rem] group hover:border-green-500/50 transition-all hover:shadow-[0_0_60px_rgba(34,197,94,0.1)]">
                <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center text-green-500 border border-zinc-800 transition-transform group-hover:rotate-12 group-hover:scale-110">
                  <Globe size={44} />
                </div>
                <h4 className="text-white text-2xl font-black uppercase tracking-widest">Cross-Chain Bridges</h4>
                <p className="text-zinc-600 text-xs leading-relaxed italic max-w-xs font-mono font-bold">
                  Building stable routes across the cryptosphere. From BSC to ARC and beyond.
                </p>
             </div>

             <div className="flex flex-col items-center space-y-8 p-14 bg-zinc-950/90 border border-zinc-900 rounded-[3rem] group hover:border-blue-500/50 transition-all hover:shadow-[0_0_60px_rgba(59,130,246,0.1)]">
                <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center text-blue-500 border border-zinc-800 transition-transform group-hover:-rotate-12 group-hover:scale-110">
                  <Users size={44} />
                </div>
                <h4 className="text-white text-2xl font-black uppercase tracking-widest">Passenger Perks</h4>
                <p className="text-zinc-600 text-xs leading-relaxed italic max-w-xs font-mono font-bold">
                  Holders aren't just investors; they're passengers on a journey of rebase scaling.
                </p>
             </div>

             <div className="flex flex-col items-center space-y-8 p-14 bg-zinc-950/90 border border-zinc-900 rounded-[3rem] group hover:border-yellow-500/50 transition-all hover:shadow-[0_0_60px_rgba(234,179,8,0.1)]">
                <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center text-yellow-500 border border-zinc-800 transition-transform group-hover:scale-110">
                  <Shield size={44} />
                </div>
                <h4 className="text-white text-2xl font-black uppercase tracking-widest">Symcryptosis Index</h4>
                <p className="text-zinc-600 text-xs leading-relaxed italic max-w-xs font-mono font-bold">
                  An emerging price point derived from the equilibrium between liquidity and mean average.
                </p>
             </div>
          </div>
        </div>
      </main>

      <footer className="p-24 border-t border-zinc-900 text-center space-y-16 bg-zinc-950/40">
        <div className="text-[22px] text-zinc-600 tracking-[1.2em] uppercase font-black">
          POWERED BY <span className="text-white">DeltaV THRUST ENGINE</span>
        </div>
        <div className="text-[12px] text-zinc-800 font-mono flex flex-col md:flex-row items-center justify-center gap-20 uppercase tracking-[0.5em] font-black">
          <span className="flex items-center gap-4"><Rocket size={18} /> © 2024 DELTAV ECOSYSTEM</span>
          <span className="flex items-center gap-4 italic"><Star size={18} /> CAPTAIN'S LOG ENCRYPTED</span>
          <span className="flex items-center gap-4"><Shield size={18} /> VERSION: SYMCRYPTOSIS_7.0</span>
        </div>
      </footer>
    </div>
  );
};
