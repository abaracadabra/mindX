
import React, { useState, useEffect } from 'react';
import { Crown, Zap, ShieldAlert, Target, Play, Pause, ExternalLink, BellRing } from 'lucide-react';
import { PANCAKESWAP_URL } from '../../constants';
import { fetchLivePrice } from '../../services/oracleService';

export const VipControlsTab: React.FC = () => {
  const [threshold, setThreshold] = useState<number>(0.00005000);
  const [isActive, setIsActive] = useState(false);
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [triggered, setTriggered] = useState(false);

  const addLog = (msg: string) => {
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 19)]);
  };

  useEffect(() => {
    let interval: any;
    if (isActive && !triggered) {
      addLog(`Auto-Buy Protocol Engaged. Target: $${threshold.toFixed(8)}`);
      interval = setInterval(async () => {
        const data = await fetchLivePrice();
        if (data) {
          setCurrentPrice(data.priceUsd);
          if (data.priceUsd <= threshold) {
            handleTrigger(data.priceUsd);
          }
        }
      }, 5000);
    } else if (!isActive) {
      addLog("Protocol Standby.");
    }
    return () => clearInterval(interval);
  }, [isActive, threshold, triggered]);

  const handleTrigger = (price: number) => {
    setTriggered(true);
    setIsActive(false);
    addLog(`!!! TARGET REACHED: $${price.toFixed(8)} !!!`);
    addLog("Executing automated buy sequence via PancakeSwap V2...");
    
    // In a real dApp, this would call a smart contract function or an EWS.
    // Here we simulate the 'Auto-Buy' by opening the DEX with the correct pair.
    setTimeout(() => {
      window.open(PANCAKESWAP_URL, '_blank');
    }, 1500);
  };

  const resetProtocol = () => {
    setTriggered(false);
    setIsActive(false);
    addLog("System Reset. Awaiting new parameters.");
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 border-b border-zinc-900 pb-8">
        <div>
          <div className="flex items-center gap-3 text-yellow-500 mb-2">
            <Crown size={24} className="animate-pulse" />
            <h2 className="text-2xl font-black tracking-tighter uppercase italic">VIP_AUTO_BUY_PROTOCOL</h2>
          </div>
          <p className="text-[10px] text-zinc-500 font-bold tracking-widest uppercase">Level 5 Autonomous Trading Module</p>
        </div>
        
        <div className="bg-zinc-950 border border-zinc-800 px-6 py-4 rounded-2xl flex items-center gap-6">
          <div className="text-right">
            <div className="text-[9px] text-zinc-600 font-black uppercase">Service_Status</div>
            <div className={`text-xs font-black uppercase ${isActive ? 'text-green-500' : 'text-zinc-500'}`}>
              {isActive ? 'MONITORING_ACTIVE' : 'STANDBY_IDLE'}
            </div>
          </div>
          <button 
            onClick={() => setIsActive(!isActive)}
            disabled={triggered}
            className={`w-14 h-8 rounded-full relative transition-all p-1 ${isActive ? 'bg-green-600 shadow-[0_0_15px_rgba(22,163,74,0.5)]' : 'bg-zinc-800'}`}
          >
            <div className={`w-6 h-6 bg-white rounded-full transition-all shadow-md ${isActive ? 'translate-x-6' : 'translate-x-0'}`}></div>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-[2rem] space-y-8 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <Zap size={80} className="text-yellow-500" />
            </div>
            
            <div className="space-y-2">
              <label className="text-[11px] font-black uppercase text-zinc-500 tracking-[0.2em] flex items-center gap-2">
                <Target size={14} className="text-yellow-500" /> BUY_THRESHOLD_USD
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-600 font-black">$</span>
                <input 
                  type="number" 
                  step="0.00000001"
                  value={threshold}
                  onChange={(e) => setThreshold(parseFloat(e.target.value))}
                  className="w-full bg-black border border-zinc-800 rounded-xl p-4 pl-10 text-xl font-black text-white focus:border-yellow-500/50 outline-none transition-all font-mono"
                  placeholder="0.00005398"
                />
              </div>
              <p className="text-[9px] text-zinc-700 italic">Trigger threshold for autonomous execution.</p>
            </div>

            <div className="p-4 bg-black/50 border border-zinc-800 rounded-xl">
              <div className="flex justify-between items-center text-[10px] mb-2 uppercase font-black text-zinc-500">
                <span>Current Price</span>
                <span className="text-green-500">${currentPrice.toFixed(8)}</span>
              </div>
              <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-yellow-500 transition-all duration-1000" 
                  style={{ width: `${Math.min(100, (currentPrice / threshold) * 50)}%` }}
                ></div>
              </div>
            </div>

            <button 
              onClick={resetProtocol}
              className="w-full py-4 border border-zinc-800 hover:border-zinc-700 rounded-xl text-[10px] font-black uppercase tracking-widest text-zinc-500 hover:text-white transition-all"
            >
              Emergency Reset
            </button>
          </div>

          <div className="bg-red-950/10 border border-red-900/20 p-6 rounded-2xl flex gap-4">
            <ShieldAlert className="text-red-500 shrink-0" size={20} />
            <div className="space-y-2">
              <h4 className="text-[10px] font-black text-red-500 uppercase">Risk Disclosure</h4>
              <p className="text-[9px] text-zinc-600 leading-relaxed italic">
                Autonomous trading involves significant financial risk. Protocol execution is irreversible. Ensure you have authorized the PancakeSwap router for automated swaps.
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 flex flex-col gap-6">
          <div className="bg-black border border-zinc-800 rounded-[2rem] p-8 flex-1 flex flex-col min-h-[400px]">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-500 flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse"></div>
                Protocol_Execution_Console
              </h3>
              {triggered && (
                <div className="flex items-center gap-2 text-red-500 animate-bounce">
                  <BellRing size={16} />
                  <span className="text-[10px] font-black uppercase">Auto_Buy_Triggered</span>
                </div>
              )}
            </div>

            <div className="flex-1 font-mono text-[11px] space-y-2 overflow-y-auto custom-scrollbar pr-4 text-zinc-400">
              {logs.length === 0 && <div className="opacity-20 italic">Awaiting protocol initiation...</div>}
              {logs.map((log, i) => (
                <div key={i} className={`p-2 border-l-2 ${log.includes('TARGET') ? 'bg-red-500/10 border-red-500 text-red-400 font-bold' : 'border-zinc-800'}`}>
                  {log}
                </div>
              ))}
            </div>

            {triggered && (
              <div className="mt-6 animate-in slide-in-from-bottom-4">
                <button 
                  onClick={() => window.open(PANCAKESWAP_URL, '_blank')}
                  className="w-full py-6 bg-yellow-500 text-black font-black text-xl rounded-2xl flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_30px_rgba(234,179,8,0.3)]"
                >
                  <ExternalLink size={24} />
                  CONFIRM DEX TRANSACTION
                </button>
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-900 flex items-center gap-4 group hover:border-yellow-500/20 transition-all">
                <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center text-yellow-500 group-hover:scale-110 transition-transform">
                  <Zap size={24} />
                </div>
                <div>
                   <div className="text-[10px] font-black uppercase text-zinc-500">Auto_Slippage</div>
                   <div className="text-xs font-black text-white uppercase">Optimized 0.5%</div>
                </div>
             </div>
             <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-900 flex items-center gap-4 group hover:border-yellow-500/20 transition-all">
                <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center text-yellow-500 group-hover:scale-110 transition-transform">
                  <Play size={24} />
                </div>
                <div>
                   <div className="text-[10px] font-black uppercase text-zinc-500">Node_Routing</div>
                   <div className="text-xs font-black text-white uppercase">Direct BSC-RPC</div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};
