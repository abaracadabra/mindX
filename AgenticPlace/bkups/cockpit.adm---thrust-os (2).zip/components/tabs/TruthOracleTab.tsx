
import React, { useState, useEffect } from 'react';
import { generateSnapshot, ThrustSnapshot } from '../../services/oracleService';
import { LiveGraph } from '../visuals/LiveGraph';
import { Activity, ShieldCheck, Globe, Database, Zap, ArrowUpRight } from 'lucide-react';

export const TruthOracleTab: React.FC = () => {
  const [snapshots, setSnapshots] = useState<ThrustSnapshot[]>([]);
  const [current, setCurrent] = useState<ThrustSnapshot | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const fresh = generateSnapshot();
      setCurrent(fresh);
      setSnapshots(prev => [...prev.slice(-29), fresh]);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  if (!current) return <div className="p-8 text-center animate-pulse text-green-500 font-mono uppercase tracking-widest">Establishing DeltaV Uplink...</div>;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-zinc-900/80 border border-green-900/40 p-4 rounded-lg flex flex-col items-center justify-center text-center group hover:border-green-500 transition-all">
          <Activity size={18} className="mb-2 text-green-400" />
          <span className="text-[9px] uppercase opacity-50 tracking-tighter">THRUST/USD</span>
          <span className="text-xl font-bold font-mono text-white tracking-tighter">${current.priceUSD.toFixed(8)}</span>
          <span className={`text-[9px] font-mono mt-1 ${current.deltaSinceLast >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            {current.deltaSinceLast >= 0 ? '+' : ''}{(current.deltaSinceLast * 100).toFixed(3)}%
          </span>
        </div>
        <div className="bg-zinc-900/80 border border-green-900/40 p-4 rounded-lg flex flex-col items-center justify-center text-center group hover:border-blue-500 transition-all">
          <Database size={18} className="mb-2 text-blue-400" />
          <span className="text-[9px] uppercase opacity-50 tracking-tighter">Liquidity Backing</span>
          <span className="text-xl font-bold font-mono text-white tracking-tighter">{current.liquidityBacking.toFixed(2)}%</span>
          <span className="text-[9px] text-zinc-500 uppercase font-mono mt-1">Target: 25.00%</span>
        </div>
        <div className="bg-zinc-900/80 border border-green-900/40 p-4 rounded-lg flex flex-col items-center justify-center text-center group hover:border-purple-500 transition-all">
          <Zap size={18} className="mb-2 text-purple-400" />
          <span className="text-[9px] uppercase opacity-50 tracking-tighter">Circulating Supply</span>
          <span className="text-xl font-bold font-mono text-white tracking-tighter">{(current.circulatingSupply / 1000000).toFixed(2)}M</span>
          <span className="text-[9px] text-zinc-500 uppercase font-mono mt-1">DeltaV Adjusted</span>
        </div>
        <div className="bg-zinc-900/80 border border-green-900/40 p-4 rounded-lg flex flex-col items-center justify-center text-center group hover:border-yellow-500 transition-all">
          <ShieldCheck size={18} className="mb-2 text-yellow-400" />
          <span className="text-[9px] uppercase opacity-50 tracking-tighter">Node Status</span>
          <span className="text-xl font-bold text-green-400 tracking-tighter uppercase">Synchronized</span>
          <span className="text-[9px] text-zinc-500 font-mono mt-1">Block: {current.block}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
           <LiveGraph data={snapshots} />
        </div>
        <div className="bg-zinc-900/50 border border-green-900/20 rounded-lg p-5 flex flex-col gap-4">
           <h4 className="text-[10px] font-bold uppercase text-green-500 flex items-center gap-2">
             <ArrowUpRight size={14} /> Rebase Statistics
           </h4>
           <div className="space-y-4">
              <div className="flex justify-between items-end border-b border-zinc-800 pb-2">
                <span className="text-[10px] uppercase text-zinc-500">Yield Denominator</span>
                <span className="text-xs font-mono">10,000,000</span>
              </div>
              <div className="flex justify-between items-end border-b border-zinc-800 pb-2">
                <span className="text-[10px] uppercase text-zinc-500">Reward Rate</span>
                <span className="text-xs font-mono text-green-400">{(current.rewardYield * 100).toFixed(4)}%</span>
              </div>
              <div className="flex justify-between items-end border-b border-zinc-800 pb-2">
                <span className="text-[10px] uppercase text-zinc-500">Rebase Frequency</span>
                <span className="text-xs font-mono">900s (15 min)</span>
              </div>
              <div className="flex justify-between items-end border-b border-zinc-800 pb-2">
                <span className="text-[10px] uppercase text-zinc-500">Auto-Rebase</span>
                <span className="text-xs font-mono text-green-500">ENABLED</span>
              </div>
              <div className="flex justify-between items-end border-b border-zinc-800 pb-2">
                <span className="text-[10px] uppercase text-zinc-500">Total Buy Fee</span>
                <span className="text-xs font-mono">14.0%</span>
              </div>
              <div className="flex justify-between items-end border-b border-zinc-800 pb-2">
                <span className="text-[10px] uppercase text-zinc-500">Total Sell Fee</span>
                <span className="text-xs font-mono">16.0%</span>
              </div>
           </div>
           <button className="mt-auto w-full py-2 bg-green-500/10 border border-green-500/30 text-green-500 text-[10px] font-bold uppercase hover:bg-green-500/20 transition-all rounded">
             Initiate Manual Sync
           </button>
        </div>
      </div>

      <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4">
        <h4 className="text-[10px] font-bold uppercase mb-4 opacity-50 flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
          Truth Feed Real-Time Log
        </h4>
        <div className="space-y-1 font-mono text-[10px] overflow-y-auto max-h-[120px] custom-scrollbar">
          {snapshots.slice().reverse().map((s, i) => (
            <div key={i} className="flex justify-between border-b border-zinc-900 py-1 opacity-70 hover:opacity-100 transition-opacity">
              <span className="flex gap-4">
                <span className="text-zinc-600">[{s.block}]</span>
                <span className="text-green-700">INF:</span>
                <span>DeltaV THRUST Liquidity Index update complete. Delta: {s.deltaSinceLast.toFixed(5)}</span>
              </span>
              <span className="text-zinc-700">{new Date(s.timestamp).toLocaleTimeString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
