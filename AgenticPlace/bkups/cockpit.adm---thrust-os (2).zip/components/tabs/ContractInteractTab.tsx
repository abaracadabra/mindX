
import React, { useState } from 'react';
import { MOCK_ABI, THRUST_ADDRESS } from '../../constants';
import { Play, Eye, Terminal, Settings, ArrowRight } from 'lucide-react';

export const ContractInteractTab: React.FC = () => {
  const [responses, setResponses] = useState<{[key: string]: string}>({});
  const [inputs, setInputs] = useState<{[key: string]: {[key: number]: string}}>({});
  const [logs, setLogs] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState<'all' | 'read' | 'write'>('all');

  const handleInputChange = (fnName: string, idx: number, val: string) => {
    setInputs(prev => ({
      ...prev,
      [fnName]: {
        ...(prev[fnName] || {}),
        [idx]: val
      }
    }));
  };

  const handleExecute = (fnName: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] CMD > EXECUTE: ${fnName}`, ...prev]);
    
    setTimeout(() => {
      const fnDef = MOCK_ABI.find(f => f.name === fnName);
      const isView = fnDef?.stateMutability === 'view' || fnDef?.stateMutability === 'pure';
      
      if (isView) {
        let mockResult = "null";
        if (fnName === 'name') mockResult = "DeltaV THRUST";
        else if (fnName === 'symbol') mockResult = "THRUST";
        else if (fnName === 'decimals') mockResult = "5";
        else if (fnName === 'totalSupply') mockResult = "100000000000000";
        else if (fnName === 'getCirculatingSupply') mockResult = "540230124";
        else if (fnName === 'rewardYield') mockResult = "235";
        else if (fnName === 'getLiquidityBacking') mockResult = "1542";
        else if (fnName === 'autoRebase') mockResult = "true";
        else if (fnName === 'totalBuyFee') mockResult = "140";
        else if (fnName === 'totalSellFee') mockResult = "160";
        else mockResult = "0x969F60Bfe17962E0f061B434596545C7b6Cd6Fc4";

        setResponses(prev => ({ ...prev, [fnName]: mockResult }));
        setLogs(prev => [`[${timestamp}] RES < ${mockResult}`, ...prev]);
      } else {
        const txHash = '0x' + Math.random().toString(16).slice(2, 42);
        setResponses(prev => ({ ...prev, [fnName]: `TX SUCCESS` }));
        setLogs(prev => [`[${timestamp}] NET < BROADCAST_COMPLETE: ${txHash.slice(0, 16)}...`, ...prev]);
      }
    }, 600);
  };

  const filteredAbi = MOCK_ABI.filter(fn => {
    if (activeCategory === 'all') return true;
    const isRead = fn.stateMutability === 'view' || fn.stateMutability === 'pure';
    return activeCategory === 'read' ? isRead : !isRead;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full animate-in fade-in slide-in-from-left-4 duration-500">
      <div className="lg:col-span-1 space-y-4">
        <div className="bg-zinc-900/80 border border-green-900/30 p-4 rounded-lg">
          <h3 className="text-[10px] font-bold uppercase mb-4 text-zinc-500">Filter Methods</h3>
          <div className="flex flex-col gap-2">
            {(['all', 'read', 'write'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`text-[10px] font-bold uppercase py-2 px-4 rounded text-left border transition-all ${
                  activeCategory === cat ? 'bg-green-500/10 border-green-500 text-green-500' : 'bg-transparent border-zinc-800 text-zinc-500 hover:border-zinc-700'
                }`}
              >
                {cat} MODULES
              </button>
            ))}
          </div>
        </div>

        <div className="bg-zinc-900/80 border border-green-900/30 p-4 rounded-lg">
          <h3 className="text-[10px] font-bold uppercase mb-4 text-zinc-500">Module Metadata</h3>
          <div className="text-[10px] font-mono space-y-2 opacity-70 leading-relaxed">
            <div><span className="text-zinc-500">NAME:</span> DeltaV THRUST</div>
            <div><span className="text-zinc-500">ADDR:</span> <span className="text-green-800">{THRUST_ADDRESS}</span></div>
            <div><span className="text-zinc-500">NET:</span> BSC-MAINNET</div>
            <div><span className="text-zinc-500">VER:</span> 0.8.20+COMMIT</div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-2 overflow-y-auto pr-2 space-y-3 custom-scrollbar max-h-[75vh]">
        {filteredAbi.map((fn, i) => {
          const isView = fn.stateMutability === 'view' || fn.stateMutability === 'pure';
          return (
            <div key={i} className="bg-zinc-900/30 border border-zinc-800/60 p-4 rounded-lg hover:border-green-900/50 transition-all group relative overflow-hidden">
              <div className="absolute top-0 right-0 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
                <Settings size={40} className="animate-spin-slow" />
              </div>
              
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-1.5 h-1.5 rounded-full ${isView ? 'bg-blue-500' : 'bg-orange-500'} shadow-[0_0_5px_currentColor]`}></div>
                  <h3 className="text-xs font-bold font-mono tracking-tight group-hover:text-green-400 transition-colors uppercase">{fn.name}</h3>
                </div>
                <button 
                  onClick={() => handleExecute(fn.name)}
                  className={`flex items-center gap-2 px-3 py-1 rounded-md text-[10px] font-bold uppercase transition-all ${
                    isView 
                    ? 'bg-blue-900/20 text-blue-400 hover:bg-blue-500 hover:text-white border border-blue-500/30' 
                    : 'bg-orange-900/20 text-orange-400 hover:bg-orange-500 hover:text-black border border-orange-500/30'
                  }`}
                >
                  {isView ? <Eye size={12} /> : <Play size={12} />}
                  {isView ? 'QUERY' : 'EXECUTE'}
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-2">
                {fn.inputs.map((input, idx) => (
                  <div key={idx} className="flex flex-col gap-1">
                    <label className="text-[9px] text-zinc-600 font-mono uppercase italic">{input.name || `param_${idx}`} <span className="opacity-50">({input.type})</span></label>
                    <input 
                      type="text"
                      placeholder="0x... | uint256 | bool"
                      className="bg-black/50 border border-zinc-800 text-green-500 font-mono text-[10px] p-2 rounded focus:outline-none focus:border-green-900 transition-all placeholder:opacity-20"
                      onChange={(e) => handleInputChange(fn.name, idx, e.target.value)}
                    />
                  </div>
                ))}
              </div>

              {responses[fn.name] && (
                <div className="mt-2 p-2 bg-green-500/5 rounded border border-green-500/10 text-[10px] font-mono text-green-400 flex items-center justify-between animate-in slide-in-from-top-2">
                  <div className="flex items-center gap-2">
                    <ArrowRight size={10} className="opacity-40" />
                    <span className="opacity-40 uppercase italic">Result:</span>
                    <span>{responses[fn.name]}</span>
                  </div>
                  <button 
                    onClick={() => navigator.clipboard.writeText(responses[fn.name])}
                    className="text-[8px] opacity-30 hover:opacity-100 uppercase"
                  >
                    Copy
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="lg:col-span-1 flex flex-col gap-4">
        <div className="bg-black border border-zinc-800 rounded-lg p-4 flex-1 flex flex-col overflow-hidden">
          <h4 className="text-[10px] font-bold uppercase mb-4 text-zinc-600 flex items-center gap-2 tracking-widest">
            <Terminal size={14} /> Execution Console
          </h4>
          <div className="flex-1 overflow-y-auto font-mono text-[9px] text-green-800 custom-scrollbar leading-tight">
            {logs.length === 0 && <span className="opacity-20 italic">Awaiting secure handshake...</span>}
            {logs.map((log, i) => (
              <div key={i} className={`mb-1 pb-1 border-b border-zinc-900/50 ${log.includes('CMD') ? 'text-zinc-500' : 'text-green-600'}`}>
                {log}
              </div>
            ))}
          </div>
        </div>
        <div className="bg-red-900/10 border border-red-900/20 p-4 rounded-lg">
           <h4 className="text-[10px] font-bold uppercase mb-2 text-red-500">Security Warning</h4>
           <p className="text-[9px] text-zinc-500 leading-relaxed italic">Write functions require gas. DeltaV THRUST mechanics may trigger rebase events upon successful state modification.</p>
        </div>
      </div>
    </div>
  );
};
