
import React, { useState, useEffect } from 'react';
import { Rocket, Shield, ExternalLink, Zap, Lock, Info, Activity, ArrowRight, RefreshCcw, TrendingUp } from 'lucide-react';
import { THRUST_ADDRESS, PANCAKESWAP_URL } from '../constants';
import { fetchLivePrice } from '../services/oracleService';

interface LandingPageProps {
  onEnterCockpit: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onEnterCockpit }) => {
  const [priceData, setPriceData] = useState({
    priceUsd: 0.00005398,
    liquidityUsd: 0,
    volume24h: 0,
    priceChange: 0
  });
  const [isHovered, setIsHovered] = useState(false);
  const [isSyncing, setIsSyncing] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  const syncPrice = async () => {
    setIsSyncing(true);
    const data = await fetchLivePrice();
    if (data) {
      setPriceData(data);
    } else {
      // Micro-jitter simulation for visual continuity if API throttle occurs
      setPriceData(prev => ({
        ...prev,
        priceUsd: prev.priceUsd + (Math.random() - 0.5) * 0.000000000000001
      }));
    }
    setLastUpdate(Date.now());
    // Artificial delay to make the "Sync" feel substantive
    setTimeout(() => setIsSyncing(false), 1200);
  };

  useEffect(() => {
    syncPrice();
    const interval = setInterval(syncPrice, 15000); // 15s refresh
    return () => clearInterval(interval);
  }, []);

  const handleBuy = () => {
    window.open(PANCAKESWAP_URL, '_blank');
  };

  // Logic: Expressing the price of THRUST as number of THRUST / 1 USD
  const thrustPerDollar = priceData.priceUsd > 0 ? 1 / priceData.priceUsd : 0;
  
  // Format high precision price
  const priceParts = priceData.priceUsd.toFixed(18).split('.');
  const whole = priceParts[0];
  const fractional = priceParts[1];

  return (
    <div className="min-h-screen bg-black text-green-500 font-mono flex flex-col selection:bg-green-500 selection:text-black overflow-x-hidden">
      {/* HUD Navigation */}
      <nav className="p-6 flex justify-between items-center border-b border-green-900/20 bg-black/95 backdrop-blur-2xl sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-green-500 text-black flex items-center justify-center font-black text-xl rounded shadow-[0_0_30px_rgba(34,197,94,0.5)]">
            Δ
          </div>
          <div className="hidden sm:block">
            <span className="font-black tracking-tighter text-2xl text-white block leading-none">DELTA.V</span>
            <span className="text-[8px] text-green-800 tracking-[0.4em] font-black uppercase">Actual Truth Connector v6.0</span>
          </div>
        </div>
        
        <button 
          onClick={onEnterCockpit}
          className="group flex items-center gap-3 px-6 py-2.5 bg-zinc-950 border border-zinc-800 hover:border-green-500/50 transition-all rounded-md"
        >
          <Shield size={16} className="text-zinc-600 group-hover:text-green-500 transition-colors" />
          <div className="text-left hidden md:block">
            <div className="text-[10px] font-black uppercase text-zinc-500 group-hover:text-white transition-colors tracking-widest leading-none">Admin Cockpit</div>
            <div className="text-[8px] text-zinc-700 tracking-tighter uppercase font-mono">Verified Access Required</div>
          </div>
        </button>
      </nav>

      {/* Main Burn Portal */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-12 relative">
        {/* Dynamic Scanlines & Grid */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1600px] h-[1600px] bg-green-500/[0.03] rounded-full blur-[250px]"></div>
          <div className="absolute top-0 w-full h-full opacity-[0.05]" style={{ backgroundImage: 'linear-gradient(#0f0 1px, transparent 1px), linear-gradient(90deg, #0f0 1px, transparent 1px)', backgroundSize: '120px 120px' }}></div>
        </div>

        {/* 18dp Actual Price Monitor */}
        <div className="z-10 space-y-10 animate-in fade-in slide-in-from-top-16 duration-1000">
          <div className="inline-flex items-center gap-5 px-6 py-2.5 border border-green-900/40 bg-green-950/50 rounded-full backdrop-blur-md">
            <div className="relative">
              <div className={`w-2.5 h-2.5 rounded-full ${isSyncing ? 'bg-yellow-500 animate-ping' : 'bg-green-500'} relative shadow-[0_0_20px_currentColor]`}></div>
            </div>
            <span className="text-zinc-400 text-[10px] uppercase tracking-[0.6em] font-black">
              {isSyncing ? 'UPLINKING_ON_CHAIN_DEAL...' : 'PANCAKESWAP_NOMINAL_SYNC'}
            </span>
          </div>

          <div className="space-y-8">
            <h2 className="text-[14px] text-zinc-600 uppercase tracking-[1em] font-black">Protocol Valuation Index</h2>
            
            <div className="relative group flex flex-col items-center gap-8">
               {/* Primary Price Display: 1 THRUST value in USD */}
               <div className="bg-zinc-950/90 border border-zinc-800/80 p-10 md:p-14 rounded-[3rem] shadow-[0_0_120px_rgba(34,197,94,0.15)] backdrop-blur-xl transition-all hover:scale-[1.01] hover:border-green-500/40">
                 <div className="text-[11px] uppercase tracking-[0.8em] text-zinc-500 mb-6 font-black opacity-50">1 THRUST =</div>
                 <div className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black tracking-tighter text-white font-mono leading-none flex items-center justify-center">
                   <span className="text-green-500 opacity-60 mr-4 md:mr-8">$</span>
                   {whole}.<span className="text-zinc-200">{fractional.slice(0, 8)}</span><span className="text-zinc-600">{fractional.slice(8, 14)}</span><span className="text-zinc-800">{fractional.slice(14)}</span>
                 </div>
               </div>

               {/* Secondary Calculation: THRUST / 1 USD */}
               <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-700 flex flex-col items-center group/deal">
                  <div className="h-10 w-px bg-gradient-to-b from-zinc-800 to-green-900/40 mb-2"></div>
                  <div className="bg-green-950/20 border border-zinc-900 px-10 py-6 rounded-2xl backdrop-blur-lg shadow-inner group-hover/deal:border-green-500/30 transition-all cursor-crosshair">
                    <span className="text-[11px] uppercase tracking-[0.6em] text-zinc-500 mr-6 font-black">Yield Capacity (1 USD):</span>
                    <span className="text-2xl md:text-4xl font-black font-mono text-green-400">
                      {thrustPerDollar.toLocaleString(undefined, { maximumFractionDigits: 6 })} <span className="text-green-800 text-base tracking-normal">THRUST</span>
                    </span>
                  </div>
               </div>
            </div>

            {/* Metrics HUD */}
            <div className="pt-10 flex flex-wrap justify-center items-center gap-10 text-zinc-600 text-[10px] font-black tracking-[0.4em] uppercase">
              <div className="flex items-center gap-3">
                <Activity size={14} className="text-green-900" />
                <span>LIQ: <span className="text-zinc-400">${(priceData.liquidityUsd / 1000).toFixed(1)}K</span></span>
              </div>
              <div className="flex items-center gap-3 border-x border-zinc-900 px-10">
                <TrendingUp size={14} className={priceData.priceChange >= 0 ? "text-green-500" : "text-red-500"} />
                <span className={priceData.priceChange >= 0 ? "text-green-500" : "text-red-500"}>
                  {priceData.priceChange >= 0 ? '+' : ''}{priceData.priceChange.toFixed(2)}%
                </span>
              </div>
              <div className="flex items-center gap-3 cursor-pointer hover:text-green-500 transition-colors" onClick={syncPrice}>
                <RefreshCcw size={14} className={isSyncing ? "animate-spin" : ""} /> 
                <span className="font-mono">LAST_ACTUAL_SYNC: {Math.floor((Date.now() - lastUpdate) / 1000)}s</span>
              </div>
            </div>
          </div>
        </div>

        {/* Primary Call to Action */}
        <div className="z-10 w-full max-w-2xl animate-in fade-in zoom-in-95 duration-1000 delay-500">
          <button 
            onClick={handleBuy}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            className="group relative w-full py-16 bg-green-500 text-black font-black text-4xl sm:text-5xl tracking-[0.1em] rounded-[2rem] overflow-hidden transition-all hover:scale-[1.04] active:scale-95 shadow-[0_0_150px_rgba(34,197,94,0.4)] border-b-[14px] border-green-700 active:border-b-0 hover:shadow-[0_0_180px_rgba(34,197,94,0.7)]"
          >
            <div className={`absolute inset-0 bg-white/40 transition-transform duration-700 ${isHovered ? 'translate-x-0' : '-translate-x-full'}`}></div>
            <div className="relative flex flex-col items-center gap-5">
              <div className="flex items-center gap-6">
                <Rocket className={`${isHovered ? 'animate-bounce' : ''}`} size={64} />
                INITIATE IGNITION
              </div>
              <div className="flex items-center gap-4 text-[16px] tracking-[0.8em] opacity-80 font-black">
                EXECUTE DEAL ON PANCAKESWAP <ArrowRight size={20} />
              </div>
            </div>
          </button>
          
          <div className="mt-14 grid grid-cols-2 gap-10 px-6 text-[12px] text-zinc-500 font-black uppercase tracking-widest">
            <div className="flex flex-col items-center gap-4 bg-zinc-950/80 p-8 rounded-3xl border border-zinc-900 backdrop-blur-xl group hover:border-green-500/30 transition-all">
              <Zap size={28} className="text-yellow-500 opacity-60 group-hover:opacity-100 transition-opacity" />
              <span className="text-zinc-400">Actual Deal Offer</span>
              <p className="text-[9px] text-zinc-600 tracking-normal italic normal-case">Real-time routing via BSC network protocol.</p>
            </div>
            <div className="flex flex-col items-center gap-4 bg-zinc-950/80 p-8 rounded-3xl border border-zinc-900 backdrop-blur-xl group hover:border-blue-500/30 transition-all">
              <Lock size={28} className="text-blue-500 opacity-60 group-hover:opacity-100 transition-opacity" />
              <span className="text-zinc-400">100Y LP Locked</span>
              <p className="text-[9px] text-zinc-600 tracking-normal italic normal-case">Mathematically guaranteed security until 2124.</p>
            </div>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="z-10 w-full max-w-7xl py-16 animate-in fade-in slide-in-from-bottom-24 duration-1000 delay-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
             <div className="flex flex-col items-center space-y-8 p-14 bg-zinc-950/90 border border-zinc-900 rounded-[3rem] group hover:border-green-500/50 transition-all hover:shadow-[0_0_60px_rgba(34,197,94,0.1)]">
                <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center text-green-500 border border-zinc-800 transition-transform group-hover:rotate-12 group-hover:scale-110">
                  <ExternalLink size={44} />
                </div>
                <h4 className="text-white text-2xl font-black uppercase tracking-widest">Instant Swap</h4>
                <p className="text-zinc-600 text-xs leading-relaxed italic max-w-xs font-mono font-bold">
                  Direct smart-link to PancakeSwap V2. Pre-filled with verified THRUST liquidity routing.
                </p>
             </div>

             <div className="flex flex-col items-center space-y-8 p-14 bg-zinc-950/90 border border-zinc-900 rounded-[3rem] group hover:border-blue-500/50 transition-all hover:shadow-[0_0_60px_rgba(59,130,246,0.1)]">
                <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center text-blue-500 border border-zinc-800 transition-transform group-hover:-rotate-12 group-hover:scale-110">
                  <Lock size={44} />
                </div>
                <h4 className="text-white text-2xl font-black uppercase tracking-widest">Century Lock</h4>
                <p className="text-zinc-600 text-xs leading-relaxed italic max-w-xs font-mono font-bold">
                  Immutable trust. Liquidity pools are mathematically sequestered for 100 years.
                </p>
             </div>

             <div className="flex flex-col items-center space-y-8 p-14 bg-zinc-950/90 border border-zinc-900 rounded-[3rem] group hover:border-yellow-500/50 transition-all hover:shadow-[0_0_60px_rgba(234,179,8,0.1)]">
                <div className="w-24 h-24 bg-zinc-900 rounded-[2rem] flex items-center justify-center text-yellow-500 border border-zinc-800 transition-transform group-hover:scale-110">
                  <Zap size={44} />
                </div>
                <h4 className="text-white text-2xl font-black uppercase tracking-widest">100% APY Power</h4>
                <p className="text-zinc-600 text-xs leading-relaxed italic max-w-xs font-mono font-bold">
                  Earn rewards every 15 minutes. High-velocity rebase mechanics scale your orbit.
                </p>
             </div>
          </div>
        </div>
      </main>

      {/* Verification Overlay */}
      <section className="py-48 bg-black border-t border-zinc-900 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-transparent via-green-500 to-transparent"></div>
        <div className="max-w-6xl mx-auto px-6 space-y-20">
          <div className="space-y-6">
            <h3 className="text-xl uppercase font-black tracking-[1.2em] text-zinc-500">System Identity Protocol</h3>
            <div className="flex items-center justify-center gap-14 text-green-900 text-sm font-black uppercase tracking-widest font-mono">
              <span className="flex items-center gap-3"><Shield size={20} /> ON_CHAIN_VERIFIED</span>
              <span className="flex items-center gap-3"><Info size={20} /> BROBOT_AUDITED</span>
              <span className="flex items-center gap-3"><Lock size={20} /> IMMUTABLE_STATE</span>
            </div>
          </div>
          
          <div className="bg-zinc-950 border border-zinc-800 p-14 rounded-[4rem] flex flex-col items-center gap-14 group relative shadow-2xl">
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 px-8 py-3 bg-zinc-900 border border-zinc-800 rounded-full text-[12px] font-black text-green-500 tracking-[0.6em] uppercase shadow-2xl animate-bounce">Secure Contract</div>
            <code className="text-sm md:text-3xl lg:text-4xl text-green-500/80 group-hover:text-green-400 transition-all break-all font-mono tracking-tighter bg-black border border-zinc-900 p-10 rounded-3xl block w-full text-center shadow-inner">
              {THRUST_ADDRESS}
            </code>
            <div className="flex flex-col sm:flex-row gap-10 w-full max-w-4xl">
              <button 
                onClick={() => {
                   navigator.clipboard.writeText(THRUST_ADDRESS);
                }}
                className="flex-1 px-14 py-8 bg-zinc-900 border border-zinc-800 text-base font-black uppercase hover:bg-zinc-800 transition-all rounded-[1.5rem] text-zinc-500 hover:text-white tracking-[0.4em] shadow-lg"
              >
                COPY ADDRESS
              </button>
              <a 
                href={`https://bscscan.com/address/${THRUST_ADDRESS}`} 
                target="_blank" 
                className="flex-1 px-14 py-8 bg-green-500/5 border border-green-500/20 text-base font-black uppercase hover:bg-green-500/10 transition-all rounded-[1.5rem] text-green-500 hover:text-green-400 flex items-center justify-center gap-6 tracking-[0.4em] shadow-lg"
              >
                BSCSCAN VIEW <ExternalLink size={32} />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Corporate Footer */}
      <footer className="p-24 border-t border-zinc-900 text-center space-y-16 bg-zinc-950/40">
        <div className="text-[22px] text-zinc-600 tracking-[1.2em] uppercase font-black">
          POWERED BY <span className="text-white">BROBOT AI ONBOARDING</span>
        </div>
        <div className="text-[12px] text-zinc-800 font-mono flex flex-col md:flex-row items-center justify-center gap-20 uppercase tracking-[0.5em] font-black">
          <span className="flex items-center gap-4"><Rocket size={18} /> © 2024 DELTAV ECOSYSTEM</span>
          <span className="flex items-center gap-4 italic"><RefreshCcw size={18} /> ACTUAL PRICE FEED ACTIVE</span>
          <span className="flex items-center gap-4"><Shield size={18} /> VERSION: THRUST_FINAL_7.0</span>
        </div>
      </footer>
    </div>
  );
};
