
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import hljs from "highlight.js";
import { epistemic, LogEntry } from './epistemic.ts';

interface Message {
    text: string;
    sender: 'user' | 'ai';
    grounding?: any[];
}

interface Persona {
    id: string;
    name: string;
    description: string;
    instruction: string;
}

interface ModuleState {
    id: string;
    x: number;
    y: number;
    w: number;
    h: number;
    isDecoupled: boolean;
    isOpen: boolean;
    zIndex: number;
}

const TOOLTIP_MAP: Record<string, string> = {
    "PYTHAI": "The central mastermind and parent organization (pythai.net).",
    "Sun Tsu": "Tactical Dojo master providing Art of War guidance.",
    "openDAO": "Cross-domain consensus governance layer.",
    "Seven Soldiers": "Executive command board: COO, CFO, CTO, CISO, CLO, CPO, CRO.",
    "RAGE": "Retrieval Augmented Generative Engine powering the Knowledge Economy."
};

const SOLDIERS = [
    { id: 'COO', name: 'Operations' }, { id: 'CFO', name: 'Finance' },
    { id: 'CTO', name: 'Technology' }, { id: 'CISO', name: 'Security' },
    { id: 'CLO', name: 'Legal' }, { id: 'CPO', name: 'Product' },
    { id: 'CRO', name: 'Risk' }
];

const SOURCE_FILES: Record<string, string> = {
    'openDAO.sol': `// SPDX-License-Identifier: MIT\npragma solidity ^0.8.20;\n\ncontract OpenDAO {\n    // 2/3 Cross-Domain Logic\n    // DEV, MKT, COMM majority enforcement...`,
    'board_meeting.sol': `// CEO + Seven Soldiers signature substrate.\n// Requires CEO signature and 5/7 Soldiers.`,
    'consensus.yaml': `thresholds:\n  overall: 0.666\n  domain: 0.666\ndomains: [DEV, MKT, COMM]`
};

const App = () => {
    // Neural States
    const [messages, setMessages] = useState<Message[]>([
        { text: "Neural link established. **PYTHAI // THE ROOT** online.\nSun Tsu active in DOJO. OpenDAO consensus tree: INITIALIZED.\nSelf-evolving reasoning substrate: ACTIVE.", sender: 'ai' }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isRageMode, setIsRageMode] = useState(false);
    const [directiveMode, setDirectiveMode] = useState<'DIRECT' | 'DOJO' | 'BANKON'>('DIRECT');
    
    // Knowledge State
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [activeSource, setActiveSource] = useState<string | null>(null);

    // Persona/Identity Substrate
    const [personas, setPersonas] = useState<Persona[]>([]);
    const [activePersona, setActivePersona] = useState<Persona | null>(null);
    const [isPersonaMenuOpen, setIsPersonaMenuOpen] = useState(false);

    // Module Order & Layout
    const [moduleOrder, setModuleOrder] = useState<string[]>(['resp', 'input', 'manifesto', 'soldiers', 'dao', 'tree', 'viz', 'logs', 'diag']);
    const [modules, setModules] = useState<Record<string, ModuleState>>({
        resp: { id: 'resp', x: 0, y: 0, w: 680, h: 420, isDecoupled: false, isOpen: true, zIndex: 10 },
        input: { id: 'input', x: 0, y: 0, w: 680, h: 360, isDecoupled: false, isOpen: true, zIndex: 11 },
        manifesto: { id: 'manifesto', x: 0, y: 0, w: 680, h: 420, isDecoupled: false, isOpen: false, zIndex: 12 },
        soldiers: { id: 'soldiers', x: 0, y: 0, w: 680, h: 220, isDecoupled: false, isOpen: true, zIndex: 13 },
        dao: { id: 'dao', x: 0, y: 0, w: 680, h: 250, isDecoupled: false, isOpen: true, zIndex: 14 },
        tree: { id: 'tree', x: 0, y: 0, w: 680, h: 320, isDecoupled: false, isOpen: true, zIndex: 15 },
        viz: { id: 'viz', x: 0, y: 0, w: 680, h: 250, isDecoupled: false, isOpen: true, zIndex: 16 },
        logs: { id: 'logs', x: 0, y: 0, w: 680, h: 300, isDecoupled: false, isOpen: false, zIndex: 17 },
        diag: { id: 'diag', x: 0, y: 0, w: 680, h: 140, isDecoupled: false, isOpen: true, zIndex: 18 }
    });

    const [diagnostics, setDiagnostics] = useState({ load: 2, mem: 34, status: 'STABLE' });
    const [soldierStatus, setSoldierStatus] = useState<Record<string, boolean>>(Object.fromEntries(SOLDIERS.map(s => [s.id, true])));
    const [daoStatus, setDaoStatus] = useState({ dev: 0.94, mkt: 0.82, comm: 0.76 });

    // Dao Separation States
    const [isDaoIsolated, setIsDaoIsolated] = useState(false);
    const [daoPosition, setDaoPosition] = useState({ x: 0, y: 0 });
    const [isDraggingDao, setIsDraggingDao] = useState(false);
    const daoHoldTimer = useRef<number | null>(null);

    const activeDrag = useRef<string | null>(null);
    const dragOffset = useRef({ x: 0, y: 0 });
    const topZ = useRef(50);
    const workspaceRef = useRef<HTMLDivElement>(null);
    const textAreaRef = useRef<HTMLTextAreaElement>(null);

    const resetAllPositions = useCallback(() => {
        const isMobile = window.innerWidth < 768;
        const w = isMobile ? window.innerWidth * 0.96 : 680;
        const startX = (window.innerWidth - w) / 2;
        let currentY = 70;

        setModules(prev => {
            const updated = { ...prev };
            moduleOrder.forEach(id => {
                const mod = updated[id];
                if (mod && mod.isOpen && !mod.isDecoupled) {
                    updated[id] = { ...mod, x: startX, y: currentY, w: w };
                    currentY += mod.h + 15;
                }
            });
            return updated;
        });
    }, [moduleOrder]);

    useEffect(() => {
        resetAllPositions();
        fetch('/persona.json').then(res => res.json()).then(data => {
            setPersonas(data.personas);
            setActivePersona(data.personas[0]);
        });

        const unsubscribe = epistemic.subscribe(() => {
            setLogs(epistemic.getLogs());
        });

        const interval = setInterval(() => {
            setDiagnostics(d => ({ ...d, load: 1 + Math.random() * 5, mem: 34 + Math.random() * 2 }));
            setSoldierStatus(prev => ({ ...prev, [SOLDIERS[Math.floor(Math.random() * 7)].id]: Math.random() > 0.05 }));
        }, 5000);

        return () => {
            clearInterval(interval);
            unsubscribe();
        };
    }, [resetAllPositions]);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (!workspaceRef.current) return;
            const x = (e.clientX / window.innerWidth - 0.5) * 5; 
            const y = (e.clientY / window.innerHeight - 0.5) * -5;
            workspaceRef.current.style.setProperty('--x-rotation', `${y}deg`);
            workspaceRef.current.style.setProperty('--y-rotation', `${x}deg`);

            if (isDraggingDao) {
                const rect = workspaceRef.current.getBoundingClientRect();
                setDaoPosition({
                    x: e.clientX - rect.left - rect.width / 2,
                    y: e.clientY - rect.top - 200
                });
            }
        };

        const handleMouseUp = () => {
            if (daoHoldTimer.current) {
                clearTimeout(daoHoldTimer.current);
                daoHoldTimer.current = null;
            }
            setIsDraggingDao(false);
        };

        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDraggingDao]);

    const handleDaoMouseDown = (e: React.MouseEvent) => {
        e.stopPropagation();
        e.preventDefault();
        if (isDaoIsolated) {
            setIsDraggingDao(true);
        } else {
            daoHoldTimer.current = window.setTimeout(() => {
                setIsDaoIsolated(true);
                epistemic.logEvent("substrateDecoupling", "Expression of the Dao isolated from neural core");
            }, 600);
        }
    };

    const toggleModule = (id: string) => {
        setModules(prev => ({
            ...prev,
            [id]: { ...prev[id], isOpen: !prev[id].isOpen }
        }));
    };

    const handleSendMessage = async (textOverride?: string) => {
        const finalContent = textOverride || inputValue;
        if (!finalContent.trim() || isLoading) return;
        
        const prefix = directiveMode === 'DOJO' ? '[SUN_TSU_DOJO] ' : directiveMode === 'BANKON' ? '[IDENTITY_AUTH] ' : '';
        const msg = prefix + finalContent;
        
        setMessages(prev => [...prev, { text: msg, sender: 'user' }, { text: '', sender: 'ai' }]);
        setInputValue('');
        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            // Self-evolving logic reference: awesome-agentic-reasoning & Sun Tzu
            let systemInst = `${activePersona?.instruction || "You are PYTHAI."} 
            Reference tactical wisdom: Sun Tsu Art of War (Invincibility first, then victory). 
            Apply reflective reasoning (Chain-of-Thought with self-critique).
            Current Executive State: 7 Soldiers Active (COO, CFO, CTO, CISO, CLO, CPO, CRO). 
            Threshold Consensus Logic: (Dev: 2/3 AND Mkt: 2/3) OR (Mkt: 2/3 AND Comm: 2/3) OR (Dev: 2/3 AND Comm: 2/3).
            Focus on self-evolving patterns: https://github.com/weitianxin/Awesome-Agentic-Reasoning. Always consider CFO's financial constraints and CTO's technical feasibility.`;
            
            if (isRageMode) {
                systemInst += `\n**RAGE MODE ACTIVE**: Focus on Knowledge Economy monetization. Reference https://rage.pythai.net.`;
            }

            const response = await ai.models.generateContent({
                model: 'gemini-3-pro-preview',
                contents: msg,
                config: { 
                    systemInstruction: systemInst,
                    tools: [{ googleSearch: {} }]
                }
            });
            const text = response.text || "Neural link failure.";
            
            setMessages(prev => {
                const next = [...prev];
                next[next.length - 1] = { text, sender: 'ai', grounding: response.candidates?.[0]?.groundingMetadata?.groundingChunks };
                return next;
            });
        } catch (e: any) {
            setMessages(prev => [...prev.slice(0, -1), { text: "Cognitive link disrupted: " + e.message, sender: 'ai' }]);
        } finally {
            setIsLoading(false);
        }
    };

    const renderModule = (id: string, title: string, content: React.ReactNode) => {
        const mod = modules[id];
        if (!mod || !mod.isOpen) return null;
        return (
            <div 
                className={`module ${id}-module ${mod.isDecoupled ? 'decoupled' : 'linked'} layer`}
                style={{ 
                    left: mod.x, 
                    top: mod.y, 
                    width: mod.w, 
                    height: mod.h, 
                    zIndex: mod.zIndex 
                }}
                onMouseDown={(e) => {
                    const target = e.target as HTMLElement;
                    if (target.closest('.module-handle')) {
                        topZ.current += 1;
                        setModules(prev => ({ ...prev, [id]: { ...prev[id], zIndex: topZ.current } }));
                        activeDrag.current = id;
                        dragOffset.current = { x: e.clientX - mod.x, y: e.clientY - mod.y };
                    }
                }}
            >
                <div className="module-handle">
                    <span className="ladder-pos">#{moduleOrder.indexOf(id) + 1}</span>
                    <span className="handle-title">{title}</span>
                    <div className="mod-controls">
                        <button onClick={(e) => { e.stopPropagation(); setModules(prev => ({...prev, [id]: {...prev[id], isDecoupled: !prev[id].isDecoupled}})) }}>{mod.isDecoupled ? '⚓' : '🔗'}</button>
                        <button onClick={(e) => { e.stopPropagation(); setModules(prev => ({...prev, [id]: {...prev[id], isOpen: false}})) }}>×</button>
                    </div>
                </div>
                <div className="module-inner">{content}</div>
            </div>
        );
    };

    return (
        <div ref={workspaceRef} className="workspace">
            {/* Top Command Bar */}
            <div className="substrate-control-bar layer depth-layer-near">
                <div className="bar-logo">
                    <img src="https://agenticplace.pythai.net/agentaitrans.png" className="bar-img" />
                    <span>PYTHAI // EXECUTIVE_SUBSTRATE</span>
                </div>
                <div className="bar-buttons">
                    {Object.keys(modules).map(id => (
                        <button key={id} className={modules[id].isOpen ? 'active' : ''} onClick={() => toggleModule(id)}>
                            {id.toUpperCase()}
                        </button>
                    ))}
                </div>
            </div>

            {renderModule('resp', 'EXECUTIVE_COMMAND_CENTER', (
                <div className="chat-area">
                    {messages.map((m, i) => (
                        <div key={i} className={`message ${m.sender}`}>
                            <div dangerouslySetInnerHTML={{ __html: marked.parse(m.text) as string }} />
                        </div>
                    ))}
                    {isLoading && <div className="loading-ping">Self-evolving tactical analysis...</div>}
                </div>
            ))}

            {renderModule('input', 'DIRECTIVE_CONSOLE', (
                <div className="input-substrate">
                    <div className="directive-controls">
                        <div className="mode-selector">
                            <button className={directiveMode === 'DIRECT' ? 'active' : ''} onClick={() => setDirectiveMode('DIRECT')}>DIRECT</button>
                            <button className={directiveMode === 'DOJO' ? 'active' : ''} onClick={() => setDirectiveMode('DOJO')}>SUN_TSU_DOJO</button>
                        </div>
                    </div>
                    <textarea 
                        value={inputValue} 
                        onChange={(e) => setInputValue(e.target.value)} 
                        placeholder="Issue strategic directive to Seven Soldiers and CEO..."
                        onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
                    />
                    <button onClick={() => handleSendMessage()} disabled={isLoading} className="transmit-btn">TRANSMIT</button>
                </div>
            ))}

            {renderModule('dao', 'OPENDAO // CONSENSUS_SUBSTRATE', (
                <div className="dao-substrate">
                    <div className="source-tabs">
                        {Object.keys(SOURCE_FILES).map(f => (
                            <button key={f} className={activeSource === f ? 'active' : ''} onClick={() => setActiveSource(f)}>{f}</button>
                        ))}
                    </div>
                    <div className="code-viewer">
                        <pre><code>{activeSource ? SOURCE_FILES[activeSource] : "// OpenDAO Consensus Logic"}</code></pre>
                    </div>
                    <div className="dao-visual-tree">
                        <div className="domain-row">
                            <div className="domain-item">DEV: 2/3</div>
                            <div className="domain-item">MKT: 2/3</div>
                            <div className="domain-item">COMM: 2/3</div>
                        </div>
                        <div className="consensus-result">CONSENSUS = (DEV & MKT) | (MKT & COMM) | (DEV & COMM)</div>
                    </div>
                </div>
            ))}

            {renderModule('tree', 'CEO_DECISION_FRAMEWORK', (
                <div className="tree-substrate">
                    <svg className="decision-tree-svg" width="100%" height="300" viewBox="0 0 500 300">
                        {/* Recursive Path Lines */}
                        <path d="M 50 150 L 150 150" stroke="var(--accent)" fill="none" strokeWidth="2" />
                        <path d="M 150 150 L 250 80" stroke="var(--accent)" fill="none" strokeWidth="1" />
                        <path d="M 150 150 L 250 150" stroke="var(--accent)" fill="none" strokeWidth="1" />
                        <path d="M 150 150 L 250 220" stroke="var(--accent)" fill="none" strokeWidth="1" />
                        
                        {/* Domain Threshhold Branches */}
                        <path d="M 250 80 L 350 40" stroke="var(--accent)" fill="none" opacity="0.5" />
                        <path d="M 250 80 L 350 100" stroke="var(--accent)" fill="none" opacity="0.5" />
                        
                        <path d="M 250 220 L 350 180" stroke="var(--accent)" fill="none" opacity="0.5" />
                        <path d="M 250 220 L 350 240" stroke="var(--accent)" fill="none" opacity="0.5" />

                        {/* Nodes */}
                        <circle cx="50" cy="150" r="10" fill="var(--accent)" />
                        <text x="20" y="130" fill="var(--accent)" fontSize="10" fontWeight="900">INTENT</text>
                        
                        <rect x="135" y="130" width="30" height="40" fill="var(--module-bg)" stroke="var(--accent)" />
                        <text x="130" y="120" fill="var(--accent)" fontSize="9">CEO_AGENT</text>
                        
                        <circle cx="250" cy="80" r="8" fill="var(--accent)" opacity="0.8" />
                        <text x="265" y="85" fill="var(--accent)" fontSize="9">DEV_DOMAIN (2/3)</text>
                        
                        <circle cx="250" cy="150" r="8" fill="var(--rage)" />
                        <text x="265" y="155" fill="var(--rage)" fontSize="9">MKT_DOMAIN (2/3)</text>
                        
                        <circle cx="250" cy="220" r="8" fill="var(--accent)" opacity="0.8" />
                        <text x="265" y="225" fill="var(--accent)" fontSize="9">COMM_DOMAIN (2/3)</text>
                        
                        {/* Result Node */}
                        <rect x="420" y="135" width="60" height="30" fill="var(--accent)" stroke="#000" />
                        <text x="425" y="155" fill="#000" fontSize="10" fontWeight="900">EXECUTE</text>
                    </svg>
                </div>
            ))}

            {renderModule('soldiers', 'MINDX // EXECUTIVE_BOARD', (
                <div className="soldiers-substrate">
                    <div className="soldier-grid">
                        {SOLDIERS.map(s => (
                            <div key={s.id} className="soldier-card">
                                <label>{s.id}</label>
                                <div className={`status-dot ${soldierStatus[s.id] ? 'alive' : 'stale'}`}></div>
                                <span className="s-name">{s.name}</span>
                            </div>
                        ))}
                    </div>
                    <div className="consensus-meter">
                        <label>EXECUTIVE SUPERMAJORITY [5/7]</label>
                        <div className="meter-bar"><div className="fill" style={{ width: `${(Object.values(soldierStatus).filter(v => v).length / 7) * 100}%` }}></div></div>
                    </div>
                </div>
            ))}
            
            {renderModule('viz', 'DYNAMIC_3D_VISUALIZER', (
                <div className="viz-substrate">
                    <div className="viz-box">
                        <div className="box-face face-front">PYTHAI</div>
                        <div className="box-face face-back">mindX</div>
                        <div className="box-face face-right">RAGE</div>
                        <div className="box-face face-left">OPENDAO</div>
                        {/* Dao Center Interaction Surface */}
                        <div 
                            className={`dao-center ${isDaoIsolated ? 'isolated' : ''} ${isDraggingDao ? 'dragging' : ''}`}
                            style={isDaoIsolated ? { transform: `translate3d(${daoPosition.x}px, ${daoPosition.y}px, 200px) rotateZ(0deg)` } : { transform: 'translateZ(70px)' }}
                            onMouseDown={handleDaoMouseDown}
                        >
                            <div className="taijitu">
                                <div className="dot top"></div>
                                <div className="dot bottom"></div>
                            </div>
                            <div className="hit-area-hint">DAO_ROOT</div>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
