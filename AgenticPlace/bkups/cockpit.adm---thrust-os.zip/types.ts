
// Fix: Import React to resolve 'Cannot find namespace React' error when using React.ReactNode in type definitions
import React from 'react';

export enum Network {
  BSC_MAINNET = 'BSC_MAINNET',
  ARC_TESTNET = 'ARC_TESTNET'
}

export type OracleSnapshot = {
  priceUSD: number;
  volume24h: number;
  liquidity: number;
  timestamp: number;
  block: number;
  deltaSinceLast: number;
  confirmed: boolean;
};

export interface TabConfig {
  id: string;
  label: string;
  icon: React.ReactNode;
}

export interface ContractFunction {
  name: string;
  inputs: { name: string; type: string }[];
  stateMutability: 'view' | 'pure' | 'nonpayable' | 'payable';
}

export interface AdminCredentials {
  address: string;
  role: string;
  isConnected: boolean;
  owner: boolean;
}
