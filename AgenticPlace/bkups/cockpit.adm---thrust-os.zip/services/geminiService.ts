
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeContractCode(code: string) {
  try {
    // Fix: Upgrade to gemini-3-pro-preview for complex coding and reasoning tasks (smart contract auditing)
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Analyze the following smart contract code for potential vulnerabilities and summarize its main functionality: \n\n${code}`,
      config: {
        systemInstruction: "You are a senior smart contract auditor. Provide concise, high-impact security analysis in Markdown format."
      }
    });
    // Fix: Ensure we use the .text property directly as per latest SDK guidelines
    return response.text;
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return "Analysis unavailable. Check API configuration.";
  }
}
