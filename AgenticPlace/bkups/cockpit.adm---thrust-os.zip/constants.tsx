
import React from 'react';
import { Network, ContractFunction } from './types';

export const COLORS = {
  PRIMARY: '#00ff00',
  SECONDARY: '#004400',
  BACKGROUND: '#000000',
  ERROR: '#ff0000',
  WARNING: '#ffff00',
};

export const MOCK_ABI: ContractFunction[] = [
  { name: 'setFees', inputs: [{ name: 'buyFee', type: 'uint256' }, { name: 'sellFee', type: 'uint256' }], stateMutability: 'nonpayable' },
  { name: 'owner', inputs: [], stateMutability: 'view' },
  { name: 'balanceOf', inputs: [{ name: 'account', type: 'address' }], stateMutability: 'view' },
  { name: 'rebase', inputs: [{ name: 'epoch', type: 'uint256' }, { name: 'supplyDelta', type: 'int256' }], stateMutability: 'nonpayable' },
  { name: 'setLocker', inputs: [{ name: 'locker', type: 'address' }], stateMutability: 'nonpayable' },
  { name: 'getReserves', inputs: [], stateMutability: 'view' },
];

export const NETWORK_CONFIGS = {
  [Network.BSC_MAINNET]: {
    name: 'Binance Smart Chain',
    chainId: 56,
    explorer: 'https://bscscan.com',
    color: '#F3BA2F'
  },
  [Network.ARC_TESTNET]: {
    name: 'ARC Testnet',
    chainId: 12345,
    explorer: 'https://explorer.arc-testnet.url',
    color: '#00ffcc'
  }
};
