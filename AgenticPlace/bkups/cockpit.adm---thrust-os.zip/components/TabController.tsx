
import React, { useState } from 'react';
import { TruthOracleTab } from './tabs/TruthOracleTab';
import { LauncherTab } from './tabs/LauncherTab';
import { ContractInteractTab } from './tabs/ContractInteractTab';
import { AttentionRewardTab } from './tabs/AttentionRewardTab';
import { AdminViewTab } from './tabs/AdminViewTab';
import { Shield, Radio, Terminal, Heart, Zap, LayoutGrid } from 'lucide-react';

export const TabController: React.FC = () => {
  const [activeTab, setActiveTab] = useState('oracle');

  const tabs = [
    { id: 'oracle', label: 'TRUTH ORACLE', icon: <Radio size={16} />, component: <TruthOracleTab /> },
    { id: 'interact', label: 'CONTRACT UI', icon: <Terminal size={16} />, component: <ContractInteractTab /> },
    { id: 'launch', label: 'LAUNCHER LAB', icon: <Zap size={16} />, component: <LauncherTab /> },
    { id: 'attention', label: 'LUV ATTENTION', icon: <Heart size={16} />, component: <AttentionRewardTab /> },
    { id: 'admin', label: 'SYSTEM ADM', icon: <Shield size={16} />, component: <AdminViewTab /> },
  ];

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {/* Tab Navigation */}
      <div className="flex border-b border-green-900/30 bg-black/80 backdrop-blur-xl px-4 pt-4 sticky top-0 z-50">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`
              flex items-center gap-2 px-6 py-3 text-[10px] font-bold tracking-widest uppercase transition-all
              ${activeTab === tab.id 
                ? 'text-green-400 border-b-2 border-green-500 bg-green-500/5' 
                : 'text-zinc-600 hover:text-zinc-300 border-b-2 border-transparent'}
            `}
          >
            {tab.icon}
            <span className="hidden md:inline">{tab.label}</span>
          </button>
        ))}
        <div className="flex-1"></div>
        <div className="flex items-center gap-4 px-4 pb-2">
          <div className="flex flex-col items-end">
             <span className="text-[8px] text-zinc-500 uppercase">System Status</span>
             <span className="text-[10px] text-green-500 font-mono animate-pulse">OPTIMAL.v4</span>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
        <div className="max-w-[1400px] mx-auto h-full">
           {tabs.find(t => t.id === activeTab)?.component}
        </div>
      </main>

      {/* Footer Status Bar */}
      <footer className="bg-black border-t border-zinc-900 px-6 py-2 flex items-center justify-between text-[9px] font-mono text-zinc-500 uppercase tracking-tighter">
        <div className="flex gap-6">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            NETWORK: BSC_MAINNET
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
            MIRROR: ARC_TESTNET
          </div>
        </div>
        <div className="flex gap-6">
          <span>LATENCY: 42ms</span>
          <span>UPTIME: 99.999%</span>
          <span>© 2024 THRUST.OS // COCKPIT.ADM</span>
        </div>
      </footer>
    </div>
  );
};
