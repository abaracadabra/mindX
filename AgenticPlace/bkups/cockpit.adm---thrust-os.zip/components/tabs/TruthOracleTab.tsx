
import React, { useState, useEffect } from 'react';
import { generateSnapshot } from '../../services/oracleService';
import { OracleSnapshot } from '../../types';
import { LiveGraph } from '../visuals/LiveGraph';
import { Activity, ShieldCheck, Globe, Database } from 'lucide-react';

export const TruthOracleTab: React.FC = () => {
  const [snapshots, setSnapshots] = useState<OracleSnapshot[]>([]);
  const [current, setCurrent] = useState<OracleSnapshot | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const fresh = generateSnapshot();
      setCurrent(fresh);
      setSnapshots(prev => [...prev.slice(-29), fresh]);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  if (!current) return <div className="p-8 text-center animate-pulse">Initializing Oracle Streams...</div>;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-zinc-900/80 border border-green-900 p-4 rounded-lg flex flex-col items-center justify-center text-center">
          <Activity size={20} className="mb-2 text-green-400" />
          <span className="text-[10px] uppercase opacity-50">Price USD</span>
          <span className="text-xl font-bold font-mono">${current.priceUSD.toFixed(8)}</span>
        </div>
        <div className="bg-zinc-900/80 border border-green-900 p-4 rounded-lg flex flex-col items-center justify-center text-center">
          <Globe size={20} className="mb-2 text-blue-400" />
          <span className="text-[10px] uppercase opacity-50">24h Volume</span>
          <span className="text-xl font-bold font-mono">${(current.volume24h / 1000).toFixed(1)}K</span>
        </div>
        <div className="bg-zinc-900/80 border border-green-900 p-4 rounded-lg flex flex-col items-center justify-center text-center">
          <Database size={20} className="mb-2 text-purple-400" />
          <span className="text-[10px] uppercase opacity-50">Liquidity</span>
          <span className="text-xl font-bold font-mono">${(current.liquidity / 1000000).toFixed(2)}M</span>
        </div>
        <div className="bg-zinc-900/80 border border-green-900 p-4 rounded-lg flex flex-col items-center justify-center text-center">
          <ShieldCheck size={20} className="mb-2 text-yellow-400" />
          <span className="text-[10px] uppercase opacity-50">Status</span>
          <span className="text-xl font-bold text-green-400">CONFIRMED</span>
        </div>
      </div>

      <LiveGraph data={snapshots} />

      <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4">
        <h4 className="text-xs font-bold uppercase mb-4 opacity-70 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          Live Event Log
        </h4>
        <div className="space-y-2 font-mono text-[11px] overflow-y-auto max-h-[150px]">
          {snapshots.slice().reverse().map((s, i) => (
            <div key={i} className="flex justify-between border-b border-zinc-800 pb-1 opacity-80 hover:opacity-100">
              <span>[BLOCK {s.block}] Oracle Sync: Price @ {s.priceUSD.toFixed(8)}</span>
              <span className="text-zinc-500">{new Date(s.timestamp).toLocaleTimeString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
