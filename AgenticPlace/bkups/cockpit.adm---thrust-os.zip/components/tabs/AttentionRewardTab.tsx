
import React, { useState, useEffect } from 'react';
import { generateSnapshot } from '../../services/oracleService';
import { Heart, TrendingUp, Zap, Users } from 'lucide-react';

export const AttentionRewardTab: React.FC = () => {
  const [luvBalance, setLuvBalance] = useState(12450.32);
  const [earningsRate, setEarningsRate] = useState(0.42);
  const [thrustPrice, setThrustPrice] = useState(0.00001193);
  
  useEffect(() => {
    const interval = setInterval(() => {
      const s = generateSnapshot();
      setThrustPrice(s.priceUSD);
      setLuvBalance(prev => prev + (Math.random() * 0.1));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const attentionCoefficient = 2.5; // Custom scaling factor
  const luvUsdValue = thrustPrice * attentionCoefficient;

  return (
    <div className="space-y-6 animate-in zoom-in-95 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-zinc-900/80 border-b-2 border-red-900/50 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <Heart className="text-red-500 animate-pulse" />
            <span className="text-[10px] bg-red-900/30 text-red-400 px-2 py-0.5 rounded">LUV BALANCE</span>
          </div>
          <p className="text-2xl font-bold font-mono">{luvBalance.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
          <p className="text-xs text-zinc-500 mt-1">≈ ${(luvBalance * luvUsdValue).toFixed(2)} USD</p>
        </div>

        <div className="bg-zinc-900/80 border-b-2 border-yellow-900/50 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <Zap className="text-yellow-500" />
            <span className="text-[10px] bg-yellow-900/30 text-yellow-400 px-2 py-0.5 rounded">ATTENTION RATE</span>
          </div>
          <p className="text-2xl font-bold font-mono">{earningsRate} LUV/min</p>
          <p className="text-xs text-zinc-500 mt-1">Activity Score: 84%</p>
        </div>

        <div className="bg-zinc-900/80 border-b-2 border-blue-900/50 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <TrendingUp className="text-blue-500" />
            <span className="text-[10px] bg-blue-900/30 text-blue-400 px-2 py-0.5 rounded">LUV/USD INDEX</span>
          </div>
          <p className="text-2xl font-bold font-mono">${luvUsdValue.toFixed(6)}</p>
          <p className="text-xs text-zinc-500 mt-1">Relative to THRUST price</p>
        </div>

        <div className="bg-zinc-900/80 border-b-2 border-green-900/50 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <Users className="text-green-500" />
            <span className="text-[10px] bg-green-900/30 text-green-400 px-2 py-0.5 rounded">NETWORK NODES</span>
          </div>
          <p className="text-2xl font-bold font-mono">1,024</p>
          <p className="text-xs text-zinc-500 mt-1">Synchronized Participants</p>
        </div>
      </div>

      <div className="bg-zinc-900/30 border border-zinc-800 p-6 rounded-lg">
        <h3 className="text-sm font-bold uppercase mb-6 flex items-center gap-2">
          <Zap size={16} className="text-yellow-500" /> Valuation Methodology
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="space-y-2">
            <div className="text-3xl font-mono text-green-500">${thrustPrice.toFixed(8)}</div>
            <div className="text-[10px] uppercase text-zinc-500">THRUST/USD Value</div>
          </div>
          <div className="flex items-center justify-center text-zinc-700 font-bold text-2xl">×</div>
          <div className="space-y-2">
            <div className="text-3xl font-mono text-yellow-500">{attentionCoefficient}</div>
            <div className="text-[10px] uppercase text-zinc-500">Attention Coefficient</div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-zinc-800 flex justify-center">
          <div className="text-center">
            <div className="text-4xl font-mono font-bold text-white">${luvUsdValue.toFixed(6)}</div>
            <div className="text-[10px] uppercase text-zinc-400 mt-2">Current Implied LUV Value</div>
          </div>
        </div>
      </div>
    </div>
  );
};
