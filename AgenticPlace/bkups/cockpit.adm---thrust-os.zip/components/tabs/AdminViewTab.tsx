
import React from 'react';
import { Shield, Key, Lock, UserCheck } from 'lucide-react';

export const AdminViewTab: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in zoom-in-95 duration-700">
      <div className="text-center">
        <h2 className="text-2xl font-bold glow-text mb-2">SYSTEM CREDENTIALS</h2>
        <p className="text-xs text-zinc-500 uppercase tracking-widest">Admin Authorization Level 4</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-lg flex gap-4 items-start">
          <div className="p-3 bg-green-500/10 rounded-lg text-green-500">
            <UserCheck size={24} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-zinc-400 mb-1">CONNECTED WALLET</h4>
            <p className="text-sm font-mono text-green-400">0x969F60Bfe17962E0f061B434596545C7b6Cd6Fc4</p>
            <p className="text-[10px] text-zinc-500 mt-1 uppercase">VERIFIED SYSTEM OWNER</p>
          </div>
        </div>

        <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-lg flex gap-4 items-start">
          <div className="p-3 bg-blue-500/10 rounded-lg text-blue-500">
            <Shield size={24} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-zinc-400 mb-1">ACCESS LEVEL</h4>
            <p className="text-sm font-mono text-blue-400 font-bold uppercase">Super Admin / Multisig Signer</p>
            <p className="text-[10px] text-zinc-500 mt-1 uppercase">UNRESTRICTED PROTOCOL CONTROL</p>
          </div>
        </div>
      </div>

      <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg overflow-hidden">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-zinc-800/50">
            <tr>
              <th className="p-4 border-b border-zinc-700 text-zinc-400">ROLE_NAME</th>
              <th className="p-4 border-b border-zinc-700 text-zinc-400">ACCESS_KEY</th>
              <th className="p-4 border-b border-zinc-700 text-zinc-400">STATUS</th>
            </tr>
          </thead>
          <tbody>
            <tr className="hover:bg-zinc-800/20 transition-colors">
              <td className="p-4 border-b border-zinc-800">EMERGENCY_PAUSE</td>
              <td className="p-4 border-b border-zinc-800 opacity-30">0x2A1...92F3</td>
              <td className="p-4 border-b border-zinc-800 text-green-500">ACTIVE</td>
            </tr>
            <tr className="hover:bg-zinc-800/20 transition-colors">
              <td className="p-4 border-b border-zinc-800">FEE_CONTROLLER</td>
              <td className="p-4 border-b border-zinc-800 opacity-30">0x969...6Fc4</td>
              <td className="p-4 border-b border-zinc-800 text-green-500">ACTIVE</td>
            </tr>
            <tr className="hover:bg-zinc-800/20 transition-colors">
              <td className="p-4 border-b border-zinc-800">UPGRADE_HANDLER</td>
              <td className="p-4 border-b border-zinc-800 opacity-30">0x969...6Fc4</td>
              <td className="p-4 border-b border-zinc-800 text-green-500">ACTIVE</td>
            </tr>
            <tr className="hover:bg-zinc-800/20 transition-colors">
              <td className="p-4 border-b border-zinc-800">DAO_ORCHESTRATOR</td>
              <td className="p-4 border-b border-zinc-800 opacity-30">0x4F2...8C11</td>
              <td className="p-4 border-b border-zinc-800 text-yellow-500">PENDING_APPROVAL</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="bg-red-950/20 border border-red-900/30 p-6 rounded-lg">
        <div className="flex items-center gap-3 mb-4">
          <Lock className="text-red-500" size={20} />
          <h4 className="text-sm font-bold text-red-500 uppercase">Emergency Protocol Override</h4>
        </div>
        <p className="text-xs text-red-400/70 mb-4">Activating emergency protocols will freeze all contract movements across BSC and ARC networks. This action requires a secondary signature.</p>
        <button className="bg-red-900 hover:bg-red-800 text-white font-bold py-2 px-6 rounded text-xs transition-colors">INITIATE GLOBAL LOCKDOWN</button>
      </div>
    </div>
  );
};
