
import React, { useState } from 'react';
import { analyzeContractCode } from '../../services/geminiService';
import { Terminal, Rocket, Search, ShieldAlert } from 'lucide-react';

export const LauncherTab: React.FC = () => {
  const [code, setCode] = useState(`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract ThrustExtension {
    address public admin;
    
    constructor() {
        admin = msg.sender;
    }
    
    function executeThrust(uint256 amount) external {
        // Logic for extension execution
    }
}`);
  const [analysis, setAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isDeploying, setIsDeploying] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    const result = await analyzeContractCode(code);
    setAnalysis(result || "Analysis failed.");
    setIsAnalyzing(false);
    setLogs(prev => [`[SYSTEM] AI Audit initiated at ${new Date().toLocaleTimeString()}`, ...prev]);
  };

  const handleDeploy = () => {
    setIsDeploying(true);
    setLogs(prev => [`[NETWORK] Broadcasing deployment transaction...`, ...prev]);
    setTimeout(() => {
      setLogs(prev => [`[SUCCESS] Contract deployed at 0x969F...6Fc4`, ...prev]);
      setIsDeploying(false);
    }, 2000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setCode(text);
    setLogs(prev => [`[LOCAL] Imported file: ${file.name}`, ...prev]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full animate-in fade-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col gap-4">
        <div className="flex justify-between items-center bg-zinc-900 border border-green-900 p-2 rounded-t-lg">
          <span className="text-[10px] uppercase font-bold px-2">Contract Editor (v0.8.20)</span>
          <div className="flex gap-2">
            <input type="file" id="remix-upload" className="hidden" onChange={handleFileUpload} />
            <label htmlFor="remix-upload" className="cursor-pointer text-[9px] bg-zinc-800 hover:bg-zinc-700 px-2 py-1 rounded transition-all">
              IMPORT FROM REMIX
            </label>
          </div>
        </div>
        <textarea
          className="flex-1 w-full bg-black text-green-400 font-mono text-xs p-4 border border-zinc-800 focus:outline-none focus:border-green-500 rounded-b-lg min-h-[400px]"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          spellCheck={false}
        />
        <div className="flex gap-4">
          <button 
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-white p-3 rounded-lg border border-zinc-700 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            <Search size={16} className={isAnalyzing ? 'animate-spin' : ''} />
            {isAnalyzing ? 'AUDITING...' : 'AI AUDIT'}
          </button>
          <button 
            onClick={handleDeploy}
            disabled={isDeploying}
            className="flex-1 bg-green-600 hover:bg-green-700 text-black font-bold p-3 rounded-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-[0_0_15px_rgba(22,163,74,0.4)]"
          >
            <Rocket size={16} />
            {isDeploying ? 'DEPLOYING...' : 'DEPLOY TO ARC'}
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 flex-1 overflow-y-auto">
          <h4 className="text-xs font-bold uppercase mb-4 text-yellow-400 flex items-center gap-2">
            <ShieldAlert size={14} /> AI Auditor Analysis
          </h4>
          <div className="text-xs leading-relaxed text-zinc-300 font-sans prose prose-invert max-w-none">
            {analysis || "Submit code for AI security analysis."}
          </div>
        </div>

        <div className="bg-black border border-zinc-800 rounded-lg p-4 h-[150px] overflow-hidden flex flex-col">
          <h4 className="text-[10px] font-bold uppercase mb-2 text-zinc-500 flex items-center gap-2">
            <Terminal size={12} /> Execution Logs
          </h4>
          <div className="flex-1 overflow-y-auto font-mono text-[10px] text-green-600">
            {logs.length === 0 && <span className="opacity-30">Waiting for commands...</span>}
            {logs.map((log, i) => <div key={i}>{log}</div>)}
          </div>
        </div>
      </div>
    </div>
  );
};
