
import React, { useState } from 'react';
import { MOCK_ABI } from '../../constants';
import { Play, Eye, Terminal } from 'lucide-react';

export const ContractInteractTab: React.FC = () => {
  const [responses, setResponses] = useState<{[key: string]: string}>({});
  const [inputs, setInputs] = useState<{[key: string]: string[]}>({});
  const [logs, setLogs] = useState<string[]>([]);

  const handleInputChange = (fnName: string, idx: number, val: string) => {
    setInputs(prev => ({
      ...prev,
      [fnName]: {
        ...prev[fnName],
        [idx]: val
      }
    }));
  };

  const handleExecute = (fnName: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] Executing ${fnName}...`, ...prev]);
    
    // Simulate interaction
    setTimeout(() => {
      const isView = MOCK_ABI.find(f => f.name === fnName)?.stateMutability === 'view';
      if (isView) {
        const mockResult = fnName === 'owner' ? '0x969F...6Fc4' : Math.floor(Math.random() * 1000000).toString();
        setResponses(prev => ({ ...prev, [fnName]: mockResult }));
        setLogs(prev => [`[${timestamp}] Result: ${mockResult}`, ...prev]);
      } else {
        const txHash = '0x' + Math.random().toString(16).slice(2, 42);
        setResponses(prev => ({ ...prev, [fnName]: `TX: ${txHash.slice(0, 10)}...` }));
        setLogs(prev => [`[${timestamp}] Success. Hash: ${txHash}`, ...prev]);
      }
    }, 800);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full animate-in fade-in slide-in-from-left-4 duration-500">
      <div className="lg:col-span-2 overflow-y-auto pr-2 space-y-4 max-h-[70vh]">
        {MOCK_ABI.map((fn, i) => {
          const isView = fn.stateMutability === 'view' || fn.stateMutability === 'pure';
          return (
            <div key={i} className="bg-zinc-900/40 border border-zinc-800 p-4 rounded-lg hover:border-green-800 transition-colors group">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] px-2 py-0.5 rounded ${isView ? 'bg-blue-900/50 text-blue-400' : 'bg-orange-900/50 text-orange-400'}`}>
                    {fn.stateMutability.toUpperCase()}
                  </span>
                  <h3 className="text-sm font-bold font-mono">{fn.name}</h3>
                </div>
                <button 
                  onClick={() => handleExecute(fn.name)}
                  className={`p-2 rounded-full transition-all ${isView ? 'hover:bg-blue-500/20 text-blue-400' : 'hover:bg-orange-500/20 text-orange-400'}`}
                >
                  {isView ? <Eye size={16} /> : <Play size={16} />}
                </button>
              </div>
              
              <div className="space-y-2">
                {fn.inputs.map((input, idx) => (
                  <div key={idx} className="flex flex-col gap-1">
                    <label className="text-[10px] text-zinc-500 font-mono">{input.name} ({input.type})</label>
                    <input 
                      type="text"
                      className="bg-black border border-zinc-800 text-green-500 font-mono text-xs p-2 rounded focus:outline-none focus:border-green-900"
                      onChange={(e) => handleInputChange(fn.name, idx, e.target.value)}
                    />
                  </div>
                ))}
              </div>

              {responses[fn.name] && (
                <div className="mt-3 p-2 bg-black/80 rounded border border-green-900/30 text-[10px] font-mono text-green-400 flex items-center gap-2">
                  <span className="opacity-50">Response:</span>
                  <span>{responses[fn.name]}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="flex flex-col gap-4">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 flex-1 flex flex-col">
          <h4 className="text-xs font-bold uppercase mb-4 text-zinc-500 flex items-center gap-2">
            <Terminal size={14} /> Interaction History
          </h4>
          <div className="flex-1 overflow-y-auto font-mono text-[10px] text-green-800">
            {logs.map((log, i) => (
              <div key={i} className="mb-1 border-b border-zinc-800/50 pb-1">{log}</div>
            ))}
          </div>
        </div>
        <div className="bg-zinc-900 p-4 rounded-lg border border-green-900/30">
          <h4 className="text-xs font-bold uppercase mb-2">Contract Metadata</h4>
          <div className="text-[10px] font-mono space-y-1 opacity-70">
            <p>Address: 0x969F60B...6Fc4</p>
            <p>Compiler: v0.8.20+commit</p>
            <p>Optimizations: Enabled (200)</p>
          </div>
        </div>
      </div>
    </div>
  );
};
