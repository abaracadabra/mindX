
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { OracleSnapshot } from '../../types';

interface LiveGraphProps {
  data: OracleSnapshot[];
}

export const LiveGraph: React.FC<LiveGraphProps> = ({ data }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || data.length < 2) return;

    const margin = { top: 20, right: 30, bottom: 30, left: 60 };
    const width = svgRef.current.clientWidth - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const g = svg.append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    const x = d3.scaleTime()
      .domain(d3.extent(data, d => new Date(d.timestamp)) as [Date, Date])
      .range([0, width]);

    const y = d3.scaleLinear()
      .domain([
        d3.min(data, d => d.priceUSD) * 0.999,
        d3.max(data, d => d.priceUSD) * 1.001
      ])
      .range([height, 0]);

    const line = d3.line<OracleSnapshot>()
      .x(d => x(new Date(d.timestamp)))
      .y(d => y(d.priceUSD))
      .curve(d3.curveMonotoneX);

    // Grid lines
    g.append("g")
      .attr("class", "grid")
      .attr("stroke", "#111")
      .call(d3.axisLeft(y).tickSize(-width).tickFormat(() => ""));

    // Line
    const path = g.append("path")
      .datum(data)
      .attr("fill", "none")
      .attr("stroke", "#0f0")
      .attr("stroke-width", 2)
      .attr("d", line);

    // Area
    const area = d3.area<OracleSnapshot>()
      .x(d => x(new Date(d.timestamp)))
      .y0(height)
      .y1(d => y(d.priceUSD));

    g.append("path")
      .datum(data)
      .attr("fill", "url(#gradient)")
      .attr("d", area);

    // Gradient
    const defs = svg.append("defs");
    const gradient = defs.append("linearGradient")
      .attr("id", "gradient")
      .attr("x1", "0%").attr("y1", "0%")
      .attr("x2", "0%").attr("y2", "100%");
    gradient.append("stop").attr("offset", "0%").attr("stop-color", "#0f0").attr("stop-opacity", 0.3);
    gradient.append("stop").attr("offset", "100%").attr("stop-color", "#0f0").attr("stop-opacity", 0);

    // Axes
    g.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x).ticks(5).tickFormat(d3.timeFormat("%H:%M:%S") as any))
      .style("color", "#0f0");

    g.append("g")
      .call(d3.axisLeft(y).ticks(5).tickFormat(d3.format(".8f") as any))
      .style("color", "#0f0");

  }, [data]);

  return (
    <div className="w-full bg-black/50 border border-green-900 rounded-lg p-4 overflow-hidden">
      <h3 className="text-xs font-bold mb-2 uppercase tracking-tighter opacity-70">Live Truth Feed (Price USD)</h3>
      <svg ref={svgRef} className="w-full h-[300px]"></svg>
    </div>
  );
};
