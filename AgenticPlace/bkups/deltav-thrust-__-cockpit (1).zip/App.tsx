
import React, { useState, useEffect } from 'react';
import { TabController } from './components/TabController';
import { LandingPage } from './components/LandingPage';
import { LayoutGrid, Maximize2, Minimize2, Power, Globe, Star } from 'lucide-react';

const App: React.FC = () => {
  const [booted, setBooted] = useState(false);
  const [view, setView] = useState<'landing' | 'cockpit'>('landing');
  const [showMonitor, setShowMonitor] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setBooted(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  if (!booted) {
    return (
      <div className="h-screen w-screen bg-black flex flex-col items-center justify-center font-mono space-y-6">
        <div className="relative">
          <div className="w-24 h-24 border-4 border-green-500/20 border-t-green-500 rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center text-green-500 glow-text text-xl font-bold">Δ</div>
        </div>
        <div className="text-center">
          <h1 className="text-xl tracking-[0.5em] text-green-500 glow-text font-bold mb-2 uppercase">DeltaV THRUST</h1>
          <p className="text-[10px] text-green-800 animate-pulse uppercase tracking-widest">Initiating symcryptosis bridge...</p>
        </div>
      </div>
    );
  }

  if (view === 'landing') {
    return <LandingPage onEnterCockpit={() => setView('cockpit')} />;
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-black text-green-500 selection:bg-green-500 selection:text-black">
      {/* Global Admin Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-green-900/40 bg-zinc-950 backdrop-blur-md z-50">
        <div className="flex items-center gap-6">
          <button 
            onClick={() => setView('cockpit')}
            className="flex items-center gap-3 group"
          >
             <div className="bg-green-600 text-black p-1.5 font-black rounded text-sm leading-none transition-transform group-hover:scale-110 shadow-[0_0_10px_rgba(34,197,94,0.5)]">Δ</div>
             <h1 className="font-black tracking-tighter text-lg uppercase glow-text text-white">DeltaV THRUST // COCKPIT</h1>
          </button>
          
          <div className="h-6 w-px bg-zinc-800 hidden md:block"></div>
          
          <button 
            onClick={() => setView('landing')}
            className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-green-500 hover:border-green-500/50 transition-all"
          >
            <Globe size={14} className="text-zinc-500 group-hover:text-green-500" />
            JOURNEY HUB
          </button>
          
          <div className="hidden lg:flex gap-6 text-[10px] font-mono opacity-40">
            <span className="hover:opacity-100 cursor-help uppercase tracking-widest">BRIDGE_CAPTAIN_MODE</span>
            <span className="hover:opacity-100 cursor-help uppercase tracking-widest italic">Symcryptosis Theory Active</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
           <button 
             onClick={() => setShowMonitor(!showMonitor)}
             className={`p-2 border rounded-lg transition-all ${showMonitor ? 'bg-green-900/20 border-green-500 text-green-400 shadow-[0_0_15px_rgba(34,197,94,0.2)]' : 'border-zinc-800 text-zinc-500 hover:border-zinc-700 hover:text-white'}`}
             title="Toggle Real-Time Market Vector"
           >
             <LayoutGrid size={18} />
           </button>
           <button 
             onClick={() => setView('landing')}
             className="flex items-center gap-3 bg-red-950/10 border border-red-900/20 px-4 py-2 rounded-lg text-[10px] font-black hover:bg-red-500 hover:text-white transition-all text-red-500 uppercase tracking-widest"
           >
             <Power size={14} />
             ABORT MISSION
           </button>
        </div>
      </header>

      {/* Main Admin Environment */}
      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 relative bg-black">
           <TabController />
        </div>

        {/* Sidebar Price Monitor */}
        {showMonitor && (
          <aside className="w-[480px] border-l border-zinc-900 bg-zinc-950 flex flex-col animate-in slide-in-from-right-full duration-500">
             <div className="p-5 border-b border-zinc-900 flex justify-between items-center bg-zinc-900/50">
               <div className="flex items-center gap-3">
                 <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                 <h3 className="text-xs font-black uppercase tracking-[0.2em] text-white">THRUST Market Vector</h3>
               </div>
               <button onClick={() => setShowMonitor(false)} className="text-zinc-500 hover:text-white transition-colors">
                 <Minimize2 size={16} />
               </button>
             </div>
             <div className="flex-1 relative bg-black">
               <div id="dexscreener-embed" className="w-full h-full">
                 <iframe 
                   src="https://dexscreener.com/bsc/0x762e1925Cc37Ac085dC81732113E0Eb1382C4D2B?embed=1&loadChartSettings=0&chartTheme=dark&theme=dark&chartStyle=9&chartType=usd&interval=1S"
                   style={{ width: '100%', height: '100%', border: '0' }}
                   className="grayscale opacity-90 hover:grayscale-0 hover:opacity-100 transition-all duration-700"
                 ></iframe>
               </div>
             </div>
          </aside>
        )}
      </div>
    </div>
  );
};

export default App;
