
import React, { useState } from 'react';
import { analyzeContractCode } from '../../services/geminiService';
import { Terminal, Rocket, Search, ShieldAlert, Globe, ArrowRight, Layers, Share2 } from 'lucide-react';

export const LauncherTab: React.FC = () => {
  const [code, setCode] = useState(`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract ThrustL2Bridge {
    // Symcryptosis Theory Bridge Logic
    // Syncing Price Mean across L2 nodes
}`);
  const [analysis, setAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    const result = await analyzeContractCode(code);
    setAnalysis(result || "Analysis failed.");
    setIsAnalyzing(false);
    setLogs(prev => [`[AUDIT] Cryptosphere Scan initiated...`, ...prev]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full animate-in fade-in slide-in-from-right-4 duration-700">
      {/* Code Editor Column */}
      <div className="lg:col-span-7 flex flex-col gap-6">
        <div className="flex flex-col flex-1 bg-zinc-950 border border-zinc-900 rounded-[2.5rem] overflow-hidden shadow-2xl">
          <div className="flex justify-between items-center bg-zinc-900/50 p-4 border-b border-zinc-900">
            <div className="flex items-center gap-3">
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/20"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-green-500/20"></div>
              </div>
              <span className="text-[10px] uppercase font-black text-zinc-500 tracking-widest px-2">Bridge_Constructor_v1.0</span>
            </div>
          </div>
          <textarea
            className="flex-1 w-full bg-transparent text-green-500 font-mono text-[11px] p-8 focus:outline-none custom-scrollbar resize-none"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            spellCheck={false}
          />
          <div className="p-6 border-t border-zinc-900 flex gap-4 bg-zinc-900/20">
            <button 
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 py-4 rounded-2xl border border-zinc-800 flex items-center justify-center gap-3 transition-all font-black text-[10px] uppercase tracking-widest disabled:opacity-50"
            >
              <Search size={16} className={isAnalyzing ? 'animate-spin' : ''} />
              {isAnalyzing ? 'SCANNING...' : 'AI_SECURITY_SCAN'}
            </button>
            <button 
              className="flex-1 bg-green-500 hover:bg-green-600 text-black py-4 rounded-2xl flex items-center justify-center gap-3 transition-all font-black text-[10px] uppercase tracking-widest shadow-[0_0_20px_rgba(34,197,94,0.3)]"
            >
              <Rocket size={16} />
              CONSTRUCT_L2_BRIDGE
            </button>
          </div>
        </div>
      </div>

      {/* Telemetry & Analysis Column */}
      <div className="lg:col-span-5 flex flex-col gap-6">
        {/* Bridge Map Simulation */}
        <div className="bg-zinc-900/40 border border-zinc-800 p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden">
          <div className="absolute bottom-0 right-0 p-4 opacity-5">
            <Globe size={150} className="text-blue-500" />
          </div>
          <h3 className="text-xs font-black uppercase mb-6 text-zinc-500 flex items-center gap-3 tracking-[0.3em]">
            <Share2 size={16} className="text-blue-500" /> Cross_Chain_Telemetry
          </h3>
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="text-center">
                <div className="text-[10px] font-black text-white">BSC</div>
                <div className="text-[8px] text-green-500 font-mono uppercase">Source</div>
              </div>
              <div className="flex-1 mx-4 h-px bg-zinc-800 relative">
                <div className="absolute top-1/2 left-0 -translate-y-1/2 w-2 h-2 bg-green-500 rounded-full animate-ping"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[8px] bg-zinc-900 px-2 text-zinc-600 font-black">SYNCING</div>
              </div>
              <div className="text-center opacity-30">
                <div className="text-[10px] font-black text-white uppercase italic">Polygon</div>
                <div className="text-[8px] text-zinc-500 font-mono uppercase">Target</div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-center">
                <div className="text-[10px] font-black text-white uppercase italic">ARC</div>
                <div className="text-[8px] text-blue-500 font-mono uppercase">Next_Node</div>
              </div>
              <div className="flex-1 mx-4 h-px bg-zinc-800 border-dashed border-t opacity-20"></div>
              <div className="text-center opacity-10">
                <div className="text-[10px] font-black text-white uppercase italic">L2_OS</div>
                <div className="text-[8px] text-zinc-500 font-mono uppercase">Queue</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-black border border-zinc-800 p-8 rounded-[2.5rem] flex-1 overflow-y-auto shadow-inner relative">
          <h4 className="text-xs font-black uppercase mb-6 text-yellow-500 flex items-center gap-3 tracking-widest">
            <ShieldAlert size={16} /> Audit_Feedback
          </h4>
          <div className="text-[11px] leading-relaxed text-zinc-400 font-mono whitespace-pre-wrap italic">
            {analysis || "// Waiting for L2 bridge source code analysis..."}
          </div>
        </div>

        <div className="bg-zinc-950 border border-zinc-900 p-6 rounded-[2rem] flex flex-col h-[180px]">
          <h4 className="text-[10px] font-black uppercase mb-4 text-zinc-600 flex items-center gap-2">
            <Terminal size={14} /> Bridge_Logs
          </h4>
          <div className="flex-1 overflow-y-auto font-mono text-[9px] text-green-900 custom-scrollbar">
            {logs.length === 0 && <span className="opacity-20 italic">No construction tasks in queue...</span>}
            {logs.map((log, i) => <div key={i} className="mb-1">{log}</div>)}
          </div>
        </div>
      </div>
    </div>
  );
};
