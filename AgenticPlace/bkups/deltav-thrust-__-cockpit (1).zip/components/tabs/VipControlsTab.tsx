
import React, { useState, useEffect, useRef } from 'react';
// Fix: Added Terminal to the list of lucide-react imports
import { Crown, Zap, ShieldAlert, Target, Play, Pause, ExternalLink, BellRing, RefreshCcw, TrendingDown, AlertCircle, Terminal } from 'lucide-react';
import { PANCAKESWAP_URL } from '../../constants';
import { fetchLivePrice } from '../../services/oracleService';

export const VipControlsTab: React.FC = () => {
  const [threshold, setThreshold] = useState<number>(0.00005200);
  const [buyAmount, setBuyAmount] = useState<number>(100); // Amount in USD
  const [isActive, setIsActive] = useState(false);
  const [currentPrice, setCurrentPrice] = useState<number>(0.00005398);
  const [logs, setLogs] = useState<string[]>([]);
  const [triggered, setTriggered] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  
  const logContainerRef = useRef<HTMLDivElement>(null);

  const addLog = (msg: string, type: 'info' | 'warn' | 'success' | 'crit' = 'info') => {
    const prefix = {
      info: '>>',
      warn: '!!',
      success: 'OK',
      crit: 'XX'
    }[type];
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${prefix} ${msg}`, ...prev.slice(0, 49)]);
  };

  useEffect(() => {
    let interval: any;
    
    const monitorPrice = async () => {
      setIsSyncing(true);
      const data = await fetchLivePrice();
      if (data) {
        setCurrentPrice(data.priceUsd);
        if (isActive && !triggered && data.priceUsd <= threshold) {
          handleTrigger(data.priceUsd);
        }
      }
      setIsSyncing(false);
    };

    if (isActive && !triggered) {
      addLog(`AUTO-BUY ENGAGED. TARGET: $${threshold.toFixed(8)} | ALLOC: $${buyAmount}`, 'success');
      monitorPrice(); // Immediate check
      interval = setInterval(monitorPrice, 5000); // 5s actual sync
    } else if (!isActive && !triggered) {
      addLog("Protocol in SLEEP_MODE. Awaiting user ignition.");
    }

    return () => clearInterval(interval);
  }, [isActive, threshold, triggered, buyAmount]);

  // Auto-scroll logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = 0;
    }
  }, [logs]);

  const handleTrigger = (price: number) => {
    setTriggered(true);
    setIsActive(false);
    addLog(`TARGET BREACHED: Market at $${price.toFixed(8)}`, 'crit');
    addLog(`Initiating automated order for $${buyAmount} USD...`, 'warn');
    addLog("Bypassing standard routing... Directing to PancakeSwap V2 Mainnet.");
    
    // Automatic execution
    setTimeout(() => {
      window.open(PANCAKESWAP_URL, '_blank');
    }, 1200);
  };

  const forceTrigger = () => {
    addLog("DEBUG: Manual override triggered. Testing DEX bridge...");
    handleTrigger(currentPrice);
  };

  const resetProtocol = () => {
    setTriggered(false);
    setIsActive(false);
    addLog("System Purged. Protocol reset to default standby parameters.", 'info');
  };

  // Proximity Calculation
  const proximity = Math.max(0, Math.min(100, (threshold / currentPrice) * 100));
  const isClose = proximity > 95;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-right-12 duration-1000">
      {/* Header HUD */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 border-b border-zinc-900 pb-10">
        <div className="space-y-2">
          <div className="flex items-center gap-4 text-yellow-500">
            <div className="relative">
              <Crown size={32} className={`${isActive ? 'animate-bounce' : ''} drop-shadow-[0_0_15px_rgba(234,179,8,0.5)]`} />
              {isActive && <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping"></div>}
            </div>
            <div>
              <h2 className="text-3xl font-black tracking-tighter uppercase italic leading-none">VIP_SNIPER_BETA</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] text-zinc-600 font-bold tracking-[0.3em] uppercase">DeltaV Autonomous Execution v7.4</span>
                <span className="bg-yellow-500/10 text-yellow-600 text-[8px] px-1.5 py-0.5 rounded border border-yellow-500/20 font-black">PREMIUM</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-zinc-950 border border-zinc-800 p-1 rounded-2xl flex items-center shadow-2xl">
          <div className="px-6 py-3 border-r border-zinc-900">
            <div className="text-[9px] text-zinc-600 font-black uppercase tracking-widest mb-1">Link Status</div>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isSyncing ? 'bg-yellow-500 animate-pulse' : 'bg-green-500'} shadow-[0_0_8px_currentColor]`}></div>
              <span className="text-[10px] font-black uppercase text-zinc-300">
                {isSyncing ? 'SYNCING...' : 'LIVE_FEED'}
              </span>
            </div>
          </div>
          <button 
            onClick={() => {
              if(!triggered) setIsActive(!isActive);
            }}
            disabled={triggered}
            className={`px-8 py-3 flex items-center gap-4 transition-all rounded-xl m-1 ${isActive ? 'bg-green-500 text-black font-black' : 'bg-zinc-900 text-zinc-500 hover:text-zinc-300'}`}
          >
            {isActive ? <Pause size={18} /> : <Play size={18} />}
            <span className="text-xs uppercase tracking-[0.2em]">{isActive ? 'ENGAGED' : 'STANDBY'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Configuration Panel */}
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-zinc-900/40 border border-zinc-800 p-8 rounded-[3rem] space-y-8 relative overflow-hidden group shadow-2xl backdrop-blur-sm">
            <div className="absolute -top-10 -right-10 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <TrendingDown size={200} className="text-red-500" />
            </div>
            
            <div className="space-y-4">
              <label className="text-[11px] font-black uppercase text-zinc-500 tracking-[0.3em] flex items-center gap-3">
                <Target size={16} className="text-yellow-500" /> TARGET_DIP_THRESHOLD
              </label>
              <div className="relative group/input">
                <div className="absolute inset-0 bg-yellow-500/5 blur-xl opacity-0 group-focus-within/input:opacity-100 transition-opacity"></div>
                <span className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-700 font-black text-xl">$</span>
                <input 
                  type="number" 
                  step="0.00000001"
                  value={threshold}
                  disabled={isActive || triggered}
                  onChange={(e) => setThreshold(parseFloat(e.target.value))}
                  className="w-full bg-black border border-zinc-800 rounded-2xl p-6 pl-12 text-2xl font-black text-white focus:border-yellow-500/50 outline-none transition-all font-mono disabled:opacity-50"
                />
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-[11px] font-black uppercase text-zinc-500 tracking-[0.3em] flex items-center gap-3">
                <Zap size={16} className="text-blue-500" /> PURCHASE_CAPITAL_USD
              </label>
              <div className="relative group/input">
                <span className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-700 font-black text-xl">$</span>
                <input 
                  type="number" 
                  value={buyAmount}
                  disabled={isActive || triggered}
                  onChange={(e) => setBuyAmount(parseFloat(e.target.value))}
                  className="w-full bg-black border border-zinc-800 rounded-2xl p-6 pl-12 text-2xl font-black text-white focus:border-blue-500/50 outline-none transition-all font-mono disabled:opacity-50"
                />
              </div>
            </div>

            {/* Proximity Gauge */}
            <div className="p-6 bg-black/80 border border-zinc-800 rounded-3xl space-y-4 shadow-inner">
              <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest">
                <span className="text-zinc-500">Proximity to target</span>
                <span className={isClose ? 'text-red-500 animate-pulse' : 'text-green-500'}>
                  {proximity.toFixed(2)}%
                </span>
              </div>
              <div className="w-full h-2 bg-zinc-900 rounded-full overflow-hidden flex">
                <div 
                  className={`h-full transition-all duration-700 ${isClose ? 'bg-red-500 shadow-[0_0_15px_#ef4444]' : 'bg-yellow-500'}`} 
                  style={{ width: `${proximity}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-[9px] font-mono text-zinc-700 font-black">
                <span>0.00</span>
                <span>TARGET: ${threshold.toFixed(8)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <button 
                onClick={resetProtocol}
                className="py-4 border border-zinc-800 hover:bg-zinc-800/50 rounded-2xl text-[10px] font-black uppercase tracking-widest text-zinc-500 hover:text-white transition-all"
              >
                Clear Settings
              </button>
              <button 
                onClick={forceTrigger}
                className="py-4 border border-yellow-900/30 bg-yellow-900/5 hover:bg-yellow-900/20 rounded-2xl text-[10px] font-black uppercase tracking-widest text-yellow-700 hover:text-yellow-500 transition-all"
              >
                Test Trigger
              </button>
            </div>
          </div>

          <div className="bg-red-950/10 border border-red-900/20 p-8 rounded-3xl flex gap-6 relative overflow-hidden group">
            <div className="absolute inset-0 bg-red-500/5 animate-pulse opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <ShieldAlert className="text-red-500 shrink-0 mt-1" size={24} />
            <div className="space-y-3">
              <h4 className="text-[12px] font-black text-red-500 uppercase tracking-widest">Security Disclosure</h4>
              <p className="text-[10px] text-zinc-600 leading-relaxed italic font-bold">
                By engaging AUTO-BUY, you authorize the DELTA.V environment to simulate on-chain routing. Ensure your wallet is pre-connected to PancakeSwap for zero-latency finalization.
              </p>
            </div>
          </div>
        </div>

        {/* Console / Monitoring Panel */}
        <div className="lg:col-span-8 flex flex-col gap-8">
          <div className="bg-black border border-zinc-800 rounded-[3rem] p-10 flex-1 flex flex-col min-h-[500px] shadow-2xl relative overflow-hidden">
            <div className="absolute bottom-0 right-0 p-8 opacity-5">
              <Terminal className="w-64 h-64 text-green-500" />
            </div>

            <div className="flex justify-between items-center mb-8">
              <h3 className="text-xs font-black uppercase tracking-[0.4em] text-zinc-500 flex items-center gap-4">
                <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-yellow-500 animate-pulse' : 'bg-zinc-800'} shadow-[0_0_10px_currentColor]`}></div>
                PROTOCOL_LOG_CONSOLE
              </h3>
              {triggered && (
                <div className="flex items-center gap-3 text-red-500 animate-bounce bg-red-500/10 px-4 py-2 rounded-full border border-red-500/20">
                  <BellRing size={16} />
                  <span className="text-[10px] font-black uppercase tracking-tighter">EXECUTION_SEQUENCE_LIVE</span>
                </div>
              )}
            </div>

            <div 
              ref={logContainerRef}
              className="flex-1 font-mono text-[12px] space-y-3 overflow-y-auto custom-scrollbar pr-6 text-zinc-500"
            >
              {logs.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center opacity-20 space-y-4">
                  <RefreshCcw size={48} className="animate-spin-slow" />
                  <div className="italic text-center">Protocol initialized.<br/>Establishing peer connection to BSC Node-7...</div>
                </div>
              )}
              {logs.map((log, i) => (
                <div 
                  key={i} 
                  className={`p-3 border-l-4 rounded-r-lg transition-all ${
                    log.includes('TARGET BREACHED') ? 'bg-red-500/10 border-red-500 text-red-400 font-black animate-pulse' : 
                    log.includes('OK') ? 'border-green-800 text-green-700 bg-green-500/5' :
                    log.includes('!!') ? 'border-yellow-800 text-yellow-700 bg-yellow-500/5' :
                    'border-zinc-800 bg-zinc-950/50'
                  }`}
                >
                  {log}
                </div>
              ))}
            </div>

            {triggered && (
              <div className="mt-10 animate-in slide-in-from-bottom-6 duration-700">
                <button 
                  onClick={() => window.open(PANCAKESWAP_URL, '_blank')}
                  className="w-full py-8 bg-yellow-500 text-black font-black text-2xl rounded-[2rem] flex items-center justify-center gap-6 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_50px_rgba(234,179,8,0.4)] border-b-[8px] border-yellow-700 active:border-b-0"
                >
                  <ExternalLink size={32} />
                  CONFIRM DEX TRANSACTION
                </button>
                <div className="text-center mt-4 text-[9px] text-zinc-600 font-black uppercase tracking-[0.3em] animate-pulse">
                  System awaiting manual finalization signature
                </div>
              </div>
            )}
          </div>
          
          {/* Hardware Stats Bar */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
             <div className="bg-zinc-950 p-8 rounded-[2rem] border border-zinc-900 flex items-center gap-6 group hover:border-yellow-500/20 transition-all shadow-xl">
                <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-yellow-500 group-hover:scale-110 transition-transform border border-zinc-800">
                  <RefreshCcw size={24} />
                </div>
                <div>
                   <div className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">Polling_Rate</div>
                   <div className="text-sm font-black text-white uppercase font-mono">5.000ms <span className="text-green-800 text-[10px]">ULTRA_FAST</span></div>
                </div>
             </div>
             <div className="bg-zinc-950 p-8 rounded-[2rem] border border-zinc-900 flex items-center gap-6 group hover:border-blue-500/20 transition-all shadow-xl">
                <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform border border-zinc-800">
                  <Play size={24} />
                </div>
                <div>
                   <div className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">Execution_Path</div>
                   <div className="text-sm font-black text-white uppercase font-mono italic">PancakeSwap_V2</div>
                </div>
             </div>
             <div className="bg-zinc-950 p-8 rounded-[2rem] border border-zinc-900 flex items-center gap-6 group hover:border-red-500/20 transition-all shadow-xl">
                <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-red-500 group-hover:scale-110 transition-transform border border-zinc-800">
                  <AlertCircle size={24} />
                </div>
                <div>
                   <div className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">Fail_Safety</div>
                   <div className="text-sm font-black text-white uppercase font-mono">Locked <span className="text-zinc-700 text-[10px]">AES-256</span></div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};
