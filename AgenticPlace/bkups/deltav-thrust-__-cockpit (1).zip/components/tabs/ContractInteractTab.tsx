
import React, { useState, useEffect } from 'react';
import { MOCK_ABI, THRUST_ADDRESS } from '../../constants';
import { Play, Eye, Terminal, Settings, ArrowRight, ShieldCheck, ShieldAlert, CheckSquare, Square, Lock, Unlock, TrendingDown, Bot, Anchor } from 'lucide-react';

export const ContractInteractTab: React.FC = () => {
  const [responses, setResponses] = useState<{[key: string]: string}>({});
  const [inputs, setInputs] = useState<{[key: string]: {[key: number]: string}}>({});
  const [logs, setLogs] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState<'all' | 'read' | 'write'>('all');
  
  // Pre-renounce checklist state
  const [checklist, setChecklist] = useState({
    feesFinalized: true,
    rebaseTuned: true,
    liquidityTargetSet: true,
    bridgeAuthenticated: false
  });

  const handleInputChange = (fnName: string, idx: number, val: string) => {
    setInputs(prev => ({
      ...prev,
      [fnName]: {
        ...(prev[fnName] || {}),
        [idx]: val
      }
    }));
  };

  const handleExecute = (fnName: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] CMD > EXECUTE: ${fnName}`, ...prev]);
    
    if (fnName === 'setFees') {
      addLog("FEE_RATCHET_PROTOCOL: Validating against 5% ceiling and 1% sustainability floor...");
    }

    setTimeout(() => {
      const fnDef = MOCK_ABI.find(f => f.name === fnName);
      const isView = fnDef?.stateMutability === 'view' || fnDef?.stateMutability === 'pure';
      
      if (isView) {
        let mockResult = "null";
        if (fnName === 'name') mockResult = "DeltaV THRUST";
        else if (fnName === 'symbol') mockResult = "THRUST";
        else if (fnName === 'decimals') mockResult = "18";
        else if (fnName === 'totalSupply') mockResult = "1,000,000,000";
        else if (fnName === 'autoRebase') mockResult = "true";
        else if (fnName === 'totalBuyFee') mockResult = "500 (5.0%)";
        else mockResult = "0x969F60Bfe17962E0f061B434596545C7b6Cd6Fc4";

        setResponses(prev => ({ ...prev, [fnName]: mockResult }));
        setLogs(prev => [`[${timestamp}] RES < ${mockResult}`, ...prev]);
      } else {
        const txHash = '0x' + Math.random().toString(16).slice(2, 42);
        setResponses(prev => ({ ...prev, [fnName]: `TX SUCCESS` }));
        setLogs(prev => [`[${timestamp}] NET < BROADCAST_COMPLETE: ${txHash.slice(0, 16)}...`, ...prev]);
      }
    }, 600);
  };

  const addLog = (msg: string) => {
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] SYS > ${msg}`, ...prev]);
  };

  const filteredAbi = MOCK_ABI.filter(fn => {
    if (activeCategory === 'all') return true;
    const isRead = fn.stateMutability === 'view' || fn.stateMutability === 'pure';
    return activeCategory === 'read' ? isRead : !isRead;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full animate-in fade-in slide-in-from-left-4 duration-500">
      <div className="lg:col-span-1 space-y-4">
        {/* Fee Ratchet HUD */}
        <div className="bg-zinc-950 border border-blue-900/40 p-6 rounded-[2rem] shadow-2xl relative overflow-hidden">
          <div className="absolute -top-4 -right-4 opacity-10">
            <TrendingDown size={80} className="text-blue-500" />
          </div>
          <h3 className="text-[10px] font-black uppercase mb-4 text-blue-600 tracking-[0.2em] flex items-center gap-2">
            <ShieldCheck size={12} /> Fee_Ratchet_System
          </h3>
          <div className="space-y-4">
             <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                <span className="text-[9px] text-zinc-500 uppercase font-black tracking-widest">Current_Ceiling</span>
                <span className="text-xs font-mono text-white">5.0%</span>
             </div>
             <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                <span className="text-[9px] text-zinc-500 uppercase font-black tracking-widest">Sustainability_Floor</span>
                <span className="text-xs font-mono text-orange-500">1.0%</span>
             </div>
             <div className="p-3 bg-orange-500/5 border border-orange-500/20 rounded-xl space-y-2">
               <div className="flex items-center gap-2 text-[8px] text-orange-400 font-black uppercase tracking-tighter">
                 <Bot size={10} /> Bot Protection Active
               </div>
               <p className="text-[8px] text-zinc-600 font-mono italic leading-tight">
                 Sustainability policy mandates a 1% floor for LP health. Total fee lowering capped at ratchet mechanics.
               </p>
             </div>
          </div>
        </div>

        {/* Renounce Readiness HUD */}
        <div className="bg-zinc-950 border border-yellow-900/40 p-5 rounded-[2rem] shadow-2xl relative overflow-hidden">
          <div className="absolute -top-4 -right-4 opacity-10">
            <ShieldAlert size={80} className="text-yellow-500" />
          </div>
          <h3 className="text-[10px] font-black uppercase mb-4 text-yellow-600 tracking-[0.2em] flex items-center gap-2">
            <Lock size={12} /> Renounce_Checklist
          </h3>
          <div className="space-y-3">
            {Object.entries(checklist).map(([key, val]) => (
              <div key={key} className="flex items-center justify-between group cursor-help">
                <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-tighter group-hover:text-zinc-300 transition-colors">
                  {key.replace(/([A-Z])/g, '_$1')}
                </span>
                {val ? <CheckSquare size={14} className="text-green-500" /> : <Square size={14} className="text-zinc-800" />}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-zinc-900/80 border border-green-900/30 p-4 rounded-[1.5rem]">
          <h3 className="text-[10px] font-bold uppercase mb-4 text-zinc-500 tracking-widest">Handshake Filter</h3>
          <div className="flex flex-col gap-2">
            {(['all', 'read', 'write'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`text-[10px] font-black uppercase py-2 px-4 rounded-xl text-left border transition-all ${
                  activeCategory === cat ? 'bg-green-500/10 border-green-500 text-green-500' : 'bg-transparent border-zinc-800 text-zinc-500 hover:border-zinc-700'
                }`}
              >
                {cat} MODULES
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="lg:col-span-2 overflow-y-auto pr-2 space-y-3 custom-scrollbar max-h-[75vh]">
        {filteredAbi.map((fn, i) => {
          const isView = fn.stateMutability === 'view' || fn.stateMutability === 'pure';
          return (
            <div key={i} className="bg-zinc-900/30 border border-zinc-800/60 p-5 rounded-2xl hover:border-green-900/50 transition-all group relative overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className={`w-2 h-2 rounded-full ${isView ? 'bg-blue-500' : 'bg-orange-500'} shadow-[0_0_8px_currentColor]`}></div>
                  <h3 className="text-xs font-black font-mono tracking-wider group-hover:text-green-400 transition-colors uppercase italic">{fn.name}</h3>
                </div>
                <button 
                  onClick={() => handleExecute(fn.name)}
                  className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${
                    isView 
                    ? 'bg-blue-900/20 text-blue-400 hover:bg-blue-500 hover:text-white border border-blue-500/30' 
                    : 'bg-orange-900/20 text-orange-400 hover:bg-orange-500 hover:text-black border border-orange-500/30 shadow-[0_0_15px_rgba(249,115,22,0.1)]'
                  }`}
                >
                  {isView ? <Eye size={12} /> : <Play size={12} />}
                  {isView ? 'READ' : 'WRITE'}
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-2">
                {fn.inputs.map((input, idx) => (
                  <div key={idx} className="flex flex-col gap-1.5">
                    <label className="text-[9px] text-zinc-600 font-mono uppercase tracking-tighter">
                      {input.name || `param_${idx}`} <span className="opacity-40">({input.type})</span>
                    </label>
                    <input 
                      type="text"
                      placeholder={`Enter ${input.type}...`}
                      className="bg-black/80 border border-zinc-800 text-green-500 font-mono text-[10px] p-2.5 rounded-lg focus:outline-none focus:border-green-900 transition-all"
                      onChange={(e) => handleInputChange(fn.name, idx, e.target.value)}
                    />
                  </div>
                ))}
              </div>

              {responses[fn.name] && (
                <div className="mt-3 p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-[10px] font-mono text-zinc-300 flex items-center justify-between animate-in slide-in-from-top-2">
                  <div className="flex items-center gap-3">
                    <ArrowRight size={12} className="text-green-500" />
                    <span className="opacity-50 uppercase italic font-bold">Protocol_Response:</span>
                    <span className="text-green-400">{responses[fn.name]}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="lg:col-span-1 flex flex-col gap-4">
        <div className="bg-black border border-zinc-900 rounded-[2rem] p-6 flex-1 flex flex-col overflow-hidden shadow-inner">
          <h4 className="text-[10px] font-black uppercase mb-6 text-zinc-700 flex items-center gap-3 tracking-[0.2em]">
            <Terminal size={14} className="text-green-900" /> SYSTEM_TERMINAL
          </h4>
          <div className="flex-1 overflow-y-auto font-mono text-[9px] text-zinc-500 custom-scrollbar leading-relaxed">
            {logs.length === 0 && <span className="opacity-10 italic">HANDSHAKE_PENDING...</span>}
            {logs.map((log, i) => (
              <div key={i} className={`mb-2 pb-2 border-b border-zinc-900/30 ${log.includes('CMD') ? 'text-zinc-600' : 'text-green-800/80 font-black'}`}>
                {log}
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-blue-950/10 border border-blue-900/20 p-6 rounded-[2rem]">
           <div className="flex items-center gap-2 text-blue-500 mb-2">
             <Anchor size={14} />
             <h4 className="text-[10px] font-black uppercase tracking-widest">Bridge Stability</h4>
           </div>
           <p className="text-[9px] text-zinc-600 italic leading-relaxed">
             Polygon and ARC bridge nodes are monitoring liquidity parity. Final ratchet signatures required for L2 deployment.
           </p>
        </div>
      </div>
    </div>
  );
};
