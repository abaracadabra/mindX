
import React from 'react';
import { Book, MessageSquare, Terminal, Star, Anchor, Rocket, Zap, Users, ShieldCheck, Gauge, Bot, Milestone } from 'lucide-react';

export const CaptainsLogTab: React.FC = () => {
  const logs = [
    {
      date: '2024-06-21',
      time: '18:45:00',
      author: 'CAPTAIN',
      category: 'STRATEGY',
      icon: <Bot size={24} />,
      message: 'Sustainability directive: We will maintain a 1% liquidity fee floor to ensure anti-bot protection and long-term protocol fuel. This is non-negotiable for fleet security.'
    },
    {
      date: '2024-06-21',
      time: '11:00:00',
      author: 'ENGINEER',
      category: 'PROTOCOL',
      icon: <ShieldCheck size={24} />,
      message: 'Fee Ratchet Protocol initialized. Global fee ceiling at 5.0%. 2026 Roadmap target established: 2% entry and exit fees upon multi-chain maturity.'
    },
    {
      date: '2024-06-20',
      time: '14:30:00',
      author: 'CAPTAIN',
      category: 'NAVIGATION',
      icon: <Rocket size={24} />,
      message: '400 holders confirmed. Preparing for Gate 1: 1,000 passengers. Data models suggest a 2.5x price correction as we reach this threshold. Jump engines warming.'
    },
    {
      date: '2024-06-19',
      time: '18:15:22',
      author: 'SYSTEM',
      category: 'GROWTH',
      icon: <Gauge size={24} />,
      message: 'Volume-Linked Growth module active. THRUST mass expanding proportionally to swap velocity. Supply rebases #1-1422 successfully calibrated for current trajectory.'
    },
    {
      date: '2024-06-18',
      time: '02:10:45',
      author: 'SYSTEM',
      category: 'REBASE',
      icon: <Zap size={24} />,
      message: 'Critical Rebase milestone cleared. Circulating mass adjusted for passenger stability. Symcryptosis theory validated through multi-node observation.'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12 animate-in fade-in zoom-in-95 duration-700 pb-20">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-3 px-6 py-2 bg-green-500/10 border border-green-500/20 rounded-full text-green-500 text-[10px] font-black tracking-[0.4em] uppercase">
          <Book size={14} /> Mission Data Stream
        </div>
        <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic">Captain's Log</h2>
        <p className="text-zinc-500 text-xs font-mono tracking-widest uppercase">The chronicled journey of DeltaV THRUST</p>
      </div>

      <div className="space-y-8">
        {logs.map((log, i) => (
          <div key={i} className="group relative flex gap-8">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-center text-green-500 group-hover:scale-110 transition-transform shadow-lg z-10">
                {log.icon}
              </div>
              <div className="flex-1 w-px bg-zinc-800 mt-4 group-last:bg-transparent"></div>
            </div>
            
            <div className="flex-1 bg-zinc-950/50 border border-zinc-900 p-8 rounded-[2rem] hover:border-green-500/30 transition-all shadow-xl space-y-4">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{log.author} // {log.category}</span>
                  <div className="text-xs font-mono text-zinc-300">STAR_DATE: {log.date} T {log.time}</div>
                </div>
                <div className="px-3 py-1 bg-zinc-900 rounded-md text-[8px] font-black text-zinc-600 border border-zinc-800 uppercase tracking-widest">Verified Log Entry</div>
              </div>
              <p className="text-sm md:text-base text-zinc-400 font-mono leading-relaxed italic">
                "{log.message}"
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-blue-950/10 border border-blue-900/20 p-10 rounded-[3rem] text-center space-y-6">
        <Milestone className="mx-auto text-blue-500" size={32} />
        <h3 className="text-xl font-black text-white uppercase tracking-widest">Mission Roadmap</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          <div className="p-4 bg-black/40 rounded-2xl border border-zinc-800">
            <div className="text-green-500 text-xs font-black uppercase mb-1">Gate 1</div>
            <div className="text-white font-mono text-lg">1k Holders</div>
            <div className="text-[9px] text-zinc-500 uppercase">2.5x Correction</div>
          </div>
          <div className="p-4 bg-black/40 rounded-2xl border border-zinc-800">
            <div className="text-blue-500 text-xs font-black uppercase mb-1">Bridge</div>
            <div className="text-white font-mono text-lg">L2 Nodes</div>
            <div className="text-[9px] text-zinc-500 uppercase">Polygon & ARC</div>
          </div>
          <div className="p-4 bg-black/40 rounded-2xl border border-zinc-800">
            <div className="text-red-500 text-xs font-black uppercase mb-1">Final Gate</div>
            <div className="text-white font-mono text-lg">10k Holders</div>
            <div className="text-[9px] text-zinc-500 uppercase">Vertical Spike</div>
          </div>
        </div>
        <p className="text-xs text-zinc-500 italic max-w-xl mx-auto">
          Currently at 412 passengers. Sustainability floor locked at 1% liquidity fee. Roadmap targets 2% entry/exit fees by 2026.
        </p>
      </div>
    </div>
  );
};
