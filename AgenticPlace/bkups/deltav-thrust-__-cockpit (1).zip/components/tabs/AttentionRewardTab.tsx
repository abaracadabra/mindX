
import React, { useState, useEffect } from 'react';
import { generateSnapshot, ThrustSnapshot } from '../../services/oracleService';
import { Heart, TrendingUp, Zap, Users, ShieldAlert } from 'lucide-react';

export const AttentionRewardTab: React.FC = () => {
  const [luvBalance, setLuvBalance] = useState(12450.32);
  const [earningsRate, setEarningsRate] = useState(0.42);
  const [thrustData, setThrustData] = useState<ThrustSnapshot | null>(null);
  
  useEffect(() => {
    const interval = setInterval(() => {
      const s = generateSnapshot();
      setThrustData(s);
      setLuvBalance(prev => prev + (Math.random() * 0.1));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const attentionCoefficient = 2.5; 
  const thrustPrice = thrustData?.priceUSD || 0.00001193;
  const luvUsdValue = thrustPrice * attentionCoefficient;

  return (
    <div className="space-y-6 animate-in zoom-in-95 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-zinc-900/80 border-b-2 border-red-900/50 p-6 rounded-lg group hover:bg-zinc-800/80 transition-all">
          <div className="flex items-center justify-between mb-4">
            <Heart className="text-red-500 animate-pulse" />
            <span className="text-[10px] bg-red-900/30 text-red-400 px-2 py-0.5 rounded tracking-tighter uppercase">LUV BALANCE</span>
          </div>
          <p className="text-2xl font-bold font-mono text-white tracking-tighter">{luvBalance.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
          <p className="text-[10px] text-zinc-500 mt-2 uppercase font-mono italic">≈ ${(luvBalance * luvUsdValue).toFixed(2)} USD value</p>
        </div>

        <div className="bg-zinc-900/80 border-b-2 border-yellow-900/50 p-6 rounded-lg group hover:bg-zinc-800/80 transition-all">
          <div className="flex items-center justify-between mb-4">
            <Zap className="text-yellow-500" />
            <span className="text-[10px] bg-yellow-900/30 text-yellow-400 px-2 py-0.5 rounded tracking-tighter uppercase">REWARD YIELD</span>
          </div>
          <p className="text-2xl font-bold font-mono text-white tracking-tighter">0.0235%</p>
          <p className="text-[10px] text-zinc-500 mt-2 uppercase font-mono italic">Per 15-Min Epoch</p>
        </div>

        <div className="bg-zinc-900/80 border-b-2 border-blue-900/50 p-6 rounded-lg group hover:bg-zinc-800/80 transition-all">
          <div className="flex items-center justify-between mb-4">
            <TrendingUp className="text-blue-500" />
            <span className="text-[10px] bg-blue-900/30 text-blue-400 px-2 py-0.5 rounded tracking-tighter uppercase">DELTA ATTN INDEX</span>
          </div>
          <p className="text-2xl font-bold font-mono text-white tracking-tighter">1.42x</p>
          <p className="text-[10px] text-zinc-500 mt-2 uppercase font-mono italic">Attention Velocity</p>
        </div>

        <div className="bg-zinc-900/80 border-b-2 border-green-900/50 p-6 rounded-lg group hover:bg-zinc-800/80 transition-all">
          <div className="flex items-center justify-between mb-4">
            <Users className="text-green-500" />
            <span className="text-[10px] bg-green-900/30 text-green-400 px-2 py-0.5 rounded tracking-tighter uppercase">ACTIVE NODES</span>
          </div>
          <p className="text-2xl font-bold font-mono text-white tracking-tighter">1,024</p>
          <p className="text-[10px] text-zinc-500 mt-2 uppercase font-mono italic">Verified Synchronized</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-zinc-900/30 border border-zinc-800 p-6 rounded-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Heart size={120} className="text-red-500 rotate-12" />
          </div>
          <h3 className="text-sm font-bold uppercase mb-8 flex items-center gap-2 text-zinc-200">
            <Zap size={16} className="text-yellow-500" /> Economic Synergies (LUV/THRUST)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center items-center">
            <div className="space-y-2 p-4 bg-black/40 rounded-lg border border-zinc-800">
              <div className="text-2xl font-mono text-green-500">${thrustPrice.toFixed(8)}</div>
              <div className="text-[9px] uppercase text-zinc-500 tracking-widest font-bold">THRUST Base (BSC)</div>
            </div>
            <div className="text-zinc-700 font-bold text-3xl">⊕</div>
            <div className="space-y-2 p-4 bg-black/40 rounded-lg border border-zinc-800">
              <div className="text-2xl font-mono text-red-500">2.50x</div>
              <div className="text-[9px] uppercase text-zinc-500 tracking-widest font-bold">Attention Multiplier</div>
            </div>
          </div>
          <div className="mt-10 pt-10 border-t border-zinc-800 flex justify-center">
            <div className="text-center group cursor-help">
              <div className="text-5xl font-mono font-bold text-white tracking-tighter group-hover:text-red-500 transition-colors">${luvUsdValue.toFixed(6)}</div>
              <div className="text-[10px] uppercase text-zinc-400 mt-4 tracking-[0.4em] font-bold">Implied LUV Unit Value</div>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900/50 border border-zinc-800 p-5 rounded-lg flex flex-col gap-4">
           <div className="flex items-center gap-2 text-yellow-500 mb-2">
             <ShieldAlert size={16} />
             <h4 className="text-[10px] font-bold uppercase">Attention Policy</h4>
           </div>
           <p className="text-[10px] text-zinc-500 leading-relaxed font-mono">
             Attention rewards are calculated based on your LUV balance relative to the DeltaV THRUST circulating supply. 
             Rebase events proportionally adjust LUV unit valuation but do not impact your total network percentage.
           </p>
           <div className="mt-4 p-3 bg-black/60 rounded border border-zinc-800 space-y-3">
              <div className="flex justify-between items-center text-[9px] font-mono uppercase">
                <span className="text-zinc-600">Max Fee Rate</span>
                <span>2,500 (25%)</span>
              </div>
              <div className="flex justify-between items-center text-[9px] font-mono uppercase">
                <span className="text-zinc-600">Fee Denominator</span>
                <span>10,000</span>
              </div>
              <div className="flex justify-between items-center text-[9px] font-mono uppercase">
                <span className="text-zinc-600">Yield Denominator</span>
                <span>10,000,000</span>
              </div>
           </div>
           <button className="mt-auto py-3 bg-red-900/20 border border-red-900/40 text-red-500 font-bold text-[10px] uppercase hover:bg-red-500 hover:text-white transition-all rounded">
             Claim Attention Yield
           </button>
        </div>
      </div>
    </div>
  );
};
