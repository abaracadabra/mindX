
import React, { useState } from 'react';
import { TruthOracleTab } from './tabs/TruthOracleTab';
import { LauncherTab } from './tabs/LauncherTab';
import { ContractInteractTab } from './tabs/ContractInteractTab';
import { AttentionRewardTab } from './tabs/AttentionRewardTab';
import { CaptainsLogTab } from './tabs/CaptainsLogTab';
import { VipControlsTab } from './tabs/VipControlsTab';
import { Shield, Radio, Terminal, Heart, Zap, Compass, Crown, Book } from 'lucide-react';

export const TabController: React.FC = () => {
  const [activeTab, setActiveTab] = useState('oracle');

  const tabs = [
    { id: 'oracle', label: 'SYMCRYPTOSIS.INDEX', icon: <Compass size={16} />, component: <TruthOracleTab /> },
    { id: 'interact', label: 'SYSTEM.CORE', icon: <Terminal size={16} />, component: <ContractInteractTab /> },
    { id: 'launch', label: 'BRIDGE.CONSTRUCTOR', icon: <Zap size={16} />, component: <LauncherTab /> },
    { id: 'attention', label: 'PASSENGER.CABIN', icon: <Heart size={16} />, component: <AttentionRewardTab /> },
    { id: 'vip', label: 'FLIGHT.MANEUVER', icon: <Crown size={16} className="text-yellow-500" />, component: <VipControlsTab /> },
    { id: 'log', label: 'CAPTAIN.LOG', icon: <Book size={16} />, component: <CaptainsLogTab /> },
  ];

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {/* Tab Navigation */}
      <div className="flex border-b border-green-900/30 bg-black/80 backdrop-blur-xl px-4 pt-4 sticky top-0 z-50">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`
              flex items-center gap-2 px-6 py-3 text-[10px] font-bold tracking-widest uppercase transition-all
              ${activeTab === tab.id 
                ? 'text-green-400 border-b-2 border-green-500 bg-green-500/5' 
                : 'text-zinc-600 hover:text-zinc-300 border-b-2 border-transparent'}
            `}
          >
            {tab.icon}
            <span className="hidden md:inline">{tab.label}</span>
          </button>
        ))}
        <div className="flex-1"></div>
        <div className="flex items-center gap-4 px-4 pb-2">
          <div className="flex flex-col items-end">
             <span className="text-[8px] text-zinc-500 uppercase">Flight Path</span>
             <span className="text-[10px] text-green-500 font-mono animate-pulse uppercase tracking-widest">Symcryptosis Active</span>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar bg-black">
        <div className="max-w-[1400px] mx-auto h-full">
           {tabs.find(t => t.id === activeTab)?.component}
        </div>
      </main>

      {/* Footer Status Bar */}
      <footer className="bg-black border-t border-zinc-900 px-6 py-2 flex items-center justify-between text-[9px] font-mono text-zinc-500 uppercase tracking-tighter">
        <div className="flex gap-6">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            PASSENGER_TRUST: VERIFIED
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_5px_#3b82f6]"></span>
            BRIDGE_STABILITY: 99.9%
          </div>
        </div>
        <div className="flex gap-6">
          <span className="text-yellow-600 font-bold tracking-widest">JOURNEY_MODE: ACTIVE</span>
          <span>LATENCY: 42ms</span>
          <span>© 2024 DeltaV THRUST // COCKPIT.ADM</span>
        </div>
      </footer>
    </div>
  );
};
