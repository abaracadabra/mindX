
import { OracleSnapshot } from '../types';

export interface ThrustSnapshot extends OracleSnapshot {
  liquidityBacking: number;
  circulatingSupply: number;
  rewardYield: number;
  holderCount: number;
  rebaseTotalCount: number;
  volumeGrowthFactor: number;
  currentFeeRate: number;
  pairAddress?: string;
  baseTokenSymbol?: string;
}

export function generateSnapshot(): ThrustSnapshot {
  // Base price target: $0.00005398
  const simulatedPrice = 0.00005398 + (Math.random() - 0.5) * 0.0000001;
  const simulatedVolume = 452180 + Math.floor(Math.random() * 8000);
  
  // Growth is tied to volume
  const growthFactor = (simulatedVolume / 450000) * 1.15;

  return {
    priceUSD: simulatedPrice,
    volume24h: simulatedVolume,
    liquidity: 25420000 + (Math.random() - 0.5) * 150000,
    timestamp: Date.now(),
    block: 31245000 + Math.floor(Math.random() * 100),
    deltaSinceLast: (Math.random() - 0.5) * 0.08,
    confirmed: true,
    liquidityBacking: 16.85 + (Math.random() - 0.5) * 0.15,
    circulatingSupply: 540230124 + (Math.random() - 0.5) * 500,
    rewardYield: 0.0235,
    holderCount: 412, // Starting around 400 as per mission brief
    rebaseTotalCount: 1422, // High rebase history
    volumeGrowthFactor: growthFactor,
    currentFeeRate: 5.0 // Initial 5% fee
  };
}

/**
 * Fetches real-time price and pair data from DexScreener API.
 */
export async function fetchLivePrice(): Promise<{
  priceUsd: number;
  liquidityUsd: number;
  volume24h: number;
  priceChange: number;
} | null> {
  try {
    const response = await fetch('https://api.dexscreener.com/latest/dex/pairs/bsc/0x762e1925Cc37Ac085dC81732113E0Eb1382C4D2B');
    if (!response.ok) return null;
    const data = await response.json();
    const pair = data.pair;
    if (!pair) return null;

    return {
      priceUsd: parseFloat(pair.priceUsd),
      liquidityUsd: pair.liquidity?.usd || 0,
      volume24h: pair.volume?.h24 || 0,
      priceChange: pair.priceChange?.h24 || 0
    };
  } catch (e) {
    console.error("Actual price connector failed:", e);
    return null;
  }
}
