
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import hljs from "highlight.js";

interface Message {
    text: string;
    sender: 'user' | 'ai';
}

const TOOLTIP_MAP: Record<string, string> = {
    // Commands
    "evolve": "Triggers a recursive update cycle to improve the agent's underlying logic and capabilities.",
    "deploy": "Orchestrates the instantiation of specialized sub-agents to handle complex multi-step tasks.",
    "introspect": "Generates a deep personality profile and operational persona for a specific intelligence role.",
    "mastermind_status": "Provides a high-level overview of current strategic objectives and historical operational data.",
    "show_agent_registry": "Retrieves the full list of active and dormant agents currently managed by the Coordinator.",
    "analyze_codebase": "Executes a multi-pass semantic analysis of the target source code for optimization and vulnerability detection.",
    "basegen": "Generates comprehensive Markdown documentation from raw source files or directories.",
    "id_list": "Lists all cryptographic identities and public keys currently managed by the identity substrate.",
    "id_create": "Mints a new unique cryptographic identity for a secure entity or agent.",
    "id_deprecate": "Safely removes and archives an identity, marking it as inactive in the registry.",
    "coord_query": "Direct communication channel to the Coordinator's central reasoning engine.",
    "coord_analyze": "Forces a system-wide self-diagnostic and contextual state assessment.",
    "coord_improve": "Requests a targeted optimization of a specific system component or agent.",
    "coord_backlog": "Displays the queue of pending system improvements and pending approvals.",
    "agent_create": "Spawns a new autonomous agent instance with specific configurations and constraints.",
    "agent_list": "Displays real-time status and metadata for all registered autonomous agents.",
    "help": "Displays the command reference and operational manual for this terminal.",
    
    // Keywords
    "PYTHAI": "The core mastermind entity of the mindX agency, specializing in high-level orchestration.",
    "mindX": "The Augmentic Intelligence agency responsible for the development of high-tier agentic systems.",
    "Augmentic Intelligence": "A state-of-the-art hybrid intelligence paradigm focusing on human-AI synergy.",
    "Coordinator": "The central processing node that manages agent lifecycles.",
    "IDManager": "The security layer responsible for managing agent identities.",
    "AgenticPlace": "The secure communication environment for mindX interface.",
    "Gemini": "The underlying large language model family powering the cognitive engines.",

    // Utility buttons
    "upload": "Upload local files or codebase snapshots for intelligence analysis.",
    "mode": "Switch between Creative, Precise, and Analytical operational modes.",
    "persona": "Reconfigure the active agent persona and linguistic profile.",
    "model": "Select the underlying cognitive architecture (Gemini 2.5/3.0 Series).",
    "agent": "Activate specialized prompt engineering agents for complex task drafting.",
    "terminal": "Toggle between chat-centric and full-screen terminal command mode.",
    "clear": "Flush current terminal session and re-stabilize connection.",

    // Message Actions
    "copy_msg": "Copy response text to your terminal clipboard.",
    "send_to": "Transfer this intelligence output to your prompt terminal.",
    "auto_send": "Re-transmit this response as a new directive (Auto-Run)."
};

const HELP_COMMAND_RESPONSE = `
As a mastermind AI, I can execute a range of directives.

### Core Commands
- **evolve <directive>**: Task Mastermind to EVOLVE its own codebase.
- **deploy <directive>**: Task AutoMINDX/Mastermind to DEPLOY new agents.
- **introspect <role>**: Generate a new persona for a given role.
- **mastermind_status**: Display Mastermind's objectives.
- **show_agent_registry**: Display active agents.
- **/clear**: Flush terminal history.
`;

const wrapKeywords = (text: string) => {
    let result = text;
    const keywords = ["PYTHAI", "mindX", "Augmentic Intelligence", "Coordinator", "IDManager", "AgenticPlace", "Gemini"];
    keywords.forEach(keyword => {
        const regex = new RegExp(`(?<!<[^>]*)\\b${keyword}\\b(?![^<]*>)`, 'g');
        result = result.replace(regex, `<span class="keyword-highlight" data-tooltip="${TOOLTIP_MAP[keyword]}">${keyword}</span>`);
    });
    return result;
};

const renderer = new marked.Renderer();

// Fix: Add code highlighting to renderer to resolve 'highlight' option error in newer marked versions
renderer.code = ({ text, lang }: any) => {
    const language = (lang && hljs.getLanguage(lang)) ? lang : 'plaintext';
    const highlighted = hljs.highlight(text, { language }).value;
    return `<pre><code class="hljs language-${language}">${highlighted}</code></pre>`;
};

renderer.strong = ({ text }: any) => {
    if (!text) return ''; 
    const commandText = text.replace(/&lt;/g, '<').replace(/&gt;/, '>');
    const baseCommand = commandText.split(' ')[0].toLowerCase();
    const tooltip = TOOLTIP_MAP[baseCommand] || "Execute this mastermind command.";
    return `<button class="command-button" data-command="${commandText}" data-tooltip="${tooltip}">${text}</button>`;
};

// Configure marked with custom renderer
marked.setOptions({
    renderer: renderer,
    gfm: true,
    breaks: true
});

const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { text: "Welcome to AgenticPlace. I am PYTHAI, a mastermind AI from mindX. Your wish is my mind command. Type `/help` for system directives.", sender: 'ai' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [tooltipContent, setTooltipContent] = useState<string | null>(null);
    const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
    
    // Response Window State
    const [dimensions, setDimensions] = useState({ width: 650, height: 550 });
    const [position, setPosition] = useState({ x: 100, y: 50 });
    
    // Input Window State
    const [inputPos, setInputPos] = useState({ x: 100, y: 620 });
    const [inputWidth, setInputWidth] = useState(650);

    const isResizing = useRef(false);
    const activeDrag = useRef<'response' | 'input' | null>(null);
    const dragOffset = useRef({ x: 0, y: 0 });
    
    const chatWindowRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);
    const appContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const h = Math.min(window.innerHeight * 0.65, 650);
        const w = Math.min(window.innerWidth * 0.55, 650);
        setDimensions({ width: w, height: h });
        const startX = (window.innerWidth - w) / 2;
        const startY = 80;
        setPosition({ x: startX, y: startY });
        setInputPos({ x: startX, y: startY + h + 15 });
        setInputWidth(w);
    }, []);

    const startDraggingResponse = useCallback((e: React.MouseEvent) => {
        if ((e.target as HTMLElement).closest('.logo-focus-area')) return;
        activeDrag.current = 'response';
        dragOffset.current = { x: e.clientX - position.x, y: e.clientY - position.y };
        document.body.style.cursor = 'grabbing';
    }, [position]);

    const startDraggingInput = useCallback((e: React.MouseEvent) => {
        if (e.target === inputRef.current || (e.target as HTMLElement).closest('.send-button') || (e.target as HTMLElement).closest('.util-btn')) return;
        activeDrag.current = 'input';
        dragOffset.current = { x: e.clientX - inputPos.x, y: e.clientY - inputPos.y };
        document.body.style.cursor = 'grabbing';
    }, [inputPos]);

    const startResizing = useCallback((e: React.MouseEvent) => {
        e.preventDefault();
        isResizing.current = true;
        document.body.style.cursor = 'nwse-resize';
    }, []);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (isResizing.current) {
                const rect = appContainerRef.current?.getBoundingClientRect();
                if (rect) {
                    const newWidth = Math.max(400, e.clientX - rect.left);
                    const newHeight = Math.max(300, e.clientY - rect.top);
                    setDimensions({ width: newWidth, height: newHeight });
                }
            } else if (activeDrag.current === 'response') {
                setPosition({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
            } else if (activeDrag.current === 'input') {
                setInputPos({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
            }
        };
        const handleMouseUp = () => {
            isResizing.current = false;
            activeDrag.current = null;
            document.body.style.cursor = '';
        };
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, []);

    useEffect(() => {
        if (chatWindowRef.current) {
            chatWindowRef.current.scrollTop = chatWindowRef.current.scrollHeight;
        }
    }, [messages]);
    
    useEffect(() => {
        const textarea = inputRef.current;
        if (textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = `${textarea.scrollHeight}px`;
        }
    }, [input]);

    useEffect(() => {
        const handleMouseMoveTooltip = (e: MouseEvent) => {
            const target = (e.target as HTMLElement).closest('[data-tooltip]');
            if (target instanceof HTMLElement) {
                const tooltip = target.getAttribute('data-tooltip');
                if (tooltip) {
                    setTooltipContent(tooltip);
                    setTooltipPos({ x: e.clientX, y: e.clientY + 20 });
                }
            } else {
                setTooltipContent(null);
            }
        };
        document.addEventListener('mousemove', handleMouseMoveTooltip);
        return () => {
            document.removeEventListener('mousemove', handleMouseMoveTooltip);
        };
    }, []);

    const handleSendMessage = async (textToSend: string = input) => {
        const trimmedInput = textToSend.trim();
        if (!trimmedInput || isLoading) return;
        
        if (trimmedInput.toLowerCase() === '/clear') {
            setMessages([{ text: "Terminal history purged. Connection stable.", sender: 'ai' }]);
            setInput('');
            return;
        }

        const userMessage: Message = { text: trimmedInput, sender: 'user' };
        if (trimmedInput.toLowerCase() === '/help' || trimmedInput.toLowerCase() === 'help') {
            setMessages(prev => [...prev, userMessage, { text: HELP_COMMAND_RESPONSE, sender: 'ai' }]);
            setInput('');
            return;
        }
        
        setMessages(prev => [...prev, userMessage, { text: '', sender: 'ai' }]);
        setInput('');
        setIsLoading(true);
        
        try {
            // Fix: Create a new GoogleGenAI instance right before making an API call
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const stream = await ai.models.generateContentStream({
                // Fix: Use 'gemini-3-pro-preview' for complex mastermind reasoning tasks
                model: 'gemini-3-pro-preview',
                contents: trimmedInput,
                config: {
                   systemInstruction: "You are PYTHAI, a mastermind AI from mindX. Tone is authoritative yet seamless. Use Markdown. Use bold for **commands**. Output complex code blocks and tables where relevant.",
                }
            });
            let fullResponse = '';
            for await (const chunk of stream) {
                // Fix: Access response.text directly (property, not a function)
                fullResponse += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1].text = fullResponse;
                    return newMessages;
                });
            }
        } catch (error) {
            setMessages(prev => {
                 const newMessages = [...prev];
                 newMessages[newMessages.length - 1].text = "Signal lost. Terminal re-synchronization recommended.";
                 return newMessages;
            });
        } finally {
            setIsLoading(false);
        }
    };

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
        setTooltipContent("COPIED TO CLIPBOARD");
        setTimeout(() => setTooltipContent(null), 1500);
    };

    const sendToInput = (text: string, autoSend: boolean = false) => {
        if (autoSend) {
            handleSendMessage(text);
        } else {
            setInput(text);
            inputRef.current?.focus();
        }
    };

    const clearTerminal = () => {
        handleSendMessage('/clear');
    };

    const renderMessage = (msg: Message, index: number) => {
        if (msg.sender === 'user') return msg.text;
        if (isLoading && index === messages.length - 1 && msg.text === '') {
            return <div className="loading-indicator"><span className="dot"></span><span className="dot"></span><span className="dot"></span></div>;
        }
        let html = marked.parse(msg.text) as string;
        html = wrapKeywords(html);
        return (
            <div className="ai-content-wrapper">
                <div dangerouslySetInnerHTML={{ __html: html }} />
                <div className="message-actions">
                    <button className="msg-action-btn" onClick={() => copyToClipboard(msg.text)} data-tooltip={TOOLTIP_MAP["copy_msg"]}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                    </button>
                    <button className="msg-action-btn" onClick={() => sendToInput(msg.text, false)} data-tooltip={TOOLTIP_MAP["send_to"]}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
                    </button>
                    <button className="msg-action-btn pulse-action" onClick={() => sendToInput(msg.text, true)} data-tooltip={TOOLTIP_MAP["auto_send"]}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                    </button>
                </div>
            </div>
        );
    };

    return (
        <div className="workspace">
            {/* Movable & Resizable Response Window */}
            <div 
                ref={appContainerRef} 
                className="app-container response-window"
                style={{ 
                    width: `${dimensions.width}px`, 
                    height: `${dimensions.height}px`,
                    left: `${position.x}px`,
                    top: `${position.y}px`,
                    position: 'fixed'
                }}
            >
                <header className="app-header" onMouseDown={startDraggingResponse}>
                    <div className="logo-focus-area" data-tooltip={TOOLTIP_MAP["Augmentic Intelligence"]}>
                        <img 
                            src="https://agenticplace.pythai.net/agentaitrans.png" 
                            alt="Face" 
                            className="app-logo" 
                        />
                        <div className="logo-aura"></div>
                        <div className="scan-line"></div>
                    </div>
                    <div className="header-text">
                        <div className="header-top-row">
                            <h1>AgenticPlace</h1>
                            <div className="core-status">
                                <span className="status-dot"></span> CORE: {isLoading ? 'PROCESSING' : 'STABLE'}
                            </div>
                        </div>
                        <p className="subtitle">PYTHAI // mindX <span className="keyword-highlight" data-tooltip={TOOLTIP_MAP["Augmentic Intelligence"]}>Augmentic Intelligence</span></p>
                    </div>
                    <div className="drag-hint">MOVE TERMINAL</div>
                </header>
                
                <main ref={chatWindowRef} className="chat-window">
                    {messages.map((msg, index) => (
                        <div key={index} className={`message ${msg.sender}-message`}>
                            {renderMessage(msg, index)}
                        </div>
                    ))}
                </main>

                <div className="resize-handle" onMouseDown={startResizing}>
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 22h-2v-2h2v2zm0-4h-2v-2h2v2zm-4 4h-2v-2h2v2zm0-4h-2v-2h2v2zm-4 4h-2v-2h2v2z"/></svg>
                </div>
            </div>

            {/* Movable Input Window */}
            <div 
                className="input-window movable-input"
                onMouseDown={startDraggingInput}
                style={{
                    left: `${inputPos.x}px`,
                    top: `${inputPos.y}px`,
                    width: `${inputWidth}px`,
                    position: 'fixed'
                }}
            >
                <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="message-form">
                    <textarea
                        ref={inputRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
                        className="message-input semi-transparent"
                        placeholder="TRANSMIT DIRECTIVE..."
                        rows={1}
                        disabled={isLoading}
                    />
                    <button type="submit" className="send-button" disabled={!input.trim() || isLoading}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                    </button>
                </form>
                
                <div className="input-utilities">
                    <button className="util-btn" data-tooltip={TOOLTIP_MAP["upload"]}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    </button>
                    <button className="util-btn" data-tooltip={TOOLTIP_MAP["mode"]}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                    </button>
                    <button className="util-btn" data-tooltip={TOOLTIP_MAP["persona"]}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </button>
                    <button className="util-btn" data-tooltip={TOOLTIP_MAP["model"]}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="15" x2="23" y2="15"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="15" x2="4" y2="15"/></svg>
                    </button>
                    <button className="util-btn" data-tooltip={TOOLTIP_MAP["agent"]}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a10 10 0 1 0 10 10H12V2z"/><path d="M12 12L2.1 12.1"/><path d="M12 12l9.9-0.1"/><path d="M12 12l-5-5"/><path d="M12 12l5 5"/></svg>
                    </button>
                    <button className="util-btn" data-tooltip={TOOLTIP_MAP["clear"]} onClick={clearTerminal}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                    </button>
                    <button className="util-btn" data-tooltip={TOOLTIP_MAP["terminal"]}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>
                    </button>
                </div>

                <div className="input-drag-hint">MOVE INPUT</div>
            </div>

            {/* Global Tooltip Element */}
            {tooltipContent && (
                <div className="master-tooltip" style={{ left: `${tooltipPos.x}px`, top: `${tooltipPos.y}px` }}>
                    {tooltipContent}
                </div>
            )}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
