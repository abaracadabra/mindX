// This script loads environment variables from a .env file
// before starting the main application.

const root = document.getElementById('root');

const renderError = (title, message) => {
    root.innerHTML = `
        <div style="
            font-family: 'Inter', sans-serif;
            color: #ff3333;
            background-color: #1a0000;
            border: 1px solid #ff3333;
            border-radius: 8px;
            padding: 2rem;
            margin: 2rem;
            text-align: left;
        ">
            <h2 style="margin-top: 0;">${title}</h2>
            <p>${message}</p>
            <p>Please create a file named <code>.env</code> in the root of your project with the following content:</p>
            <pre style="
                background-color: #333;
                padding: 1rem;
                border-radius: 4px;
                white-space: pre-wrap;
                word-wrap: break-word;
                color: #fff;
            ">API_KEY=YOUR_GEMINI_API_KEY_HERE</pre>
        </div>
    `;
};

async function loadEnvAndStartApp() {
    try {
        const response = await fetch('/.env');
        if (!response.ok) {
            throw new Error('Failed to fetch .env file.');
        }

        const text = await response.text();
        const env = {};
        text.split('\n').forEach(line => {
            const trimmedLine = line.trim();
            if (trimmedLine && !trimmedLine.startsWith('#')) {
                const [key, ...valueParts] = trimmedLine.split('=');
                const value = valueParts.join('=').trim();
                if (key) {
                    env[key.trim()] = value;
                }
            }
        });
        
        // Polyfill process.env for browser environment
        window.process = {
            env: env,
        };

        if (!window.process.env.API_KEY || window.process.env.API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
            renderError(
                'API Key Missing',
                'Your Gemini API key is not configured in the .env file.'
            );
            return;
        }

        // Dynamically import the main app script
        await import('./index.tsx');

    } catch (error) {
        console.error('Error loading configuration:', error);
        renderError(
             'Configuration Error',
            `Could not load configuration. The <code>.env</code> file may be missing or inaccessible.`
        );
    }
}

loadEnvAndStartApp();
