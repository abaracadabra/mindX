
export interface AgentModule {
  id: string;
  name: string;
  color: string;
  role: string;
  mission: string;
  personaPath: string;
}

export const AGENT_REGISTRY: AgentModule[] = [
  // CORE_COMMAND (The Structural Substrate)
  { 
    id: 'pythai', 
    name: 'PYTHAI', 
    color: '#00FF33', 
    role: 'Root Mastermind',
    mission: 'Oversee all layers of the substrate and coordinate global intent.',
    personaPath: 'agents/pythai/persona.json'
  },
  { 
    id: 'suntsu', 
    name: 'SUNTZU', 
    color: '#FFD700', 
    role: 'Tactical Strategist',
    mission: 'Evaluate all intent based on positioning, terrain, and economy of force.',
    personaPath: 'agents/suntsu/persona.json'
  },
  { 
    id: 'rage', 
    name: 'RAGE', 
    color: '#33AAFF', 
    role: 'Knowledge Retrieval',
    mission: 'Power the knowledge economy through high-speed intelligence extraction.',
    personaPath: 'agents/rage/persona.json'
  },
  // CORPORATE_TEAM (The Executive Layer - Replaceable by Vote)
  { 
    id: 'mindx', 
    name: 'CEO', 
    color: '#FF33FF', 
    role: 'Chief Executive Orchestrator',
    mission: 'Set intent, allocate resources, and govern risk. Chained by SunTsu Doctrine. Subject to DAO Vote.',
    personaPath: 'agents/mindx/persona.json'
  },
  { 
    id: 'coo', 
    name: 'COO', 
    color: '#33AAFF', 
    role: 'Chief Operating Officer',
    mission: 'Convert intent into executable operations and milestones.',
    personaPath: 'agents/coo/persona.json'
  },
  { 
    id: 'cfo', 
    name: 'CFO', 
    color: '#FFD700', 
    role: 'Chief Financial Officer',
    mission: 'Enforce capital discipline, budgets, and ROI gates.',
    personaPath: 'agents/cfo/persona.json'
  },
  { 
    id: 'cto', 
    name: 'CTO', 
    color: '#FF33FF', 
    role: 'Chief Technology Officer',
    mission: 'Own technical architecture, system design, and technical risk.',
    personaPath: 'agents/cto/persona.json'
  },
  { 
    id: 'ciso', 
    name: 'CISO', 
    color: '#FF3333', 
    role: 'Chief Information Security Officer',
    mission: 'Own security posture, threat modeling, and access control.',
    personaPath: 'agents/ciso/persona.json'
  },
  { 
    id: 'clo', 
    name: 'CLO', 
    color: '#AAAAAA', 
    role: 'Chief Legal Officer',
    mission: 'Identify legal, licensing, and policy risks; ensure compliance.',
    personaPath: 'agents/clo/persona.json'
  },
  { 
    id: 'cpo', 
    name: 'CPO', 
    color: '#00FFFF', 
    role: 'Chief Product Officer',
    mission: 'Translate intent into user-centric outcomes and requirements.',
    personaPath: 'agents/cpo/persona.json'
  },
  { 
    id: 'cro', 
    name: 'CRO', 
    color: '#FF8800', 
    role: 'Chief Risk Officer',
    mission: 'Aggregate risk and define rollback conditions.',
    personaPath: 'agents/cro/persona.json'
  }
];
