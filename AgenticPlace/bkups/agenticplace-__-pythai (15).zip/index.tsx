
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import { epistemic, LogEntry } from './epistemic.ts';
import { Visualizer, DAOBoard, PersonaSelector } from './SubstrateComponents.tsx';
import { AGENT_REGISTRY } from './agents/registry.ts';

interface Message {
    text: string;
    sender: 'user' | 'ai';
    persona?: string;
    timestamp: string;
    status?: string;
}

interface ResponseWindowState {
    id: string; 
    text: string;
    x: number;
    y: number;
    w: number;
    h: number;
    isDecoupled: boolean;
    isCollapsed: boolean;
    zIndex: number;
}

const SECTIONS = [
    { name: "CORE_COMMAND", id: 0 },
    { name: "BOARD_CONSENSUS", id: 1 },
    { name: "SUBSTRATE_TELEMETRY", id: 2 }
];

const CEO_LOGIC_FLOW = `EXECUTIVE_LAYER v0.4.5
│
├─► 1. CEO DEFINES INTENT
│     ├─ Strategy (Replaceable by Vote)
│     ├─ Chained by SunTsu Gate
│     └─ Resource Requests
│
├─► 2. SUNTZU DOCTRINE GATE
│     ├─ Terrain check (Art of War)
│     ├─ Economy of force
│     └─ FAIL ──► REVISE INTENT
│
├─► 3. DEPLOY CORPORATE TEAM
│     ├─ COO (Operations)
│     ├─ CFO (Finance)
│     ├─ CTO (Tech)
│     ├─ CISO (Security)
│     ├─ CLO (Legal)
│     ├─ CPO (Product)
│     └─ CRO (Risk)
│
├─► 4. DAO CONSENSUS
│     ├─ 2/3 Supermajority Check
│     └─ PASS ──► EXECUTE
│
└─► 5. MANDATED ACTION`;

const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { 
            text: "**OPENMINDX // BRIDGE** active. Protocol v0.4.5 initialized. CEO layer chained by SunTsu. Executive substrate connected.", 
            sender: 'ai', 
            persona: 'pythai',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: 'BRIDGE_STABLE'
        }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [activePersona, setActivePersona] = useState('pythai');
    const [currentSection, setCurrentSection] = useState(0);
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [responseWindows, setResponseWindows] = useState<ResponseWindowState[]>([]);
    const [maxZIndex, setMaxZIndex] = useState(8001);
    const [tabPosition, setTabPosition] = useState<'top' | 'bottom'>('bottom');

    const [consolePos, setConsolePos] = useState({ x: 60, y: 380 });
    const [consoleSize, setConsoleSize] = useState({ w: 740, h: 420 });

    const draggingConsole = useRef(false);
    const draggingResponseId = useRef<string | null>(null);
    const resizingConsole = useRef(false);
    const dragOffset = useRef({ x: 0, y: 0 });
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    const copyText = (text: string) => {
        navigator.clipboard.writeText(text).catch(err => console.error('Copy failed: ', err));
    };

    const handleSendMessage = async (text: string) => {
        if (!text.trim() || isLoading) return;
        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        setMessages(prev => [...prev, { text, sender: 'user', timestamp, status: 'DIRECTIVE' }]);
        setInputValue('');
        
        const exists = responseWindows.find(w => w.id === activePersona);
        if (!exists) togglePersonaWindow(activePersona);

        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const agent = AGENT_REGISTRY.find(a => a.id === activePersona);
            const instruction = `You are ${agent?.name}. ROLE: ${agent?.role}. MISSION: ${agent?.mission}.
            Executive Protocol: ${CEO_LOGIC_FLOW}
            Respond with high-tier executive precision. Maintain shortcodes (CFO, COO, etc). Reflect status: CEO is doctrinal but replaceable.`;
            
            const response = await ai.models.generateContent({
                model: 'gemini-3-pro-preview',
                contents: text,
                config: { 
                    systemInstruction: instruction,
                    thinkingConfig: { thinkingBudget: 16000 }
                }
            });

            const aiText = response.text || "NO_DATA";
            const aiTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            
            setMessages(prev => [...prev, { text: aiText, sender: 'ai', persona: activePersona, timestamp: aiTimestamp, status: 'VERIFIED' }]);
            setResponseWindows(prev => prev.map(w => 
                w.id === activePersona 
                ? { ...w, text: aiText, isCollapsed: false, zIndex: maxZIndex + 1 } 
                : w
            ));
            setMaxZIndex(prev => prev + 1);
            epistemic.logEvent("AgentResponse", `[${agent?.name || activePersona.toUpperCase()}] broadcast confirmed.`);
        } catch (e: any) {
            setMessages(prev => [...prev, { text: "CRITICAL_LOGIC_FAULT: " + e.message, sender: 'ai', persona: activePersona, timestamp, status: 'ERROR' }]);
        } finally {
            setIsLoading(false);
        }
    };

    const togglePersonaWindow = (pid: string) => {
        setActivePersona(pid);
        setResponseWindows(prev => {
            const exists = prev.find(w => w.id === pid);
            if (exists) {
                return prev.map(w => w.id === pid ? { ...w, zIndex: maxZIndex + 1 } : w);
            } else {
                const count = prev.length;
                const agent = AGENT_REGISTRY.find(a => a.id === pid);
                return [...prev, {
                    id: pid,
                    text: `**${agent?.name || pid.toUpperCase()}** SUBSTRATE_LINK_STABLE.`,
                    x: consolePos.x + 50 + (count * 30),
                    y: consolePos.y + 100 + (count * 30),
                    w: 640,
                    h: 320,
                    isDecoupled: false,
                    isCollapsed: false,
                    zIndex: maxZIndex + 1
                }];
            }
        });
        setMaxZIndex(prev => prev + 1);
    };

    const closeResponseWindow = (pid: string) => {
        setResponseWindows(prev => prev.filter(w => w.id !== pid));
    };

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (draggingConsole.current) {
                setConsolePos({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
            } else if (resizingConsole.current) {
                setConsoleSize({ w: Math.max(500, e.clientX - consolePos.x), h: Math.max(300, e.clientY - consolePos.y) });
            } else if (draggingResponseId.current) {
                const rid = draggingResponseId.current;
                setResponseWindows(prev => prev.map(w => {
                    if (w.id !== rid) return w;
                    const newX = e.clientX - dragOffset.current.x;
                    const newY = e.clientY - dragOffset.current.y;
                    
                    const stackX = consolePos.x + 50;
                    const stackY = consolePos.y + 100;
                    const distance = Math.sqrt(Math.pow(newX - stackX, 2) + Math.pow(newY - stackY, 2));
                    const shouldDock = distance < 30;

                    return { ...w, x: newX, y: newY, isDecoupled: !shouldDock };
                }));
            }
        };
        const handleMouseUp = () => {
            draggingConsole.current = false;
            draggingResponseId.current = null;
            resizingConsole.current = false;
        };
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [consolePos, consoleSize, responseWindows]);

    useEffect(() => {
        const unsub = epistemic.subscribe(() => setLogs(epistemic.getLogs()));
        return unsub;
    }, []);

    const toggleTabPosition = () => {
        setTabPosition(prev => prev === 'top' ? 'bottom' : 'top');
    };

    const consoleSelector = <PersonaSelector current={activePersona} onSelect={togglePersonaWindow} />;
    const consoleInput = (
        <div className="input-wrap">
            <textarea 
                value={inputValue} 
                onChange={(e) => setInputValue(e.target.value)} 
                placeholder={`INSTRUCT_${activePersona.toUpperCase()} ...`} 
                onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(inputValue); } }} 
            />
            <div className="console-toolkit">
                <button className="transmit-btn" onClick={() => handleSendMessage(inputValue)}>TRANSMIT_DATA</button>
            </div>
        </div>
    );

    return (
        <div className="app-container">
            <div className="master-backdrop-substrate"></div>
            <div className="logic-map-bg">{CEO_LOGIC_FLOW}</div>

            <header className="substrate-header">
                <div className="header-left">
                    <div className="avatar-wrapper">
                        <img src="https://agenticplace.pythai.net/agentaitrans.png" className="avatar-img" alt="pythai" />
                    </div>
                    <div className="logo-group">
                        <div className="logo-main"><span className="text-accent">PYTHAI</span> MASTERMIND</div>
                        <div className="logo-sub">// EXECUTIVE_ORCHESTRATOR_v0.4.5</div>
                    </div>
                </div>
                <nav className="header-nav">
                    {SECTIONS.map(s => (
                        <button 
                            key={s.id} 
                            className={`nav-btn ${currentSection === s.id ? 'active' : ''}`}
                            onClick={() => setCurrentSection(s.id)}
                        >
                            {s.name}
                        </button>
                    ))}
                </nav>
            </header>

            <main className="workspace" style={{ transform: `translateY(-${currentSection * 100}vh)` }}>
                <section className="section-container">
                    <div className="main-grid-layout">
                        <div className="grid-left feed-module">
                            <div className="feed-header"><span className="header-title">NEURAL_FEED_STREAM</span></div>
                            <div className="chat-area">
                                {messages.map((m, i) => (
                                    <div key={i} className={`message ${m.sender}`}>
                                        <div className="m-tag">{m.sender === 'user' ? 'ROOT_USER' : m.persona?.toUpperCase()}</div>
                                        <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(m.text) as string }} />
                                    </div>
                                ))}
                                {isLoading && <div className="message ai"><div className="dots-pulse">TRANSMITTING...</div></div>}
                                <div ref={chatEndRef} />
                            </div>
                        </div>
                        <div className="grid-right glass-module">
                            <Visualizer />
                        </div>
                    </div>

                    <div className="master-console-floating" style={{ left: consolePos.x, top: consolePos.y, width: consoleSize.w, height: consoleSize.h }}>
                        <div className="console-handle" onMouseDown={(e) => { draggingConsole.current = true; dragOffset.current = { x: e.clientX - consolePos.x, y: e.clientY - consolePos.y }; }}>
                            <div className="handle-left">
                                <div className="status-dot-active"></div>
                                <span className="handle-text">PYTHAI // COMMAND_CENTER</span>
                            </div>
                            <div className="handle-actions">
                                <button className="action-btn-header" title="Toggle Tab Position" onClick={(e) => { e.stopPropagation(); toggleTabPosition(); }}>
                                    {tabPosition === 'top' ? '▼' : '▲'} LAYOUT
                                </button>
                                <span style={{ opacity: 0.3, margin: '0 5px' }}>|</span>
                                <span>•••</span>
                            </div>
                        </div>
                        <div className="console-body">
                            {tabPosition === 'top' && consoleSelector}
                            {consoleInput}
                            {tabPosition === 'bottom' && consoleSelector}
                        </div>
                        <div className="console-resize-handle" onMouseDown={() => resizingConsole.current = true}></div>
                    </div>

                    {responseWindows.map((rw, index) => {
                        const finalX = rw.isDecoupled ? rw.x : consolePos.x + 40 + (index * 20);
                        const finalY = rw.isDecoupled ? rw.y : consolePos.y - 200 - (index * 40);
                        const agent = AGENT_REGISTRY.find(a => a.id === rw.id);
                        
                        return (
                            <div 
                                key={rw.id} 
                                className={`response-window-floating ${rw.isDecoupled ? 'decoupled' : 'docked'} ${activePersona === rw.id ? 'active-focus' : ''}`} 
                                style={{ left: finalX, top: finalY, width: rw.w, height: rw.isCollapsed ? 'auto' : rw.h, zIndex: rw.zIndex, position: 'fixed' }}
                                onMouseDown={() => {
                                    setResponseWindows(prev => prev.map(w => w.id === rw.id ? { ...w, zIndex: maxZIndex + 1 } : w));
                                    setMaxZIndex(prev => prev + 1);
                                    setActivePersona(rw.id);
                                }}
                            >
                                <div className="response-handle" onMouseDown={(e) => { draggingResponseId.current = rw.id; dragOffset.current = { x: e.clientX - finalX, y: e.clientY - finalY }; }}>
                                    <div className="handle-left"><span className="handle-text">{(agent?.name || rw.id).toUpperCase()} // OUTPUT</span></div>
                                    <div className="handle-actions">
                                        <button className="action-btn" onClick={() => copyText(rw.text)}>COPY</button>
                                        <button className="action-btn" onClick={() => setResponseWindows(p => p.map(w => w.id === rw.id ? {...w, isCollapsed: !w.isCollapsed} : w))}>{rw.isCollapsed ? 'MAX' : 'MIN'}</button>
                                        <button className="action-btn close-btn" onClick={() => closeResponseWindow(rw.id)}>✕</button>
                                    </div>
                                </div>
                                {!rw.isCollapsed && (
                                    <div className="response-content-area">
                                        <div className="markdown-content" dangerouslySetInnerHTML={{ __html: marked.parse(rw.text) as string }} />
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </section>

                <section className="section-container">
                    <div className="consensus-module-full glass-module">
                        <div className="module-header">EXECUTIVE_CONSENSUS_GRID</div>
                        <DAOBoard />
                    </div>
                </section>

                <section className="section-container">
                    <div className="logs-module-full glass-module">
                        <div className="module-header">SUBSTRATE_TELEMETRY</div>
                        <div className="logs-scroll">
                            {logs.map((l, i) => (
                                <div key={i} className="log-line">
                                    <span className="l-time">[{l.timestamp.split('T')[1].slice(0,8)}]</span>
                                    <span className="l-type">{l.eventType}</span>
                                    <span className="l-msg">{l.message}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
            </main>
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
