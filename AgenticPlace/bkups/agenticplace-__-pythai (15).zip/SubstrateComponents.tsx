
import React, { useState, useEffect } from 'react';
import { epistemic } from './epistemic.ts';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import { AGENT_REGISTRY, AgentModule } from './agents/registry.ts';

export const PersonaSelector = ({ current, onSelect }: { current: string, onSelect: (id: string) => void }) => {
  const [activeTab, setActiveTab] = useState<'core' | 'soldiers'>('core');
  
  // PYTHAI, SUNTZU, RAGE are Core (Structural)
  // CEO and the Seven Soldiers are Corporate Team (Executive)
  const core = AGENT_REGISTRY.filter(a => ['pythai', 'suntsu', 'rage'].includes(a.id));
  const soldiers = AGENT_REGISTRY.filter(a => !['pythai', 'suntsu', 'rage'].includes(a.id));

  return (
    <div className="persona-nav-container">
      <div className="persona-tab-header">
        <button 
          className={`tab-toggle ${activeTab === 'core' ? 'active' : ''}`} 
          onClick={() => setActiveTab('core')}
        >
          CORE_COMMAND
        </button>
        <button 
          className={`tab-toggle ${activeTab === 'soldiers' ? 'active' : ''}`} 
          onClick={() => setActiveTab('soldiers')}
        >
          CORPORATE_TEAM
        </button>
      </div>
      <div className="persona-selector-wrap">
        {(activeTab === 'core' ? core : soldiers).map(p => (
          <button 
            key={p.id} 
            className={`persona-btn ${current === p.id ? 'active' : ''}`}
            onClick={() => onSelect(p.id)}
            style={{ '--p-color': p.color } as any}
          >
            <div className="p-dot"></div>
            <span className="p-label">{p.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export const Visualizer = () => {
  const [axis, setAxis] = useState({ x: true, y: true, z: false });
  const [load, setLoad] = useState(32);

  useEffect(() => {
    const interval = setInterval(() => {
      setLoad(prev => {
        const drift = (Math.random() * 6 - 3);
        const next = Math.max(10, Math.min(98, prev + drift));
        return next;
      });
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const getAnimation = () => {
    const parts = [];
    const speed = 20;
    if (axis.x) parts.push(`rotX ${speed}s linear infinite`);
    if (axis.y) parts.push(`rotY ${speed * 1.5}s linear infinite`);
    if (axis.z) parts.push(`rotZ ${speed * 0.8}s linear infinite`);
    return parts.length === 0 ? 'none' : parts.join(', ');
  };

  return (
    <div className="viz-module-container" style={{ display: 'flex', flexDirection: 'column', gap: '20px', height: '100%' }}>
      <div className="viz-viewport" style={{ flexGrow: 1, position: 'relative' }}>
        <div className="viz-glow-core" style={{ 
          transform: `scale(${1 + load/150})`, 
          opacity: load/120,
          background: load > 85 ? 'rgba(255, 51, 51, 0.4)' : 'rgba(0, 255, 51, 0.4)'
        }}></div>
        <div className="viz-box" style={{ animation: getAnimation() }}>
          <div className="box-face face-front">MASTERMIND</div>
          <div className="box-face face-back">mindX</div>
          <div className="box-face face-right">ALPHA</div>
          <div className="box-face face-left">ROOT</div>
          <div className="box-face face-top">PYTHAI</div>
          <div className="box-face face-bottom">CORE</div>
        </div>
      </div>
      <div className="viz-telemetry glass-panel">
        <div className="tele-item">
          <span className="t-label" style={{ opacity: 0.6, fontSize: '9px', fontWeight: 900 }}>NEURAL_LOAD_STATE</span>
          <span className="t-value" style={{ color: load > 85 ? '#ff3333' : '#00ff33', fontWeight: 900, fontSize: '10px' }}>{load.toFixed(1)}%</span>
        </div>
        <div className="load-bar" style={{ height: '3px', background: 'rgba(255,255,255,0.05)', borderRadius: '2px', overflow: 'hidden' }}>
          <div className="load-fill" style={{ width: `${load}%`, height: '100%', background: load > 85 ? '#ff3333' : '#00ff33', boxShadow: `0 0 10px ${load > 85 ? '#ff3333' : '#00ff33'}` }}></div>
        </div>
        <div className="control-group axes" style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
          <button className={`action-btn ${axis.x ? 'active' : ''}`} onClick={() => setAxis(a => ({...a, x: !a.x}))} style={{ color: axis.x ? '#00ff33' : '' }}>ROT_X</button>
          <button className={`action-btn ${axis.y ? 'active' : ''}`} onClick={() => setAxis(a => ({...a, y: !a.y}))} style={{ color: axis.y ? '#00ff33' : '' }}>ROT_Y</button>
          <button className={`action-btn ${axis.z ? 'active' : ''}`} onClick={() => setAxis(a => ({...a, z: !a.z}))} style={{ color: axis.z ? '#00ff33' : '' }}>ROT_Z</button>
        </div>
      </div>
    </div>
  );
};

const SOLDIERS = [
  { id: "CEO", name: "Executive", color: "#FF33FF" },
  { id: "COO", name: "Operations", color: "#33AAFF" },
  { id: "CFO", name: "Finance", color: "#FFD700" },
  { id: "CTO", name: "Technology", color: "#FF33FF" },
  { id: "CISO", name: "Security", color: "#FF3333" },
  { id: "CLO", name: "Legal", color: "#AAAAAA" },
  { id: "CPO", name: "Product", color: "#00FFFF" },
  { id: "CRO", name: "Risk", color: "#FF8800" }
];

export const DAOBoard = () => {
  const [positions, setPositions] = useState<Record<string, 'pool' | 'approved' | 'rejected'>>(
    Object.fromEntries(SOLDIERS.map(s => [s.id, 'pool']))
  );
  const [protocolResult, setProtocolResult] = useState<string>("");
  const [executing, setExecuting] = useState(false);

  const onDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData("agentId", id);
  };
  const onDrop = (e: React.DragEvent, zone: 'pool' | 'approved' | 'rejected') => {
    const id = e.dataTransfer.getData("agentId");
    if (positions[id] !== zone) setPositions(prev => ({ ...prev, [id]: zone }));
  };

  const executeProtocol = async () => {
    if (executing) return;
    setExecuting(true);
    const approved = SOLDIERS.filter(s => positions[s.id] === 'approved').map(s => s.id);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `DAO Board State Update. Approved Soldiers: ${approved.length}/8. Status: ${approved.length >= 6 ? 'SUPERMAJORITY_ACHIEVED' : 'QUORUM_PENDING'}.`
      });
      setProtocolResult(response.text || "NO_DATA");
      epistemic.logEvent("ConsensusCalculated", `Calculated result: ${approved.length}/8 approval.`);
    } catch (e) {
      setProtocolResult("PROTOCOL_ERROR_DETECTED");
    } finally {
      setExecuting(false);
    }
  };

  const approvedCount = Object.values(positions).filter(v => v === 'approved').length;
  const isConsensus = approvedCount >= 6; // Adjusted for 8 board members (CEO + 7)

  return (
    <div className={`dao-substrate ${isConsensus ? 'consensus-active' : ''}`} style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div className="dao-zones" style={{ flexGrow: 1 }}>
        <div className="drop-zone reject" onDragOver={e => e.preventDefault()} onDrop={e => onDrop(e, 'rejected')}>
          <label>REJECT_PROTOCOLS</label>
          <div className="zone-content">
            {SOLDIERS.filter(s => positions[s.id] === 'rejected').map(s => (
              <div key={s.id} draggable onDragStart={e => onDragStart(e, s.id)} className="soldier-token" style={{ '--s-color': s.color } as any}>{s.id}</div>
            ))}
          </div>
        </div>
        <div className="drop-zone pool" onDragOver={e => e.preventDefault()} onDrop={e => onDrop(e, 'pool')}>
          <label>BOARD_POOL</label>
          <div className="zone-content">
            {SOLDIERS.filter(s => positions[s.id] === 'pool').map(s => (
              <div key={s.id} draggable onDragStart={e => onDragStart(e, s.id)} className="soldier-token" style={{ '--s-color': s.color } as any}>{s.id}</div>
            ))}
          </div>
        </div>
        <div className="drop-zone approve" onDragOver={e => e.preventDefault()} onDrop={e => onDrop(e, 'approved')}>
          <label>AUTHORIZE_OPERATIONS</label>
          <div className="zone-content">
            {SOLDIERS.filter(s => positions[s.id] === 'approved').map(s => (
              <div key={s.id} draggable onDragStart={e => onDragStart(e, s.id)} className="soldier-token" style={{ '--s-color': s.color } as any}>{s.id}</div>
            ))}
          </div>
        </div>
      </div>
      <div className="executive-view-panel" style={{ padding: '20px', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
          <button className="execute-btn transmit-btn" onClick={executeProtocol} disabled={executing} style={{ width: '100%' }}>
            {executing ? 'CALCULATING...' : 'EXECUTE_CONSENSUS_LOGIC'}
          </button>
          {protocolResult && (
            <div className="protocol-result-scroll" style={{ marginTop: '15px', maxHeight: '120px', overflowY: 'auto' }}>
              <div className="markdown-content" style={{ fontSize: '11px' }} dangerouslySetInnerHTML={{ __html: marked.parse(protocolResult) as string }} />
            </div>
          )}
      </div>
    </div>
  );
};
