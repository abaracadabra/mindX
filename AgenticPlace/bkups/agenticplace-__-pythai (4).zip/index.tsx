
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";
import hljs from "highlight.js";

interface Message {
    text: string;
    sender: 'user' | 'ai';
}

interface InputBuffer {
    id: string;
    value: string;
}

const TOOLTIP_MAP: Record<string, string> = {
    "PYTHAI": "The core mastermind entity of the mindX agency.",
    "Augmentic Intelligence": "A hybrid intelligence paradigm focusing on human-AI synergy.",
    "home": "Restore all modules to the central stabilization zone.",
    "relink": "Snap all decoupled modules back into the master stack.",
    "diagnostics": "Real-time substrate metrics and link spider.",
    "decouple": "Press and hold to detach this module from the neural stack.",
    "spider": "Access Professor-Codephreak builds and gpt.pythai.net assets."
};

const renderer = new marked.Renderer();
renderer.code = (token: any) => {
    const text = token.text || '';
    const lang = token.lang || '';
    const language = (lang && hljs.getLanguage(lang)) ? lang : 'plaintext';
    const highlighted = hljs.highlight(text, { language }).value;
    return `<pre><code class="hljs language-${language}">${highlighted}</code></pre>`;
};
renderer.strong = (token: any) => {
    const text = token.text;
    if (!text || typeof text !== 'string') return ''; 
    return `<button class="command-button">${text}</button>`;
};
marked.setOptions({ renderer, gfm: true, breaks: true });

const wrapKeywords = (text: any) => {
    if (typeof text !== 'string') return '';
    let result = text;
    const keywords = ["PYTHAI", "mindX", "Augmentic Intelligence", "Coordinator", "AgenticPlace"];
    keywords.forEach(keyword => {
        const regex = new RegExp(`(?<!<[^>]*)\\b${keyword}\\b(?![^<]*>)`, 'g');
        result = result.replace(regex, `<span class="keyword-highlight" data-tooltip="${TOOLTIP_MAP[keyword] || ''}">${keyword}</span>`);
    });
    return result;
};

const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { text: "Neural link established. I am **PYTHAI**. Modular substrate initialized. Use the connectors to decouple interface blocks.", sender: 'ai' }
    ]);
    const [inputBuffers, setInputBuffers] = useState<InputBuffer[]>([{ id: 'init', value: '' }]);
    const [isLoading, setIsLoading] = useState(false);
    const [tooltipContent, setTooltipContent] = useState<string | null>(null);
    const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

    // Module Positions & States
    const [respPos, setRespPos] = useState({ x: 0, y: 0 });
    const [inputPos, setInputPos] = useState({ x: 0, y: 0 });
    const [diagPos, setDiagPos] = useState({ x: 0, y: 0 });
    
    const [isInputDecoupled, setIsInputDecoupled] = useState(false);
    const [isDiagDecoupled, setIsDiagDecoupled] = useState(false);
    const [devBarOpen, setDevBarOpen] = useState(true);
    
    const [dimensions, setDimensions] = useState({ width: 680, height: 400 });
    const [diagnostics, setDiagnostics] = useState({ 
        ip: 'DETECTING...', 
        os: navigator.platform, 
        browser: navigator.userAgent.split(' ').pop() || 'Unknown',
        load: 12, 
        mem: 45 
    });

    const activeDrag = useRef<string | null>(null);
    const dragOffset = useRef({ x: 0, y: 0 });
    const longPressTimer = useRef<number | null>(null);
    const chatWindowRef = useRef<HTMLDivElement>(null);

    // Initial Centering
    useEffect(() => {
        const w = Math.min(window.innerWidth * 0.9, 680);
        const h = Math.min(window.innerHeight * 0.4, 400);
        setDimensions({ width: w, height: h });

        const startX = (window.innerWidth - w) / 2;
        const startY = 100;

        setRespPos({ x: startX, y: startY });
        setInputPos({ x: startX, y: startY + h + 100 }); // Estimating stack
        setDiagPos({ x: startX, y: startY + h + 250 });
        
        // Auto-fetch IP
        fetch('https://api.ipify.org?format=json')
            .then(res => res.json())
            .then(data => setDiagnostics(d => ({ ...d, ip: data.ip })))
            .catch(() => setDiagnostics(d => ({ ...d, ip: '127.0.0.1' })));
            
        const interval = setInterval(() => {
            setDiagnostics(d => ({ 
                ...d, 
                load: Math.floor(Math.random() * 20) + 5, 
                mem: Math.floor(Math.random() * 10) + 40 
            }));
        }, 4000);
        return () => clearInterval(interval);
    }, []);

    const resetAllPositions = useCallback(() => {
        const w = dimensions.width;
        const startX = (window.innerWidth - w) / 2;
        const startY = 80;
        
        setRespPos({ x: startX, y: startY });
        setInputPos({ x: startX, y: startY + dimensions.height + 95 });
        setDiagPos({ x: startX, y: startY + dimensions.height + 265 });
        
        setIsInputDecoupled(false);
        setIsDiagDecoupled(false);
    }, [dimensions]);

    const handleMouseDown = (e: React.MouseEvent, module: string) => {
        if ((e.target as HTMLElement).closest('.message-input') || (e.target as HTMLElement).closest('button')) return;
        
        activeDrag.current = module;
        const currentPos = module === 'resp' ? respPos : (module === 'input' ? inputPos : diagPos);
        dragOffset.current = { x: e.clientX - currentPos.x, y: e.clientY - currentPos.y };
        
        // Long Press Logic to Decouple
        longPressTimer.current = window.setTimeout(() => {
            if (module === 'input' && !isInputDecoupled) setIsInputDecoupled(true);
            if (module === 'diag' && !isDiagDecoupled) setIsDiagDecoupled(true);
            document.body.classList.add('is-decoupling');
        }, 500);

        document.body.style.cursor = 'grabbing';
    };

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (!activeDrag.current) return;
            
            // If we move too much, cancel the long press
            if (longPressTimer.current) {
                window.clearTimeout(longPressTimer.current);
                longPressTimer.current = null;
            }

            const newX = e.clientX - dragOffset.current.x;
            const newY = e.clientY - dragOffset.current.y;

            if (activeDrag.current === 'resp') {
                const dx = newX - respPos.x;
                const dy = newY - respPos.y;
                setRespPos({ x: newX, y: newY });
                
                // If linked, move others
                if (!isInputDecoupled) setInputPos(p => ({ x: p.x + dx, y: p.y + dy }));
                if (!isDiagDecoupled) setDiagPos(p => ({ x: p.x + dx, y: p.y + dy }));
            } else if (activeDrag.current === 'input') {
                setInputPos({ x: newX, y: newY });
            } else if (activeDrag.current === 'diag') {
                setDiagPos({ x: newX, y: newY });
            }
        };

        const handleMouseUp = () => {
            activeDrag.current = null;
            if (longPressTimer.current) window.clearTimeout(longPressTimer.current);
            document.body.style.cursor = '';
            document.body.classList.remove('is-decoupling');
        };

        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [respPos, isInputDecoupled, isDiagDecoupled]);

    const handleSendMessage = async (textToSend: string, bufferId?: string) => {
        if (!textToSend.trim() || isLoading) return;
        setMessages(prev => [...prev, { text: textToSend, sender: 'user' }, { text: '', sender: 'ai' }]);
        setInputBuffers(prev => prev.map(b => b.id === bufferId ? { ...b, value: '' } : b));
        setIsLoading(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const stream = await ai.models.generateContentStream({
                model: 'gemini-3-pro-preview',
                contents: textToSend,
                config: { systemInstruction: "You are PYTHAI. Mastermind AI. Decisive and concise." }
            });
            let full = '';
            for await (const chunk of stream) {
                full += chunk.text;
                setMessages(prev => {
                    const next = [...prev];
                    next[next.length - 1].text = full;
                    return next;
                });
            }
        } catch (e) {
            setMessages(prev => [...prev.slice(0, -1), { text: "Signal corrupted. Check API connection.", sender: 'ai' }]);
        } finally {
            setIsLoading(false);
        }
    };

    const updateBuffer = (id: string, val: string) => {
        setInputBuffers(prev => prev.map(b => b.id === id ? { ...b, value: val } : b));
    };

    return (
        <div className="workspace">
            {/* RESPONSE MODULE */}
            <div 
                className={`module response-module ${!isInputDecoupled ? 'stacked-top' : ''}`}
                style={{ left: respPos.x, top: respPos.y, width: dimensions.width }}
                onMouseDown={(e) => handleMouseDown(e, 'resp')}
            >
                <header className="module-header">
                    <div className="title-area">
                        <img src="https://agenticplace.pythai.net/agentaitrans.png" className="mini-logo" />
                        <div className="meta">
                            <h1>PYTHAI // AgenticPlace</h1>
                            <div className="title-buttons">
                                <button onClick={resetAllPositions} data-tooltip={TOOLTIP_MAP.home}>HOME</button>
                                <button onClick={resetAllPositions} data-tooltip={TOOLTIP_MAP.relink}>RELINK</button>
                                <button onClick={() => setDevBarOpen(!devBarOpen)}>DEV</button>
                            </div>
                        </div>
                    </div>
                </header>
                <main ref={chatWindowRef} className="chat-area" style={{ height: dimensions.height }}>
                    {messages.map((m, i) => (
                        <div key={i} className={`message ${m.sender}`}>
                            <div dangerouslySetInnerHTML={{ __html: wrapKeywords(marked.parse(m.text)) }} />
                        </div>
                    ))}
                </main>
                {!isInputDecoupled && <div className="connector-node-visual" data-tooltip={TOOLTIP_MAP.decouple}></div>}
            </div>

            {/* INPUT MODULE */}
            <div 
                className={`module input-module ${isInputDecoupled ? 'decoupled' : 'linked'}`}
                style={{ left: inputPos.x, top: inputPos.y, width: dimensions.width }}
                onMouseDown={(e) => handleMouseDown(e, 'input')}
            >
                <div className="module-handle">DIRECTIVE TRANSMITTER</div>
                <div className="buffer-list">
                    {inputBuffers.map((b, i) => (
                        <form key={b.id} onSubmit={(e) => { e.preventDefault(); handleSendMessage(b.value, b.id); }} className="input-row">
                            <textarea 
                                value={b.value} 
                                onChange={(e) => updateBuffer(b.id, e.target.value)}
                                placeholder={`BUFFER_${i + 1} Ready...`}
                                rows={1}
                            />
                            <button type="submit" disabled={isLoading}>SEND</button>
                        </form>
                    ))}
                </div>
                <div className="input-footer">
                    <button className="plus-btn" onClick={() => setInputBuffers([...inputBuffers, { id: Math.random().toString(), value: '' }])}>+</button>
                    <button onClick={() => setMessages([{ text: "History purged.", sender: 'ai' }])}>FLUSH</button>
                </div>
                {!isDiagDecoupled && <div className="connector-node-visual lower" data-tooltip={TOOLTIP_MAP.decouple}></div>}
            </div>

            {/* DIAGNOSTICS MODULE */}
            {devBarOpen && (
                <div 
                    className={`module diag-module ${isDiagDecoupled ? 'decoupled' : 'linked'}`}
                    style={{ left: diagPos.x, top: diagPos.y, width: dimensions.width }}
                    onMouseDown={(e) => handleMouseDown(e, 'diag')}
                >
                    <div className="module-handle">MACHINE_DIAGNOSTICS // SUBSTRATE</div>
                    <div className="diag-content">
                        <div className="diag-section main-stats">
                            <div><label>IPADDR:</label> <span>{diagnostics.ip}</span></div>
                            <div><label>PLATFORM:</label> <span>{diagnostics.os}</span></div>
                            <div><label>SUBSTRATE:</label> <span>{diagnostics.browser}</span></div>
                        </div>
                        <div className="diag-section meters">
                            <div className="meter-row">
                                <label>LOAD</label>
                                <div className="meter"><div className="fill" style={{ width: `${diagnostics.load}%` }}></div></div>
                                <span>{diagnostics.load}%</span>
                            </div>
                            <div className="meter-row">
                                <label>MEM</label>
                                <div className="meter"><div className="fill" style={{ width: `${diagnostics.mem}%` }}></div></div>
                                <span>{diagnostics.mem}%</span>
                            </div>
                        </div>
                        <div className="diag-section spider">
                            <label>LINK SPIDER</label>
                            <div className="spider-web">
                                <a href="https://github.com/Professor-Codephreak" target="_blank">GITHUB_BUILDS</a>
                                <a href="https://gpt.pythai.net" target="_blank">GPT_TEAM</a>
                                <a href="https://agenticplace.pythai.net" target="_blank">AGENTIC_NODE</a>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {tooltipContent && (
                <div className="master-tooltip" style={{ left: tooltipPos.x, top: tooltipPos.y }}>
                    {tooltipContent}
                </div>
            )}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
