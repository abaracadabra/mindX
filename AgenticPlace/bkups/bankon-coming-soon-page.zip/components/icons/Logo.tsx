import React from 'react';

interface IconProps {
  className?: string;
}

export const Logo: React.FC<IconProps> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className}
    aria-hidden="true"
  >
    <path d="M12 2L4 7v2h16V7l-8-5zM4 10v10h16V10H4zm2 2h2v6H6v-6zm5 0h2v6h-2v-6zm5 0h2v6h-2v-6z"></path>
  </svg>
);
