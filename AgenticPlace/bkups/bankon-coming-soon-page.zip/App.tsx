import React, { useState } from 'react';
import { Logo } from './components/icons/Logo';
import { FacebookIcon } from './components/icons/FacebookIcon';
import { TwitterIcon } from './components/icons/TwitterIcon';
import { LinkedInIcon } from './components/icons/LinkedInIcon';
import { InstagramIcon } from './components/icons/InstagramIcon';

const App: React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [isError, setIsError] = useState<boolean>(false);

  const handleSignup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setMessage('Please enter a valid email address.');
      setIsError(true);
      return;
    }
    
    // In a real app, you would send this email to your backend.
    // For this demo, we'll just show a success message.
    setMessage(`Thank you! We've received your email: ${email}. We'll be in touch!`);
    setIsError(false);
    setEmail('');
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 font-['Roboto',_sans-serif] text-gray-800">
      <header className="py-6 px-4 sm:px-6 lg:px-8 bg-white/80 backdrop-blur-sm sticky top-0 z-10 border-b border-gray-200">
        <div className="container mx-auto flex items-center justify-center sm:justify-start">
          <div className="flex items-center gap-3">
            <Logo className="h-10 w-10 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">BankOn</h1>
          </div>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center text-center py-12 md:py-24">
        <section className="hero max-w-3xl mb-12 md:mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4 leading-tight">
            Revolutionizing Banking for the Modern World.
          </h2>
          <p className="text-lg md:text-xl text-gray-600 mb-8">
            Get ready for a smarter, simpler, and more secure way to manage your finances. Our launch is just around the corner.
          </p>
        </section>

        <section className="signup w-full max-w-lg mb-12 md:mb-16 bg-white p-8 rounded-2xl shadow-lg border border-gray-200">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Stay Updated!</h3>
          <p className="text-gray-600 mb-6">
            Be the first to know when we launch and get exclusive early access.
          </p>
          <form onSubmit={handleSignup} className="flex flex-col sm:flex-row gap-4">
            <input 
              type="email" 
              id="email" 
              name="email" 
              placeholder="Your Email Address" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-grow px-4 py-3 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200"
              required 
            />
            <button 
              type="submit"
              className="bg-blue-600 text-white font-bold px-6 py-3 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200 transform hover:scale-105"
            >
              Notify Me
            </button>
          </form>
          {message && (
            <div 
              className={`mt-4 text-sm ${isError ? 'text-red-600' : 'text-green-600'}`}
            >
              {message}
            </div>
          )}
        </section>

        <section className="social w-full max-w-lg">
          <p className="text-gray-600 mb-4">Follow us for updates and sneak peeks!</p>
          <div className="flex justify-center items-center gap-6">
            <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="text-gray-500 hover:text-blue-600 transition duration-200">
              <FacebookIcon className="h-8 w-8" />
            </a>
            <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Twitter" className="text-gray-500 hover:text-blue-500 transition duration-200">
              <TwitterIcon className="h-8 w-8" />
            </a>
            <a href="#" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="text-gray-500 hover:text-blue-700 transition duration-200">
              <LinkedInIcon className="h-8 w-8" />
            </a>
            <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-gray-500 hover:text-pink-500 transition duration-200">
              <InstagramIcon className="h-8 w-8" />
            </a>
          </div>
        </section>
      </main>

      <footer className="w-full py-6 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} BankOn. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
