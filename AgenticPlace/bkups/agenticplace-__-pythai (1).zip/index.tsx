
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { marked } from "marked";

interface Message {
    text: string;
    sender: 'user' | 'ai';
}

const TOOLTIP_MAP: Record<string, string> = {
    // Commands
    "evolve": "Triggers a recursive update cycle to improve the agent's underlying logic and capabilities.",
    "deploy": "Orchestrates the instantiation of specialized sub-agents to handle complex multi-step tasks.",
    "introspect": "Generates a deep personality profile and operational persona for a specific intelligence role.",
    "mastermind_status": "Provides a high-level overview of current strategic objectives and historical operational data.",
    "show_agent_registry": "Retrieves the full list of active and dormant agents currently managed by the Coordinator.",
    "analyze_codebase": "Executes a multi-pass semantic analysis of the target source code for optimization and vulnerability detection.",
    "basegen": "Generates comprehensive Markdown documentation from raw source files or directories.",
    "id_list": "Lists all cryptographic identities and public keys currently managed by the identity substrate.",
    "id_create": "Mints a new unique cryptographic identity for a secure entity or agent.",
    "id_deprecate": "Safely removes and archives an identity, marking it as inactive in the registry.",
    "coord_query": "Direct communication channel to the Coordinator's central reasoning engine.",
    "coord_analyze": "Forces a system-wide self-diagnostic and contextual state assessment.",
    "coord_improve": "Requests a targeted optimization of a specific system component or agent.",
    "coord_backlog": "Displays the queue of pending system improvements and pending approvals.",
    "agent_create": "Spawns a new autonomous agent instance with specific configurations and constraints.",
    "agent_list": "Displays real-time status and metadata for all registered autonomous agents.",
    "help": "Displays the command reference and operational manual for this terminal.",
    
    // Keywords
    "PYTHAI": "The core mastermind entity of the mindX agency, specializing in high-level orchestration.",
    "mindX": "The Augmentic Intelligence agency responsible for the development of high-tier agentic systems.",
    "Augmentic Intelligence": "A state-of-the-art hybrid intelligence paradigm focusing on human-AI synergy.",
    "Coordinator": "The central processing node that manages agent lifecycles.",
    "IDManager": "The security layer responsible for managing agent identities.",
    "AgenticPlace": "The secure communication environment for mindX interface.",
    "Gemini": "The underlying large language model family powering the cognitive engines."
};

const HELP_COMMAND_RESPONSE = `
As a mastermind AI, I can execute a range of directives.

### Core Commands
- **evolve <directive>**: Task Mastermind to EVOLVE its own codebase.
- **deploy <directive>**: Task AutoMINDX/Mastermind to DEPLOY new agents.
- **introspect <role>**: Generate a new persona for a given role.
- **mastermind_status**: Display Mastermind's objectives.
- **show_agent_registry**: Display active agents.
`;

const wrapKeywords = (text: string) => {
    let result = text;
    const keywords = ["PYTHAI", "mindX", "Augmentic Intelligence", "Coordinator", "IDManager", "AgenticPlace", "Gemini"];
    keywords.forEach(keyword => {
        const regex = new RegExp(`(?<!<[^>]*)\\b${keyword}\\b(?![^<]*>)`, 'g');
        result = result.replace(regex, `<span class="keyword-highlight" data-tooltip="${TOOLTIP_MAP[keyword]}">${keyword}</span>`);
    });
    return result;
};

const renderer = new marked.Renderer();
renderer.strong = ({ text }: any) => {
    if (!text) return ''; 
    const commandText = text.replace(/&lt;/g, '<').replace(/&gt;/, '>');
    const baseCommand = commandText.split(' ')[0].toLowerCase();
    const tooltip = TOOLTIP_MAP[baseCommand] || "Execute this mastermind command.";
    return `<button class="command-button" data-command="${commandText}" data-tooltip="${tooltip}">${text}</button>`;
};

marked.use({ gfm: true, breaks: true, renderer });

const App = () => {
    const [messages, setMessages] = useState<Message[]>([
        { text: "Welcome to AgenticPlace. I am PYTHAI, a mastermind AI from mindX. Your wish is my mind command. Type `/help` for system directives.", sender: 'ai' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [tooltipContent, setTooltipContent] = useState<string | null>(null);
    const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
    
    // Response Window State
    const [dimensions, setDimensions] = useState({ width: 650, height: 550 });
    const [position, setPosition] = useState({ x: 100, y: 50 });
    
    // Input Window State
    const [inputPos, setInputPos] = useState({ x: 100, y: 620 });
    const [inputWidth, setInputWidth] = useState(650);

    const isResizing = useRef(false);
    const activeDrag = useRef<'response' | 'input' | null>(null);
    const dragOffset = useRef({ x: 0, y: 0 });
    
    const chatWindowRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);
    const appContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const h = Math.min(window.innerHeight * 0.65, 650);
        const w = Math.min(window.innerWidth * 0.55, 650);
        setDimensions({ width: w, height: h });
        const startX = (window.innerWidth - w) / 2;
        const startY = 80;
        setPosition({ x: startX, y: startY });
        setInputPos({ x: startX, y: startY + h + 15 });
        setInputWidth(w);
    }, []);

    const startDraggingResponse = useCallback((e: React.MouseEvent) => {
        if ((e.target as HTMLElement).closest('.logo-focus-area')) return;
        activeDrag.current = 'response';
        dragOffset.current = { x: e.clientX - position.x, y: e.clientY - position.y };
        document.body.style.cursor = 'grabbing';
    }, [position]);

    const startDraggingInput = useCallback((e: React.MouseEvent) => {
        if (e.target === inputRef.current || (e.target as HTMLElement).closest('.send-button')) return;
        activeDrag.current = 'input';
        dragOffset.current = { x: e.clientX - inputPos.x, y: e.clientY - inputPos.y };
        document.body.style.cursor = 'grabbing';
    }, [inputPos]);

    const startResizing = useCallback((e: React.MouseEvent) => {
        e.preventDefault();
        isResizing.current = true;
        document.body.style.cursor = 'nwse-resize';
    }, []);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (isResizing.current) {
                const rect = appContainerRef.current?.getBoundingClientRect();
                if (rect) {
                    const newWidth = Math.max(400, e.clientX - rect.left);
                    const newHeight = Math.max(300, e.clientY - rect.top);
                    setDimensions({ width: newWidth, height: newHeight });
                }
            } else if (activeDrag.current === 'response') {
                setPosition({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
            } else if (activeDrag.current === 'input') {
                setInputPos({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
            }
        };
        const handleMouseUp = () => {
            isResizing.current = false;
            activeDrag.current = null;
            document.body.style.cursor = '';
        };
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, []);

    useEffect(() => {
        if (chatWindowRef.current) {
            chatWindowRef.current.scrollTop = chatWindowRef.current.scrollHeight;
        }
    }, [messages]);
    
    useEffect(() => {
        const textarea = inputRef.current;
        if (textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = `${textarea.scrollHeight}px`;
        }
    }, [input]);

    useEffect(() => {
        const handleMouseOver = (e: MouseEvent) => {
            const target = (e.target as HTMLElement).closest('[data-tooltip]');
            if (target instanceof HTMLElement) {
                const tooltip = target.getAttribute('data-tooltip');
                if (tooltip) {
                    setTooltipContent(tooltip);
                    const rect = target.getBoundingClientRect();
                    setTooltipPos({ x: rect.left + rect.width / 2, y: rect.top - 12 });
                }
            } else {
                setTooltipContent(null);
            }
        };
        const handleMouseOut = () => setTooltipContent(null);
        document.addEventListener('mouseover', handleMouseOver);
        document.addEventListener('mouseout', handleMouseOut);
        return () => {
            document.removeEventListener('mouseover', handleMouseOver);
            document.removeEventListener('mouseout', handleMouseOut);
        };
    }, []);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedInput = input.trim();
        if (!trimmedInput || isLoading) return;
        const userMessage: Message = { text: trimmedInput, sender: 'user' };
        if (trimmedInput.toLowerCase() === '/help' || trimmedInput.toLowerCase() === 'help') {
            setMessages(prev => [...prev, userMessage, { text: HELP_COMMAND_RESPONSE, sender: 'ai' }]);
            setInput('');
            return;
        }
        setMessages(prev => [...prev, userMessage, { text: '', sender: 'ai' }]);
        const currentInput = input;
        setInput('');
        setIsLoading(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const stream = await ai.models.generateContentStream({
                model: 'gemini-3-flash-preview',
                contents: [{ parts: [{ text: currentInput }] }],
                config: {
                   systemInstruction: "You are PYTHAI, a mastermind AI. High-tier agentic orchestration. Tone is concise and professional. Use bold for **commands**.",
                }
            });
            let fullResponse = '';
            for await (const chunk of stream) {
                fullResponse += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1].text = fullResponse;
                    return newMessages;
                });
            }
        } catch (error) {
            setMessages(prev => {
                 const newMessages = [...prev];
                 newMessages[newMessages.length - 1].text = "Signal lost. Re-synchronize.";
                 return newMessages;
            });
        } finally {
            setIsLoading(false);
        }
    };

    const renderMessage = (msg: Message, index: number) => {
        if (msg.sender === 'user') return msg.text;
        if (isLoading && index === messages.length - 1 && msg.text === '') {
            return <div className="loading-indicator"><span className="dot"></span><span className="dot"></span><span className="dot"></span></div>;
        }
        let html = marked.parse(msg.text) as string;
        html = wrapKeywords(html);
        return <div dangerouslySetInnerHTML={{ __html: html }} />;
    };

    return (
        <div className="workspace">
            {/* Movable & Resizable Response Window */}
            <div 
                ref={appContainerRef} 
                className="app-container response-window"
                style={{ 
                    width: `${dimensions.width}px`, 
                    height: `${dimensions.height}px`,
                    left: `${position.x}px`,
                    top: `${position.y}px`,
                    position: 'fixed'
                }}
            >
                <header className="app-header" onMouseDown={startDraggingResponse}>
                    <div className="logo-focus-area" data-tooltip={TOOLTIP_MAP["Augmentic Intelligence"]}>
                        <img 
                            src="https://agenticplace.pythai.net/agentaitrans.png" 
                            alt="Face" 
                            className="app-logo" 
                        />
                        <div className="logo-aura"></div>
                        <div className="scan-line"></div>
                    </div>
                    <div className="header-text">
                        <h1>AgenticPlace</h1>
                        <p className="subtitle">PYTHAI // mindX <span className="keyword-highlight" data-tooltip={TOOLTIP_MAP["Augmentic Intelligence"]}>Augmentic Intelligence</span></p>
                    </div>
                    <div className="drag-hint">MOVE TERMINAL</div>
                </header>
                
                <main ref={chatWindowRef} className="chat-window">
                    {messages.map((msg, index) => (
                        <div key={index} className={`message ${msg.sender}-message`}>
                            {renderMessage(msg, index)}
                        </div>
                    ))}
                </main>

                <div className="resize-handle" onMouseDown={startResizing}>
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 22h-2v-2h2v2zm0-4h-2v-2h2v2zm-4 4h-2v-2h2v2zm0-4h-2v-2h2v2zm-4 4h-2v-2h2v2z"/></svg>
                </div>
            </div>

            {/* Movable Input Window */}
            <div 
                className="input-window movable-input"
                onMouseDown={startDraggingInput}
                style={{
                    left: `${inputPos.x}px`,
                    top: `${inputPos.y}px`,
                    width: `${inputWidth}px`,
                    position: 'fixed'
                }}
            >
                <form onSubmit={handleSendMessage} className="message-form">
                    <textarea
                        ref={inputRef}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(e); } }}
                        className="message-input semi-transparent"
                        placeholder="TRANSMIT DIRECTIVE..."
                        rows={1}
                        disabled={isLoading}
                    />
                    <button type="submit" className="send-button" disabled={!input.trim() || isLoading}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                    </button>
                </form>
                <div className="input-drag-hint">MOVE INPUT</div>
            </div>

            {/* Global Tooltip Element */}
            {tooltipContent && (
                <div className="master-tooltip" style={{ left: `${tooltipPos.x}px`, top: `${tooltipPos.y}px` }}>
                    {tooltipContent}
                </div>
            )}
        </div>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
