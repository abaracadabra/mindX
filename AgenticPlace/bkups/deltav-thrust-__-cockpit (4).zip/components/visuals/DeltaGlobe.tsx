
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

export const DeltaGlobe: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = 600;
    const height = 600;
    const sensitivity = 75;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .attr('viewBox', `0 0 ${width} ${height}`);

    svg.selectAll("*").remove();

    const projection = d3.geoOrthographic()
      .scale(250)
      .center([0, 0])
      .rotate([0, -30])
      .translate([width / 2, height / 2]);

    const initialScale = projection.scale();
    const path = d3.geoPath().projection(projection);

    // Background Glow
    svg.append("circle")
      .attr("cx", width / 2)
      .attr("cy", height / 2)
      .attr("r", projection.scale())
      .attr("fill", "url(#globe-glow)")
      .attr("filter", "blur(40px)")
      .style("opacity", 0.3);

    const defs = svg.append("defs");
    const gradient = defs.append("radialGradient")
      .attr("id", "globe-glow")
      .attr("cx", "50%")
      .attr("cy", "50%")
      .attr("r", "50%");
    gradient.append("stop").attr("offset", "0%").attr("stop-color", "#00ff00").attr("stop-opacity", 0.5);
    gradient.append("stop").attr("offset", "100%").attr("stop-color", "#000").attr("stop-opacity", 0);

    const globe = svg.append("g");

    // Graticule (Grid Lines)
    const graticule = d3.geoGraticule();
    globe.append("path")
      .datum(graticule())
      .attr("class", "graticule")
      .attr("d", path)
      .attr("fill", "none")
      .attr("stroke", "#0f0")
      .attr("stroke-width", 0.2)
      .attr("opacity", 0.3);

    // Simulated "TNT Nodes" across the globe
    const nodes = Array.from({ length: 15 }, () => ({
      type: "Point",
      coordinates: [(Math.random() - 0.5) * 360, (Math.random() - 0.5) * 180],
      id: Math.random().toString()
    }));

    const nodeGroup = globe.selectAll(".node")
      .data(nodes)
      .enter()
      .append("path")
      .attr("class", "node")
      .attr("d", path)
      .attr("fill", "#0f0")
      .attr("stroke", "#fff")
      .attr("stroke-width", 0.5)
      .style("filter", "drop-shadow(0 0 5px #0f0)");

    // Rotating Motion
    let rotation = 0;
    const timer = d3.timer(() => {
      rotation += 0.2;
      projection.rotate([rotation, -20]);
      globe.selectAll("path").attr("d", path);
      
      // Update node visibility based on whether they are in front
      nodeGroup.style("opacity", d => {
        const geoPoint = d.coordinates as [number, number];
        const center = projection.invert([width / 2, height / 2]) as [number, number];
        const distance = d3.geoDistance(geoPoint, center);
        return distance > Math.PI / 2 ? 0 : 0.8;
      });
    });

    // Interaction
    svg.call(d3.drag()
      .on('drag', (event) => {
        const rotate = projection.rotate();
        const k = sensitivity / projection.scale();
        projection.rotate([
          rotate[0] + event.dx * k,
          rotate[1] - event.dy * k
        ]);
        globe.selectAll("path").attr("d", path);
      }));

    return () => timer.stop();
  }, []);

  return (
    <div className="relative flex items-center justify-center select-none">
      <svg ref={svgRef} className="cursor-move drop-shadow-[0_0_50px_rgba(0,255,0,0.15)]"></svg>
      <div className="absolute bottom-10 flex flex-col items-center gap-2 pointer-events-none">
        <div className="px-4 py-1.5 bg-green-500/10 border border-green-500/30 rounded-full text-[9px] font-black text-green-500 uppercase tracking-widest backdrop-blur-md">
          DELTAVERSE_CORE_VIEW
        </div>
      </div>
    </div>
  );
};
