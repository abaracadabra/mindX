
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface Node extends d3.SimulationNodeDatum {
  id: string;
  group: number;
}

interface Link extends d3.SimulationLinkDatum<Node> {
  value: number;
}

export const SymcryptosisFlow: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!containerRef.current || !svgRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = 400;

    const svg = d3.select(svgRef.current)
      .attr("width", width)
      .attr("height", height);

    svg.selectAll("*").remove();

    const nodes: Node[] = Array.from({ length: 40 }, (_, i) => ({
      id: `node-${i}`,
      group: Math.floor(Math.random() * 3)
    }));

    const links: Link[] = Array.from({ length: 60 }, () => ({
      source: nodes[Math.floor(Math.random() * nodes.length)].id,
      target: nodes[Math.floor(Math.random() * nodes.length)].id,
      value: Math.random()
    }));

    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(100))
      .force("charge", d3.forceManyBody().strength(-50))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("x", d3.forceX(width / 2).strength(0.1))
      .force("y", d3.forceY(height / 2).strength(0.1));

    const linkGroup = svg.append("g")
      .attr("stroke", "#0f0")
      .attr("stroke-opacity", 0.2)
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke-width", d => Math.sqrt(d.value) * 2);

    const nodeGroup = svg.append("g")
      .attr("stroke", "#fff")
      .attr("stroke-width", 0.5)
      .selectAll("circle")
      .data(nodes)
      .join("circle")
      .attr("r", 4)
      .attr("fill", d => ["#00ff00", "#3b82f6", "#10b981"][d.group])
      .style("filter", "drop-shadow(0 0 8px currentColor)");

    // Particle flow effect along links
    const particles: any[] = [];
    const particleTimer = d3.timer(() => {
      if (Math.random() < 0.1) {
        const link = links[Math.floor(Math.random() * links.length)];
        particles.push({
          link,
          progress: 0,
          id: Math.random()
        });
      }

      svg.selectAll(".particle")
        .data(particles, (d: any) => d.id)
        .join(
          enter => enter.append("circle")
            .attr("class", "particle")
            .attr("r", 2)
            .attr("fill", "#fff")
            .style("filter", "drop-shadow(0 0 5px #fff)"),
          update => update,
          exit => exit.remove()
        )
        .attr("cx", (d: any) => {
          const s = d.link.source as any;
          const t = d.link.target as any;
          return s.x + (t.x - s.x) * d.progress;
        })
        .attr("cy", (d: any) => {
          const s = d.link.source as any;
          const t = d.link.target as any;
          return s.y + (t.y - s.y) * d.progress;
        });

      particles.forEach((p, i) => {
        p.progress += 0.02;
        if (p.progress > 1) particles.splice(i, 1);
      });
    });

    simulation.on("tick", () => {
      linkGroup
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      nodeGroup
        .attr("cx", (d: any) => d.x)
        .attr("cy", (d: any) => d.y);
    });

    return () => {
      simulation.stop();
      particleTimer.stop();
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full bg-zinc-950/50 border border-zinc-900 rounded-[2.5rem] p-4 overflow-hidden relative group">
      <div className="absolute top-6 left-10 flex items-center gap-3">
        <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
        <span className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.4em]">Emotonomic_Resonance_Flow</span>
      </div>
      <svg ref={svgRef} className="w-full h-full"></svg>
    </div>
  );
};
