
import React, { useState, useEffect } from 'react';
import { generateSnapshot, ThrustSnapshot, fetchLivePrice } from '../../services/oracleService';
import { LiveGraph } from '../visuals/LiveGraph';
import { SymcryptosisFlow } from '../visuals/SymcryptosisFlow';
import { Activity, ShieldCheck, Database, Zap, Target, Compass, Info, TrendingUp, Search, Users, Rocket, Gauge, Bot, ShieldAlert } from 'lucide-react';

export const TruthOracleTab: React.FC = () => {
  const [snapshots, setSnapshots] = useState<ThrustSnapshot[]>([]);
  const [current, setCurrent] = useState<ThrustSnapshot | null>(null);
  const [liveData, setLiveData] = useState<any>(null);
  const [showDiscovery, setShowDiscovery] = useState(false);
  const [isSimulatorActive, setIsSimulatorActive] = useState(false);

  useEffect(() => {
    const sync = async () => {
      const live = await fetchLivePrice();
      if (live) setLiveData(live);
      const fresh = generateSnapshot();
      setCurrent(fresh);
      setSnapshots(prev => [...prev.slice(-29), fresh]);
    };
    
    sync();
    const interval = setInterval(sync, 5000);
    return () => clearInterval(interval);
  }, []);

  if (!current) return <div className="p-8 text-center animate-pulse text-green-500 font-mono uppercase tracking-widest">Calculating Symcryptosis...</div>;

  const lpPrice = liveData?.priceUsd || current.priceUSD;
  const meanPrice = lpPrice * (1 + (Math.random() - 0.5) * 0.002); 
  
  const multiplier = isSimulatorActive ? 2.5 : 1;
  const emergingPoint = ((lpPrice + meanPrice) / 2) * multiplier;

  const currentHolders = 412;
  const nextMilestone = 1000;
  const ultimateMilestone = 10000;
  const milestoneProgress = (currentHolders / nextMilestone) * 100;
  const spikeProgress = (currentHolders / ultimateMilestone) * 100;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Symcryptosis Engine Display */}
      <div className="bg-zinc-950 border border-green-900/20 p-10 rounded-[3rem] relative overflow-hidden shadow-2xl group hover:border-green-500/30 transition-all">
        <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:opacity-10 transition-opacity">
          <Compass size={240} className="animate-spin-slow text-green-500" />
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-12 relative z-10">
          <div className="space-y-6 text-center md:text-left flex-1">
            <div className="flex items-center gap-4 justify-center md:justify-start">
               <h2 className="text-[11px] font-black uppercase tracking-[0.8em] text-green-800">Symcryptosis Theory Index</h2>
               <button 
                 onClick={() => setShowDiscovery(!showDiscovery)}
                 className="p-1.5 bg-zinc-900 border border-zinc-800 rounded-full text-zinc-500 hover:text-white transition-colors"
               >
                 <Info size={14} />
               </button>
               {isSimulatorActive && (
                 <span className="bg-red-500 text-black text-[9px] font-black px-2 py-0.5 rounded-full animate-pulse tracking-tighter">1,000_HOLDER_PROJECTION</span>
               )}
            </div>
            <div className={`text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter font-mono transition-all duration-1000 ${isSimulatorActive ? 'text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.5)]' : 'text-white'}`}>
              ${emergingPoint.toFixed(10)}
            </div>
            <div className="flex items-center gap-3 justify-center md:justify-start">
              <p className="text-[10px] text-zinc-600 italic max-w-lg leading-relaxed uppercase tracking-widest font-bold">
                {isSimulatorActive ? "Predicted 2.5x correction upon reaching 1,000 passengers." : "Current emerging price point based on liquidity/mean average parity."}
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-6 w-full md:w-auto">
            <div className="flex items-center gap-10 bg-black/60 p-8 rounded-[2rem] border border-zinc-900 shadow-inner">
              <div className="space-y-2 text-center">
                <span className="text-[9px] text-zinc-600 uppercase font-black tracking-widest">DEX_SCR_Pair</span>
                <div className="text-xl font-black font-mono text-blue-500">${lpPrice.toFixed(8)}</div>
              </div>
              <div className="text-zinc-800 font-black text-2xl">⇹</div>
              <div className="space-y-2 text-center">
                <span className="text-[9px] text-zinc-600 uppercase font-black tracking-widest">Global_Mean</span>
                <div className="text-xl font-black font-mono text-purple-500">${meanPrice.toFixed(8)}</div>
              </div>
            </div>
            
            <button 
              onClick={() => setIsSimulatorActive(!isSimulatorActive)}
              className={`w-full py-4 border rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${isSimulatorActive ? 'bg-red-900/20 border-red-500 text-red-500' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'}`}
            >
              {isSimulatorActive ? 'Deactivate Projection' : 'Simulate 1,000 Holder Jump'}
            </button>
          </div>
        </div>
      </div>

      {/* New Motion Flow Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8">
          <SymcryptosisFlow />
        </div>
        <div className="lg:col-span-4 bg-zinc-950 border border-zinc-900 rounded-[2.5rem] p-8 flex flex-col justify-center gap-6 shadow-xl relative overflow-hidden">
           <div className="absolute inset-0 opacity-5 pointer-events-none">
             <Zap size={200} className="text-yellow-500" />
           </div>
           <h4 className="text-[11px] font-black uppercase text-yellow-500 tracking-[0.2em] flex items-center gap-3">
             <Activity size={16} /> Emotonomic Resonance
           </h4>
           <p className="text-[10px] text-zinc-500 leading-relaxed font-mono uppercase italic">
             Visualizing real-time attention velocity as it iterates through the Symcryptosis logic core.
           </p>
           <div className="space-y-4">
              <div className="flex justify-between items-center text-[9px] font-black text-zinc-700 uppercase">
                 <span>Input Frequency</span>
                 <span className="text-white">88.4 Hz</span>
              </div>
              <div className="w-full h-1 bg-zinc-900 rounded-full">
                <div className="h-full bg-blue-500" style={{ width: '64%' }}></div>
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-zinc-900/50 border border-blue-900/30 p-6 rounded-2xl flex flex-col items-center justify-center text-center group hover:border-blue-500/50 transition-all hover:bg-zinc-900 relative overflow-hidden">
          <div className="absolute inset-0 bg-blue-500/[0.03] animate-pulse"></div>
          <Users size={20} className="mb-3 text-blue-400 group-hover:scale-110 transition-transform relative z-10" />
          <span className="text-[10px] uppercase text-zinc-500 tracking-tighter font-black mb-1 relative z-10">PASSENGER COUNT</span>
          <span className="text-2xl font-black font-mono text-white tracking-tighter relative z-10">{currentHolders}</span>
          <div className="w-full mt-3 h-1.5 bg-black rounded-full overflow-hidden relative z-10 border border-zinc-800">
            <div className="h-full bg-blue-500 shadow-[0_0_10px_#3b82f6]" style={{ width: `${milestoneProgress}%` }}></div>
          </div>
          <span className="text-[9px] text-zinc-600 font-mono mt-2 uppercase tracking-widest relative z-10">Gate: 1,000 (2.5x Target)</span>
        </div>

        <div className="bg-zinc-900/50 border border-green-800 p-6 rounded-2xl flex flex-col items-center justify-center text-center group hover:border-green-500/50 transition-all hover:bg-zinc-900 relative">
          <Gauge size={20} className="mb-3 text-green-400 group-hover:scale-110 transition-transform" />
          <span className="text-[10px] uppercase text-zinc-500 tracking-tighter font-black mb-1">THRUST GROWTH</span>
          <span className="text-2xl font-black font-mono text-white tracking-tighter">x{current.volumeGrowthFactor.toFixed(2)}</span>
          <span className="text-[9px] text-zinc-600 uppercase font-mono mt-2 font-bold tracking-widest animate-pulse">Volume Scaled</span>
        </div>
        
        <div className="bg-zinc-900/50 border border-orange-800/40 p-6 rounded-2xl flex flex-col items-center justify-center text-center group hover:border-orange-500/50 transition-all hover:bg-zinc-900">
          <Bot size={20} className="mb-3 text-orange-400 group-hover:scale-110 transition-transform" />
          <span className="text-[10px] uppercase text-zinc-500 tracking-tighter font-black mb-1">LIQUIDITY POLICY</span>
          <span className="text-2xl font-black font-mono text-white tracking-tighter">1.0%</span>
          <span className="text-[9px] text-zinc-600 uppercase font-mono mt-2 font-bold tracking-widest">Sustainability Locked</span>
        </div>

        <div className="bg-zinc-900/50 border border-yellow-800/30 p-6 rounded-2xl flex flex-col items-center justify-center text-center group hover:border-yellow-500/50 transition-all hover:bg-zinc-900">
          <ShieldCheck size={20} className="mb-3 text-yellow-400 group-hover:scale-110 transition-transform" />
          <span className="text-[10px] uppercase text-zinc-500 tracking-tighter font-black mb-1">TOTAL SYSTEM FEE</span>
          <span className="text-2xl font-black text-green-500 tracking-tighter uppercase italic">{current.currentFeeRate.toFixed(1)}%</span>
          <span className="text-[9px] text-zinc-700 font-mono mt-2 font-black italic">RATCHET_DOWN_ONLY</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 shadow-2xl">
           <LiveGraph data={snapshots} />
        </div>
        <div className="lg:col-span-4 bg-zinc-950 border border-zinc-900 rounded-[2.5rem] p-8 flex flex-col gap-8 shadow-xl">
           <div className="flex justify-between items-center">
             <h4 className="text-[11px] font-black uppercase text-green-500 flex items-center gap-3 tracking-[0.2em]">
               <Rocket size={16} className="animate-bounce" /> Mission_Trajectory
             </h4>
             <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_#22c55e]"></div>
           </div>
           
           <div className="space-y-5">
              {[
                { label: 'Next_Milestone', value: '1,000 Holders', color: 'text-blue-400' },
                { label: 'Correction_Est', value: '2.50x Velocity', color: 'text-white' },
                { label: 'Endgame_Gate', value: '10,000 Holders', color: 'text-red-500' },
                { label: '2026_Fee_Target', value: '2.0% ENTRY/EXIT', color: 'text-yellow-600' }
              ].map((item, idx) => (
                <div key={idx} className="flex justify-between items-end border-b border-zinc-900 pb-3 hover:border-zinc-700 transition-colors">
                  <span className="text-[10px] uppercase text-zinc-600 font-bold tracking-tight">{item.label}</span>
                  <span className={`text-xs font-black font-mono ${item.color}`}>{item.value}</span>
                </div>
              ))}
           </div>
           
           <div className="mt-auto space-y-4">
             <div className="p-4 bg-black rounded-2xl border border-zinc-900 border-dashed text-center">
                <div className="text-[10px] text-zinc-500 uppercase font-black mb-2 flex items-center justify-center gap-2">
                  Distance to 10k Spike <ShieldAlert size={10} className="text-red-500" />
                </div>
                <div className="text-xl font-black text-white font-mono">{spikeProgress.toFixed(2)}%</div>
                <div className="h-1 w-full bg-zinc-900 mt-2 rounded-full overflow-hidden">
                   <div className="h-full bg-red-600 shadow-[0_0_10px_#ef4444]" style={{ width: `${spikeProgress}%` }}></div>
                </div>
             </div>
             <button className="w-full py-5 bg-blue-600 text-white text-[11px] font-black uppercase hover:bg-blue-500 transition-all rounded-2xl shadow-lg border-b-4 border-blue-800 active:border-b-0">
               Generate Viral Vector
             </button>
           </div>
        </div>
      </div>
    </div>
  );
};
