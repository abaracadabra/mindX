
import React, { useState, useRef, useEffect } from 'react';
import { askBrobot } from '../../services/geminiService';
import { Send, Terminal, Bot, Sparkles, User, Wifi, ShieldCheck, Zap } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'brobot';
  timestamp: Date;
}

export const BrobotTab: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: 'YO BRO! Protocol intelligence BROBOT online. How can I calibrate your THRUST experience today?', sender: 'brobot', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { id: Date.now().toString(), text: input, sender: 'user', timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const response = await askBrobot(input);
    const botMsg: Message = { id: (Date.now() + 1).toString(), text: response || 'PROTOCOL_TIMEOUT', sender: 'brobot', timestamp: new Date() };
    
    setMessages(prev => [...prev, botMsg]);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-full gap-6 animate-in fade-in zoom-in-95 duration-500">
      <div className="flex items-center justify-between px-6 py-4 bg-zinc-950 border border-zinc-900 rounded-2xl shadow-xl">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center text-green-500 border border-green-500/20">
              <Bot size={28} className={isLoading ? 'animate-bounce' : ''} />
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-black rounded-full shadow-[0_0_10px_#22c55e]"></div>
          </div>
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-widest">BROBOT_CORE_AI</h3>
            <div className="flex items-center gap-2 text-[10px] text-zinc-500 font-mono">
              <Wifi size={10} className="text-green-500" />
              HANDSHAKE_STABLE_v7.4
            </div>
          </div>
        </div>
        <div className="hidden md:flex gap-4">
          <div className="px-4 py-2 bg-black border border-zinc-900 rounded-xl flex items-center gap-2">
            <ShieldCheck size={14} className="text-blue-500" />
            <span className="text-[9px] font-black text-zinc-600 uppercase tracking-tighter">Safety_Shield_Active</span>
          </div>
          <div className="px-4 py-2 bg-black border border-zinc-900 rounded-xl flex items-center gap-2">
            <Zap size={14} className="text-yellow-500" />
            <span className="text-[9px] font-black text-zinc-600 uppercase tracking-tighter">1000%_APY_MOD_READY</span>
          </div>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 bg-black border border-zinc-900 rounded-[2.5rem] p-8 overflow-y-auto custom-scrollbar space-y-6 shadow-inner relative"
      >
        <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
          <Terminal size={300} className="text-green-500" />
        </div>

        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
            <div className={`max-w-[80%] flex gap-4 ${m.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${m.sender === 'user' ? 'bg-blue-500/10 border-blue-500/30 text-blue-500' : 'bg-green-500/10 border-green-500/30 text-green-500'}`}>
                {m.sender === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`p-5 rounded-2xl text-[13px] font-mono leading-relaxed ${m.sender === 'user' ? 'bg-zinc-900 text-zinc-200 border border-zinc-800' : 'bg-black border border-green-900/30 text-green-400/90 italic shadow-lg shadow-green-500/5'}`}>
                {m.text}
                <div className="mt-2 text-[8px] opacity-30 font-black uppercase tracking-widest">
                  {m.timestamp.toLocaleTimeString()}
                </div>
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start animate-pulse">
            <div className="bg-zinc-950 border border-zinc-900 p-4 rounded-2xl flex items-center gap-3">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
              <span className="text-[9px] font-black text-zinc-700 uppercase tracking-widest">BROBOT_CALCULATING...</span>
            </div>
          </div>
        )}
      </div>

      <div className="relative group">
        <div className="absolute inset-0 bg-green-500 blur-2xl opacity-5 group-focus-within:opacity-10 transition-opacity"></div>
        <div className="relative bg-zinc-950 border border-zinc-800 p-2 rounded-[2rem] flex items-center shadow-2xl focus-within:border-green-500/50 transition-all">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask BROBOT about Symcryptosis, APY, or Bridge Tech..."
            className="flex-1 bg-transparent border-none text-white font-mono px-6 py-4 outline-none text-sm placeholder:text-zinc-700"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading}
            className="bg-green-500 hover:bg-green-400 text-black p-4 rounded-full transition-all disabled:opacity-50 disabled:grayscale shadow-[0_0_20px_rgba(34,197,94,0.4)]"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};
