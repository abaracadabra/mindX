
import React, { useState, useEffect } from 'react';
import { generateSnapshot, ThrustSnapshot } from '../../services/oracleService';
import { Heart, TrendingUp, Zap, Users, ShieldAlert, Leaf, Sprout, Trees, Waves, Sparkles } from 'lucide-react';

export const AttentionRewardTab: React.FC = () => {
  const [luvBalance, setLuvBalance] = useState(12450.32);
  const [thrustData, setThrustData] = useState<ThrustSnapshot | null>(null);
  const [resonance, setResonance] = useState(88);
  
  useEffect(() => {
    const interval = setInterval(() => {
      const s = generateSnapshot();
      setThrustData(s);
      setLuvBalance(prev => prev + (Math.random() * 0.1));
      setResonance(prev => Math.min(100, Math.max(50, prev + (Math.random() - 0.5) * 5)));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const attentionCoefficient = 2.5; 
  const thrustPrice = thrustData?.priceUSD || 0.00001193;
  const luvUsdValue = thrustPrice * attentionCoefficient;

  return (
    <div className="space-y-6 animate-in zoom-in-95 duration-500 pb-20">
      {/* Shamba Header with Emotonomics logic */}
      <div className="bg-gradient-to-br from-emerald-900/40 via-black to-green-900/20 border border-emerald-500/30 p-10 rounded-[3.5rem] flex flex-col md:flex-row items-center justify-between gap-8 shadow-[0_0_80px_rgba(16,185,129,0.15)] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <Waves className="w-full h-full text-emerald-500" />
        </div>
        
        <div className="flex items-center gap-8 relative z-10">
          <div className="relative">
             <div className="w-20 h-20 bg-emerald-500/10 rounded-3xl flex items-center justify-center text-emerald-400 border border-emerald-500/30 shadow-[0_0_40px_rgba(16,185,129,0.3)] animate-pulse">
               <Heart size={40} className="fill-emerald-500/20" />
             </div>
             <div className="absolute -top-2 -right-2 bg-white text-black text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter">EMOTONOMICS_ACTIVE</div>
          </div>
          <div className="text-left">
            <h2 className="text-3xl font-black text-white tracking-tighter uppercase italic leading-none">SHAMBA LUV</h2>
            <p className="text-[10px] text-emerald-500 font-mono font-black tracking-[0.5em] uppercase mt-2">The Heart of the Plantation</p>
          </div>
        </div>

        <div className="flex flex-col items-end gap-3 relative z-10">
          <div className="bg-black/60 px-8 py-4 rounded-3xl border border-emerald-900/40 flex items-center gap-6">
            <div className="text-right">
              <div className="text-[9px] text-zinc-500 uppercase font-black tracking-widest">Emotonomic Resonance</div>
              <div className="text-xl font-mono font-black text-emerald-400">{resonance.toFixed(1)}%</div>
            </div>
            <div className="flex gap-1.5 h-10 items-end">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className={`w-2 rounded-full transition-all duration-1000 ${i <= (resonance / 16) ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-zinc-800'}`} style={{ height: `${Math.random() * 100}%` }}></div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-zinc-950 border border-emerald-900/30 p-8 rounded-[2rem] group hover:border-emerald-500/50 transition-all shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <Sparkles className="text-emerald-500" size={18} />
            <span className="text-[9px] bg-emerald-950 text-emerald-400 px-3 py-1 rounded-full font-black tracking-tighter uppercase">HARVEST_READY</span>
          </div>
          <p className="text-3xl font-black font-mono text-white tracking-tighter">{luvBalance.toLocaleString(undefined, { maximumFractionDigits: 2 })} LUV</p>
          <p className="text-[10px] text-zinc-600 mt-3 uppercase font-black italic tracking-widest">≈ ${(luvBalance * luvUsdValue).toFixed(2)} USD value</p>
        </div>

        <div className="bg-zinc-950 border border-yellow-900/30 p-8 rounded-[2rem] group hover:border-yellow-500/50 transition-all shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <Sprout className="text-yellow-500" size={18} />
            <span className="text-[9px] bg-yellow-950 text-yellow-400 px-3 py-1 rounded-full font-black tracking-tighter uppercase">ATTN_MULTIPLIER</span>
          </div>
          <p className="text-3xl font-black font-mono text-white tracking-tighter">2.50x</p>
          <p className="text-[10px] text-zinc-600 mt-3 uppercase font-black italic tracking-widest">Growth Vector: Alpha</p>
        </div>

        <div className="bg-zinc-950 border border-blue-900/30 p-8 rounded-[2rem] group hover:border-blue-500/50 transition-all shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <TrendingUp className="text-blue-500" size={18} />
            <span className="text-[9px] bg-blue-950 text-blue-400 px-3 py-1 rounded-full font-black tracking-tighter uppercase">SENTIMENT_PARITY</span>
          </div>
          <p className="text-3xl font-black font-mono text-white tracking-tighter">1.42x</p>
          <p className="text-[10px] text-zinc-600 mt-3 uppercase font-black italic tracking-widest">DeltaVerse Stability</p>
        </div>

        <div className="bg-zinc-950 border border-green-900/30 p-8 rounded-[2rem] group hover:border-green-500/50 transition-all shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <Users className="text-green-500" size={18} />
            <span className="text-[9px] bg-green-950 text-green-400 px-3 py-1 rounded-full font-black tracking-tighter uppercase">FLEET_RESONANCE</span>
          </div>
          <p className="text-3xl font-black font-mono text-white tracking-tighter">1,024</p>
          <p className="text-[10px] text-zinc-600 mt-3 uppercase font-black italic tracking-widest">Nodes Synchronized</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 bg-zinc-950 border border-zinc-900 p-10 rounded-[3rem] relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none group-hover:opacity-10 transition-opacity">
            <Trees size={300} className="text-emerald-500" />
          </div>
          <div className="relative z-10 space-y-10">
            <div className="flex items-center gap-4">
               <div className="w-1.5 h-6 bg-emerald-500 rounded-full shadow-[0_0_10px_#10b981]"></div>
               <h3 className="text-sm font-black uppercase text-white tracking-[0.4em]">Emotonomic Logic Core</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-6">
                 <p className="text-zinc-500 text-xs leading-relaxed font-mono uppercase italic">
                   "Emotonomics is the art of converting attention velocity into rebase mass. In the Shamba, every like, share, and heartbeat feeds the yield plantation."
                 </p>
                 <div className="p-6 bg-black border border-zinc-900 rounded-3xl space-y-4">
                    <div className="flex justify-between items-center text-[10px] font-black text-zinc-500">
                      <span>ATTN_QUOTA</span>
                      <span className="text-emerald-500">82%</span>
                    </div>
                    <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: '82%' }}></div>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-black text-zinc-500">
                      <span>SENTIMENT_FLOW</span>
                      <span className="text-blue-500">OPTIMAL</span>
                    </div>
                    <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500" style={{ width: '94%' }}></div>
                    </div>
                 </div>
              </div>
              <div className="flex flex-col justify-center items-center gap-6 border-l border-zinc-900 pl-10">
                 <div className="text-center">
                    <div className="text-[10px] font-black text-zinc-600 uppercase tracking-widest mb-2">Yield Plantation Projection</div>
                    <div className="text-5xl font-black text-white font-mono tracking-tighter">${luvUsdValue.toFixed(6)}</div>
                    <div className="text-[9px] text-emerald-600 font-black uppercase mt-2">SHAMBA_LUV_PEG</div>
                 </div>
                 <button className="w-full py-5 bg-emerald-600 text-white text-[11px] font-black uppercase rounded-2xl hover:bg-emerald-500 transition-all shadow-[0_0_30px_rgba(16,185,129,0.3)]">
                   Amplify Resonance
                 </button>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-6">
           <div className="bg-zinc-900/40 border border-zinc-800 p-8 rounded-[2.5rem] flex flex-col gap-6 shadow-xl h-full">
              <div className="flex items-center gap-3 text-emerald-500">
                <Leaf size={18} />
                <h4 className="text-[11px] font-black uppercase tracking-widest">Plantation Specs</h4>
              </div>
              <div className="space-y-4 font-mono">
                {[
                  { label: 'Harvest_Freq', value: '15_MIN_EPOCH' },
                  { label: 'Min_Attention', value: '88_BPM' },
                  { label: 'Luv_Multiplier', value: 'x2.50' },
                  { label: 'Network_Node', value: 'SHAMBA_01' }
                ].map((item, i) => (
                  <div key={i} className="flex justify-between items-center border-b border-zinc-900/50 pb-3">
                    <span className="text-[9px] text-zinc-600 uppercase">{item.label}</span>
                    <span className="text-[10px] text-zinc-300 font-bold">{item.value}</span>
                  </div>
                ))}
              </div>
              <div className="mt-auto p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                 <p className="text-[9px] text-emerald-700 font-black uppercase leading-relaxed italic">
                   "The Shamba only grows for the devoted. Participation in the DeltaVerse is mandatory for max harvest."
                 </p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
