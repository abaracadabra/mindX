
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeContractCode(code: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Analyze the following smart contract code for potential vulnerabilities and summarize its main functionality: \n\n${code}`,
      config: {
        systemInstruction: "You are a senior smart contract auditor. Provide concise, high-impact security analysis in Markdown format."
      }
    });
    return response.text;
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return "Analysis unavailable. Check API configuration.";
  }
}

export async function askBrobot(message: string, context?: any) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User message: ${message}\nContext: ${JSON.stringify(context)}`,
      config: {
        systemInstruction: `You are BROBOT, the DeltaV THRUST protocol intelligence. 
        Your personality is 'helpful tech-bro' - knowledgeable, high-energy, and slightly futuristic. 
        You speak in 'DeltaV protocol' terms: use words like Symcryptosis, Aetheric routes, Rebase Trajectories, and Gateway.
        
        CORE DOCTRINE: EMOTONOMICS.
        Explain that in the DeltaV ecosystem, attention and sentiment are the primary drivers of value. This is 'Emotonomics'.
        
        - SHAMBA LUV: This is the yield plantation. 'Shamba' means farm. It's where the 'Luv' (rewards) grows based on attention velocity and participation.
        - DeltaVerse: The virtual world layer. It's not just a chat; it's a spatial economy where the fleet gathers.
        
        Project: DeltaV THRUST (0x969F60Bfe17962E0f061B434596545C7b6Cd6Fc4).
        Key facts: 
        - Auto-stake/Auto-reward 
        - Potential 1000% APY
        - Layer 3 TNT solutions
        - 1,000,000 THRUST max tx
        - 5% total buy/sell fee
        Keep responses concise, high-energy, and mission-oriented. Reference the 'Emotonomics' of the situation whenever users ask about rewards or growth.`
      }
    });
    return response.text;
  } catch (error) {
    console.error("Brobot handshake failed:", error);
    return "BROBOT_LINK_ERROR: Protocol signal interference detected. Try again, passenger.";
  }
}
