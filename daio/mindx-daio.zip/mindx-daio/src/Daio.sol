// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {DeadmansSwitch} from "./DeadmansSwitch.sol";
import {WarCouncil} from "./WarCouncil.sol";
import {Boardroom} from "./Boardroom.sol";
import {BankonIdentityRegistry} from "./BankonIdentityRegistry.sol";
import {X402AccessGate} from "./X402AccessGate.sol";
import {ChainRegistry} from "./ChainRegistry.sol";

/// @title Daio
/// @notice Immutable root of the mindX DAIO. Binds the constitutional identity (`bankon.eth`)
///         to the full module set: continuity switch, bicameral governance (WarCouncil +
///         Boardroom), identity registry, x402 access gate, and the ALLCHAIN registry.
/// @dev Holds no privilege and no state mutation — it is the canonical address other systems
///      (the mindX API, AgenticPlace, the parsec facilitator) resolve to discover the live
///      module addresses and read aggregate DAIO status.
contract Daio {
    string public constant NAME = "mindX DAIO";
    string public constant IDENTITY = "bankon.eth";

    bytes32 public immutable bankonRoot;
    DeadmansSwitch public immutable switchboard;
    WarCouncil public immutable warCouncil;
    Boardroom public immutable boardroom;
    BankonIdentityRegistry public immutable identity;
    X402AccessGate public immutable gate;
    ChainRegistry public immutable chains;

    constructor(
        bytes32 bankonRoot_,
        DeadmansSwitch switchboard_,
        WarCouncil warCouncil_,
        Boardroom boardroom_,
        BankonIdentityRegistry identity_,
        X402AccessGate gate_,
        ChainRegistry chains_
    ) {
        bankonRoot = bankonRoot_;
        switchboard = switchboard_;
        warCouncil = warCouncil_;
        boardroom = boardroom_;
        identity = identity_;
        gate = gate_;
        chains = chains_;
    }

    /// @notice True when the DAIO has at least one living seat and the gate is not paused.
    function isOperational() external view returns (bool) {
        return switchboard.livingSeats() > 0 && !gate.paused();
    }

    function livingSeats() external view returns (uint256) {
        return switchboard.livingSeats();
    }

    function quorum() external view returns (uint256) {
        return switchboard.requiredQuorum();
    }

    function mode() external view returns (WarCouncil.Mode) {
        return warCouncil.effectiveMode();
    }
}
