// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Governed} from "./Governed.sol";

/// @title BankonIdentityRegistry
/// @notice Cryptographic binding of an EVM wallet to a `bankon.eth` subname namehash.
/// @dev Self-service binding uses an EIP-712 signed IdentityClaim — the wallet proves control
///      by signing. Governance (WarCouncil) can force-bind or unbind to resolve disputes. A
///      subname maps to at most one wallet and a wallet to at most one subname. This is the
///      identity primitive the x402 access gate consults for identity-conditioned tiers.
contract BankonIdentityRegistry is Governed {
    bytes32 public immutable DOMAIN_SEPARATOR;
    bytes32 public constant CLAIM_TYPEHASH =
        keccak256("IdentityClaim(address wallet,bytes32 subnameHash,uint256 nonce,uint256 deadline)");

    /// @notice Namehash of the `bankon.eth` root these subnames descend from.
    bytes32 public immutable bankonRoot;

    mapping(address => bytes32) public subnameOf;
    mapping(bytes32 => address) public walletOf;
    mapping(address => uint256) public nonces;

    event IdentityBound(address indexed wallet, bytes32 indexed subnameHash);
    event IdentityUnbound(address indexed wallet, bytes32 indexed subnameHash);

    constructor(address deployer_, bytes32 bankonRoot_) Governed(deployer_) {
        bankonRoot = bankonRoot_;
        DOMAIN_SEPARATOR = keccak256(
            abi.encode(
                keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
                keccak256(bytes("BANKON Identity")),
                keccak256(bytes("1")),
                block.chainid,
                address(this)
            )
        );
    }

    /// @notice Self-service bind: the wallet itself signs an EIP-712 IdentityClaim.
    function bind(address wallet, bytes32 subnameHash, uint256 deadline, uint8 v, bytes32 r, bytes32 s) external {
        require(block.timestamp <= deadline, "expired");
        require(subnameHash != bytes32(0), "subname=0");
        require(walletOf[subnameHash] == address(0), "subname taken");
        require(subnameOf[wallet] == bytes32(0), "already bound");

        uint256 nonce = nonces[wallet]++;
        bytes32 structHash = keccak256(abi.encode(CLAIM_TYPEHASH, wallet, subnameHash, nonce, deadline));
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", DOMAIN_SEPARATOR, structHash));
        address signer = ecrecover(digest, v, r, s);
        require(signer != address(0) && signer == wallet, "bad signature");

        subnameOf[wallet] = subnameHash;
        walletOf[subnameHash] = wallet;
        emit IdentityBound(wallet, subnameHash);
    }

    /// @notice Governance force-bind (dispute resolution / institutional assignment).
    function govBind(address wallet, bytes32 subnameHash) external onlyCouncil {
        require(subnameHash != bytes32(0), "subname=0");
        require(walletOf[subnameHash] == address(0) && subnameOf[wallet] == bytes32(0), "conflict");
        subnameOf[wallet] = subnameHash;
        walletOf[subnameHash] = wallet;
        emit IdentityBound(wallet, subnameHash);
    }

    /// @notice Governance unbind.
    function govUnbind(address wallet) external onlyCouncil {
        bytes32 sn = subnameOf[wallet];
        require(sn != bytes32(0), "not bound");
        delete subnameOf[wallet];
        delete walletOf[sn];
        emit IdentityUnbound(wallet, sn);
    }

    function isBound(address wallet) external view returns (bool) {
        return subnameOf[wallet] != bytes32(0);
    }
}
