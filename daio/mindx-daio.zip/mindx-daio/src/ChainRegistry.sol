// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Governed} from "./Governed.sol";

/// @title ChainRegistry
/// @notice On-chain projection of the AgenticPlace ALLCHAIN mapping (allchain.html) — the
///         "Chain as a Service" directory consumed by AI agents and wallets.
/// @dev RPC and explorer endpoints are stored as keccak pointers rather than raw strings to
///      keep records compact and tamper-evident; the off-chain allchain_sync resolver maps the
///      pointer back to the canonical URL set. Seeded once at deploy with the operational
///      chains, thereafter mutated only by WarCouncil governance.
contract ChainRegistry is Governed {
    struct Chain {
        uint64 chainId;
        bytes32 nameHash;
        bytes32 rpcHash;
        bytes32 explorerHash;
        bytes32 nativeSymbol; // right-padded short symbol, e.g. bytes32("ETH")
        uint8 tier; // service tier
        bool mainnet;
        bool active;
    }

    mapping(uint64 => Chain) public chains;
    uint64[] public chainIds;
    mapping(uint64 => bool) private _known;

    event ChainUpserted(uint64 indexed chainId, bytes32 nameHash, bool mainnet, bool active);
    event ChainActiveSet(uint64 indexed chainId, bool active);

    constructor(address deployer_) Governed(deployer_) {}

    /// @notice Deploy-time bulk seed. Callable once, by deployer, before council wiring.
    function seed(Chain[] calldata cs) external {
        require(msg.sender == deployer && council == address(0), "locked");
        uint256 n = cs.length;
        for (uint256 i; i < n; ++i) {
            _upsert(cs[i]);
        }
    }

    /// @notice Governance upsert of a single chain record.
    function upsert(Chain calldata c) external onlyCouncil {
        _upsert(c);
    }

    /// @notice Governance toggle of a chain's active flag.
    function setActive(uint64 chainId, bool a) external onlyCouncil {
        require(_known[chainId], "unknown");
        chains[chainId].active = a;
        emit ChainActiveSet(chainId, a);
    }

    function _upsert(Chain calldata c) private {
        require(c.chainId != 0, "chainId=0");
        if (!_known[c.chainId]) {
            _known[c.chainId] = true;
            chainIds.push(c.chainId);
        }
        chains[c.chainId] = c;
        emit ChainUpserted(c.chainId, c.nameHash, c.mainnet, c.active);
    }

    function count() external view returns (uint256) {
        return chainIds.length;
    }

    function isKnown(uint64 chainId) external view returns (bool) {
        return _known[chainId];
    }

    function isActive(uint64 chainId) external view returns (bool) {
        return chains[chainId].active;
    }

    function allChainIds() external view returns (uint64[] memory) {
        return chainIds;
    }
}
