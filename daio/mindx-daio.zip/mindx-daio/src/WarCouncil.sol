// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {DeadmansSwitch} from "./DeadmansSwitch.sol";

/// @title WarCouncil
/// @notice Strategic governor of the mindX DAIO. The sole privileged caller of every governed
///         module (identity registry, x402 access gate, chain registry, deadman's switch).
/// @dev Seat eligibility and quorum are read live from the DeadmansSwitch — the council never
///      keeps its own seat list. Proposals support a bounded multi-round negotiation: the
///      proposer may amend target/calldata and advance the round, resetting votes, up to
///      MAX_ROUNDS. There are no admin keys; the council can only change its own mode through
///      a passed proposal that calls back into `setMode`.
contract WarCouncil {
    enum Mode {
        OVERLORD, // normal: passed proposals execute once the voting window closes
        OVERSEER, // cautious: passed proposals enter a timelock before execution
        SHADOW_OVERLORD // continuity: emergency execution with no window/timelock friction
    }

    enum PType {
        STANDARD,
        CONSTITUTIONAL, // forbidden while a single seat is living (dictator protection)
        SWITCH_CONTROL, // forbidden while a single seat is living (dictator protection)
        CHAIN_REGISTRY,
        GATE_CONFIG,
        IDENTITY
    }

    DeadmansSwitch public immutable switchboard;

    Mode public mode;

    uint256 public constant VOTING_WINDOW = 3 days;
    uint256 public constant OVERSEER_TIMELOCK = 2 days;
    uint64 public constant MAX_ROUNDS = 7;
    /// @notice At or below this many living seats the council auto-enters SHADOW continuity.
    uint256 public constant SHADOW_THRESHOLD = 3;

    struct Proposal {
        address proposer;
        address target;
        uint256 value;
        bytes data;
        PType ptype;
        uint64 round;
        uint64 createdAt;
        uint64 deadline;
        uint64 eta; // timelock execution time (OVERSEER), 0 until queued
        uint128 forVotes;
        uint128 againstVotes;
        bool executed;
        bool canceled;
    }

    Proposal[] private _proposals;
    // proposalId => round => seat => voted
    mapping(uint256 => mapping(uint64 => mapping(address => bool))) public hasVoted;

    event Proposed(uint256 indexed id, address indexed proposer, address indexed target, PType ptype);
    event Amended(uint256 indexed id, uint64 round, address target);
    event Voted(uint256 indexed id, address indexed seat, bool support, uint64 round);
    event Queued(uint256 indexed id, uint64 eta);
    event Executed(uint256 indexed id);
    event Canceled(uint256 indexed id);
    event ModeSet(Mode mode);

    modifier onlyAliveSeat() {
        require(switchboard.isAlive(msg.sender), "not living seat");
        _;
    }

    constructor(DeadmansSwitch switchboard_) {
        switchboard = switchboard_;
        mode = Mode.OVERLORD;
    }

    receive() external payable {}

    /// @notice Effective mode, accounting for automatic SHADOW continuity under decimation.
    function effectiveMode() public view returns (Mode) {
        if (switchboard.livingSeats() <= SHADOW_THRESHOLD) return Mode.SHADOW_OVERLORD;
        return mode;
    }

    function propose(address target, uint256 value, bytes calldata data, PType ptype)
        external
        onlyAliveSeat
        returns (uint256 id)
    {
        if (switchboard.livingSeats() == 1) {
            require(ptype != PType.CONSTITUTIONAL && ptype != PType.SWITCH_CONTROL, "dictator protected");
        }
        id = _proposals.length;
        _proposals.push(
            Proposal({
                proposer: msg.sender,
                target: target,
                value: value,
                data: data,
                ptype: ptype,
                round: 0,
                createdAt: uint64(block.timestamp),
                deadline: uint64(block.timestamp + VOTING_WINDOW),
                eta: 0,
                forVotes: 0,
                againstVotes: 0,
                executed: false,
                canceled: false
            })
        );
        emit Proposed(id, msg.sender, target, ptype);
    }

    /// @notice Multi-round negotiation: the proposer revises terms and opens a fresh round.
    function amend(uint256 id, address target, bytes calldata data) external onlyAliveSeat {
        Proposal storage p = _proposals[id];
        require(msg.sender == p.proposer, "only proposer");
        require(!p.executed && !p.canceled, "settled");
        require(p.round + 1 < MAX_ROUNDS, "max rounds");
        p.round += 1;
        p.target = target;
        p.data = data;
        p.forVotes = 0;
        p.againstVotes = 0;
        p.eta = 0;
        p.deadline = uint64(block.timestamp + VOTING_WINDOW);
        emit Amended(id, p.round, target);
    }

    function vote(uint256 id, bool support) external onlyAliveSeat {
        Proposal storage p = _proposals[id];
        require(block.timestamp <= p.deadline, "round closed");
        require(!p.executed && !p.canceled, "settled");
        require(!hasVoted[id][p.round][msg.sender], "voted");
        hasVoted[id][p.round][msg.sender] = true;
        if (support) {
            p.forVotes += 1;
        } else {
            p.againstVotes += 1;
        }
        emit Voted(id, msg.sender, support, p.round);
    }

    /// @notice A proposal passes with quorum support and a simple for>against margin.
    function passed(uint256 id) public view returns (bool) {
        Proposal storage p = _proposals[id];
        if (p.executed || p.canceled) return false;
        uint256 q = switchboard.requiredQuorum();
        return p.forVotes >= q && p.forVotes > p.againstVotes;
    }

    /// @notice Execute a passed proposal, honoring mode-dependent friction.
    /// @dev OVERLORD: executes after the voting window closes. OVERSEER: first call queues an
    ///      execution-time-lock, second call (after eta) executes. SHADOW_OVERLORD: executes
    ///      immediately once passed, no window or timelock — emergency continuity.
    function execute(uint256 id) external payable {
        Proposal storage p = _proposals[id];
        require(!p.executed && !p.canceled, "settled");
        require(passed(id), "not passed");

        Mode m = effectiveMode();
        if (m != Mode.SHADOW_OVERLORD) {
            require(block.timestamp > p.deadline, "voting open");
        }
        if (m == Mode.OVERSEER) {
            if (p.eta == 0) {
                p.eta = uint64(block.timestamp + OVERSEER_TIMELOCK);
                emit Queued(id, p.eta);
                return;
            }
            require(block.timestamp >= p.eta, "timelock");
        }

        p.executed = true;
        (bool ok,) = p.target.call{value: p.value}(p.data);
        require(ok, "exec failed");
        emit Executed(id);
    }

    function cancel(uint256 id) external {
        Proposal storage p = _proposals[id];
        require(!p.executed, "executed");
        require(msg.sender == p.proposer || msg.sender == address(this), "not authorized");
        p.canceled = true;
        emit Canceled(id);
    }

    /// @notice Set the council operating mode. Only reachable through a passed proposal.
    function setMode(Mode m) external {
        require(msg.sender == address(this), "only governance");
        mode = m;
        emit ModeSet(m);
    }

    // --- views ---

    function proposalCount() external view returns (uint256) {
        return _proposals.length;
    }

    function getProposal(uint256 id) external view returns (Proposal memory) {
        return _proposals[id];
    }
}
