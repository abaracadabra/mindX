// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {DeadmansSwitch} from "./DeadmansSwitch.sol";
import {X402AccessGate} from "./X402AccessGate.sol";

/// @title Boardroom
/// @notice Economic chamber of the bicameral mindX DAIO. Where the WarCouncil holds the
///         constitutional/strategic mandate, the Boardroom holds the economic lane: it sets
///         x402 access-tier pricing on the gate.
/// @dev Shares the same seat electorate and dynamic quorum as the WarCouncil via the
///      DeadmansSwitch, but its authority on the gate is scoped (economicGovernor) to pricing
///      only. Resolutions pass on a single round with switch-driven quorum.
contract Boardroom {
    DeadmansSwitch public immutable switchboard;
    X402AccessGate public immutable gate;

    uint256 public constant VOTING_WINDOW = 2 days;

    struct Resolution {
        address proposer;
        uint8 tier;
        uint256 priceMicroUSDC;
        uint64 deadline;
        uint128 forVotes;
        uint128 againstVotes;
        bool enacted;
        bool canceled;
    }

    Resolution[] private _resolutions;
    mapping(uint256 => mapping(address => bool)) public voted;

    event Resolved(uint256 indexed id, address indexed proposer, uint8 tier, uint256 priceMicroUSDC);
    event ResolutionVoted(uint256 indexed id, address indexed seat, bool support);
    event Enacted(uint256 indexed id);
    event ResolutionCanceled(uint256 indexed id);

    modifier onlyAliveSeat() {
        require(switchboard.isAlive(msg.sender), "not living seat");
        _;
    }

    constructor(DeadmansSwitch switchboard_, X402AccessGate gate_) {
        switchboard = switchboard_;
        gate = gate_;
    }

    function proposePrice(uint8 tier, uint256 priceMicroUSDC) external onlyAliveSeat returns (uint256 id) {
        id = _resolutions.length;
        _resolutions.push(
            Resolution({
                proposer: msg.sender,
                tier: tier,
                priceMicroUSDC: priceMicroUSDC,
                deadline: uint64(block.timestamp + VOTING_WINDOW),
                forVotes: 0,
                againstVotes: 0,
                enacted: false,
                canceled: false
            })
        );
        emit Resolved(id, msg.sender, tier, priceMicroUSDC);
    }

    function vote(uint256 id, bool support) external onlyAliveSeat {
        Resolution storage r = _resolutions[id];
        require(block.timestamp <= r.deadline, "closed");
        require(!r.enacted && !r.canceled, "settled");
        require(!voted[id][msg.sender], "voted");
        voted[id][msg.sender] = true;
        if (support) {
            r.forVotes += 1;
        } else {
            r.againstVotes += 1;
        }
        emit ResolutionVoted(id, msg.sender, support);
    }

    function enact(uint256 id) external {
        Resolution storage r = _resolutions[id];
        require(!r.enacted && !r.canceled, "settled");
        require(block.timestamp > r.deadline, "voting open");
        uint256 q = switchboard.requiredQuorum();
        require(r.forVotes >= q && r.forVotes > r.againstVotes, "not passed");
        r.enacted = true;
        gate.setTierPrice(r.tier, r.priceMicroUSDC);
        emit Enacted(id);
    }

    function cancel(uint256 id) external {
        Resolution storage r = _resolutions[id];
        require(!r.enacted, "enacted");
        require(msg.sender == r.proposer, "only proposer");
        r.canceled = true;
        emit ResolutionCanceled(id);
    }

    function resolutionCount() external view returns (uint256) {
        return _resolutions.length;
    }

    function getResolution(uint256 id) external view returns (Resolution memory) {
        return _resolutions[id];
    }
}
