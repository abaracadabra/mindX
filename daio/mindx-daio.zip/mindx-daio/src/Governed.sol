// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

/// @title Governed
/// @notice Minimal governance anchor for DAIO modules under the cypherpunk2048 standard.
/// @dev There are NO admin keys post-deploy and NO upgradeable proxies. The deployer
///      address can perform exactly ONE irreversible action: wiring the module to its
///      governor (the WarCouncil) via `initCouncil`. After that, the deployer holds zero
///      privilege for the life of the contract. All subsequent mutation is gated to the
///      council, which is itself the on-chain DAIO seat electorate.
abstract contract Governed {
    /// @notice Address permitted to perform the one-shot council wiring at deploy time.
    address public immutable deployer;

    /// @notice The governor authorized for privileged mutation. Set once, then immutable in practice.
    address public council;

    error NotDeployer();
    error AlreadyWired();
    error ZeroCouncil();
    error NotCouncil();

    event CouncilWired(address indexed council);

    constructor(address deployer_) {
        require(deployer_ != address(0), "deployer=0");
        deployer = deployer_;
    }

    /// @notice One-shot wiring of the governor. Callable once, only by the deployer.
    function initCouncil(address council_) external {
        if (msg.sender != deployer) revert NotDeployer();
        if (council != address(0)) revert AlreadyWired();
        if (council_ == address(0)) revert ZeroCouncil();
        council = council_;
        emit CouncilWired(council_);
    }

    modifier onlyCouncil() {
        if (msg.sender != council) revert NotCouncil();
        _;
    }
}
