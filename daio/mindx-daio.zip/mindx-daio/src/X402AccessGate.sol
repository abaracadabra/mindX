// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Governed} from "./Governed.sol";
import {BankonIdentityRegistry} from "./BankonIdentityRegistry.sol";

/// @title X402AccessGate
/// @notice EVM-side access ledger for the mindX / AgenticPlace services. Payments settle off
///         this chain on Algorand via the parsec x402-AVM facilitator; the facilitator is the
///         single authorized settlement oracle that records the resulting access grant here,
///         carrying the Algorand transaction id as a cross-chain settlement proof pointer.
/// @dev Two scoped governors under the constitutional/economic split:
///        - council (WarCouncil): facilitator address, pause, identity rules — constitutional.
///        - economicGovernor (Boardroom): per-tier pricing — economic.
///      Conditional privilege gating combines tier height, expiry, identity binding, and the
///      global pause into a single `hasAccess` predicate consumed by the mindX API.
contract X402AccessGate is Governed {
    enum Tier {
        NONE,
        BRONZE,
        SILVER,
        GOLD,
        SOVEREIGN
    }

    BankonIdentityRegistry public immutable identity;

    /// @notice Economic governor (Boardroom). One-shot wired at deploy.
    address public economicGovernor;

    /// @notice parsec x402-AVM facilitator — the only address allowed to record settlements.
    address public facilitator;

    bool public paused;

    struct Grant {
        Tier tier;
        uint64 expiresAt;
        bytes32 algoTxId; // Algorand settlement transaction id (cross-chain proof pointer)
    }

    mapping(address => Grant) public grants;
    mapping(uint8 => bool) public tierRequiresIdentity; // conditional gating rule
    mapping(uint8 => uint256) public priceMicroUSDC; // economic lane (Boardroom)

    event Settled(address indexed user, Tier tier, uint64 expiresAt, bytes32 algoTxId);
    event FacilitatorSet(address indexed facilitator);
    event PausedSet(bool paused);
    event TierPriceSet(uint8 indexed tier, uint256 priceMicroUSDC);
    event TierIdentityRuleSet(uint8 indexed tier, bool requiresIdentity);

    error NotEconomicGovernor();
    error NotFacilitator();

    constructor(address deployer_, BankonIdentityRegistry identity_) Governed(deployer_) {
        identity = identity_;
    }

    /// @notice One-shot wiring of the economic governor (Boardroom), only by deployer.
    function initEconomic(address gov) external {
        require(msg.sender == deployer && economicGovernor == address(0), "wired");
        require(gov != address(0), "zero");
        economicGovernor = gov;
    }

    modifier onlyEconomic() {
        if (msg.sender != economicGovernor) revert NotEconomicGovernor();
        _;
    }

    // --- constitutional lane (WarCouncil) ---

    function setFacilitator(address f) external onlyCouncil {
        facilitator = f;
        emit FacilitatorSet(f);
    }

    function setPaused(bool p) external onlyCouncil {
        paused = p;
        emit PausedSet(p);
    }

    function setTierIdentityRule(uint8 tier, bool requiresIdentity) external onlyCouncil {
        tierRequiresIdentity[tier] = requiresIdentity;
        emit TierIdentityRuleSet(tier, requiresIdentity);
    }

    // --- economic lane (Boardroom) ---

    function setTierPrice(uint8 tier, uint256 priceMicroUSDC_) external onlyEconomic {
        priceMicroUSDC[tier] = priceMicroUSDC_;
        emit TierPriceSet(tier, priceMicroUSDC_);
    }

    // --- parsec facilitator settlement (Algorand x402 -> EVM record) ---

    function recordSettlement(address user, Tier tier, uint64 expiresAt, bytes32 algoTxId) external {
        if (msg.sender != facilitator) revert NotFacilitator();
        require(!paused, "paused");
        require(tier != Tier.NONE && expiresAt > block.timestamp, "bad grant");
        grants[user] = Grant(tier, expiresAt, algoTxId);
        emit Settled(user, tier, expiresAt, algoTxId);
    }

    // --- conditional privilege gating (read by mindX API) ---

    function hasAccess(address user, Tier required) public view returns (bool) {
        if (paused) return false;
        Grant memory g = grants[user];
        if (uint8(g.tier) < uint8(required)) return false;
        if (g.expiresAt <= block.timestamp) return false;
        if (tierRequiresIdentity[uint8(required)] && !identity.isBound(user)) return false;
        return true;
    }

    function tierOf(address user) external view returns (Tier) {
        Grant memory g = grants[user];
        if (g.expiresAt <= block.timestamp) return Tier.NONE;
        return g.tier;
    }
}
