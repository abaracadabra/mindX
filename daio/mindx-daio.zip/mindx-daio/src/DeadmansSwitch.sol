// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Governed} from "./Governed.sol";

/// @title DeadmansSwitch
/// @notice Continuity engine for the mindX DAIO War Council.
/// @dev Each council seat must emit a heartbeat at least once per 2-moon window. Seats that
///      fall silent are excluded from the *living* set, which shrinks the dynamic quorum from
///      a maximum of 13 seats down to 1. At a single living seat that seat becomes the
///      "protected dictator": it can act, but the WarCouncil forbids it from dismantling the
///      switch or amending the constitution, preserving the path back to plural governance.
///      This is a continuity mechanism, not a death switch — a silent seat may heartbeat again
///      to revive, unless governance has permanently revoked it.
contract DeadmansSwitch is Governed {
    /// @notice Maximum number of council seats.
    uint256 public constant MAX_SEATS = 13;

    /// @notice One synodic month in seconds (~29.53 days).
    uint256 public constant MOON = 2_551_443;

    /// @notice The 2-moon dead window. A seat silent longer than this is non-living.
    uint256 public constant HEARTBEAT_WINDOW = 2 * MOON;

    address[] private _seats;
    mapping(address => bool) public isSeat;
    mapping(address => uint256) public lastSeen;
    mapping(address => bool) public revoked;

    event SeatAdded(address indexed seat);
    event SeatRevoked(address indexed seat);
    event Heartbeat(address indexed seat, uint256 at);

    constructor(address deployer_, address[] memory initialSeats) Governed(deployer_) {
        uint256 n = initialSeats.length;
        require(n > 0 && n <= MAX_SEATS, "seat count");
        for (uint256 i; i < n; ++i) {
            address s = initialSeats[i];
            require(s != address(0) && !isSeat[s], "bad/dup seat");
            isSeat[s] = true;
            _seats.push(s);
            lastSeen[s] = block.timestamp;
            emit SeatAdded(s);
        }
    }

    /// @notice Refresh the caller's heartbeat. Any active (non-revoked) seat may call.
    function heartbeat() external {
        require(isSeat[msg.sender] && !revoked[msg.sender], "not active seat");
        lastSeen[msg.sender] = block.timestamp;
        emit Heartbeat(msg.sender, block.timestamp);
    }

    /// @notice True if `s` is a seat that has heartbeat within the 2-moon window.
    function isAlive(address s) public view returns (bool) {
        if (!isSeat[s] || revoked[s]) return false;
        return block.timestamp - lastSeen[s] <= HEARTBEAT_WINDOW;
    }

    /// @notice Count of currently living seats.
    function livingSeats() public view returns (uint256 n) {
        uint256 len = _seats.length;
        for (uint256 i; i < len; ++i) {
            if (isAlive(_seats[i])) ++n;
        }
    }

    function totalSeats() external view returns (uint256) {
        return _seats.length;
    }

    function seats() external view returns (address[] memory) {
        return _seats;
    }

    /// @notice Dynamic quorum: simple majority of the living seats.
    /// @dev Scales 7 (at 13 living) down to 1 (at 1 living). When zero seats are living the
    ///      DAIO is frozen and no proposal can ever reach quorum.
    function requiredQuorum() public view returns (uint256) {
        uint256 n = livingSeats();
        if (n == 0) return type(uint256).max;
        return n / 2 + 1;
    }

    /// @notice True when exactly one seat is living and it is `s` (the protected dictator).
    function isProtectedDictator(address s) external view returns (bool) {
        return livingSeats() == 1 && isAlive(s);
    }

    // --- governance (WarCouncil) seat management ---

    /// @notice Add a brand new seat or re-seat a revoked address. Resets its heartbeat.
    function addSeat(address s) external onlyCouncil {
        require(s != address(0) && _seats.length < MAX_SEATS, "max/zero");
        require(!isSeat[s], "exists");
        isSeat[s] = true;
        revoked[s] = false;
        _seats.push(s);
        lastSeen[s] = block.timestamp;
        emit SeatAdded(s);
    }

    /// @notice Permanently revoke a seat. A revoked seat can never be alive again unless re-added.
    function revokeSeat(address s) external onlyCouncil {
        require(isSeat[s] && !revoked[s], "no live seat");
        revoked[s] = true;
        emit SeatRevoked(s);
    }
}
