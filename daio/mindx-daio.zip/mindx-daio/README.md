# mindX DAIO — on-chain deployment

Sovereign on-chain governance + access layer binding the three live BANKON services into a
single bicameral DAIO with `bankon.eth` as its constitutional identity:

| Service | URL | Role on-chain |
|---|---|---|
| AgenticPlace | agenticplace.pythai.net | ALLCHAIN map → `ChainRegistry` |
| mindX | mindx.pythai.net (API) | reads `X402AccessGate.hasAccess` to gate API calls |
| BANKON | bankon.pythai.net | `bankon.eth` identity root → `BankonIdentityRegistry` |

Payments settle off-chain on **Algorand mainnet** through the **parsec** x402-AVM facilitator;
the facilitator is the sole authorized oracle that records the resulting access grant on the
EVM gate, carrying the Algorand transaction id as a cross-chain settlement proof pointer.

Built to the **cypherpunk2048** standard: Apache-2.0, `(c) 2026 BANKON` headers, **no admin
keys post-deploy**, **no upgradeable proxies**, mainnet-only targets, solc **0.8.26**, Foundry
canonical. The deployer's only privileged action is a one-shot wiring; afterward it holds zero
power for the life of the contracts.

## Architecture

```
                          Daio  (immutable root, no privilege — discovery + status)
                            │
      ┌───────────┬─────────┼───────────┬──────────────┬───────────────┐
 DeadmansSwitch  WarCouncil  Boardroom  BankonIdentity  X402AccessGate  ChainRegistry
 (continuity)   (constit.)  (economic) Registry         (access ledger) (ALLCHAIN)
      │              │           │           │                │  ▲
      │  quorum/seats│           │           │ identity rule  │  │ recordSettlement
      └──────────────┴───────────┘           └────────────────┘  │ (only parsec)
                                                                  │
                                          parsec x402-AVM facilitator
                                          (Algorand mainnet ── USDC ASA)
```

**Bicameral governance over one electorate.** Seats and quorum live in `DeadmansSwitch`; both
chambers read them live.
- **WarCouncil** (constitutional/strategic): the only privileged caller of every governed
  module. Multi-round negotiable proposals (`amend` resets votes, up to 7 rounds), three modes
  — OVERLORD (execute after window), OVERSEER (timelock), SHADOW_OVERLORD (emergency, no
  friction). Auto-enters SHADOW at ≤3 living seats.
- **Boardroom** (economic): scoped to x402 tier pricing only (`economicGovernor` on the gate).

**Continuity.** `DeadmansSwitch` runs a 2-moon (≈59-day) heartbeat window. Quorum scales with
living seats (n/2+1); the registry freezes at zero living seats. A lone surviving seat becomes a
**protected dictator** — it can act on standard matters but cannot touch the constitution or the
switch itself.

**Conditional privilege gating.** `X402AccessGate.hasAccess(user, tier)` combines tier height,
grant non-expiry, the global pause, and — for identity-conditioned tiers — a live `bankon.eth`
binding. This single predicate is what the mindX API calls per request.

**Identity.** `BankonIdentityRegistry` binds a wallet to a `bankon.eth` subname namehash. Wallets
self-bind with an EIP-712 `IdentityClaim` signature; governance can force-bind/unbind for disputes.

## Contracts (`src/`)

| Contract | Purpose |
|---|---|
| `Governed.sol` | one-shot `initCouncil` wiring; zero deployer privilege after |
| `DeadmansSwitch.sol` | seats, 2-moon heartbeat, dynamic quorum, dictator protection |
| `WarCouncil.sol` | constitutional governor; multi-round proposals; 3 modes |
| `Boardroom.sol` | economic governor; x402 tier pricing |
| `BankonIdentityRegistry.sol` | EIP-712 `bankon.eth` wallet binding |
| `X402AccessGate.sol` | access ledger; parsec settlement recorder; `hasAccess` gate |
| `ChainRegistry.sol` | on-chain ALLCHAIN projection (keccak URL pointers) |
| `Daio.sol` | immutable root: module discovery + aggregate status |

## Build & test (Foundry)

```bash
forge install foundry-rs/forge-std
forge build            # solc 0.8.26, optimizer 200, evm cancun
forge test -vvv
```

Coverage: `DeadmansSwitch` (dynamic quorum, dictator, freeze/revival), `WarCouncil` (quorum,
multi-round amend, OVERSEER timelock, SHADOW auto-execute, dictator protection), `X402AccessGate`
(settlement, expiry, pause, identity-conditioned tiers, scoped governors), `BankonIdentityRegistry`
(EIP-712 bind, bad-signer, replay/taken, gov bind/unbind), `ChainRegistry` (seed-then-lock,
governance upsert), `Boardroom` (price resolutions), and `Integration` (end-to-end x402→access→
identity, deployer-renounced, SHADOW continuity).

> The container used to author this could not install Foundry (release host blocked), so `src/`
> was verified to compile clean with solc 0.8.26 via `script/compile_check.js`. Run `forge test`
> locally for the suite.

## Deploy (mainnet)

```bash
cp .env.example .env       # fill PRIVATE_KEY, RPCs, BANKON_ROOT, INITIAL_SEATS, PARSEC_FACILITATOR
forge script script/DeployMainnet.s.sol:DeployMainnet \
  --rpc-url $ETHEREUM_RPC_URL --broadcast --verify
```

The script deploys all seven contracts, seeds the ALLCHAIN registry from `script/chains.json`
(Ethereum, Polygon, Moonbeam; Arc Testnet as inactive reference), performs the one-shot wiring
(`initCouncil` ×4 + `initEconomic`), and renounces. The parsec facilitator is installed
**afterward via a WarCouncil proposal** calling `gate.setFacilitator` — never as a deploy-time
admin key.

## Integration layer (`integration/`)

```bash
pip install -r integration/requirements.txt
```

- **`parsec_facilitator.py`** — the x402-AVM facilitator. `verify` → `settle` on Algorand
  (`exact` scheme, mainnet CAIP-2 `algorand:wGHE2…it8=`) → `record_grant` on the EVM gate.
  Refuses to record unless it is the council-authorized facilitator.
- **`mindx_bridge.py`** — drop-in replacement for the mindX `X402Gateway.authorize` and
  `BankonIdentityService.resolve` stubs; both now read on-chain state.
- **`allchain_sync.py`** — pulls the ALLCHAIN feed, builds `ChainRegistry` records + a local
  keccak-pointer→URL map, and emits WarCouncil `upsert` calldata (post-deploy mutation is
  governance-only).

## x402 payment flow

1. mindX endpoint returns `402` + `paymentRequirements` (scheme `exact`, Algorand mainnet, USDC ASA, payTo BANKON treasury).
2. Client signs an Algorand payment group → `X-PAYMENT` header.
3. parsec `verify` + `settle` on Algorand → confirmed txid.
4. parsec `recordSettlement(user, tier, expiresAt, algoTxId)` on the gate.
5. mindX calls `hasAccess(user, tier)` per request; SOVEREIGN additionally requires a bound `bankon.eth` identity.
