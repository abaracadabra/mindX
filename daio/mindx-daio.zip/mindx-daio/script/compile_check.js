const fs = require("fs");
const path = require("path");
const solc = require("/home/claude/solctest/node_modules/solc");

const SRC = "/home/claude/mindx-daio/src";

function readSources(dir) {
  const out = {};
  for (const f of fs.readdirSync(dir)) {
    if (f.endsWith(".sol")) {
      out[f] = { content: fs.readFileSync(path.join(dir, f), "utf8") };
    }
  }
  return out;
}

function findImports(importPath) {
  // imports are like "./Governed.sol"
  const base = importPath.replace(/^\.\//, "");
  const full = path.join(SRC, base);
  if (fs.existsSync(full)) {
    return { contents: fs.readFileSync(full, "utf8") };
  }
  return { error: "File not found: " + importPath };
}

const input = {
  language: "Solidity",
  sources: readSources(SRC),
  settings: {
    optimizer: { enabled: true, runs: 200 },
    evmVersion: "cancun",
    outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
  },
};

const output = JSON.parse(
  solc.compile(JSON.stringify(input), { import: findImports })
);

let hasError = false;
if (output.errors) {
  for (const e of output.errors) {
    if (e.severity === "error") hasError = true;
    console.log(`[${e.severity}] ${e.formattedMessage}`);
  }
}
if (!hasError) {
  console.log("=== COMPILE CLEAN (solc " + solc.version() + ") ===");
  for (const file in output.contracts) {
    for (const name in output.contracts[file]) {
      const bc = output.contracts[file][name].evm.bytecode.object;
      console.log(`  ${name}: ${bc.length / 2} bytes`);
    }
  }
}
process.exit(hasError ? 1 : 0);
