// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Script, console2} from "forge-std/Script.sol";
import {DeadmansSwitch} from "../src/DeadmansSwitch.sol";
import {WarCouncil} from "../src/WarCouncil.sol";
import {Boardroom} from "../src/Boardroom.sol";
import {BankonIdentityRegistry} from "../src/BankonIdentityRegistry.sol";
import {X402AccessGate} from "../src/X402AccessGate.sol";
import {ChainRegistry} from "../src/ChainRegistry.sol";
import {Daio} from "../src/Daio.sol";

/// @title DeployMainnet
/// @notice Single-transaction-batch deploy of the mindX DAIO. After this script the deployer
///         holds zero privilege (all `initCouncil`/`initEconomic`/`seed` one-shots are spent).
/// @dev cypherpunk2048: mainnet-only, no proxies, no retained admin. Run with:
///        forge script script/DeployMainnet.s.sol:DeployMainnet \
///          --rpc-url $ETHEREUM_RPC_URL --broadcast --verify
contract DeployMainnet is Script {
    function run() external {
        uint256 pk = vm.envUint("PRIVATE_KEY");
        bytes32 bankonRoot = vm.envBytes32("BANKON_ROOT");
        address[] memory seats = vm.envAddress("INITIAL_SEATS", ",");
        address facilitator = vm.envAddress("PARSEC_FACILITATOR");
        address deployer = vm.addr(pk);

        vm.startBroadcast(pk);

        // 1. Continuity switch (holds the seat electorate).
        DeadmansSwitch switchboard = new DeadmansSwitch(deployer, seats);

        // 2. Strategic governor.
        WarCouncil warCouncil = new WarCouncil(switchboard);

        // 3. Identity registry bound to bankon.eth.
        BankonIdentityRegistry identity = new BankonIdentityRegistry(deployer, bankonRoot);

        // 4. x402 access gate (consults identity).
        X402AccessGate gate = new X402AccessGate(deployer, identity);

        // 5. ALLCHAIN registry.
        ChainRegistry chains = new ChainRegistry(deployer);

        // 6. Economic chamber (scoped to gate pricing).
        Boardroom boardroom = new Boardroom(switchboard, gate);

        // 7. Immutable orchestrator.
        Daio daio = new Daio(bankonRoot, switchboard, warCouncil, boardroom, identity, gate, chains);

        // 8. Seed ALLCHAIN before wiring (deployer one-shot).
        _seedChains(chains);

        // 9. One-shot wiring; spends every deployer privilege.
        switchboard.initCouncil(address(warCouncil));
        identity.initCouncil(address(warCouncil));
        gate.initCouncil(address(warCouncil));
        chains.initCouncil(address(warCouncil));
        gate.initEconomic(address(boardroom));

        vm.stopBroadcast();

        console2.log("Daio:                  ", address(daio));
        console2.log("DeadmansSwitch:        ", address(switchboard));
        console2.log("WarCouncil:            ", address(warCouncil));
        console2.log("Boardroom:             ", address(boardroom));
        console2.log("BankonIdentityRegistry:", address(identity));
        console2.log("X402AccessGate:        ", address(gate));
        console2.log("ChainRegistry:         ", address(chains));
        console2.log("parsec facilitator must be set by WarCouncil governance via gate.setFacilitator():", facilitator);
    }

    /// @notice Seed the operational ALLCHAIN set. URLs are hashed; allchain_sync resolves them.
    function _seedChains(ChainRegistry chains) internal {
        ChainRegistry.Chain[] memory cs = new ChainRegistry.Chain[](4);

        cs[0] = ChainRegistry.Chain({
            chainId: 1,
            nameHash: keccak256("Ethereum"),
            rpcHash: keccak256("https://eth.llamarpc.com"),
            explorerHash: keccak256("https://etherscan.io"),
            nativeSymbol: bytes32("ETH"),
            tier: 1,
            mainnet: true,
            active: true
        });
        cs[1] = ChainRegistry.Chain({
            chainId: 137,
            nameHash: keccak256("Polygon"),
            rpcHash: keccak256("https://polygon-rpc.com"),
            explorerHash: keccak256("https://polygonscan.com"),
            nativeSymbol: bytes32("POL"),
            tier: 1,
            mainnet: true,
            active: true
        });
        cs[2] = ChainRegistry.Chain({
            chainId: 1284,
            nameHash: keccak256("Moonbeam"),
            rpcHash: keccak256("https://rpc.api.moonbeam.network"),
            explorerHash: keccak256("https://moonbeam.moonscan.io"),
            nativeSymbol: bytes32("GLMR"),
            tier: 1,
            mainnet: true,
            active: true
        });
        cs[3] = ChainRegistry.Chain({
            chainId: 5042002,
            nameHash: keccak256("Arc Testnet"),
            rpcHash: keccak256("https://rpc.arc-testnet.pythai.net"),
            explorerHash: keccak256("https://explorer.arc-testnet.pythai.net"),
            nativeSymbol: bytes32("ARC"),
            tier: 3,
            mainnet: false,
            active: false
        });

        chains.seed(cs);
    }
}
