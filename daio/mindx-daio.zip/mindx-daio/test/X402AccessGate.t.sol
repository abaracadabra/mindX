// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Base} from "./Base.t.sol";
import {WarCouncil} from "../src/WarCouncil.sol";
import {X402AccessGate} from "../src/X402AccessGate.sol";

contract X402AccessGateTest is Base {
    address internal user = address(0xBEEF);

    function _setFacilitator(address f) internal {
        _govExecute(
            address(gate),
            abi.encodeCall(X402AccessGate.setFacilitator, (f)),
            WarCouncil.PType.GATE_CONFIG
        );
    }

    function _setPaused(bool p) internal {
        _govExecute(
            address(gate),
            abi.encodeCall(X402AccessGate.setPaused, (p)),
            WarCouncil.PType.GATE_CONFIG
        );
    }

    function _setIdentityRule(uint8 tier, bool req) internal {
        _govExecute(
            address(gate),
            abi.encodeCall(X402AccessGate.setTierIdentityRule, (tier, req)),
            WarCouncil.PType.GATE_CONFIG
        );
    }

    function testFacilitatorSetViaGovernance() public {
        _setFacilitator(facilitator);
        assertEq(gate.facilitator(), facilitator);
    }

    function testSettlementGrantsAccess() public {
        _setFacilitator(facilitator);
        vm.prank(facilitator);
        gate.recordSettlement(user, X402AccessGate.Tier.GOLD, uint64(block.timestamp + 30 days), bytes32("ALGOTX1"));

        assertTrue(gate.hasAccess(user, X402AccessGate.Tier.BRONZE));
        assertTrue(gate.hasAccess(user, X402AccessGate.Tier.GOLD));
        assertFalse(gate.hasAccess(user, X402AccessGate.Tier.SOVEREIGN));
        assertEq(uint8(gate.tierOf(user)), uint8(X402AccessGate.Tier.GOLD));
    }

    function testOnlyFacilitatorCanSettle() public {
        _setFacilitator(facilitator);
        vm.expectRevert(X402AccessGate.NotFacilitator.selector);
        gate.recordSettlement(user, X402AccessGate.Tier.GOLD, uint64(block.timestamp + 1 days), bytes32(0));
    }

    function testExpiredGrantDeniesAccess() public {
        _setFacilitator(facilitator);
        uint64 exp = uint64(block.timestamp + 1 days);
        vm.prank(facilitator);
        gate.recordSettlement(user, X402AccessGate.Tier.SILVER, exp, bytes32("X"));

        assertTrue(gate.hasAccess(user, X402AccessGate.Tier.SILVER));
        vm.warp(uint256(exp) + 1);
        assertFalse(gate.hasAccess(user, X402AccessGate.Tier.SILVER));
        assertEq(uint8(gate.tierOf(user)), uint8(X402AccessGate.Tier.NONE));
    }

    function testPauseBlocksAccessAndSettlement() public {
        _setFacilitator(facilitator);
        vm.prank(facilitator);
        gate.recordSettlement(user, X402AccessGate.Tier.GOLD, uint64(block.timestamp + 30 days), bytes32("X"));
        assertTrue(gate.hasAccess(user, X402AccessGate.Tier.GOLD));

        _setPaused(true);
        assertFalse(gate.hasAccess(user, X402AccessGate.Tier.GOLD));

        vm.prank(facilitator);
        vm.expectRevert(bytes("paused"));
        gate.recordSettlement(user, X402AccessGate.Tier.GOLD, uint64(block.timestamp + 30 days), bytes32("Y"));
    }

    function testIdentityConditionedTier() public {
        _setFacilitator(facilitator);
        _setIdentityRule(uint8(X402AccessGate.Tier.SOVEREIGN), true);

        vm.prank(facilitator);
        gate.recordSettlement(user, X402AccessGate.Tier.SOVEREIGN, uint64(block.timestamp + 30 days), bytes32("X"));

        // tier height satisfied but identity not bound -> denied at SOVEREIGN
        assertFalse(gate.hasAccess(user, X402AccessGate.Tier.SOVEREIGN));
        // lower tier without identity rule still granted
        assertTrue(gate.hasAccess(user, X402AccessGate.Tier.GOLD));

        // governance binds identity, now SOVEREIGN passes
        bytes32 sn = keccak256("sovereign.bankon.eth");
        _govExecute(
            address(identity),
            abi.encodeCall(identity.govBind, (user, sn)),
            WarCouncil.PType.IDENTITY
        );
        assertTrue(gate.hasAccess(user, X402AccessGate.Tier.SOVEREIGN));
    }

    function testEconomicLaneRejectsCouncilCaller() public {
        // setTierPrice is economicGovernor (Boardroom) only; a council-routed call must revert.
        vm.expectRevert(); // inner NotEconomicGovernor bubbles as exec failed
        _govExecute(
            address(gate),
            abi.encodeCall(X402AccessGate.setTierPrice, (uint8(X402AccessGate.Tier.GOLD), 1_000_000)),
            WarCouncil.PType.GATE_CONFIG
        );
    }

    function testConstitutionalLaneRejectsBoardroomCaller() public {
        // Boardroom has no path to setFacilitator; direct prank as boardroom reverts NotCouncil.
        vm.prank(address(boardroom));
        vm.expectRevert();
        gate.setFacilitator(facilitator);
    }

    function testInitEconomicOnlyOnce() public {
        vm.expectRevert(bytes("wired"));
        gate.initEconomic(address(0x1234));
    }
}
