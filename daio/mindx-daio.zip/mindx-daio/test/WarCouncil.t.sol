// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Base} from "./Base.t.sol";
import {WarCouncil} from "../src/WarCouncil.sol";
import {X402AccessGate} from "../src/X402AccessGate.sol";

contract WarCouncilTest is Base {
    function test_proposeVoteExecuteOverlord() public {
        bytes memory data = abi.encodeCall(X402AccessGate.setPaused, (true));
        uint256 id = _propose(address(gate), data, WarCouncil.PType.GATE_CONFIG);
        _voteFor(id, 7);
        assertTrue(council.passed(id));
        vm.warp(block.timestamp + council.VOTING_WINDOW() + 1);
        council.execute(id);
        assertTrue(gate.paused());
    }

    function test_failsBelowQuorum() public {
        bytes memory data = abi.encodeCall(X402AccessGate.setPaused, (true));
        uint256 id = _propose(address(gate), data, WarCouncil.PType.GATE_CONFIG);
        _voteFor(id, 6); // quorum is 7
        assertFalse(council.passed(id));
        vm.warp(block.timestamp + council.VOTING_WINDOW() + 1);
        vm.expectRevert(bytes("not passed"));
        council.execute(id);
    }

    function test_cannotExecuteWhileVotingOpen() public {
        bytes memory data = abi.encodeCall(X402AccessGate.setPaused, (true));
        uint256 id = _propose(address(gate), data, WarCouncil.PType.GATE_CONFIG);
        _voteFor(id, 7);
        vm.expectRevert(bytes("voting open"));
        council.execute(id);
    }

    function test_multiRoundAmendResetsVotes() public {
        bytes memory data = abi.encodeCall(X402AccessGate.setPaused, (true));
        uint256 id = _propose(address(gate), data, WarCouncil.PType.GATE_CONFIG);
        _voteFor(id, 7); // round 0 has quorum
        // proposer amends -> round 1, votes reset
        vm.prank(seats[0]);
        council.amend(id, address(gate), abi.encodeCall(X402AccessGate.setPaused, (false)));
        assertFalse(council.passed(id)); // votes were cleared
        _voteFor(id, 7); // re-vote round 1
        vm.warp(block.timestamp + council.VOTING_WINDOW() + 1);
        council.execute(id);
        assertFalse(gate.paused()); // executed the amended (false) call
    }

    function test_overseerTimelock() public {
        // 1) governance switches mode to OVERSEER
        _govExecute(
            address(council),
            abi.encodeCall(WarCouncil.setMode, (WarCouncil.Mode.OVERSEER)),
            WarCouncil.PType.CONSTITUTIONAL
        );
        assertEq(uint8(council.mode()), uint8(WarCouncil.Mode.OVERSEER));

        // 2) a new proposal must queue then wait the timelock
        bytes memory data = abi.encodeCall(X402AccessGate.setPaused, (true));
        uint256 id = _propose(address(gate), data, WarCouncil.PType.GATE_CONFIG);
        _voteFor(id, 7);
        vm.warp(block.timestamp + council.VOTING_WINDOW() + 1);

        council.execute(id); // queues, sets eta, returns
        assertFalse(gate.paused());
        vm.expectRevert(bytes("timelock"));
        council.execute(id);

        vm.warp(block.timestamp + council.OVERSEER_TIMELOCK());
        council.execute(id);
        assertTrue(gate.paused());
    }

    function test_shadowAutoExecutesImmediately() public {
        keepAliveOnly(3); // <= SHADOW_THRESHOLD -> effective SHADOW_OVERLORD, quorum 2
        assertEq(uint8(council.effectiveMode()), uint8(WarCouncil.Mode.SHADOW_OVERLORD));

        bytes memory data = abi.encodeCall(X402AccessGate.setPaused, (true));
        uint256 id = _propose(address(gate), data, WarCouncil.PType.GATE_CONFIG);
        _voteFor(id, 2);
        // no warp past deadline — shadow mode executes once passed
        council.execute(id);
        assertTrue(gate.paused());
    }

    function test_dictatorCannotTouchConstitution() public {
        keepAliveOnly(1);
        vm.prank(seats[0]);
        vm.expectRevert(bytes("dictator protected"));
        council.propose(address(council), "", WarCouncil.PType.CONSTITUTIONAL);
    }

    function test_dictatorCanActOnStandard() public {
        keepAliveOnly(1); // quorum 1, shadow mode
        bytes memory data = abi.encodeCall(X402AccessGate.setPaused, (true));
        uint256 id = _propose(address(gate), data, WarCouncil.PType.GATE_CONFIG);
        _voteFor(id, 1);
        council.execute(id);
        assertTrue(gate.paused());
    }

    function test_onlyLivingSeatCanPropose() public {
        keepAliveOnly(3);
        vm.prank(seats[12]); // dead seat
        vm.expectRevert(bytes("not living seat"));
        council.propose(address(gate), "", WarCouncil.PType.STANDARD);
    }

    function test_setModeOnlyViaGovernance() public {
        vm.expectRevert(bytes("only governance"));
        council.setMode(WarCouncil.Mode.OVERSEER);
    }
}
