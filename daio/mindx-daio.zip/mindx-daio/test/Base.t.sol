// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Test} from "forge-std/Test.sol";
import {DeadmansSwitch} from "../src/DeadmansSwitch.sol";
import {WarCouncil} from "../src/WarCouncil.sol";
import {Boardroom} from "../src/Boardroom.sol";
import {BankonIdentityRegistry} from "../src/BankonIdentityRegistry.sol";
import {X402AccessGate} from "../src/X402AccessGate.sol";
import {ChainRegistry} from "../src/ChainRegistry.sol";
import {Daio} from "../src/Daio.sol";

/// @dev Shared deploy harness mirroring DeployMainnet, with seat/heartbeat/governance helpers.
contract Base is Test {
    DeadmansSwitch internal switchboard;
    WarCouncil internal council;
    Boardroom internal boardroom;
    BankonIdentityRegistry internal identity;
    X402AccessGate internal gate;
    ChainRegistry internal chains;
    Daio internal daio;

    uint256 internal constant N = 13;
    uint256[] internal seatPk;
    address[] internal seats;
    bytes32 internal constant BANKON_ROOT = keccak256("bankon.eth");
    address internal facilitator = address(0xFAC11);

    function setUp() public virtual {
        for (uint256 i = 1; i <= N; ++i) {
            seatPk.push(i);
            seats.push(vm.addr(i));
        }

        switchboard = new DeadmansSwitch(address(this), seats);
        council = new WarCouncil(switchboard);
        identity = new BankonIdentityRegistry(address(this), BANKON_ROOT);
        gate = new X402AccessGate(address(this), identity);
        chains = new ChainRegistry(address(this));
        boardroom = new Boardroom(switchboard, gate);
        daio = new Daio(BANKON_ROOT, switchboard, council, boardroom, identity, gate, chains);

        switchboard.initCouncil(address(council));
        identity.initCouncil(address(council));
        gate.initCouncil(address(council));
        chains.initCouncil(address(council));
        gate.initEconomic(address(boardroom));
    }

    // --- helpers ---

    /// @dev Leave only the first `k` seats living; the rest fall past the 2-moon window.
    function keepAliveOnly(uint256 k) internal {
        vm.warp(block.timestamp + switchboard.HEARTBEAT_WINDOW());
        for (uint256 i; i < k; ++i) {
            vm.prank(seats[i]);
            switchboard.heartbeat();
        }
        vm.warp(block.timestamp + 1);
    }

    function _propose(address target, bytes memory data, WarCouncil.PType ptype) internal returns (uint256 id) {
        vm.prank(seats[0]);
        id = council.propose(target, 0, data, ptype);
    }

    function _voteFor(uint256 id, uint256 count) internal {
        for (uint256 i; i < count; ++i) {
            vm.prank(seats[i]);
            council.vote(id, true);
        }
    }

    /// @dev Propose, reach quorum, close the window, and execute (OVERLORD path).
    function _govExecute(address target, bytes memory data, WarCouncil.PType ptype) internal {
        uint256 q = switchboard.requiredQuorum();
        uint256 id = _propose(target, data, ptype);
        _voteFor(id, q);
        vm.warp(block.timestamp + council.VOTING_WINDOW() + 1);
        council.execute(id);
    }
}
