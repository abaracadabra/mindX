// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Base} from "./Base.t.sol";
import {WarCouncil} from "../src/WarCouncil.sol";
import {ChainRegistry} from "../src/ChainRegistry.sol";

contract ChainRegistryTest is Base {
    function _chain(uint64 id, string memory name, bool mainnet, bool active)
        internal
        pure
        returns (ChainRegistry.Chain memory)
    {
        return ChainRegistry.Chain({
            chainId: id,
            nameHash: keccak256(bytes(name)),
            rpcHash: keccak256(bytes(string.concat("rpc:", name))),
            explorerHash: keccak256(bytes(string.concat("exp:", name))),
            nativeSymbol: bytes32(bytes("SYM")),
            tier: 1,
            mainnet: mainnet,
            active: active
        });
    }

    function testFreshSeedThenLockedAfterWiring() public {
        ChainRegistry reg = new ChainRegistry(address(this));

        ChainRegistry.Chain[] memory cs = new ChainRegistry.Chain[](2);
        cs[0] = _chain(1, "Ethereum", true, true);
        cs[1] = _chain(137, "Polygon", true, true);
        reg.seed(cs);

        assertEq(reg.count(), 2);
        assertTrue(reg.isKnown(1));
        assertTrue(reg.isActive(137));

        // wire council, then seed is permanently locked
        reg.initCouncil(address(council));
        ChainRegistry.Chain[] memory more = new ChainRegistry.Chain[](1);
        more[0] = _chain(1284, "Moonbeam", true, true);
        vm.expectRevert(bytes("locked"));
        reg.seed(more);
    }

    function testGovernanceUpsertAndSetActive() public {
        // Base's `chains` registry already wired to council, unseeded.
        ChainRegistry.Chain memory c = _chain(1284, "Moonbeam", true, true);
        _govExecute(
            address(chains),
            abi.encodeCall(chains.upsert, (c)),
            WarCouncil.PType.CHAIN_REGISTRY
        );
        assertTrue(chains.isKnown(1284));
        assertTrue(chains.isActive(1284));
        assertEq(chains.count(), 1);

        _govExecute(
            address(chains),
            abi.encodeCall(chains.setActive, (uint64(1284), false)),
            WarCouncil.PType.CHAIN_REGISTRY
        );
        assertFalse(chains.isActive(1284));
    }

    function testDirectUpsertRejectedFromNonCouncil() public {
        ChainRegistry.Chain memory c = _chain(5042002, "Arc Testnet", false, true);
        vm.expectRevert();
        chains.upsert(c);
    }
}
