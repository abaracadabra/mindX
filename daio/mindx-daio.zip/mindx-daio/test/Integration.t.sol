// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Base} from "./Base.t.sol";
import {Governed} from "../src/Governed.sol";
import {WarCouncil} from "../src/WarCouncil.sol";
import {X402AccessGate} from "../src/X402AccessGate.sol";

/// @dev Exercises the full AgenticPlace + mindX + BANKON loop the off-chain services consume:
///      WarCouncil installs the parsec facilitator, an Algorand x402 settlement is recorded,
///      the mindX API reads access, and a SOVEREIGN tier is gated on bankon.eth identity.
contract IntegrationTest is Base {
    address internal subscriber = address(0xC0DE);
    uint256 internal subscriberPk = 0xC0DE;

    function testFullX402SettlementToAccessFlow() public {
        // 1. WarCouncil (constitutional lane) installs the parsec x402-AVM facilitator.
        _govExecute(
            address(gate),
            abi.encodeCall(X402AccessGate.setFacilitator, (facilitator)),
            WarCouncil.PType.GATE_CONFIG
        );
        assertEq(gate.facilitator(), facilitator);

        // 2. Boardroom (economic lane) prices the GOLD tier.
        uint8 gold = uint8(X402AccessGate.Tier.GOLD);
        uint256 q = switchboard.requiredQuorum();
        vm.prank(seats[0]);
        uint256 rid = boardroom.proposePrice(gold, 9_000_000);
        for (uint256 i; i < q; ++i) {
            vm.prank(seats[i]);
            boardroom.vote(rid, true);
        }
        vm.warp(block.timestamp + boardroom.VOTING_WINDOW() + 1);
        boardroom.enact(rid);
        assertEq(gate.priceMicroUSDC(gold), 9_000_000);

        // 3. parsec settles an Algorand payment and records the grant with the AVM tx id.
        bytes32 algoTx = keccak256("ALGORAND_MAINNET_TX");
        vm.prank(facilitator);
        gate.recordSettlement(subscriber, X402AccessGate.Tier.GOLD, uint64(block.timestamp + 30 days), algoTx);

        // 4. mindX API gate check — GOLD access granted off a single x402 settlement.
        assertTrue(gate.hasAccess(subscriber, X402AccessGate.Tier.GOLD));
        (X402AccessGate.Tier t,, bytes32 proof) = gate.grants(subscriber);
        assertEq(uint8(t), gold);
        assertEq(proof, algoTx);

        // 5. SOVEREIGN requires a bound bankon.eth identity; enable the rule.
        _govExecute(
            address(gate),
            abi.encodeCall(X402AccessGate.setTierIdentityRule, (uint8(X402AccessGate.Tier.SOVEREIGN), true)),
            WarCouncil.PType.GATE_CONFIG
        );

        // Upgrade subscriber to SOVEREIGN via a fresh settlement.
        vm.prank(facilitator);
        gate.recordSettlement(subscriber, X402AccessGate.Tier.SOVEREIGN, uint64(block.timestamp + 30 days), algoTx);
        assertFalse(gate.hasAccess(subscriber, X402AccessGate.Tier.SOVEREIGN)); // no identity yet

        // 6. Subscriber self-binds bankon.eth subname via EIP-712, unlocking SOVEREIGN.
        bytes32 sn = keccak256("codephreak.bankon.eth");
        uint256 deadline = block.timestamp + 1 hours;
        bytes32 structHash =
            keccak256(abi.encode(identity.CLAIM_TYPEHASH(), subscriber, sn, identity.nonces(subscriber), deadline));
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", identity.DOMAIN_SEPARATOR(), structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(subscriberPk, digest);
        identity.bind(subscriber, sn, deadline, v, r, s);

        assertTrue(gate.hasAccess(subscriber, X402AccessGate.Tier.SOVEREIGN));
        assertTrue(daio.isOperational());
    }

    function testDeployerHasNoPowerAfterWiring() public {
        // address(this) was the deployer in setUp; every privileged surface is now closed.
        vm.expectRevert(Governed.AlreadyWired.selector);
        gate.initCouncil(address(0xABCD));

        vm.expectRevert(Governed.AlreadyWired.selector);
        identity.initCouncil(address(0xABCD));

        vm.expectRevert(Governed.NotCouncil.selector);
        gate.setFacilitator(facilitator);

        vm.expectRevert(Governed.NotCouncil.selector);
        identity.govBind(subscriber, keccak256("x"));

        // switchboard seat control is council-only too
        vm.expectRevert();
        switchboard.addSeat(address(0xABCD));
    }

    function testContinuityShadowModeUnderDecimation() public {
        // Reduce to 2 living seats: council auto-enters SHADOW_OVERLORD continuity.
        keepAliveOnly(2);
        assertEq(switchboard.livingSeats(), 2);
        assertEq(uint8(council.effectiveMode()), uint8(WarCouncil.Mode.SHADOW_OVERLORD));

        // A standard proposal executes immediately once passed (no window wait).
        uint256 q = switchboard.requiredQuorum(); // 2 -> quorum 2
        vm.prank(seats[0]);
        uint256 id = council.propose(
            address(gate),
            0,
            abi.encodeCall(X402AccessGate.setFacilitator, (facilitator)),
            WarCouncil.PType.GATE_CONFIG
        );
        for (uint256 i; i < q; ++i) {
            vm.prank(seats[i]);
            council.vote(id, true);
        }
        council.execute(id); // no warp past deadline needed under SHADOW
        assertEq(gate.facilitator(), facilitator);
    }
}
