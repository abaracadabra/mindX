// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Base} from "./Base.t.sol";
import {X402AccessGate} from "../src/X402AccessGate.sol";

contract BoardroomTest is Base {
    uint8 internal constant GOLD = uint8(X402AccessGate.Tier.GOLD);

    function testProposeVoteEnactSetsPrice() public {
        uint256 q = switchboard.requiredQuorum();

        vm.prank(seats[0]);
        uint256 id = boardroom.proposePrice(GOLD, 5_000_000); // 5 USDC (micro)

        for (uint256 i; i < q; ++i) {
            vm.prank(seats[i]);
            boardroom.vote(id, true);
        }

        vm.warp(block.timestamp + boardroom.VOTING_WINDOW() + 1);
        boardroom.enact(id);

        assertEq(gate.priceMicroUSDC(GOLD), 5_000_000);
    }

    function testEnactFailsBelowQuorum() public {
        vm.prank(seats[0]);
        uint256 id = boardroom.proposePrice(GOLD, 1_000_000);

        // only 2 votes, quorum is 7 with 13 living
        vm.prank(seats[0]);
        boardroom.vote(id, true);
        vm.prank(seats[1]);
        boardroom.vote(id, true);

        vm.warp(block.timestamp + boardroom.VOTING_WINDOW() + 1);
        vm.expectRevert(bytes("not passed"));
        boardroom.enact(id);
    }

    function testCannotEnactWhileVotingOpen() public {
        uint256 q = switchboard.requiredQuorum();
        vm.prank(seats[0]);
        uint256 id = boardroom.proposePrice(GOLD, 2_000_000);
        for (uint256 i; i < q; ++i) {
            vm.prank(seats[i]);
            boardroom.vote(id, true);
        }
        vm.expectRevert(bytes("voting open"));
        boardroom.enact(id);
    }

    function testOnlyAliveSeatCanPropose() public {
        vm.prank(address(0xDEAD));
        vm.expectRevert(bytes("not living seat"));
        boardroom.proposePrice(GOLD, 1);
    }

    function testProposerCanCancel() public {
        vm.prank(seats[0]);
        uint256 id = boardroom.proposePrice(GOLD, 1);
        vm.prank(seats[0]);
        boardroom.cancel(id);
        vm.warp(block.timestamp + boardroom.VOTING_WINDOW() + 1);
        vm.expectRevert(bytes("settled"));
        boardroom.enact(id);
    }
}
