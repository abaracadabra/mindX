// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Base} from "./Base.t.sol";
import {Governed} from "../src/Governed.sol";
import {DeadmansSwitch} from "../src/DeadmansSwitch.sol";
import {WarCouncil} from "../src/WarCouncil.sol";

contract DeadmansSwitchTest is Base {
    function test_initialState() public view {
        assertEq(switchboard.totalSeats(), 13);
        assertEq(switchboard.livingSeats(), 13);
        assertEq(switchboard.requiredQuorum(), 7);
    }

    function test_silentSeatBecomesNonLiving() public {
        keepAliveOnly(5);
        assertEq(switchboard.livingSeats(), 5);
        assertTrue(switchboard.isAlive(seats[0]));
        assertFalse(switchboard.isAlive(seats[12]));
    }

    function test_dynamicQuorumScales() public {
        // 13 -> 7
        assertEq(switchboard.requiredQuorum(), 7);
        keepAliveOnly(8);
        assertEq(switchboard.requiredQuorum(), 5); // 8/2+1
        keepAliveOnly(3);
        assertEq(switchboard.requiredQuorum(), 2); // 3/2+1
        keepAliveOnly(1);
        assertEq(switchboard.requiredQuorum(), 1); // protected dictator
    }

    function test_protectedDictator() public {
        keepAliveOnly(1);
        assertTrue(switchboard.isProtectedDictator(seats[0]));
        assertFalse(switchboard.isProtectedDictator(seats[1]));
    }

    function test_frozenWhenZeroLiving() public {
        keepAliveOnly(0);
        assertEq(switchboard.livingSeats(), 0);
        assertEq(switchboard.requiredQuorum(), type(uint256).max);
    }

    function test_revivalByHeartbeat() public {
        keepAliveOnly(1);
        assertEq(switchboard.livingSeats(), 1);
        vm.prank(seats[5]);
        switchboard.heartbeat();
        assertEq(switchboard.livingSeats(), 2);
        assertTrue(switchboard.isAlive(seats[5]));
    }

    function test_heartbeatOnlySeat() public {
        vm.expectRevert(bytes("not active seat"));
        vm.prank(address(0xBEEF));
        switchboard.heartbeat();
    }

    function test_addSeatRequiresCouncil() public {
        vm.expectRevert(Governed.NotCouncil.selector);
        switchboard.addSeat(address(0xCAFE));
    }

    function test_revokeSeatViaGovernance() public {
        _govExecute(
            address(switchboard), abi.encodeCall(DeadmansSwitch.revokeSeat, (seats[12])), WarCouncil.PType.STANDARD
        );
        assertFalse(switchboard.isAlive(seats[12]));
        assertEq(switchboard.livingSeats(), 12);
    }
}
