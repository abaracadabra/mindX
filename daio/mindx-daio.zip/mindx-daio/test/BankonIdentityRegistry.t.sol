// SPDX-License-Identifier: Apache-2.0
// (c) 2026 BANKON — all rights reserved
pragma solidity 0.8.26;

import {Base} from "./Base.t.sol";
import {WarCouncil} from "../src/WarCouncil.sol";
import {BankonIdentityRegistry} from "../src/BankonIdentityRegistry.sol";

contract BankonIdentityRegistryTest is Base {
    uint256 internal walletPk = 0xA11CE;
    address internal wallet;
    bytes32 internal sn = keccak256("alice.bankon.eth");

    function setUp() public override {
        super.setUp();
        wallet = vm.addr(walletPk);
    }

    function _digest(address w, bytes32 subname, uint256 nonce, uint256 deadline) internal view returns (bytes32) {
        bytes32 structHash = keccak256(
            abi.encode(identity.CLAIM_TYPEHASH(), w, subname, nonce, deadline)
        );
        return keccak256(abi.encodePacked("\x19\x01", identity.DOMAIN_SEPARATOR(), structHash));
    }

    function testSelfBindViaSignature() public {
        uint256 deadline = block.timestamp + 1 hours;
        bytes32 digest = _digest(wallet, sn, identity.nonces(wallet), deadline);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(walletPk, digest);

        identity.bind(wallet, sn, deadline, v, r, s);

        assertTrue(identity.isBound(wallet));
        assertEq(identity.subnameOf(wallet), sn);
        assertEq(identity.walletOf(sn), wallet);
        assertEq(identity.nonces(wallet), 1);
    }

    function testBindRejectsWrongSigner() public {
        uint256 deadline = block.timestamp + 1 hours;
        bytes32 digest = _digest(wallet, sn, 0, deadline);
        // sign with a different key
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(0xBADBAD, digest);

        vm.expectRevert(bytes("bad signature"));
        identity.bind(wallet, sn, deadline, v, r, s);
    }

    function testBindRejectsExpired() public {
        uint256 deadline = block.timestamp + 10;
        bytes32 digest = _digest(wallet, sn, 0, deadline);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(walletPk, digest);
        vm.warp(deadline + 1);
        vm.expectRevert(bytes("expired"));
        identity.bind(wallet, sn, deadline, v, r, s);
    }

    function testSubnameCannotBeTakenTwice() public {
        uint256 deadline = block.timestamp + 1 hours;
        bytes32 d1 = _digest(wallet, sn, 0, deadline);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(walletPk, d1);
        identity.bind(wallet, sn, deadline, v, r, s);

        uint256 otherPk = 0xB0B;
        address other = vm.addr(otherPk);
        bytes32 d2 = _digest(other, sn, 0, deadline);
        (uint8 v2, bytes32 r2, bytes32 s2) = vm.sign(otherPk, d2);
        vm.expectRevert(bytes("subname taken"));
        identity.bind(other, sn, deadline, v2, r2, s2);
    }

    function testGovBindAndUnbind() public {
        _govExecute(
            address(identity),
            abi.encodeCall(identity.govBind, (wallet, sn)),
            WarCouncil.PType.IDENTITY
        );
        assertTrue(identity.isBound(wallet));

        _govExecute(
            address(identity),
            abi.encodeCall(identity.govUnbind, (wallet)),
            WarCouncil.PType.IDENTITY
        );
        assertFalse(identity.isBound(wallet));
        assertEq(identity.walletOf(sn), address(0));
    }

    function testGovBindRejectsNonCouncil() public {
        vm.expectRevert();
        identity.govBind(wallet, sn);
    }
}
