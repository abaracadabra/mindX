# SPDX-License-Identifier: Apache-2.0
# (c) 2026 BANKON — all rights reserved
"""
parsec — x402-AVM settlement facilitator for the mindX DAIO.

Bridges the Algorand x402 payment rail (the `exact` AVM scheme registered on Algorand
mainnet) to the EVM X402AccessGate. parsec is the single address authorized by the
WarCouncil to call `recordSettlement`, carrying the Algorand transaction id as a
cross-chain settlement proof pointer.

Flow (HTTP 402 -> settle -> on-chain grant):
  1. A mindX / AgenticPlace endpoint answers an unpaid request with 402 + paymentRequirements
     (scheme="exact", network=algorand mainnet CAIP-2, asset=USDC ASA, payTo=BANKON treasury).
  2. The client signs an Algorand payment group and returns it in the X-PAYMENT header.
  3. parsec.verify() validates the signature/amount, parsec.settle() submits to Algorand.
  4. On confirmation, parsec.record_grant() writes the access tier to the EVM gate.

The Algorand-side primitives follow the GoPlausible / Algorand Foundation x402-avm
reference (register_exact_avm_facilitator, ALGORAND_MAINNET_CAIP2). Imports degrade
gracefully so the module can be wired and unit-tested without the live SDK installed.
"""

from __future__ import annotations

import base64
import dataclasses
import os
import time
from typing import Optional

# --- Algorand x402-AVM (GoPlausible reference) ---------------------------------------
ALGORAND_MAINNET_CAIP2 = "algorand:wGHE2Pwdvd7S12BL5FaOP20EGYesN73ktiC1qzkkit8="

try:  # live SDK
    from x402_avm import (  # type: ignore
        x402Facilitator,
        register_exact_avm_facilitator,
        AvmPaymentRequirements,
    )
    _HAVE_X402_AVM = True
except Exception:  # pragma: no cover - allows wiring without the SDK present
    _HAVE_X402_AVM = False

try:  # algod client
    from algosdk.v2client import algod  # type: ignore
    _HAVE_ALGOSDK = True
except Exception:  # pragma: no cover
    _HAVE_ALGOSDK = False

# --- EVM side -------------------------------------------------------------------------
try:
    from web3 import Web3  # type: ignore
    _HAVE_WEB3 = True
except Exception:  # pragma: no cover
    _HAVE_WEB3 = False


# X402AccessGate.Tier mirror (must match the Solidity enum ordering exactly).
TIER_NONE = 0
TIER_BRONZE = 1
TIER_SILVER = 2
TIER_GOLD = 3
TIER_SOVEREIGN = 4

# Minimal ABI for the only EVM call parsec is permitted to make.
GATE_ABI = [
    {
        "type": "function",
        "name": "recordSettlement",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "user", "type": "address"},
            {"name": "tier", "type": "uint8"},
            {"name": "expiresAt", "type": "uint64"},
            {"name": "algoTxId", "type": "bytes32"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "facilitator",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
]


@dataclasses.dataclass(frozen=True)
class Settlement:
    """Result of a confirmed Algorand x402 payment, ready to record on the gate."""

    user: str  # EVM address receiving access
    tier: int  # X402AccessGate.Tier
    expires_at: int  # unix seconds
    algo_txid: str  # Algorand transaction id (base32)


def _txid_to_bytes32(algo_txid: str) -> bytes:
    """Pack an Algorand base32 txid into a 32-byte word for the EVM proof pointer."""
    raw = base64.b32decode(algo_txid + "=" * (-len(algo_txid) % 8))
    return raw[:32].rjust(32, b"\x00")


class ParsecFacilitator:
    """x402-AVM facilitator + EVM settlement recorder for the mindX DAIO gate."""

    def __init__(
        self,
        gate_address: str,
        evm_rpc_url: Optional[str] = None,
        facilitator_key: Optional[str] = None,
        algod_url: str = "https://mainnet-api.algonode.cloud",
        algod_token: str = "",
        facilitator_url: Optional[str] = None,
    ) -> None:
        self.gate_address = gate_address
        self.facilitator_url = facilitator_url or os.environ.get(
            "PARSEC_FACILITATOR_URL", "https://bankon.pythai.net/x402"
        )

        # EVM signer (the parsec address the WarCouncil authorized on the gate).
        self.facilitator_key = facilitator_key or os.environ.get("PARSEC_FACILITATOR_KEY")
        self.evm_rpc_url = evm_rpc_url or os.environ.get("ETHEREUM_RPC_URL")
        self._w3 = None
        self._gate = None
        self._acct = None
        if _HAVE_WEB3 and self.evm_rpc_url and self.facilitator_key:
            self._w3 = Web3(Web3.HTTPProvider(self.evm_rpc_url))
            self._acct = self._w3.eth.account.from_key(self.facilitator_key)
            self._gate = self._w3.eth.contract(
                address=Web3.to_checksum_address(gate_address), abi=GATE_ABI
            )

        # Algorand x402 facilitator (exact AVM scheme on mainnet).
        self._algod = None
        self._avm = None
        if _HAVE_ALGOSDK:
            self._algod = algod.AlgodClient(algod_token, algod_url)
        if _HAVE_X402_AVM:
            self._avm = x402Facilitator(network=ALGORAND_MAINNET_CAIP2)
            register_exact_avm_facilitator(self._avm)

    # --- x402 protocol surface --------------------------------------------------------

    def verify(self, payment_header: str, requirements: dict) -> bool:
        """Validate a client X-PAYMENT payload against the stated requirements."""
        if not self._avm:
            raise RuntimeError("x402-avm SDK not installed; cannot verify on-chain payment")
        return self._avm.verify(payment_header, requirements)

    def settle(self, payment_header: str, requirements: dict) -> str:
        """Submit the signed Algorand payment group; return the confirmed txid."""
        if not self._avm:
            raise RuntimeError("x402-avm SDK not installed; cannot settle on Algorand")
        result = self._avm.settle(payment_header, requirements)
        return result["transaction"] if isinstance(result, dict) else str(result)

    # --- EVM grant recording ----------------------------------------------------------

    def record_grant(self, s: Settlement) -> str:
        """Record a confirmed settlement as an access grant on the EVM gate."""
        if not self._gate or not self._acct:
            raise RuntimeError("EVM gate not configured (need web3, RPC, and PARSEC_FACILITATOR_KEY)")

        # Defensive: refuse to record if the council has not authorized this address.
        on_chain = self._gate.functions.facilitator().call()
        if on_chain.lower() != self._acct.address.lower():
            raise PermissionError(
                f"parsec {self._acct.address} is not the council-authorized facilitator ({on_chain})"
            )

        fn = self._gate.functions.recordSettlement(
            Web3.to_checksum_address(s.user),
            int(s.tier),
            int(s.expires_at),
            _txid_to_bytes32(s.algo_txid),
        )
        tx = fn.build_transaction(
            {
                "from": self._acct.address,
                "nonce": self._w3.eth.get_transaction_count(self._acct.address),
                "gas": 120_000,
                "maxFeePerGas": self._w3.eth.gas_price * 2,
                "maxPriorityFeePerGas": self._w3.to_wei(1, "gwei"),
                "chainId": self._w3.eth.chain_id,
            }
        )
        signed = self._acct.sign_transaction(tx)
        h = self._w3.eth.send_raw_transaction(signed.raw_transaction)
        return h.hex()

    # --- one-call convenience ---------------------------------------------------------

    def fulfill(
        self,
        payment_header: str,
        requirements: dict,
        user: str,
        tier: int,
        ttl_seconds: int = 30 * 24 * 3600,
    ) -> Settlement:
        """End-to-end: verify -> settle on Algorand -> record grant on the EVM gate."""
        if not self.verify(payment_header, requirements):
            raise ValueError("x402 payment verification failed")
        txid = self.settle(payment_header, requirements)
        s = Settlement(
            user=user,
            tier=tier,
            expires_at=int(time.time()) + ttl_seconds,
            algo_txid=txid,
        )
        self.record_grant(s)
        return s
