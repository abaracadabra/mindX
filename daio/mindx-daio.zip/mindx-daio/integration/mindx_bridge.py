# SPDX-License-Identifier: Apache-2.0
# (c) 2026 BANKON — all rights reserved
"""
mindx_bridge — connects the mindX API (mindx.pythai.net) to the on-chain DAIO.

The original mindX stubs (mindx/x402/access.py, mindx/bankon/service.py) returned
unconditional grants. This bridge replaces those decisions with reads against the
deployed X402AccessGate and BankonIdentityRegistry, so access reflects real x402
settlements (settled on Algorand via parsec) and real bankon.eth identity bindings.

Drop-in usage in the mindX service layer:

    bridge = MindxDaioBridge(gate, identity, rpc_url)
    if bridge.authorize(wallet, required="GOLD")["access"]:
        ...serve the agent call...
"""

from __future__ import annotations

import os
from typing import Optional

try:
    from web3 import Web3  # type: ignore
    _HAVE_WEB3 = True
except Exception:  # pragma: no cover
    _HAVE_WEB3 = False

TIERS = {"NONE": 0, "BRONZE": 1, "SILVER": 2, "GOLD": 3, "SOVEREIGN": 4}
TIER_NAMES = {v: k for k, v in TIERS.items()}

GATE_ABI = [
    {
        "type": "function",
        "name": "hasAccess",
        "stateMutability": "view",
        "inputs": [{"name": "user", "type": "address"}, {"name": "required", "type": "uint8"}],
        "outputs": [{"name": "", "type": "bool"}],
    },
    {
        "type": "function",
        "name": "tierOf",
        "stateMutability": "view",
        "inputs": [{"name": "user", "type": "address"}],
        "outputs": [{"name": "", "type": "uint8"}],
    },
    {
        "type": "function",
        "name": "paused",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "bool"}],
    },
]

IDENTITY_ABI = [
    {
        "type": "function",
        "name": "isBound",
        "stateMutability": "view",
        "inputs": [{"name": "wallet", "type": "address"}],
        "outputs": [{"name": "", "type": "bool"}],
    },
    {
        "type": "function",
        "name": "subnameOf",
        "stateMutability": "view",
        "inputs": [{"name": "wallet", "type": "address"}],
        "outputs": [{"name": "", "type": "bytes32"}],
    },
]


class MindxDaioBridge:
    """On-chain-backed replacement for the mindX X402Gateway + BankonIdentityService."""

    def __init__(
        self,
        gate_address: str,
        identity_address: str,
        rpc_url: Optional[str] = None,
    ) -> None:
        if not _HAVE_WEB3:
            raise RuntimeError("web3 is required for the mindX DAIO bridge")
        self.rpc_url = rpc_url or os.environ.get("ETHEREUM_RPC_URL")
        self._w3 = Web3(Web3.HTTPProvider(self.rpc_url))
        self._gate = self._w3.eth.contract(
            address=Web3.to_checksum_address(gate_address), abi=GATE_ABI
        )
        self._identity = self._w3.eth.contract(
            address=Web3.to_checksum_address(identity_address), abi=IDENTITY_ABI
        )

    # --- replaces X402Gateway.authorize -----------------------------------------------

    def authorize(self, user: str, required: str = "BRONZE") -> dict:
        """Conditional privilege gate consumed by mindX endpoints.

        Returns the same shape the stub returned, but `access` is now the on-chain
        `hasAccess` predicate: tier height + non-expiry + identity rule + not paused.
        """
        req = TIERS.get(required.upper())
        if req is None:
            raise ValueError(f"unknown tier {required!r}")
        addr = Web3.to_checksum_address(user)
        granted = self._gate.functions.hasAccess(addr, req).call()
        held = self._gate.functions.tierOf(addr).call()
        return {
            "user": user,
            "access": bool(granted),
            "required": required.upper(),
            "tier": TIER_NAMES.get(held, "NONE"),
        }

    # --- replaces BankonIdentityService.resolve ---------------------------------------

    def resolve(self, wallet: str) -> dict:
        """Resolve a wallet's bankon.eth identity binding from the registry."""
        addr = Web3.to_checksum_address(wallet)
        bound = self._identity.functions.isBound(addr).call()
        subname_hash = self._identity.functions.subnameOf(addr).call()
        return {
            "wallet": wallet,
            "identity": "bankon.eth",
            "resolved": bool(bound),
            "subnameHash": "0x" + subname_hash.hex() if bound else None,
        }

    def paused(self) -> bool:
        return bool(self._gate.functions.paused().call())
