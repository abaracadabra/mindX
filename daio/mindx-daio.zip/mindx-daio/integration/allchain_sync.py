# SPDX-License-Identifier: Apache-2.0
# (c) 2026 BANKON — all rights reserved
"""
allchain_sync — projects the AgenticPlace ALLCHAIN map onto the on-chain ChainRegistry.

allchain.html (agenticplace.pythai.net) is the "Chain as a Service" directory. This tool
pulls that map, normalizes each chain into a ChainRegistry.Chain record, and:

  * stores RPC/explorer URLs as keccak pointers on-chain (compact + tamper-evident),
  * keeps the reverse pointer->URL map locally (allchain_pointers.json) so the gateway
    can resolve a stored hash back to its canonical endpoint,
  * emits WarCouncil `upsert` calldata, because after deploy the registry is mutated
    only through governance (no admin key). A living seat submits the proposal.

The deploy-time seed (script/chains.json) covers the operational chains; this keeps the
registry in sync as ALLCHAIN grows.
"""

from __future__ import annotations

import json
import sys
from typing import Optional

try:
    from web3 import Web3  # type: ignore
    from eth_abi import encode as abi_encode  # type: ignore
    _HAVE_WEB3 = True
except Exception:  # pragma: no cover
    _HAVE_WEB3 = False

try:
    import requests  # type: ignore
    _HAVE_REQUESTS = True
except Exception:  # pragma: no cover
    _HAVE_REQUESTS = False

ALLCHAIN_URL = "https://agenticplace.pythai.net/allchain.html"
ALLCHAIN_API = "https://agenticplace.pythai.net/api/allchain"  # JSON feed behind the page

UPSERT_SELECTOR = "upsert((uint64,bytes32,bytes32,bytes32,bytes32,uint8,bool,bool))"
SET_ACTIVE_SELECTOR = "setActive(uint64,bool)"


def keccak(s: str) -> bytes:
    return Web3.keccak(text=s)


def symbol_to_bytes32(sym: str) -> bytes:
    b = sym.encode("utf-8")[:32]
    return b.ljust(32, b"\x00")


def build_record(chain: dict) -> tuple[tuple, dict]:
    """Return (solidity_tuple, pointer_map_entry) for one ALLCHAIN entry."""
    cid = int(chain["chainId"])
    name = chain.get("name", f"chain-{cid}")
    rpc = chain.get("rpc", "")
    explorer = chain.get("explorer", "")
    symbol = chain.get("nativeSymbol", "")
    tier = int(chain.get("tier", 1))
    mainnet = bool(chain.get("mainnet", True))
    active = bool(chain.get("active", True))

    name_hash = keccak(name)
    rpc_hash = keccak(rpc) if rpc else b"\x00" * 32
    explorer_hash = keccak(explorer) if explorer else b"\x00" * 32

    record = (
        cid,
        name_hash,
        rpc_hash,
        explorer_hash,
        symbol_to_bytes32(symbol),
        tier,
        mainnet,
        active,
    )
    pointers = {
        "0x" + name_hash.hex(): name,
        "0x" + rpc_hash.hex(): rpc,
        "0x" + explorer_hash.hex(): explorer,
    }
    return record, pointers


def fetch_allchain() -> list[dict]:
    """Pull the ALLCHAIN JSON feed. Falls back to script/chains.json if offline."""
    if _HAVE_REQUESTS:
        try:
            r = requests.get(ALLCHAIN_API, timeout=15)
            r.raise_for_status()
            data = r.json()
            return data["chains"] if isinstance(data, dict) and "chains" in data else data
        except Exception as e:  # pragma: no cover
            print(f"[allchain_sync] live fetch failed ({e}); using local seed", file=sys.stderr)
    with open("script/chains.json") as f:
        return json.load(f)["chains"]


def encode_upsert(record: tuple) -> str:
    """ABI-encode a WarCouncil proposal calldata to upsert one chain record."""
    selector = Web3.keccak(text=UPSERT_SELECTOR)[:4]
    encoded = abi_encode(
        ["(uint64,bytes32,bytes32,bytes32,bytes32,uint8,bool,bool)"],
        [record],
    )
    return "0x" + (selector + encoded).hex()


def sync(registry_address: Optional[str] = None, rpc_url: Optional[str] = None) -> dict:
    """Build registry records + governance calldata; diff against on-chain if reachable."""
    if not _HAVE_WEB3:
        raise RuntimeError("web3 + eth_abi required for allchain_sync")

    chains = fetch_allchain()
    records, pointer_map, proposals = [], {}, []
    for c in chains:
        rec, ptrs = build_record(c)
        records.append(rec)
        pointer_map.update(ptrs)
        proposals.append({"chainId": rec[0], "calldata": encode_upsert(rec)})

    # Persist the reverse pointer map for the gateway resolver.
    with open("allchain_pointers.json", "w") as f:
        json.dump(pointer_map, f, indent=2)

    result = {
        "chains": len(records),
        "proposals": proposals,
        "pointer_map_file": "allchain_pointers.json",
    }

    # Optional on-chain diff: report which chains are not yet known.
    if registry_address and rpc_url:
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        reg = w3.eth.contract(
            address=Web3.to_checksum_address(registry_address),
            abi=[{
                "type": "function", "name": "isKnown", "stateMutability": "view",
                "inputs": [{"name": "chainId", "type": "uint64"}],
                "outputs": [{"name": "", "type": "bool"}],
            }],
        )
        missing = [r[0] for r in records if not reg.functions.isKnown(r[0]).call()]
        result["missing_on_chain"] = missing

    return result


if __name__ == "__main__":
    import os

    out = sync(os.environ.get("CHAIN_REGISTRY_ADDRESS"), os.environ.get("ETHEREUM_RPC_URL"))
    print(json.dumps(out, indent=2))
