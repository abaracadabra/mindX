# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
#
# Pattern 3 of 3 ported from zilliztech/memsearch (MIT, inherited from OpenClaw):
# forked-subagent recall context for AGInt's "Orient" phase.
"""Forked-subagent recall context for AGInt P-O-D-A.

Problem: when the BDI agent calls RAGE during the Orient phase, every
intermediate ranked chunk that came back gets folded into the parent
agent's belief base. Most of those chunks were noise — they got ranked,
inspected, and discarded. Their presence in the belief base biases the
Decide phase and bloats the working context.

Solution: run retrieval in a forked sub-context. The sub-context inherits
the parent's read-only beliefs but has its own working scratch. When it
exits, only the *promoted* facts (chunks the sub-context explicitly chose
to escalate) flow back to the parent. Everything else is discarded.

This module is framework-agnostic: it takes any object with a
``beliefs`` mapping and produces an isolated context manager. mindX's
``bdi_agent.py`` wires this into the orient step; tests use a stub.
"""

from __future__ import annotations

import contextlib
import copy
import time
from collections.abc import AsyncIterator, Mapping
from dataclasses import dataclass, field
from typing import Any, Generic, Protocol, TypeVar
from uuid import uuid4

import structlog

from .schemas import ChunkFull

log = structlog.get_logger(__name__)


class HasBeliefs(Protocol):
    """Minimal contract: anything with a beliefs mapping qualifies as a parent."""

    @property
    def beliefs(self) -> Mapping[str, Any]: ...


P = TypeVar("P", bound=HasBeliefs)


@dataclass(slots=True)
class RecallTrace:
    """Auditable record of what a fork did. Append-only.

    Written to the Gödel choice log by mindX so each AGInt Orient phase
    has a reproducible retrieval trail.
    """

    fork_id: str
    parent_id: str
    started_at: float
    finished_at: float | None = None
    chunks_inspected: int = 0
    chunks_promoted: int = 0
    promoted_chunk_ids: list[str] = field(default_factory=list)
    query: str | None = None
    promoted_keys: list[str] = field(default_factory=list)

    @property
    def duration_ms(self) -> float | None:
        if self.finished_at is None:
            return None
        return (self.finished_at - self.started_at) * 1000.0


@dataclass(slots=True)
class ForkedRecallContext(Generic[P]):
    """A throwaway scratch space for a single recall episode.

    Usage::

        async with forked_recall(parent_agent, query="...") as fork:
            chunks = await rage.retrieve(...)
            for c in chunks:
                if relevant(c):
                    fork.promote_chunk(c)
                    fork.promote_belief(f"saw:{c.chunk_id}", c.source_uri)
        # parent_agent.beliefs now contains ONLY the promoted entries
        # plus its prior state; the discarded chunks never touched it.

    The context's ``scratch_beliefs`` are a shallow-copied view of the
    parent's beliefs at entry time. Mutations within the fork land in
    ``scratch_beliefs`` only. On exit, ``promoted_keys`` are copied from
    scratch back to the parent and ``promoted_chunks`` are returned
    alongside the trace.
    """

    parent: P
    fork_id: str
    parent_id: str
    query: str | None
    scratch_beliefs: dict[str, Any]
    promoted_keys: set[str] = field(default_factory=set)
    promoted_chunks: list[ChunkFull] = field(default_factory=list)
    trace: RecallTrace = field(init=False)

    def __post_init__(self) -> None:
        self.trace = RecallTrace(
            fork_id=self.fork_id,
            parent_id=self.parent_id,
            started_at=time.perf_counter(),
            query=self.query,
        )

    def note(self, key: str, value: Any) -> None:
        """Write to scratch. Does NOT escape unless promoted."""
        self.scratch_beliefs[key] = value

    def inspect_chunk(self, chunk: ChunkFull) -> None:
        """Record that a chunk was considered. Audit-only."""
        self.trace.chunks_inspected += 1

    def promote_belief(self, key: str, value: Any) -> None:
        """Mark a scratch belief for escalation to the parent on exit."""
        self.scratch_beliefs[key] = value
        self.promoted_keys.add(key)

    def promote_chunk(self, chunk: ChunkFull) -> None:
        """Mark a chunk for escalation to the parent on exit."""
        self.promoted_chunks.append(chunk)
        self.trace.chunks_promoted += 1
        self.trace.promoted_chunk_ids.append(chunk.chunk_id)


@contextlib.asynccontextmanager
async def forked_recall(
    parent: P,
    *,
    query: str | None = None,
    parent_id: str | None = None,
) -> AsyncIterator[ForkedRecallContext[P]]:
    """Open a forked recall sub-context.

    Args:
        parent: The parent agent (must expose ``beliefs``).
        query: Optional query string for the audit trail.
        parent_id: Optional explicit parent identifier; defaults to
            ``id(parent)`` rendered as hex.

    Yields:
        A :class:`ForkedRecallContext`. On normal exit, promoted keys are
        merged into ``parent.beliefs`` if it is a ``MutableMapping``;
        otherwise the caller is responsible for reading
        ``ctx.promoted_chunks`` and ``ctx.promoted_keys`` themselves.

    On exception, nothing is promoted — the exception propagates and the
    parent is untouched. This is the whole point of the pattern.
    """
    fork_id = uuid4().hex[:16]
    pid = parent_id or f"0x{id(parent):x}"

    # Shallow-copy parent beliefs to avoid leaking writes upward by accident.
    # Deepcopy is too expensive for the orient hot path; the contract is that
    # the fork mutates *bindings*, not nested objects.
    scratch = dict(parent.beliefs) if hasattr(parent, "beliefs") else {}

    ctx: ForkedRecallContext[P] = ForkedRecallContext(
        parent=parent,
        fork_id=fork_id,
        parent_id=pid,
        query=query,
        scratch_beliefs=scratch,
    )

    log.info("recall.fork.open", fork_id=fork_id, parent_id=pid, query=query)
    try:
        yield ctx
    except Exception:
        ctx.trace.finished_at = time.perf_counter()
        log.warning(
            "recall.fork.aborted",
            fork_id=fork_id,
            parent_id=pid,
            chunks_inspected=ctx.trace.chunks_inspected,
            chunks_promoted=0,  # promotion is forfeit on exception
        )
        raise
    else:
        ctx.trace.finished_at = time.perf_counter()
        ctx.trace.promoted_keys = sorted(ctx.promoted_keys)
        # Only merge if the parent's beliefs is a mutable mapping. mindX's
        # belief_system exposes a dict-like; tests can pass a plain object
        # with a read-only beliefs property and harvest promotions manually.
        beliefs = getattr(parent, "beliefs", None)
        if isinstance(beliefs, dict):
            for k in ctx.promoted_keys:
                beliefs[k] = ctx.scratch_beliefs[k]
        log.info(
            "recall.fork.close",
            fork_id=fork_id,
            parent_id=pid,
            chunks_inspected=ctx.trace.chunks_inspected,
            chunks_promoted=ctx.trace.chunks_promoted,
            promoted_keys=len(ctx.promoted_keys),
            duration_ms=round(ctx.trace.duration_ms or 0.0, 2),
        )


# Convenience deep-copy variant for the rare orient phase where the fork
# needs to mutate nested belief structures without leaking writes. Slower
# by ~10x on large belief bases; do not use in the hot path.
@contextlib.asynccontextmanager
async def forked_recall_deep(
    parent: P,
    *,
    query: str | None = None,
    parent_id: str | None = None,
) -> AsyncIterator[ForkedRecallContext[P]]:
    """Like :func:`forked_recall` but ``deepcopy``s the belief base.

    Use only when the fork will mutate nested objects (lists, dicts) inside
    beliefs. For simple key replacement (the common case), prefer
    :func:`forked_recall`.
    """
    fork_id = uuid4().hex[:16]
    pid = parent_id or f"0x{id(parent):x}"

    scratch_src = parent.beliefs if hasattr(parent, "beliefs") else {}
    scratch = copy.deepcopy(dict(scratch_src))

    ctx: ForkedRecallContext[P] = ForkedRecallContext(
        parent=parent,
        fork_id=fork_id,
        parent_id=pid,
        query=query,
        scratch_beliefs=scratch,
    )

    log.info("recall.fork.open.deep", fork_id=fork_id, parent_id=pid, query=query)
    try:
        yield ctx
    except Exception:
        ctx.trace.finished_at = time.perf_counter()
        log.warning("recall.fork.deep.aborted", fork_id=fork_id)
        raise
    else:
        ctx.trace.finished_at = time.perf_counter()
        ctx.trace.promoted_keys = sorted(ctx.promoted_keys)
        beliefs = getattr(parent, "beliefs", None)
        if isinstance(beliefs, dict):
            for k in ctx.promoted_keys:
                beliefs[k] = ctx.scratch_beliefs[k]
        log.info(
            "recall.fork.deep.close",
            fork_id=fork_id,
            chunks_promoted=ctx.trace.chunks_promoted,
            duration_ms=round(ctx.trace.duration_ms or 0.0, 2),
        )


__all__ = [
    "ForkedRecallContext",
    "HasBeliefs",
    "RecallTrace",
    "forked_recall",
    "forked_recall_deep",
]
