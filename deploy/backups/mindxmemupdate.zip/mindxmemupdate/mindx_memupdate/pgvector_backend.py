# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""Reference :class:`RageBackend` implementation against pgvector.

This is a thin reference adapter that mindX can lift wholesale into
``agents/memory_agent.py`` or wire as a sidecar. It expects the schema
created by ``migrations/001_chunk_composite_pk.sql``.

The hybrid-search query is intentionally simple: it does the dense+sparse
part with pgvector + pg_trgm. mindX's real Knowledge Catalogue layer adds
graph traversal and cross-encoder rerank on top; that lives upstream of
this backend and remains unchanged. This adapter exists so a fresh deploy
has a working L1/L2/L3 path on day one without the full Catalogue.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, cast

import structlog

from .schemas import (
    ChunkFull,
    Importance,
    MemoryTier,
    MemoryType,
    RetrieveRequest,
)

if TYPE_CHECKING:
    import asyncpg

log = structlog.get_logger(__name__)


class PgvectorRageBackend:
    """Adapter from the :class:`RageBackend` protocol to pgvector.

    Construct with an ``asyncpg.Pool`` and an async ``embed_fn`` that turns
    a query string into a ``list[float]`` matching the configured dim.
    """

    def __init__(
        self,
        pool: asyncpg.Pool,
        *,
        embed_fn: Any,
        embedding_dim: int = 768,
        table: str = "rage_chunks",
    ) -> None:
        self._pool = pool
        self._embed = embed_fn
        self._dim = embedding_dim
        self._table = table

    async def hybrid_search(self, req: RetrieveRequest) -> list[ChunkFull]:
        embedding = await self._embed(req.query)
        if len(embedding) != self._dim:
            raise ValueError(
                f"embedding dim mismatch: got {len(embedding)} want {self._dim}"
            )

        filters: list[str] = []
        params: list[Any] = [embedding, req.query, req.top_k]
        if req.memory_types:
            filters.append(f"memory_type = ANY(${len(params) + 1}::text[])")
            params.append([m.value for m in req.memory_types])
        if req.tier_filter:
            filters.append(f"tier = ANY(${len(params) + 1}::text[])")
            params.append([t.value for t in req.tier_filter])
        if req.min_importance is not None:
            rank_map = {
                Importance.LOW: 1,
                Importance.MEDIUM: 2,
                Importance.HIGH: 3,
                Importance.CRITICAL: 4,
            }
            filters.append(f"importance_rank >= ${len(params) + 1}")
            params.append(rank_map[req.min_importance])

        where = ("WHERE " + " AND ".join(filters)) if filters else ""

        sql = f"""
            WITH dense AS (
                SELECT chunk_id,
                       1.0 - (embedding <=> $1) AS dense_score
                FROM {self._table}
                {where}
                ORDER BY embedding <=> $1
                LIMIT $3 * 4
            ),
            sparse AS (
                SELECT chunk_id,
                       similarity(content, $2) AS sparse_score
                FROM {self._table}
                {where}
                ORDER BY similarity(content, $2) DESC
                LIMIT $3 * 4
            ),
            fused AS (
                SELECT chunk_id,
                       COALESCE(d.dense_score, 0) * 0.6
                     + COALESCE(s.sparse_score, 0) * 0.4 AS score
                FROM dense d
                FULL OUTER JOIN sparse s USING (chunk_id)
            )
            SELECT c.chunk_id, c.source_uri, c.start_line, c.end_line,
                   c.content, c.content_hash, c.memory_type, c.importance,
                   c.tier, c.created_at, c.embedding_model,
                   f.score
            FROM fused f
            JOIN {self._table} c USING (chunk_id)
            ORDER BY f.score DESC
            LIMIT $3
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        return [_row_to_chunk(r) for r in rows]

    async def get_chunk(self, chunk_id: str) -> ChunkFull | None:
        sql = f"""
            SELECT chunk_id, source_uri, start_line, end_line, content,
                   content_hash, memory_type, importance, tier, created_at,
                   embedding_model
            FROM {self._table}
            WHERE chunk_id = $1
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, chunk_id)
        return _row_to_chunk(row) if row else None

    async def get_neighbors(self, chunk_id: str) -> tuple[str | None, str | None]:
        sql = f"""
            WITH target AS (
                SELECT source_uri, start_line, end_line
                FROM {self._table}
                WHERE chunk_id = $1
            )
            SELECT
              (SELECT chunk_id FROM {self._table}, target
                 WHERE {self._table}.source_uri = target.source_uri
                   AND {self._table}.end_line < target.start_line
                 ORDER BY end_line DESC
                 LIMIT 1) AS prev_id,
              (SELECT chunk_id FROM {self._table}, target
                 WHERE {self._table}.source_uri = target.source_uri
                   AND {self._table}.start_line > target.end_line
                 ORDER BY start_line ASC
                 LIMIT 1) AS next_id
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, chunk_id)
        if row is None:
            return None, None
        return row["prev_id"], row["next_id"]

    async def get_source_chunks(
        self,
        source_uri: str,
        around_chunk_id: str | None,
        window: int,
    ) -> tuple[list[ChunkFull], int, bool]:
        async with self._pool.acquire() as conn:
            total = await conn.fetchval(
                f"SELECT COUNT(*) FROM {self._table} WHERE source_uri = $1",
                source_uri,
            )
            total = int(total or 0)

            if around_chunk_id is None:
                rows: Sequence[Any] = await conn.fetch(
                    f"""
                    SELECT chunk_id, source_uri, start_line, end_line, content,
                           content_hash, memory_type, importance, tier, created_at,
                           embedding_model
                    FROM {self._table}
                    WHERE source_uri = $1
                    ORDER BY start_line ASC
                    LIMIT $2
                    """,
                    source_uri,
                    window * 2 + 1,
                )
                truncated = total > len(rows)
                return [_row_to_chunk(r) for r in rows], total, truncated

            center = await conn.fetchrow(
                f"SELECT start_line FROM {self._table} WHERE chunk_id = $1",
                around_chunk_id,
            )
            if center is None:
                return [], total, False
            center_line = int(center["start_line"])
            rows = await conn.fetch(
                f"""
                SELECT chunk_id, source_uri, start_line, end_line, content,
                       content_hash, memory_type, importance, tier, created_at,
                       embedding_model
                FROM {self._table}
                WHERE source_uri = $1
                  AND start_line BETWEEN $2 AND $3
                ORDER BY start_line ASC
                """,
                source_uri,
                max(0, center_line - window * 50),
                center_line + window * 50,
            )
            truncated = len(rows) > (window * 2 + 1)
            if truncated:
                rows = rows[: window * 2 + 1]
            return [_row_to_chunk(r) for r in rows], total, truncated


def _row_to_chunk(row: Any) -> ChunkFull:
    return ChunkFull(
        chunk_id=row["chunk_id"],
        source_uri=row["source_uri"],
        start_line=int(row["start_line"]),
        end_line=int(row["end_line"]),
        content=row["content"],
        content_hash=row["content_hash"],
        memory_type=cast(MemoryType, row["memory_type"]),
        importance=cast(Importance, row["importance"]),
        tier=cast(MemoryTier, row["tier"]),
        created_at=row["created_at"],
        embedding_model=row["embedding_model"],
    )


__all__ = ["PgvectorRageBackend"]
