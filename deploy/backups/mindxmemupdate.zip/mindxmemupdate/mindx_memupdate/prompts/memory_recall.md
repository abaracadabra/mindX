<!--
Copyright 2026 BANKON
Licensed under the Apache License, Version 2.0

Prompt template ported from zilliztech/memsearch plugins/claude-code/skills/memory-recall.md
Adapted for mindX AGInt P-O-D-A orient phase.
-->

# Memory Recall Skill (mindX RAGE, 3-Layer)

You have three retrieval layers. Use them in order; do not skip ahead.

## L1 — Snippet scan (`/api/rage/retrieve`)
Cheap. Returns ranked snippets (~350 tokens each). Call once per orient
phase. Scan results; identify 1–3 chunks worth opening.

**Skip L2 entirely** if no snippet looks relevant. Report `no_relevant_memory`
and proceed with the goal directly.

## L2 — Expand chunk (`/api/rage/retrieve/expand`)
Open only the chunks you flagged. Each L2 call returns the full chunk
plus neighbor IDs (`prev_chunk_id`, `next_chunk_id`). Walk laterally with
more L2 calls — do not jump to L3 unless lateral walking won't suffice.

## L3 — Transcript (`/api/rage/retrieve/transcript`)
Forensic only. Use when you need the surrounding source document, not
just adjacent chunks. Caps the window at 20 chunks by default; bump
`window_chunks` only with explicit justification.

## Promotion rules
You are operating inside a **forked recall context**. Everything you see
at L1/L2/L3 is in scratch only — none of it pollutes the parent agent's
belief base until you explicitly call `fork.promote_chunk(...)` or
`fork.promote_belief(key, value)`.

Promote sparingly. Defaults:
- **CRITICAL** importance → promote.
- **HIGH** importance and directly relevant to current goal → promote.
- **MEDIUM/LOW** → do not promote unless explicitly required by the goal.

## Output contract
Return a structured object:

```json
{
  "query": "...",
  "inspected": <int>,
  "promoted": <int>,
  "promoted_chunk_ids": ["..."],
  "rationale": "one sentence why these chunks were promoted"
}
```

## Anti-patterns
- ❌ Calling L3 first to "see everything." Token budget death.
- ❌ Promoting every L1 result. Defeats the fork isolation.
- ❌ Bypassing the fork and writing directly to `agent.beliefs`.
- ❌ Holding L2 chunk bodies in working context after the orient phase ends.
