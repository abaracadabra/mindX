# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""mindx-memupdate: cherry-picked memsearch patterns for mindX RAGE.

Three patterns, no Milvus, pure pgvector. Apache-2.0, Python 3.12+,
cypherpunk2048-compliant. Drop-in for mindX's existing 307-endpoint
API surface; additive only.
"""

from __future__ import annotations

from .chunk_hash import (
    CHUNK_SCHEMA_VERSION,
    ChunkKey,
    content_hash_hex,
    make_chunk_id,
)
from .forked_recall import (
    ForkedRecallContext,
    HasBeliefs,
    RecallTrace,
    forked_recall,
    forked_recall_deep,
)
from .progressive_disclosure import (
    ProgressiveDisclosureService,
    RageBackend,
)
from .rage_routes import build_router
from .schemas import (
    ChunkFull,
    ChunkSnippet,
    ExpandRequest,
    Importance,
    MemoryTier,
    MemoryType,
    RetrieveRequest,
    RetrieveResponse,
    TranscriptRequest,
    TranscriptWindow,
)

__version__ = "0.1.0"

__all__ = [
    "CHUNK_SCHEMA_VERSION",
    "ChunkFull",
    "ChunkKey",
    "ChunkSnippet",
    "ExpandRequest",
    "ForkedRecallContext",
    "HasBeliefs",
    "Importance",
    "MemoryTier",
    "MemoryType",
    "ProgressiveDisclosureService",
    "RageBackend",
    "RecallTrace",
    "RetrieveRequest",
    "RetrieveResponse",
    "TranscriptRequest",
    "TranscriptWindow",
    "__version__",
    "build_router",
    "content_hash_hex",
    "forked_recall",
    "forked_recall_deep",
    "make_chunk_id",
]
