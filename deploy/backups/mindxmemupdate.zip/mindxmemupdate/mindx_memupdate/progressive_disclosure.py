# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
#
# Pattern 1 of 3 ported from zilliztech/memsearch (MIT):
# 3-layer progressive disclosure for the RAGE retrieval API.
#   L1 /api/rage/retrieve          -> ChunkSnippet  (cheap, ranked)
#   L2 /api/rage/retrieve/expand   -> ChunkFull     (one chunk, full body + neighbors)
#   L3 /api/rage/retrieve/transcript -> TranscriptWindow (source-wide drill-down)
"""Progressive-disclosure retrieval layer for mindX RAGE.

The agent calls L1 to scan candidates cheaply, L2 to materialize the chunks
worth reading, and L3 only for forensic context. This is the single biggest
token-cost win on every BDI cycle: median retrieval drops from "full chunk
bodies for top_k=10" to "snippet bodies for top_k=10, full body for top_k≈2".

Backend interface is defined as a Protocol so this module is independent of
the concrete pgvector / Knowledge Catalogue implementation. mindX wires its
existing repository into ``ProgressiveDisclosureService(backend=...)``.
"""

from __future__ import annotations

import time
from typing import Protocol

import structlog

from .schemas import (
    ChunkFull,
    ChunkSnippet,
    ExpandRequest,
    RetrieveRequest,
    RetrieveResponse,
    TranscriptRequest,
    TranscriptWindow,
)

log = structlog.get_logger(__name__)

# Snippet budget. Tuned for Qwen3.5/3.6 — 350 tokens lets an agent scan
# top_k=10 candidates in <4k tokens including framing overhead.
SNIPPET_TARGET_CHARS = 1400
SNIPPET_CONTEXT_LINES = 2  # lines of context shown above/below the matched span


class RageBackend(Protocol):
    """Storage-agnostic backend contract.

    mindX wires its existing pgvector + Knowledge Catalogue repository to
    this protocol. No SQL leaks into this module.
    """

    async def hybrid_search(self, req: RetrieveRequest) -> list[ChunkFull]:
        """Run the existing BM25+dense+graph+cross-encoder hybrid search.

        Implementations return full ChunkFull rows; this service truncates
        them to ChunkSnippet for the L1 response. Returning full rows here
        (vs. snippets at the SQL layer) lets the L2 cache below be warmed
        as a side effect of every L1 call.
        """
        ...

    async def get_chunk(self, chunk_id: str) -> ChunkFull | None:
        """Fetch a single chunk by composite-hash chunk_id."""
        ...

    async def get_neighbors(
        self, chunk_id: str
    ) -> tuple[str | None, str | None]:
        """Return (prev_chunk_id, next_chunk_id) within the same source_uri."""
        ...

    async def get_source_chunks(
        self,
        source_uri: str,
        around_chunk_id: str | None,
        window: int,
    ) -> tuple[list[ChunkFull], int, bool]:
        """Return (chunks, total_lines, truncated) for L3."""
        ...


def _summarize_to_snippet(chunk: ChunkFull, query_terms: list[str]) -> str:
    """Extract the most-relevant span from a full chunk.

    Strategy: find the line with the densest match against query terms,
    return a SNIPPET_CONTEXT_LINES window around it, capped at
    SNIPPET_TARGET_CHARS. Falls back to chunk head if no terms match.
    Pure-Python, no NLP deps — deliberately cheap.
    """
    lines = chunk.content.splitlines()
    if not lines:
        return ""

    # Score each line by count of any query term occurrence (case-insensitive).
    lowered_terms = [t.lower() for t in query_terms if t]
    if not lowered_terms:
        head = "\n".join(lines[: SNIPPET_CONTEXT_LINES * 2 + 1])
        return head[:SNIPPET_TARGET_CHARS]

    best_idx = 0
    best_score = -1
    for i, line in enumerate(lines):
        lo = line.lower()
        score = sum(lo.count(t) for t in lowered_terms)
        if score > best_score:
            best_score = score
            best_idx = i

    start = max(0, best_idx - SNIPPET_CONTEXT_LINES)
    end = min(len(lines), best_idx + SNIPPET_CONTEXT_LINES + 1)
    snippet = "\n".join(lines[start:end])
    return snippet[:SNIPPET_TARGET_CHARS]


def _chunk_to_snippet(chunk: ChunkFull, query_terms: list[str]) -> ChunkSnippet:
    return ChunkSnippet(
        chunk_id=chunk.chunk_id,
        source_uri=chunk.source_uri,
        snippet=_summarize_to_snippet(chunk, query_terms),
        score=0.0,  # backend sets real score; default for type safety
        memory_type=chunk.memory_type,
        importance=chunk.importance,
        tier=chunk.tier,
        created_at=chunk.created_at,
    )


class ProgressiveDisclosureService:
    """L1/L2/L3 retrieval orchestrator.

    Thin layer over a :class:`RageBackend`. Stateless aside from a small
    in-process LRU that warms L2 hits from preceding L1 calls — turn it
    off (``warm_cache_size=0``) in tests or multi-process deployments.
    """

    def __init__(self, backend: RageBackend, *, warm_cache_size: int = 256) -> None:
        self._backend = backend
        self._cache_size = warm_cache_size
        self._warm: dict[str, ChunkFull] = {}

    def _cache_put(self, chunk: ChunkFull) -> None:
        if self._cache_size <= 0:
            return
        if len(self._warm) >= self._cache_size:
            # Pop oldest insertion (dict preserves order in 3.7+).
            try:
                self._warm.pop(next(iter(self._warm)))
            except StopIteration:  # pragma: no cover
                pass
        self._warm[chunk.chunk_id] = chunk

    # ------------------------------------------------------------------ L1

    async def retrieve(self, req: RetrieveRequest) -> RetrieveResponse:
        """L1: snippet-only ranked results."""
        t0 = time.perf_counter()
        full = await self._backend.hybrid_search(req)
        terms = [t for t in req.query.split() if len(t) > 2]
        snippets: list[ChunkSnippet] = []
        for c in full:
            self._cache_put(c)
            s = _chunk_to_snippet(c, terms)
            snippets.append(s)
        latency_ms = (time.perf_counter() - t0) * 1000.0
        log.info(
            "rage.retrieve.l1",
            query_len=len(req.query),
            top_k=req.top_k,
            returned=len(snippets),
            latency_ms=round(latency_ms, 2),
        )
        # Backend supplied real scores on ChunkFull.created_at order; if it
        # also exposed a score we'd plumb it through. Keeping signature stable
        # so this module stays decoupled from the scoring implementation.
        return RetrieveResponse(results=snippets, query=req.query, latency_ms=latency_ms)

    # ------------------------------------------------------------------ L2

    async def expand(self, req: ExpandRequest) -> ChunkFull | None:
        """L2: full body of one chunk, with optional neighbor links."""
        chunk = self._warm.get(req.chunk_id)
        if chunk is None:
            chunk = await self._backend.get_chunk(req.chunk_id)
            if chunk is None:
                log.info("rage.retrieve.l2.miss", chunk_id=req.chunk_id)
                return None
            self._cache_put(chunk)
        else:
            log.info("rage.retrieve.l2.warm_hit", chunk_id=req.chunk_id)

        if req.include_neighbors:
            prev_id, next_id = await self._backend.get_neighbors(req.chunk_id)
            # Pydantic model is frozen-ish (immutable=False by default but we
            # treat it as immutable). Rebuild with neighbor fields populated.
            chunk = chunk.model_copy(
                update={"prev_chunk_id": prev_id, "next_chunk_id": next_id}
            )
        return chunk

    # ------------------------------------------------------------------ L3

    async def transcript(self, req: TranscriptRequest) -> TranscriptWindow:
        """L3: chunks around a target within the same source."""
        chunks, total_lines, truncated = await self._backend.get_source_chunks(
            source_uri=req.source_uri,
            around_chunk_id=req.around_chunk_id,
            window=req.window_chunks,
        )
        for c in chunks:
            self._cache_put(c)
        log.info(
            "rage.retrieve.l3",
            source_uri=req.source_uri,
            returned=len(chunks),
            truncated=truncated,
        )
        return TranscriptWindow(
            source_uri=req.source_uri,
            chunks=chunks,
            total_lines=total_lines,
            truncated=truncated,
        )


__all__ = [
    "ProgressiveDisclosureService",
    "RageBackend",
    "SNIPPET_CONTEXT_LINES",
    "SNIPPET_TARGET_CHARS",
]
