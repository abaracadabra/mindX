# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""Pydantic schemas for the cherry-picked RAGE extensions."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, Field, NonNegativeInt, PositiveInt


class MemoryTier(StrEnum):
    """Mirrors mindX hot/warm/cold lifecycle tiering."""

    HOT = "hot"
    WARM = "warm"
    COLD = "cold"


class MemoryType(StrEnum):
    """Mirrors mindX memory_agent MemoryType enum."""

    INTERACTION = "interaction"
    CONTEXT = "context"
    LEARNING = "learning"
    SYSTEM_STATE = "system_state"
    PERFORMANCE = "performance"
    ERROR = "error"
    GOAL = "goal"
    BELIEF = "belief"
    PLAN = "plan"


class Importance(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class ChunkSnippet(BaseModel):
    """L1 result: cheap snippet for ranking and triage.

    Designed to be ~150-400 tokens so an agent can scan 10-20 candidates
    without blowing the context budget.
    """

    chunk_id: str = Field(..., min_length=64, max_length=64, description="64-char hex sha256")
    source_uri: str
    snippet: str = Field(..., description="Token-budgeted excerpt; not the full chunk")
    score: float = Field(..., description="Hybrid retrieval score (BM25+dense+graph+CE)")
    memory_type: MemoryType
    importance: Importance
    tier: MemoryTier
    created_at: datetime
    expanded: Literal[False] = False


class ChunkFull(BaseModel):
    """L2 result: full chunk text with neighborhood metadata.

    Returned by /api/rage/retrieve/expand. Holds the entire chunk body
    plus links to siblings in the same source so the agent can walk
    laterally without round-tripping to L1.
    """

    chunk_id: str = Field(..., min_length=64, max_length=64)
    source_uri: str
    start_line: NonNegativeInt
    end_line: NonNegativeInt
    content: str
    content_hash: str = Field(..., min_length=64, max_length=64)
    memory_type: MemoryType
    importance: Importance
    tier: MemoryTier
    created_at: datetime
    embedding_model: str
    prev_chunk_id: str | None = None
    next_chunk_id: str | None = None
    expanded: Literal[True] = True


class TranscriptWindow(BaseModel):
    """L3 result: full transcript / source document around a chunk.

    Returned by /api/rage/retrieve/transcript. Use sparingly — this is
    the heaviest tier and meant for forensic drill-down only.
    """

    source_uri: str
    chunks: list[ChunkFull]
    total_lines: NonNegativeInt
    truncated: bool = Field(default=False, description="True if a window cap was applied")


class RetrieveRequest(BaseModel):
    """L1 request body — mirrors existing /api/rage/retrieve."""

    query: str = Field(..., min_length=1, max_length=4096)
    top_k: PositiveInt = Field(default=10, le=100)
    memory_types: list[MemoryType] | None = None
    min_importance: Importance | None = None
    tier_filter: list[MemoryTier] | None = None


class ExpandRequest(BaseModel):
    """L2 request body."""

    chunk_id: str = Field(..., min_length=64, max_length=64)
    include_neighbors: bool = Field(
        default=True,
        description="If true, populate prev_chunk_id / next_chunk_id",
    )


class TranscriptRequest(BaseModel):
    """L3 request body."""

    source_uri: str
    around_chunk_id: str | None = Field(
        default=None,
        description="Center the window on this chunk; None returns the whole source",
    )
    window_chunks: PositiveInt = Field(
        default=20,
        le=200,
        description="Max chunks before+after; hard cap protects context budget",
    )


class RetrieveResponse(BaseModel):
    results: list[ChunkSnippet]
    query: str
    latency_ms: float


__all__ = [
    "ChunkFull",
    "ChunkSnippet",
    "ExpandRequest",
    "Importance",
    "MemoryTier",
    "MemoryType",
    "RetrieveRequest",
    "RetrieveResponse",
    "TranscriptRequest",
    "TranscriptWindow",
]
