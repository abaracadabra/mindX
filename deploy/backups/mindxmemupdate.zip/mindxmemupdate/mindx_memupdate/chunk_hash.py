# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Pattern 2 of 3 ported from zilliztech/memsearch (MIT, inherited from OpenClaw):
# composite primary key for chunk rows in pgvector so re-indexing skips
# unchanged content without a separate dedup cache. Halves embedding cost on
# incremental machine.dreaming cycles.
"""SHA-256 composite primary key for mindX RAGE / Knowledge Catalogue chunks.

The chunk_id is computed deterministically from a stable tuple:

    (source_uri, start_line, end_line, content_hash, embedding_model)

This means the same chunk indexed by the same model produces the same
chunk_id across machines, restarts, and re-ingests. Re-indexing becomes
an idempotent upsert: rows already present (matched by primary key) are
skipped at the SQL layer, no embedding call is issued.

Compatible with mindX's pgvector schema on PostgreSQL 16. The chunk_id is
encoded as a 64-character lowercase hex string (BYTEA recommended in
schema for compactness; TEXT accepted for portability).
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Final

# Hash algorithm constant — single source of truth.
# Changing this invalidates all existing chunk_ids; bump CHUNK_SCHEMA_VERSION below
# and run a full re-index. Do not change casually.
_HASH_ALGO: Final[str] = "sha256"
_FIELD_SEP: Final[str] = "\x1f"  # ASCII unit separator, cannot appear in URIs
_DIGEST_HEX_LEN: Final[int] = 64

# Bump when the composite-key shape changes (fields added/removed/reordered).
# Keys produced under different versions are not comparable.
CHUNK_SCHEMA_VERSION: Final[int] = 1


@dataclass(frozen=True, slots=True)
class ChunkKey:
    """Stable identity for a chunk.

    Attributes:
        source_uri: Canonical, unambiguous source identifier. For mindX:
            ``ltm://<session_id>/<event_seq>`` for LTM events,
            ``catalogue://<entry_group>/<entry_id>`` for Knowledge Catalogue
            entries, ``ipfs://<cid>#<offset>`` for offloaded chunks,
            ``file://<abs_path>`` for raw file ingest.
        start_line: 1-indexed inclusive start line within ``source_uri``.
            Use 0 for non-line-oriented sources (binary, JSON blobs); in that
            case ``end_line`` must also be 0.
        end_line: 1-indexed inclusive end line. Must be >= ``start_line``.
        content_hash: SHA-256 hex digest of the chunk text as ingested
            (post-normalization, pre-embedding). Computed by
            :func:`content_hash_hex`.
        embedding_model: Fully-qualified embedding model identifier, e.g.
            ``ollama:nomic-embed-text:v1.5`` or ``openai:text-embedding-3-small``.
            Including the model means re-embedding under a new model produces
            new rows; the old rows can be GC'd by the prune job.
    """

    source_uri: str
    start_line: int
    end_line: int
    content_hash: str
    embedding_model: str

    def __post_init__(self) -> None:
        if not self.source_uri:
            raise ValueError("source_uri must be non-empty")
        if _FIELD_SEP in self.source_uri:
            raise ValueError("source_uri may not contain the unit-separator byte")
        if self.start_line < 0 or self.end_line < 0:
            raise ValueError("line numbers must be non-negative")
        if self.end_line < self.start_line:
            raise ValueError("end_line must be >= start_line")
        if len(self.content_hash) != _DIGEST_HEX_LEN:
            raise ValueError(
                f"content_hash must be {_DIGEST_HEX_LEN} hex chars (sha256); "
                f"got {len(self.content_hash)}"
            )
        if not self.embedding_model:
            raise ValueError("embedding_model must be non-empty")

    def chunk_id(self) -> str:
        """Return the 64-char lowercase hex chunk_id.

        Deterministic across processes and machines.
        """
        h = hashlib.new(_HASH_ALGO)
        payload = _FIELD_SEP.join(
            [
                f"v{CHUNK_SCHEMA_VERSION}",
                self.source_uri,
                str(self.start_line),
                str(self.end_line),
                self.content_hash,
                self.embedding_model,
            ]
        )
        h.update(payload.encode("utf-8"))
        return h.hexdigest()


def content_hash_hex(text: str) -> str:
    """SHA-256 hex digest of a chunk's text, NFC-normalized and stripped.

    Normalization is conservative on purpose: we strip leading/trailing
    whitespace and collapse Windows line endings to LF so the same logical
    chunk hashes identically across platforms, but preserve interior
    whitespace because indentation is semantically meaningful for code and
    markdown chunks (mindX ingests both).
    """
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    return hashlib.new(_HASH_ALGO, normalized.encode("utf-8")).hexdigest()


def make_chunk_id(
    *,
    source_uri: str,
    start_line: int,
    end_line: int,
    text: str,
    embedding_model: str,
) -> tuple[str, str]:
    """Convenience: returns ``(chunk_id, content_hash)`` for a chunk.

    Use this from the ingest path; the returned content_hash should be stored
    alongside chunk_id so prune jobs can detect drift without re-hashing.
    """
    ch = content_hash_hex(text)
    key = ChunkKey(
        source_uri=source_uri,
        start_line=start_line,
        end_line=end_line,
        content_hash=ch,
        embedding_model=embedding_model,
    )
    return key.chunk_id(), ch


__all__ = [
    "CHUNK_SCHEMA_VERSION",
    "ChunkKey",
    "content_hash_hex",
    "make_chunk_id",
]
