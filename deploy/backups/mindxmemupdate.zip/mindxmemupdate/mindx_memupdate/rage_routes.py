# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""FastAPI router exposing the L1/L2/L3 progressive-disclosure endpoints.

Mounts as ``app.include_router(rage_router, prefix="/api/rage")`` so the
final routes are:

    POST /api/rage/retrieve              (L1)  -- existing path, extended
    POST /api/rage/retrieve/expand       (L2)  -- NEW
    POST /api/rage/retrieve/transcript   (L3)  -- NEW

The existing mindX ``/api/rage/retrieve`` route can either delegate to the
L1 handler here, or be left as-is — L2 and L3 are additive and do not
conflict with the current 307-endpoint surface.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from .progressive_disclosure import ProgressiveDisclosureService
from .schemas import (
    ChunkFull,
    ExpandRequest,
    RetrieveRequest,
    RetrieveResponse,
    TranscriptRequest,
    TranscriptWindow,
)


def build_router(service_dep: type) -> APIRouter:
    """Build the RAGE router using a FastAPI dependency that returns the service.

    Pattern lets mindX inject its concrete ``ProgressiveDisclosureService``
    (wired with the production pgvector + Knowledge Catalogue backend) via
    ``Depends`` without this module importing the backend directly.

    Example wiring in mindX main app::

        from mindx_memupdate.rage_routes import build_router
        from mindx.api.deps import get_progressive_disclosure_service

        app.include_router(
            build_router(get_progressive_disclosure_service),
            prefix="/api/rage",
            tags=["rage"],
        )
    """
    router = APIRouter()

    @router.post(
        "/retrieve",
        response_model=RetrieveResponse,
        summary="L1: ranked snippet retrieval",
    )
    async def retrieve_l1(
        req: RetrieveRequest,
        service: ProgressiveDisclosureService = Depends(service_dep),
    ) -> RetrieveResponse:
        return await service.retrieve(req)

    @router.post(
        "/retrieve/expand",
        response_model=ChunkFull,
        summary="L2: full body of a single chunk by chunk_id",
        responses={404: {"description": "chunk_id not found"}},
    )
    async def retrieve_l2(
        req: ExpandRequest,
        service: ProgressiveDisclosureService = Depends(service_dep),
    ) -> ChunkFull:
        chunk = await service.expand(req)
        if chunk is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"chunk_id {req.chunk_id} not found",
            )
        return chunk

    @router.post(
        "/retrieve/transcript",
        response_model=TranscriptWindow,
        summary="L3: source-wide transcript window (forensic drill-down)",
    )
    async def retrieve_l3(
        req: TranscriptRequest,
        service: ProgressiveDisclosureService = Depends(service_dep),
    ) -> TranscriptWindow:
        return await service.transcript(req)

    return router


__all__ = ["build_router"]
