# Architecture

## Position in mindX

```
                        ┌─────────────────────────────────────┐
                        │   mindX BDI Agent (P-O-D-A loop)    │
                        │                                     │
                        │   Perceive ─► Orient ─► Decide ─► Act
                        │                  │                  │
                        │                  ▼                  │
                        │       forked_recall(...)            │
                        │       (Pattern 3)                   │
                        └──────────────────┬──────────────────┘
                                           │
                                           ▼
                        ┌─────────────────────────────────────┐
                        │ ProgressiveDisclosureService        │
                        │ (Pattern 1)                         │
                        │                                     │
                        │  L1 retrieve  ─► snippets           │
                        │  L2 expand    ─► full chunk         │
                        │  L3 transcript ─► source window     │
                        └──────────────────┬──────────────────┘
                                           │
                                           ▼
                        ┌─────────────────────────────────────┐
                        │ RageBackend (Protocol)              │
                        │                                     │
                        │ ─► PgvectorRageBackend (reference)  │
                        │ ─► mindX Knowledge Catalogue        │
                        │     (BM25+dense+graph+CE — existing)│
                        └──────────────────┬──────────────────┘
                                           │
                                           ▼
                        ┌─────────────────────────────────────┐
                        │ PostgreSQL 16 + pgvector            │
                        │                                     │
                        │  rage_chunks                        │
                        │   PK: chunk_id CHAR(64)             │
                        │       (Pattern 2 — composite hash)  │
                        │  rage_recall_traces                 │
                        │       (Gödel audit log)             │
                        └─────────────────────────────────────┘
```

## Data flow

### Ingest (machine.dreaming consolidation)

```
event/text ──► normalize ──► content_hash_hex ──► make_chunk_id ──► upsert_chunk_sql
                                                       │
                                                       ▼
                                              ON CONFLICT DO UPDATE
                                              WHERE content_hash IS DISTINCT
                                              (skips no-op re-ingest)
```

### Retrieve (AGInt orient phase)

```
Orient(query)
   │
   ▼
forked_recall.open() ── scratch = dict(parent.beliefs)
   │
   ├── L1 retrieve(query, top_k=10)         ─► 10 snippets, ~3.5k tokens total
   │       │
   │       └── for snippet in top_k:
   │              ├── L2 expand(chunk_id)    ─► full body if worth opening
   │              ├── policy(snippet, full)  ─► True/False
   │              └── if promote: fork.promote_chunk(full)
   │
   ▼
forked_recall.close() ── merge promoted_keys ─► parent.beliefs
                          discard scratch (and all noise)
                          emit RecallTrace ─► rage_recall_traces
```

## Three patterns, three guarantees

### Pattern 1 — Progressive disclosure

**Guarantee:** an agent never pays for chunk bodies it ranks but doesn't read.

Snippets are 1.4kB cap. A full chunk averages ~4-12kB. Top-k=10 retrieval drops from ~80kB → ~14kB on the wire (snippet phase), and the L2 cost is paid only for the 1-3 chunks the agent actually promotes.

### Pattern 2 — Composite chunk PK

**Guarantee:** `chunk_id` is a pure function of `(source_uri, start_line, end_line, content_hash, embedding_model)`. Same inputs anywhere produce the same ID.

Consequences:
- Re-running an ingest on unchanged source is a no-op at the SQL layer (ON CONFLICT skip).
- Re-embedding under a new model produces fresh rows, never overwrites old ones; prune jobs GC by `embedding_model` field.
- No separate dedup cache needed; the PK is the dedup cache.
- Schema version is baked into the hash payload (`v1`), so future shape changes trigger a clean re-index rather than silent collisions.

### Pattern 3 — Forked recall context

**Guarantee:** intermediate retrieval state never enters the parent belief base.

Two failure modes were considered and handled:

1. **Exception during orient.** All promotions are forfeit; the parent is observed in pre-fork state.
2. **Belief base is not a mutable mapping.** Promotions accumulate in `fork.promoted_chunks` and `fork.promoted_keys`; the caller harvests manually. mindX's read-only belief views still work.

The `forked_recall_deep` variant exists for the (rare) case where the fork needs to mutate nested belief structures. ~10× slower than the shallow variant; the docstring warns against use in the orient hot path.

## What this stack is NOT

- Not a RAG framework. mindX RAGE is the framework; this package is three additive patches.
- Not a vector DB. pgvector is. This package is the protocol + reference adapter.
- Not a memory consolidation engine. `machine.dreaming` is. This package's composite PK supports machine.dreaming's idempotency requirements.
- Not a graph layer. mindX Knowledge Catalogue handles graph. The RageBackend Protocol lets the existing graph+CE rerank slot in front of this package's L1.
- Not a replacement for memsearch. memsearch is a markdown-first cross-IDE plugin layer; mindX is a server-side autonomous-agent platform. The three patterns are the only overlap worth porting.
