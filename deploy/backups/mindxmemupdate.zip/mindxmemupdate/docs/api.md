# API Reference

## HTTP endpoints (mounted at `/api/rage`)

### `POST /api/rage/retrieve` — L1

Request:
```json
{
  "query": "string",
  "top_k": 10,
  "memory_types": ["context", "belief"],
  "min_importance": "high",
  "tier_filter": ["hot", "warm"]
}
```

Response:
```json
{
  "results": [
    {
      "chunk_id": "7c4f...",
      "source_uri": "ltm://sess-42/event-9",
      "snippet": "...",
      "score": 0.847,
      "memory_type": "context",
      "importance": "high",
      "tier": "hot",
      "created_at": "2026-05-22T00:00:00Z",
      "expanded": false
    }
  ],
  "query": "...",
  "latency_ms": 23.4
}
```

### `POST /api/rage/retrieve/expand` — L2

Request:
```json
{ "chunk_id": "7c4f...", "include_neighbors": true }
```

Response: full `ChunkFull` object including `content`, `prev_chunk_id`, `next_chunk_id`.

404 if chunk_id is unknown.

### `POST /api/rage/retrieve/transcript` — L3

Request:
```json
{
  "source_uri": "ltm://sess-42/event-9",
  "around_chunk_id": "7c4f...",
  "window_chunks": 20
}
```

Response: `TranscriptWindow` with `chunks` (sorted by `start_line`), `total_lines`, `truncated`.

---

## Python API

### `make_chunk_id(...)` → `(chunk_id, content_hash)`

```python
chunk_id, content_hash = make_chunk_id(
    source_uri="ltm://sess-42/event-9",
    start_line=1,
    end_line=15,
    text="...",
    embedding_model="ollama:nomic-embed-text:v1.5",
)
```

### `ProgressiveDisclosureService(backend, warm_cache_size=256)`

- `.retrieve(req: RetrieveRequest) -> RetrieveResponse`
- `.expand(req: ExpandRequest) -> ChunkFull | None`
- `.transcript(req: TranscriptRequest) -> TranscriptWindow`

### `forked_recall(agent, *, query=None, parent_id=None)`

Async context manager. Yields `ForkedRecallContext` with:

- `.note(key, value)` — write scratch (not promoted)
- `.inspect_chunk(chunk)` — audit-only increment
- `.promote_belief(key, value)` — flag for parent merge
- `.promote_chunk(chunk)` — collect for caller harvest
- `.trace` — `RecallTrace` (fork_id, parent_id, timing, counts)

On `__aexit__`:
- Normal exit: promoted keys merged to `parent.beliefs` if dict; trace finalized.
- Exception: promotions forfeit; trace marks `aborted`.

### `forked_recall_deep(agent, ...)`

Same contract, deepcopies belief base on entry. Use only when fork mutates nested objects.

### `build_router(service_dep)` → `APIRouter`

`service_dep` is a FastAPI dependency callable that returns a `ProgressiveDisclosureService`. Lets mindX wire its concrete backend via `Depends` without circular imports.

---

## Protocol contract: `RageBackend`

Implement to integrate any backend. Methods:

- `async hybrid_search(req: RetrieveRequest) -> list[ChunkFull]`
- `async get_chunk(chunk_id: str) -> ChunkFull | None`
- `async get_neighbors(chunk_id: str) -> tuple[str | None, str | None]`
- `async get_source_chunks(source_uri, around_chunk_id, window) -> tuple[list[ChunkFull], int, bool]`

`PgvectorRageBackend` is the reference implementation. mindX's Knowledge Catalogue can be wrapped in another adapter that adds graph traversal + cross-encoder rerank before returning to L1.

---

## SQL surface

### `rage_chunks`

| Column | Type | Notes |
|---|---|---|
| `chunk_id` | CHAR(64) | PK — sha256 hex from `make_chunk_id` |
| `source_uri` | TEXT | canonical source identifier |
| `start_line`, `end_line` | INTEGER | inclusive 0/1-indexed |
| `content` | TEXT | chunk body |
| `content_hash` | CHAR(64) | sha256 of normalized text |
| `embedding` | vector(768) | configurable dim via migration edit |
| `embedding_model` | TEXT | model fingerprint |
| `memory_type` | mindx_memory_type | enum |
| `importance` | mindx_importance | enum |
| `importance_rank` | SMALLINT | auto-synced by trigger |
| `tier` | mindx_tier | enum (hot/warm/cold) |
| `created_at`, `updated_at` | TIMESTAMPTZ | auto |
| `metadata` | JSONB | open-ended |

Indexes: HNSW(embedding cosine), GIN trgm(content), btree(source_uri, start_line), btree(memory_type, tier, importance_rank), btree(created_at DESC).

### `rage_recall_traces`

Append-only audit table consumed by `/insight/eval/recent`. Schema in `migrations/001_chunk_composite_pk.sql`.

---

## Structlog events

| Event | Fields |
|---|---|
| `rage.retrieve.l1` | query_len, top_k, returned, latency_ms |
| `rage.retrieve.l2.warm_hit` | chunk_id |
| `rage.retrieve.l2.miss` | chunk_id |
| `rage.retrieve.l3` | source_uri, returned, truncated |
| `recall.fork.open` | fork_id, parent_id, query |
| `recall.fork.close` | fork_id, chunks_inspected, chunks_promoted, promoted_keys, duration_ms |
| `recall.fork.aborted` | fork_id, parent_id, chunks_inspected |
| `agint.orient.l1` | fork_id, returned, latency_ms |
