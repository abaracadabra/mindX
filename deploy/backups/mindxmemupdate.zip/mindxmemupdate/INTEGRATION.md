# mindX Integration Guide

Four-step injection of `mindx_memupdate` into the deployed mindX system at `mindx.pythai.net`. Total wiring time: ~30 minutes; zero downtime if migration is run with `CREATE INDEX CONCURRENTLY` substitutions on the hot path.

---

## Step 1 — Apply the schema migration

```bash
psql "$MINDX_DATABASE_URL" -f migrations/001_chunk_composite_pk.sql
```

Adds `rage_chunks` (composite-hash PK), `rage_recall_traces` (Gödel audit), three mindX enums (`mindx_memory_type`, `mindx_importance`, `mindx_tier`), and HNSW + pg_trgm indexes. Idempotent.

**Existing data:** if mindX already has a `rage_chunks` or equivalent table, rename the new one (e.g., `rage_chunks_v2`) and run a one-shot backfill that recomputes chunk_id via `make_chunk_id` and inserts ON CONFLICT DO NOTHING. Schedule under a `machine.dreaming` 8h dream shift to avoid disrupting STM writes.

## Step 2 — Mount the L1/L2/L3 router

In the mindX FastAPI entrypoint (the file that builds the 307-endpoint app):

```python
from mindx_memupdate.rage_routes import build_router
from mindx_memupdate.progressive_disclosure import ProgressiveDisclosureService
from mindx_memupdate.pgvector_backend import PgvectorRageBackend

async def get_rage_service() -> ProgressiveDisclosureService:
    # Reuse mindX's existing asyncpg.Pool and embed function.
    backend = PgvectorRageBackend(
        pool=app.state.pg_pool,
        embed_fn=app.state.embed_fn,
        embedding_dim=768,
    )
    return ProgressiveDisclosureService(backend, warm_cache_size=512)

app.include_router(
    build_router(get_rage_service),
    prefix="/api/rage",
    tags=["rage"],
)
```

After mount the surface is:

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/rage/retrieve` | L1 — ranked snippets |
| POST | `/api/rage/retrieve/expand` | L2 — full chunk + neighbors |
| POST | `/api/rage/retrieve/transcript` | L3 — source-wide window |

The existing `/api/rage/retrieve` route either delegates here or coexists; L2 and L3 are purely additive.

## Step 3 — Swap the ingest path

In `agents/memory_agent.py`, replace whatever currently generates chunk PKs with `make_chunk_id`:

```python
from mindx_memupdate import make_chunk_id
from mindx_memupdate.agents.memory_agent_patch import upsert_chunk_sql

async def store_chunk(self, *, source_uri, start_line, end_line, text, memory_type, importance, embedding):
    chunk_id, content_hash = make_chunk_id(
        source_uri=source_uri,
        start_line=start_line,
        end_line=end_line,
        text=text,
        embedding_model=self.embedding_model,
    )
    await self.pool.execute(
        upsert_chunk_sql("rage_chunks"),
        chunk_id, source_uri, start_line, end_line, text, content_hash,
        embedding, self.embedding_model,
        memory_type.value, importance.value, "hot", {},
    )
```

Same chunk → same `chunk_id` → ON CONFLICT skips re-embedding when `content_hash` is unchanged. Expected effect on incremental `machine.dreaming` cycles: ~50% reduction in embedding calls (memsearch reports similar; verify on your own logs after one full dream cycle).

## Step 4 — Wire forked recall into AGInt orient

In `agents/bdi_agent.py`, find the orient phase that currently calls RAGE directly and replace with:

```python
from mindx_memupdate.agents.memory_agent_patch import orient_with_forked_recall

async def orient(self, perception: dict) -> None:
    trace = await orient_with_forked_recall(
        agent=self,
        query=perception["query"],
        rage_service=self.rage_service,
        top_k=10,
        memory_types=[MemoryType.CONTEXT, MemoryType.LEARNING, MemoryType.BELIEF],
    )
    await self.godel_log.append("agint.orient", trace)
```

The agent's `beliefs` mapping is now only mutated by chunks that pass the promotion policy (default: HIGH/CRITICAL only). Everything else stays in the fork's scratch and is dropped on context exit.

For audit, the trace dict is the shape expected by `/insight/eval/recent`:

```json
{
  "fork_id": "9b1f3a...",
  "query": "why did CEO veto?",
  "inspected": 10,
  "promoted": 2,
  "promoted_chunk_ids": ["7c4f...", "a103..."]
}
```

---

## Rollback

```bash
psql "$MINDX_DATABASE_URL" -f migrations/001_chunk_composite_pk.down.sql
```

Then revert the four code edits above. No data loss if the old chunk table was renamed in Step 1 rather than dropped.

## Observability

All three patterns emit structlog events under stable keys:

| Event | Source |
|---|---|
| `rage.retrieve.l1`, `rage.retrieve.l2.*`, `rage.retrieve.l3` | progressive_disclosure |
| `recall.fork.open`, `recall.fork.close`, `recall.fork.aborted` | forked_recall |
| `agint.orient.l1` | memory_agent_patch |

Pipe through mindX's existing structlog → JSONL → NATS subject layout. No new infrastructure.

## Verification checklist

- [ ] `pytest -v` → 37 passed
- [ ] `psql -c "\\d rage_chunks"` shows composite PK on `chunk_id CHAR(64)`
- [ ] `curl -X POST /api/rage/retrieve/expand -d '{"chunk_id":"…"}'` returns 200 with full body
- [ ] AGInt orient logs show `chunks_inspected >= chunks_promoted` with a non-zero `fork_id`
- [ ] Re-running an identical ingest job results in zero new embedding calls (`grep "embed.call" logs/`)

## kaizen.agent registry entry

After successful integration, append to the Library Registry:

```yaml
- name: zilliztech/memsearch
  license: MIT
  status: patterns_only
  adopted_patterns:
    - progressive_disclosure_l1_l2_l3
    - sha256_composite_chunk_pk
    - forked_subagent_recall_context
  rejected_components:
    - MilvusStore
    - claude-code-plugin
    - opencode-plugin
    - codex-cli-plugin
  rationale: |
    Project hard-coupled to Milvus; conflicts with mindX pgvector standard.
    Scope is IDE coding-agent plugin layer, out of scope for mindX.
    Three retrieval patterns were re-implemented from scratch against
    mindX primitives (Apache-2.0, no vendored MIT code).
  next_evaluation: getzep/graphiti  # see relevance assessment
```
