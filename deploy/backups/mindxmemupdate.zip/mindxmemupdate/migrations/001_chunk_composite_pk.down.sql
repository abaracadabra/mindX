-- Copyright 2026 BANKON
-- Licensed under the Apache License, Version 2.0
-- Rollback for migration 001.
BEGIN;
DROP TABLE IF EXISTS rage_recall_traces;
DROP TRIGGER IF EXISTS trg_rage_chunks_importance ON rage_chunks;
DROP FUNCTION IF EXISTS rage_chunks_set_importance_rank();
DROP TABLE IF EXISTS rage_chunks;
DROP TYPE IF EXISTS mindx_tier;
DROP TYPE IF EXISTS mindx_importance;
DROP TYPE IF EXISTS mindx_memory_type;
COMMIT;
