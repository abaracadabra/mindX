-- Copyright 2026 BANKON
-- Licensed under the Apache License, Version 2.0
--
-- Migration 001: chunk composite primary key for mindX RAGE.
--
-- Idempotent; safe to run multiple times. Creates the rage_chunks table
-- if absent and adds the composite-hash chunk_id as PK + supporting
-- indexes for hybrid retrieval (pgvector + pg_trgm).
--
-- Run on PostgreSQL 16 with pgvector >= 0.7 already installed.
--
-- Rollback: see migrations/001_chunk_composite_pk.down.sql

BEGIN;

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS btree_gin;

-- Memory-type and importance domains. Mirror mindX enums so referential
-- integrity is enforced at the DB layer, not just the Pydantic layer.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'mindx_memory_type') THEN
        CREATE TYPE mindx_memory_type AS ENUM (
            'interaction', 'context', 'learning', 'system_state',
            'performance', 'error', 'goal', 'belief', 'plan'
        );
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'mindx_importance') THEN
        CREATE TYPE mindx_importance AS ENUM ('low', 'medium', 'high', 'critical');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'mindx_tier') THEN
        CREATE TYPE mindx_tier AS ENUM ('hot', 'warm', 'cold');
    END IF;
END$$;

-- rage_chunks: the canonical chunk table.
-- chunk_id is the 64-char hex sha256 produced by mindx_memupdate.chunk_hash.
CREATE TABLE IF NOT EXISTS rage_chunks (
    chunk_id          CHAR(64) PRIMARY KEY,
    source_uri        TEXT NOT NULL,
    start_line        INTEGER NOT NULL CHECK (start_line >= 0),
    end_line          INTEGER NOT NULL CHECK (end_line >= start_line),
    content           TEXT NOT NULL,
    content_hash      CHAR(64) NOT NULL,
    embedding         vector(768) NOT NULL,
    embedding_model   TEXT NOT NULL,
    memory_type       mindx_memory_type NOT NULL,
    importance        mindx_importance NOT NULL DEFAULT 'medium',
    importance_rank   SMALLINT NOT NULL DEFAULT 2,
    tier              mindx_tier NOT NULL DEFAULT 'hot',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    schema_version    SMALLINT NOT NULL DEFAULT 1,
    metadata          JSONB NOT NULL DEFAULT '{}'::jsonb
);

-- Keep importance_rank in sync with importance via trigger so SQL
-- filters can use numeric comparisons (>= 3 means HIGH or CRITICAL).
CREATE OR REPLACE FUNCTION rage_chunks_set_importance_rank()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    NEW.importance_rank := CASE NEW.importance
        WHEN 'low' THEN 1
        WHEN 'medium' THEN 2
        WHEN 'high' THEN 3
        WHEN 'critical' THEN 4
    END;
    NEW.updated_at := now();
    RETURN NEW;
END$$;

DROP TRIGGER IF EXISTS trg_rage_chunks_importance ON rage_chunks;
CREATE TRIGGER trg_rage_chunks_importance
    BEFORE INSERT OR UPDATE ON rage_chunks
    FOR EACH ROW EXECUTE FUNCTION rage_chunks_set_importance_rank();

-- Dense ANN index. HNSW gives lower-latency reads than IVFFlat at the
-- 157K+ vector scale mindX is running today.
CREATE INDEX IF NOT EXISTS rage_chunks_embedding_hnsw
    ON rage_chunks USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- Sparse/BM25-ish full-text via pg_trgm.
CREATE INDEX IF NOT EXISTS rage_chunks_content_trgm
    ON rage_chunks USING gin (content gin_trgm_ops);

-- Common filter combinations.
CREATE INDEX IF NOT EXISTS rage_chunks_source_uri
    ON rage_chunks (source_uri, start_line);

CREATE INDEX IF NOT EXISTS rage_chunks_type_tier_imp
    ON rage_chunks (memory_type, tier, importance_rank);

CREATE INDEX IF NOT EXISTS rage_chunks_created_at
    ON rage_chunks (created_at DESC);

-- Audit log for the forked-recall pattern. Append-only; consumed by
-- mindX's Gödel choice log via /insight/eval/recent.
CREATE TABLE IF NOT EXISTS rage_recall_traces (
    fork_id            CHAR(16) PRIMARY KEY,
    parent_id          TEXT NOT NULL,
    query              TEXT,
    chunks_inspected   INTEGER NOT NULL DEFAULT 0,
    chunks_promoted    INTEGER NOT NULL DEFAULT 0,
    promoted_chunk_ids TEXT[] NOT NULL DEFAULT '{}',
    promoted_keys      TEXT[] NOT NULL DEFAULT '{}',
    duration_ms        DOUBLE PRECISION,
    started_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at        TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS rage_recall_traces_parent
    ON rage_recall_traces (parent_id, started_at DESC);

COMMIT;
