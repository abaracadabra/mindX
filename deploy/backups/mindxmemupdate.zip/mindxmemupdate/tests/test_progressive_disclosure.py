# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""Tests for the L1/L2/L3 progressive-disclosure service."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from mindx_memupdate.chunk_hash import make_chunk_id
from mindx_memupdate.progressive_disclosure import (
    SNIPPET_TARGET_CHARS,
    ProgressiveDisclosureService,
)
from mindx_memupdate.schemas import (
    ChunkFull,
    ExpandRequest,
    Importance,
    MemoryTier,
    MemoryType,
    RetrieveRequest,
    TranscriptRequest,
)


def _mk_chunk(
    *,
    source_uri: str,
    start_line: int,
    end_line: int,
    content: str,
    importance: Importance = Importance.MEDIUM,
) -> ChunkFull:
    cid, ch = make_chunk_id(
        source_uri=source_uri,
        start_line=start_line,
        end_line=end_line,
        text=content,
        embedding_model="test:v1",
    )
    return ChunkFull(
        chunk_id=cid,
        source_uri=source_uri,
        start_line=start_line,
        end_line=end_line,
        content=content,
        content_hash=ch,
        memory_type=MemoryType.CONTEXT,
        importance=importance,
        tier=MemoryTier.HOT,
        created_at=datetime.now(UTC),
        embedding_model="test:v1",
    )


class StubBackend:
    """In-memory RageBackend for tests."""

    def __init__(self, chunks: list[ChunkFull]) -> None:
        self._by_id = {c.chunk_id: c for c in chunks}
        # Group by source for neighbor + transcript queries.
        self._by_source: dict[str, list[ChunkFull]] = {}
        for c in chunks:
            self._by_source.setdefault(c.source_uri, []).append(c)
        for source_chunks in self._by_source.values():
            source_chunks.sort(key=lambda c: c.start_line)

    async def hybrid_search(self, req: RetrieveRequest) -> list[ChunkFull]:
        terms = [t.lower() for t in req.query.split()]
        scored = []
        for c in self._by_id.values():
            lo = c.content.lower()
            s = sum(lo.count(t) for t in terms)
            if s > 0:
                scored.append((s, c))
        scored.sort(key=lambda p: p[0], reverse=True)
        return [c for _, c in scored[: req.top_k]]

    async def get_chunk(self, chunk_id: str) -> ChunkFull | None:
        return self._by_id.get(chunk_id)

    async def get_neighbors(self, chunk_id: str) -> tuple[str | None, str | None]:
        target = self._by_id.get(chunk_id)
        if target is None:
            return None, None
        siblings = self._by_source[target.source_uri]
        idx = siblings.index(target)
        prev_id = siblings[idx - 1].chunk_id if idx > 0 else None
        next_id = siblings[idx + 1].chunk_id if idx < len(siblings) - 1 else None
        return prev_id, next_id

    async def get_source_chunks(
        self, source_uri: str, around_chunk_id: str | None, window: int
    ) -> tuple[list[ChunkFull], int, bool]:
        siblings = self._by_source.get(source_uri, [])
        total_lines = sum(c.end_line - c.start_line + 1 for c in siblings)
        if around_chunk_id is None:
            cap = window * 2 + 1
            return siblings[:cap], total_lines, len(siblings) > cap
        target = self._by_id.get(around_chunk_id)
        if target is None or target.source_uri != source_uri:
            return [], total_lines, False
        idx = siblings.index(target)
        start = max(0, idx - window)
        end = min(len(siblings), idx + window + 1)
        sliced = siblings[start:end]
        truncated = (start > 0) or (end < len(siblings))
        return sliced, total_lines, truncated


@pytest.fixture
def corpus() -> list[ChunkFull]:
    return [
        _mk_chunk(
            source_uri="ltm://sess-1",
            start_line=1, end_line=10,
            content="The BDI agent decides goals via P-O-D-A loop.",
            importance=Importance.HIGH,
        ),
        _mk_chunk(
            source_uri="ltm://sess-1",
            start_line=11, end_line=20,
            content="machine.dreaming runs every 2 hours consolidating LTM.",
            importance=Importance.CRITICAL,
        ),
        _mk_chunk(
            source_uri="ltm://sess-1",
            start_line=21, end_line=30,
            content="Unrelated content about weather and cooking.",
            importance=Importance.LOW,
        ),
        _mk_chunk(
            source_uri="ltm://sess-2",
            start_line=1, end_line=8,
            content="AGInt orient phase queries RAGE for context chunks.",
            importance=Importance.HIGH,
        ),
    ]


async def test_l1_returns_snippets_with_match(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus))
    resp = await svc.retrieve(RetrieveRequest(query="agent BDI", top_k=5))
    assert len(resp.results) >= 1
    # All results are L1 snippets, not full bodies.
    for r in resp.results:
        assert r.expanded is False
        assert len(r.snippet) <= SNIPPET_TARGET_CHARS


async def test_l1_returns_empty_on_no_match(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus))
    resp = await svc.retrieve(RetrieveRequest(query="xenomorph", top_k=5))
    assert resp.results == []


async def test_l2_warm_hit_after_l1(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus), warm_cache_size=64)
    resp = await svc.retrieve(RetrieveRequest(query="BDI", top_k=5))
    assert len(resp.results) >= 1
    cid = resp.results[0].chunk_id
    full = await svc.expand(ExpandRequest(chunk_id=cid))
    assert full is not None
    assert full.expanded is True
    assert full.chunk_id == cid


async def test_l2_cold_lookup(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus), warm_cache_size=0)
    cid = corpus[0].chunk_id
    full = await svc.expand(ExpandRequest(chunk_id=cid))
    assert full is not None
    assert full.chunk_id == cid


async def test_l2_neighbors_populated(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus))
    middle_chunk = corpus[1]  # middle of ltm://sess-1
    full = await svc.expand(
        ExpandRequest(chunk_id=middle_chunk.chunk_id, include_neighbors=True)
    )
    assert full is not None
    assert full.prev_chunk_id == corpus[0].chunk_id
    assert full.next_chunk_id == corpus[2].chunk_id


async def test_l2_neighbors_at_boundary(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus))
    first_chunk = corpus[0]
    full = await svc.expand(
        ExpandRequest(chunk_id=first_chunk.chunk_id, include_neighbors=True)
    )
    assert full is not None
    assert full.prev_chunk_id is None
    assert full.next_chunk_id == corpus[1].chunk_id


async def test_l2_missing_chunk_returns_none(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus))
    full = await svc.expand(ExpandRequest(chunk_id="0" * 64))
    assert full is None


async def test_l3_returns_full_source(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus))
    win = await svc.transcript(
        TranscriptRequest(source_uri="ltm://sess-1", window_chunks=10)
    )
    assert len(win.chunks) == 3
    assert all(c.source_uri == "ltm://sess-1" for c in win.chunks)


async def test_l3_centered_window(corpus: list[ChunkFull]) -> None:
    svc = ProgressiveDisclosureService(StubBackend(corpus))
    target = corpus[1].chunk_id
    win = await svc.transcript(
        TranscriptRequest(
            source_uri="ltm://sess-1",
            around_chunk_id=target,
            window_chunks=1,
        )
    )
    # window=1 around middle: prev + target + next = 3
    assert len(win.chunks) == 3
    assert {c.chunk_id for c in win.chunks} == {
        corpus[0].chunk_id,
        corpus[1].chunk_id,
        corpus[2].chunk_id,
    }


async def test_warm_cache_eviction() -> None:
    chunks = [
        _mk_chunk(
            source_uri=f"ltm://s{i}",
            start_line=1, end_line=2,
            content=f"chunk {i}",
        )
        for i in range(5)
    ]
    svc = ProgressiveDisclosureService(StubBackend(chunks), warm_cache_size=2)
    # Force three chunks into cache; oldest must evict.
    await svc.expand(ExpandRequest(chunk_id=chunks[0].chunk_id))
    await svc.expand(ExpandRequest(chunk_id=chunks[1].chunk_id))
    await svc.expand(ExpandRequest(chunk_id=chunks[2].chunk_id))
    # The internal dict should hold at most 2 entries.
    assert len(svc._warm) <= 2  # type: ignore[attr-defined]
