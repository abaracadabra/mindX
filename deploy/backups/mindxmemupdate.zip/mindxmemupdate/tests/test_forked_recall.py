# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""Tests for forked-subagent recall context isolation."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import pytest

from mindx_memupdate.chunk_hash import make_chunk_id
from mindx_memupdate.forked_recall import forked_recall, forked_recall_deep
from mindx_memupdate.schemas import ChunkFull, Importance, MemoryTier, MemoryType


class StubAgent:
    """Stand-in for mindX BDI agent."""

    def __init__(self, initial: dict[str, Any] | None = None) -> None:
        self.beliefs: dict[str, Any] = initial or {}


def _mk_chunk(content: str = "x") -> ChunkFull:
    cid, ch = make_chunk_id(
        source_uri="ltm://test", start_line=1, end_line=1,
        text=content, embedding_model="m",
    )
    return ChunkFull(
        chunk_id=cid, source_uri="ltm://test",
        start_line=1, end_line=1, content=content, content_hash=ch,
        memory_type=MemoryType.CONTEXT, importance=Importance.MEDIUM,
        tier=MemoryTier.HOT, created_at=datetime.now(UTC),
        embedding_model="m",
    )


async def test_unpromoted_writes_do_not_leak() -> None:
    agent = StubAgent({"goal": "ship"})
    async with forked_recall(agent, query="noise") as fork:
        fork.note("noise_1", "garbage")
        fork.note("noise_2", "more garbage")
    assert agent.beliefs == {"goal": "ship"}


async def test_promoted_beliefs_merge_to_parent() -> None:
    agent = StubAgent({"goal": "ship"})
    async with forked_recall(agent, query="q") as fork:
        fork.promote_belief("seen:abc", "ltm://x")
        fork.note("not_promoted", "x")
    assert agent.beliefs == {"goal": "ship", "seen:abc": "ltm://x"}


async def test_promoted_chunks_are_collected() -> None:
    agent = StubAgent()
    c1 = _mk_chunk("a")
    c2 = _mk_chunk("b")
    async with forked_recall(agent) as fork:
        fork.inspect_chunk(c1)
        fork.inspect_chunk(c2)
        fork.promote_chunk(c1)
    assert fork.trace.chunks_inspected == 2
    assert fork.trace.chunks_promoted == 1
    assert fork.trace.promoted_chunk_ids == [c1.chunk_id]


async def test_exception_forfeits_promotions() -> None:
    agent = StubAgent({"prior": 1})
    with pytest.raises(RuntimeError, match="boom"):
        async with forked_recall(agent) as fork:
            fork.promote_belief("should_not_appear", "x")
            raise RuntimeError("boom")
    assert agent.beliefs == {"prior": 1}


async def test_trace_has_duration() -> None:
    agent = StubAgent()
    async with forked_recall(agent, query="q") as fork:
        fork.note("k", "v")
    assert fork.trace.finished_at is not None
    assert fork.trace.duration_ms is not None
    assert fork.trace.duration_ms >= 0.0


async def test_fork_id_is_unique() -> None:
    agent = StubAgent()
    seen: set[str] = set()
    for _ in range(50):
        async with forked_recall(agent) as fork:
            seen.add(fork.fork_id)
    assert len(seen) == 50


async def test_query_recorded_in_trace() -> None:
    agent = StubAgent()
    async with forked_recall(agent, query="why did CEO veto?") as fork:
        pass
    assert fork.trace.query == "why did CEO veto?"


async def test_parent_id_override() -> None:
    agent = StubAgent()
    async with forked_recall(agent, parent_id="agint-7") as fork:
        pass
    assert fork.trace.parent_id == "agint-7"


async def test_scratch_isolates_shallow_mutations() -> None:
    agent = StubAgent({"shared_key": "original"})
    async with forked_recall(agent) as fork:
        fork.scratch_beliefs["shared_key"] = "scratch_mutation"
    # Shallow mutation in scratch must not affect parent.
    assert agent.beliefs["shared_key"] == "original"


async def test_deep_fork_isolates_nested_mutations() -> None:
    nested = {"inner": [1, 2, 3]}
    agent = StubAgent({"nested": nested})
    async with forked_recall_deep(agent) as fork:
        fork.scratch_beliefs["nested"]["inner"].append(99)
    assert agent.beliefs["nested"]["inner"] == [1, 2, 3]
    assert nested["inner"] == [1, 2, 3]


async def test_deep_fork_promotion_works() -> None:
    agent = StubAgent({"k": 1})
    async with forked_recall_deep(agent) as fork:
        fork.promote_belief("new_key", {"a": 1})
    assert agent.beliefs == {"k": 1, "new_key": {"a": 1}}


async def test_readonly_parent_supported() -> None:
    """Parents without dict beliefs still work; caller harvests manually."""

    class ReadOnlyAgent:
        @property
        def beliefs(self) -> dict[str, Any]:
            return {"frozen": True}

    agent = ReadOnlyAgent()
    chunks: list[ChunkFull] = []
    async with forked_recall(agent) as fork:
        c = _mk_chunk("hello")
        fork.promote_chunk(c)
        chunks = list(fork.promoted_chunks)
    assert len(chunks) == 1
    # Parent beliefs untouched because it is not a mutable dict.
    assert agent.beliefs == {"frozen": True}


async def test_promoted_keys_sorted_in_trace() -> None:
    agent = StubAgent()
    async with forked_recall(agent) as fork:
        fork.promote_belief("zebra", 1)
        fork.promote_belief("apple", 2)
        fork.promote_belief("mango", 3)
    assert fork.trace.promoted_keys == ["apple", "mango", "zebra"]
