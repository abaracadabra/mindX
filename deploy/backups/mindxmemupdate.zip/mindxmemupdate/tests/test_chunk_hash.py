# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""Tests for chunk_hash composite primary key."""

from __future__ import annotations

import pytest

from mindx_memupdate.chunk_hash import (
    CHUNK_SCHEMA_VERSION,
    ChunkKey,
    content_hash_hex,
    make_chunk_id,
)


def test_content_hash_hex_deterministic() -> None:
    a = content_hash_hex("hello world")
    b = content_hash_hex("hello world")
    assert a == b
    assert len(a) == 64
    assert all(c in "0123456789abcdef" for c in a)


def test_content_hash_normalizes_line_endings() -> None:
    assert content_hash_hex("line1\nline2") == content_hash_hex("line1\r\nline2")
    assert content_hash_hex("line1\nline2") == content_hash_hex("line1\rline2")


def test_content_hash_strips_outer_whitespace() -> None:
    assert content_hash_hex("  hello  \n") == content_hash_hex("hello")


def test_content_hash_preserves_interior_whitespace() -> None:
    # Indentation matters for code/markdown chunks.
    assert content_hash_hex("a  b") != content_hash_hex("a b")


def test_chunk_id_deterministic() -> None:
    k1 = ChunkKey(
        source_uri="ltm://sess-1/event-5",
        start_line=10,
        end_line=20,
        content_hash=content_hash_hex("body"),
        embedding_model="ollama:nomic-embed-text:v1.5",
    )
    k2 = ChunkKey(
        source_uri="ltm://sess-1/event-5",
        start_line=10,
        end_line=20,
        content_hash=content_hash_hex("body"),
        embedding_model="ollama:nomic-embed-text:v1.5",
    )
    assert k1.chunk_id() == k2.chunk_id()
    assert len(k1.chunk_id()) == 64


def test_chunk_id_changes_with_any_field() -> None:
    base = dict(
        source_uri="ltm://sess-1/event-5",
        start_line=10,
        end_line=20,
        content_hash=content_hash_hex("body"),
        embedding_model="ollama:nomic-embed-text:v1.5",
    )
    base_id = ChunkKey(**base).chunk_id()

    diffs = [
        {**base, "source_uri": "ltm://sess-1/event-6"},
        {**base, "start_line": 11},
        {**base, "end_line": 21},
        {**base, "content_hash": content_hash_hex("body2")},
        {**base, "embedding_model": "openai:text-embedding-3-small"},
    ]
    for d in diffs:
        assert ChunkKey(**d).chunk_id() != base_id


def test_chunk_id_is_collision_resistant_across_uri_components() -> None:
    # Ensure that "a" + "bc" never collides with "ab" + "c" by virtue of
    # the field-separator byte.
    k1 = ChunkKey(
        source_uri="a", start_line=0, end_line=0,
        content_hash=content_hash_hex("bc"),
        embedding_model="m",
    )
    k2 = ChunkKey(
        source_uri="ab", start_line=0, end_line=0,
        content_hash=content_hash_hex("c"),
        embedding_model="m",
    )
    assert k1.chunk_id() != k2.chunk_id()


def test_rejects_unit_separator_in_uri() -> None:
    with pytest.raises(ValueError, match="unit-separator"):
        ChunkKey(
            source_uri="bad\x1furi",
            start_line=0,
            end_line=0,
            content_hash=content_hash_hex("x"),
            embedding_model="m",
        )


def test_rejects_negative_lines() -> None:
    with pytest.raises(ValueError, match="non-negative"):
        ChunkKey(
            source_uri="a", start_line=-1, end_line=0,
            content_hash=content_hash_hex("x"), embedding_model="m",
        )


def test_rejects_end_before_start() -> None:
    with pytest.raises(ValueError, match="end_line"):
        ChunkKey(
            source_uri="a", start_line=10, end_line=5,
            content_hash=content_hash_hex("x"), embedding_model="m",
        )


def test_rejects_short_content_hash() -> None:
    with pytest.raises(ValueError, match="64 hex chars"):
        ChunkKey(
            source_uri="a", start_line=0, end_line=0,
            content_hash="abc",
            embedding_model="m",
        )


def test_rejects_empty_fields() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        ChunkKey(
            source_uri="", start_line=0, end_line=0,
            content_hash=content_hash_hex("x"), embedding_model="m",
        )
    with pytest.raises(ValueError, match="non-empty"):
        ChunkKey(
            source_uri="a", start_line=0, end_line=0,
            content_hash=content_hash_hex("x"), embedding_model="",
        )


def test_make_chunk_id_returns_consistent_pair() -> None:
    cid, ch = make_chunk_id(
        source_uri="ltm://x/y",
        start_line=1,
        end_line=3,
        text="hello",
        embedding_model="m",
    )
    assert ch == content_hash_hex("hello")
    expected = ChunkKey(
        source_uri="ltm://x/y", start_line=1, end_line=3,
        content_hash=ch, embedding_model="m",
    ).chunk_id()
    assert cid == expected


def test_schema_version_constant() -> None:
    assert CHUNK_SCHEMA_VERSION == 1
