# Changelog

All notable changes follow [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and [SemVer](https://semver.org/spec/v2.0.0.html).

## [0.1.0] — 2026-05-22

### Added
- **Pattern 1 — Progressive disclosure:** `ProgressiveDisclosureService` exposing L1 `/api/rage/retrieve`, L2 `/api/rage/retrieve/expand`, L3 `/api/rage/retrieve/transcript`. Snippet budget 1400 chars, 2-line context window, optional in-process warm cache.
- **Pattern 2 — Composite chunk PK:** `make_chunk_id(source_uri, start_line, end_line, text, embedding_model)` returning deterministic SHA-256 hex. Idempotent re-ingest via ON CONFLICT upsert.
- **Pattern 3 — Forked recall context:** `forked_recall(agent, query=...)` async context manager with `promote_chunk` / `promote_belief` escalation API. Exceptions forfeit all promotions. `forked_recall_deep` variant for nested mutations.
- `PgvectorRageBackend` reference adapter against `rage_chunks` schema (pgvector HNSW + pg_trgm).
- FastAPI router factory `build_router(service_dep)` for Depends-based wiring.
- SQL migration `001_chunk_composite_pk.sql` + down migration. Creates `rage_chunks`, `rage_recall_traces`, three mindX enums, HNSW + trgm + composite indexes.
- AGInt glue: `orient_with_forked_recall` helper producing Gödel-log-ready trace dicts.
- Memory recall skill prompt at `mindx_memupdate/prompts/memory_recall.md`.
- 37 tests; coverage of all three patterns including failure modes (exception forfeits promotions, missing chunks, cache eviction, boundary neighbors).

### Provenance
- Patterns derived from [zilliztech/memsearch](https://github.com/zilliztech/memsearch) (MIT). No upstream code vendored; re-implemented against mindX primitives.
- Rejected upstream components: `MilvusStore`, four IDE plugins, ONNX bge-m3 default.

### Compatibility
- Python ≥3.12
- PostgreSQL 16 + pgvector ≥0.7
- FastAPI ≥0.115, Pydantic ≥2.9
- mindX RAGE / Knowledge Catalogue / BDI-AGInt as documented at mindx.pythai.net/docs.html (215 docs, 307 endpoints)
