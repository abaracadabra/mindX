# mindx-memupdate

**Cherry-picked memsearch patterns ported to mindX, Milvus-free, pgvector-native.**

Three production-grade patterns extracted from [zilliztech/memsearch](https://github.com/zilliztech/memsearch) and adapted to mindX's deployed RAGE / Knowledge Catalogue / BDI-AGInt stack at `mindx.pythai.net`:

1. **3-layer progressive disclosure** for `/api/rage/retrieve*` — L1 snippet → L2 full chunk → L3 transcript window
2. **SHA-256 composite primary key** for pgvector chunks — idempotent re-ingest, no separate dedup cache
3. **Forked-subagent recall context** for AGInt P-O-D-A orient phase — discards retrieval noise before it touches the belief base

Apache-2.0, Python ≥3.12, snake_case, flat layout, no proprietary lock-in. cypherpunk2048-compliant.

## Why not just adopt memsearch?

memsearch is hard-coupled to Milvus, scoped to IDE coding-agent plugins, and has a flat memory model (no episodic/semantic split, no decay, no graph, no reflection). mindX is architecturally ahead on every axis except cross-IDE coding-session capture — which mindX doesn't need. See the relevance assessment artifact for the full gap analysis.

## Package layout

```
mindxmemupdate/
├── LICENSE                                # Apache 2.0
├── README.md                              # this file
├── INTEGRATION.md                         # mindX injection guide
├── CHANGELOG.md
├── pyproject.toml                         # Python 3.12+, no Milvus
├── migrations/
│   ├── 001_chunk_composite_pk.sql        # pgvector schema
│   └── 001_chunk_composite_pk.down.sql   # rollback
├── mindx_memupdate/
│   ├── __init__.py                       # public API surface
│   ├── chunk_hash.py                     # Pattern 2: composite PK
│   ├── progressive_disclosure.py         # Pattern 1: L1/L2/L3
│   ├── forked_recall.py                  # Pattern 3: context isolation
│   ├── rage_routes.py                    # FastAPI router
│   ├── pgvector_backend.py               # reference RageBackend adapter
│   ├── schemas.py                        # Pydantic models
│   └── prompts/
│       └── memory_recall.md              # AGInt skill prompt
├── agents/
│   └── memory_agent_patch.py             # BDI/AGInt glue
├── tests/
│   ├── test_chunk_hash.py
│   ├── test_progressive_disclosure.py
│   └── test_forked_recall.py
└── docs/
    ├── architecture.md
    └── api.md
```

## Install

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
```

## Run tests

```bash
pytest -v
```

## Apply DB migration (PostgreSQL 16 + pgvector ≥ 0.7)

```bash
psql "$MINDX_DATABASE_URL" -f migrations/001_chunk_composite_pk.sql
```

## Wire into mindX

See `INTEGRATION.md` for the four-step injection guide (router mount, ingest-path swap, AGInt orient phase replacement, Gödel log binding).

## Quickstart

```python
from mindx_memupdate import (
    make_chunk_id,
    ProgressiveDisclosureService,
    forked_recall,
    build_router,
)

# Pattern 2: composite PK at ingest
chunk_id, content_hash = make_chunk_id(
    source_uri="ltm://sess-42/event-9",
    start_line=1,
    end_line=15,
    text=chunk_body,
    embedding_model="ollama:nomic-embed-text:v1.5",
)

# Pattern 1: progressive disclosure
service = ProgressiveDisclosureService(backend=your_pgvector_backend)
snippets = await service.retrieve(RetrieveRequest(query="...", top_k=10))
chunk    = await service.expand(ExpandRequest(chunk_id=snippets.results[0].chunk_id))
window   = await service.transcript(TranscriptRequest(source_uri="..."))

# Pattern 3: forked recall in AGInt orient phase
async with forked_recall(bdi_agent, query="why did CEO veto?") as fork:
    for snippet in (await service.retrieve(req)).results:
        full = await service.expand(ExpandRequest(chunk_id=snippet.chunk_id))
        if full.importance in (Importance.HIGH, Importance.CRITICAL):
            fork.promote_chunk(full)
# bdi_agent.beliefs now contains only promoted chunks. Noise discarded.
```

## License

Apache-2.0. Copyright 2026 BANKON.

Upstream pattern provenance: [zilliztech/memsearch](https://github.com/zilliztech/memsearch) (MIT). No memsearch code is vendored; the three patterns were re-implemented from scratch against mindX primitives.
