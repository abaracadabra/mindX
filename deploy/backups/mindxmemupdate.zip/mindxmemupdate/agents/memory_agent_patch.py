# Copyright 2026 BANKON
# Licensed under the Apache License, Version 2.0
"""Integration patch for mindX agents/memory_agent.py and agents/bdi_agent.py.

This module is NOT imported by mindx_memupdate itself. It contains
copy-paste-ready snippets and a high-level glue helper so the AGInt
P-O-D-A orient phase invokes forked recall correctly.

The intent is that mindX's bdi_agent.py imports `orient_with_forked_recall`
and uses it in place of its current direct RAGE call. Existing decide/act
phases see the same belief base they always have, minus the chunk noise.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

import structlog

from mindx_memupdate.forked_recall import HasBeliefs, forked_recall
from mindx_memupdate.progressive_disclosure import ProgressiveDisclosureService
from mindx_memupdate.schemas import (
    ExpandRequest,
    Importance,
    MemoryType,
    RetrieveRequest,
)

log = structlog.get_logger(__name__)


# Type alias for a "promotion policy" — given a candidate chunk + its L2 body,
# return True if the chunk should be folded into the parent belief base.
PromotionPolicy = Callable[[Any, Any], Awaitable[bool]] | Callable[[Any, Any], bool]


async def default_promotion_policy(snippet: Any, full: Any) -> bool:
    """Conservative default: promote only high/critical-importance chunks.

    mindX should replace this with a Gödel-evaluated policy that scores
    chunks against the current goal/desire stack.
    """
    return full.importance in (Importance.HIGH, Importance.CRITICAL)


async def orient_with_forked_recall(
    *,
    agent: HasBeliefs,
    query: str,
    rage_service: ProgressiveDisclosureService,
    top_k: int = 10,
    memory_types: list[MemoryType] | None = None,
    promotion_policy: PromotionPolicy = default_promotion_policy,
    parent_id: str | None = None,
) -> dict[str, Any]:
    """AGInt Orient phase: query RAGE inside a forked sub-context.

    Returns a dict suitable for logging into the Gödel choice log::

        {
            "fork_id": "...",
            "query": "...",
            "inspected": int,
            "promoted": int,
            "promoted_chunk_ids": [...],
            "duration_ms": float,
        }

    The agent's belief base is mutated in-place IF it exposes a dict-like
    ``beliefs`` mapping and any chunks pass the promotion policy. Otherwise
    the caller is responsible for harvesting the result.
    """
    req = RetrieveRequest(
        query=query,
        top_k=top_k,
        memory_types=memory_types,
    )

    async with forked_recall(agent, query=query, parent_id=parent_id) as fork:
        l1 = await rage_service.retrieve(req)
        log.info(
            "agint.orient.l1",
            fork_id=fork.fork_id,
            returned=len(l1.results),
            latency_ms=l1.latency_ms,
        )

        for snippet in l1.results:
            fork.trace.chunks_inspected += 1
            full = await rage_service.expand(
                ExpandRequest(chunk_id=snippet.chunk_id, include_neighbors=False)
            )
            if full is None:
                continue

            # Promotion policy is sync-or-async tolerant.
            result = promotion_policy(snippet, full)
            should_promote = await result if hasattr(result, "__await__") else bool(result)

            if should_promote:
                belief_key = f"rage:{snippet.memory_type.value}:{snippet.chunk_id[:12]}"
                fork.promote_belief(
                    belief_key,
                    {
                        "source_uri": full.source_uri,
                        "content": full.content,
                        "importance": full.importance.value,
                        "memory_type": full.memory_type.value,
                    },
                )
                fork.promote_chunk(full)

        return {
            "fork_id": fork.fork_id,
            "query": query,
            "inspected": fork.trace.chunks_inspected,
            "promoted": fork.trace.chunks_promoted,
            "promoted_chunk_ids": list(fork.trace.promoted_chunk_ids),
        }


# ---------------------------------------------------------------------------
# Drop-in helper for the ingest path: replaces hand-rolled chunk_id generation
# in agents/memory_agent.py::MemoryAgent.store / RAGE ingest.
# ---------------------------------------------------------------------------


def upsert_chunk_sql(table: str = "rage_chunks") -> str:
    """Return the ON-CONFLICT upsert that respects the composite chunk_id.

    Caller passes the chunk_id (sha256 hex) computed via make_chunk_id().
    Identical re-ingests become no-ops; content drift triggers an update
    of the content and embedding columns only.
    """
    return f"""
        INSERT INTO {table} (
            chunk_id, source_uri, start_line, end_line, content, content_hash,
            embedding, embedding_model, memory_type, importance, tier, metadata
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        ON CONFLICT (chunk_id) DO UPDATE SET
            content        = EXCLUDED.content,
            embedding      = EXCLUDED.embedding,
            updated_at     = now(),
            metadata       = {table}.metadata || EXCLUDED.metadata
        WHERE {table}.content_hash IS DISTINCT FROM EXCLUDED.content_hash
    """


__all__ = [
    "default_promotion_policy",
    "orient_with_forked_recall",
    "upsert_chunk_sql",
]
