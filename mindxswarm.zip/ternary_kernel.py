"""
ternary_kernel.py  —  reference partial-forward kernel (Step 1).

A real (if minimal) ternary forward pass over a layer range, so the daisychain
executes actual math instead of the stub, and each stage emits a verifiable
trace. This is the production form of THOT weights: BitNet b1.58 ternary
({-1,0,1}) with int8-quantized activations.

The linear step is INTEGER-EXACT:

    q, a_scale = quantize_int8(x)         # activations -> int8 + scale
    acc        = W_int8 @ q_int32         # ternary matmul, int32 accumulate (exact)
    y          = acc * (a_scale * w_scale)# dequantize
    y          = silu(y) ; + residual

Because the matmul accumulates in integers, `acc` is bit-identical on any machine
— so the per-step commitment `keccak(q || acc)` is reproducible across providers
and a referee can re-run exactly one step to adjudicate a dispute. This is what
makes the ChallengeGame trace meaningful for real compute.

`ReferenceBackend` plugs into harvest_node.Provider (has_forward=True), turning
`Router.infer` into genuine pipeline-parallel inference over a reference model.
"""
from __future__ import annotations
import os
import sys
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
from eth_utils import keccak

sys.path.insert(0, os.path.dirname(__file__))
from thot_store import unpack_ternary, pack_ternary   # noqa: E402


def quantize_int8(x: np.ndarray) -> Tuple[np.ndarray, float]:
    """Per-vector absmax symmetric int8 quantization."""
    amax = float(np.max(np.abs(x))) or 1.0
    scale = amax / 127.0
    q = np.clip(np.round(x / scale), -127, 127).astype(np.int8)
    return q, scale


def silu(x: np.ndarray) -> np.ndarray:
    return x / (1.0 + np.exp(-x))


@dataclass
class TernaryLayer:
    W: np.ndarray        # int8 {-1,0,1}, shape (out, in)
    w_scale: float

    def forward(self, x: np.ndarray) -> Tuple[np.ndarray, bytes]:
        q, a_scale = quantize_int8(x)
        # integer-exact ternary GEMM
        acc = self.W.astype(np.int32) @ q.astype(np.int32)      # (out,)
        y = acc.astype(np.float64) * (a_scale * self.w_scale)
        y = silu(y)
        if y.shape == x.shape:
            y = y + x                                           # residual
        # commitment over the integer-exact intermediates (machine-independent)
        state = keccak(q.tobytes() + acc.astype(np.int32).tobytes())
        return y.astype(np.float32), state

    @classmethod
    def random(cls, out_dim: int, in_dim: int, rng: np.random.Generator) -> "TernaryLayer":
        trits = rng.integers(-1, 2, size=out_dim * in_dim, dtype=np.int8)
        # round-trip through the THOT packer to prove they are real THOT weights
        packed = pack_ternary(trits.tolist())
        unpacked = np.array(unpack_ternary(packed, out_dim * in_dim), dtype=np.int8)
        W = unpacked.reshape(out_dim, in_dim)
        w_scale = 1.0 / np.sqrt(in_dim)
        return cls(W=W, w_scale=float(w_scale))


class TernaryStage:
    """A contiguous block of layers held by one provider."""

    def __init__(self, layers: List[TernaryLayer]):
        self.layers = layers

    def forward(self, x: np.ndarray) -> Tuple[np.ndarray, List[bytes]]:
        q0, _ = quantize_int8(x)
        trace = [keccak(q0.tobytes())]            # s0 = commit(input)
        for layer in self.layers:
            x, st = layer.forward(x)
            trace.append(st)                       # s_{i+1}
        return x, trace                            # len(trace) = nSteps + 1

    @property
    def n_steps(self) -> int:
        return len(self.layers)

    @classmethod
    def random(cls, dim: int, n_layers: int, seed: int) -> "TernaryStage":
        rng = np.random.default_rng(seed)
        return cls([TernaryLayer.random(dim, dim, rng) for _ in range(n_layers)])


def trace_root(trace: List[bytes]) -> bytes:
    """Hash-chain the trace states into a single root commitment."""
    acc = b"\x00" * 32
    for s in trace:
        acc = keccak(acc + s)
    return acc


def bytes_to_vec(b: bytes, dim: int) -> np.ndarray:
    """Deterministically map arbitrary input bytes to a well-scaled float32 vector."""
    stream = bytearray()
    ctr = 0
    while len(stream) < dim:
        stream += keccak(b + ctr.to_bytes(4, "big"))
        ctr += 1
    u = np.frombuffer(bytes(stream[:dim]), dtype=np.uint8).astype(np.float32)
    return ((u - 127.5) / 127.5).astype(np.float32)        # ~[-1, 1]


def vec_to_bytes(v: np.ndarray) -> bytes:
    return v.astype(np.float32).tobytes()


class ReferenceBackend:
    """A real (reference-model) backend for harvest_node.Provider."""
    has_forward = True
    available = True

    def __init__(self, stages: Dict[int, TernaryStage], dim: int):
        self.stages = stages
        self.dim = dim
        self._roots: Dict[int, bytes] = {}
        self._traces: Dict[int, List[bytes]] = {}

    def forward_stage(self, stage: int, activations: bytes, tokens: int) -> bytes:
        x = bytes_to_vec(activations, self.dim)
        y, trace = self.stages[stage].forward(x)
        self._traces[stage] = trace
        self._roots[stage] = trace_root(trace)
        return vec_to_bytes(y)

    def last_root(self, stage: int) -> bytes:
        return self._roots[stage]

    def last_trace(self, stage: int) -> List[bytes]:
        return self._traces[stage]


if __name__ == "__main__":
    dim, layers = 64, 4
    stage = TernaryStage.random(dim, layers, seed=42)
    x = bytes_to_vec(b"the collective mind", dim)

    y1, t1 = stage.forward(x)
    y2, t2 = stage.forward(x)   # determinism check
    assert t1 == t2, "trace not deterministic"
    assert np.array_equal(y1, y2), "output not deterministic"
    assert len(t1) == layers + 1, "trace length"
    print("ternary kernel OK")
    print(f"  dim={dim} layers={layers}  trace states={len(t1)} (s0..s{layers})")
    print(f"  trace_root = 0x{trace_root(t1).hex()[:32]}…")
    print(f"  integer-exact GEMM: acc is int32, commitments reproducible cross-machine")

    # tamper: flip one weight -> trace diverges from exactly that layer onward
    stage.layers[2].W[0, 0] = -stage.layers[2].W[0, 0] if stage.layers[2].W[0, 0] != 0 else 1
    _, t3 = stage.forward(x)
    first_div = next(i for i in range(len(t1)) if t1[i] != t3[i])
    print(f"  weight tamper in layer 2 -> first divergent state s{first_div} "
          f"(bisection would localize here)  ✔")
