// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title ReceiptLib
/// @notice On-chain digest + signer recovery for stage receipts, byte-identical
///         to node/receipts.py. A receipt is self-authenticating: anyone can
///         recover the signer and check it against the provider's bound key.
library ReceiptLib {
    struct Receipt {
        bytes32 jobId;
        address node;     // claimed signer (must equal recovered signer)
        uint256 stage;
        uint256 tokens;
        uint256 flops;
        bytes32 outRoot;  // trace root of the stage's work
    }

    /// keccak256(abi.encode(...)) — matches receipt_digest() in Python.
    function digest(Receipt memory r) internal pure returns (bytes32) {
        return keccak256(abi.encode(r.jobId, r.node, r.stage, r.tokens, r.flops, r.outRoot));
    }

    /// EIP-191 personal-sign hash of the digest (toEthSignedMessageHash).
    function ethSigned(bytes32 d) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", d));
    }

    /// Recover the signer from a 65-byte (r||s||v) signature.
    function recover(Receipt memory r, bytes memory sig) internal pure returns (address) {
        require(sig.length == 65, "bad sig len");
        bytes32 rr; bytes32 ss; uint8 vv;
        assembly {
            rr := mload(add(sig, 0x20))
            ss := mload(add(sig, 0x40))
            vv := byte(0, mload(add(sig, 0x60)))
        }
        if (vv < 27) vv += 27;
        require(vv == 27 || vv == 28, "bad v");
        // reject the upper half of s (EIP-2 malleability guard)
        require(uint256(ss) <= 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0, "bad s");
        address signer = ecrecover(ethSigned(digest(r)), vv, rr, ss);
        require(signer != address(0), "ecrecover fail");
        return signer;
    }

    /// True iff the signature recovers to the receipt's claimed node.
    function verify(Receipt memory r, bytes memory sig) internal pure returns (bool) {
        return recover(r, sig) == r.node;
    }

    /// Contribution weight (same economic meaning as before).
    function weight(Receipt memory r) internal pure returns (uint256) {
        return r.flops * r.tokens;
    }
}
