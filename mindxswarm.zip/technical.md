# mindX Swarm — Technical Deep Dive

This document covers the engineering of the three completed "next steps": real
secp256k1 receipts, the integer-exact ternary partial-forward kernel, and the
mapping from a real execution trace to the on-chain ChallengeGame. Read `intro.md`
first for the system overview; this is the layer beneath it.

Everything here is implemented and exercised — file pointers and the exact
self-tests are given so you can reproduce each claim.

---

## 1. Self-authenticating receipts (secp256k1)

**Files:** `node/receipts.py`, `contracts/src/ReceiptLib.sol`,
`contracts/test/ReceiptLib.t.sol`.

A stage receipt is the unit of contribution. For it to be trustworthy on-chain,
the signer must be recoverable from the receipt alone, so the ChallengeGame and
the market can bind a receipt to the provider's ERC-8004-registered key. The
previous HMAC placeholder couldn't do that; this replaces it with secp256k1.

### Digest

Both sides compute the identical digest:

```
digest = keccak256(abi.encode(
    jobId  (bytes32),
    node   (address),
    stage  (uint256),
    tokens (uint256),
    flops  (uint256),
    outRoot(bytes32)      // the stage's trace root (see §2)
))
```

`abi.encode` (32-byte-padded fields, not packed) is used deliberately so the
Python and Solidity encodings cannot disagree on field boundaries. Python builds
it by hand in `receipt_digest()` (each field widened to a 32-byte word); Solidity
is one `abi.encode` in `ReceiptLib.digest()`.

### Signing & recovery

The signature is over the EIP-191 personal-sign form
(`toEthSignedMessageHash(digest)`), so `ecrecover` in Solidity matches
`eth_account` in Python:

- **Python** — `Account.sign_message(encode_defunct(digest), key)` → 65-byte
  `r‖s‖v`. Recovery: `Account.recover_message(...)`.
- **Solidity** — `ReceiptLib.recover()` splits `r,s,v`, normalizes `v` to 27/28,
  rejects the upper half of `s` (EIP-2 malleability guard), and `ecrecover`s the
  prefixed hash.

A node's address **is** its signing key's address (`address_from_key`), so an
honest receipt's `node` field equals the recovered signer; tampering with any
signed field changes the digest and recovery no longer matches.

### Cross-validation (the important part)

The Solidity test embeds a vector produced by the Python signer with a fixed key
(`0x11…11`): the digest, the signature, and the expected address. `forge test`
recovers the signer on-chain and asserts equality:

```
test_digest_matches_python   digest == 0x02fbeb72…037b
test_recovers_python_signer  recover(sig) == 0x19E7E376…ff2A
```

If both pass, the two implementations agree byte-for-byte — a Python-signed
receipt is verifiable by the contract, and vice-versa. The Python round-trip
(`python3 node/receipts.py`) independently shows sign → recover → tamper-detect.

---

## 2. The ternary partial-forward kernel

**File:** `node/ternary_kernel.py`. **Self-test:** `python3 node/ternary_kernel.py`.

This makes the daisychain execute real math and emit a verifiable trace, instead
of the shape-stable stub. It is the production form of THOT weights: BitNet b1.58
ternary weights in `{-1,0,1}` with int8-quantized activations.

### Integer-exact linear step

```
q, a_scale = quantize_int8(x)        # per-vector absmax → int8 + float scale
acc        = W_int8 @ q_int32        # ternary GEMM, accumulated in int32  (EXACT)
y          = acc · (a_scale · w_scale)   # dequantize
y          = silu(y)  ; + residual    # nonlinearity, residual if dims match
```

The matmul accumulates in **integers**, so `acc` is bit-identical on any CPU,
any BLAS, any order of summation. That is the crux: floating-point matmuls differ
across machines in their low bits, which would make a hash-of-output trace
useless for verification. By committing the **integer** intermediates, every
honest provider computing the same step produces the same commitment.

The weights are genuinely round-tripped through the THOT packer
(`pack_ternary`/`unpack_ternary`) in `TernaryLayer.random`, so the kernel runs on
the same 1.6-bit representation the storage layer ships.

### Trace commitments

A stage is a contiguous block of layers. `TernaryStage.forward` returns the
output and a trace:

```
s0      = keccak(quantize(x))                       # commit the input
s_{i+1} = keccak(q_i ‖ acc_i)                        # commit each layer's exact work
trace   = [s0, s1, …, sN]    (N = number of layers)
trace_root = hash-chain(trace)                       # single 32-byte root → receipt.outRoot
```

Because each `s_i` is built from integer-exact data, the whole trace is
reproducible. `trace_root` becomes the `outRoot` signed into the receipt (§1),
tying payment-bearing receipts to verifiable computation.

### Verified properties (in the self-test)

- **Determinism:** two forwards of the same input yield identical output and
  identical trace.
- **Fault surfacing:** flipping one ternary weight in layer *k* makes the trace
  first diverge at exactly `s_{k+1}` — the property the bisection relies on.

### `ReferenceBackend`

Wraps per-stage `TernaryStage`s and exposes the `forward_stage(stage, bytes,
tokens) → bytes` interface `harvest_node.Provider` expects, with `has_forward =
True`. Dropping it into a `Provider` turns `Router.infer` into genuine
pipeline-parallel inference over a reference model. Input bytes are mapped to a
well-scaled activation vector by a keccak stream (`bytes_to_vec`) so arbitrary
inputs never produce NaN/Inf that would collapse quantization.

This is a *reference* kernel (a stack of ternary linear + SiLU + residual blocks),
not GLM. It proves the contract — real ternary execution, integer-exact trace,
receipt binding — that a full bitnet.cpp model plugs into via the same seam.

---

## 3. From a real trace to on-chain dispute

**Files:** `contracts/src/ChallengeGame.sol`, `examples/verifiable_demo.py`.
**Demo:** `python3 examples/verifiable_demo.py`.

The kernel's trace is precisely the `s_0 … s_N` the ChallengeGame disputes.

### Mapping

| kernel | ChallengeGame |
|---|---|
| `s0 = commit(input)` | `AssertionInput.state0` |
| `sN = commit(stage output)` | `AssertionInput.stateN` |
| number of layers in the stage | `AssertionInput.nSteps` |
| layer *i* (`s_i → s_{i+1}`) | the single step adjudicated at the leaf |

A provider posts `(state0, stateN, nSteps)` with a bond. A challenger who believes
`stateN` is wrong matches the bond and the bisection begins.

### Why bisection localizes the fault

The parties agree on `state0` and (by the challenge) disagree on `stateN`. Each
round the solver reveals the state at the interval midpoint; the challenger, who
can recompute the true trace, agrees (dispute is above mid) or disagrees (below
mid). The interval halves each round, so after `ceil(log2 nSteps)` rounds it is a
single step where the parties agree on the input state and disagree on the output
state — *the* faulty layer.

`verifiable_demo.py` runs this against the **real** kernel: 8 layers, a fault
injected at layer 5, located in 3 rounds (= ⌈log₂8⌉):

```
[ 0, 8] mid=4  challenger agrees   s4
[ 4, 8] mid=6  challenger disagrees s6
[ 4, 6] mid=5  challenger agrees   s5
-> disputed step = layer 5   (== injected fault)
```

### Terminal adjudication

At the single step the solver claims `s_lo → s_hi`. Two paths in
`ChallengeGame.sol`:

- **On-chain `IStepVerifier`** for cheap, deterministic steps (e.g. the
  quantization or a requantize). Registered per `jobKind`.
- **Referee** for the heavy matmul: it re-runs *exactly one* layer on the agreed
  `s_lo` and returns the correct next state. This is the Gensyn-Verde economy —
  the whole model is never re-run, only one disputed operation, and one honest
  referee suffices. Because the linear step is integer-exact (§2), the referee's
  recomputation is unambiguous.

The loser is slashed: `_resolve` pays the winner both bonds and, on solver fraud,
calls `CollectiveMarket.resolveFraud(epoch, solver, …)` which freezes that epoch's
claim and slashes the provider's `ProviderRegistry` stake. The **challenge
window** (`closedAt + challengePeriod`) guarantees the dispute can complete before
the cheater can withdraw.

---

## 4. End-to-end, after these steps

A job now produces, with no trusted intermediary at the receipt layer:

1. **Real activations** through each stage (integer-exact ternary forward).
2. A **trace** per stage, committed to a `trace_root`.
3. A **secp256k1 receipt** per stage binding `(job, provider, stage, tokens,
   flops, trace_root)` — self-authenticating on-chain.
4. The aggregator's **keccak Merkle root** over `(provider, weight)` leaves that
   `CollectiveMarket.claim` verifies.
5. A **disputable** settlement: during the challenge window any verifier can open
   a ChallengeGame against a provider's trace and, on a real fault, get it slashed
   before it can claim.

`make selftest && make demo && make verify` exercises (2)–(5) offline; `forge
test` exercises the contracts including the Python↔Solidity receipt vector.

---

## 5. What is still reference vs production

- The kernel is a **reference** ternary block stack, not GLM. The seam to a full
  bitnet.cpp model is `BitNetBackend.forward_stage` (set `has_forward=True` once
  the partial-forward kernel over real GGUF layers is wired); the RPC path already
  runs real models today.
- **Float determinism** is sidestepped by committing integer intermediates. A
  production kernel must keep the same discipline (integer accumulation, committed
  quantized states) or route every step to the referee.
- The on-chain `IStepVerifier` shipped is a keccak step used to test the game
  mechanics; a production verifier checks the cheap deterministic ops, and the
  matmul goes to the referee (or a DAIO quorum referee, per `roadmap.md` Step 5).
- Receipts are bound to the signer's address; binding that address to the
  provider's **ERC-8004 id** at claim time is the remaining wire in
  `CollectiveMarket` (the registry linkage exists; enforcing recovered-signer ==
  bound-key in `claim` is the small next edit).

---

*License: MIT. Username standard: `codephreak` / `cypherpunk2048`.*
