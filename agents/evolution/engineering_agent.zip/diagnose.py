"""engineering_agent.skills.diagnose — Six-phase disciplined debugging loop."""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext

from ..deps import EngineeringDeps
from ..models import Diagnosis
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def run_loop(
        ctx: RunContext[EngineeringDeps],
        command: str,
        timeout_seconds: float = 60.0,
    ) -> dict:
        """Phase 1: Build a feedback loop. Run an arbitrary command, capture output."""
        res = await ctx.deps.shell.run(command, timeout=timeout_seconds)
        return {
            "command": res.command,
            "ok": res.ok,
            "returncode": res.returncode,
            "stdout": res.stdout,
            "stderr": res.stderr,
            "duration_seconds": res.duration_seconds,
        }

    @agent.tool
    async def measure_loop_quality(
        ctx: RunContext[EngineeringDeps],
        command: str,
        runs: int = 3,
        timeout_seconds: float = 30.0,
    ) -> dict:
        """Run the loop N times. Report runtime stats and determinism (rc identical across runs)."""
        results = []
        for _ in range(max(2, runs)):
            r = await ctx.deps.shell.run(command, timeout=timeout_seconds)
            results.append(r.returncode)
        n = len(results)
        same = sum(1 for r in results if r == results[0])
        determinism = same / n
        avg_seconds = sum(
            (await ctx.deps.shell.run(command, timeout=timeout_seconds)).duration_seconds
            for _ in range(1)
        )
        return {
            "runs": n,
            "returncodes": results,
            "determinism": determinism,
            "approx_runtime_seconds": avg_seconds,
        }

    @agent.tool
    async def grep_codebase(
        ctx: RunContext[EngineeringDeps], pattern: str, glob: str = "**/*"
    ) -> list[str]:
        """Phase 4: search the codebase for instances of a pattern. Used for instrumentation planning."""
        # Prefer ripgrep if present; fall back to git grep.
        rg = ctx.deps.shell.which("rg")
        if rg:
            res = await ctx.deps.shell.run(["rg", "-n", "--", pattern, "."])
        else:
            res = await ctx.deps.shell.run(["git", "grep", "-n", pattern])
        return [l for l in res.stdout.splitlines() if l.strip()][:200]

    @agent.tool
    async def cleanup_debug_logs(
        ctx: RunContext[EngineeringDeps], prefix: str
    ) -> dict:
        """Phase 6: identify (do NOT delete) lines tagged with the debug prefix.

        Refuses if prefix is suspiciously short — guards against deleting real code.
        """
        if len(prefix) < 6 or "[DEBUG-" not in prefix:
            raise ModelRetry(
                f"prefix {prefix!r} too short or wrong shape. "
                "Use a unique tag like '[DEBUG-a4f2]' to avoid false positives."
            )
        rg = ctx.deps.shell.which("rg")
        argv = ["rg", "-n", "--", prefix, "."] if rg else ["git", "grep", "-n", prefix]
        res = await ctx.deps.shell.run(argv)
        hits = [l for l in res.stdout.splitlines() if l.strip()]
        return {"prefix": prefix, "remaining_hits": len(hits), "files": hits[:50]}


diagnose_agent = make_skill_agent(
    SkillSpec(name="diagnose", output_type=Diagnosis, tools=_register_tools)
)
