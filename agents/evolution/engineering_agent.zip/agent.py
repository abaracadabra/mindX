"""engineering_agent.agent — The top-level `engineering` router agent.

PUBLIC API.
- `engineering`: a Pydantic AI Agent[EngineeringDeps, EngineeringResult] that
  takes a free-form user request, picks the right Pocock skill, runs it, and
  returns the typed artifact wrapped in an envelope.

- `run_skill_directly(name, request, deps)`: bypass routing and call one skill
  directly — useful when the caller already knows which skill they want.

DESIGN. The router uses a two-step pattern:
  1. The router is a Pydantic AI agent whose ONLY tool is `dispatch(...)` — one
     tool per skill. The model picks the tool based on the request; the tool
     implementation calls the corresponding sub-agent and returns its typed
     output.
  2. The router's output_type is `EngineeringResult` — so even when the
     sub-agent's typed output flows through, we keep a stable envelope for the
     caller.

Why a tool-call dispatch instead of a discriminated-union output? Because the
sub-agents themselves are full agents that may take many turns (e.g. diagnose
runs through 6 phases). Tool-call dispatch lets each sub-agent run its own
loop, then returns the typed artifact to the router.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel
from pydantic_ai import Agent, RunContext

from .deps import EngineeringDeps
from .models import (
    ArchitectureReview,
    Diagnosis,
    EngineeringResult,
    GrillSession,
    IssuesPlan,
    PRD,
    RepoSetup,
    SkillName,
    SystemView,
    TDDRun,
    TriageDecision,
)
from .skills import SUB_AGENTS

ROUTER_INSTRUCTIONS = """\
You are the `engineering` router. Your job is to recognise which of Matt
Pocock's nine engineering skills the user's request needs, then invoke the
matching `dispatch_*` tool exactly once. The tool will run the sub-agent
end-to-end and return its typed artifact.

THE NINE SKILLS:

- `grill-with-docs` — when the user has a vague plan and needs sharper
  questions; or wants to update CONTEXT.md / ADRs. Trigger words: "let's
  think through", "I'm planning", "should I…?", "what about…", "design".

- `to-prd` — when the user wants a PRD synthesised from prior conversation.
  Trigger: "write the PRD", "summarise into a PRD", "file this as a spec".

- `to-issues` — when the user has a plan/PRD and wants it broken into issues.
  Trigger: "split this", "break into tickets", "make issues for this".

- `triage` — when the user wants to move an issue forward (intake →
  reproducer → prioritiser → assigner → closer). Trigger: "triage this",
  "what's next on issue X", "label issue Y".

- `tdd` — when the user wants to BUILD a feature or FIX a bug using
  test-driven development. Trigger: "TDD this", "write tests first",
  "red-green-refactor".

- `diagnose` — when the user reports a hard bug or perf regression. Trigger:
  "this is broken", "diagnose", "debug", "why is X failing", "performance
  has regressed".

- `improve-codebase-architecture` — when the user wants to find deepening
  opportunities in the codebase. Trigger: "improve architecture", "this is a
  ball of mud", "where can we tighten interfaces".

- `zoom-out` — when the user has an unfamiliar piece of code and wants the
  system context. Trigger: "explain this in context", "zoom out", "where
  does this fit".

- `setup-matt-pocock-skills` — run ONCE per repo before the others. Trigger:
  "set up skills", "scaffold CONTEXT.md", "first time on this repo".

ROUTING RULES.
1. Pick exactly ONE skill. If the request spans multiple, pick the one that
   produces the next concrete artifact (usually the earliest in the chain
   grill→prd→issues→tdd / diagnose).
2. If the user names a skill explicitly, use it.
3. If you can't tell, prefer `grill-with-docs` — getting the user to sharpen
   the request is always safe.
4. Never invoke more than one dispatch tool per turn.

Return the EngineeringResult with skill_used set to the skill you chose, the
rationale (1–2 sentences), and the artifact returned by the dispatch tool.
"""


# --------------------------------------------------------------------------- #
# Helper: invoke a sub-agent with the user's free-form request
# --------------------------------------------------------------------------- #

async def _invoke(
    skill: SkillName, request: str, ctx: RunContext[EngineeringDeps]
) -> BaseModel:
    sub = SUB_AGENTS[skill]
    result = await sub.run(request, deps=ctx.deps)
    return result.output


# --------------------------------------------------------------------------- #
# Router agent
# --------------------------------------------------------------------------- #

engineering: Agent[EngineeringDeps, EngineeringResult] = Agent(
    "anthropic:claude-sonnet-4-6",
    deps_type=EngineeringDeps,
    output_type=EngineeringResult,
    instructions=ROUTER_INSTRUCTIONS,
    output_retries=2,
)


@engineering.tool
async def dispatch_grill_with_docs(
    ctx: RunContext[EngineeringDeps], request: str
) -> GrillSession:
    """Run grill-with-docs. Use for vague plans / design questions."""
    return await _invoke(SkillName.GRILL_WITH_DOCS, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_to_prd(ctx: RunContext[EngineeringDeps], request: str) -> PRD:
    """Run to-prd. Synthesise prior conversation into a PRD."""
    return await _invoke(SkillName.TO_PRD, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_to_issues(
    ctx: RunContext[EngineeringDeps], request: str
) -> IssuesPlan:
    """Run to-issues. Break a plan/PRD into vertical-slice issues."""
    return await _invoke(SkillName.TO_ISSUES, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_triage(
    ctx: RunContext[EngineeringDeps], request: str
) -> TriageDecision:
    """Run triage. Move ONE issue forward by ONE role transition."""
    return await _invoke(SkillName.TRIAGE, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_tdd(ctx: RunContext[EngineeringDeps], request: str) -> TDDRun:
    """Run tdd. Build a feature / fix a bug via red-green-refactor."""
    return await _invoke(SkillName.TDD, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_diagnose(
    ctx: RunContext[EngineeringDeps], request: str
) -> Diagnosis:
    """Run diagnose. Six-phase loop for hard bugs / perf regressions."""
    return await _invoke(SkillName.DIAGNOSE, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_improve_codebase_architecture(
    ctx: RunContext[EngineeringDeps], request: str
) -> ArchitectureReview:
    """Run improve-codebase-architecture. Find deepening opportunities."""
    return await _invoke(SkillName.IMPROVE_CODEBASE_ARCHITECTURE, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_zoom_out(
    ctx: RunContext[EngineeringDeps], request: str
) -> SystemView:
    """Run zoom-out. Give system context for a narrow piece of code."""
    return await _invoke(SkillName.ZOOM_OUT, request, ctx)  # type: ignore[return-value]


@engineering.tool
async def dispatch_setup(
    ctx: RunContext[EngineeringDeps], request: str
) -> RepoSetup:
    """Run setup-matt-pocock-skills. Scaffold CONTEXT.md, ADRs, label vocab."""
    return await _invoke(SkillName.SETUP, request, ctx)  # type: ignore[return-value]


# --------------------------------------------------------------------------- #
# Direct-skill API for callers that already know which skill they want
# --------------------------------------------------------------------------- #

async def run_skill_directly(
    skill: SkillName,
    request: str,
    deps: EngineeringDeps,
) -> EngineeringResult:
    """Bypass the router and call a specific skill. Returns the standard envelope."""
    sub = SUB_AGENTS[skill]
    result = await sub.run(request, deps=deps)
    return EngineeringResult(
        skill_used=skill,
        rationale="(direct invocation; routing skipped)",
        artifact=result.output,
    )
