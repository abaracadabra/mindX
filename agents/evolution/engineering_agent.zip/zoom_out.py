"""engineering_agent.skills.zoom_out — Give the user the system view of a narrow location."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext

from ..deps import EngineeringDeps
from ..models import SystemView
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def read_focus(
        ctx: RunContext[EngineeringDeps], relative_path: str, max_chars: int = 4000
    ) -> str:
        """Read the file the user is focused on."""
        p = (ctx.deps.repo_root / relative_path).resolve()
        if ctx.deps.repo_root.resolve() not in p.parents and p != ctx.deps.repo_root.resolve():
            raise ModelRetry(f"path {relative_path!r} escapes repo_root")
        if not p.exists():
            raise ModelRetry(f"no such file: {relative_path!r}")
        return p.read_text(encoding="utf-8", errors="replace")[:max_chars]

    @agent.tool
    async def find_callers(
        ctx: RunContext[EngineeringDeps], symbol: str, max_hits: int = 50
    ) -> list[str]:
        """Find call-sites of a symbol via ripgrep / git grep."""
        rg = ctx.deps.shell.which("rg")
        argv = ["rg", "-n", "--", symbol, "."] if rg else ["git", "grep", "-n", symbol]
        res = await ctx.deps.shell.run(argv)
        return [l for l in res.stdout.splitlines() if l.strip()][:max_hits]

    @agent.tool
    async def list_dependencies(
        ctx: RunContext[EngineeringDeps], relative_path: str
    ) -> list[str]:
        """Best-effort: extract import lines from the focused file."""
        p = (ctx.deps.repo_root / relative_path).resolve()
        if not p.exists():
            return []
        text = p.read_text(encoding="utf-8", errors="replace")
        imports = []
        for line in text.splitlines():
            s = line.strip()
            if (
                s.startswith("import ")
                or s.startswith("from ")
                or s.startswith("require(")
                or s.startswith("use ")
                or s.startswith("#include")
                or "import " in s and s.startswith(("export ", "const ", "let ", "var "))
            ):
                imports.append(line.strip())
        return imports[:60]


zoom_agent = make_skill_agent(
    SkillSpec(name="zoom-out", output_type=SystemView, tools=_register_tools)
)
