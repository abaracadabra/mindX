"""engineering_agent.shell_tools — Bounded subprocess execution for the agent.

Used by `tdd` (run tests), `diagnose` (run feedback loops), `triage` (call gh/linear).
The agent gets a small surface: `run`, `run_test`, `which`. All have hard
timeouts. Output is captured + truncated so it doesn't blow the LLM context.
"""
from __future__ import annotations

import asyncio
import shlex
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

DEFAULT_TIMEOUT = 120.0
DEFAULT_OUTPUT_BYTES = 16_000  # ~4k tokens


@dataclass
class CommandResult:
    command: str
    returncode: int
    stdout: str
    stderr: str
    duration_seconds: float
    truncated: bool

    @property
    def ok(self) -> bool:
        return self.returncode == 0


class ShellTools:
    def __init__(self, cwd: Path) -> None:
        self.cwd = cwd

    async def run(
        self,
        command: str | list[str],
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_bytes: int = DEFAULT_OUTPUT_BYTES,
        cwd: Optional[Path] = None,
        env: Optional[dict[str, str]] = None,
    ) -> CommandResult:
        """Run a shell command with bounded time & captured output."""
        argv = command if isinstance(command, list) else shlex.split(command)
        loop = asyncio.get_running_loop()
        start = loop.time()
        proc = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(cwd or self.cwd),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return CommandResult(
                command=" ".join(argv),
                returncode=124,
                stdout="",
                stderr=f"TIMEOUT after {timeout}s",
                duration_seconds=loop.time() - start,
                truncated=False,
            )
        duration = loop.time() - start
        out = stdout_b.decode("utf-8", errors="replace")
        err = stderr_b.decode("utf-8", errors="replace")
        truncated = len(out) > max_bytes or len(err) > max_bytes
        if truncated:
            out = out[: max_bytes // 2] + f"\n…<truncated {max(0, len(out) - max_bytes // 2)} bytes>…"
            err = err[: max_bytes // 2] + f"\n…<truncated {max(0, len(err) - max_bytes // 2)} bytes>…"
        return CommandResult(
            command=" ".join(argv),
            returncode=proc.returncode or 0,
            stdout=out,
            stderr=err,
            duration_seconds=duration,
            truncated=truncated,
        )

    async def run_test(
        self,
        target: str = "",
        *,
        runner: Optional[str] = None,
        timeout: float = 300.0,
    ) -> CommandResult:
        """Convenience: detect test runner from repo and run it.

        Detection order: pytest (Python), vitest (JS), jest, go test, cargo test, forge test.
        """
        runner = runner or self._detect_runner()
        if runner == "pytest":
            cmd = f"pytest -xvs {target}".strip()
        elif runner == "vitest":
            cmd = f"npx vitest run {target}".strip()
        elif runner == "jest":
            cmd = f"npx jest {target}".strip()
        elif runner == "go":
            cmd = f"go test ./... {target}".strip()
        elif runner == "cargo":
            cmd = f"cargo test {target}".strip()
        elif runner == "forge":
            cmd = f"forge test -vv {target}".strip()
        else:
            return CommandResult(
                command="(no test runner detected)",
                returncode=127,
                stdout="",
                stderr="No test runner detected. Pass runner= explicitly.",
                duration_seconds=0.0,
                truncated=False,
            )
        return await self.run(cmd, timeout=timeout)

    def which(self, binary: str) -> Optional[str]:
        return shutil.which(binary)

    def _detect_runner(self) -> Optional[str]:
        if (self.cwd / "pyproject.toml").exists() or (self.cwd / "pytest.ini").exists():
            return "pytest" if self.which("pytest") else None
        if (self.cwd / "vitest.config.ts").exists() or (self.cwd / "vitest.config.js").exists():
            return "vitest"
        pkg = self.cwd / "package.json"
        if pkg.exists():
            txt = pkg.read_text(errors="replace")
            if "vitest" in txt:
                return "vitest"
            if "jest" in txt:
                return "jest"
        if (self.cwd / "go.mod").exists():
            return "go"
        if (self.cwd / "Cargo.toml").exists():
            return "cargo"
        if (self.cwd / "foundry.toml").exists():
            return "forge"
        return None
