"""engineering_agent.skills.to_prd — Synthesize conversation into a PRD."""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent, RunContext

from ..deps import EngineeringDeps
from ..models import PRD
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def list_modules(ctx: RunContext[EngineeringDeps]) -> list[str]:
        """Best-effort: list directories that look like top-level modules."""
        root = ctx.deps.repo_root
        return sorted(
            p.name
            for p in root.iterdir()
            if p.is_dir()
            and not p.name.startswith(".")
            and p.name not in {"node_modules", "dist", "build", "__pycache__", "out", "lib"}
        )

    @agent.tool
    async def quote_glossary(ctx: RunContext[EngineeringDeps]) -> list[dict]:
        """Return current glossary so the PRD uses domain language."""
        return [t.model_dump() for t in ctx.deps.context_loader.load().glossary]

    @agent.tool
    async def file_prd(
        ctx: RunContext[EngineeringDeps], title: str, body: str, labels: list[str] | None = None
    ) -> dict:
        """File the PRD as an issue. Use AFTER you've finalised the PRD body."""
        ref = await ctx.deps.issues.create(title=title, body=body, labels=labels or ["prd"])
        return {"id": ref.id, "url": ref.url, "title": ref.title}


prd_agent = make_skill_agent(SkillSpec(name="to-prd", output_type=PRD, tools=_register_tools))
