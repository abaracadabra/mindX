"""engineering_agent.skills.base — Skill registry, prompt loader, agent factory.

Each Pocock skill is realised as a Pydantic AI sub-agent. Rather than hard-coding
9 separate Agent constructions, we have ONE factory: `make_skill_agent(spec)`.

Spec carries:
- the skill name (drives prompt lookup + on-disk override path)
- the typed output model
- the tool registration callback (skill-specific tools)
- the model identifier

At runtime the registry tries `<repo>/.claude/skills/engineering/<name>/SKILL.md`
first, then the bundled prompt. This means a project can override Pocock's
text without forking the package.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Generic, Optional, TypeVar

from pydantic import BaseModel
from pydantic_ai import Agent, RunContext

from ..deps import EngineeringDeps
from ._prompts import EMBEDDED

OutT = TypeVar("OutT", bound=BaseModel)


# --------------------------------------------------------------------------- #
# Prompt loading: file > embedded
# --------------------------------------------------------------------------- #

_FRONTMATTER_RE = re.compile(r"^\|\s*name\s*\|.+?\|\s*description\s*\|.+?\|", re.DOTALL)


def load_skill_prompt(name: str, deps: EngineeringDeps) -> str:
    """Resolve a skill's system prompt.

    Priority:
      1. `<deps.skills_dir>/<name>/SKILL.md` (explicit override)
      2. `<repo>/.claude/skills/engineering/<name>/SKILL.md`
      3. `<repo>/skills/engineering/<name>/SKILL.md` (Pocock layout)
      4. Bundled constant in `_prompts.EMBEDDED`
    """
    candidates: list[Path] = []
    if deps.skills_dir:
        candidates.append(deps.skills_dir / name / "SKILL.md")
    candidates.extend(
        [
            deps.repo_root / ".claude" / "skills" / "engineering" / name / "SKILL.md",
            deps.repo_root / "skills" / "engineering" / name / "SKILL.md",
        ]
    )
    for path in candidates:
        if path.is_file():
            text = path.read_text(encoding="utf-8", errors="replace")
            return _strip_pocock_frontmatter(text)
    return EMBEDDED[name]


def _strip_pocock_frontmatter(text: str) -> str:
    """Drop the `| name | ... | description | ... |` table — keep the body.

    Matt's repo uses a markdown table for frontmatter; that table is metadata
    for the skill loader, not instructions to the agent.
    """
    # Drop everything before the first H1.
    m = re.search(r"^#\s", text, re.MULTILINE)
    return text[m.start() :] if m else text


# --------------------------------------------------------------------------- #
# Skill spec
# --------------------------------------------------------------------------- #

ToolRegistrar = Callable[[Agent[EngineeringDeps, Any]], None]


@dataclass
class SkillSpec(Generic[OutT]):
    name: str
    output_type: type[OutT]
    tools: ToolRegistrar
    model: str = "anthropic:claude-sonnet-4-6"
    output_retries: int = 3
    instructions_extra: str = ""


def make_skill_agent(spec: SkillSpec[OutT]) -> Agent[EngineeringDeps, OutT]:
    """Build a fully-wired Pydantic AI sub-agent from a SkillSpec."""

    agent: Agent[EngineeringDeps, OutT] = Agent(
        spec.model,
        deps_type=EngineeringDeps,
        output_type=spec.output_type,
        output_retries=spec.output_retries,
    )

    # Static instructions: dynamically resolves the skill's prompt at run time.
    @agent.instructions
    def _skill_prompt(ctx: RunContext[EngineeringDeps]) -> str:
        base = load_skill_prompt(spec.name, ctx.deps)
        return base + (("\n\n" + spec.instructions_extra) if spec.instructions_extra else "")

    # Dynamic instructions: inject the project's domain context (CONTEXT.md, ADRs).
    @agent.instructions
    def _domain_context(ctx: RunContext[EngineeringDeps]) -> str:
        rendered = ctx.deps.context_loader.render_for_prompt()
        return f"## Project context (loaded from CONTEXT.md + docs/adr/)\n\n{rendered}"

    # Skill-specific tools.
    spec.tools(agent)
    return agent
