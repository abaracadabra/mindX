"""engineering_agent.skills.tdd — Red-green-refactor with the horizontal-slicing guard."""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext

from ..deps import EngineeringDeps
from ..models import TDDRun
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def run_tests(
        ctx: RunContext[EngineeringDeps], target: str = "", runner: str | None = None
    ) -> dict:
        """Run the project test suite (or a focused target). Returns rc, stdout, stderr."""
        res = await ctx.deps.shell.run_test(target=target, runner=runner)
        return {
            "command": res.command,
            "ok": res.ok,
            "returncode": res.returncode,
            "stdout": res.stdout,
            "stderr": res.stderr,
            "duration_seconds": res.duration_seconds,
            "truncated": res.truncated,
        }

    @agent.tool
    async def detect_runner(ctx: RunContext[EngineeringDeps]) -> str:
        """Return the auto-detected test runner name (or 'unknown')."""
        r = ctx.deps.shell._detect_runner()
        return r or "unknown"

    @agent.tool
    async def confirm_red_was_observed(
        ctx: RunContext[EngineeringDeps], failure_excerpt: str, behaviour: str
    ) -> dict:
        """Validate that a captured failure excerpt actually looks like a failed test.

        Refuses to proceed to GREEN if the excerpt is empty or matches a passing pattern.
        """
        excerpt = failure_excerpt.strip()
        if not excerpt:
            raise ModelRetry(f"red_evidence empty for behaviour '{behaviour}'. RUN the test, capture failure.")
        passing_signals = ("0 failures", "all tests passed", "0 errors", "ok ", "✓", "PASSED")
        failing_signals = (
            "FAIL",
            "failed",
            "error",
            "AssertionError",
            "expected",
            "assert",
            "✗",
            "Expected",
        )
        looks_failing = any(s.lower() in excerpt.lower() for s in failing_signals)
        looks_passing = any(s in excerpt for s in passing_signals) and not looks_failing
        if looks_passing:
            raise ModelRetry(
                f"red_evidence for '{behaviour}' looks like a PASSING test. "
                "TDD requires observing RED first; rewrite the test so it actually fails."
            )
        return {"behaviour": behaviour, "red_observed": True}

    @agent.tool
    async def list_changed_files(ctx: RunContext[EngineeringDeps]) -> list[str]:
        try:
            return ctx.deps.git.changed_files()
        except Exception as e:
            raise ModelRetry(f"git error: {e}") from e


tdd_agent = make_skill_agent(SkillSpec(name="tdd", output_type=TDDRun, tools=_register_tools))
