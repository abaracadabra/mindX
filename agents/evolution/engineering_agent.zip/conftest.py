"""tests/conftest.py — Shared fixtures."""
from __future__ import annotations

import pytest


@pytest.fixture(autouse=True)
def _disable_real_llm_calls(monkeypatch: pytest.MonkeyPatch) -> None:
    """Belt-and-braces: ensure tests never accidentally call a real LLM."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
