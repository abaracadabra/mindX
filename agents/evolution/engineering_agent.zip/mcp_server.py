"""engineering_agent.mcp_server — Expose the engineering agent over MCP.

Run with:
    engineering-mcp                  # stdio (Claude Desktop / Cursor)
    engineering-mcp --http :8000     # streamable HTTP

Each Pocock skill is registered as a discrete MCP tool, plus one `route` tool
that uses the router. Mobile-friendly tool descriptions help client UIs.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

from fastmcp import FastMCP

from .agent import engineering, run_skill_directly
from .deps import EngineeringDeps
from .models import SkillName

mcp: FastMCP = FastMCP("engineering")

# A long-lived deps cache keyed by repo path. Each repo gets one
# EngineeringDeps instance; we don't tear it down between calls because the
# httpx client benefits from connection pooling.
_DEPS_CACHE: dict[str, EngineeringDeps] = {}


async def _deps(repo: str) -> EngineeringDeps:
    key = str(Path(repo).expanduser().resolve())
    if key not in _DEPS_CACHE:
        _DEPS_CACHE[key] = EngineeringDeps.for_repo(key)
    return _DEPS_CACHE[key]


@mcp.tool()
async def route(request: str, repo: str = ".") -> dict:
    """Route a free-form engineering request to the right Pocock skill.

    The agent picks one of: grill-with-docs, to-prd, to-issues, triage, tdd,
    diagnose, improve-codebase-architecture, zoom-out, setup-matt-pocock-skills.
    Returns a typed envelope: {skill_used, rationale, artifact, timestamp}.
    """
    deps = await _deps(repo)
    result = await engineering.run(request, deps=deps)
    return result.output.model_dump(mode="json")


def _register_skill_tool(skill: SkillName) -> None:
    @mcp.tool(name=f"skill_{skill.value.replace('-', '_')}")
    async def _direct(request: str, repo: str = ".") -> dict:
        f"""Run the `{skill.value}` skill directly. Skips routing — use when you know the skill."""
        deps = await _deps(repo)
        result = await run_skill_directly(skill, request, deps)
        return result.model_dump(mode="json")


for s in SkillName:
    _register_skill_tool(s)


@mcp.tool()
async def list_skills() -> list[dict]:
    """List the nine engineering skills with their one-line descriptions."""
    from .skills._prompts import EMBEDDED

    return [
        {"name": s.value, "first_line": EMBEDDED[s.value].splitlines()[0]}
        for s in SkillName
    ]


def main() -> None:
    import sys

    if "--http" in sys.argv:
        idx = sys.argv.index("--http")
        bind = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else ":8000"
        host, _, port = bind.partition(":")
        mcp.run(transport="streamable-http", host=host or "0.0.0.0", port=int(port or 8000))
    else:
        mcp.run()


if __name__ == "__main__":
    main()
