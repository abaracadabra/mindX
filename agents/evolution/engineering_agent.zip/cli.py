"""engineering_agent.cli — Command-line interface.

Usage:
    engineering route "diagnose this flaky test"
    engineering tdd "add multi-currency support to checkout"
    engineering diagnose "checkout fails on weekends"
    engineering setup
    engineering skills           # list all skills
    engineering skill <name>     # show a skill's prompt
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.json import JSON
from rich.panel import Panel

from .agent import engineering, run_skill_directly
from .deps import EngineeringDeps
from .models import SkillName
from .skills._prompts import EMBEDDED
from .skills.base import load_skill_prompt

app = typer.Typer(
    name="engineering",
    no_args_is_help=True,
    add_completion=False,
    help="Pydantic AI agent embodying Matt Pocock's engineering skills.",
)
console = Console()


def _resolve_repo(repo: Optional[str]) -> Path:
    return Path(repo).expanduser().resolve() if repo else Path.cwd()


@app.command()
def route(
    request: str = typer.Argument(..., help="Free-form request — the router picks the skill."),
    repo: Optional[str] = typer.Option(None, "--repo", "-r", help="Repo root (default: cwd)."),
    json_out: bool = typer.Option(False, "--json", help="Print JSON instead of pretty output."),
) -> None:
    """Run the router agent."""
    asyncio.run(_route(request, repo, json_out))


async def _route(request: str, repo: Optional[str], json_out: bool) -> None:
    async with EngineeringDeps.for_repo(_resolve_repo(repo)) as deps:
        result = await engineering.run(request, deps=deps)
    payload = result.output.model_dump(mode="json")
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, default=str) + "\n")
    else:
        console.print(Panel.fit(f"[bold]Skill chosen:[/bold] {payload['skill_used']}\n\n{payload['rationale']}"))
        console.print(JSON.from_data(payload["artifact"]))


def _make_skill_command(skill: SkillName) -> None:
    cmd_name = skill.value.replace("-", "_")

    @app.command(name=skill.value)
    def _cmd(
        request: str = typer.Argument(..., help=f"Request for `{skill.value}`."),
        repo: Optional[str] = typer.Option(None, "--repo", "-r"),
        json_out: bool = typer.Option(False, "--json"),
    ) -> None:
        f"""Run the `{skill.value}` skill directly (skip routing)."""
        asyncio.run(_run_direct(skill, request, repo, json_out))

    _cmd.__name__ = f"_cmd_{cmd_name}"


async def _run_direct(skill: SkillName, request: str, repo: Optional[str], json_out: bool) -> None:
    async with EngineeringDeps.for_repo(_resolve_repo(repo)) as deps:
        result = await run_skill_directly(skill, request, deps)
    payload = result.model_dump(mode="json")
    if json_out:
        sys.stdout.write(json.dumps(payload, indent=2, default=str) + "\n")
    else:
        console.print(Panel.fit(f"[bold]{payload['skill_used']}[/bold]"))
        console.print(JSON.from_data(payload["artifact"]))


for s in SkillName:
    _make_skill_command(s)


@app.command()
def skills() -> None:
    """List all skills the agent knows."""
    for s in SkillName:
        console.print(f"[bold cyan]{s.value:<35}[/bold cyan] {EMBEDDED[s.value].splitlines()[0]}")


@app.command()
def skill(
    name: str = typer.Argument(..., help="Skill slug, e.g. 'diagnose'."),
    repo: Optional[str] = typer.Option(None, "--repo", "-r"),
) -> None:
    """Print the system prompt for one skill (resolved against repo overrides)."""
    if name not in EMBEDDED:
        console.print(f"[red]unknown skill:[/red] {name!r}. Try `engineering skills`.")
        raise typer.Exit(2)
    deps = EngineeringDeps.for_repo(_resolve_repo(repo))
    try:
        prompt = load_skill_prompt(name, deps)
    finally:
        asyncio.run(deps.aclose())
    console.print(Panel(prompt, title=f"SKILL.md — {name}"))


def main() -> None:
    app()


if __name__ == "__main__":
    main()
