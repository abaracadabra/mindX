"""engineering_agent.skills — Registry of all nine Pocock engineering sub-agents.

Importing this module wires up the typed sub-agents. The router (`agent.py`)
delegates to them by `SkillName`.
"""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent

from ..deps import EngineeringDeps
from ..models import SkillName
from .diagnose import diagnose_agent
from .grill_with_docs import grill_agent
from .improve_codebase_architecture import architecture_agent
from .setup_matt_pocock_skills import setup_agent
from .tdd import tdd_agent
from .to_issues import issues_agent
from .to_prd import prd_agent
from .triage import triage_agent
from .zoom_out import zoom_agent

# Map SkillName → sub-agent. Used by the router for dispatch.
SUB_AGENTS: dict[SkillName, Agent[EngineeringDeps, Any]] = {
    SkillName.GRILL_WITH_DOCS: grill_agent,
    SkillName.TO_PRD: prd_agent,
    SkillName.TO_ISSUES: issues_agent,
    SkillName.TRIAGE: triage_agent,
    SkillName.TDD: tdd_agent,
    SkillName.DIAGNOSE: diagnose_agent,
    SkillName.IMPROVE_CODEBASE_ARCHITECTURE: architecture_agent,
    SkillName.ZOOM_OUT: zoom_agent,
    SkillName.SETUP: setup_agent,
}

__all__ = ["SUB_AGENTS"]
