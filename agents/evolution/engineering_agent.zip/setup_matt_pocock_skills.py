"""engineering_agent.skills.setup_matt_pocock_skills — Scaffold per-repo config."""
from __future__ import annotations

import json
from typing import Any

from pydantic_ai import Agent, RunContext

from ..deps import EngineeringDeps
from ..models import RepoSetup
from .base import SkillSpec, make_skill_agent

_DEFAULT_LABELS = [
    "bug",
    "feature",
    "needs-info",
    "repro-needed",
    "confirmed",
    "wontfix",
    "priority:high",
    "priority:medium",
    "priority:low",
]

_CONTEXT_TEMPLATE = """\
# Project

(One paragraph: what does this project do, in domain terms?)

## Glossary

<!--
Add domain terms as `- **Term** — Definition. (avoid: forbidden synonyms)`
The `grill-with-docs` skill will populate this as you decide.
-->

## Triage labels

{labels}
"""

_META_ADR = """\
# 1. Record Architecture Decisions

Status: accepted

## Context

We need a lightweight way to track architectural decisions so they aren't
re-litigated on every change.

## Decision

We will use Architecture Decision Records (ADRs), one per file in `docs/adr/`,
numbered sequentially. Each ADR has Context, Decision, and Consequences sections
plus a Status line at the top.

## Consequences

- New decisions must be recorded as ADRs before being implemented.
- Superseded ADRs keep their file but flip Status to `superseded` and link
  the new ADR.
"""


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def write_context_md(
        ctx: RunContext[EngineeringDeps], labels: list[str]
    ) -> dict:
        """Create CONTEXT.md if missing."""
        path = ctx.deps.repo_root / "CONTEXT.md"
        if path.exists():
            return {"path": str(path), "created": False, "reason": "already exists"}
        path.write_text(
            _CONTEXT_TEMPLATE.format(labels=", ".join(f"`{l}`" for l in labels)),
            encoding="utf-8",
        )
        return {"path": str(path), "created": True}

    @agent.tool
    async def write_meta_adr(ctx: RunContext[EngineeringDeps]) -> dict:
        """Create docs/adr/0001-record-architecture-decisions.md if missing."""
        adr_dir = ctx.deps.repo_root / "docs" / "adr"
        adr_dir.mkdir(parents=True, exist_ok=True)
        path = adr_dir / "0001-record-architecture-decisions.md"
        if path.exists():
            return {"path": str(path), "created": False, "reason": "already exists"}
        path.write_text(_META_ADR, encoding="utf-8")
        return {"path": str(path), "created": True}

    @agent.tool
    async def save_setup(
        ctx: RunContext[EngineeringDeps],
        issue_tracker: str,
        triage_labels: list[str],
        docs_dir: str = "docs",
    ) -> dict:
        """Persist setup choices to .claude/setup.json (and triage-labels.txt)."""
        cfg_dir = ctx.deps.repo_root / ".claude"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        (cfg_dir / "setup.json").write_text(
            json.dumps(
                {
                    "issue_tracker": issue_tracker,
                    "triage_labels": triage_labels,
                    "docs_dir": docs_dir,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        (cfg_dir / "triage-labels.txt").write_text(
            "\n".join(triage_labels) + "\n", encoding="utf-8"
        )
        return {"setup_path": str(cfg_dir / "setup.json")}

    @agent.tool
    async def default_labels(ctx: RunContext[EngineeringDeps]) -> list[str]:
        """Return the recommended default label vocabulary."""
        return list(_DEFAULT_LABELS)


setup_agent = make_skill_agent(
    SkillSpec(name="setup-matt-pocock-skills", output_type=RepoSetup, tools=_register_tools)
)
