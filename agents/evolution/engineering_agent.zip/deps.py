"""engineering_agent.deps — Dependency container injected into every Pydantic AI agent.

`EngineeringDeps` is the single object passed to `Agent.run(..., deps=deps)`. Every
tool receives it via `RunContext[EngineeringDeps]`. Keep it small, typed, and
constructed once per request — never stash secrets at module scope.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import httpx

from .context_loader import ContextLoader
from .git_tools import GitTools
from .issue_tracker import IssueTracker, LocalFileTracker
from .shell_tools import ShellTools


@dataclass
class EngineeringDeps:
    """Single dependency object passed to every agent.

    Construct via `EngineeringDeps.for_repo(repo_root)` in normal flows; build
    by hand only in tests.
    """
    repo_root: Path
    context_loader: ContextLoader
    git: GitTools
    shell: ShellTools
    issues: IssueTracker
    http: httpx.AsyncClient

    # Optional: mindX integration (carries over from the SkillForge ecosystem).
    mindx_url: Optional[str] = None
    mindx_api_key: Optional[str] = None

    # Caller identity (BANKON DID), if running gated.
    caller_did: Optional[str] = None

    # The skill catalogue dir — defaults to `<repo>/.claude/skills/engineering`,
    # falls back to bundled prompts. Lets users override Pocock's text.
    skills_dir: Optional[Path] = None

    # Cached, lazy-loaded artefacts.
    _context_cache: Optional[object] = field(default=None, repr=False)

    @classmethod
    def for_repo(
        cls,
        repo_root: str | Path,
        *,
        issue_tracker: Optional[IssueTracker] = None,
        skills_dir: Optional[str | Path] = None,
        mindx_url: Optional[str] = None,
        mindx_api_key: Optional[str] = None,
        caller_did: Optional[str] = None,
        timeout: float = 60.0,
    ) -> "EngineeringDeps":
        root = Path(repo_root).expanduser().resolve()
        if not root.exists():
            raise FileNotFoundError(f"repo_root does not exist: {root}")

        return cls(
            repo_root=root,
            context_loader=ContextLoader(root),
            git=GitTools(root),
            shell=ShellTools(root),
            issues=issue_tracker or LocalFileTracker(root),
            http=httpx.AsyncClient(timeout=timeout),
            skills_dir=Path(skills_dir).expanduser().resolve() if skills_dir else None,
            mindx_url=mindx_url,
            mindx_api_key=mindx_api_key,
            caller_did=caller_did,
        )

    async def aclose(self) -> None:
        await self.http.aclose()

    async def __aenter__(self) -> "EngineeringDeps":
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()
