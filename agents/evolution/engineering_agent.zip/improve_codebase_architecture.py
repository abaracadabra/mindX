"""engineering_agent.skills.improve_codebase_architecture — Find deepening opportunities."""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent, RunContext

from ..deps import EngineeringDeps
from ..models import ArchitectureReview
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def list_modules(ctx: RunContext[EngineeringDeps]) -> list[dict]:
        """List top-level modules with a rough size signal (file count + total bytes)."""
        out: list[dict] = []
        for p in sorted(ctx.deps.repo_root.iterdir()):
            if not p.is_dir() or p.name.startswith(".") or p.name in {
                "node_modules",
                "dist",
                "build",
                "out",
                "lib",
                "__pycache__",
            }:
                continue
            files = list(p.rglob("*"))
            n_files = sum(1 for f in files if f.is_file())
            n_bytes = sum(f.stat().st_size for f in files if f.is_file())
            out.append({"name": p.name, "files": n_files, "bytes": n_bytes})
        return out

    @agent.tool
    async def churn_report(ctx: RunContext[EngineeringDeps], limit: int = 20) -> list[dict]:
        """Files most-changed in the last 100 commits. High churn = candidate for deepening."""
        try:
            commits = ctx.deps.git.recent_commits(n=100)
        except Exception:
            return []
        # Cheap churn approximation: ask git for shortstat per file path.
        res = await ctx.deps.shell.run(
            "git log --name-only --pretty=format: -n 100",
            timeout=30,
        )
        counts: dict[str, int] = {}
        for line in res.stdout.splitlines():
            if not line.strip() or line.startswith(":"):
                continue
            counts[line] = counts.get(line, 0) + 1
        ranked = sorted(counts.items(), key=lambda kv: -kv[1])[:limit]
        return [{"path": p, "changes_in_last_100_commits": n} for p, n in ranked]

    @agent.tool
    async def read_glossary_and_adrs(ctx: RunContext[EngineeringDeps]) -> dict:
        """Return glossary terms + ADR titles. Recommendations MUST cite these."""
        c = ctx.deps.context_loader.load()
        return {
            "glossary": [t.model_dump() for t in c.glossary],
            "adrs": [{"number": a.number, "title": a.title, "status": a.status} for a in c.adrs],
        }


architecture_agent = make_skill_agent(
    SkillSpec(
        name="improve-codebase-architecture",
        output_type=ArchitectureReview,
        tools=_register_tools,
    )
)
