"""engineering_agent.git_tools — Thin GitPython wrapper for the agent's repo ops.

Read-only by default. Mutating ops (commit, branch, push) require explicit calls
and return the new ref so the agent can verify state before proceeding.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

try:
    import git  # GitPython
except ImportError:  # pragma: no cover
    git = None  # type: ignore[assignment]


class GitNotARepo(RuntimeError):
    pass


class GitTools:
    """Synchronous git operations. Cheap; no need for async."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        if git is None:
            self._repo = None
            return
        try:
            self._repo = git.Repo(repo_root)
        except Exception:
            self._repo = None

    def _require(self) -> "git.Repo":
        if self._repo is None:
            raise GitNotARepo(f"{self.repo_root} is not a git repository (or GitPython missing)")
        return self._repo

    # ------------------------------------------------------------------ #
    # Read
    # ------------------------------------------------------------------ #

    def head_sha(self) -> str:
        return self._require().head.commit.hexsha

    def current_branch(self) -> str:
        try:
            return self._require().active_branch.name
        except TypeError:
            return "DETACHED"

    def is_clean(self) -> bool:
        repo = self._require()
        return not repo.is_dirty(untracked_files=False)

    def changed_files(self) -> list[str]:
        """Files modified since HEAD (not staged or staged)."""
        repo = self._require()
        diff = repo.git.diff("--name-only", "HEAD")
        return [l for l in diff.splitlines() if l.strip()]

    def recent_commits(self, n: int = 20) -> list[dict[str, str]]:
        repo = self._require()
        out: list[dict[str, str]] = []
        for c in repo.iter_commits(max_count=n):
            out.append(
                {
                    "sha": c.hexsha[:12],
                    "author": str(c.author),
                    "summary": c.summary,
                    "date": c.committed_datetime.isoformat(),
                }
            )
        return out

    def show_file_at(self, path: str, ref: str = "HEAD") -> Optional[str]:
        repo = self._require()
        try:
            return repo.git.show(f"{ref}:{path}")
        except Exception:
            return None

    # ------------------------------------------------------------------ #
    # Write (explicit; the agent must opt in via tool args)
    # ------------------------------------------------------------------ #

    def stage(self, *paths: str) -> None:
        repo = self._require()
        repo.index.add(list(paths))

    def commit(self, message: str, *, allow_empty: bool = False) -> str:
        repo = self._require()
        if not allow_empty and not repo.is_dirty():
            raise RuntimeError("nothing staged to commit")
        new = repo.index.commit(message)
        return new.hexsha

    def create_branch(self, name: str, *, checkout: bool = True) -> str:
        repo = self._require()
        new = repo.create_head(name)
        if checkout:
            new.checkout()
        return new.name
