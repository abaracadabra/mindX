# engineering-agent

A Pydantic AI agent embodying [Matt Pocock's engineering skills](https://github.com/mattpocock/skills) — `grill-with-docs`, `to-prd`, `to-issues`, `triage`, `tdd`, `diagnose`, `improve-codebase-architecture`, `zoom-out`, `setup-matt-pocock-skills` — as a typed, composable Python agent.

Every skill is a Pydantic AI sub-agent whose **system prompt is the SKILL.md** itself (loaded from disk first, with bundled fallbacks) and whose **output is a typed Pydantic model**. A top-level router agent picks the right skill based on a free-form request and returns a typed envelope.

## Why

Skills give the model a vocabulary of "what should I do here". But Pocock's skills only act on the agent's *prose* — the agent decides whether to follow them. This package binds each skill to a **typed contract** the model must satisfy: a `Diagnosis` must have 3–5 falsifiable hypotheses; a `TDDRun` must have non-empty RED evidence per cycle; a `FeedbackLoop` slower than 30s and less than 95% deterministic gets bounced via `ModelRetry`. The skills aren't suggestions any more — they're enforced by the Pydantic schema.

## Install

```bash
pip install -e .          # this package
pip install -e ".[dev]"   # plus pytest/ruff/mypy
pip install -e ".[github]"  # PyGithub for the GitHub issue tracker
```

Set an LLM key:
```bash
export ANTHROPIC_API_KEY=...
```

## Quickstart

```python
import asyncio
from engineering_agent import engineering, EngineeringDeps

async def main():
    async with EngineeringDeps.for_repo(".") as deps:
        result = await engineering.run("diagnose this flaky test", deps=deps)
    print(result.output.skill_used)            # SkillName.DIAGNOSE
    print(result.output.artifact.hypotheses)   # list[Hypothesis] (typed)

asyncio.run(main())
```

## CLI

```bash
engineering route "diagnose this flaky test"
engineering tdd "add multi-currency support"
engineering diagnose "checkout fails on weekends"
engineering setup-matt-pocock-skills
engineering skills            # list all 9 skills
engineering skill diagnose    # print the resolved system prompt
```

## MCP server

Expose the agent over MCP for Claude Desktop / Cursor / any MCP client:

```bash
engineering-mcp                   # stdio
engineering-mcp --http :8000      # streamable HTTP
```

Each skill is a discrete MCP tool (`skill_diagnose`, `skill_tdd`, …) plus a `route` tool that uses the router.

## Architecture

```
                    ┌─────────────────────────────────────┐
   user request ─→ │   engineering (router agent)        │
                    │   output_type=EngineeringResult     │
                    └────────┬────────────────────────────┘
                             │ picks ONE of 9 dispatch tools
                             ▼
                  ┌──────────────────────────┐
                  │  SUB_AGENTS[SkillName]   │     each: typed output
                  │  ────────────────────    │     each: SKILL.md as prompt
                  │  • grill_agent           │     each: skill-specific tools
                  │  • prd_agent             │
                  │  • issues_agent          │
                  │  • triage_agent          │
                  │  • tdd_agent             │
                  │  • diagnose_agent        │
                  │  • architecture_agent    │
                  │  • zoom_agent            │
                  │  • setup_agent           │
                  └────────────┬─────────────┘
                               │ deps: EngineeringDeps
                               ▼
                ┌──────────────────────────────────┐
                │  EngineeringDeps                 │
                │  • repo_root: Path               │
                │  • context_loader (CONTEXT.md +  │
                │       docs/adr/)                 │
                │  • git: GitTools                 │
                │  • shell: ShellTools             │
                │  • issues: IssueTracker          │
                │     (local | GitHub | Linear)    │
                │  • mindx_url, caller_did (opt.)  │
                └──────────────────────────────────┘
```

## Skill prompt resolution

When a sub-agent runs, its system prompt is resolved in this order:

1. `<deps.skills_dir>/<name>/SKILL.md` (explicit override)
2. `<repo>/.claude/skills/engineering/<name>/SKILL.md`
3. `<repo>/skills/engineering/<name>/SKILL.md` (Pocock layout)
4. The bundled string constant in `engineering_agent.skills._prompts.EMBEDDED`

So a project can override Pocock's text without forking this package — drop a `SKILL.md` into `.claude/skills/engineering/diagnose/SKILL.md` and the diagnose sub-agent loads it. The router still dispatches by name.

## Skill outputs (the typed contract)

| Skill | Output type | Key invariants |
|---|---|---|
| `grill-with-docs` | `GrillSession` | ≥1 question OR ≥1 ADR proposed |
| `to-prd` | `PRD` | non-empty `affected_modules` + `success_criteria` |
| `to-issues` | `IssuesPlan` | ≥1 vertical slice; horizontal-slicing detected via `file_slice` tool |
| `triage` | `TriageDecision` | exactly one role transition |
| `tdd` | `TDDRun` | non-empty RED per cycle; non-empty GREEN per cycle |
| `diagnose` | `Diagnosis` | 3–5 falsifiable ranked hypotheses; loop must be fast OR deterministic |
| `improve-codebase-architecture` | `ArchitectureReview` | ≥1 deepening opportunity |
| `zoom-out` | `SystemView` | tight role paragraph |
| `setup-matt-pocock-skills` | `RepoSetup` | tracker ∈ {github, linear, local} |

These constraints are enforced by Pydantic `model_validator`s — the agent retries on violation via `ModelRetry`.

## Domain context (CONTEXT.md + ADRs)

Every sub-agent gets the project's domain context injected as a dynamic system prompt:

- `CONTEXT.md` — `## Glossary` section parsed into `GlossaryTerm`s with avoid-lists.
- `docs/adr/NNNN-*.md` — parsed into `ADR`s with status (proposed / accepted / deprecated / superseded).
- `.claude/triage-labels.txt` (or `## Triage labels` in CONTEXT.md) — vocabulary for the triage skill.

This realises Pocock's "shared language" doctrine without hand-rolling the parser per skill.

## Integration with the broader ecosystem

This package is designed to slot into the SkillForge / mindX / BANKON / x402 / Algorand DAIO stack:

- `EngineeringDeps.mindx_url` + `mindx_api_key` — pass through to a mindX scoring step (use as an `@output_validator` to gate skill artifacts on alignment ≥ threshold).
- `EngineeringDeps.caller_did` — BANKON identity for skill-authoring rate limits / paid premium tiers.
- The `setup-matt-pocock-skills` skill writes to `.claude/setup.json`, the same config that other ecosystem agents read.

See [the SkillForge architecture document](../docs/skillforge-architecture.md) for the full picture.

## Tests

```bash
pytest -q
```

Tests use `TestModel` from `pydantic_ai.models.test`, so they don't require API keys.

## License

MIT (matches `mattpocock/skills`). The bundled SKILL.md prompts are derived from Matt Pocock's MIT-licensed repo; verbatim text is preserved with attribution in `engineering_agent/skills/_prompts.py`.
