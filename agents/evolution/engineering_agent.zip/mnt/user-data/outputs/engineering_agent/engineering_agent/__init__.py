"""engineering_agent — A Pydantic AI agent embodying Matt Pocock's engineering skills.

Public surface:
    from engineering_agent import engineering, EngineeringDeps, run_skill_directly
    from engineering_agent.models import SkillName, Diagnosis, TDDRun, ...

The router takes a free-form request, picks the matching skill, runs the
typed sub-agent, and returns a typed envelope.

    deps = EngineeringDeps.for_repo("/path/to/repo")
    result = await engineering.run("diagnose this flaky test", deps=deps)
    # result.output: EngineeringResult
    # result.output.skill_used == SkillName.DIAGNOSE
    # result.output.artifact: Diagnosis  (typed)
"""
from __future__ import annotations

from .agent import engineering, run_skill_directly
from .deps import EngineeringDeps
from .models import (
    ADR,
    ArchitectureReview,
    CodebaseContext,
    DeepeningOpportunity,
    Diagnosis,
    EngineeringResult,
    FeedbackLoop,
    FeedbackLoopKind,
    GlossaryTerm,
    GrillQuestion,
    GrillSession,
    Hypothesis,
    IssuesPlan,
    PRD,
    RepoSetup,
    SkillName,
    SystemView,
    TDDRun,
    TestCycle,
    TriageDecision,
    TriageRole,
    VerticalSlice,
)

__version__ = "0.1.0"

__all__ = [
    "engineering",
    "run_skill_directly",
    "EngineeringDeps",
    "EngineeringResult",
    "SkillName",
    # Domain context
    "CodebaseContext",
    "GlossaryTerm",
    "ADR",
    # Skill artifacts
    "GrillSession",
    "GrillQuestion",
    "PRD",
    "IssuesPlan",
    "VerticalSlice",
    "TriageDecision",
    "TriageRole",
    "TDDRun",
    "TestCycle",
    "Diagnosis",
    "Hypothesis",
    "FeedbackLoop",
    "FeedbackLoopKind",
    "ArchitectureReview",
    "DeepeningOpportunity",
    "SystemView",
    "RepoSetup",
    "__version__",
]
