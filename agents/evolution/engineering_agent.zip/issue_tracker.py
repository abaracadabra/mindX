"""engineering_agent.issue_tracker — Pluggable backend for issues (local / GitHub / Linear).

`/to-issues`, `/to-prd`, and `/triage` all need somewhere to put work items.
The default is a local-file backend (issues/{nnnn}-{slug}.md) so the agent works
out-of-the-box on any repo. GitHub & Linear are optional — wire them in deps via
`EngineeringDeps.for_repo(..., issue_tracker=GitHubTracker(...))`.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class IssueRef:
    id: str  # "#42" or "ABC-123" or "0042"
    url: str  # repo-relative or external
    title: str


class IssueTracker(ABC):
    @abstractmethod
    async def create(
        self,
        *,
        title: str,
        body: str,
        labels: Optional[list[str]] = None,
    ) -> IssueRef:
        ...

    @abstractmethod
    async def list(self, *, label: Optional[str] = None, limit: int = 50) -> list[IssueRef]:
        ...

    @abstractmethod
    async def add_label(self, issue_id: str, label: str) -> None:
        ...


# --------------------------------------------------------------------------- #
# Local-file backend — works without network, the default
# --------------------------------------------------------------------------- #

class LocalFileTracker(IssueTracker):
    def __init__(self, repo_root: Path, *, dirname: str = "issues") -> None:
        self.dir = repo_root / dirname
        self.dir.mkdir(parents=True, exist_ok=True)

    def _next_number(self) -> int:
        nums = []
        for p in self.dir.glob("[0-9]*.md"):
            try:
                nums.append(int(p.name.split("-", 1)[0]))
            except ValueError:
                continue
        return (max(nums) + 1) if nums else 1

    @staticmethod
    def _slug(title: str) -> str:
        s = "".join(c.lower() if c.isalnum() else "-" for c in title)
        while "--" in s:
            s = s.replace("--", "-")
        return s.strip("-")[:60] or "issue"

    async def create(
        self,
        *,
        title: str,
        body: str,
        labels: Optional[list[str]] = None,
    ) -> IssueRef:
        n = self._next_number()
        path = self.dir / f"{n:04d}-{self._slug(title)}.md"
        front = ["---", f"id: {n:04d}", f"title: {title}"]
        if labels:
            front.append(f"labels: [{', '.join(labels)}]")
        front.append("---")
        path.write_text("\n".join(front) + "\n\n" + body.strip() + "\n", encoding="utf-8")
        return IssueRef(id=f"{n:04d}", url=str(path.relative_to(self.dir.parent)), title=title)

    async def list(self, *, label: Optional[str] = None, limit: int = 50) -> list[IssueRef]:
        out: list[IssueRef] = []
        for p in sorted(self.dir.glob("[0-9]*.md"))[:limit]:
            text = p.read_text(encoding="utf-8", errors="replace")
            title_line = next((l for l in text.splitlines() if l.startswith("title:")), "title: ?")
            title = title_line.split("title:", 1)[1].strip()
            if label and f"[{label}]" not in text and f", {label}" not in text:
                continue
            out.append(IssueRef(id=p.name[:4], url=str(p), title=title))
        return out

    async def add_label(self, issue_id: str, label: str) -> None:
        for p in self.dir.glob(f"{issue_id}*.md"):
            text = p.read_text(encoding="utf-8", errors="replace")
            if "labels:" in text:
                # Append to existing labels line.
                lines = text.splitlines()
                for i, ln in enumerate(lines):
                    if ln.startswith("labels:"):
                        if label in ln:
                            return
                        lines[i] = ln.rstrip("]") + f", {label}]"
                        p.write_text("\n".join(lines) + "\n", encoding="utf-8")
                        return
            else:
                # Insert into front-matter.
                p.write_text(text.replace("---\n", f"---\nlabels: [{label}]\n", 1), encoding="utf-8")
                return


# --------------------------------------------------------------------------- #
# GitHub backend (optional dependency)
# --------------------------------------------------------------------------- #

class GitHubTracker(IssueTracker):
    """Thin wrapper over PyGithub. Requires `pip install engineering-agent[github]`."""

    def __init__(self, *, token: str, repo: str) -> None:
        try:
            from github import Github  # type: ignore[import-untyped]
        except ImportError as e:
            raise ImportError(
                "GitHubTracker requires PyGithub: `pip install 'engineering-agent[github]'`"
            ) from e
        self._gh = Github(token)
        self._repo = self._gh.get_repo(repo)

    async def create(
        self,
        *,
        title: str,
        body: str,
        labels: Optional[list[str]] = None,
    ) -> IssueRef:
        # PyGithub is sync; run in default executor.
        import asyncio

        loop = asyncio.get_running_loop()
        issue = await loop.run_in_executor(
            None,
            lambda: self._repo.create_issue(title=title, body=body, labels=labels or []),
        )
        return IssueRef(id=f"#{issue.number}", url=issue.html_url, title=title)

    async def list(self, *, label: Optional[str] = None, limit: int = 50) -> list[IssueRef]:
        import asyncio

        loop = asyncio.get_running_loop()

        def _list() -> list[IssueRef]:
            kw: dict[str, object] = {"state": "open"}
            if label:
                kw["labels"] = [label]
            return [
                IssueRef(id=f"#{i.number}", url=i.html_url, title=i.title)
                for i in self._repo.get_issues(**kw)[:limit]
            ]

        return await loop.run_in_executor(None, _list)

    async def add_label(self, issue_id: str, label: str) -> None:
        import asyncio

        loop = asyncio.get_running_loop()
        n = int(issue_id.lstrip("#"))
        await loop.run_in_executor(None, lambda: self._repo.get_issue(n).add_to_labels(label))
