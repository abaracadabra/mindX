"""tests/test_smoke.py — Smoke tests that don't require API keys.

Uses Pydantic AI's `TestModel` to verify wiring: prompt resolution, tool
registration, output schema validation, and the router → sub-agent dispatch.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic_ai.models.test import TestModel

from engineering_agent import (
    EngineeringDeps,
    SkillName,
    engineering,
    run_skill_directly,
)
from engineering_agent.agent import dispatch_diagnose
from engineering_agent.context_loader import ContextLoader
from engineering_agent.models import (
    Diagnosis,
    FeedbackLoop,
    FeedbackLoopKind,
    Hypothesis,
    TDDRun,
    TestCycle,
)
from engineering_agent.skills._prompts import EMBEDDED


# --------------------------------------------------------------------------- #
# Models — pure validation
# --------------------------------------------------------------------------- #

class TestModels:
    def test_hypothesis_requires_falsifiable_format(self) -> None:
        with pytest.raises(ValueError, match="not falsifiable"):
            Hypothesis(rank=1, cause="thread races", prediction="something might happen")

    def test_hypothesis_accepts_if_then(self) -> None:
        h = Hypothesis(
            rank=1,
            cause="thread race in cache",
            prediction="If thread race is the cause, then adding a mutex will make the bug disappear.",
        )
        assert h.rank == 1

    def test_feedback_loop_rejects_slow_flaky(self) -> None:
        with pytest.raises(ValueError, match="tighten"):
            FeedbackLoop(
                kind=FeedbackLoopKind.FAILING_TEST,
                description="slow flaky",
                command="pytest tests/foo.py",
                runtime_seconds=60.0,
                determinism=0.6,
            )

    def test_feedback_loop_accepts_fast_deterministic(self) -> None:
        loop = FeedbackLoop(
            kind=FeedbackLoopKind.FAILING_TEST,
            description="ok",
            command="pytest -x tests/foo.py",
            runtime_seconds=2.5,
            determinism=1.0,
        )
        assert loop.ok if hasattr(loop, "ok") else True
        assert loop.runtime_seconds == 2.5

    def test_diagnosis_requires_3_to_5_hypotheses(self) -> None:
        loop = FeedbackLoop(
            kind=FeedbackLoopKind.FAILING_TEST,
            description="x",
            command="pytest -x",
            runtime_seconds=1.0,
            determinism=1.0,
        )
        with pytest.raises(ValueError):
            Diagnosis(
                bug_summary="x",
                feedback_loop=loop,
                reproduction_confirmed=True,
                hypotheses=[
                    Hypothesis(
                        rank=1,
                        cause="x",
                        prediction="If x is the cause, then y will make it disappear.",
                    )
                ],
                instrumentation_plan=["log a"],
            )

    def test_diagnosis_rank_uniqueness(self) -> None:
        loop = FeedbackLoop(
            kind=FeedbackLoopKind.CLI,
            description="x",
            command="x",
            runtime_seconds=1.0,
            determinism=1.0,
        )
        h = lambda r, c: Hypothesis(  # noqa: E731
            rank=r,
            cause=c,
            prediction=f"If {c} is the cause, then logging will make the bug disappear.",
        )
        with pytest.raises(ValueError, match="unique"):
            Diagnosis(
                bug_summary="x",
                feedback_loop=loop,
                reproduction_confirmed=True,
                hypotheses=[h(1, "a"), h(1, "b"), h(2, "c")],
                instrumentation_plan=["x"],
            )

    def test_tdd_cycle_requires_red_evidence(self) -> None:
        with pytest.raises(ValueError, match="red"):
            TestCycle(
                behaviour="user can checkout",
                test_path="tests/checkout_test.py",
                red_evidence="",
                green_diff_summary="implemented checkout",
            )

    def test_tdd_run_rejects_empty_green(self) -> None:
        cycle = TestCycle(
            behaviour="user can checkout",
            test_path="tests/checkout_test.py",
            red_evidence="AssertionError: expected 200, got 500",
            green_diff_summary="",
        )
        with pytest.raises(ValueError, match="horizontal"):
            TDDRun(
                feature="checkout",
                interface="POST /checkout",
                behaviours_to_test=["user can checkout"],
                cycles=[cycle],
            )


# --------------------------------------------------------------------------- #
# Prompts — every skill has one
# --------------------------------------------------------------------------- #

class TestPrompts:
    def test_all_nine_skills_have_embedded_prompts(self) -> None:
        for skill in SkillName:
            assert skill.value in EMBEDDED, f"missing prompt for {skill.value}"
            assert len(EMBEDDED[skill.value]) > 200, f"prompt too short for {skill.value}"

    def test_diagnose_prompt_mentions_six_phases(self) -> None:
        text = EMBEDDED["diagnose"]
        for phase in ("PHASE 1", "PHASE 2", "PHASE 3", "PHASE 4", "PHASE 5", "PHASE 6"):
            assert phase in text, f"diagnose prompt missing {phase}"

    def test_tdd_prompt_warns_against_horizontal(self) -> None:
        assert "HORIZONTAL" in EMBEDDED["tdd"]


# --------------------------------------------------------------------------- #
# Context loader
# --------------------------------------------------------------------------- #

class TestContextLoader:
    def test_loads_glossary_from_context_md(self, tmp_path: Path) -> None:
        ctx_md = tmp_path / "CONTEXT.md"
        ctx_md.write_text(
            "# Project\n\nThe checkout system.\n\n"
            "## Glossary\n\n"
            "- **materialization** — turning a virtual lesson into a real one. (avoid: realisation)\n"
            "- **cascade** — the chain reaction of materialization.\n"
        )
        loader = ContextLoader(tmp_path)
        ctx = loader.load()
        assert ctx.project_summary and "checkout" in ctx.project_summary
        terms = {t.term: t for t in ctx.glossary}
        assert "materialization" in terms
        assert terms["materialization"].avoid == ["realisation"]

    def test_loads_adrs_with_status(self, tmp_path: Path) -> None:
        adr_dir = tmp_path / "docs" / "adr"
        adr_dir.mkdir(parents=True)
        (adr_dir / "0001-record-architecture-decisions.md").write_text(
            "# 1. Record Architecture Decisions\n\nstatus: accepted\n\n"
            "## Context\nWe need ADRs.\n\n"
            "## Decision\nUse ADRs.\n\n"
            "## Consequences\nMore docs.\n"
        )
        loader = ContextLoader(tmp_path)
        ctx = loader.load()
        assert len(ctx.adrs) == 1
        assert ctx.adrs[0].number == 1
        assert ctx.adrs[0].status == "accepted"

    def test_renders_compact_prompt(self, tmp_path: Path) -> None:
        loader = ContextLoader(tmp_path)
        rendered = loader.render_for_prompt()
        assert "no CONTEXT.md" in rendered


# --------------------------------------------------------------------------- #
# Agent wiring — uses TestModel (no real LLM call)
# --------------------------------------------------------------------------- #

class TestRouter:
    @pytest.mark.asyncio
    async def test_router_dispatches_to_correct_subagent(self, tmp_path: Path) -> None:
        # Override sub-agents AND the router with TestModels.
        from engineering_agent.skills import SUB_AGENTS

        # The diagnose sub-agent will be told to produce a canned Diagnosis.
        canned = Diagnosis(
            bug_summary="flaky test",
            feedback_loop=FeedbackLoop(
                kind=FeedbackLoopKind.FAILING_TEST,
                description="run pytest",
                command="pytest -x tests/flaky.py",
                runtime_seconds=2.0,
                determinism=1.0,
            ),
            reproduction_confirmed=True,
            hypotheses=[
                Hypothesis(rank=i, cause=f"cause {i}",
                           prediction=f"If cause {i} is the cause, then fix {i} will make the bug disappear.")
                for i in range(1, 4)
            ],
            instrumentation_plan=["log timing"],
        )
        diagnose = SUB_AGENTS[SkillName.DIAGNOSE]
        with diagnose.override(model=TestModel(custom_output_args=canned.model_dump(mode="json"))):
            with engineering.override(
                model=TestModel(
                    call_tools=["dispatch_diagnose"],
                    custom_output_args={
                        "skill_used": "diagnose",
                        "rationale": "User said 'diagnose'",
                        "artifact": canned.model_dump(mode="json"),
                        "timestamp": "2026-01-01T00:00:00Z",
                    },
                )
            ):
                async with EngineeringDeps.for_repo(tmp_path) as deps:
                    result = await engineering.run(
                        "diagnose this flaky test", deps=deps
                    )
        assert result.output.skill_used == SkillName.DIAGNOSE
        assert result.output.artifact.bug_summary == "flaky test"


# --------------------------------------------------------------------------- #
# Direct skill invocation
# --------------------------------------------------------------------------- #

class TestDirectInvocation:
    @pytest.mark.asyncio
    async def test_run_skill_directly_returns_envelope(self, tmp_path: Path) -> None:
        from engineering_agent.skills import SUB_AGENTS

        repo_setup = {
            "issue_tracker": "local",
            "triage_labels": ["bug", "feature"],
            "docs_dir": "docs",
            "context_md_created": True,
            "adr_dir_created": True,
        }
        with SUB_AGENTS[SkillName.SETUP].override(
            model=TestModel(custom_output_args=repo_setup)
        ):
            async with EngineeringDeps.for_repo(tmp_path) as deps:
                result = await run_skill_directly(SkillName.SETUP, "set up", deps)
        assert result.skill_used == SkillName.SETUP
        assert result.artifact.issue_tracker == "local"
