"""examples/example_diagnose.py — End-to-end diagnose skill example.

Requires ANTHROPIC_API_KEY in env. Run from repo root:

    python examples/example_diagnose.py /path/to/your/repo "checkout fails on weekends"
"""
from __future__ import annotations

import asyncio
import sys

from rich import print as rprint

from engineering_agent import EngineeringDeps, SkillName, run_skill_directly


async def main() -> None:
    if len(sys.argv) < 3:
        print("usage: example_diagnose.py <repo_root> <bug_description>", file=sys.stderr)
        sys.exit(2)
    repo, bug = sys.argv[1], sys.argv[2]

    async with EngineeringDeps.for_repo(repo) as deps:
        rprint(f"[bold cyan]Running diagnose on:[/bold cyan] {repo}")
        rprint(f"[bold]Bug:[/bold] {bug}\n")
        result = await run_skill_directly(SkillName.DIAGNOSE, bug, deps)

    diag = result.artifact
    rprint(f"[bold green]✓ Diagnosis complete[/bold green]")
    rprint(f"\n[bold]Feedback loop:[/bold] {diag.feedback_loop.kind.value}")
    rprint(f"  command: {diag.feedback_loop.command}")
    rprint(f"  runtime: {diag.feedback_loop.runtime_seconds:.1f}s")
    rprint(f"  determinism: {diag.feedback_loop.determinism:.2f}")
    rprint(f"\n[bold]Hypotheses (ranked):[/bold]")
    for h in sorted(diag.hypotheses, key=lambda x: x.rank):
        rprint(f"  {h.rank}. {h.cause}")
        rprint(f"     → {h.prediction}")
    if diag.confirmed_cause:
        rprint(f"\n[bold]Confirmed cause:[/bold] {diag.confirmed_cause}")
    if diag.fix_summary:
        rprint(f"[bold]Fix:[/bold] {diag.fix_summary}")
    if diag.architecture_handoff:
        rprint(f"\n[yellow]Hand-off to /improve-codebase-architecture:[/yellow] "
               f"{diag.architecture_handoff}")


if __name__ == "__main__":
    asyncio.run(main())
