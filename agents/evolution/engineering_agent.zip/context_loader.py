"""engineering_agent.context_loader — Loads CONTEXT.md and docs/adr/*.md.

Pocock's "shared language" doctrine: agents and humans must speak the same
domain vocabulary. The loader parses CONTEXT.md (glossary) and docs/adr/
(decisions) into typed objects so every skill can ground its outputs in
the project's actual terminology.

Format expectations are forgiving — we accept the pragmatic conventions the
mattpocock/skills setup creates, but degrade gracefully if files are missing.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from .models import ADR, CodebaseContext, GlossaryTerm

_ADR_FILENAME_RE = re.compile(r"^(\d{1,4})[-_](.+)\.md$", re.IGNORECASE)
_GLOSSARY_HEADING_RE = re.compile(r"^#{1,3}\s*glossary\b", re.IGNORECASE | re.MULTILINE)
_TERM_BULLET_RE = re.compile(
    r"^\s*[-*]\s*\*\*([^*]+?)\*\*\s*[—–:-]\s*(.+?)\s*$",
    re.MULTILINE,
)
_AVOID_RE = re.compile(r"avoid\s*:\s*(.+?)(?:\.|\n|$)", re.IGNORECASE)
_STATUS_RE = re.compile(r"^status\s*:\s*(.+?)$", re.IGNORECASE | re.MULTILINE)
_SECTION_RE = re.compile(r"^#{1,3}\s*(.+?)$", re.MULTILINE)


class ContextLoader:
    """Lazy loader for CONTEXT.md + docs/adr/."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        self._cached: Optional[CodebaseContext] = None

    # --------------------------------------------------------------------- #
    # Public API
    # --------------------------------------------------------------------- #

    def load(self, *, refresh: bool = False) -> CodebaseContext:
        if self._cached is not None and not refresh:
            return self._cached

        ctx = CodebaseContext(
            project_summary=self._load_project_summary(),
            glossary=self._load_glossary(),
            adrs=self._load_adrs(),
            issue_tracker=self._detect_issue_tracker(),
            triage_labels=self._load_triage_labels(),
            docs_dir=self._detect_docs_dir(),
        )
        self._cached = ctx
        return ctx

    def render_for_prompt(self, max_chars: int = 6000) -> str:
        """Render CodebaseContext as a compact prompt-ready string."""
        ctx = self.load()
        out: list[str] = []
        if ctx.project_summary:
            out.append(f"## Project\n{ctx.project_summary.strip()}")
        if ctx.glossary:
            out.append("## Glossary")
            for term in ctx.glossary:
                line = f"- **{term.term}** — {term.definition}"
                if term.avoid:
                    line += f" (avoid: {', '.join(term.avoid)})"
                out.append(line)
        if ctx.adrs:
            out.append("## ADRs")
            for adr in ctx.adrs:
                out.append(f"- ADR-{adr.number:04d} [{adr.status}] {adr.title}")
        if ctx.triage_labels:
            out.append(f"## Triage labels\n{', '.join(ctx.triage_labels)}")
        rendered = "\n\n".join(out)
        if len(rendered) > max_chars:
            rendered = rendered[: max_chars - 1] + "…"
        return rendered or "(no CONTEXT.md or ADRs found — running ungrounded)"

    # --------------------------------------------------------------------- #
    # Private parsers
    # --------------------------------------------------------------------- #

    def _read(self, relative: str) -> Optional[str]:
        p = self.repo_root / relative
        if not p.exists() or not p.is_file():
            return None
        try:
            return p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None

    def _load_project_summary(self) -> Optional[str]:
        text = self._read("CONTEXT.md")
        if not text:
            return None
        # First paragraph after first H1.
        m = re.search(r"^#\s+.+?$\s*\n+(.+?)(?:\n#|\Z)", text, re.DOTALL | re.MULTILINE)
        if m:
            return m.group(1).strip()
        return text.strip()[:600]

    def _load_glossary(self) -> list[GlossaryTerm]:
        text = self._read("CONTEXT.md")
        if not text:
            return []
        gh = _GLOSSARY_HEADING_RE.search(text)
        if not gh:
            return []
        # Slice from glossary heading to next H1/H2.
        body = text[gh.end() :]
        next_heading = re.search(r"^#{1,2}\s", body, re.MULTILINE)
        body = body[: next_heading.start()] if next_heading else body
        terms: list[GlossaryTerm] = []
        for m in _TERM_BULLET_RE.finditer(body):
            term, definition = m.group(1).strip(), m.group(2).strip()
            avoid_match = _AVOID_RE.search(definition)
            avoid: list[str] = []
            if avoid_match:
                avoid = [s.strip() for s in avoid_match.group(1).split(",") if s.strip()]
                definition = _AVOID_RE.sub("", definition).rstrip(" ;,.")
            terms.append(GlossaryTerm(term=term, definition=definition, avoid=avoid))
        return terms

    def _load_adrs(self) -> list[ADR]:
        adr_dir = self.repo_root / "docs" / "adr"
        if not adr_dir.is_dir():
            adr_dir = self.repo_root / "docs" / "adrs"
        if not adr_dir.is_dir():
            return []
        out: list[ADR] = []
        for path in sorted(adr_dir.glob("*.md")):
            m = _ADR_FILENAME_RE.match(path.name)
            if not m:
                continue
            number = int(m.group(1))
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            title = self._extract_title(text) or m.group(2).replace("-", " ").title()
            status = self._extract_status(text)
            out.append(
                ADR(
                    number=number,
                    title=title,
                    status=status,
                    context=self._extract_section(text, "context"),
                    decision=self._extract_section(text, "decision"),
                    consequences=self._extract_section(text, "consequences"),
                    path=path,
                )
            )
        return out

    @staticmethod
    def _extract_title(text: str) -> Optional[str]:
        m = re.search(r"^#\s+(.+?)$", text, re.MULTILINE)
        return m.group(1).strip() if m else None

    @staticmethod
    def _extract_status(text: str) -> str:
        m = _STATUS_RE.search(text)
        if not m:
            return "accepted"
        raw = m.group(1).strip().lower()
        for ok in ("proposed", "accepted", "deprecated", "superseded"):
            if ok in raw:
                return ok  # type: ignore[return-value]
        return "accepted"

    @staticmethod
    def _extract_section(text: str, name: str) -> str:
        # Find heading like "## Context" / "### Decision" etc.
        pat = re.compile(rf"^#{{1,3}}\s*{re.escape(name)}\b", re.IGNORECASE | re.MULTILINE)
        m = pat.search(text)
        if not m:
            return ""
        body = text[m.end() :]
        nxt = re.search(r"^#{1,3}\s", body, re.MULTILINE)
        body = body[: nxt.start()] if nxt else body
        return body.strip()

    def _detect_issue_tracker(self) -> str:
        if (self.repo_root / ".github").is_dir() or (self.repo_root / ".github" / "ISSUE_TEMPLATE").is_dir():
            return "github"
        if (self.repo_root / ".linear").exists():
            return "linear"
        if (self.repo_root / "issues").is_dir() or (self.repo_root / "ISSUES.md").exists():
            return "local"
        return "local"

    def _load_triage_labels(self) -> list[str]:
        # Look in .claude/triage-labels.txt or CONTEXT.md ## Triage labels.
        cfg = self.repo_root / ".claude" / "triage-labels.txt"
        if cfg.exists():
            return [l.strip() for l in cfg.read_text().splitlines() if l.strip()]
        text = self._read("CONTEXT.md") or ""
        m = re.search(
            r"#{1,3}\s*triage\s+labels\s*\n+([\s\S]+?)(?:\n#|\Z)",
            text,
            re.IGNORECASE,
        )
        if m:
            block = m.group(1)
            labels = re.findall(r"`([^`]+)`|[-*]\s*(\S+)", block)
            return [a or b for a, b in labels if (a or b)]
        return []

    def _detect_docs_dir(self) -> str:
        for cand in ("docs", "doc", "documentation"):
            if (self.repo_root / cand).is_dir():
                return cand
        return "docs"
