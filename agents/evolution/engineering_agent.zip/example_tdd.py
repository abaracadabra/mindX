"""examples/example_tdd.py — End-to-end TDD example.

The agent will:
  1. Read CONTEXT.md + ADRs to ground vocabulary.
  2. Confirm the public interface with you (in production this is interactive).
  3. List behaviours to test.
  4. Run RED → GREEN → REFACTOR cycles, calling pytest/vitest as it goes.

Requires ANTHROPIC_API_KEY.

    python examples/example_tdd.py /path/to/repo "add a /healthz endpoint that returns {status: ok}"
"""
from __future__ import annotations

import asyncio
import sys

from rich import print as rprint

from engineering_agent import EngineeringDeps, SkillName, run_skill_directly


async def main() -> None:
    if len(sys.argv) < 3:
        print("usage: example_tdd.py <repo_root> <feature_description>", file=sys.stderr)
        sys.exit(2)
    repo, feature = sys.argv[1], sys.argv[2]

    async with EngineeringDeps.for_repo(repo) as deps:
        result = await run_skill_directly(SkillName.TDD, feature, deps)
    run = result.artifact

    rprint(f"[bold green]✓ TDD run complete[/bold green]")
    rprint(f"\n[bold]Feature:[/bold] {run.feature}")
    rprint(f"[bold]Interface:[/bold] {run.interface}\n")
    for i, cycle in enumerate(run.cycles, 1):
        rprint(f"[bold cyan]Cycle {i}:[/bold cyan] {cycle.behaviour}")
        rprint(f"  test:  {cycle.test_path}")
        rprint(f"  RED:   {cycle.red_evidence[:120]}…")
        rprint(f"  GREEN: {cycle.green_diff_summary}")
        if cycle.refactor_summary:
            rprint(f"  REFACTOR: {cycle.refactor_summary}")
    if run.refactor_notes:
        rprint("\n[bold]Refactor notes:[/bold]")
        for n in run.refactor_notes:
            rprint(f"  - {n}")


if __name__ == "__main__":
    asyncio.run(main())
