"""engineering_agent.skills.triage — One issue, one role transition, one label change."""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext

from ..deps import EngineeringDeps
from ..models import TriageDecision
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def list_labels(ctx: RunContext[EngineeringDeps]) -> list[str]:
        """Return the repo's allowed triage labels (CONTEXT.md / .claude/triage-labels.txt)."""
        return ctx.deps.context_loader.load().triage_labels

    @agent.tool
    async def list_open_issues(ctx: RunContext[EngineeringDeps], limit: int = 50) -> list[dict]:
        return [r.__dict__ for r in await ctx.deps.issues.list(limit=limit)]

    @agent.tool
    async def apply_label(
        ctx: RunContext[EngineeringDeps], issue_id: str, label: str
    ) -> dict:
        """Apply a label. Refuses unknown labels (proposed labels go to the user)."""
        allowed = ctx.deps.context_loader.load().triage_labels
        if allowed and label not in allowed:
            raise ModelRetry(
                f"label '{label}' not in allowed vocabulary {allowed}. "
                "Either pick an existing label, or surface the proposal to the user "
                "before re-running."
            )
        await ctx.deps.issues.add_label(issue_id, label)
        return {"issue_id": issue_id, "label": label, "applied": True}


triage_agent = make_skill_agent(
    SkillSpec(name="triage", output_type=TriageDecision, tools=_register_tools)
)
