"""engineering_agent.skills.to_issues — Break a PRD into vertical-slice issues."""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext

from ..deps import EngineeringDeps
from ..models import IssuesPlan, VerticalSlice
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def file_slice(
        ctx: RunContext[EngineeringDeps],
        title: str,
        user_value: str,
        acceptance: list[str],
        depends_on: list[str] | None = None,
        labels: list[str] | None = None,
    ) -> dict:
        """File a single vertical slice as an issue.

        Refuses if the issue lacks user-facing value (signal of horizontal slicing).
        """
        smell = ("data layer", "api layer", "ui layer", "refactor only", "infrastructure only")
        if any(s in user_value.lower() for s in smell):
            raise ModelRetry(
                f"slice '{title}' looks horizontal (matched: {[s for s in smell if s in user_value.lower()]}). "
                "Rewrite as user-facing value."
            )
        body_lines = [f"**User value.** {user_value}", "", "## Acceptance"]
        body_lines += [f"- [ ] {a}" for a in acceptance]
        if depends_on:
            body_lines += ["", "## Depends on"] + [f"- {d}" for d in depends_on]
        ref = await ctx.deps.issues.create(
            title=title, body="\n".join(body_lines), labels=labels or []
        )
        return {"id": ref.id, "url": ref.url, "title": ref.title}

    @agent.tool
    async def validate_dag(
        ctx: RunContext[EngineeringDeps], slices_json: list[dict]
    ) -> dict:
        """Confirm depends_on edges form a DAG (no cycles, no dangling refs)."""
        titles = {s["title"] for s in slices_json}
        # Cycle check via DFS.
        graph = {s["title"]: list(s.get("depends_on", [])) for s in slices_json}
        for dep in (d for deps in graph.values() for d in deps):
            if dep not in titles:
                return {"ok": False, "reason": f"dangling dependency: {dep}"}
        WHITE, GREY, BLACK = 0, 1, 2
        color = {t: WHITE for t in titles}

        def visit(node: str) -> str | None:
            if color[node] == GREY:
                return f"cycle through {node}"
            if color[node] == BLACK:
                return None
            color[node] = GREY
            for d in graph.get(node, []):
                if (cyc := visit(d)) is not None:
                    return cyc
            color[node] = BLACK
            return None

        for t in titles:
            if (cyc := visit(t)) is not None:
                return {"ok": False, "reason": cyc}
        return {"ok": True}


issues_agent = make_skill_agent(
    SkillSpec(name="to-issues", output_type=IssuesPlan, tools=_register_tools)
)
