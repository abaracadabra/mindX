"""engineering_agent.skills.grill_with_docs — Drag a vague plan into specifics."""
from __future__ import annotations

from typing import Any

from pydantic_ai import Agent, ModelRetry, RunContext

from ..deps import EngineeringDeps
from ..models import GlossaryTerm, GrillSession
from .base import SkillSpec, make_skill_agent


def _register_tools(agent: Agent[EngineeringDeps, Any]) -> None:
    @agent.tool
    async def list_glossary(ctx: RunContext[EngineeringDeps]) -> list[dict]:
        """Return the project's current glossary terms."""
        return [t.model_dump() for t in ctx.deps.context_loader.load().glossary]

    @agent.tool
    async def list_adrs(ctx: RunContext[EngineeringDeps]) -> list[dict]:
        """Return ADR titles + numbers + statuses (without full bodies)."""
        return [
            {"number": a.number, "title": a.title, "status": a.status}
            for a in ctx.deps.context_loader.load().adrs
        ]

    @agent.tool
    async def read_adr(ctx: RunContext[EngineeringDeps], number: int) -> dict:
        """Read full body of one ADR by number."""
        for a in ctx.deps.context_loader.load().adrs:
            if a.number == number:
                return a.model_dump(mode="json")
        raise ModelRetry(f"ADR-{number} not found")

    @agent.tool
    async def propose_glossary_term(
        ctx: RunContext[EngineeringDeps],
        term: str,
        definition: str,
        avoid: list[str] | None = None,
    ) -> dict:
        """Propose adding a term to the glossary. Returns the proposed term — does NOT write."""
        return GlossaryTerm(term=term, definition=definition, avoid=avoid or []).model_dump()


grill_agent = make_skill_agent(
    SkillSpec(name="grill-with-docs", output_type=GrillSession, tools=_register_tools)
)
