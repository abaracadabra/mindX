"""engineering_agent.models — Shared Pydantic models across all skills.

The engineering agent's contract is its outputs. Each skill emits a strongly
typed artifact; the router agent returns the chosen artifact wrapped in
`EngineeringResult`. These types are also the schema other tools (MCP, A2A,
Foundry deploy scripts, on-chain SkillRegistry) consume.
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Annotated, Literal, Optional

from pydantic import BaseModel, Field, model_validator


# --------------------------------------------------------------------------- #
# Skill registry
# --------------------------------------------------------------------------- #

class SkillName(str, Enum):
    """The nine engineering skills from mattpocock/skills, as a closed set."""
    GRILL_WITH_DOCS = "grill-with-docs"
    TO_PRD = "to-prd"
    TO_ISSUES = "to-issues"
    TRIAGE = "triage"
    TDD = "tdd"
    DIAGNOSE = "diagnose"
    IMPROVE_CODEBASE_ARCHITECTURE = "improve-codebase-architecture"
    ZOOM_OUT = "zoom-out"
    SETUP = "setup-matt-pocock-skills"


# --------------------------------------------------------------------------- #
# Domain context (loaded from CONTEXT.md + docs/adr/)
# --------------------------------------------------------------------------- #

class GlossaryTerm(BaseModel):
    term: str
    definition: str
    avoid: list[str] = Field(default_factory=list, description="Forbidden synonyms.")


class ADR(BaseModel):
    """Architecture Decision Record (one per file in docs/adr/)."""
    number: int = Field(ge=1)
    title: str
    status: Literal["proposed", "accepted", "deprecated", "superseded"]
    context: str
    decision: str
    consequences: str
    path: Path

    model_config = {"arbitrary_types_allowed": True}


class CodebaseContext(BaseModel):
    """Loaded from CONTEXT.md + docs/adr/. The 'shared language' Pocock describes."""
    project_summary: Optional[str] = None
    glossary: list[GlossaryTerm] = Field(default_factory=list)
    adrs: list[ADR] = Field(default_factory=list)
    issue_tracker: Literal["github", "linear", "local"] = "local"
    triage_labels: list[str] = Field(default_factory=list)
    docs_dir: str = "docs"


# --------------------------------------------------------------------------- #
# grill-with-docs
# --------------------------------------------------------------------------- #

class GrillQuestion(BaseModel):
    number: int = Field(ge=1)
    question: str
    decision_branch: str = Field(description="What downstream branch this question resolves.")
    domain_terms_used: list[str] = Field(default_factory=list)


class GrillSession(BaseModel):
    """Output of a grill-with-docs run."""
    plan_summary: str
    questions: list[GrillQuestion] = Field(min_length=1)
    domain_terms_added: list[GlossaryTerm] = Field(default_factory=list)
    adrs_proposed: list[ADR] = Field(default_factory=list)
    open_branches: list[str] = Field(
        default_factory=list,
        description="Decision-tree branches NOT yet resolved; loop until empty.",
    )

    @model_validator(mode="after")
    def _has_progress(self) -> "GrillSession":
        if not self.questions and not self.adrs_proposed:
            raise ValueError("grill produced no questions and no ADRs — at least one required")
        return self


# --------------------------------------------------------------------------- #
# to-prd
# --------------------------------------------------------------------------- #

class PRD(BaseModel):
    title: str
    problem: str
    proposal: str
    affected_modules: list[str] = Field(min_length=1)
    out_of_scope: list[str] = Field(default_factory=list)
    success_criteria: list[str] = Field(min_length=1)
    open_questions: list[str] = Field(default_factory=list)
    domain_terms_used: list[str] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# to-issues
# --------------------------------------------------------------------------- #

class VerticalSlice(BaseModel):
    """An independently grabbable issue. Vertical = behaviour-complete, not layer-complete."""
    title: str
    user_value: str = Field(description="Plain English: what does the user gain?")
    acceptance: list[str] = Field(min_length=1)
    depends_on: list[str] = Field(default_factory=list, description="Titles of prerequisite slices.")
    estimate_hours: Optional[float] = None
    labels: list[str] = Field(default_factory=list)


class IssuesPlan(BaseModel):
    source_doc: str
    slices: list[VerticalSlice] = Field(min_length=1)


# --------------------------------------------------------------------------- #
# triage
# --------------------------------------------------------------------------- #

class TriageRole(str, Enum):
    INTAKE = "intake"
    REPRODUCER = "reproducer"
    PRIORITISER = "prioritiser"
    ASSIGNER = "assigner"
    CLOSER = "closer"


class TriageDecision(BaseModel):
    issue_id: str
    role: TriageRole
    label_changes: list[str] = Field(default_factory=list)
    next_role: Optional[TriageRole] = None
    notes: str


# --------------------------------------------------------------------------- #
# tdd
# --------------------------------------------------------------------------- #

class TestCycle(BaseModel):
    """A single red-green-refactor iteration. NEVER batched."""
    behaviour: str = Field(description="Behaviour under test, in domain language.")
    test_path: str
    red_evidence: str = Field(description="Captured failure output proving the test really fails.")
    green_diff_summary: str = Field(description="Minimal code added to pass the test.")
    refactor_summary: Optional[str] = None

    @model_validator(mode="after")
    def _saw_red_first(self) -> "TestCycle":
        # Sanity: red evidence must look like a failure, not a success.
        if not self.red_evidence.strip():
            raise ValueError("red_evidence empty — a TDD cycle MUST observe a failing test first")
        return self


class TDDRun(BaseModel):
    """Full TDD session for one feature/bug. One cycle per behaviour, sequential."""
    feature: str
    interface: str = Field(description="Public API agreed with user before any code.")
    behaviours_to_test: list[str] = Field(min_length=1)
    cycles: list[TestCycle] = Field(min_length=1)
    refactor_notes: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _no_horizontal_slicing(self) -> "TDDRun":
        # Anti-pattern check: cycles must be vertical, not "all reds then all greens".
        for c in self.cycles:
            if not c.green_diff_summary.strip():
                raise ValueError(
                    f"cycle for '{c.behaviour}' has no GREEN — horizontal slicing detected"
                )
        return self


# --------------------------------------------------------------------------- #
# diagnose
# --------------------------------------------------------------------------- #

class FeedbackLoopKind(str, Enum):
    FAILING_TEST = "failing_test"
    CURL = "curl"
    CLI = "cli"
    HEADLESS_BROWSER = "headless_browser"
    REPLAY_TRACE = "replay_trace"
    THROWAWAY_HARNESS = "throwaway_harness"
    PROPERTY_FUZZ = "property_fuzz"
    BISECT_HARNESS = "bisect_harness"
    DIFFERENTIAL = "differential"
    HITL = "hitl"


class FeedbackLoop(BaseModel):
    kind: FeedbackLoopKind
    description: str
    command: str = Field(description="The actual command/invocation to run the loop.")
    runtime_seconds: float = Field(ge=0)
    determinism: float = Field(ge=0, le=1, description="0=flaky, 1=fully deterministic")

    @model_validator(mode="after")
    def _quality(self) -> "FeedbackLoop":
        if self.runtime_seconds > 30 and self.determinism < 0.95:
            raise ValueError(
                f"loop is {self.runtime_seconds:.1f}s and only {self.determinism:.2f} deterministic — "
                "tighten before proceeding (Phase 1: 'iterate on the loop itself')"
            )
        return self


class Hypothesis(BaseModel):
    rank: int = Field(ge=1, le=5)
    cause: str
    prediction: str = Field(
        description="Falsifiable prediction. Format: 'If <cause> is the cause, "
                    "then <action> will make the bug disappear / make it worse.'"
    )

    @model_validator(mode="after")
    def _falsifiable(self) -> "Hypothesis":
        low = self.prediction.lower()
        if "if " not in low or ("disappear" not in low and "worse" not in low and "change" not in low):
            raise ValueError(
                f"hypothesis #{self.rank} not falsifiable — must follow 'If X then Y' template"
            )
        return self


class Diagnosis(BaseModel):
    bug_summary: str
    feedback_loop: FeedbackLoop
    reproduction_confirmed: bool
    hypotheses: list[Hypothesis] = Field(min_length=3, max_length=5)
    instrumentation_plan: list[str] = Field(min_length=1)
    confirmed_cause: Optional[str] = None
    fix_summary: Optional[str] = None
    regression_test_path: Optional[str] = None
    architecture_handoff: Optional[str] = Field(
        default=None,
        description="Recommendation for /improve-codebase-architecture if no good seam exists.",
    )
    debug_log_prefix: str = Field(
        default="[DEBUG-XXXX]",
        description="Tag used on every debug log; greppable for Phase 6 cleanup.",
    )

    @model_validator(mode="after")
    def _ranks_unique(self) -> "Diagnosis":
        ranks = [h.rank for h in self.hypotheses]
        if len(set(ranks)) != len(ranks):
            raise ValueError("hypothesis ranks must be unique 1..N")
        return self


# --------------------------------------------------------------------------- #
# improve-codebase-architecture
# --------------------------------------------------------------------------- #

class DeepeningOpportunity(BaseModel):
    """A place where complexity can move behind a simpler interface (Ousterhout deep modules)."""
    location: str = Field(description="Module / file / function path.")
    current_interface: str = Field(description="Width of current public surface.")
    proposed_interface: str = Field(description="Narrower surface that hides more.")
    rationale: str
    blocking_adrs: list[int] = Field(default_factory=list, description="ADR numbers that gate this.")
    risk: Literal["low", "medium", "high"] = "medium"


class ArchitectureReview(BaseModel):
    repo_summary: str
    domain_terms_referenced: list[str] = Field(default_factory=list)
    opportunities: list[DeepeningOpportunity] = Field(min_length=1)
    out_of_scope_findings: list[str] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# zoom-out
# --------------------------------------------------------------------------- #

class SystemView(BaseModel):
    focus_path: str = Field(description="The narrow location the user was looking at.")
    one_paragraph_role: str = Field(description="What this code does at the system level.")
    upstream_callers: list[str] = Field(default_factory=list)
    downstream_dependencies: list[str] = Field(default_factory=list)
    related_adrs: list[int] = Field(default_factory=list)
    related_glossary: list[str] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# setup-matt-pocock-skills
# --------------------------------------------------------------------------- #

class RepoSetup(BaseModel):
    issue_tracker: Literal["github", "linear", "local"]
    triage_labels: list[str] = Field(min_length=1)
    docs_dir: str = "docs"
    context_md_created: bool = False
    adr_dir_created: bool = False


# --------------------------------------------------------------------------- #
# Top-level result
# --------------------------------------------------------------------------- #

# Discriminated union of every skill's output. Pydantic AI returns this as the
# router's output_type, so the caller gets a single typed envelope.
SkillArtifact = Annotated[
    GrillSession | PRD | IssuesPlan | TriageDecision | TDDRun | Diagnosis
    | ArchitectureReview | SystemView | RepoSetup,
    Field(discriminator=None),  # by-shape, not by-tag (Pydantic v2 picks the right one)
]


class EngineeringResult(BaseModel):
    """The engineering router's typed envelope."""
    skill_used: SkillName
    rationale: str = Field(description="Why this skill was chosen for the request.")
    artifact: SkillArtifact
    timestamp: datetime = Field(default_factory=datetime.utcnow)
