# WISDOM

**PYTHAI knowledge delivery daemon.** x402-gated, octal-enforced,
throttle-priced file sovereignty on pure Node.js core. **Zero npm
dependencies** — there is no supply chain to attack because there is no
supply chain.

> Knowledge delivered; wisdom is in the deployment.

Part of the PYTHAI ecosystem: [AgenticPlace](https://agenticplace.pythai.net)
· [mindX](https://mindx.pythai.net) · [BANKON](https://bankon.pythai.net) ·
publishes to [RAGE](https://rage.pythai.net). Chain mapping:
[allchain.html](https://agenticplace.pythai.net/allchain.html).

## What it does

Every file uploaded to WISDOM is born `0600`, content-addressed by SHA-256,
registered to its uploader's Algorand address, and released only against a
settled x402 payment signed by **parsec / parsec-wallet** on **Algorand
mainnet**. Bandwidth is a paid dimension: the tier the client pays for sets
the bytes-per-second of the stream that serves them. The kernel's own nix
octet is the second enforcement layer. No `.htaccess` — Node serves directly
and policy lives in committed code, not hidden files in the content tree.

## The flow

```
upload ──▶ born 0600, sha256 digest ──▶ RECEIPT {digest, payTo, price, tiers}
GET /asset/<digest> ──▶ 402 + algorand-mainnet terms
parsec-wallet pays ──▶ note = base64("x402:<digest>:<tierId>")
retry + X-PAYMENT ──▶ verified on-chain, txid single-use ──▶ throttled stream
```

Settled payment **is** the credential. No accounts, no API keys, no sessions.
A mindX agent, an llms.txt-reading crawler, and a human in a browser all walk
the identical path.

## Run

```bash
# permissioned boot (Node 24 LTS) — deny by default, grant by declaration
npm start

# Node 26+: network permission is also gated
npm run start:26

# prove it
npm test
```

Routes: `GET /llms.txt` (free — the menu) · `POST /asset?choice=gated&price=10000&payTo=ALGO_ADDR&title=...`
(receive, returns receipt) · `GET /asset/<digest>` (x402 gate → throttled send)
· `GET /health`.

Permission choices map to octets server-side: `private 0600` · `gated 0640` ·
`gated-executable 0750` · `public 0644`. Unknown input collapses to `0600`.

## Deploy (Podman, mainnet posture)

```bash
podman build -t wisdom -f deploy/Containerfile .
cp deploy/wisdom.container ~/.config/containers/systemd/
systemctl --user daemon-reload && systemctl --user start wisdom
```

Container runs read-only, all capabilities dropped, `NoNewPrivileges`, vault
and state on named volumes. Set `DEFAULT_PAY_TO` to the BANKON settlement
address. The EVM mirror of this gate (X402AccessGate, DAIO stack) is
Foundry-tested and mainnet-only; this daemon is its Algorand leg.

## License

Apache-2.0. No admin keys post-deploy. No upgradeable anything.

*PYTHAI Knowledge Delivery © BANKON — all rights preserved.*
